# Groww Trading API

Facts below were verified on **2026-10-30** from the official Groww Trading API documentation, the
growwapi 1.5.0 SDK source (feed, NATS client, protobuf schema) and the instrument CSV header. No live
account was available, so live connectivity is **unverified**, and Groww has more open questions
than Zerodha (see [Verifying live](#verifying-live)). The same values drive the code:
`backend/app/providers/capabilities.py`, `backend/app/providers/groww/constants.py` and
`topics.py`.

Official documentation:

- Trading API: <https://groww.in/trade-api/docs>
- Python SDK: <https://groww.in/trade-api/docs/python-sdk>
- Live feed: <https://groww.in/trade-api/docs/python-sdk/feed>
- Instruments: <https://groww.in/trade-api/docs/python-sdk/instruments>
- Annexures (exchanges, segments, limits): <https://groww.in/trade-api/docs/python-sdk/annexures>
- REST (curl): <https://groww.in/trade-api/docs/curl>

## Subscription requirements

- **An active Groww Trading API subscription.** Groww publishes no official price page;
  third-party sources cite INR 499/month plus taxes.
- **Coverage:** NSE and BSE cash and F&O, plus indices. Groww documents no commodity (MCX) or
  currency feed.
- **Data use:** no Trading-API-specific redistribution terms were found, so treat the data as being
  for the account holder's own use only.

## Setting up an account and daily tokens

Access tokens expire daily. The expiry is taken from the token's own `exp` claim when it has a
plausible one; otherwise 06:00 IST the next day is assumed. Nothing renews a token automatically:
choose one of three methods when adding the account, then create or paste a token each trading day.

| Method (`--method`) | Stored on the account (encrypted) | Daily step |
| --- | --- | --- |
| `access-token` (default) | Nothing until you paste a token | Generate a token in Groww Cloud, then `qt groww set-token` or Providers → **Sign in** |
| `api-key-secret` | API key and secret | Approve the key in Groww Cloud, then `qt groww create-token` or Providers → **Sign in** |
| `totp` | API key (Groww's TOTP token) and, optionally, the TOTP secret | `qt groww create-token` (pass `--code` from your authenticator if no secret is stored) |

```powershell
qt accounts add groww Main --method totp
qt accounts set-credentials Main -p groww --api-key --totp-secret   # prompted without echo
qt accounts enable Main -p groww
qt groww create-token Main                                          # each trading day
```

- `api-key-secret` sends `{"key_type": "approval", "checksum": SHA-256(secret + timestamp), "timestamp": ...}`
  to `POST /token/api/access`.
- `totp` sends `{"key_type": "totp", "totp": "<6 digits>"}`. Codes are RFC 6238 (SHA-1, 6 digits,
  30-second steps).
- Groww allows **150 access-token requests per 24 hours**, and the platform refuses to go over that
  budget.
- `GROWW_API_KEY` and `GROWW_API_SECRET` in `backend/.env` are only a fallback for the
  `api-key-secret` method. Daily tokens are never put in `.env`.
- `qt groww logout` deletes the stored token; Groww has no logout API.

## Instruments

Run `qt instruments refresh groww` daily. It downloads
`https://growwapi-assets.groww.in/instruments/instrument.csv` (`GROWW_INSTRUMENTS_URL`). Exchange
tokens are unique only within one exchange and segment, so the platform's provider token is
`EXCHANGE|SEGMENT|exchange_token` (for example `NSE|CASH|2885` or `NSE|INDEX|NIFTY`).

## Streaming

- **Transport: NATS over WebSocket** at `wss://socket-api.groww.in` (`GROWW_SOCKET_URL`), taken from
  the official SDK source because Groww's prose documentation does not describe it. Each connection
  creates a fresh Ed25519 NKEY pair and exchanges its public key for a socket JWT at
  `POST /api/apex/v1/socket/token/create`. Payloads are protobuf, decoded by a built-in decoder;
  the growwapi SDK is not a runtime dependency.
- **Subjects:**
  - cash: `/ld/eq/{nse|bse}/price.<token>` and `.../book.<token>`;
  - F&O: `/ld/fo/{nse|bse}/price.<token>` and `.../book.<token>`;
  - indices: `/ld/indices/{nse|bse}/price.<token>`.
- Tokens are checked against a strict allow-list before they become subjects. A NATS wildcard
  (`*`, `>`) or an extra `.` could otherwise subscribe the connection to unrelated subjects, such as
  the account's order and position updates.
- **Modes:** LTP and QUOTE both use the price subject. FULL adds the book (depth) subject and
  therefore uses two subscriptions. Indices have only a value feed.
- **Limits:** 1000 subscriptions per connection, and one feed connection per account is assumed.
  The client pings every 60 s. nats-py buffers up to 1000 messages or 1 MiB per subscription and
  drops messages past that, reporting a slow consumer.
- **Depth** is an aggregated price-level book of variable size, not a fixed 5-level array.

### Field mapping

Protobuf field names as decoded (the SDK shows some in camelCase, such as `tsInMillis`, `bidQty` and
`offerQty`):

| Feed field | Platform field | Status |
| --- | --- | --- |
| `ltp` (indices: `value`) | `last_price` | documented |
| `open`, `high`, `low` | `open_price`, `high_price`, `low_price` | documented |
| `avg_price`, `open_interest` | `average_price`, `open_interest` | documented |
| `close` | `previous_close` | assumed previous session close (**verify live**) |
| `bid_qty`, `offer_qty` | `bid_quantity`, `ask_quantity` | assumed best bid/offer quantities (**verify live**) |
| `ts_in_millis` | `provider_timestamp` | meaning unknown: exchange, trade or publish time (**verify live**) |
| `volume` | `volume` | **ignored** unless `GROWW_FEED_VOLUME_IS_CUMULATIVE=true`; until then Groww candles have no volume |

Set `GROWW_FEED_VOLUME_IS_CUMULATIVE=true` only after confirming on the live feed that `volume` is
the day's cumulative volume.

## REST API used

Base URL `https://api.groww.in/v1` (`GROWW_API_BASE_URL`).

| Call | Use | Limit (applied by the platform) |
| --- | --- | --- |
| `POST /token/api/access` | Create access tokens | 5/s and 30/min (a conservative local limit); 150 tokens per 24 h |
| `POST /api/apex/v1/socket/token/create` | Feed credentials | 20/s and 500/min |
| `GET /user/detail` | Token check | 20/s and 500/min |
| `GET /live-data/ltp` | Live smoke tests only | 10/s and 300/min; ≤50 instruments per call |
| `GET /historical/candles` | Backtest datasets only: historical candles ([backtesting](../backtesting.md)) | 20/s and 500/min |

Like the SDK, the client reads the JSON object of a successful reply whatever its content type. Any
other reply fails with "returned an unexpected response (…)", naming the HTTP status, media type,
redirect target, page title and size, never the body. Unlike the SDK, the client does not follow
redirects. The SDK requests feed credentials at the address above with a trailing `/`, which Groww
redirects to the address without it (HTTP 307, seen live in November 2026), so the client calls
that address directly.

The client also implements `/live-data/quote` and `/live-data/ohlc`, which the platform does not
call. LTP instruments are named `EXCHANGE_TRADINGSYMBOL` (for example `NSE_RELIANCE`), as in the REST
documentation; the SDK docstrings also show `NSE:RELIANCE` (verify live).

Historical candles feed only [backtest datasets](../backtesting.md#step-1-get-candles): live charts and
signals are always built from the live feed. Groww documents them from 2020 onwards, for cash and F&O
instruments only. A request names the instrument by the `groww_symbol` of the instrument master, so
refresh the master if a download says the mapping has no Groww symbol. A download is split into
requests of at most 30 days (up to 5 minutes), 90 days (15 and 30 minutes) or 180 days (1 hour and
1 day), Groww's documented ranges, and sent one after another. The ranges are in
`backend/app/providers/history.py`.

## Verifying live

Groww has many open questions that need a real account:

- The NATS-over-WebSocket transport (from the SDK source only).
- TOTP token expiry: Groww's documentation conflicts ("No Expiry" against daily approval).
- The meaning of `tsInMillis`, `close`, `bidQty`/`offerQty` and `volume` (see the table above).
- The maximum number of concurrent feed connections per account (1 assumed).
- The instrument CSV's `expiry_date` format and `tick_size` units.
- Price scaling, depth ordering, and staying connected outside market hours.
- Historical candles: the response's timestamp format, whether `volume` is per candle, and the
  per-request ranges. The download is tested only against fixtures, not a live account.

Run the read-only live smoke tests from `backend` after creating the day's token and refreshing
instruments:

```powershell
$env:RUN_LIVE_SMOKE = "1"; pytest -m live tests/live
```

Record corrected values with `qt capabilities set groww FIELD=VALUE --source <where you verified it>`
(see the [capability matrix](capability-matrix.md)).
