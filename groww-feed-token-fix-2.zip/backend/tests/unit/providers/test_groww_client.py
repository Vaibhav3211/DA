"""Groww REST client against httpx.MockTransport (no provider is contacted)."""

from __future__ import annotations

import base64
import json
import re
import uuid
from collections.abc import Callable
from datetime import UTC, date, datetime
from typing import Any

import httpx
import pytest

from app.core.errors import AppError, ValidationFailedError
from app.core.logging import REDACTED
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderProtocolError,
    ProviderRateLimitedError,
    ProviderRequestRejectedError,
    ProviderUnavailableError,
)
from app.providers.groww import client as client_module
from app.providers.groww.auth import approval_checksum
from app.providers.groww.client import GrowwProfile, GrowwRestClient, exchange_symbol
from app.providers.groww.exceptions import error_from_response
from app.providers.http import USER_AGENT

BASE_URL = "https://groww.test/v1"
INSTRUMENTS_URL = "https://assets.groww.test/instruments/instrument.csv"
API_KEY = "growwkey123"
API_SECRET = "growwsecret456"
NOW = datetime(2026, 1, 5, 4, 15, 30, tzinfo=UTC)


def _segment(value: object) -> str:
    return base64.urlsafe_b64encode(json.dumps(value).encode()).rstrip(b"=").decode()


# A JWT-shaped access token expiring at 2026-01-06 00:00 UTC.
ACCESS_TOKEN = f"{_segment({'alg': 'HS256'})}.{_segment({'exp': 1767657600})}.c2lnbmF0dXJl"

Handler = Callable[[httpx.Request], httpx.Response]


def make_client(handler: Handler, **kwargs: Any) -> GrowwRestClient:
    return GrowwRestClient(
        base_url=BASE_URL, transport=httpx.MockTransport(handler), clock=lambda: NOW, **kwargs
    )


def recorder(requests: list[httpx.Request], respond: Callable[[], httpx.Response] | None = None) -> Handler:
    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return ok({}) if respond is None else respond()

    return handler


def ok(payload: object) -> httpx.Response:
    return httpx.Response(200, json={"status": "SUCCESS", "payload": payload})


def failure(status: int, code: object, message: str) -> httpx.Response:
    return httpx.Response(status, json={"status": "FAILURE", "error": {"code": code, "message": message}})


# ---- access tokens ---------------------------------------------------------------------------------


async def test_totp_flow_creates_a_token_that_authenticates_later_calls() -> None:
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        if request.url.path == "/v1/token/api/access":
            return httpx.Response(200, json={"token": ACCESS_TOKEN, "tokenRefId": "ref-1"})
        return ok(
            {
                "ucc": "UCC123",
                "nse_enabled": True,
                "bse_enabled": "yes",
                "active_segments": ["CASH", "FNO", 7],
            }
        )

    async with make_client(handler) as client:
        session = await client.create_access_token_with_totp(" TOTPTOKEN42 ", " 123456 ")
        profile = await client.profile()

    create, detail = seen
    assert (create.method, create.url.path) == ("POST", "/v1/token/api/access")
    assert json.loads(create.content) == {"key_type": "totp", "totp": "123456"}
    assert create.headers["Authorization"] == "Bearer TOTPTOKEN42"
    assert create.headers["Accept"] == "application/json"
    assert create.headers["x-api-version"] == "1.0"
    assert create.headers["User-Agent"] == USER_AGENT
    assert (detail.method, detail.url.path) == ("GET", "/v1/user/detail")
    assert detail.headers["Authorization"] == f"Bearer {ACCESS_TOKEN}"
    assert len({uuid.UUID(request.headers["x-request-id"]) for request in seen}) == 2

    assert session.access_token == ACCESS_TOKEN
    assert session.issued_at == NOW
    assert session.expires_at == datetime(2026, 1, 6, tzinfo=UTC)  # the token's own exp claim
    assert ACCESS_TOKEN not in repr(session)
    assert profile == GrowwProfile(user_ref="UCC123", exchanges=("NSE",), segments=("CASH", "FNO"))


async def test_approval_flow_sends_a_checksum_and_never_the_secret() -> None:
    requests: list[httpx.Request] = []
    async with make_client(recorder(requests, lambda: ok({"token": "opaque-access-token"}))) as client:
        session = await client.create_access_token_with_secret(f" {API_KEY} ", API_SECRET)

    [create] = requests
    timestamp = int(NOW.timestamp())
    assert json.loads(create.content) == {
        "key_type": "approval",
        "checksum": approval_checksum(API_SECRET, timestamp),
        "timestamp": timestamp,
    }
    assert create.headers["Authorization"] == f"Bearer {API_KEY}"
    assert API_SECRET not in create.content.decode()
    assert all(API_SECRET not in value for value in create.headers.values())
    assert session.access_token == "opaque-access-token"
    assert session.expires_at == datetime(2026, 1, 6, 0, 30, tzinfo=UTC)  # no exp claim: next 06:00 IST


@pytest.mark.parametrize(
    ("api_key", "totp", "message"),
    [
        (API_KEY, "12345", "6 to 8 digits"),
        (API_KEY, "123456789", "6 to 8 digits"),
        (API_KEY, "12a456", "6 to 8 digits"),
        (API_KEY, "\u0661\u0662\u0663\u0664\u0665\u0666", "6 to 8 digits"),
        ("", "123456", "API key is empty or contains invalid characters"),
        ("key with spaces", "12345678", "API key is empty or contains invalid characters"),
        ("k\u00e9y", "123456", "API key is empty or contains invalid characters"),
    ],
)
async def test_invalid_totp_inputs_are_rejected_before_any_request(
    api_key: str, totp: str, message: str
) -> None:
    requests: list[httpx.Request] = []
    async with make_client(recorder(requests)) as client:
        with pytest.raises(ValidationFailedError) as caught:
            await client.create_access_token_with_totp(api_key, totp)
    assert message in caught.value.message
    assert requests == []


@pytest.mark.parametrize(
    ("api_key", "secret", "message"),
    [(API_KEY, " ", "API secret is required"), ("  ", API_SECRET, "API key is empty")],
)
async def test_invalid_approval_inputs_are_rejected_before_any_request(
    api_key: str, secret: str, message: str
) -> None:
    requests: list[httpx.Request] = []
    async with make_client(recorder(requests)) as client:
        with pytest.raises(ValidationFailedError) as caught:
            await client.create_access_token_with_secret(api_key, secret)
    assert message in caught.value.message
    assert requests == []


@pytest.mark.parametrize(
    "body",
    [
        {"status": "SUCCESS", "payload": {}},
        {"status": "SUCCESS", "payload": ["token"]},
        {"token": ""},
        {"token": 7},
        {"token": "two words"},
    ],
)
async def test_access_token_responses_without_a_token_are_protocol_errors(body: object) -> None:
    async with make_client(lambda _request: httpx.Response(200, json=body)) as client:
        with pytest.raises(ProviderProtocolError, match="access token response has no token"):
            await client.create_access_token_with_totp(API_KEY, "123456")
        with pytest.raises(ProviderAuthRequiredError, match="connect the Groww account first"):
            await client.profile()


# ---- failures --------------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("response", "expected", "text"),
    [
        (
            failure(401, "GA005", "Invalid token"),
            ProviderAuthRequiredError,
            "access token (Invalid token; code GA005)",
        ),
        (
            failure(403, "GA006", "Forbidden"),
            ProviderRequestRejectedError,
            "denied the request (Forbidden; code GA006)",
        ),
        (
            failure(429, "GA429", "Slow down"),
            ProviderRateLimitedError,
            "rate limit exceeded (Slow down; code GA429)",
        ),
        (failure(500, "GA000", "Internal"), ProviderUnavailableError, "server error (Internal; code GA000)"),
        (
            failure(200, "GA001", "Bad request"),
            ProviderRequestRejectedError,
            "the request (Bad request; code GA001)",
        ),
        (failure(400, 1234, "Bad input"), ProviderRequestRejectedError, "(Bad input; code 1234)"),
        (failure(400, True, "Bad input"), ProviderRequestRejectedError, "(Bad input)"),
        (
            httpx.Response(400, json={"error": {"displayMessage": "Invalid TOTP"}}),
            ProviderRequestRejectedError,
            "(Invalid TOTP)",
        ),
        (
            httpx.Response(400, json={"status": "FAILURE", "message": "Top level"}),
            ProviderRequestRejectedError,
            "(Top level)",
        ),
        (httpx.Response(502, json={}), ProviderUnavailableError, "server error (HTTP 502)"),
        (httpx.Response(401, json=["denied"]), ProviderAuthRequiredError, "access token (HTTP 401)"),
        (
            httpx.Response(502, text="{", headers={"content-type": "application/json"}),
            ProviderUnavailableError,
            "(HTTP 502)",
        ),
        (
            httpx.Response(503, text="<html>down</html>", headers={"content-type": "text/html"}),
            ProviderUnavailableError,
            "(HTTP 503)",
        ),
        (httpx.Response(429, text="slow down"), ProviderRateLimitedError, "rate limit exceeded (HTTP 429)"),
        (
            httpx.Response(200, text="hello"),
            ProviderProtocolError,
            "profile request returned an unexpected response (HTTP 200, text/plain, 5 bytes)",
        ),
        (
            httpx.Response(200, text="{", headers={"content-type": "application/json"}),
            ProviderProtocolError,
            "profile request returned invalid JSON (HTTP 200)",
        ),
        (
            httpx.Response(200, json=["a", "list"]),
            ProviderProtocolError,
            "profile request returned an unexpected payload",
        ),
        (ok(["a", "list"]), ProviderProtocolError, "profile response is not an object"),
    ],
)
async def test_failures_are_translated(response: httpx.Response, expected: type[AppError], text: str) -> None:
    async with make_client(lambda _request: response, access_token=ACCESS_TOKEN) as client:
        with pytest.raises(expected) as caught:
            await client.profile()
    assert caught.value.message.startswith("Groww ")
    assert text in caught.value.message


async def test_error_messages_are_redacted_and_bounded() -> None:
    message = f"Bearer {ACCESS_TOKEN} rejected; token={ACCESS_TOKEN}; raw {ACCESS_TOKEN} " + "x" * 400
    async with make_client(
        lambda _request: failure(401, "GA005", message), access_token=ACCESS_TOKEN
    ) as client:
        with pytest.raises(ProviderAuthRequiredError) as caught:
            await client.profile()
    assert ACCESS_TOKEN not in caught.value.message
    assert REDACTED in caught.value.message
    assert "x" * 300 not in caught.value.message
    assert "; code GA005)" in caught.value.message


def test_error_codes_are_bounded() -> None:
    error = error_from_response(400, "  " + "C" * 100 + "  ", "bad")
    assert error.message == f"Groww rejected the request (bad; code {'C' * 40})"


@pytest.mark.parametrize(
    ("failure_type", "text"),
    [(httpx.ConnectError, "Groww profile request failed: ConnectError"), (httpx.ReadTimeout, "timed out")],
)
async def test_transport_failures_do_not_echo_the_request(
    failure_type: type[httpx.TransportError], text: str
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise failure_type(
            f"cannot reach {request.url} with {request.headers['Authorization']}", request=request
        )

    async with make_client(handler, access_token=ACCESS_TOKEN) as client:
        with pytest.raises(ProviderUnavailableError) as caught:
            await client.profile()
    assert text in caught.value.message
    assert ACCESS_TOKEN not in caught.value.message
    assert caught.value.__cause__ is None
    assert caught.value.__suppress_context__


@pytest.mark.parametrize(
    ("access_token", "message"),
    [
        (None, "connect the Groww account first"),
        ("", "connect the Groww account first"),
        ("two words", "malformed"),
    ],
)
async def test_authenticated_calls_need_a_well_formed_access_token(
    access_token: str | None, message: str
) -> None:
    requests: list[httpx.Request] = []
    async with make_client(recorder(requests), access_token=access_token) as client:
        with pytest.raises(ProviderAuthRequiredError, match=message):
            await client.profile()
        with pytest.raises(ProviderAuthRequiredError, match=message):
            await client.socket_token("UPUBLICKEY")
    assert requests == []


# ---- account, feed and market data -----------------------------------------------------------------


async def test_profile_tolerates_missing_fields() -> None:
    async with make_client(
        lambda _request: ok({"vendor_user_id": "V-1", "active_segments": "CASH"}), access_token=ACCESS_TOKEN
    ) as client:
        assert await client.profile() == GrowwProfile(user_ref="V-1", exchanges=(), segments=())
    async with make_client(
        lambda _request: ok({"ucc": "", "bse_enabled": True}), access_token=ACCESS_TOKEN
    ) as client:
        assert await client.profile() == GrowwProfile(user_ref=None, exchanges=("BSE",), segments=())


async def test_socket_token_is_requested_for_the_connection_key() -> None:
    requests: list[httpx.Request] = []

    def feed_token() -> httpx.Response:
        return ok({"token": "feed-jwt", "subscriptionId": "sub-1"})

    async with make_client(recorder(requests, feed_token), access_token=ACCESS_TOKEN) as client:
        assert await client.socket_token("UPUBLICKEY") == "feed-jwt"
    [request] = requests
    assert (request.method, request.url.path) == ("POST", "/v1/api/apex/v1/socket/token/create")
    assert json.loads(request.content) == {"socketKey": "UPUBLICKEY"}
    assert request.headers["Authorization"] == f"Bearer {ACCESS_TOKEN}"


@pytest.mark.parametrize("payload", [{}, {"token": ""}, {"token": 5}, ["feed-jwt"]])
async def test_socket_token_responses_without_a_token_are_protocol_errors(payload: object) -> None:
    async with make_client(lambda _request: ok(payload), access_token=ACCESS_TOKEN) as client:
        with pytest.raises(ProviderProtocolError, match="feed token response has no token"):
            await client.socket_token("UPUBLICKEY")


@pytest.mark.parametrize("headers", [{"content-type": "text/plain; charset=utf-8"}, {}])
async def test_a_json_feed_token_is_read_whatever_its_content_type(headers: dict[str, str]) -> None:
    body = json.dumps({"status": "SUCCESS", "payload": {"token": "feed-jwt"}}).encode()
    async with make_client(
        lambda _request: httpx.Response(200, content=body, headers=headers), access_token=ACCESS_TOKEN
    ) as client:
        assert await client.socket_token("UPUBLICKEY") == "feed-jwt"


PAGE = f"<html><head><TITLE lang=en>\n Access &amp;\n denied </TITLE></head><body>{ACCESS_TOKEN}</body>"


@pytest.mark.parametrize(
    ("response", "description"),
    [
        (
            httpx.Response(302, headers={"location": f"/login?token={ACCESS_TOKEN}#{ACCESS_TOKEN}"}),
            "HTTP 302, no content type, redirect to https://groww.test/login, empty body",
        ),
        (
            httpx.Response(200, text=PAGE, headers={"content-type": "text/html; charset=UTF-8"}),
            f'HTTP 200, text/html, page "Access & denied", {len(PAGE)} bytes',
        ),
        (httpx.Response(200, text='["feed-jwt"]'), "HTTP 200, text/plain, 12 bytes"),
        (httpx.Response(204), "HTTP 204, no content type, empty body"),
    ],
)
async def test_other_feed_token_responses_are_described_without_their_body(
    response: httpx.Response, description: str
) -> None:
    async with make_client(lambda _request: response, access_token=ACCESS_TOKEN) as client:
        with pytest.raises(ProviderProtocolError) as caught:
            await client.socket_token("UPUBLICKEY")
    assert caught.value.message == f"Groww feed token request returned an unexpected response ({description})"


async def test_quote_returns_the_payload_object() -> None:
    requests: list[httpx.Request] = []
    async with make_client(
        recorder(requests, lambda: ok({"last_price": 2501.5})), access_token=ACCESS_TOKEN
    ) as client:
        assert await client.quote("NSE", "CASH", "RELIANCE") == {"last_price": 2501.5}
    [request] = requests
    assert (request.method, request.url.path) == ("GET", "/v1/live-data/quote")
    assert dict(request.url.params) == {"exchange": "NSE", "segment": "CASH", "trading_symbol": "RELIANCE"}

    async with make_client(lambda _request: ok(None), access_token=ACCESS_TOKEN) as client:
        with pytest.raises(ProviderProtocolError, match="quote response is not an object"):
            await client.quote("NSE", "CASH", "RELIANCE")


@pytest.mark.parametrize(("method", "path"), [("ltp", "/v1/live-data/ltp"), ("ohlc", "/v1/live-data/ohlc")])
async def test_ltp_and_ohlc_requests_are_deduplicated_and_batched(
    monkeypatch: pytest.MonkeyPatch, method: str, path: str
) -> None:
    monkeypatch.setattr(client_module, "LTP_OHLC_BATCH_SIZE", 2)
    batches: list[tuple[str | None, list[str]]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == path
        symbols = request.url.params.get_list("exchange_symbols")
        batches.append((request.url.params.get("segment"), symbols))
        if symbols == ["NSE_SBIN"]:
            return ok(["not", "a", "mapping"])  # ignored, the other batches still count
        return ok(dict.fromkeys(symbols, 1.5))

    symbols = [
        exchange_symbol("NSE", "RELIANCE"),
        "NSE_TCS",
        "NSE_RELIANCE",
        "BSE_INFY",
        "NSE_ITC",
        "NSE_SBIN",
    ]
    async with make_client(handler, access_token=ACCESS_TOKEN) as client:
        result = await getattr(client, method)("CASH", symbols)
        assert await getattr(client, method)("CASH", []) == {}
    assert batches == [
        ("CASH", ["NSE_RELIANCE", "NSE_TCS"]),
        ("CASH", ["BSE_INFY", "NSE_ITC"]),
        ("CASH", ["NSE_SBIN"]),
    ]
    assert result == {"NSE_RELIANCE": 1.5, "NSE_TCS": 1.5, "BSE_INFY": 1.5, "NSE_ITC": 1.5}


# ---- instrument master -----------------------------------------------------------------------------


async def test_instrument_master_is_downloaded_without_credentials() -> None:
    requests: list[httpx.Request] = []

    def respond() -> httpx.Response:
        return httpx.Response(200, content=b"exchange,exchange_token\n", headers={"content-type": "text/csv"})

    async with make_client(recorder(requests, respond), access_token=ACCESS_TOKEN) as client:
        assert await client.instruments_csv(INSTRUMENTS_URL) == b"exchange,exchange_token\n"
    [request] = requests
    assert str(request.url) == INSTRUMENTS_URL
    assert "Authorization" not in request.headers
    assert request.headers["Accept"] == "text/csv, */*"
    assert request.extensions["timeout"]["read"] == client_module.INSTRUMENTS_TIMEOUT_SECONDS


@pytest.mark.parametrize(
    ("response", "expected", "text"),
    [
        (httpx.Response(404, text="missing"), ProviderRequestRejectedError, "(HTTP 404)"),
        (httpx.Response(503, text="busy"), ProviderUnavailableError, "(HTTP 503)"),
        (httpx.Response(200, json={"status": "FAILURE"}), ProviderProtocolError, "did not return CSV"),
        (
            httpx.Response(200, text="<html/>", headers={"content-type": "text/html"}),
            ProviderProtocolError,
            "did not return CSV",
        ),
    ],
)
async def test_instrument_download_failures(
    response: httpx.Response, expected: type[AppError], text: str
) -> None:
    async with make_client(lambda _request: response) as client:
        with pytest.raises(expected, match=re.escape(text)):
            await client.instruments_csv(INSTRUMENTS_URL)


@pytest.mark.parametrize(
    ("failure_type", "text"),
    [
        (httpx.ConnectError, "Groww instrument download failed: ConnectError"),
        (httpx.ReadTimeout, "timed out"),
    ],
)
async def test_instrument_download_transport_failures(
    failure_type: type[httpx.TransportError], text: str
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise failure_type("unreachable", request=request)

    async with make_client(handler) as client:
        with pytest.raises(ProviderUnavailableError, match=text):
            await client.instruments_csv(INSTRUMENTS_URL)


# ---- historical candles ----------------------------------------------------------------------------


async def test_historical_candles_cover_whole_exchange_days() -> None:
    requests: list[httpx.Request] = []
    rows = [["2026-01-05T09:15:00", 100, 101, 99, 100.5, 1200, None]]

    async with make_client(
        recorder(requests, lambda: ok({"candles": rows})), access_token=ACCESS_TOKEN
    ) as client:
        candles = await client.historical_candles(
            "NSE", "CASH", "NSE-RELIANCE", "1minute", date(2026, 1, 5), date(2026, 1, 9)
        )

    assert candles == rows
    [request] = requests
    assert (request.method, request.url.path) == ("GET", "/v1/historical/candles")
    assert dict(request.url.params) == {
        "exchange": "NSE",
        "segment": "CASH",
        "groww_symbol": "NSE-RELIANCE",
        "start_time": "2026-01-05 00:00:00",
        "end_time": "2026-01-09 23:59:59",
        "candle_interval": "1minute",
    }


@pytest.mark.parametrize("payload", [None, {}, {"candles": {"0": []}}])
async def test_a_historical_response_without_a_candle_list_is_refused(payload: object) -> None:
    async with make_client(lambda _request: ok(payload), access_token=ACCESS_TOKEN) as client:
        with pytest.raises(ProviderProtocolError, match="historical candle response has no candle list"):
            await client.historical_candles(
                "NSE", "CASH", "NSE-RELIANCE", "1day", date(2026, 1, 5), date(2026, 1, 5)
            )
