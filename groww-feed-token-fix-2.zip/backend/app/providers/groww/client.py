"""Async Groww Trading API REST client (httpx). Supplemental to the live feed, never a substitute.

Requests send ``Authorization: Bearer <token>`` (the API key or TOTP token when creating an access
token, the access token otherwise), ``x-api-version: 1.0`` and a fresh ``x-request-id``, like
growwapi 1.5.0 ``_build_headers``. The SDK's ``x-client-*`` headers describe the SDK itself and are
not sent. Rate limits are enforced per client instance and per API type (see ``constants``).
"""

from __future__ import annotations

import html
import json
import re
import uuid
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date, datetime
from types import TracebackType
from typing import Any, Final, Self

import httpx

from app.core.clock import utc_now
from app.core.errors import ValidationFailedError
from app.core.logging import redact_text
from app.core.rate_limit import SlidingWindowRateLimiter
from app.providers.errors import ProviderAuthRequiredError, ProviderProtocolError
from app.providers.groww.auth import approval_checksum, token_expiry
from app.providers.groww.constants import (
    ACCESS_TOKEN_PATH,
    API_VERSION,
    API_VERSION_HEADER,
    AUTH_RATE_WINDOWS,
    EXCHANGE_SYMBOL_SEPARATOR,
    HISTORICAL_CANDLES_PATH,
    LIVE_DATA_RATE_WINDOWS,
    LTP_OHLC_BATCH_SIZE,
    LTP_PATH,
    NON_TRADING_RATE_WINDOWS,
    OHLC_PATH,
    PROFILE_PATH,
    QUOTE_PATH,
    REQUEST_ID_HEADER,
    SOCKET_TOKEN_PATH,
)
from app.providers.groww.exceptions import PROVIDER_NAME, error_from_response
from app.providers.http import create_http_client, decode_json, error_body, is_json, transport_error

DEFAULT_TIMEOUT_SECONDS = 7.0
INSTRUMENTS_TIMEOUT_SECONDS = 120.0

# Bearer values must be a single printable ASCII token: anything else is a paste error.
_BEARER: Final = re.compile(r"[\x21-\x7e]{1,4096}")
_TOTP_CODE: Final = re.compile(r"[0-9]{6,8}")

# Describing an unexpected response: health views keep the first 200 characters of an error.
_PAGE_TITLE: Final = re.compile(rb"<title(?:\s[^>]*)?>([^<]{1,200})", re.IGNORECASE)
_TITLE_SCAN_BYTES: Final = 4096
_MEDIA_TYPE_LIMIT: Final = 40
_REDIRECT_TARGET_LIMIT: Final = 60
_TITLE_LIMIT: Final = 40


@dataclass(frozen=True, slots=True)
class GrowwSession:
    """A newly created access token."""

    access_token: str = field(repr=False)
    issued_at: datetime
    expires_at: datetime


@dataclass(frozen=True, slots=True)
class GrowwProfile:
    user_ref: str | None
    exchanges: tuple[str, ...]
    segments: tuple[str, ...]


class GrowwRestClient:
    def __init__(
        self,
        *,
        base_url: str,
        access_token: str | None = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        transport: httpx.AsyncBaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self._access_token = access_token
        self._clock = clock
        self._http = create_http_client(
            base_url=base_url,
            timeout=timeout,
            headers={API_VERSION_HEADER: API_VERSION},
            transport=transport,
        )
        self._auth_limiter = SlidingWindowRateLimiter(AUTH_RATE_WINDOWS)
        self._live_limiter = SlidingWindowRateLimiter(LIVE_DATA_RATE_WINDOWS)
        self._default_limiter = SlidingWindowRateLimiter(NON_TRADING_RATE_WINDOWS)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, tb: TracebackType | None
    ) -> None:
        await self.aclose()

    # -- access tokens ----------------------------------------------------------------------------

    async def create_access_token_with_totp(self, api_key: str, totp: str) -> GrowwSession:
        """TOTP flow: the TOTP token is the bearer and ``totp`` the current authenticator code."""
        code = totp.strip()
        if not _TOTP_CODE.fullmatch(code):
            raise ValidationFailedError("the TOTP code must be 6 to 8 digits")
        return await self._create_access_token(api_key, {"key_type": "totp", "totp": code})

    async def create_access_token_with_secret(self, api_key: str, api_secret: str) -> GrowwSession:
        """Approval flow: the API key must have been approved in Groww Cloud for the day."""
        if not api_secret.strip():
            raise ValidationFailedError("a Groww API secret is required")
        timestamp = int(self._clock().timestamp())
        body = {
            "key_type": "approval",
            "checksum": approval_checksum(api_secret, timestamp),
            "timestamp": timestamp,
        }
        return await self._create_access_token(api_key, body)

    async def _create_access_token(self, api_key: str, body: Mapping[str, Any]) -> GrowwSession:
        key = api_key.strip()
        if not _BEARER.fullmatch(key):
            raise ValidationFailedError("the Groww API key is empty or contains invalid characters")
        data = await self._request(
            "POST",
            ACCESS_TOKEN_PATH,
            operation="access token request",
            limiter=self._auth_limiter,
            bearer=key,
            json_body=body,
        )
        token = data.get("token") if isinstance(data, Mapping) else None
        if not isinstance(token, str) or not _BEARER.fullmatch(token):
            raise ProviderProtocolError(f"{PROVIDER_NAME} access token response has no token")
        issued_at = self._clock()
        self._access_token = token
        return GrowwSession(
            access_token=token, issued_at=issued_at, expires_at=token_expiry(token, issued_at)
        )

    # -- account and feed -------------------------------------------------------------------------

    async def profile(self) -> GrowwProfile:
        """Validates the access token. Field names follow the user-detail documentation."""
        data = await self._request("GET", PROFILE_PATH, operation="profile request")
        if not isinstance(data, Mapping):
            raise ProviderProtocolError(f"{PROVIDER_NAME} profile response is not an object")
        user_ref = data.get("ucc") or data.get("vendor_user_id")
        exchanges = tuple(
            name for name, flag in (("NSE", "nse_enabled"), ("BSE", "bse_enabled")) if data.get(flag) is True
        )
        return GrowwProfile(
            user_ref=user_ref if isinstance(user_ref, str) and user_ref else None,
            exchanges=exchanges,
            segments=_strings(data.get("active_segments")),
        )

    async def socket_token(self, public_key: str) -> str:
        """A feed JWT bound to the NKEY ``public_key`` of one connection attempt."""
        data = await self._request(
            "POST",
            SOCKET_TOKEN_PATH,
            operation="feed token request",
            json_body={"socketKey": public_key},
        )
        token = data.get("token") if isinstance(data, Mapping) else None
        if not isinstance(token, str) or not token:
            raise ProviderProtocolError(f"{PROVIDER_NAME} feed token response has no token")
        return token

    # -- market data ------------------------------------------------------------------------------

    async def quote(self, exchange: str, segment: str, trading_symbol: str) -> Mapping[str, Any]:
        """Full quote for one instrument (exchange NSE/BSE, segment CASH/FNO)."""
        data = await self._request(
            "GET",
            QUOTE_PATH,
            operation="quote request",
            limiter=self._live_limiter,
            params={"exchange": exchange, "segment": segment, "trading_symbol": trading_symbol},
        )
        if not isinstance(data, Mapping):
            raise ProviderProtocolError(f"{PROVIDER_NAME} quote response is not an object")
        return data

    async def ltp(self, segment: str, exchange_symbols: Sequence[str]) -> dict[str, Any]:
        """Last prices keyed ``EXCHANGE_TRADINGSYMBOL`` (≤50 per call)."""
        return await self._batched(LTP_PATH, segment, exchange_symbols, "LTP request")

    async def ohlc(self, segment: str, exchange_symbols: Sequence[str]) -> dict[str, Any]:
        return await self._batched(OHLC_PATH, segment, exchange_symbols, "OHLC request")

    async def historical_candles(
        self,
        exchange: str,
        segment: str,
        groww_symbol: str,
        interval: str,
        first_day: date,
        last_day: date,
    ) -> list[Any]:
        """Raw candles ``[timestamp, open, high, low, close, volume, oi]`` from the start of
        ``first_day`` to the end of ``last_day`` (exchange-local dates). Callers keep each request
        within Groww's per-interval range."""
        data = await self._request(
            "GET",
            HISTORICAL_CANDLES_PATH,
            operation="historical candle request",
            params={
                "exchange": exchange,
                "segment": segment,
                "groww_symbol": groww_symbol,
                "start_time": f"{first_day.isoformat()} 00:00:00",
                "end_time": f"{last_day.isoformat()} 23:59:59",
                "candle_interval": interval,
            },
        )
        candles = data.get("candles") if isinstance(data, Mapping) else None
        if not isinstance(candles, list):
            raise ProviderProtocolError(f"{PROVIDER_NAME} historical candle response has no candle list")
        return candles

    async def _batched(
        self, path: str, segment: str, exchange_symbols: Sequence[str], operation: str
    ) -> dict[str, Any]:
        result: dict[str, Any] = {}
        unique = list(dict.fromkeys(exchange_symbols))
        for start in range(0, len(unique), LTP_OHLC_BATCH_SIZE):
            batch = unique[start : start + LTP_OHLC_BATCH_SIZE]
            data = await self._request(
                "GET",
                path,
                operation=operation,
                limiter=self._live_limiter,
                params=httpx.QueryParams(
                    [("segment", segment), *(("exchange_symbols", symbol) for symbol in batch)]
                ),
            )
            if isinstance(data, Mapping):
                result.update(data)
        return result

    async def instruments_csv(self, url: str) -> bytes:
        """The public instrument master CSV. Downloaded without credentials (it is a public file)."""
        try:
            response = await self._http.get(
                url, headers={"Accept": "text/csv, */*"}, timeout=INSTRUMENTS_TIMEOUT_SECONDS
            )
        except httpx.HTTPError as exc:
            raise transport_error(PROVIDER_NAME, "instrument download", exc) from None
        content_type = response.headers.get("content-type", "").lower()
        if response.is_error:
            raise error_from_response(response.status_code, None, None)
        if is_json(response) or "html" in content_type:
            raise ProviderProtocolError(f"{PROVIDER_NAME} instrument download did not return CSV")
        return response.content

    # -- transport --------------------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        operation: str,
        limiter: SlidingWindowRateLimiter | None = None,
        bearer: str | None = None,
        params: Mapping[str, str] | httpx.QueryParams | None = None,
        json_body: Mapping[str, Any] | None = None,
    ) -> Any:
        token = bearer if bearer is not None else self._access_token
        if not token:
            raise ProviderAuthRequiredError(
                f"no {PROVIDER_NAME} access token; connect the Groww account first"
            )
        if not _BEARER.fullmatch(token):
            raise ProviderAuthRequiredError(
                f"the stored {PROVIDER_NAME} access token is malformed; connect the Groww account again"
            )
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            REQUEST_ID_HEADER: str(uuid.uuid4()),
        }
        async with limiter or self._default_limiter:
            try:
                response = await self._http.request(
                    method, path, params=params, json=json_body, headers=headers
                )
            except httpx.HTTPError as exc:
                raise transport_error(PROVIDER_NAME, operation, exc) from None
        if response.is_error:
            code, message = _error_details(error_body(response))
            raise error_from_response(response.status_code, code, message)
        payload = _decode(operation, response)
        if not isinstance(payload, Mapping):
            raise ProviderProtocolError(f"{PROVIDER_NAME} {operation} returned an unexpected payload")
        if payload.get("status") == "FAILURE":
            code, message = _error_details(payload)
            raise error_from_response(response.status_code, code, message)
        return payload.get("payload", payload)


def exchange_symbol(provider_exchange: str, provider_symbol: str) -> str:
    """Instrument key for the LTP and OHLC endpoints, e.g. ``NSE_RELIANCE``."""
    return f"{provider_exchange}{EXCHANGE_SYMBOL_SEPARATOR}{provider_symbol}"


def _decode(operation: str, response: httpx.Response) -> Any:
    """The body of a successful (2xx) response. Like growwapi 1.5.0 ``_parse_response``, a JSON
    object is accepted whatever its content type. A redirect is never the result (redirects are not
    followed) and every other response is described for diagnosis."""
    if response.is_success:
        if is_json(response):
            return decode_json(PROVIDER_NAME, operation, response)
        try:
            payload = json.loads(response.content)
        except (ValueError, RecursionError):
            payload = None
        if isinstance(payload, Mapping):
            return payload
    raise ProviderProtocolError(
        f"{PROVIDER_NAME} {operation} returned an unexpected response ({_describe(response)})"
    )


def _describe(response: httpx.Response) -> str:
    """Status, media type, redirect target, page title and size of a response. The body is never
    quoted (it may carry a token); the redirect target keeps only its scheme, host and path."""
    media_type = response.headers.get("content-type", "").split(";", 1)[0].strip()
    parts = [f"HTTP {response.status_code}", media_type[:_MEDIA_TYPE_LIMIT] or "no content type"]
    if response.next_request is not None:
        parts.append(f"redirect to {_redirect_target(response.next_request.url)}")
    title = _page_title(response.content)
    if title:
        parts.append(f'page "{title}"')
    parts.append(f"{len(response.content)} bytes" if response.content else "empty body")
    return redact_text(", ".join(parts))


def _redirect_target(url: httpx.URL) -> str:
    """httpx resolves the location into ``next_request`` because redirects are not followed."""
    return f"{url.scheme}://{url.host}{url.path}"[:_REDIRECT_TARGET_LIMIT]


def _page_title(content: bytes) -> str | None:
    match = _PAGE_TITLE.search(content[:_TITLE_SCAN_BYTES])
    if match is None:
        return None
    title = " ".join(html.unescape(match.group(1).decode("utf-8", "replace")).split())
    return title[:_TITLE_LIMIT] or None


def _error_details(payload: Mapping[str, Any]) -> tuple[str | None, object]:
    error = payload.get("error")
    if not isinstance(error, Mapping):
        return None, payload.get("message")
    code = error.get("code")
    code_text = str(code) if isinstance(code, str | int) and not isinstance(code, bool) else None
    return code_text, error.get("message") or error.get("displayMessage")


def _strings(value: object) -> tuple[str, ...]:
    if not isinstance(value, list):
        return ()
    return tuple(item for item in value if isinstance(item, str))
