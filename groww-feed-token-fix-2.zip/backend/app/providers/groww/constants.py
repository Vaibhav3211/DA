"""Groww Trading API protocol constants.

Sources: Groww Trading API documentation (python-sdk, feed, instruments, annexures, curl) and the
growwapi 1.5.0 SDK source (``client.py``, ``feed.py``, ``nats_client.py``, ``constants.py`` and the
feed protobuf schema), verified on ``app.providers.capabilities.VERIFIED_ON``.
"""

from __future__ import annotations

from typing import Final

from app.domain.enums import Exchange, Segment

# REST paths, relative to the API base URL (https://api.groww.in/v1).
ACCESS_TOKEN_PATH: Final = "/token/api/access"  # noqa: S105  (a URL path, not a secret)
# Without the SDK's trailing "/": Groww redirects that address here (HTTP 307, seen live in November
# 2026), and the client does not follow redirects.
SOCKET_TOKEN_PATH: Final = "/api/apex/v1/socket/token/create"  # noqa: S105  (a URL path, not a secret)
PROFILE_PATH: Final = "/user/detail"
QUOTE_PATH: Final = "/live-data/quote"
LTP_PATH: Final = "/live-data/ltp"
OHLC_PATH: Final = "/live-data/ohlc"
# Historical candles: exchange, segment, groww_symbol, start_time and end_time ("yyyy-MM-dd HH:mm:ss",
# exchange-local) and candle_interval. Cash and F&O only; ranges per request: app.providers.history.
HISTORICAL_CANDLES_PATH: Final = "/historical/candles"

API_VERSION_HEADER: Final = "x-api-version"
API_VERSION: Final = "1.0"
REQUEST_ID_HEADER: Final = "x-request-id"

# REST rate limits per API type: (requests, window seconds) pairs. The live-data and non-trading
# limits follow the documentation; the auth budget is a conservative local limit.
AUTH_RATE_WINDOWS: Final = ((5, 1.0), (30, 60.0))
LIVE_DATA_RATE_WINDOWS: Final = ((10, 1.0), (300, 60.0))
NON_TRADING_RATE_WINDOWS: Final = ((20, 1.0), (500, 60.0))
# Access-token creation is capped per account; the auth service enforces this budget.
ACCESS_TOKENS_PER_DAY: Final = 150
LTP_OHLC_BATCH_SIZE: Final = 50
# LTP/OHLC instruments are named EXCHANGE_TRADINGSYMBOL (e.g. NSE_RELIANCE). The SDK docstrings
# also show "NSE:RELIANCE"; the underscore form follows the REST documentation (verify live).
EXCHANGE_SYMBOL_SEPARATOR: Final = "_"

# Live feed (NATS over WebSocket).
MAX_SUBSCRIPTIONS_PER_CONNECTION: Final = 1000
MAX_CONNECTIONS: Final = 1
PING_INTERVAL_SECONDS: Final = 60
CONNECT_TIMEOUT_SECONDS: Final = 10
FLUSH_TIMEOUT_SECONDS: Final = 5
# Per-subscription buffers inside nats-py; a full buffer drops messages and reports SlowConsumer.
PENDING_MESSAGES_LIMIT: Final = 1000
PENDING_BYTES_LIMIT: Final = 1024 * 1024

# Assumed daily reset when an access token carries no expiry claim.
TOKEN_RESET_HOUR_IST: Final = 6

# Exchanges and segments this platform streams from Groww (instrument CSV and API vocabulary).
EXCHANGES: Final[dict[str, Exchange]] = {"NSE": Exchange.NSE, "BSE": Exchange.BSE}
SEGMENTS: Final[dict[str, Segment]] = {"CASH": Segment.CASH, "FNO": Segment.FNO}
