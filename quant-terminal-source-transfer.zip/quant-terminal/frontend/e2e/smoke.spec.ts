import { expect, test } from "@playwright/test";

// Needs the API running and the terminal user from `qt create-admin`.
test("signs in and shows the system health", async ({ page }) => {
  const username = process.env.E2E_USERNAME;
  const password = process.env.E2E_PASSWORD;
  // Fail, not skip: a skipped smoke test reads like a passing one.
  if (!username || !password) {
    throw new Error("Set E2E_USERNAME and E2E_PASSWORD (frontend/.env.local or the shell) to the `qt create-admin` user.");
  }

  await page.goto("/login?next=%2Fsystem");
  await page.getByLabel("Username", { exact: true }).fill(username);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();

  await expect(page).toHaveURL(/\/system$/);
  await expect(page.getByRole("heading", { level: 1, name: "System" })).toBeVisible();
  await expect(page.getByTestId("system-health")).toBeVisible({ timeout: 15_000 });
});
