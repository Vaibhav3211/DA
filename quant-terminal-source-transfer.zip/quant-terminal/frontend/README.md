# Quant Terminal — frontend

The Next.js terminal for the Quant Terminal API. It covers India workspaces (watchlists, live quotes, charts), provider feed health, a strategy lab and the signal feed. It shows live market data and research signals only; nothing here places orders.

This app was written on a machine where packages could not be installed, so it has never been compiled or run. Work through the [first-run checklist](#first-run-checklist) once after installing.

## Requirements

- Node.js 22.12 or later.
- The backend, running:
  - PostgreSQL, Redis and `qt-api` on port 8000;
  - for live data and signals, the market-data and strategy workers too;
  - for backtests, the backtest worker.

  `scripts\start-dev.ps1` (repository root) starts all of these, plus this app.
- The terminal user, created with `backend\.venv\Scripts\qt.exe create-admin --username admin`.

## Setup

`scripts\setup-dev.ps1` copies `.env.example` to `.env.local` and installs the packages. To do the same by hand:

```powershell
cd frontend
Copy-Item .env.example .env.local
npm install                       # writes package-lock.json: keep it (later setups run `npm ci`)
npx playwright install chromium   # only needed for the smoke test
```

## Run

```powershell
npm run dev                       # http://localhost:3000
npm run build; npm start          # production build
```

Open `http://localhost:3000`, not `127.0.0.1`. The API accepts browser requests only from `ALLOWED_ORIGINS`, which defaults to `http://localhost:3000`.

## Configuration

`.env.local` is read by `next dev`, `next build` and `npm run e2e`. The frontend holds no secrets.

| Variable | Default | Meaning |
|---|---|---|
| `BACKEND_URL` | `http://localhost:8000` | Where `/api/*` is proxied. Fixed at build time. |
| `NEXT_PUBLIC_WS_URL` | empty | WebSocket origin of the API. Empty means `ws://<page host>:8000` (`wss://` on https pages). Inlined at build time. |
| `E2E_USERNAME`, `E2E_PASSWORD` | empty | Sign-in for the smoke test. |
| `E2E_BASE_URL` | empty | Run the smoke test against an app that is already running. Empty starts `next dev`. |

These backend settings (`backend\.env`) must agree with this app:

| Setting | Local value |
|---|---|
| `ALLOWED_ORIGINS` | Includes `http://localhost:3000`. |
| `FRONTEND_BASE_URL` | `http://localhost:3000`. The Zerodha callback sends the browser back here. |
| `ZERODHA_REDIRECT_URL` | `http://localhost:3000/api/v1/providers/zerodha/callback`. Register exactly this as the Kite Connect app's redirect URL. An older `backend\.env` may still point to port 8000; change it to this value. |
| `COOKIE_SECURE` | `true` whenever the app is served over https. |

## How it talks to the API

- **REST:**
  - The browser calls `/api/v1/...` on this app's origin, and Next.js proxies the call to `BACKEND_URL`.
  - The session cookie is therefore first-party, and no CORS is needed.
  - The cookie is HttpOnly: the API sets it at sign-in, and this app never reads it.
- **Live updates:**
  - WebSockets go straight to the API (`/ws/v1/market`, `/ws/v1/signals`, `/ws/v1/system`), because the proxy does not carry them.
  - Browsers send cookies to any port of the same host, so the session cookie still reaches the API. The API must therefore be reachable on the same host name as this app.
  - A dropped connection reconnects with backoff, resubscribes and reloads the REST data.
  - A sign-out or expired session (close code 4401) returns to the sign-in page.

## Pages

| Path | Contents |
|---|---|
| `/` | Overview: market sessions, alerts, workspaces, recent signals |
| `/workspaces/<slug>` | A workspace: quote table, chart, watchlists, universe, feeds, signals, deployments, risk |
| `/signals` | Signal history with filters, and each signal's explanation |
| `/strategies` | Strategy laboratory: catalogue, deployments and their settings, runs |
| `/providers` | Provider accounts, credentials, Zerodha and Groww sign-in, feed health |
| `/system` | Health, alerts, components, workers, provider streams, global risk rules, kill switch |
| `/login` | Sign-in |

Every quote, candle and feed carries one status: LIVE, DELAYED, STALE, DISCONNECTED, RECONNECTING, SIMULATED or UNKNOWN.
- SIMULATED (simulator, fixtures, replay) is violet and hatched, so it never looks like LIVE.
- The top bar also shows SIMULATED while the API runs in simulated mode.
- The server pushes only changes, so the browser itself marks a quote that stops updating as STALE.

## Checks

```powershell
npm run check        # ESLint, TypeScript, Vitest unit tests
npm run build
npm run test:watch   # Vitest in watch mode
```

`scripts\check.ps1` (repository root) runs the frontend checks after the backend gates. Add `-Audit` to also run `npm audit --omit=dev`.

## API types

`src/lib/api/types.gen.ts` is generated from the backend's API models; never edit it by hand. After changing an API model, run `python -m app.api.contract` in `backend\` with the virtual environment active. Until you do, the backend unit test `test_the_frontend_types_are_up_to_date` fails.

## Smoke test

The Playwright smoke test signs in through the real API and opens the System page.

1. Start the backend: `scripts\start-dev.ps1` (add `-NoFrontend` to start the app yourself).
2. Put the `qt create-admin` user in `E2E_USERNAME` and `E2E_PASSWORD`, in `.env.local` or the shell. Shell values take precedence.
3. Run `npm run e2e`.
   - It starts `next dev`, unless one is already running or `E2E_BASE_URL` is set.
   - Without credentials the test fails; it does not skip.

A failed run saves a trace under `test-results/` that records what was typed, including the password. Delete it afterwards.

## First-run checklist

Confirm these once, and report any failure with its output; they are the unverified parts of milestones M6, M8 and M9.

1. `npm install` succeeds. Exact pins: `next` 16.4.3, `react`/`react-dom` 19.3.1, `@tanstack/react-query` 5.105.0, `lightweight-charts` 5.2.1.
2. `npm run check` and `npm run build` pass. The likeliest compile errors:
   - `lucide-react` icon names;
   - Radix component props;
   - the `lightweight-charts` v5 series API;
   - the typing of `vi.fn<typeof fetch>()`.
3. The formatting tests pass: Indian digit grouping and IST times. They need Node's full ICU, which official Node builds include.
4. Sign-in works through the proxy:
   - the session cookie is set;
   - saving a change works, because the proxy passes on the browser's `Origin`;
   - a 401 leads to `/login`.
5. In development with `SIMULATOR_ENABLED=true`, quotes and charts update and show SIMULATED, never LIVE.
6. The three dots in the top bar show "Streaming". After you restart `qt-api`, they recover on their own.
7. After the Kite login, the browser lands on `/providers?zerodha=connected`. This confirms the API's 303 redirect passes through the proxy.
8. `npm run e2e` passes.
9. The M8 strategy workflow, on the Simulation Lab workspace with the example strategy (see [live monitoring](../docs/operations/live-monitoring.md)):
   - selecting an instrument shows the **Strategy** panel beside its chart, with the strategy's compatibility verdict;
   - **New configuration…** ticks only that instrument under **Chosen instruments**; **The whole workspace** needs its extra tick; saving leaves live signals off;
   - the configuration's **Backtest** summary shows **Not backtested**;
   - **Enable live signals…** asks first, the badge reaches **Running** (through **Starting** and possibly **Warming up**), enabling again changes nothing, and **Stop live signals** shows **Stopped**;
   - **Apply to chart** adds a numbered row under the chart, and once signals exist they appear as markers; clicking one opens the signal with its **Configuration** section;
   - the overview's **Market availability** card shows crypto, spot Forex and spot metals as unavailable, with reasons.
10. The M9 backtest workflow, with the same configuration, `qt-backtest-worker` running and the simulator having run for an hour or more (see [backtesting](../docs/backtesting.md)):
    - **Run backtest…** → **Get candles…** lists Zerodha and Groww history as unavailable, with reasons, and **Simulated** as available;
    - requesting today's simulated candles reaches READY, with its coverage, gaps for the hours the simulator was off, and a SIMULATED notice;
    - without trade rules, **Run backtest** stays disabled and the dialog says why; **Trade rules…** → **Save rules** enables it;
    - the run passes through Queued and Running to Succeeded; **View results** shows the summary, equity curve, trades and notes, labelled SIMULATED, and the summary shows **Current**;
    - changing a trade rule turns the summary **Outdated**, and **All runs…** keeps the earlier run;
    - after a new run, with the configuration applied to a 1m chart, its trades appear as muted circles, unlike live signal markers; **Backtest trades** hides them, and clicking one opens its trade.

## Troubleshooting

- **403 `origin_not_allowed`, or live updates never connect (the browser reports close code 1006):**
  - The page's origin is not in `ALLOWED_ORIGINS`.
  - Open `http://localhost:3000`, or add your origin to `ALLOWED_ORIGINS` and restart the API.
- **"Live updates degraded" while pages load:**
  - Either the browser cannot reach the API on port 8000, or the page and the API use different host names, so the cookie is not sent.
  - Set `NEXT_PUBLIC_WS_URL`.
- **A changed `BACKEND_URL` or `NEXT_PUBLIC_WS_URL` has no effect:**
  - Restart `next dev`. For `npm start`, rebuild first.
- **"Too many failed sign-in attempts from this address":**
  - Behind the proxy, every sign-in comes from the Next.js server's address.
  - 5 failures in 15 minutes therefore block sign-in through this app for 15 minutes.
  - `qt reset-password` unlocks a locked user, but not the address.
- **The Zerodha login ends on `/providers?zerodha=error&code=…`:**
  - The code says why. For example, `unauthenticated` means you are not signed in to this app in that browser.
- **Using `qt zerodha login` instead of the Providers page:**
  - After the Kite login, the callback does not redirect. It shows a page titled "Finish the login at the command line" with the address to paste at the command's prompt.
  - You do not need to be signed in to this app in that browser.
