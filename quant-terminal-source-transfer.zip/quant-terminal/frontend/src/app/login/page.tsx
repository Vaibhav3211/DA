"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ChartCandlestick } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { LoadingState, Spinner } from "@/components/ui/feedback";
import { Field, Input } from "@/components/ui/input";
import { auth } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import { errorMessage, safeNext } from "@/lib/utils";

function LoginForm() {
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"));
  const queryClient = useQueryClient();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const login = useMutation({
    mutationFn: auth.login,
    onSuccess: (session) => {
      queryClient.setQueryData(queryKeys.me, session);
      router.replace(next);
    },
  });

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    login.mutate({ username: username.trim(), password });
  };

  return (
    <form onSubmit={submit} className="flex w-full max-w-sm flex-col gap-4 rounded-lg border bg-card p-6" noValidate>
      <div className="flex items-center gap-2">
        <ChartCandlestick className="size-6 text-primary" aria-hidden />
        <h1 className="text-lg font-semibold">Quant Terminal</h1>
      </div>
      <p className="text-sm text-muted-foreground">Sign in to your terminal.</p>
      <Field label="Username" htmlFor="username">
        <Input
          id="username"
          autoComplete="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          required
          autoFocus
        />
      </Field>
      <Field label="Password" htmlFor="password">
        <Input
          id="password"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          required
        />
      </Field>
      {login.isError ? (
        <p role="alert" className="rounded-md border border-red-500/40 bg-red-500/10 p-2 text-sm text-red-300">
          {errorMessage(login.error)}
        </p>
      ) : null}
      <Button type="submit" disabled={login.isPending || !username.trim() || !password}>
        {login.isPending ? <Spinner /> : null}
        Sign in
      </Button>
    </form>
  );
}

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center p-4">
      <Suspense fallback={<LoadingState />}>
        <LoginForm />
      </Suspense>
    </main>
  );
}
