"use client";

import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { X } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useId, useMemo, useState, type ReactNode } from "react";
import { SignalDetailDialog } from "@/components/signals/signal-detail";
import { SignalTable } from "@/components/signals/signal-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { Input, NativeSelect } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { signals as signalsApi, strategies as strategiesApi, workspaces as workspacesApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import { humanize } from "@/lib/format";
import { SIGNAL_STATUSES, SIGNAL_TYPES, signalSearch, withParam } from "@/lib/signal-filters";
import { cn } from "@/lib/utils";

function Filter({ label, children }: { label: string; children: (id: string) => ReactNode }) {
  const id = useId();
  return (
    <div className="flex flex-col gap-1">
      <label htmlFor={id} className="text-xs text-muted-foreground">
        {label}
      </label>
      {children(id)}
    </div>
  );
}

/** An option for a value the URL names but the list lacks, so the select still shows it. */
function MissingOption({ value, known }: { value: string | null; known: readonly string[] }) {
  if (!value || known.includes(value)) return null;
  return <option value={value}>{value}</option>;
}

function SignalHistory() {
  const params = useSearchParams();
  const router = useRouter();
  const search = params.toString();
  const { filters, problem } = useMemo(() => signalSearch(new URLSearchParams(search)), [search]);
  const [selected, setSelected] = useState<string | null>(null);
  // Cursors of the pages after the first; they belong to one set of filters.
  const [paging, setPaging] = useState<{ search: string; cursors: string[] }>({ search, cursors: [] });
  const cursors = paging.search === search ? paging.cursors : [];
  const cursor = cursors.at(-1) ?? null;

  const workspaces = useQuery({ queryKey: queryKeys.workspaces, queryFn: workspacesApi.list });
  const strategies = useQuery({ queryKey: queryKeys.strategies, queryFn: strategiesApi.list });
  const page = useQuery({
    queryKey: [...queryKeys.signalList(filters), cursor],
    queryFn: () => signalsApi.list(filters, cursor),
    placeholderData: keepPreviousData,
    enabled: problem === null,
  });

  const navigate = (query: string) => router.replace(query ? `/signals?${query}` : "/signals", { scroll: false });
  const set = (name: string, value: string | null) => navigate(withParam(search, name, value));
  const value = (name: string) => params.get(name) ?? "";
  const workspaceSlugs = (workspaces.data ?? []).map((workspace) => workspace.slug);
  const strategyIds = (strategies.data ?? []).map((strategy) => strategy.strategy_id);
  const nextCursor = page.data?.next_cursor ?? null;
  const settled = !page.isPlaceholderData;

  return (
    <div className="flex flex-col gap-4">
      <Card aria-label="Signal filters">
        <CardContent className="flex flex-wrap items-end gap-3">
          <Filter label="Workspace">
            {(id) => (
              <NativeSelect id={id} className="h-8 w-44 text-xs" value={filters.workspace ?? ""} onChange={(event) => set("workspace", event.target.value)}>
                <option value="">All workspaces</option>
                {(workspaces.data ?? []).map((workspace) => (
                  <option key={workspace.slug} value={workspace.slug}>
                    {workspace.name}
                  </option>
                ))}
                <MissingOption value={filters.workspace ?? null} known={workspaceSlugs} />
              </NativeSelect>
            )}
          </Filter>
          <Filter label="Strategy">
            {(id) => (
              <NativeSelect id={id} className="h-8 w-44 text-xs" value={filters.strategy_id ?? ""} onChange={(event) => set("strategy_id", event.target.value)}>
                <option value="">All strategies</option>
                {(strategies.data ?? []).map((strategy) => (
                  <option key={strategy.strategy_id} value={strategy.strategy_id}>
                    {strategy.name}
                  </option>
                ))}
                <MissingOption value={filters.strategy_id ?? null} known={strategyIds} />
              </NativeSelect>
            )}
          </Filter>
          <Filter label="Type">
            {(id) => (
              <NativeSelect id={id} className="h-8 w-32 text-xs" value={filters.signal_type ?? ""} onChange={(event) => set("type", event.target.value)}>
                <option value="">Any type</option>
                {SIGNAL_TYPES.map((type) => (
                  <option key={type} value={type}>
                    {humanize(type)}
                  </option>
                ))}
              </NativeSelect>
            )}
          </Filter>
          <Filter label="Status">
            {(id) => (
              <NativeSelect id={id} className="h-8 w-36 text-xs" value={filters.status ?? ""} onChange={(event) => set("status", event.target.value)}>
                <option value="">Any status</option>
                {SIGNAL_STATUSES.map((status) => (
                  <option key={status} value={status}>
                    {humanize(status)}
                  </option>
                ))}
              </NativeSelect>
            )}
          </Filter>
          <Filter label="Actionable">
            {(id) => (
              <NativeSelect
                id={id}
                className="h-8 w-36 text-xs"
                value={filters.actionable === undefined ? "" : String(filters.actionable)}
                onChange={(event) => set("actionable", event.target.value)}
              >
                <option value="">Any</option>
                <option value="true">Actionable</option>
                <option value="false">Informational</option>
              </NativeSelect>
            )}
          </Filter>
          <Filter label="From">
            {(id) => (
              <Input id={id} type="date" className="h-8 w-36 text-xs" value={value("from")} onChange={(event) => set("from", event.target.value)} />
            )}
          </Filter>
          <Filter label="To">
            {(id) => (
              <Input id={id} type="date" className="h-8 w-36 text-xs" value={value("to")} onChange={(event) => set("to", event.target.value)} />
            )}
          </Filter>
          <Filter label="Open only">
            {(id) => (
              <span className="flex h-8 items-center">
                <Switch id={id} checked={filters.open_only === true} onCheckedChange={(on) => set("open", on ? "1" : null)} />
              </span>
            )}
          </Filter>
          {filters.instrument ? (
            <Button size="sm" variant="secondary" onClick={() => set("instrument", null)} title="Show every instrument">
              {`Instrument ${filters.instrument}`}
              <X aria-hidden />
              <span className="sr-only">Remove the instrument filter</span>
            </Button>
          ) : null}
          <Button size="sm" variant="ghost" className="ml-auto" disabled={search === ""} onClick={() => navigate("")}>
            Clear filters
          </Button>
        </CardContent>
      </Card>

      <Card aria-label="Signal history">
        <CardHeader
          title="History"
          description="Newest first. Times are when the strategy generated the signal."
          actions={
            <span className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">{`Page ${cursors.length + 1}`}</span>
              <Button size="sm" variant="outline" disabled={cursors.length === 0} onClick={() => setPaging({ search, cursors: [] })}>
                Newest
              </Button>
              <Button size="sm" variant="outline" disabled={cursors.length === 0} onClick={() => setPaging({ search, cursors: cursors.slice(0, -1) })}>
                Newer
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={!settled || nextCursor === null}
                onClick={() => {
                  if (nextCursor !== null) setPaging({ search, cursors: [...cursors, nextCursor] });
                }}
              >
                Older
              </Button>
            </span>
          }
        />
        <CardContent>
          {problem !== null ? (
            <EmptyState title="Check the dates">{problem}</EmptyState>
          ) : page.isPending ? (
            <LoadingState label="Loading signals…" />
          ) : page.isError ? (
            <ErrorState error={page.error} onRetry={() => void page.refetch()} />
          ) : (
            <div className={cn(!settled && "opacity-60")}>
              <SignalTable
                items={page.data.items}
                onSelect={setSelected}
                selectedId={selected}
                showWorkspace={!filters.workspace}
                empty={
                  <EmptyState title={search === "" ? "No signals yet" : "No signals match these filters"}>
                    {search === ""
                      ? "Signals appear when an enabled strategy emits one."
                      : "Widen the filters or clear them."}
                  </EmptyState>
                }
              />
            </div>
          )}
        </CardContent>
      </Card>
      <SignalDetailDialog signalId={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

export default function SignalsPage() {
  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-lg font-semibold">Signals</h1>
        <p className="text-sm text-muted-foreground">
          Research output for review, not orders.
        </p>
      </div>
      <Suspense fallback={<LoadingState label="Loading signals…" />}>
        <SignalHistory />
      </Suspense>
    </div>
  );
}
