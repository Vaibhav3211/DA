"use client";

import { useQuery } from "@tanstack/react-query";
import type { ReactNode } from "react";
import { Banners } from "@/components/shell/banners";
import { SideNav } from "@/components/shell/side-nav";
import { TopBar } from "@/components/shell/top-bar";
import { ErrorState, LoadingState } from "@/components/ui/feedback";
import { isUnauthorized } from "@/lib/api/client";
import { auth } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import { LiveProvider } from "@/lib/live/provider";

export default function TerminalLayout({ children }: { children: ReactNode }) {
  // A 401 here is sent to /login by the query cache; see app/providers.tsx.
  const me = useQuery({ queryKey: queryKeys.me, queryFn: auth.me, staleTime: 5 * 60_000 });

  if (me.isPending) {
    return (
      <main className="flex min-h-screen items-center justify-center">
        <LoadingState label="Checking your session…" />
      </main>
    );
  }
  if (me.isError) {
    return (
      <main className="flex min-h-screen items-center justify-center p-4">
        {isUnauthorized(me.error) ? (
          <LoadingState label="Redirecting to sign in…" />
        ) : (
          <ErrorState error={me.error} title="The API is not reachable" onRetry={() => void me.refetch()} />
        )}
      </main>
    );
  }
  return (
    <LiveProvider>
      <div className="flex h-screen overflow-hidden">
        <SideNav />
        <div className="flex min-w-0 flex-1 flex-col">
          <TopBar username={me.data.username} />
          <Banners />
          <main id="content" className="min-h-0 flex-1 overflow-y-auto p-4">
            {children}
          </main>
        </div>
      </div>
    </LiveProvider>
  );
}
