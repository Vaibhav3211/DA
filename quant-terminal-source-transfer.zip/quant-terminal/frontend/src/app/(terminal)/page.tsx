"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { useState } from "react";
import { MarketAvailabilityCard, MarketSessions, WorkspaceGrid } from "@/components/market/market-overview";
import { useSystemHealth } from "@/components/shell/top-bar";
import { SignalDetailDialog } from "@/components/signals/signal-detail";
import { SignalTable } from "@/components/signals/signal-table";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { signals as signalsApi, type SignalFilters } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";

const RECENT: SignalFilters = { limit: 10 };
const ALERT_VARIANT = { critical: "destructive", warning: "warning", info: "info" } as const;

function Alerts() {
  const health = useSystemHealth();
  const alerts = health.data?.alerts ?? [];
  return (
    <Card>
      <CardHeader title="Alerts" description="Conditions the system reports now." actions={<Link className="text-xs underline" href="/system">System</Link>} />
      <CardContent>
        {health.isPending ? (
          <LoadingState />
        ) : health.isError ? (
          <ErrorState error={health.error} onRetry={() => void health.refetch()} />
        ) : alerts.length === 0 ? (
          <EmptyState title="No alerts" />
        ) : (
          <ul className="flex flex-col gap-2">
            {alerts.map((alert) => (
              <li key={`${alert.code}:${alert.subject ?? ""}`} className="flex items-start gap-2 text-sm">
                <Badge variant={ALERT_VARIANT[alert.severity]}>{alert.severity}</Badge>
                <span className="min-w-0">
                  {alert.message}
                  {alert.subject ? <span className="ml-1 text-xs text-muted-foreground">({alert.subject})</span> : null}
                </span>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function RecentSignals() {
  const [selected, setSelected] = useState<string | null>(null);
  const recent = useQuery({ queryKey: queryKeys.signalList(RECENT), queryFn: () => signalsApi.list(RECENT) });
  return (
    <Card>
      <CardHeader
        title="Recent signals"
        description="Every workspace. Signals are research output, not orders."
        actions={
          <Link className="text-xs underline" href="/signals">
            All signals
          </Link>
        }
      />
      {recent.isPending ? (
        <LoadingState />
      ) : recent.isError ? (
        <CardContent>
          <ErrorState error={recent.error} onRetry={() => void recent.refetch()} />
        </CardContent>
      ) : (
        <SignalTable items={recent.data.items} onSelect={setSelected} selectedId={selected} showWorkspace />
      )}
      <SignalDetailDialog signalId={selected} onClose={() => setSelected(null)} />
    </Card>
  );
}

export default function OverviewPage() {
  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-lg font-semibold">Overview</h1>
      <div className="grid gap-4 xl:grid-cols-2">
        <MarketSessions />
        <Alerts />
      </div>
      <WorkspaceGrid />
      <MarketAvailabilityCard />
      <RecentSignals />
    </div>
  );
}
