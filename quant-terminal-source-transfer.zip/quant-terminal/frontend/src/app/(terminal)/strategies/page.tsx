"use client";

import { useQuery } from "@tanstack/react-query";
import { RefreshCw, Upload } from "lucide-react";
import Link from "next/link";
import { useId, useState } from "react";
import { RunsTable } from "@/components/strategies/runs-table";
import { StrategyDeployments } from "@/components/strategies/strategy-deployments";
import { ConfigSchemaTable, StrategyRequirementsList } from "@/components/strategies/strategy-detail";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { Input } from "@/components/ui/input";
import { strategies as strategiesApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type { StrategyView } from "@/lib/api/types.gen";
import { notify } from "@/lib/notifications";
import { syncSummary } from "@/lib/strategies";
import { cn } from "@/lib/utils";

const RUN_LIMIT = 25;
const RUN_POLL_MS = 15_000;

function StrategyBadges({ strategy }: { strategy: StrategyView }) {
  return (
    <>
      {strategy.is_available ? null : (
        <Badge
          variant="destructive"
          title="The catalogue lists it but the code no longer has it, so its saved configurations cannot run"
        >
          Not in code
        </Badge>
      )}
      {strategy.is_example ? (
        <Badge variant="info" title="Ships with the platform as an example">
          Example
        </Badge>
      ) : null}
      {strategy.can_emit_actionable ? (
        <Badge variant="warning" title="May emit actionable signals; each one passes the risk gate first">
          Actionable
        </Badge>
      ) : (
        <Badge variant="secondary" title="Emits informational signals only">
          Informational
        </Badge>
      )}
    </>
  );
}

function CatalogueList({
  items,
  selectedId,
  onSelect,
}: {
  items: readonly StrategyView[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  return (
    <Card aria-label="Strategy catalogue" className="self-start">
      <CardHeader title="Catalogue" description={`${items.length} ${items.length === 1 ? "strategy" : "strategies"}`} />
      <CardContent className="p-2">
        <ul className="flex flex-col gap-1">
          {items.map((strategy) => {
            const selected = strategy.strategy_id === selectedId;
            return (
              <li key={strategy.strategy_id}>
                <button
                  type="button"
                  aria-pressed={selected}
                  onClick={() => onSelect(strategy.strategy_id)}
                  className={cn(
                    "flex w-full flex-col gap-1 rounded-md border px-3 py-2 text-left transition-colors hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring/60 focus-visible:outline-none",
                    selected ? "border-primary/60 bg-accent" : "border-transparent",
                    strategy.is_available ? "" : "opacity-60",
                  )}
                >
                  <span className="flex items-center gap-2">
                    <span className="truncate text-sm font-medium">{strategy.name}</span>
                    <span className="ml-auto font-mono text-xs text-muted-foreground">{`v${strategy.version}`}</span>
                  </span>
                  <span className="truncate font-mono text-xs text-muted-foreground">{strategy.strategy_id}</span>
                  <span className="flex flex-wrap items-center gap-1">
                    <StrategyBadges strategy={strategy} />
                    <span
                      className="ml-auto text-xs text-muted-foreground"
                      title="Saved configurations with live signals on, of all its saved configurations"
                    >
                      {`${strategy.enabled_deployments} of ${strategy.deployments} live`}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </CardContent>
    </Card>
  );
}

function StrategyPanel({ strategy }: { strategy: StrategyView }) {
  const runParams = { strategy_id: strategy.strategy_id, limit: RUN_LIMIT };
  const runs = useQuery({
    queryKey: queryKeys.runs(runParams),
    queryFn: () => strategiesApi.runs(runParams),
    refetchInterval: RUN_POLL_MS,
  });
  return (
    <div className="flex min-w-0 flex-col gap-4">
      <Card aria-label={`Strategy ${strategy.name}`}>
        <CardHeader
          title={strategy.name}
          description={`${strategy.strategy_id} · v${strategy.version} · by ${strategy.author}`}
          actions={
            <Link
              className="text-xs underline"
              href={`/signals?strategy_id=${encodeURIComponent(strategy.strategy_id)}`}
            >
              Signal history
            </Link>
          }
        />
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center gap-1">
            <StrategyBadges strategy={strategy} />
            <span
              className="ml-auto font-mono text-xs text-muted-foreground"
              title={`Code fingerprint ${strategy.code_fingerprint}`}
            >
              {`Code ${strategy.code_fingerprint.slice(0, 12)}`}
            </span>
          </div>
          <p className="text-sm">{strategy.description}</p>
          {strategy.is_available ? null : (
            <p role="note" className="rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-200">
              This strategy is no longer in the code. Its saved configurations cannot run or be edited until it returns
              and the catalogue is synced.
            </p>
          )}
          <section className="flex flex-col gap-2">
            <h3 className="text-sm font-medium">Input requirements</h3>
            <StrategyRequirementsList metadata={strategy.metadata} />
          </section>
          <section className="flex flex-col gap-2">
            <h3 className="text-sm font-medium">Settings</h3>
            <ConfigSchemaTable strategy={strategy} />
          </section>
        </CardContent>
      </Card>
      <Card aria-label="Saved configurations">
        <CardHeader
          title="Saved configurations"
          description="Each has its own name, settings and instruments; a workspace can hold several. Live signals are turned on per configuration."
        />
        <CardContent>
          <StrategyDeployments strategy={strategy} />
        </CardContent>
      </Card>
      <Card aria-label="Runs">
        <CardHeader
          title="Runs"
          description={`Runtime health and errors from the strategy worker; the latest ${RUN_LIMIT} runs.`}
        />
        <CardContent>
          {runs.isPending ? (
            <LoadingState />
          ) : runs.isError ? (
            <ErrorState error={runs.error} onRetry={() => void runs.refetch()} />
          ) : (
            <RunsTable runs={runs.data} />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function PluginUploadCard() {
  const inputId = useId();
  return (
    <Card aria-label="Strategy plugin upload">
      <CardHeader
        title="Upload a strategy plugin"
        description="Disabled until uploaded code can run in isolation. Register your strategies in backend/app/strategies/custom and sync the catalogue instead (see docs/strategy-registration.md)."
      />
      <CardContent className="flex flex-wrap items-center gap-2">
        <label htmlFor={inputId} className="sr-only">
          Strategy plugin file
        </label>
        <Input id={inputId} type="file" accept=".py,.zip" disabled className="max-w-sm" />
        <Button size="sm" disabled>
          <Upload aria-hidden />
          Upload
        </Button>
      </CardContent>
    </Card>
  );
}

export default function StrategiesPage() {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const catalogue = useQuery({ queryKey: queryKeys.strategies, queryFn: strategiesApi.list });
  const sync = useApiMutation({
    mutationFn: () => strategiesApi.sync(),
    invalidate: [queryKeys.strategies, ["deployments"]],
    success: null,
    errorTitle: "Could not sync the catalogue",
    onSuccess: (result) => notify("success", "Catalogue synced", syncSummary(result)),
  });

  const items = [...(catalogue.data ?? [])].sort(
    (a, b) => Number(b.is_available) - Number(a.is_available) || a.name.localeCompare(b.name),
  );
  const current = items.find((strategy) => strategy.strategy_id === selectedId) ?? items[0] ?? null;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h1 className="text-lg font-semibold">Strategy laboratory</h1>
          <p className="text-sm text-muted-foreground">
            Strategies turn market data into research signals for review. Nothing here places orders.
          </p>
        </div>
        <Button
          size="sm"
          variant="outline"
          disabled={sync.isPending}
          title="Record new, upgraded and removed strategies from the backend code"
          onClick={() => sync.mutate()}
        >
          <RefreshCw aria-hidden className={cn(sync.isPending && "animate-spin")} />
          Sync catalogue
        </Button>
      </div>
      {catalogue.isPending ? (
        <LoadingState label="Loading strategies…" />
      ) : catalogue.isError ? (
        <ErrorState error={catalogue.error} onRetry={() => void catalogue.refetch()} />
      ) : current === null ? (
        <EmptyState title="No strategies">
          Register a strategy in backend/app/strategies/custom (see docs/strategy-registration.md), then sync the
          catalogue.
        </EmptyState>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[minmax(0,18rem)_minmax(0,1fr)]">
          <CatalogueList items={items} selectedId={current.strategy_id} onSelect={setSelectedId} />
          <StrategyPanel key={current.strategy_id} strategy={current} />
        </div>
      )}
      <PluginUploadCard />
    </div>
  );
}
