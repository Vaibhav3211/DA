"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { AccountCard } from "@/components/providers/account-card";
import { CreateAccountDialog } from "@/components/providers/account-dialogs";
import { CapabilitiesPanel } from "@/components/providers/capabilities";
import { InstrumentRefreshDialog } from "@/components/providers/instrument-refresh";
import { FeedPanel, useFeedStreams } from "@/components/providers/stream-table";
import { StatusBadge } from "@/components/status/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import type { DataStatus, Provider, ProviderAccountView, ProviderSummary, StreamHealth } from "@/lib/api/types.gen";
import { humanize } from "@/lib/format";
import { useLiveStore, useSocketStatus } from "@/lib/live/store";
import { ACCOUNT_PROVIDERS, zerodhaReturn } from "@/lib/providers";
import { effectiveStatus } from "@/lib/status";
import { cn } from "@/lib/utils";

/** The outcome of a Kite login, which the API's callback passes back in the query string. */
function ZerodhaReturnBanner({ accounts }: { accounts: readonly ProviderAccountView[] | undefined }) {
  const params = useSearchParams();
  const router = useRouter();
  const result = zerodhaReturn(params);
  if (result === null) return null;
  const accountId = result.ok ? result.accountId : null;
  const account = accountId === null ? undefined : accounts?.find((item) => item.id === accountId);
  const message = result.ok
    ? `Kite sign-in finished${account ? ` for ${account.label}` : ""}.${
        account && !account.is_enabled ? " Turn on Stream to start its feed." : ""
      }`
    : result.message;
  return (
    <div
      role={result.ok ? "status" : "alert"}
      className={cn(
        "flex flex-wrap items-center gap-3 rounded-md border px-3 py-2 text-sm",
        result.ok ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-200" : "border-red-500/30 bg-red-500/10 text-red-200",
      )}
    >
      <p className="min-w-0 flex-1">
        {message}
        {result.ok ? null : <span className="ml-1 font-mono text-xs opacity-70">{`(${result.code})`}</span>}
      </p>
      <Button size="sm" variant="ghost" onClick={() => router.replace("/providers", { scroll: false })}>
        Dismiss
      </Button>
    </div>
  );
}

function ProviderSection({
  summary,
  status,
  streams,
}: {
  summary: ProviderSummary;
  status: DataStatus;
  streams: readonly StreamHealth[];
}) {
  const enabled = summary.accounts.find((account) => account.is_enabled) ?? null;
  const description =
    summary.accounts.length === 0
      ? "No accounts yet."
      : enabled
        ? `Streams with ${enabled.label}. One account per provider streams at a time.`
        : "No account is enabled, so nothing streams.";
  return (
    <Card aria-label={summary.display_name}>
      <CardHeader
        title={
          <span className="flex items-center gap-2">
            {summary.display_name}
            <StatusBadge status={status} />
          </span>
        }
        description={description}
        actions={
          <InstrumentRefreshDialog
            provider={summary.provider}
            displayName={summary.display_name}
            accounts={summary.accounts}
          />
        }
      />
      <CardContent className="flex flex-col gap-3">
        {summary.accounts.length === 0 ? (
          <EmptyState title={`No ${summary.display_name} accounts`}>Use Add account to connect one.</EmptyState>
        ) : (
          summary.accounts.map((account) => (
            <AccountCard
              key={account.id}
              account={account}
              streams={streams.filter((stream) => stream.account_id === account.id)}
              otherEnabled={enabled !== null && enabled.id !== account.id ? enabled.label : null}
              tokenExpiry={summary.capabilities.token_expiry}
            />
          ))
        )}
        <CapabilitiesPanel summary={summary} account={enabled} />
      </CardContent>
    </Card>
  );
}

export default function ProvidersPage() {
  const feed = useFeedStreams();
  const live = useLiveStore((state) => state.feed);
  const market = useSocketStatus("market");
  const summaries = feed.list.data;
  const names = new Map((summaries ?? []).map((summary) => [summary.provider, summary.display_name] as const));
  const displayName = (provider: Provider) => names.get(provider) ?? humanize(provider);
  // The simulator is listed only when it is in use: accounts for it can't be added here.
  const shown = summaries?.filter(
    (summary) => summary.provider !== "SIMULATOR" || summary.accounts.length > 0 || summary.feeds.length > 0,
  );
  const streams = feed.streams ?? [];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h1 className="text-lg font-semibold">Providers</h1>
          <p className="text-xs text-muted-foreground">
            Accounts, sign-in and feeds. Secrets and access tokens are never shown; API keys appear masked.
          </p>
        </div>
        <CreateAccountDialog providers={ACCOUNT_PROVIDERS} displayName={displayName} />
      </div>
      <Suspense fallback={null}>
        <ZerodhaReturnBanner accounts={summaries?.flatMap((summary) => summary.accounts)} />
      </Suspense>
      {shown ? (
        shown.length === 0 ? (
          <EmptyState title="No providers">The API lists no market data providers.</EmptyState>
        ) : (
          shown.map((summary) => (
            <ProviderSection
              key={summary.provider}
              summary={summary}
              status={effectiveStatus(live?.providers[summary.provider] ?? summary.data_status, market)}
              streams={streams.filter((stream) => stream.provider === summary.provider)}
            />
          ))
        )
      ) : feed.list.isError ? (
        <ErrorState error={feed.list.error} onRetry={() => void feed.list.refetch()} />
      ) : (
        <LoadingState />
      )}
      <FeedPanel />
    </div>
  );
}
