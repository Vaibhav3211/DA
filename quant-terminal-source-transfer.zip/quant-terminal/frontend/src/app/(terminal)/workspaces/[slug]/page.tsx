"use client";

import { useQuery } from "@tanstack/react-query";
import { TriangleAlert } from "lucide-react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useId, useState } from "react";
import { ChartPanel } from "@/components/market/chart-panel";
import { InstrumentPanel } from "@/components/market/instrument-panel";
import { REGION_LABEL, SessionStateBadge, useMarketOverview } from "@/components/market/market-overview";
import { QuoteTable, useWorkspaceQuotes, type QuotesByInstrument } from "@/components/market/quote-table";
import { FeedPanel } from "@/components/providers/stream-table";
import { useRiskRules, workspacePause } from "@/components/risk/risk-rules";
import { WorkspaceSignals } from "@/components/signals/signal-feed";
import { StrategyPanel } from "@/components/strategies/strategy-panel";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { NativeSelect } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DeploymentsPanel } from "@/components/workspace/deployments-panel";
import { RiskPanel } from "@/components/workspace/risk-panel";
import { UniversePanel } from "@/components/workspace/universe-panel";
import { useWatchlists, WatchlistsPanel } from "@/components/workspace/watchlists-panel";
import { ApiError } from "@/lib/api/client";
import { workspaces as workspacesApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type {
  CandleInterval,
  MarketSession,
  Provider,
  UniverseEntry,
  WorkspaceView,
} from "@/lib/api/types.gen";
import { formatInteger, humanize } from "@/lib/format";
import { useNow } from "@/lib/hooks";
import { useLiveSockets, useLiveSubscription } from "@/lib/live/provider";
import { useSocketStatus, useStaleAfterSeconds } from "@/lib/live/store";
import { countStatuses, isDegraded, quoteStatus } from "@/lib/status";
import { toggleApplied } from "@/lib/strategies";

const OPEN_STATES = new Set(["OPEN", "PRE_OPEN"]);
const NOTHING_APPLIED: readonly string[] = [];

function decodeSlug(raw: string): string {
  try {
    return decodeURIComponent(raw);
  } catch {
    return raw;
  }
}

function EnabledSwitch({ workspace }: { workspace: WorkspaceView }) {
  const switchId = useId();
  const sockets = useLiveSockets();
  const toggle = useApiMutation({
    mutationFn: (enabled: boolean) =>
      enabled ? workspacesApi.enable(workspace.slug) : workspacesApi.disable(workspace.slug),
    invalidate: [queryKeys.workspaces, ["deployments"], ["strategy-runs"], ["quotes"]],
    success: (result, enabled) => (result.changed ? `${workspace.name} ${enabled ? "enabled" : "disabled"}` : null),
    errorTitle: "Could not switch the workspace",
    onSuccess: () => sockets.market.resubscribe("quotes"),
  });
  return (
    <span className="flex items-center gap-2 text-sm">
      <Switch
        id={switchId}
        checked={workspace.is_enabled}
        disabled={toggle.isPending}
        onCheckedChange={(enabled) => toggle.mutate(enabled)}
      />
      <label htmlFor={switchId}>{workspace.is_enabled ? "Enabled" : "Disabled"}</label>
    </span>
  );
}

/** Warns when streamed quotes are not live, unless the markets are closed and quiet data is expected. */
function DataWarning({
  entries,
  quotes,
  marketsOpen,
}: {
  entries: readonly UniverseEntry[];
  quotes: QuotesByInstrument;
  marketsOpen: boolean | null;
}) {
  const now = useNow(5000);
  const socket = useSocketStatus("market");
  const staleAfter = useStaleAfterSeconds();
  const statuses = entries
    .filter((entry) => entry.status === "PLANNED")
    .map((entry) => quoteStatus(quotes[entry.instrument.id], now, staleAfter, socket));
  const degraded = statuses.filter(isDegraded);
  if (degraded.length === 0) return null;
  const summary = countStatuses(degraded)
    .map(([status, count]) => `${count} ${humanize(status).toLowerCase()}`)
    .join(", ");
  if (marketsOpen === false) {
    return <p className="text-xs text-muted-foreground">Markets are closed, so quiet quotes are expected ({summary}).</p>;
  }
  return (
    <div className="flex items-start gap-2 rounded-md border border-amber-500/40 bg-amber-500/10 p-3 text-sm">
      <TriangleAlert aria-hidden className="mt-0.5 size-4 shrink-0 text-amber-300" />
      <span>
        {degraded.length} of {statuses.length} streamed instruments are not live ({summary}). The data quality rule
        blocks signals on stale or disconnected data.
      </span>
    </div>
  );
}

function Header({
  workspace,
  sessions,
  paused,
}: {
  workspace: WorkspaceView;
  sessions: readonly MarketSession[];
  paused: { paused: boolean; reason: string | null };
}) {
  return (
    <div className="flex flex-wrap items-start gap-3">
      <div className="min-w-0">
        <h1 className="text-lg font-semibold">{workspace.name}</h1>
        <p className="text-xs text-muted-foreground">
          {humanize(workspace.kind)} · {REGION_LABEL[workspace.market_region]} ·{" "}
          {formatInteger(workspace.instrument_count)} instruments
        </p>
        {workspace.description ? <p className="mt-1 text-sm text-muted-foreground">{workspace.description}</p> : null}
      </div>
      <div className="ml-auto flex flex-wrap items-center gap-3">
        {sessions.map((session) => (
          <span key={session.exchange} className="flex items-center gap-1.5 text-xs">
            <span className="text-muted-foreground">{session.exchange}</span>
            <SessionStateBadge state={session.state} />
          </span>
        ))}
        {paused.paused ? (
          <Badge variant="warning" title={paused.reason ?? "No reason given"}>
            Signals paused
          </Badge>
        ) : null}
        <EnabledSwitch workspace={workspace} />
      </div>
    </div>
  );
}

function Workspace({ workspace, entries }: { workspace: WorkspaceView; entries: UniverseEntry[] }) {
  const slug = workspace.slug;
  const filterId = useId();
  useLiveSubscription("market", { channel: "quotes", workspace_id: slug });
  const quotes = useWorkspaceQuotes(slug, entries);
  const watchlists = useWatchlists(slug);
  const rules = useRiskRules(slug);
  const overview = useMarketOverview();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [watchlistId, setWatchlistId] = useState("");
  const [chartInterval, setChartInterval] = useState<CandleInterval>("1m");
  // The saved configurations applied to each instrument's chart, kept while the page is open.
  const [applied, setApplied] = useState<Readonly<Record<string, readonly string[]>>>({});

  const watchlist = watchlists.data?.find((list) => list.id === watchlistId);
  const byId = new Map(entries.map((entry) => [entry.instrument.id, entry] as const));
  const shown = watchlist
    ? watchlist.items.flatMap((item) => {
        const entry = byId.get(item.instrument.id);
        return entry ? [entry] : [];
      })
    : entries;
  const hidden = watchlist ? watchlist.items.length - shown.length : 0;
  const selected: UniverseEntry | undefined = (selectedId ? byId.get(selectedId) : undefined) ?? shown[0] ?? entries[0];

  const exchanges = new Set(entries.map((entry) => entry.instrument.exchange));
  const sessions = (overview.data?.markets ?? []).filter((session) => exchanges.has(session.exchange));
  const marketsOpen = sessions.length === 0 ? null : sessions.some((session) => OPEN_STATES.has(session.state));
  const providers = new Set<Provider>(entries.map((entry) => entry.provider));
  const selectedApplied = selected ? (applied[selected.instrument.id] ?? NOTHING_APPLIED) : NOTHING_APPLIED;
  const toggleOverlay = (instrumentId: string, deploymentId: string) =>
    setApplied((previous) => ({
      ...previous,
      [instrumentId]: toggleApplied(previous[instrumentId] ?? NOTHING_APPLIED, deploymentId),
    }));

  return (
    <div className="flex flex-col gap-4">
      <Header workspace={workspace} sessions={sessions} paused={workspacePause(rules.data)} />
      {workspace.is_enabled ? null : (
        <div className="rounded-md border border-amber-500/40 bg-amber-500/10 p-3 text-sm">
          This workspace is disabled: none of its instruments stream for it and its strategies are blocked. Switch it on
          above to start.
        </div>
      )}
      <DataWarning entries={entries} quotes={quotes} marketsOpen={marketsOpen} />
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_380px]">
        <div className="flex min-w-0 flex-col gap-4">
          {selected ? (
            <ChartPanel
              slug={slug}
              instrument={selected.instrument}
              provider={selected.provider}
              interval={chartInterval}
              onIntervalChange={setChartInterval}
              applied={selectedApplied}
              onToggleApplied={(deploymentId) => toggleOverlay(selected.instrument.id, deploymentId)}
            />
          ) : (
            <Card>
              <CardContent>
                <EmptyState title="Nothing to chart">Add instruments under Universe to see their candles.</EmptyState>
              </CardContent>
            </Card>
          )}
          <Card>
            <CardHeader
              title="Quotes"
              description={
                hidden > 0
                  ? `${hidden} instrument${hidden === 1 ? " is" : "s are"} in the watchlist but not in the universe.`
                  : undefined
              }
              actions={
                <span className="flex items-center gap-2 text-xs text-muted-foreground">
                  <label htmlFor={filterId}>Show</label>
                  <NativeSelect
                    id={filterId}
                    className="h-8 w-52"
                    value={watchlist ? watchlist.id : ""}
                    onChange={(event) => setWatchlistId(event.target.value)}
                  >
                    <option value="">{`Whole universe (${entries.length})`}</option>
                    {(watchlists.data ?? []).map((list) => (
                      <option key={list.id} value={list.id}>
                        {`${list.name} (${list.items.length})`}
                      </option>
                    ))}
                  </NativeSelect>
                </span>
              }
            />
            {watchlist && shown.length === 0 ? (
              <CardContent>
                <EmptyState title={`${watchlist.name} has no streamed instruments`}>
                  Add instruments to it under Watchlists below.
                </EmptyState>
              </CardContent>
            ) : (
              <QuoteTable
                entries={shown}
                quotes={quotes}
                selectedId={selected ? selected.instrument.id : null}
                onSelect={setSelectedId}
              />
            )}
          </Card>
        </div>
        <div className="flex min-w-0 flex-col gap-4">
          {selected ? (
            <StrategyPanel
              slug={slug}
              entries={entries}
              entry={selected}
              chartInterval={chartInterval}
              applied={selectedApplied}
              onToggleApplied={(deploymentId) => toggleOverlay(selected.instrument.id, deploymentId)}
            />
          ) : null}
          {selected ? <InstrumentPanel entry={selected} quote={quotes[selected.instrument.id]} /> : null}
          <WorkspaceSignals slug={slug} />
        </div>
      </div>
      <Tabs defaultValue="strategies">
        <TabsList aria-label="Workspace settings">
          <TabsTrigger value="strategies">Strategies</TabsTrigger>
          <TabsTrigger value="universe">{`Universe (${entries.length})`}</TabsTrigger>
          <TabsTrigger value="watchlists">
            {watchlists.data ? `Watchlists (${watchlists.data.length})` : "Watchlists"}
          </TabsTrigger>
          <TabsTrigger value="risk">Risk</TabsTrigger>
          <TabsTrigger value="feeds">Feeds</TabsTrigger>
        </TabsList>
        <TabsContent value="strategies">
          <DeploymentsPanel slug={slug} entries={entries} marketRegion={workspace.market_region} />
        </TabsContent>
        <TabsContent value="universe">
          <UniversePanel workspace={workspace} entries={entries} />
        </TabsContent>
        <TabsContent value="watchlists">
          <WatchlistsPanel slug={slug} entries={entries} />
        </TabsContent>
        <TabsContent value="risk">
          <RiskPanel slug={slug} />
        </TabsContent>
        <TabsContent value="feeds">
          <div className="flex flex-col gap-2">
            <p className="text-xs text-muted-foreground">
              Streams of the providers this universe uses. Accounts and sign-ins are on the{" "}
              <Link className="underline" href="/providers">
                Providers
              </Link>{" "}
              page.
            </p>
            <FeedPanel providers={providers} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function WorkspacePage() {
  const params = useParams<{ slug: string }>();
  const slug = decodeSlug(params.slug);
  const universe = useQuery({ queryKey: queryKeys.universe(slug), queryFn: () => workspacesApi.universe(slug) });

  if (universe.isPending) return <LoadingState label="Loading the workspace…" />;
  if (universe.isError) {
    if (universe.error instanceof ApiError && universe.error.status === 404) {
      return (
        <EmptyState title={`No workspace "${slug}"`}>
          <Link className="underline" href="/">
            Back to the overview
          </Link>
        </EmptyState>
      );
    }
    return <ErrorState error={universe.error} onRetry={() => void universe.refetch()} />;
  }
  // Keyed so the selection and the watchlist filter reset when moving to another workspace.
  return <Workspace key={universe.data.workspace.id} workspace={universe.data.workspace} entries={universe.data.entries} />;
}
