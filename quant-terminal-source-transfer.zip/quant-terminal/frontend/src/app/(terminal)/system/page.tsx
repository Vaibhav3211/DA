"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { ACCOUNT_STATUS } from "@/components/providers/account-card";
import { StreamTable } from "@/components/providers/stream-table";
import { RiskRulesTable } from "@/components/risk/risk-rules";
import { useSystemHealth } from "@/components/shell/top-bar";
import { StatusBadge } from "@/components/status/status-badge";
import { KillSwitchCard } from "@/components/system/kill-switch-card";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { JsonBlock, Stat, StatGrid } from "@/components/ui/stat";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { system as systemApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { AccountHealth, Alert, ComponentHealth, SystemHealth, WorkerStatus } from "@/lib/api/types.gen";
import { ageSeconds, formatAge, formatDateTime, formatInteger, formatLatency, humanize } from "@/lib/format";
import { useNow } from "@/lib/hooks";
import { cn } from "@/lib/utils";

const HEALTH = {
  ok: { label: "Healthy", variant: "success" },
  degraded: { label: "Degraded", variant: "warning" },
  down: { label: "Down", variant: "destructive" },
} as const;

const ALERT_VARIANT = { critical: "destructive", warning: "warning", info: "info" } as const;

function HealthSummary({ health }: { health: SystemHealth }) {
  const now = useNow(5000);
  const style = HEALTH[health.status];
  const flags = Object.entries(health.flags);
  return (
    <Card data-testid="system-health" aria-label="System health">
      <CardHeader
        title="Health"
        description={`Reported ${formatAge(health.generated_at, now)}`}
        actions={
          <>
            {health.simulated_mode ? (
              <StatusBadge status="SIMULATED" title="The platform runs in simulated mode" />
            ) : null}
            <Badge variant={style.variant}>{style.label}</Badge>
          </>
        }
      />
      <CardContent className="flex flex-col gap-3">
        <StatGrid>
          <Stat label="Status" value={style.label} />
          <Stat label="Version" value={health.version} />
          <Stat label="Environment" value={health.app_env} />
          <Stat label="Mode" value={health.simulated_mode ? "Simulated" : "Provider data"} />
        </StatGrid>
        {flags.length > 0 ? (
          <div className="flex flex-wrap gap-1" aria-label="Feature flags">
            {flags.map(([name, on]) => (
              <Badge key={name} variant={on ? "info" : "outline"}>
                {`${humanize(name)}: ${on ? "on" : "off"}`}
              </Badge>
            ))}
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}

function AlertList({ alerts }: { alerts: readonly Alert[] }) {
  if (alerts.length === 0) return <EmptyState title="No alerts">Everything the API checks looks fine.</EmptyState>;
  return (
    <ul className="flex flex-col gap-2">
      {alerts.map((alert) => (
        <li key={`${alert.code}:${alert.subject ?? ""}`} className="flex items-start gap-2 text-sm">
          <Badge variant={ALERT_VARIANT[alert.severity]}>{alert.severity}</Badge>
          <span className="min-w-0">
            {alert.message}
            {alert.subject ? <span className="ml-1 text-xs text-muted-foreground">({alert.subject})</span> : null}
          </span>
        </li>
      ))}
    </ul>
  );
}

function ComponentsTable({ components }: { components: readonly ComponentHealth[] }) {
  if (components.length === 0) return <EmptyState title="No components reported" />;
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Component</TableHead>
          <TableHead>State</TableHead>
          <TableHead className="text-right">Latency</TableHead>
          <TableHead>Error</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {components.map((component) => (
          <TableRow key={component.name}>
            <TableCell className="font-medium">{humanize(component.name)}</TableCell>
            <TableCell>
              <Badge variant={component.ok ? "success" : "destructive"}>{component.ok ? "OK" : "Failing"}</Badge>
            </TableCell>
            <TableCell className="text-right font-mono text-xs tabular-nums">
              {formatLatency(component.latency_ms)}
            </TableCell>
            <TableCell className="max-w-md text-xs text-red-300">{component.error ?? ""}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

function WorkersTable({ workers }: { workers: readonly WorkerStatus[] }) {
  const now = useNow(5000);
  if (workers.length === 0) return <EmptyState title="No workers reported">Start the workers to stream data.</EmptyState>;
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Worker</TableHead>
          <TableHead>State</TableHead>
          <TableHead>Instance</TableHead>
          <TableHead>Version</TableHead>
          <TableHead>Started</TableHead>
          <TableHead>Heartbeat</TableHead>
          <TableHead>Details</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {workers.map((worker) => (
          <TableRow key={`${worker.worker}:${worker.instance ?? ""}`}>
            <TableCell className="font-medium">{humanize(worker.worker)}</TableCell>
            <TableCell>
              <Badge variant={worker.alive ? "success" : "destructive"}>
                {worker.alive ? "Alive" : "Not reporting"}
              </Badge>
            </TableCell>
            <TableCell className="font-mono text-xs">{worker.instance ?? "—"}</TableCell>
            <TableCell className="font-mono text-xs">{worker.version ?? "—"}</TableCell>
            <TableCell className="text-xs whitespace-nowrap">{formatDateTime(worker.started_at)}</TableCell>
            <TableCell className="text-xs whitespace-nowrap" title={formatDateTime(worker.heartbeat_at)}>
              {formatAge(worker.heartbeat_at, now)}
            </TableCell>
            <TableCell className="text-xs">
              {Object.keys(worker.details).length > 0 ? (
                <details>
                  <summary className="cursor-pointer text-muted-foreground">Show</summary>
                  <JsonBlock value={worker.details} className="mt-1 max-w-md" />
                </details>
              ) : (
                "—"
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

function AccountsTable({ accounts }: { accounts: readonly AccountHealth[] }) {
  const now = useNow(30_000);
  if (accounts.length === 0) {
    return (
      <EmptyState title="No provider accounts">
        Add one on the <Link className="underline" href="/providers">Providers</Link> page.
      </EmptyState>
    );
  }
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Provider</TableHead>
          <TableHead>Account</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Streaming</TableHead>
          <TableHead>Token expires</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {accounts.map((account) => {
          const status = ACCOUNT_STATUS[account.status];
          // ageSeconds is zero for a time in the future, so a positive age means the token has expired.
          const expired = (ageSeconds(account.token_expires_at, now) ?? 0) > 0;
          return (
            <TableRow key={account.account_id}>
              <TableCell>{humanize(account.provider)}</TableCell>
              <TableCell className="font-medium">{account.label}</TableCell>
              <TableCell>
                <Badge variant={status.variant} title={status.hint}>
                  {status.label}
                </Badge>
              </TableCell>
              <TableCell className="text-xs">{account.is_enabled ? "Enabled" : "Off"}</TableCell>
              <TableCell className={cn("text-xs whitespace-nowrap", expired && "text-red-300")}>
                {account.token_expires_at
                  ? `${formatDateTime(account.token_expires_at)}${expired ? " (expired)" : ""}`
                  : "—"}
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

function MetricsCard() {
  const metrics = useQuery({ queryKey: queryKeys.metrics, queryFn: systemApi.metrics, refetchInterval: 30_000 });
  const data = metrics.data;
  return (
    <Card aria-label="Metrics">
      <CardHeader title="Metrics" description="A summary; Prometheus scrapes the full set." />
      <CardContent className="flex flex-col gap-3">
        {data ? (
          <>
            <StatGrid>
              <Stat label="Socket clients" value={formatInteger(data.websocket_clients)} />
              <Stat label="Workers" value={formatInteger(data.workers.length)} />
              <Stat label="Feeds" value={formatInteger(data.feeds.length)} />
              <Stat label="Prometheus" value={data.prometheus_endpoint} title="The API's Prometheus scrape endpoint" />
            </StatGrid>
            <details>
              <summary className="cursor-pointer text-xs text-muted-foreground">Raw worker and feed metrics</summary>
              <JsonBlock value={{ workers: data.workers, feeds: data.feeds }} className="mt-2" />
            </details>
          </>
        ) : metrics.isError ? (
          <ErrorState error={metrics.error} onRetry={() => void metrics.refetch()} />
        ) : (
          <LoadingState />
        )}
      </CardContent>
    </Card>
  );
}

export default function SystemPage() {
  const health = useSystemHealth();
  const data = health.data;
  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-lg font-semibold">System</h1>
        <p className="text-sm text-muted-foreground">
          The API, workers, feeds and accounts. Health refreshes over the live socket and every 30 seconds.
        </p>
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        {data ? (
          <HealthSummary health={data} />
        ) : health.isError ? (
          <ErrorState error={health.error} title="Could not load system health" onRetry={() => void health.refetch()} />
        ) : (
          <LoadingState label="Loading system health…" />
        )}
        <KillSwitchCard />
      </div>
      {data ? (
        <>
          <Card aria-label="Alerts">
            <CardHeader title="Alerts" />
            <CardContent>
              <AlertList alerts={data.alerts} />
            </CardContent>
          </Card>
          <div className="grid gap-4 xl:grid-cols-2">
            <Card aria-label="Components">
              <CardHeader title="Components" description="Database, cache and other services the API depends on." />
              <CardContent>
                <ComponentsTable components={data.components} />
              </CardContent>
            </Card>
            <Card aria-label="Provider accounts">
              <CardHeader
                title="Provider accounts"
                actions={
                  <Link className="text-xs underline" href="/providers">
                    Manage
                  </Link>
                }
              />
              <CardContent>
                <AccountsTable accounts={data.accounts} />
              </CardContent>
            </Card>
          </div>
          <Card aria-label="Workers">
            <CardHeader title="Workers" description="Background processes and their last heartbeat." />
            <CardContent>
              <WorkersTable workers={data.workers} />
            </CardContent>
          </Card>
          <Card aria-label="Provider streams">
            <CardHeader title="Provider streams" />
            <CardContent>
              <StreamTable streams={data.feeds} />
            </CardContent>
          </Card>
        </>
      ) : null}
      <MetricsCard />
      <Card aria-label="Global risk rules">
        <CardHeader title="Global risk rules" description="The global layer; a workspace can override a rule." />
        <CardContent>
          <RiskRulesTable workspace={null} />
        </CardContent>
      </Card>
    </div>
  );
}
