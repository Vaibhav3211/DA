import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Providers } from "./providers";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Quant Terminal", template: "%s · Quant Terminal" },
  description: "Live market data, strategies and signals.",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = { colorScheme: "dark", themeColor: "#11131a" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen font-sans antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
