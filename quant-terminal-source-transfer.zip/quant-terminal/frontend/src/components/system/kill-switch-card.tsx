"use client";

import { useQuery } from "@tanstack/react-query";
import { useId, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ErrorState, LoadingState } from "@/components/ui/feedback";
import { Textarea } from "@/components/ui/input";
import { system as systemApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type { KillSwitchUpdate } from "@/lib/api/types.gen";
import { formatDateTime } from "@/lib/format";
import { notify } from "@/lib/notifications";

const REASON_MAX = 300;

/** Confirms engaging or releasing the switch; mounted only while open, so each opening starts blank. */
function KillSwitchDialog({ engage, onClose }: { engage: boolean; onClose: () => void }) {
  const reasonId = useId();
  const [reason, setReason] = useState("");
  const update = useApiMutation({
    mutationFn: (body: KillSwitchUpdate) => systemApi.setKillSwitch(body),
    invalidate: [queryKeys.killSwitch, queryKeys.health],
    // The live socket reports the change too; the shared notice key keeps it to one notice.
    success: null,
    onSuccess: (next) => {
      notify(
        next.engaged ? "error" : "success",
        next.engaged ? "Kill switch engaged" : "Kill switch released",
        next.reason,
        "kill-switch",
      );
      onClose();
    },
    errorTitle: "Could not change the kill switch",
  });

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open && !update.isPending) onClose();
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{engage ? "Engage the kill switch?" : "Release the kill switch?"}</DialogTitle>
          <DialogDescription>
            {engage
              ? "The risk gate will block every new actionable signal in every workspace until the switch is released."
              : "New actionable signals will again be checked against the other risk rules only."}
          </DialogDescription>
        </DialogHeader>
        <form
          className="flex flex-col gap-1.5"
          onSubmit={(event) => {
            event.preventDefault();
            const note = reason.trim();
            update.mutate({ engaged: engage, reason: note === "" ? null : note });
          }}
        >
          <label htmlFor={reasonId} className="text-sm">
            Reason <span className="text-muted-foreground">(optional, kept in the audit log)</span>
          </label>
          <Textarea
            id={reasonId}
            value={reason}
            maxLength={REASON_MAX}
            rows={3}
            placeholder={engage ? "e.g. feed glitch, results day" : "e.g. feed recovered"}
            onChange={(event) => setReason(event.target.value)}
          />
          <span className="text-right text-xs text-muted-foreground">{`${reason.length}/${REASON_MAX}`}</span>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline" disabled={update.isPending}>
                Cancel
              </Button>
            </DialogClose>
            <Button type="submit" variant={engage ? "destructive" : "default"} disabled={update.isPending}>
              {engage ? "Engage" : "Release"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/** The global kill switch: its state, who changed it last, and the control to change it. */
export function KillSwitchCard() {
  // The action is fixed when the dialog opens, even if the state changes while it is open.
  const [action, setAction] = useState<"engage" | "release" | null>(null);
  const state = useQuery({ queryKey: queryKeys.killSwitch, queryFn: systemApi.killSwitch, refetchInterval: 30_000 });
  const data = state.data;
  return (
    <Card aria-label="Kill switch" className={data?.engaged ? "border-red-500/50" : undefined}>
      <CardHeader
        title="Kill switch"
        description="While engaged, the risk gate blocks every new actionable signal."
        actions={
          data ? (
            <Button
              size="sm"
              variant={data.engaged ? "outline" : "destructive"}
              onClick={() => setAction(data.engaged ? "release" : "engage")}
            >
              {data.engaged ? "Release…" : "Engage…"}
            </Button>
          ) : null
        }
      />
      <CardContent className="flex flex-col gap-2 text-sm">
        {data ? (
          <>
            <span className="flex flex-wrap items-center gap-2">
              <Badge variant={data.engaged ? "destructive" : "success"}>{data.engaged ? "Engaged" : "Released"}</Badge>
              {data.updated_at ? (
                <span className="text-xs text-muted-foreground">
                  {`Changed ${formatDateTime(data.updated_at)}${data.updated_by ? ` by ${data.updated_by}` : ""}`}
                </span>
              ) : null}
            </span>
            {data.reason ? <p className="text-xs">{`Reason: ${data.reason}`}</p> : null}
          </>
        ) : state.isError ? (
          <ErrorState error={state.error} onRetry={() => void state.refetch()} />
        ) : (
          <LoadingState />
        )}
      </CardContent>
      {action ? <KillSwitchDialog engage={action === "engage"} onClose={() => setAction(null)} /> : null}
    </Card>
  );
}
