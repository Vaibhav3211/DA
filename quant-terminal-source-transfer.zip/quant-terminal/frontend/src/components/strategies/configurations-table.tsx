"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { DeploymentView, StrategyView } from "@/lib/api/types.gen";
import { formatDateTime } from "@/lib/format";
import { scopeSummary, type ScopeContext } from "@/lib/strategies";
import { ArchiveConfigurationButton, LiveSignalsControl, MonitoringBadge, MonitoringNotes } from "./monitoring";
import { RunSummary } from "./run-status";

/** Saved configurations with their live-monitoring state and the actions on them. */
export function ConfigurationsTable({
  deployments,
  strategies,
  context,
  showWorkspace = false,
  onEdit,
}: {
  deployments: readonly DeploymentView[];
  /** The catalogue by strategy id. */
  strategies: ReadonlyMap<string, StrategyView>;
  context?: ScopeContext;
  showWorkspace?: boolean;
  onEdit: (strategy: StrategyView, deployment: DeploymentView) => void;
}) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Configuration</TableHead>
          <TableHead>Instruments</TableHead>
          <TableHead>Live signals</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {deployments.map((deployment) => {
          const strategy = strategies.get(deployment.strategy_id);
          const run = deployment.last_run;
          return (
            <TableRow key={deployment.id}>
              <TableCell>
                <span className="font-medium">{deployment.label}</span>
                <span className="block text-xs text-muted-foreground">
                  {`${strategy?.name ?? deployment.strategy_id} · v${deployment.strategy_version}`}
                  {strategy && strategy.version !== deployment.strategy_version ? ` (code has v${strategy.version})` : ""}
                </span>
                {showWorkspace ? (
                  <Link
                    href={`/workspaces/${encodeURIComponent(deployment.workspace_slug)}`}
                    className="block text-xs underline-offset-2 hover:underline"
                  >
                    {`${deployment.workspace_slug} · ${deployment.market_region}`}
                  </Link>
                ) : null}
              </TableCell>
              <TableCell className="text-xs">{scopeSummary(deployment, context)}</TableCell>
              <TableCell>
                <div className="flex max-w-md flex-col items-start gap-1">
                  <MonitoringBadge monitoring={deployment.monitoring} />
                  <MonitoringNotes monitoring={deployment.monitoring} />
                  {deployment.is_enabled && run ? <RunSummary run={run} /> : null}
                  {deployment.is_enabled && deployment.enabled_at ? (
                    <span className="text-xs text-muted-foreground">
                      {`On since ${formatDateTime(deployment.enabled_at)}${deployment.enabled_by ? ` by ${deployment.enabled_by}` : ""}`}
                    </span>
                  ) : null}
                </div>
              </TableCell>
              <TableCell className="text-right">
                <div className="flex flex-wrap justify-end gap-1">
                  <LiveSignalsControl deployment={deployment} strategyName={strategy?.name} context={context} />
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={!strategy?.is_available}
                    title={strategy?.is_available ? undefined : "The strategy is not in the code any more"}
                    aria-label={`Edit ${deployment.label}`}
                    onClick={() => {
                      if (strategy) onEdit(strategy, deployment);
                    }}
                  >
                    Edit…
                  </Button>
                  <ArchiveConfigurationButton deployment={deployment} />
                </div>
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}
