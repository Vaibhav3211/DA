"use client";

import type { ReactNode } from "react";
import { Field, Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import type { FormValues, SchemaField } from "@/lib/schema-form";

function describeDefault(value: unknown): string | null {
  if (value === undefined) return null;
  if (value === null) return "none";
  return typeof value === "object" ? JSON.stringify(value) : String(value);
}

function hintFor(field: SchemaField): string | null {
  const bounds = [
    field.minimum !== null ? `at least ${field.minimum}` : null,
    field.exclusiveMinimum !== null ? `more than ${field.exclusiveMinimum}` : null,
    field.maximum !== null ? `at most ${field.maximum}` : null,
    field.exclusiveMaximum !== null ? `less than ${field.exclusiveMaximum}` : null,
  ].filter((part): part is string => part !== null);
  const defaultText = describeDefault(field.defaultValue);
  const parts = [
    field.description,
    bounds.length > 0 ? `Must be ${bounds.join(" and ")}.` : null,
    field.nullable && field.kind !== "enum" ? "Leave empty for none." : null,
    defaultText !== null ? `Default: ${defaultText}.` : null,
  ].filter((part): part is string => Boolean(part));
  return parts.length > 0 ? parts.join(" ") : null;
}

/** Inputs for a strategy's settings, one per field of its JSON schema. */
export function SchemaFormFields({
  fields,
  values,
  errors,
  onChange,
  idPrefix,
  disabled = false,
}: {
  fields: readonly SchemaField[];
  values: FormValues;
  errors: Record<string, string>;
  onChange: (name: string, value: string | boolean) => void;
  idPrefix: string;
  disabled?: boolean;
}) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {fields.map((field) => {
        const id = `${idPrefix}-${field.name}`;
        const error: string | undefined = errors[field.name];
        const value: string | boolean | undefined = values[field.name];
        const text = typeof value === "string" ? value : "";
        const inputProps = {
          id,
          disabled,
          "aria-invalid": error ? true : undefined,
          "aria-describedby": error ? `${id}-error` : undefined,
        };
        let control: ReactNode;
        switch (field.kind) {
          case "boolean":
            control = (
              <Switch
                id={id}
                checked={value === true}
                onCheckedChange={(checked) => onChange(field.name, checked)}
                disabled={disabled}
              />
            );
            break;
          case "enum":
            control = (
              <NativeSelect {...inputProps} value={text} onChange={(event) => onChange(field.name, event.target.value)}>
                {field.nullable || text === "" ? <option value="">{field.nullable ? "None" : "Choose…"}</option> : null}
                {field.options.map((option) => (
                  <option key={String(option)} value={String(option)}>
                    {String(option)}
                  </option>
                ))}
              </NativeSelect>
            );
            break;
          case "json":
            control = (
              <Textarea
                {...inputProps}
                rows={4}
                spellCheck={false}
                value={text}
                onChange={(event) => onChange(field.name, event.target.value)}
              />
            );
            break;
          default:
            control = (
              <Input
                {...inputProps}
                autoComplete="off"
                inputMode={field.kind === "integer" ? "numeric" : field.kind === "string" ? undefined : "decimal"}
                value={text}
                onChange={(event) => onChange(field.name, event.target.value)}
              />
            );
        }
        return (
          <Field
            key={field.name}
            label={field.label}
            htmlFor={id}
            hint={hintFor(field)}
            error={error}
            className={field.kind === "json" ? "sm:col-span-2" : undefined}
          >
            {control}
          </Field>
        );
      })}
    </div>
  );
}
