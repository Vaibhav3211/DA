"use client";

import { Badge, type BadgeVariant } from "@/components/ui/badge";
import type { RunView, StrategyRunStatus } from "@/lib/api/types.gen";
import { formatAge, formatInteger, humanize } from "@/lib/format";
import { useNow } from "@/lib/hooks";

const RUN_VARIANT: Record<StrategyRunStatus, BadgeVariant> = {
  STARTING: "info",
  RUNNING: "success",
  CIRCUIT_OPEN: "warning",
  STOPPED: "secondary",
  FAILED: "destructive",
};

const RUN_HELP: Record<StrategyRunStatus, string> = {
  STARTING: "The strategy worker is warming the strategy up.",
  RUNNING: "The strategy worker is evaluating it.",
  CIRCUIT_OPEN: "Calls are skipped after repeated failures or timeouts; the worker makes a trial call after a pause.",
  STOPPED: "The run ended normally.",
  FAILED: "The run ended with an error, or its worker stopped sending heartbeats.",
};

export function RunStatusBadge({ run }: { run: RunView | null }) {
  if (run === null) {
    return (
      <Badge variant="outline" title="The strategy worker has not run this deployment yet">
        Never run
      </Badge>
    );
  }
  return (
    <Badge variant={RUN_VARIANT[run.status]} title={RUN_HELP[run.status]}>
      {humanize(run.status)}
    </Badge>
  );
}

/** One line of run counters for a table cell. */
export function RunSummary({ run }: { run: RunView }) {
  const now = useNow(5000);
  const problems = run.failures + run.timeouts;
  return (
    <span className="text-xs text-muted-foreground" title={run.last_error ?? undefined}>
      {`Heartbeat ${formatAge(run.heartbeat_at ?? run.started_at, now)} · ${formatInteger(run.candles_processed)} candles · ${formatInteger(run.signals_emitted)} signals`}
      {problems > 0 ? (
        <span className="text-amber-200">{` · ${formatInteger(run.failures)} failures, ${formatInteger(run.timeouts)} timeouts`}</span>
      ) : null}
    </span>
  );
}
