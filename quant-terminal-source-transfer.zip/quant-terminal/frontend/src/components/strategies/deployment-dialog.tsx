"use client";

import { useId, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Field, Input } from "@/components/ui/input";
import { deployments as deploymentsApi } from "@/lib/api/endpoints";
import { useApiMutation } from "@/lib/api/hooks";
import type {
  ConfigurationCreate,
  ConfigurationUpdate,
  DeploymentView,
  ScopeBody,
  ScopeKind,
  StrategyView,
  UniverseEntry,
} from "@/lib/api/types.gen";
import { parseFormValues, schemaFields, toFormValues, type FormValues } from "@/lib/schema-form";
import { CONFIGURATION_QUERIES } from "./monitoring";
import { SchemaFormFields } from "./schema-form-fields";

const MAX_LABEL = 80;

export interface ConfigurationTarget {
  strategy: StrategyView;
  /** Null for a new configuration. */
  deployment: DeploymentView | null;
}

type SaveRequest =
  | { kind: "create"; body: ConfigurationCreate }
  | { kind: "update"; id: string; body: ConfigurationUpdate };

function sameIds(a: readonly string[], b: readonly string[]): boolean {
  if (a.length !== b.length) return false;
  const known = new Set(a);
  return b.every((id) => known.has(id));
}

/** Saves a configuration of a strategy: its name, settings and instruments. Live signals are a separate step. */
export function DeploymentDialog({
  slug,
  strategy,
  deployment,
  entries,
  initialInstrumentIds = [],
  onClose,
}: ConfigurationTarget & {
  slug: string;
  entries: readonly UniverseEntry[];
  /** The instruments a new configuration starts with, such as the chart's. */
  initialInstrumentIds?: readonly string[];
  onClose: () => void;
}) {
  const formId = useId();
  const fields = useMemo(() => schemaFields(strategy.config_schema), [strategy.config_schema]);
  const [label, setLabel] = useState(deployment?.label ?? "");
  const [labelError, setLabelError] = useState<string | null>(null);
  const [values, setValues] = useState<FormValues>(() =>
    toFormValues(fields, { ...strategy.default_config, ...(deployment?.config ?? {}) }),
  );
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [scope, setScope] = useState<ScopeKind>(deployment?.scope_kind ?? "INSTRUMENTS");
  const [selected, setSelected] = useState<ReadonlySet<string>>(
    () => new Set(deployment ? deployment.instrument_ids : initialInstrumentIds),
  );
  // Choosing the whole workspace takes a second, explicit tick; a saved whole-workspace scope already had it.
  const [wholeConfirmed, setWholeConfirmed] = useState(deployment?.scope_kind === "WORKSPACE");
  const [scopeError, setScopeError] = useState<string | null>(null);

  const universeIds = useMemo(() => new Set(entries.map((entry) => entry.instrument.id)), [entries]);
  const outside = (deployment?.instrument_ids ?? []).filter((id) => !universeIds.has(id)).length;
  const savedVersion = deployment?.strategy_version;

  const save = useApiMutation({
    mutationFn: (request: SaveRequest) =>
      request.kind === "create" ? deploymentsApi.create(request.body) : deploymentsApi.update(request.id, request.body),
    invalidate: CONFIGURATION_QUERIES,
    success: (view, request) =>
      request.kind === "create"
        ? `${view.label} saved; its live signals stay off until you enable them`
        : `${view.label} saved`,
    errorTitle: deployment ? `Could not save ${deployment.label}` : `Could not save a configuration of ${strategy.name}`,
    onSuccess: onClose,
  });

  const change = (name: string, value: string | boolean) => {
    setValues((current) => ({ ...current, [name]: value }));
    setErrors((current) => {
      if (!(name in current)) return current;
      const next = { ...current };
      delete next[name];
      return next;
    });
  };

  const toggle = (id: string, checked: boolean) => {
    setSelected((current) => {
      const next = new Set(current);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });
    setScopeError(null);
  };

  const submit = () => {
    const parsed = parseFormValues(fields, values);
    setErrors(parsed.errors);
    const name = label.trim();
    const nameProblem =
      deployment && name === ""
        ? "A saved configuration needs a name."
        : name.length > MAX_LABEL
          ? `Use at most ${MAX_LABEL} characters.`
          : null;
    setLabelError(nameProblem);
    // Universe order; instruments no longer in the universe drop out of the scope.
    const ids = entries.filter((entry) => selected.has(entry.instrument.id)).map((entry) => entry.instrument.id);
    const scopeProblem =
      scope === "INSTRUMENTS" && ids.length === 0
        ? "Tick at least one instrument, or choose the whole workspace."
        : scope === "WORKSPACE" && !wholeConfirmed
          ? "Confirm that this configuration should watch the whole workspace."
          : null;
    setScopeError(scopeProblem);
    if (Object.keys(parsed.errors).length > 0 || nameProblem !== null || scopeProblem !== null) return;

    const scopeBody: ScopeBody = scope === "WORKSPACE" ? { kind: "WORKSPACE" } : { kind: "INSTRUMENTS", instrument_ids: ids };
    if (deployment === null) {
      save.mutate({
        kind: "create",
        body: {
          workspace: slug,
          strategy_id: strategy.strategy_id,
          scope: scopeBody,
          label: name === "" ? undefined : name,
          config: parsed.config,
        },
      });
      return;
    }
    const scopeChanged =
      scope !== deployment.scope_kind || (scope === "INSTRUMENTS" && !sameIds(ids, deployment.instrument_ids));
    save.mutate({
      kind: "update",
      id: deployment.id,
      body: {
        label: name === deployment.label ? undefined : name,
        scope: scopeChanged ? scopeBody : undefined,
        config: parsed.config,
      },
    });
  };

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{deployment ? `Edit ${deployment.label}` : `New configuration of ${strategy.name}`}</DialogTitle>
          <DialogDescription>
            {deployment
              ? `${strategy.name} in ${slug}. The chart and live signals use the saved settings.`
              : `${strategy.name} v${strategy.version} in ${slug}. Saving starts nothing: live signals stay off until you enable them.`}
          </DialogDescription>
        </DialogHeader>
        {savedVersion !== undefined && savedVersion !== strategy.version ? (
          <p className="rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
            {`Saved with version ${savedVersion}; saving moves it to version ${strategy.version}, the one in the code.`}
          </p>
        ) : null}
        {deployment?.is_enabled ? (
          <p className="rounded-md border border-sky-500/40 bg-sky-500/10 px-3 py-2 text-xs text-sky-200">
            Live signals are on. If you change its settings, instruments or version, the strategy worker restarts
            monitoring with them. A change that would duplicate another enabled configuration is refused.
          </p>
        ) : null}
        <form
          id={formId}
          noValidate
          className="flex flex-col gap-5"
          onSubmit={(event) => {
            event.preventDefault();
            submit();
          }}
        >
          <Field
            label="Name"
            htmlFor={`${formId}-label`}
            hint={
              deployment
                ? "Unique among the workspace's saved configurations."
                : `Optional: without one it is named ${strategy.strategy_id}, numbered if that is taken.`
            }
            error={labelError}
          >
            <Input
              id={`${formId}-label`}
              value={label}
              maxLength={MAX_LABEL}
              placeholder={deployment ? undefined : strategy.strategy_id}
              disabled={save.isPending}
              aria-invalid={labelError !== null}
              aria-describedby={labelError ? `${formId}-label-error` : undefined}
              onChange={(event) => {
                setLabel(event.target.value);
                setLabelError(null);
              }}
            />
          </Field>

          <section aria-labelledby={`${formId}-settings`} className="flex flex-col gap-3">
            <div className="flex items-center justify-between gap-2">
              <h3 id={`${formId}-settings`} className="text-sm font-medium">
                Settings
              </h3>
              {fields.length > 0 ? (
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  disabled={save.isPending}
                  onClick={() => {
                    setValues(toFormValues(fields, strategy.default_config));
                    setErrors({});
                  }}
                >
                  Reset to defaults
                </Button>
              ) : null}
            </div>
            {fields.length === 0 ? (
              <p className="text-xs text-muted-foreground">This strategy has no settings.</p>
            ) : (
              <SchemaFormFields
                fields={fields}
                values={values}
                errors={errors}
                onChange={change}
                idPrefix={`${formId}-config`}
                disabled={save.isPending}
              />
            )}
          </section>

          <fieldset className="flex flex-col gap-2" disabled={save.isPending}>
            <legend className="mb-1 text-sm font-medium">Instruments</legend>
            <label className="flex items-start gap-2 text-sm">
              <input
                type="radio"
                name={`${formId}-scope`}
                className="mt-0.5 accent-primary"
                checked={scope === "INSTRUMENTS"}
                onChange={() => {
                  setScope("INSTRUMENTS");
                  setScopeError(null);
                }}
              />
              <span>
                Chosen instruments
                <span className="block text-xs text-muted-foreground">
                  {`${selected.size} ticked. Instruments added to the workspace later are not included.`}
                </span>
              </span>
            </label>
            {scope === "INSTRUMENTS" ? (
              entries.length === 0 ? (
                <p className="text-xs text-muted-foreground">The universe is empty: add instruments under Universe first.</p>
              ) : (
                <ul
                  aria-label="Instruments to watch"
                  className="grid max-h-48 grid-cols-2 gap-x-4 overflow-y-auto rounded-md border p-2 sm:grid-cols-3"
                >
                  {entries.map((entry) => {
                    const id = `${formId}-instrument-${entry.instrument.id}`;
                    return (
                      <li key={entry.instrument.id} className="flex min-w-0 items-center gap-2 py-0.5 text-sm">
                        <input
                          id={id}
                          type="checkbox"
                          className="accent-primary"
                          checked={selected.has(entry.instrument.id)}
                          onChange={(event) => toggle(entry.instrument.id, event.target.checked)}
                        />
                        <label htmlFor={id} className="truncate font-mono">
                          {entry.instrument.symbol}
                        </label>
                        <span className="text-xs text-muted-foreground">{entry.instrument.exchange}</span>
                      </li>
                    );
                  })}
                </ul>
              )
            ) : null}
            <label className="flex items-start gap-2 text-sm">
              <input
                type="radio"
                name={`${formId}-scope`}
                className="mt-0.5 accent-primary"
                checked={scope === "WORKSPACE"}
                onChange={() => {
                  setScope("WORKSPACE");
                  setScopeError(null);
                }}
              />
              <span>
                The whole workspace
                <span className="block text-xs text-muted-foreground">
                  {`Every instrument in it: ${entries.length} now, and any added later.`}
                </span>
              </span>
            </label>
            {scope === "WORKSPACE" ? (
              <label className="ml-6 flex items-start gap-2 rounded-md border border-amber-500/40 bg-amber-500/10 p-2 text-xs text-amber-200">
                <input
                  type="checkbox"
                  className="mt-0.5 accent-primary"
                  checked={wholeConfirmed}
                  onChange={(event) => {
                    setWholeConfirmed(event.target.checked);
                    setScopeError(null);
                  }}
                />
                <span>
                  {`I want this configuration to watch every instrument in ${slug}, not only the ones I chose.`}
                </span>
              </label>
            ) : null}
            {outside > 0 ? (
              <p className="text-xs text-amber-200">
                {`${outside} of its instrument${outside === 1 ? " is" : "s are"} no longer in the workspace; saving drops ${outside === 1 ? "it" : "them"}.`}
              </p>
            ) : null}
            {scopeError ? (
              <p role="alert" className="text-xs text-red-300">
                {scopeError}
              </p>
            ) : null}
          </fieldset>
        </form>
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form={formId} disabled={save.isPending}>
            {save.isPending ? "Saving…" : deployment ? "Save" : "Save configuration"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
