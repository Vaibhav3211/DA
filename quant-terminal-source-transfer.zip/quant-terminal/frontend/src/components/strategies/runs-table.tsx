"use client";

import Link from "next/link";
import { EmptyState } from "@/components/ui/feedback";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { RunView } from "@/lib/api/types.gen";
import { formatAge, formatDateTime, formatInteger } from "@/lib/format";
import { useNow } from "@/lib/hooks";
import { cn } from "@/lib/utils";
import { RunStatusBadge } from "./run-status";

function Count({ value, warn = false }: { value: number; warn?: boolean }) {
  return (
    <TableCell className={cn("text-right font-mono text-xs tabular-nums", warn && value > 0 && "text-amber-200")}>
      {formatInteger(value)}
    </TableCell>
  );
}

function RunError({ error }: { error: string | null }) {
  if (!error) return <span className="text-muted-foreground">—</span>;
  const firstLine = error.split("\n", 1)[0] ?? error;
  return (
    <details className="max-w-sm">
      <summary className="cursor-pointer truncate text-red-300" title="Show the whole error">
        {firstLine}
      </summary>
      <pre className="mt-1 max-h-48 overflow-auto rounded-md bg-muted/40 p-2 font-mono text-[11px] whitespace-pre-wrap">
        {error}
      </pre>
    </details>
  );
}

/** Strategy runs, newest first: their state, heartbeat, counters and last error. */
export function RunsTable({ runs, showStrategy = false }: { runs: readonly RunView[]; showStrategy?: boolean }) {
  const now = useNow(5000);
  if (runs.length === 0) {
    return (
      <EmptyState title="No runs yet">
        The strategy worker starts a run when a deployment is enabled and records its health here.
      </EmptyState>
    );
  }
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Started</TableHead>
          <TableHead>Workspace</TableHead>
          {showStrategy ? <TableHead>Strategy</TableHead> : null}
          <TableHead>Status</TableHead>
          <TableHead>Heartbeat</TableHead>
          <TableHead className="text-right">Events</TableHead>
          <TableHead className="text-right">Candles</TableHead>
          <TableHead className="text-right">Signals</TableHead>
          <TableHead className="text-right">Failures</TableHead>
          <TableHead className="text-right">Timeouts</TableHead>
          <TableHead>Last error</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {runs.map((run) => (
          <TableRow key={run.id}>
            <TableCell className="text-xs whitespace-nowrap" title={`Run ${run.id}`}>
              {formatDateTime(run.started_at)}
            </TableCell>
            <TableCell className="text-xs">
              <Link
                href={`/workspaces/${encodeURIComponent(run.workspace_slug)}`}
                className="underline-offset-2 hover:underline"
              >
                {run.workspace_slug}
              </Link>
              <span
                className="block font-mono text-muted-foreground"
                title={`Configuration ${run.config_hash} · code ${run.code_fingerprint ?? "not recorded"}`}
              >
                {`v${run.strategy_version} · ${run.config_hash.slice(0, 8)}`}
              </span>
            </TableCell>
            {showStrategy ? <TableCell className="font-mono text-xs">{run.strategy_id}</TableCell> : null}
            <TableCell>
              <RunStatusBadge run={run} />
            </TableCell>
            <TableCell className="text-xs whitespace-nowrap">
              {run.stopped_at ? (
                <span title={formatDateTime(run.stopped_at)}>{`Stopped ${formatAge(run.stopped_at, now)}`}</span>
              ) : (
                <span title={`Worker ${run.worker_id}`}>
                  {formatAge(run.heartbeat_at ?? run.started_at, now)}
                </span>
              )}
              {run.status === "CIRCUIT_OPEN" && run.circuit_opened_at ? (
                <span className="block text-amber-200">{`Circuit opened ${formatAge(run.circuit_opened_at, now)}`}</span>
              ) : null}
            </TableCell>
            <Count value={run.events_processed} />
            <Count value={run.candles_processed} />
            <Count value={run.signals_emitted} />
            <Count value={run.failures} warn />
            <Count value={run.timeouts} warn />
            <TableCell className="text-xs">
              <RunError error={run.last_error} />
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
