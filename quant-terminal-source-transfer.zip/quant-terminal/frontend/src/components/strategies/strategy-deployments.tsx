"use client";

import { useQuery } from "@tanstack/react-query";
import { useId, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { NativeSelect } from "@/components/ui/input";
import { deployments as deploymentsApi, workspaces as workspacesApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { DeploymentView, StrategyView } from "@/lib/api/types.gen";
import { strategyRequirements, supportsMarket } from "@/lib/strategies";
import { ConfigurationsTable } from "./configurations-table";
import { DeploymentDialog } from "./deployment-dialog";
import { MONITORING_POLL_MS } from "./monitoring";

interface EditTarget {
  slug: string;
  /** Null for a new configuration. */
  deployment: DeploymentView | null;
}

/** Loads the workspace universe that the configuration dialog picks instruments from. */
function ConfigurationEditor({
  strategy,
  target,
  onClose,
}: {
  strategy: StrategyView;
  target: EditTarget;
  onClose: () => void;
}) {
  const universe = useQuery({
    queryKey: queryKeys.universe(target.slug),
    queryFn: () => workspacesApi.universe(target.slug),
  });
  if (universe.data) {
    return (
      <DeploymentDialog
        slug={target.slug}
        strategy={strategy}
        deployment={target.deployment}
        entries={universe.data.entries}
        onClose={onClose}
      />
    );
  }
  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{target.deployment ? `Edit ${target.deployment.label}` : `New configuration of ${strategy.name}`}</DialogTitle>
          <DialogDescription>{`Workspace ${target.slug}`}</DialogDescription>
        </DialogHeader>
        {universe.isError ? (
          <ErrorState
            error={universe.error}
            title="Could not load the workspace universe"
            onRetry={() => void universe.refetch()}
          />
        ) : (
          <LoadingState label="Loading the workspace universe…" />
        )}
      </DialogContent>
    </Dialog>
  );
}

/** A strategy's saved configurations across workspaces, with their live monitoring. */
export function StrategyDeployments({ strategy }: { strategy: StrategyView }) {
  const pickerId = useId();
  const [target, setTarget] = useState<EditTarget | null>(null);
  const [choice, setChoice] = useState("");
  const filters = { strategy_id: strategy.strategy_id };
  const deployments = useQuery({
    queryKey: queryKeys.deployments(filters),
    queryFn: () => deploymentsApi.list(filters),
    refetchInterval: MONITORING_POLL_MS,
  });
  const workspaces = useQuery({ queryKey: queryKeys.workspaces, queryFn: workspacesApi.list });

  const requirements = strategyRequirements(strategy.metadata);
  // A workspace can hold several configurations of the same strategy, so none is excluded.
  const candidates = (workspaces.data ?? []).filter((workspace) => supportsMarket(requirements, workspace.market_region));
  const catalogue = useMemo(() => new Map([[strategy.strategy_id, strategy]]), [strategy]);
  const placeholder = !strategy.is_available
    ? "Not in the code"
    : !workspaces.isSuccess
      ? "Loading workspaces…"
      : candidates.length === 0
        ? "No eligible workspace"
        : "Choose a workspace…";
  const close = () => {
    setTarget(null);
    setChoice("");
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <label htmlFor={pickerId} className="text-xs text-muted-foreground">
          New configuration in
        </label>
        <NativeSelect
          id={pickerId}
          className="h-8 w-56 text-xs"
          value={choice}
          onChange={(event) => setChoice(event.target.value)}
          disabled={!strategy.is_available || candidates.length === 0}
        >
          <option value="">{placeholder}</option>
          {candidates.map((workspace) => (
            <option key={workspace.slug} value={workspace.slug}>
              {`${workspace.name} (${workspace.market_region})`}
            </option>
          ))}
        </NativeSelect>
        <Button
          size="sm"
          disabled={!strategy.is_available || !candidates.some((workspace) => workspace.slug === choice)}
          onClick={() => setTarget({ slug: choice, deployment: null })}
        >
          New configuration…
        </Button>
        {requirements.markets.length > 0 ? (
          <span className="text-xs text-muted-foreground">{`Supports ${requirements.markets.join(", ")} workspaces`}</span>
        ) : null}
      </div>
      {deployments.isPending ? (
        <LoadingState />
      ) : deployments.isError ? (
        <ErrorState error={deployments.error} onRetry={() => void deployments.refetch()} />
      ) : deployments.data.length === 0 ? (
        <EmptyState title="No saved configurations">
          Save one in a workspace above, or from the Strategy panel beside a chart. Saving starts nothing: enabling live
          signals is a separate step.
        </EmptyState>
      ) : (
        <ConfigurationsTable
          deployments={deployments.data}
          strategies={catalogue}
          showWorkspace
          onEdit={(_strategy, deployment) => setTarget({ slug: deployment.workspace_slug, deployment })}
        />
      )}
      {target ? (
        <ConfigurationEditor
          key={`${target.slug}:${target.deployment?.id ?? "new"}`}
          strategy={strategy}
          target={target}
          onClose={close}
        />
      ) : null}
    </div>
  );
}
