"use client";

import { useMemo } from "react";
import { SignalTypeBadge } from "@/components/signals/signal-badges";
import { Badge } from "@/components/ui/badge";
import { CodeList, DetailList, DetailRow } from "@/components/ui/details";
import { EmptyState } from "@/components/ui/feedback";
import { JsonBlock } from "@/components/ui/stat";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { StrategyView } from "@/lib/api/types.gen";
import { formatInteger, humanize, segmentLabel } from "@/lib/format";
import { schemaFields } from "@/lib/schema-form";
import { SIGNAL_TYPES } from "@/lib/signal-filters";
import {
  type SignalConditionInfo,
  fieldConstraint,
  formatConfigValue,
  formatParams,
  strategyRequirements,
} from "@/lib/strategies";

/** When the strategy proposes each signal type, as it declares, and the inputs that decide it. */
export function SignalConditionsList({ conditions }: { conditions: readonly SignalConditionInfo[] }) {
  if (conditions.length === 0) {
    return <span className="text-muted-foreground">None declared, so it proposes no signals</span>;
  }
  return (
    <ul className="flex flex-col gap-2">
      {conditions.map((condition, index) => {
        const known = SIGNAL_TYPES.find((type) => type === condition.signalType);
        return (
          <li key={`${condition.signalType}-${index}`} className="flex flex-col gap-1">
            <span className="flex flex-wrap items-center gap-1">
              {known ? <SignalTypeBadge type={known} /> : <Badge variant="outline">{condition.signalType}</Badge>}
              {condition.inputs.map((input) => (
                <Badge key={input} variant="outline" className="font-mono" title="An input that decides it">
                  {input}
                </Badge>
              ))}
            </span>
            <span>{condition.description || "No description"}</span>
          </li>
        );
      })}
    </ul>
  );
}

/** What the strategy needs from the platform: markets, instruments, timeframes, data and indicators. */
export function StrategyRequirementsList({
  metadata,
  showConditions = true,
}: {
  metadata: Record<string, unknown>;
  /** False where the signal conditions are shown separately. */
  showConditions?: boolean;
}) {
  const needs = useMemo(() => strategyRequirements(metadata), [metadata]);
  return (
    <DetailList>
      <DetailRow label="Markets">
        <CodeList values={needs.markets} empty="None, so no workspace can use it" />
      </DetailRow>
      <DetailRow label="Exchanges">
        <CodeList values={needs.exchanges} empty="Every exchange of its markets" />
      </DetailRow>
      <DetailRow label="Segments">
        <CodeList values={needs.segments} format={segmentLabel} />
      </DetailRow>
      <DetailRow label="Instrument types">
        <CodeList values={needs.instrumentTypes} format={humanize} />
      </DetailRow>
      <DetailRow label="Instruments">
        <CodeList values={needs.instrumentKeys} empty="Every instrument of those markets, segments and types" />
      </DetailRow>
      <DetailRow label="Candle intervals">
        <CodeList values={needs.candleIntervals} />
      </DetailRow>
      <DetailRow label="Required data">
        <CodeList values={needs.requiredData} format={humanize} empty="Prices only" />
      </DetailRow>
      <DetailRow label="Event types">
        <CodeList values={needs.eventTypes} format={humanize} />
      </DetailRow>
      <DetailRow label="Indicators">
        {needs.indicators.length === 0 ? (
          <span className="text-muted-foreground">None</span>
        ) : (
          <ul className="flex flex-col gap-0.5 font-mono">
            {needs.indicators.map((need) => {
              const params = formatParams(need.params);
              return (
                <li key={need.alias}>
                  {`${need.alias}: ${need.indicator}${params ? `(${params})` : ""}`}
                  {need.interval ? <span className="text-muted-foreground">{` on ${need.interval}`}</span> : null}
                </li>
              );
            })}
          </ul>
        )}
      </DetailRow>
      <DetailRow label="Warm-up">
        {needs.warmupCandles > 0 ? `${formatInteger(needs.warmupCandles)} candles` : "None"}
      </DetailRow>
      <DetailRow label="Candles">
        {needs.usesPartialCandles ? "Closed and still-forming candles" : "Closed candles only"}
      </DetailRow>
      <DetailRow label="Resource profile">{needs.resourceProfile ? humanize(needs.resourceProfile) : "—"}</DetailRow>
      <DetailRow label="Risk profile">{needs.riskProfile ?? "—"}</DetailRow>
      {showConditions ? (
        <DetailRow label="Signal conditions">
          <SignalConditionsList conditions={needs.signalConditions} />
        </DetailRow>
      ) : null}
    </DetailList>
  );
}

/** The strategy's settings as its configuration schema declares them, with their defaults. */
export function ConfigSchemaTable({ strategy }: { strategy: StrategyView }) {
  const fields = useMemo(() => schemaFields(strategy.config_schema), [strategy.config_schema]);
  const defaults = strategy.default_config;
  return (
    <div className="flex flex-col gap-2">
      {fields.length === 0 ? (
        <EmptyState title="No settings">This strategy runs without configuration.</EmptyState>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Setting</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Default</TableHead>
              <TableHead>Accepts</TableHead>
              <TableHead>Description</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {fields.map((field) => {
              const fallback = Object.hasOwn(defaults, field.name) ? defaults[field.name] : field.defaultValue;
              return (
                <TableRow key={field.name}>
                  <TableCell>
                    <span className="font-medium">{field.label}</span>
                    <span className="block font-mono text-xs text-muted-foreground">{field.name}</span>
                  </TableCell>
                  <TableCell className="text-xs">{humanize(field.kind)}</TableCell>
                  <TableCell className="max-w-48 truncate font-mono text-xs" title={formatConfigValue(fallback)}>
                    {formatConfigValue(fallback)}
                  </TableCell>
                  <TableCell className="text-xs">
                    {[field.required ? "Required" : null, fieldConstraint(field) || null]
                      .filter((part) => part !== null)
                      .join(" · ") || "—"}
                  </TableCell>
                  <TableCell className="max-w-md text-xs text-muted-foreground">{field.description ?? "—"}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      )}
      <details>
        <summary className="cursor-pointer text-xs text-muted-foreground">Raw schema and defaults</summary>
        <div className="mt-2 grid gap-2 lg:grid-cols-2">
          <JsonBlock value={strategy.config_schema} />
          <JsonBlock value={strategy.default_config} />
        </div>
      </details>
    </div>
  );
}
