"use client";

import { useState } from "react";
import { Badge, type BadgeVariant } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DetailList, DetailRow } from "@/components/ui/details";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Spinner } from "@/components/ui/feedback";
import { deployments as deploymentsApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type { DeploymentView, Monitoring, MonitoringState } from "@/lib/api/types.gen";
import { formatInteger } from "@/lib/format";
import { formatConfigValue, scopeSummary, type ScopeContext } from "@/lib/strategies";
import { cn, errorMessage } from "@/lib/utils";

/** The queries a change to a saved configuration can affect, including whether its backtests are outdated. */
export const CONFIGURATION_QUERIES = [["deployments"], queryKeys.strategies, ["strategy-runs"], ["backtests"]] as const;

/** How often lists of saved configurations refresh their monitoring state. */
export const MONITORING_POLL_MS = 15_000;

const MONITORING: Record<MonitoringState, { label: string; variant: BadgeVariant; help: string }> = {
  STOPPED: { label: "Stopped", variant: "secondary", help: "Live signals are off: nothing monitors this configuration." },
  STARTING: {
    label: "Starting",
    variant: "info",
    help: "Live signals are on and the strategy worker is starting a run of the current settings.",
  },
  WARMING_UP: {
    label: "Warming up",
    variant: "info",
    help: "Running, but some instruments still lack the closed candles the strategy needs.",
  },
  RUNNING: { label: "Running", variant: "success", help: "The strategy worker monitors it on the server." },
  BLOCKED: { label: "Blocked", variant: "destructive", help: "Live signals are on but blocked; see the reasons." },
  FAILED: {
    label: "Failed",
    variant: "destructive",
    help: "Live signals are on, but the run failed or the strategy worker is not reporting; see the reasons.",
  },
};

/** The live-monitoring state of a saved configuration. */
export function MonitoringBadge({ monitoring }: { monitoring: Monitoring | null }) {
  if (monitoring === null) {
    return (
      <Badge variant="outline" title="The server did not report a monitoring state">
        Unknown
      </Badge>
    );
  }
  const { label, variant, help } = MONITORING[monitoring.state];
  return (
    <Badge variant={variant} title={help}>
      {label}
    </Badge>
  );
}

/** Why monitoring is not running, how far its warm-up is, and what limits it. */
export function MonitoringNotes({ monitoring, className }: { monitoring: Monitoring | null; className?: string }) {
  if (monitoring === null) return null;
  const serious = monitoring.state === "BLOCKED" || monitoring.state === "FAILED";
  const remaining = Object.entries(monitoring.warmup?.remaining ?? {}).filter(([, candles]) => candles > 0);
  if (monitoring.reasons.length === 0 && monitoring.warnings.length === 0 && remaining.length === 0) return null;
  return (
    <ul className={cn("flex flex-col gap-0.5 text-xs", className)}>
      {monitoring.reasons.map((reason) => (
        <li key={`reason:${reason}`} className={serious ? "text-red-300" : "text-muted-foreground"}>
          {reason}
        </li>
      ))}
      {remaining.length > 0 ? (
        <li className="text-muted-foreground">
          {`Warm-up still needs up to ${remaining
            .map(([interval, candles]) => `${formatInteger(candles)} × ${interval}`)
            .join(", ")} closed candles.`}
        </li>
      ) : null}
      {monitoring.warnings.map((warning) => (
        <li key={`warning:${warning}`} className="text-amber-200">
          {warning}
        </li>
      ))}
    </ul>
  );
}

/** Asks before turning live signals on, saying what will be monitored and that it outlives the chart. */
export function EnableLiveSignalsDialog({
  deployment,
  strategyName,
  context,
  onClose,
}: {
  deployment: DeploymentView;
  strategyName?: string;
  context?: ScopeContext;
  onClose: () => void;
}) {
  const enable = useApiMutation({
    mutationFn: () => deploymentsApi.enable(deployment.id),
    invalidate: CONFIGURATION_QUERIES,
    success: (view) => `Live signals on for ${view.label}`,
    errorTitle: `Could not enable live signals for ${deployment.label}`,
    onSuccess: onClose,
  });
  const before = deployment.monitoring?.state === "STOPPED" ? deployment.monitoring.warnings : [];
  const settings = Object.entries(deployment.config);
  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{`Enable live signals for ${deployment.label}?`}</DialogTitle>
          <DialogDescription>The strategy worker starts monitoring this saved configuration on the server.</DialogDescription>
        </DialogHeader>
        <DetailList>
          <DetailRow label="Strategy">{`${strategyName ?? deployment.strategy_id} v${deployment.strategy_version}`}</DetailRow>
          <DetailRow label="Workspace">{deployment.workspace_slug}</DetailRow>
          <DetailRow label="Instruments">
            {deployment.scope_kind === "WORKSPACE"
              ? "Whole workspace, including instruments added to it later"
              : scopeSummary(deployment, context)}
          </DetailRow>
          <DetailRow label="Settings">
            {settings.length === 0 ? (
              "None"
            ) : (
              <span className="font-mono">
                {settings.map(([name, value]) => `${name}=${formatConfigValue(value)}`).join(", ")}
              </span>
            )}
          </DetailRow>
        </DetailList>
        <ul className="flex list-disc flex-col gap-1 pl-4 text-xs text-muted-foreground">
          <li>
            Monitoring runs on the server, not in this browser: it carries on after you close the chart or the browser,
            until you stop live signals.
          </li>
          <li>
            Every signal still goes through the risk rules, data freshness included. Blocked signals are kept with their
            reasons.
          </li>
          <li>Signals are information only: nothing here places orders.</li>
        </ul>
        {before.length > 0 ? (
          <div className="rounded-md border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-200">
            <p className="font-medium">Before you enable</p>
            <ul className="mt-1 flex list-disc flex-col gap-0.5 pl-4">
              {before.map((warning) => (
                <li key={warning}>{warning}</li>
              ))}
            </ul>
          </div>
        ) : null}
        {enable.isError ? (
          <p role="alert" className="text-xs text-red-300">
            {errorMessage(enable.error)}
          </p>
        ) : null}
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={enable.isPending} onClick={() => enable.mutate()}>
            {enable.isPending ? <Spinner /> : null}
            Enable live signals
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** "Enable live signals…" (asks first) or "Stop live signals" (at once), as the configuration stands. */
export function LiveSignalsControl({
  deployment,
  strategyName,
  context,
}: {
  deployment: DeploymentView;
  strategyName?: string;
  context?: ScopeContext;
}) {
  const [confirming, setConfirming] = useState(false);
  const stop = useApiMutation({
    mutationFn: () => deploymentsApi.disable(deployment.id),
    invalidate: CONFIGURATION_QUERIES,
    success: (view) => `Live signals stopped for ${view.label}`,
    errorTitle: `Could not stop live signals for ${deployment.label}`,
  });
  if (deployment.archived_at !== null) return null;
  if (deployment.is_enabled) {
    return (
      <Button
        size="sm"
        variant="outline"
        disabled={stop.isPending}
        aria-label={`Stop live signals for ${deployment.label}`}
        onClick={() => stop.mutate()}
      >
        {stop.isPending ? <Spinner /> : null}
        Stop live signals
      </Button>
    );
  }
  return (
    <>
      <Button size="sm" aria-label={`Enable live signals for ${deployment.label}`} onClick={() => setConfirming(true)}>
        Enable live signals…
      </Button>
      {confirming ? (
        <EnableLiveSignalsDialog
          deployment={deployment}
          strategyName={strategyName}
          context={context}
          onClose={() => setConfirming(false)}
        />
      ) : null}
    </>
  );
}

/** Archives a configuration whose live signals are off, after asking; nothing while they are on. */
export function ArchiveConfigurationButton({ deployment }: { deployment: DeploymentView }) {
  const [open, setOpen] = useState(false);
  const archive = useApiMutation({
    mutationFn: () => deploymentsApi.archive(deployment.id),
    invalidate: CONFIGURATION_QUERIES,
    success: (view) => `${view.label} archived`,
    errorTitle: `Could not archive ${deployment.label}`,
    onSuccess: () => setOpen(false),
  });
  if (deployment.archived_at !== null || deployment.is_enabled) return null;
  return (
    <>
      <Button size="sm" variant="ghost" aria-label={`Archive ${deployment.label}`} onClick={() => setOpen(true)}>
        Archive
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{`Archive ${deployment.label}?`}</DialogTitle>
            <DialogDescription>
              It leaves the lists and frees its name; its runs and signals stay in the history. An archived
              configuration cannot be edited or enabled again: save a new one instead.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" disabled={archive.isPending} onClick={() => archive.mutate()}>
              {archive.isPending ? <Spinner /> : null}
              Archive
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
