"use client";

import { useQuery } from "@tanstack/react-query";
import { Check, RefreshCw } from "lucide-react";
import { useId, useMemo, useState } from "react";
import { BacktestHistoryDialog } from "@/components/backtests/backtest-history";
import { BacktestResultsDialog } from "@/components/backtests/backtest-results";
import {
  type BacktestDialogRequest,
  LatestBacktestSummary,
  latestBacktestQuery,
} from "@/components/backtests/latest-backtest";
import { RunBacktestDialog } from "@/components/backtests/run-backtest-dialog";
import { TradeRulesDialog } from "@/components/backtests/trade-rules-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { deployments as deploymentsApi, strategies as strategiesApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type {
  CandleInterval,
  CheckStatus,
  CompatibilityAspect,
  CompatibilityCheck,
  DeploymentView,
  StrategyCompatibility,
  StrategyView,
  UniverseEntry,
} from "@/lib/api/types.gen";
import { formatInteger } from "@/lib/format";
import { notify } from "@/lib/notifications";
import {
  type ScopeContext,
  appliedOverlays,
  compatibilityVerdict,
  formatConfigValue,
  scopeSummary,
  strategyRequirements,
  syncSummary,
} from "@/lib/strategies";
import { cn } from "@/lib/utils";
import { type ConfigurationTarget, DeploymentDialog } from "./deployment-dialog";
import {
  ArchiveConfigurationButton,
  LiveSignalsControl,
  MONITORING_POLL_MS,
  MonitoringBadge,
  MonitoringNotes,
} from "./monitoring";
import { SignalConditionsList, StrategyRequirementsList } from "./strategy-detail";

// Stored warm-up candles grow as the market trades, so the coverage is refreshed now and then.
const COMPATIBILITY_POLL_MS = 60_000;

const ASPECTS: Record<CompatibilityAspect, string> = {
  MARKET: "Market",
  INSTRUMENT: "Instrument",
  TIMEFRAME: "Timeframe",
  DATA: "Data",
  WARMUP: "Warm-up",
};

const CHECK_STATUS: Record<CheckStatus, { glyph: string; word: string; className: string }> = {
  PASSED: { glyph: "✓", word: "passed", className: "text-emerald-300" },
  WARNING: { glyph: "!", word: "warning", className: "text-amber-200" },
  FAILED: { glyph: "✕", word: "failed", className: "text-red-300" },
};

/** Whether the catalogue holds the version the code has, so its settings form matches the code. */
type CatalogueState = "current" | "missing" | "outdated";

function catalogueState(compatibility: StrategyCompatibility, strategy: StrategyView | undefined): CatalogueState {
  if (strategy === undefined) return "missing";
  return strategy.is_available && strategy.version === compatibility.version ? "current" : "outdated";
}

function CheckGlyph({ status }: { status: CheckStatus }) {
  const { glyph, className } = CHECK_STATUS[status];
  return (
    <span aria-hidden className={cn("inline-block w-3 shrink-0 text-center font-semibold", className)}>
      {glyph}
    </span>
  );
}

/** One line per aspect: market, instrument, timeframe, data and warm-up. */
function CheckSummary({ checks }: { checks: readonly CompatibilityCheck[] }) {
  return (
    <span className="flex flex-wrap gap-x-3 gap-y-0.5 text-xs">
      {checks.map((check) => (
        <span key={check.aspect} className="flex items-center gap-1">
          <CheckGlyph status={check.status} />
          {ASPECTS[check.aspect]}
          <span className="sr-only">{` ${CHECK_STATUS[check.status].word}`}</span>
        </span>
      ))}
    </span>
  );
}

function StrategyItem({
  compatibility,
  strategy,
  expanded,
  onToggle,
  onCreate,
}: {
  compatibility: StrategyCompatibility;
  /** Its catalogue entry, if the catalogue has one. */
  strategy: StrategyView | undefined;
  expanded: boolean;
  onToggle: () => void;
  onCreate: (strategy: StrategyView) => void;
}) {
  const detailsId = useId();
  const verdict = compatibilityVerdict(compatibility);
  const state = catalogueState(compatibility, strategy);
  const current = state === "current" ? strategy : undefined;
  const conditions = useMemo(
    () => (current ? strategyRequirements(current.metadata).signalConditions : []),
    [current],
  );
  const failed = compatibility.checks.filter((check) => check.status === "FAILED");
  const createBlocked = !compatibility.compatible
    ? `Not compatible with this instrument: ${failed.map((check) => check.detail).join("; ") || "see the checks"}.`
    : current === undefined
      ? `The catalogue does not have v${compatibility.version} yet. Sync it first, so the settings form matches the code.`
      : null;
  return (
    <li className="rounded-md border">
      <button
        type="button"
        aria-expanded={expanded}
        aria-controls={detailsId}
        onClick={onToggle}
        className="flex w-full flex-col gap-1 rounded-md px-3 py-2 text-left transition-colors hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring/60 focus-visible:outline-none"
      >
        <span className="flex items-center gap-2">
          <span className="truncate text-sm font-medium">{strategy?.name ?? compatibility.strategy_id}</span>
          <span className="ml-auto shrink-0 font-mono text-xs text-muted-foreground">{`v${compatibility.version}`}</span>
        </span>
        {strategy && !expanded ? (
          <span className="line-clamp-2 text-xs text-muted-foreground">{strategy.description}</span>
        ) : null}
        <span className="flex flex-wrap items-center gap-1">
          <Badge variant={verdict.tone}>{verdict.label}</Badge>
          {state === "missing" ? (
            <Badge variant="warning" title="The code has it but the catalogue does not yet">
              Not catalogued
            </Badge>
          ) : state === "outdated" ? (
            <Badge variant="warning" title={`The catalogue has v${strategy?.version ?? "?"}; the code has v${compatibility.version}`}>
              Catalogue outdated
            </Badge>
          ) : null}
        </span>
        <CheckSummary checks={compatibility.checks} />
      </button>
      {expanded ? (
        <div id={detailsId} className="flex flex-col gap-3 border-t px-3 py-2 text-xs">
          <p className="font-mono text-muted-foreground">{compatibility.strategy_id}</p>
          {strategy ? <p>{strategy.description}</p> : null}
          <section className="flex flex-col gap-1" aria-label="Compatibility checks">
            <h4 className="font-medium">With this instrument</h4>
            <ul className="flex flex-col gap-1">
              {compatibility.checks.map((check) => (
                <li key={check.aspect} className="flex gap-2">
                  <CheckGlyph status={check.status} />
                  <span>
                    <span className="font-medium">{ASPECTS[check.aspect]}</span>
                    <span className="sr-only">{` ${CHECK_STATUS[check.status].word}`}</span>
                    {`: ${check.detail}`}
                  </span>
                </li>
              ))}
            </ul>
            {compatibility.warmup.length > 0 ? (
              <p className="text-muted-foreground">
                {`Closed candles stored for its warm-up: ${compatibility.warmup
                  .map((item) => `${item.interval} ${formatInteger(item.stored)} of ${formatInteger(item.needed)}`)
                  .join(", ")}.`}
              </p>
            ) : null}
          </section>
          <section className="flex flex-col gap-1" aria-label="Signal conditions">
            <h4 className="font-medium">Signal conditions</h4>
            {current ? (
              <SignalConditionsList conditions={conditions} />
            ) : (
              <p className="text-muted-foreground">Sync the catalogue to see this version&apos;s conditions.</p>
            )}
          </section>
          {current ? (
            <details>
              <summary className="cursor-pointer text-muted-foreground">Everything it needs</summary>
              <div className="mt-2">
                <StrategyRequirementsList metadata={current.metadata} showConditions={false} />
              </div>
            </details>
          ) : null}
          <div className="flex flex-col gap-1">
            <div>
              <Button
                size="sm"
                disabled={current === undefined || !compatibility.compatible}
                onClick={() => {
                  if (current) onCreate(current);
                }}
              >
                New configuration…
              </Button>
            </div>
            <p className={createBlocked ? "text-amber-200" : "text-muted-foreground"}>
              {createBlocked ??
                "Saves its settings for this instrument, or the whole workspace if you choose so. Saving starts nothing."}
            </p>
          </div>
        </div>
      ) : null}
    </li>
  );
}

function ConfigurationItem({
  deployment,
  strategy,
  number,
  context,
  instrumentId,
  symbol,
  editBlocked,
  onToggleApplied,
  onEdit,
}: {
  deployment: DeploymentView;
  strategy: StrategyView | undefined;
  /** Its number on the chart while applied there; null otherwise. */
  number: number | null;
  context: ScopeContext;
  /** The chart's instrument, which its backtests replay. */
  instrumentId: string;
  symbol: string;
  /** Why it cannot be edited now; null if it can. */
  editBlocked: string | null;
  onToggleApplied: () => void;
  onEdit: () => void;
}) {
  const applied = number !== null;
  const settings = Object.entries(deployment.config);
  const latest = useQuery(latestBacktestQuery(deployment.id, instrumentId));
  const [dialog, setDialog] = useState<BacktestDialogRequest | null>(null);
  const close = () => setDialog(null);
  return (
    <li className="flex flex-col gap-2 rounded-md border px-3 py-2" aria-label={`Configuration ${deployment.label}`}>
      <div className="flex items-start gap-2">
        {applied ? (
          <span
            className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground"
            title={`Its chart markers carry the number ${number}`}
          >
            {number}
          </span>
        ) : null}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium" title={deployment.label}>
            {deployment.label}
          </p>
          <p className="text-xs text-muted-foreground">
            {`${strategy?.name ?? deployment.strategy_id} · v${deployment.strategy_version} · ${scopeSummary(deployment, context)}`}
          </p>
        </div>
        <MonitoringBadge monitoring={deployment.monitoring} />
      </div>
      <p className="font-mono text-xs break-all text-muted-foreground">
        {settings.length === 0
          ? "No settings"
          : settings.map(([name, value]) => `${name}=${formatConfigValue(value)}`).join(", ")}
      </p>
      <LatestBacktestSummary query={latest} symbol={symbol} onOpen={setDialog} />
      <MonitoringNotes monitoring={deployment.monitoring} />
      <div className="flex flex-wrap items-center gap-2">
        <Button
          size="sm"
          variant={applied ? "secondary" : "outline"}
          aria-pressed={applied}
          aria-label={`Apply ${deployment.label} to the chart`}
          title="Shows its stored signals and its current backtest's trades for this instrument on the chart. It starts nothing."
          onClick={onToggleApplied}
        >
          {applied ? <Check aria-hidden /> : null}
          Apply to chart
        </Button>
        <Button
          size="sm"
          variant="outline"
          aria-label={`Run a backtest of ${deployment.label}`}
          title="Replays stored candles on the backtest worker. It does not start live signals."
          onClick={() => setDialog({ kind: "run" })}
        >
          Run backtest…
        </Button>
        <LiveSignalsControl deployment={deployment} strategyName={strategy?.name} context={context} />
        <Button
          size="sm"
          variant="ghost"
          disabled={editBlocked !== null}
          title={editBlocked ?? undefined}
          aria-label={`Edit ${deployment.label}`}
          onClick={onEdit}
        >
          Edit…
        </Button>
        <ArchiveConfigurationButton deployment={deployment} />
      </div>
      {editBlocked ? <p className="text-xs text-muted-foreground">{editBlocked}</p> : null}
      {dialog?.kind === "run" ? (
        <RunBacktestDialog
          deployment={deployment}
          instrumentId={instrumentId}
          symbol={symbol}
          onClose={close}
          onOpenResults={(runId) => setDialog({ kind: "results", runId })}
        />
      ) : null}
      {dialog?.kind === "rules" ? <TradeRulesDialog deployment={deployment} onClose={close} /> : null}
      {dialog?.kind === "results" ? <BacktestResultsDialog runId={dialog.runId} onClose={close} /> : null}
      {dialog?.kind === "history" ? (
        <BacktestHistoryDialog deployment={deployment} instrumentId={instrumentId} symbol={symbol} onClose={close} />
      ) : null}
    </li>
  );
}

/**
 * The strategies beside a chart: the saved configurations that cover its instrument, and every strategy in
 * the code with how it suits the instrument. Opening it or choosing a strategy starts nothing.
 */
export function StrategyPanel({
  slug,
  entries,
  entry,
  chartInterval,
  applied,
  onToggleApplied,
}: {
  slug: string;
  /** The workspace universe, for the instrument picker and symbols. */
  entries: readonly UniverseEntry[];
  /** The chart's instrument. */
  entry: UniverseEntry;
  chartInterval: CandleInterval;
  /** The configurations applied to this instrument's chart, in the order they were applied. */
  applied: readonly string[];
  onToggleApplied: (deploymentId: string) => void;
}) {
  const instrument = entry.instrument;
  const [expanded, setExpanded] = useState<string | null>(null);
  const [target, setTarget] = useState<ConfigurationTarget | null>(null);

  const filters = { workspace: slug, instrument_id: instrument.id };
  const configurations = useQuery({
    queryKey: queryKeys.deployments(filters),
    queryFn: () => deploymentsApi.list(filters),
    refetchInterval: MONITORING_POLL_MS,
  });
  const params = { workspace: slug, instrument_id: instrument.id, chart_interval: chartInterval };
  const compatibility = useQuery({
    queryKey: queryKeys.compatibility(params),
    queryFn: () => strategiesApi.compatibility(params),
    refetchInterval: COMPATIBILITY_POLL_MS,
  });
  const catalogue = useQuery({ queryKey: queryKeys.strategies, queryFn: strategiesApi.list });
  const sync = useApiMutation({
    mutationFn: () => strategiesApi.sync(),
    invalidate: [queryKeys.strategies, ["deployments"], ["backtests"]],
    success: null,
    errorTitle: "Could not sync the catalogue",
    onSuccess: (result) => notify("success", "Catalogue synced", syncSummary(result)),
  });

  const byId = useMemo(
    () => new Map((catalogue.data ?? []).map((strategy) => [strategy.strategy_id, strategy])),
    [catalogue.data],
  );
  const context = useMemo<ScopeContext>(() => {
    const symbols = new Map(entries.map((item) => [item.instrument.id, item.instrument.symbol]));
    return { instrumentId: instrument.id, symbolOf: (id) => symbols.get(id) };
  }, [entries, instrument.id]);

  const codeStrategies = compatibility.data?.strategies ?? [];
  const codeVersions = new Map(codeStrategies.map((item) => [item.strategy_id, item.version]));
  const sorted = [...codeStrategies].sort(
    (a, b) =>
      Number(b.compatible) - Number(a.compatible) ||
      (byId.get(a.strategy_id)?.name ?? a.strategy_id).localeCompare(byId.get(b.strategy_id)?.name ?? b.strategy_id),
  );
  const unsynced = catalogue.isSuccess
    ? codeStrategies.filter((item) => catalogueState(item, byId.get(item.strategy_id)) !== "current")
    : [];
  const numbers = new Map(
    appliedOverlays(applied, configurations.data ?? []).map((overlay) => [overlay.deployment.id, overlay.number]),
  );

  const editBlocked = (deployment: DeploymentView): string | null => {
    const strategy = byId.get(deployment.strategy_id);
    if (catalogue.isError) return "The catalogue did not load, so its settings form is unavailable.";
    if (!catalogue.isSuccess) return "Loading the catalogue…";
    if (strategy === undefined) return "Its strategy is not in the catalogue.";
    if (!strategy.is_available) return "Its strategy is no longer in the code, so it cannot be edited.";
    const code = codeVersions.get(deployment.strategy_id);
    if (code !== undefined && code !== strategy.version) {
      return `The catalogue does not have v${code} yet. Sync it before editing.`;
    }
    return null;
  };

  return (
    <Card aria-label="Strategy panel">
      <CardHeader
        title={`Strategies · ${instrument.symbol}`}
        description={`On the ${chartInterval} chart. Choosing a strategy or saving a configuration starts nothing: live signals start only when you enable them.`}
      />
      <CardContent className="flex flex-col gap-4">
        <section className="flex flex-col gap-2" aria-label="Saved configurations for this instrument">
          <h3 className="text-sm font-medium">Saved configurations</h3>
          {configurations.isPending ? (
            <LoadingState />
          ) : configurations.isError ? (
            <ErrorState error={configurations.error} onRetry={() => void configurations.refetch()} />
          ) : configurations.data.length === 0 ? (
            <EmptyState title={`None covers ${instrument.symbol}`}>
              Pick a strategy below and save a configuration. Configurations for other instruments are in the
              Strategies tab.
            </EmptyState>
          ) : (
            <ul className="flex flex-col gap-2">
              {configurations.data.map((deployment) => {
                const strategy = byId.get(deployment.strategy_id);
                return (
                  <ConfigurationItem
                    key={deployment.id}
                    deployment={deployment}
                    strategy={strategy}
                    number={numbers.get(deployment.id) ?? null}
                    context={context}
                    instrumentId={instrument.id}
                    symbol={instrument.symbol}
                    editBlocked={editBlocked(deployment)}
                    onToggleApplied={() => onToggleApplied(deployment.id)}
                    onEdit={() => {
                      if (strategy) setTarget({ strategy, deployment });
                    }}
                  />
                );
              })}
            </ul>
          )}
        </section>
        <section className="flex flex-col gap-2" aria-label="Strategies in the code">
          <h3 className="text-sm font-medium">Strategies</h3>
          {unsynced.length > 0 ? (
            <div className="flex flex-col gap-2 rounded-md border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-200">
              <p>
                {`The catalogue is behind the code for ${unsynced.map((item) => item.strategy_id).join(", ")}. Sync it to configure ${unsynced.length === 1 ? "it" : "them"}.`}
              </p>
              <div>
                <Button size="sm" variant="outline" disabled={sync.isPending} onClick={() => sync.mutate()}>
                  <RefreshCw aria-hidden className={cn(sync.isPending && "animate-spin")} />
                  Sync catalogue
                </Button>
              </div>
            </div>
          ) : null}
          {catalogue.isError ? (
            <ErrorState
              error={catalogue.error}
              title="Could not load the catalogue"
              onRetry={() => void catalogue.refetch()}
            />
          ) : compatibility.isPending || catalogue.isPending ? (
            <LoadingState label="Checking the strategies against this instrument…" />
          ) : compatibility.isError ? (
            <ErrorState error={compatibility.error} onRetry={() => void compatibility.refetch()} />
          ) : sorted.length === 0 ? (
            <EmptyState title="No strategies in the code">
              Register one in backend/app/strategies/custom (see docs/strategy-registration.md).
            </EmptyState>
          ) : (
            <ul className="flex flex-col gap-2">
              {sorted.map((item) => (
                <StrategyItem
                  key={item.strategy_id}
                  compatibility={item}
                  strategy={byId.get(item.strategy_id)}
                  expanded={expanded === item.strategy_id}
                  onToggle={() => setExpanded(expanded === item.strategy_id ? null : item.strategy_id)}
                  onCreate={(strategy) => setTarget({ strategy, deployment: null })}
                />
              ))}
            </ul>
          )}
        </section>
      </CardContent>
      {target ? (
        <DeploymentDialog
          key={`${target.strategy.strategy_id}:${target.deployment?.id ?? "new"}`}
          slug={slug}
          strategy={target.strategy}
          deployment={target.deployment}
          entries={entries}
          initialInstrumentIds={[instrument.id]}
          onClose={() => setTarget(null)}
        />
      ) : null}
    </Card>
  );
}
