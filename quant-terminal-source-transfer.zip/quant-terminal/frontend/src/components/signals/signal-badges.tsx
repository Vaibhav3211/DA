import { Badge, type BadgeVariant } from "@/components/ui/badge";
import type { RiskOutcome, SignalEventType, SignalStatus, SignalType } from "@/lib/api/types.gen";
import { humanize } from "@/lib/format";

const TYPE_VARIANT: Record<SignalType, BadgeVariant> = {
  BUY: "success",
  SELL: "destructive",
  EXIT: "warning",
  HOLD: "secondary",
  WATCH: "info",
  INVALIDATED: "outline",
};

const STATUS_VARIANT: Record<SignalStatus, BadgeVariant> = {
  GENERATED: "info",
  ACTIVE: "success",
  UPDATED: "info",
  INVALIDATED: "outline",
  EXPIRED: "outline",
  SUPERSEDED: "outline",
  CLOSED: "secondary",
  BLOCKED: "destructive",
};

export const OPEN_SIGNAL_STATUSES: readonly SignalStatus[] = ["GENERATED", "ACTIVE", "UPDATED"];

export function SignalTypeBadge({ type }: { type: SignalType }) {
  return <Badge variant={TYPE_VARIANT[type]}>{type}</Badge>;
}

export function SignalStatusBadge({ status }: { status: SignalStatus | SignalEventType }) {
  return <Badge variant={STATUS_VARIANT[status === "ACTIVATED" ? "ACTIVE" : status]}>{humanize(status)}</Badge>;
}

export function RiskOutcomeBadge({ outcome }: { outcome: RiskOutcome }) {
  return <Badge variant={outcome === "ALLOW" ? "success" : "destructive"}>Risk {outcome === "ALLOW" ? "allowed" : "blocked"}</Badge>;
}

export function ActionableBadge({ actionable }: { actionable: boolean }) {
  return actionable ? (
    <Badge variant="info" title="The strategy may emit actionable signals and the risk gate allowed this one">
      Actionable
    </Badge>
  ) : (
    <Badge variant="outline" title="For information only: do not act on it">
      Info only
    </Badge>
  );
}
