"use client";

import { useQuery } from "@tanstack/react-query";
import { CircleCheck, CircleX } from "lucide-react";
import type { ReactNode } from "react";
import { StatusBadge } from "@/components/status/status-badge";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ErrorState, LoadingState } from "@/components/ui/feedback";
import { JsonBlock, Stat, StatGrid } from "@/components/ui/stat";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { signals as signalsApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type {
  IndicatorValue,
  RiskDecision,
  RiskDecisionView,
  SignalConfiguration,
  SignalEventView,
  SignalView,
} from "@/lib/api/types.gen";
import { formatDateTime, formatPrice, formatTime, humanize } from "@/lib/format";
import { formatConfigValue } from "@/lib/strategies";
import { ActionableBadge, RiskOutcomeBadge, SignalStatusBadge, SignalTypeBadge } from "./signal-badges";

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="flex flex-col gap-2">
      <h3 className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">{title}</h3>
      {children}
    </section>
  );
}

function Indicators({ values }: { values: IndicatorValue[] }) {
  if (values.length === 0) return <p className="text-sm text-muted-foreground">The strategy recorded no indicators.</p>;
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Indicator</TableHead>
          <TableHead className="text-right">Value</TableHead>
          <TableHead>Input candles</TableHead>
          <TableHead>Data</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {values.map((value) => (
          <TableRow key={value.name}>
            <TableCell>
              <span className="font-medium">{value.name}</span>
              <span className="ml-1 text-xs text-muted-foreground" title={JSON.stringify(value.params)}>
                {value.indicator} v{value.version}
              </span>
            </TableCell>
            <TableCell className="text-right font-mono">{value.value ?? "—"}</TableCell>
            <TableCell className="text-xs text-muted-foreground">
              {value.input_count} × {value.interval ?? "?"}
              {value.input_from ? `, ${formatDateTime(value.input_from)} → ${formatTime(value.input_to)}` : ""}
            </TableCell>
            <TableCell>
              <StatusBadge status={value.data_status} />
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

function RiskChecks({ decision }: { decision: RiskDecision | RiskDecisionView }) {
  return (
    <div className="flex flex-col gap-1.5">
      <p className="flex items-center gap-2 text-sm">
        <RiskOutcomeBadge outcome={decision.outcome} />
        <span className="text-xs text-muted-foreground">evaluated {formatDateTime(decision.evaluated_at)}</span>
      </p>
      <ul className="flex flex-col gap-1">
        {decision.checks.map((check) => (
          <li key={check.rule} className="flex items-start gap-2 text-sm">
            {check.passed ? (
              <CircleCheck aria-label="Passed" className="mt-0.5 size-4 shrink-0 text-emerald-400" />
            ) : (
              <CircleX
                aria-label="Failed"
                className={check.severity === "BLOCK" ? "mt-0.5 size-4 shrink-0 text-red-400" : "mt-0.5 size-4 shrink-0 text-amber-300"}
              />
            )}
            <span className="min-w-0">
              <span className="font-mono text-xs">{check.rule}</span>
              {!check.passed ? (
                <Badge variant={check.severity === "BLOCK" ? "destructive" : "warning"} className="ml-1">
                  {check.severity}
                </Badge>
              ) : null}
              <span className="block text-muted-foreground">{check.message}</span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Timeline({ events }: { events: SignalEventView[] }) {
  return (
    <ol className="flex flex-col gap-2 border-l pl-4">
      {events.map((event) => (
        <li key={event.id} className="relative flex flex-col gap-1">
          <span aria-hidden className="absolute top-1.5 -left-[21px] size-2 rounded-full bg-primary" />
          <p className="flex flex-wrap items-center gap-2 text-sm">
            <span className="text-xs text-muted-foreground">{formatDateTime(event.occurred_at)}</span>
            <SignalStatusBadge status={event.event_type} />
            <span className="text-xs text-muted-foreground">
              {event.from_status ? `${humanize(event.from_status)} → ` : ""}
              {humanize(event.to_status)}
            </span>
          </p>
          <JsonBlock value={event.details} />
        </li>
      ))}
    </ol>
  );
}

function Levels({ signal }: { signal: SignalView }) {
  return (
    <div className="flex flex-col gap-3">
      <StatGrid>
        <Stat label="Entry" value={formatPrice(signal.entry_price)} />
        <Stat label="Stop loss" value={formatPrice(signal.stop_loss)} />
        <Stat label="Risk : reward" value={signal.risk_reward ?? "—"} />
        <Stat label="Score" value={signal.score ?? "—"} title={signal.score_definition ?? undefined} />
      </StatGrid>
      {signal.targets.length > 0 ? (
        <StatGrid>
          {signal.targets.map((target) => (
            <Stat key={target.label} label={target.label} value={formatPrice(target.price)} />
          ))}
        </StatGrid>
      ) : null}
    </div>
  );
}

function Provenance({ signal }: { signal: SignalView }) {
  const rows: [string, ReactNode][] = [
    ["Strategy", `${signal.strategy_id} v${signal.strategy_version}`],
    ["Workspace", signal.workspace_slug],
    ["Provider", signal.provider],
    ["Source candle", signal.source_candle_start ? `${signal.source_candle_interval ?? ""} from ${formatDateTime(signal.source_candle_start)}` : null],
    ["Source event", signal.source_event_time ? formatDateTime(signal.source_event_time) : null],
    ["Updated", `${formatDateTime(signal.updated_at)} (${signal.update_count} updates)`],
    ["Valid until", signal.valid_until ? formatDateTime(signal.valid_until) : null],
    ["Closed", signal.closed_at ? formatDateTime(signal.closed_at) : null],
    ["Superseded by", signal.superseded_by],
    ["Saved configuration id", signal.deployment_id],
    ["Run", signal.strategy_run_id],
    ["Signal id", signal.id],
  ];
  return (
    <dl className="grid grid-cols-[max-content_1fr] gap-x-4 gap-y-1 text-xs">
      {rows
        .filter(([, value]) => value !== null && value !== "")
        .map(([label, value]) => (
          <div key={label} className="contents">
            <dt className="text-muted-foreground">{label}</dt>
            <dd className="min-w-0 font-mono break-all">{value}</dd>
          </div>
        ))}
    </dl>
  );
}

function ConfigurationSection({ configuration, signal }: { configuration: SignalConfiguration; signal: SignalView }) {
  const settings = Object.entries(configuration.config);
  const rows: [string, ReactNode][] = [
    ["Saved configuration", configuration.deployment_label],
    ["Strategy", `${signal.strategy_id} v${signal.strategy_version}`],
    [
      "Settings",
      settings.length === 0 ? "None" : settings.map(([name, value]) => `${name}=${formatConfigValue(value)}`).join(", "),
    ],
    ["Settings hash", configuration.config_hash],
    ["Code fingerprint", configuration.code_fingerprint ?? "Not recorded by the run"],
    ["Run started", formatDateTime(configuration.run_started_at)],
    ["Configuration id", configuration.configuration_id],
  ];
  return (
    <div className="flex flex-col gap-2">
      {configuration.is_current ? null : (
        <p className="text-xs text-amber-200">
          The saved configuration has been edited since this run started. These are the settings the signal was
          generated with, not its current ones.
        </p>
      )}
      <dl className="grid grid-cols-[max-content_1fr] gap-x-4 gap-y-1 text-xs">
        {rows.map(([label, value]) => (
          <div key={label} className="contents">
            <dt className="text-muted-foreground">{label}</dt>
            <dd className="min-w-0 font-mono break-all">{value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

function SignalDetailBody({ id }: { id: string }) {
  const detail = useQuery({ queryKey: queryKeys.signal(id), queryFn: () => signalsApi.get(id) });

  if (!detail.isSuccess) {
    return (
      <>
        <DialogHeader>
          <DialogTitle>Signal</DialogTitle>
          <DialogDescription>{detail.isError ? "The signal could not be loaded." : "Loading the signal…"}</DialogDescription>
        </DialogHeader>
        {detail.isError ? (
          <ErrorState error={detail.error} onRetry={() => void detail.refetch()} />
        ) : (
          <LoadingState />
        )}
      </>
    );
  }

  const { signal, configuration, events, decisions } = detail.data;
  return (
    <>
      <DialogHeader>
        <DialogTitle className="flex flex-wrap items-center gap-2">
          <SignalTypeBadge type={signal.signal_type} />
          <span className="font-mono">{signal.symbol}</span>
          <span className="text-sm font-normal text-muted-foreground">
            {signal.exchange} · {humanize(signal.segment)}
          </span>
        </DialogTitle>
        <DialogDescription>
          {signal.strategy_id} · generated {formatDateTime(signal.generated_at)}
        </DialogDescription>
      </DialogHeader>
      <div className="flex flex-wrap items-center gap-2">
        <SignalStatusBadge status={signal.status} />
        <ActionableBadge actionable={signal.is_actionable} />
        <RiskOutcomeBadge outcome={signal.risk_decision.outcome} />
        <StatusBadge status={signal.data_status} title="Data quality when the signal was generated" />
      </div>
      <p className="rounded-md border border-amber-500/40 bg-amber-500/10 p-2 text-xs text-amber-100">
        {signal.disclaimer}
      </p>
      <Levels signal={signal} />
      <Section title="Why">
        <p className="text-sm whitespace-pre-wrap">{signal.explanation}</p>
        {signal.reasons.length > 0 ? (
          <ul className="list-disc pl-5 text-sm text-muted-foreground">
            {signal.reasons.map((reason) => (
              <li key={reason}>{reason}</li>
            ))}
          </ul>
        ) : null}
      </Section>
      {signal.invalidation_conditions.length > 0 ? (
        <Section title="Invalidated when">
          <ul className="list-disc pl-5 text-sm text-muted-foreground">
            {signal.invalidation_conditions.map((condition) => (
              <li key={condition}>{condition}</li>
            ))}
          </ul>
        </Section>
      ) : null}
      <Section title="Indicators">
        <Indicators values={signal.indicator_values} />
      </Section>
      <Section title="Configuration">
        <ConfigurationSection configuration={configuration} signal={signal} />
      </Section>
      <Section title="Risk gate">
        <RiskChecks decision={signal.risk_decision} />
        {decisions.length > 1 ? (
          <details className="text-sm">
            <summary className="cursor-pointer text-muted-foreground">Earlier decisions ({decisions.length - 1})</summary>
            <div className="mt-2 flex flex-col gap-3">
              {/* Oldest first; the last one is the signal's current decision shown above. */}
              {decisions
                .slice(0, -1)
                .reverse()
                .map((decision) => (
                  <RiskChecks key={decision.id} decision={decision} />
                ))}
            </div>
          </details>
        ) : null}
      </Section>
      <Section title="History">
        {events.length > 0 ? <Timeline events={events} /> : <p className="text-sm text-muted-foreground">No events.</p>}
      </Section>
      <Section title="Provenance">
        <Provenance signal={signal} />
      </Section>
    </>
  );
}

/** A signal with its explanation, indicators, risk decisions and history. */
export function SignalDetailDialog({ signalId, onClose }: { signalId: string | null; onClose: () => void }) {
  return (
    <Dialog
      open={signalId !== null}
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="max-w-3xl">{signalId ? <SignalDetailBody id={signalId} /> : null}</DialogContent>
    </Dialog>
  );
}
