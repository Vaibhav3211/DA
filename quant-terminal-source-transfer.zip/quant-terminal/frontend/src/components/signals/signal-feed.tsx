"use client";

import { keepPreviousData, useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { useId, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { Switch } from "@/components/ui/switch";
import { signals as signalsApi, type SignalFilters } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { SignalView } from "@/lib/api/types.gen";
import { formatPrice, formatTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import { ActionableBadge, SignalStatusBadge, SignalTypeBadge } from "./signal-badges";
import { SignalDetailDialog } from "./signal-detail";

const FEED_LIMIT = 20;

function SignalItem({ signal, onSelect }: { signal: SignalView; onSelect: (id: string) => void }) {
  return (
    <li>
      <button
        type="button"
        onClick={() => onSelect(signal.id)}
        aria-label={`Open ${signal.signal_type} signal for ${signal.symbol}`}
        className={cn(
          "flex w-full flex-col gap-1 rounded-md px-2 py-1.5 text-left hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring/60 focus-visible:outline-none",
          signal.is_actionable ? "" : "text-muted-foreground",
        )}
      >
        <span className="flex items-center gap-1.5">
          <SignalTypeBadge type={signal.signal_type} />
          <span className="font-mono text-sm font-medium">{signal.symbol}</span>
          <ActionableBadge actionable={signal.is_actionable} />
          <span className="ml-auto text-xs text-muted-foreground">{formatTime(signal.generated_at)}</span>
        </span>
        <span className="flex items-center gap-2 text-xs">
          <SignalStatusBadge status={signal.status} />
          <span className="min-w-0 truncate text-muted-foreground">{signal.strategy_id}</span>
          <span className="ml-auto font-mono whitespace-nowrap tabular-nums">
            {formatPrice(signal.entry_price)} · SL {formatPrice(signal.stop_loss)}
          </span>
        </span>
      </button>
    </li>
  );
}

/** The workspace's latest signals; the live provider refreshes them as signal updates stream in. */
export function WorkspaceSignals({ slug }: { slug: string }) {
  const switchId = useId();
  const [openOnly, setOpenOnly] = useState(true);
  const [selected, setSelected] = useState<string | null>(null);
  const filters: SignalFilters = { workspace: slug, open_only: openOnly, limit: FEED_LIMIT };
  const feed = useQuery({
    queryKey: queryKeys.signalList(filters),
    queryFn: () => signalsApi.list(filters),
    placeholderData: keepPreviousData,
  });

  return (
    <Card>
      <CardHeader
        title="Signals"
        description="Research output, not orders."
        actions={
          <span className="flex items-center gap-2 text-xs text-muted-foreground">
            <Switch id={switchId} checked={openOnly} onCheckedChange={setOpenOnly} />
            <label htmlFor={switchId}>Open only</label>
          </span>
        }
      />
      <CardContent className="flex flex-col gap-2">
        {feed.isPending ? (
          <LoadingState />
        ) : feed.isError ? (
          <ErrorState error={feed.error} onRetry={() => void feed.refetch()} />
        ) : feed.data.items.length === 0 ? (
          <EmptyState title={openOnly ? "No open signals" : "No signals yet"}>
            Signals appear when an enabled strategy in this workspace emits one.
          </EmptyState>
        ) : (
          <ul className={cn("flex flex-col gap-0.5", feed.isPlaceholderData && "opacity-60")}>
            {feed.data.items.map((signal) => (
              <SignalItem key={signal.id} signal={signal} onSelect={setSelected} />
            ))}
          </ul>
        )}
        <Link className="text-xs underline" href={`/signals?workspace=${encodeURIComponent(slug)}`}>
          All signals for this workspace
        </Link>
      </CardContent>
      <SignalDetailDialog signalId={selected} onClose={() => setSelected(null)} />
    </Card>
  );
}
