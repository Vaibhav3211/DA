"use client";

import type { ReactNode } from "react";
import { StatusBadge } from "@/components/status/status-badge";
import { EmptyState } from "@/components/ui/feedback";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { SignalView } from "@/lib/api/types.gen";
import { formatDateTime, formatPrice } from "@/lib/format";
import { cn } from "@/lib/utils";
import { ActionableBadge, SignalStatusBadge, SignalTypeBadge } from "./signal-badges";

export function SignalTable({
  items,
  onSelect,
  selectedId,
  showWorkspace = false,
  empty,
}: {
  items: SignalView[];
  onSelect: (id: string) => void;
  selectedId?: string | null;
  showWorkspace?: boolean;
  empty?: ReactNode;
}) {
  if (items.length === 0) return <>{empty ?? <EmptyState title="No signals yet" />}</>;
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Generated</TableHead>
          <TableHead>Signal</TableHead>
          <TableHead>Instrument</TableHead>
          {showWorkspace ? <TableHead>Workspace</TableHead> : null}
          <TableHead>Strategy</TableHead>
          <TableHead className="text-right">Entry</TableHead>
          <TableHead className="text-right">Stop loss</TableHead>
          <TableHead className="text-right">First target</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Data</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {items.map((signal) => (
          <TableRow
            key={signal.id}
            data-selected={signal.id === selectedId}
            className={cn("cursor-pointer", signal.is_actionable ? "" : "text-muted-foreground")}
            onClick={() => onSelect(signal.id)}
          >
            <TableCell className="text-xs">{formatDateTime(signal.generated_at)}</TableCell>
            <TableCell>
              <span className="flex items-center gap-1">
                <SignalTypeBadge type={signal.signal_type} />
                <ActionableBadge actionable={signal.is_actionable} />
              </span>
            </TableCell>
            <TableCell>
              <button
                type="button"
                className="font-mono font-medium text-foreground underline-offset-2 hover:underline"
                onClick={(event) => {
                  event.stopPropagation();
                  onSelect(signal.id);
                }}
                aria-label={`Open ${signal.signal_type} signal for ${signal.symbol}`}
              >
                {signal.symbol}
              </button>
              <span className="ml-1 text-xs text-muted-foreground">{signal.exchange}</span>
            </TableCell>
            {showWorkspace ? <TableCell className="text-xs">{signal.workspace_slug}</TableCell> : null}
            <TableCell className="text-xs">{signal.strategy_id}</TableCell>
            <TableCell className="text-right font-mono">{formatPrice(signal.entry_price)}</TableCell>
            <TableCell className="text-right font-mono">{formatPrice(signal.stop_loss)}</TableCell>
            <TableCell className="text-right font-mono">{formatPrice(signal.targets[0]?.price)}</TableCell>
            <TableCell>
              <SignalStatusBadge status={signal.status} />
            </TableCell>
            <TableCell>
              <StatusBadge status={signal.data_status} />
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
