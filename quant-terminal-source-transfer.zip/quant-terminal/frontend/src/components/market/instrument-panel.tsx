"use client";

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ErrorState, LoadingState } from "@/components/ui/feedback";
import { Stat, StatGrid } from "@/components/ui/stat";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { quotes as quotesApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { DepthLevel, MarketDepth, UniverseEntry } from "@/lib/api/types.gen";
import {
  formatAge,
  formatCompact,
  formatDateTime,
  formatInteger,
  formatPrice,
  formatTime,
  humanize,
} from "@/lib/format";
import { useNow } from "@/lib/hooks";
import { instrumentSubtitle } from "@/lib/universe";
import type { LiveQuote } from "@/lib/ws/protocol";
import { InstrumentInfo } from "./instrument-search";
import { EntryStatusBadge } from "./quote-table";

const DEPTH_POLL_MS = 2_000;

function DepthTable({ depth }: { depth: MarketDepth }) {
  const levels = Math.max(depth.bids.length, depth.asks.length);
  return (
    <Table aria-label="Market depth">
      <TableHeader>
        <TableRow>
          <TableHead className="text-right">Bid qty</TableHead>
          <TableHead className="text-right">Bid</TableHead>
          <TableHead className="text-right">Ask</TableHead>
          <TableHead className="text-right">Ask qty</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {Array.from({ length: levels }, (_, index) => {
          const bid: DepthLevel | undefined = depth.bids[index];
          const ask: DepthLevel | undefined = depth.asks[index];
          return (
            <TableRow key={index}>
              <TableCell className="text-right font-mono text-xs tabular-nums">{formatInteger(bid?.quantity)}</TableCell>
              <TableCell className="text-right font-mono text-xs text-emerald-300 tabular-nums">
                {formatPrice(bid?.price)}
              </TableCell>
              <TableCell className="text-right font-mono text-xs text-red-300 tabular-nums">
                {formatPrice(ask?.price)}
              </TableCell>
              <TableCell className="text-right font-mono text-xs tabular-nums">{formatInteger(ask?.quantity)}</TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

/** The selected instrument: day statistics, market depth (Full mode only) and reference data. */
export function InstrumentPanel({ entry, quote }: { entry: UniverseEntry; quote: LiveQuote | undefined }) {
  const now = useNow(1000);
  const { instrument } = entry;
  const wantsDepth = entry.mode === "FULL" && entry.status === "PLANNED";
  // The socket's one quote subscription covers the whole workspace, so depth is polled for one instrument.
  const depth = useQuery({
    queryKey: queryKeys.quotes(`depth:${entry.provider}:${instrument.id}`),
    queryFn: () => quotesApi.latest({ instrument_id: [instrument.id], provider: entry.provider }),
    enabled: wantsDepth,
    refetchInterval: DEPTH_POLL_MS,
  });
  const depthQuote = depth.data?.items.find((item) => item.instrument_id === instrument.id);

  return (
    <Card>
      <CardHeader
        title={instrument.symbol}
        description={instrumentSubtitle(instrument) || instrument.exchange}
        actions={<EntryStatusBadge entry={entry} />}
      />
      <CardContent className="flex flex-col gap-4">
        <StatGrid className="sm:grid-cols-3">
          <Stat label="Open" value={formatPrice(quote?.open_price)} />
          <Stat label="High" value={formatPrice(quote?.high_price)} />
          <Stat label="Low" value={formatPrice(quote?.low_price)} />
          <Stat label="Prev close" value={formatPrice(quote?.previous_close)} />
          <Stat label="Avg price" value={formatPrice(quote?.average_price)} />
          <Stat label="Last qty" value={formatInteger(quote?.last_quantity)} />
          <Stat label="Buy qty" value={formatCompact(quote?.total_buy_quantity)} />
          <Stat label="Sell qty" value={formatCompact(quote?.total_sell_quantity)} />
          <Stat label="Last trade" value={formatTime(quote?.last_trade_time)} />
        </StatGrid>
        <p className="text-xs text-muted-foreground">
          {quote
            ? `Exchange time ${formatTime(quote.source_timestamp)} · received ${formatAge(quote.received_at, now)} · ${humanize(quote.last_event_type)} event`
            : "No quote received yet."}
        </p>

        <section aria-labelledby="depth-heading" className="flex flex-col gap-2">
          <h3 id="depth-heading" className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
            Market depth
          </h3>
          {!wantsDepth ? (
            <p className="text-xs text-muted-foreground">
              {entry.mode === "FULL"
                ? "This instrument is not streaming."
                : "Depth needs the Full data mode; change it under Universe."}
            </p>
          ) : depth.isPending ? (
            <LoadingState label="Loading depth…" />
          ) : depth.isError ? (
            <ErrorState error={depth.error} onRetry={() => void depth.refetch()} />
          ) : depthQuote?.market_depth ? (
            <>
              <DepthTable depth={depthQuote.market_depth} />
              <p className="text-xs text-muted-foreground">
                Received {formatAge(depthQuote.depth_received_at, now)}; refreshed every {DEPTH_POLL_MS / 1000}s.
              </p>
            </>
          ) : (
            <p className="text-xs text-muted-foreground">No depth received yet.</p>
          )}
        </section>

        <p className="text-xs text-muted-foreground">
          {`Streams from ${entry.provider} (${entry.streamed_by?.label ?? entry.account?.label ?? "its enabled account"}) in ${humanize(entry.mode)} mode. Added ${formatDateTime(entry.added_at)}${entry.added_by ? ` by ${entry.added_by}` : ""}.`}
        </p>
        <details className="text-sm">
          <summary className="cursor-pointer text-xs text-muted-foreground">Instrument details</summary>
          <div className="pt-2">
            <InstrumentInfo instrument={instrument} />
          </div>
        </details>
      </CardContent>
    </Card>
  );
}
