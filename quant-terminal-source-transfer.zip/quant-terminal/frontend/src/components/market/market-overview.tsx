"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { Badge, type BadgeVariant } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ErrorState, LoadingState } from "@/components/ui/feedback";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { markets, workspaces as workspacesApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { MarketRegion, MarketSessionState } from "@/lib/api/types.gen";
import { formatDate, formatTime, humanize } from "@/lib/format";

const SESSION_VARIANT: Record<MarketSessionState, BadgeVariant> = {
  PRE_OPEN: "info",
  OPEN: "success",
  POST_CLOSE: "warning",
  CLOSED: "secondary",
  HOLIDAY: "secondary",
  UNKNOWN: "outline",
};

export function SessionStateBadge({ state }: { state: MarketSessionState }) {
  return <Badge variant={SESSION_VARIANT[state]}>{humanize(state)}</Badge>;
}

export function useMarketOverview() {
  return useQuery({ queryKey: queryKeys.markets, queryFn: markets.overview, refetchInterval: 60_000 });
}

export function MarketSessions() {
  const overview = useMarketOverview();
  return (
    <Card>
      <CardHeader title="Market sessions" description="Exchange calendars, in IST." />
      {overview.isPending ? (
        <LoadingState />
      ) : overview.isError ? (
        <CardContent>
          <ErrorState error={overview.error} onRetry={() => void overview.refetch()} />
        </CardContent>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Exchange</TableHead>
              <TableHead>State</TableHead>
              <TableHead>Session</TableHead>
              <TableHead>Opens</TableHead>
              <TableHead>Closes</TableHead>
              <TableHead>Notes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {overview.data.markets.map((session) => (
              <TableRow key={session.exchange}>
                <TableCell className="font-medium">{session.exchange}</TableCell>
                <TableCell>
                  <SessionStateBadge state={session.state} />
                </TableCell>
                <TableCell className="text-xs">
                  {formatDate(session.session_date)} · {humanize(session.day_kind)}
                </TableCell>
                <TableCell className="font-mono text-xs">{formatTime(session.open_at)}</TableCell>
                <TableCell className="font-mono text-xs">{formatTime(session.close_at)}</TableCell>
                <TableCell className="text-xs text-muted-foreground">
                  {[
                    session.special ? "Special session" : null,
                    session.verified ? null : "Calendar not verified",
                    session.calendar_covered_until ? `Calendar to ${formatDate(session.calendar_covered_until)}` : null,
                  ]
                    .filter(Boolean)
                    .join(" · ")}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </Card>
  );
}

export const REGION_LABEL: Record<MarketRegion, string> = {
  INDIA: "India",
  FOREX: "Forex",
  CRYPTO: "Crypto",
  LAB: "Simulation lab",
};

/** Which markets the providers' capabilities stream, and why the others are unavailable. Nothing stands in
 * for an unavailable market. */
export function MarketAvailabilityCard() {
  const availability = useQuery({
    queryKey: queryKeys.marketAvailability,
    queryFn: markets.availability,
    staleTime: 60_000,
  });
  return (
    <Card>
      <CardHeader
        title="Market availability"
        description="From each provider's capabilities, not from connected accounts."
        actions={
          <Link className="text-xs underline" href="/providers">
            Providers
          </Link>
        }
      />
      <CardContent>
        {availability.isPending ? (
          <LoadingState />
        ) : availability.isError ? (
          <ErrorState error={availability.error} onRetry={() => void availability.refetch()} />
        ) : (
          <ul className="flex flex-col divide-y">
            {availability.data.map((market) => (
              <li key={market.key} className="flex flex-col gap-1 py-2 first:pt-0 last:pb-0">
                <span className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">{market.name}</span>
                  {market.available ? (
                    <Badge variant="success">Available</Badge>
                  ) : (
                    <Badge variant="secondary">Unavailable</Badge>
                  )}
                  <span className="text-xs text-muted-foreground">
                    {market.region ? `Region: ${REGION_LABEL[market.region]}` : "No region yet"}
                  </span>
                </span>
                <span className="text-xs">
                  {market.reason}
                  {market.planned_milestone ? ` · planned for milestone ${market.planned_milestone}` : null}
                </span>
                {market.notes.map((note) => (
                  <span key={note} className="text-xs text-muted-foreground">
                    {note}
                  </span>
                ))}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

export function WorkspaceGrid() {
  const list = useQuery({ queryKey: queryKeys.workspaces, queryFn: workspacesApi.list });
  if (list.isPending) return <LoadingState label="Loading workspaces…" />;
  if (list.isError) return <ErrorState error={list.error} onRetry={() => void list.refetch()} />;
  const sorted = [...list.data].sort((a, b) => a.sort_order - b.sort_order);
  return (
    <div className="flex flex-col gap-4">
      {(Object.keys(REGION_LABEL) as MarketRegion[]).map((region) => {
        const items = sorted.filter((workspace) => workspace.market_region === region);
        if (items.length === 0) return null;
        return (
          <section key={region} aria-labelledby={`region-${region}`} className="flex flex-col gap-2">
            <h2 id={`region-${region}`} className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
              {REGION_LABEL[region]}
            </h2>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {items.map((workspace) => (
                <Link
                  key={workspace.id}
                  href={`/workspaces/${encodeURIComponent(workspace.slug)}`}
                  className="flex flex-col gap-1 rounded-lg border bg-card p-3 transition-colors hover:border-ring/60"
                >
                  <span className="flex items-center justify-between gap-2">
                    <span className="truncate font-medium">{workspace.name}</span>
                    {workspace.is_enabled ? (
                      <Badge variant="success">On</Badge>
                    ) : (
                      <Badge variant="outline">Off</Badge>
                    )}
                  </span>
                  <span className="text-xs text-muted-foreground">{humanize(workspace.kind)}</span>
                  <span className="line-clamp-2 text-xs text-muted-foreground">{workspace.description}</span>
                  <span className="mt-auto pt-1 text-xs tabular-nums">
                    {workspace.instrument_count} instrument{workspace.instrument_count === 1 ? "" : "s"}
                  </span>
                </Link>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
