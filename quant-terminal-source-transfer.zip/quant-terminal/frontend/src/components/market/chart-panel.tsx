"use client";

import { useQueries, useQuery, type UseQueryResult } from "@tanstack/react-query";
import { X } from "lucide-react";
import dynamic from "next/dynamic";
import { useMemo, useState } from "react";
import { BacktestResultsDialog } from "@/components/backtests/backtest-results";
import { BacktestTradeDialog } from "@/components/backtests/backtest-trade-dialog";
import { BacktestStateBadge, DataBadge } from "@/components/backtests/common";
import { latestBacktestQuery } from "@/components/backtests/latest-backtest";
import { SignalStatusBadge, SignalTypeBadge } from "@/components/signals/signal-badges";
import { SignalDetailDialog } from "@/components/signals/signal-detail";
import { StatusBadge } from "@/components/status/status-badge";
import { MonitoringBadge } from "@/components/strategies/monitoring";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import {
  backtests as backtestsApi,
  candles as candlesApi,
  deployments as deploymentsApi,
  signals as signalsApi,
  type CandleQuery,
  type ChartSignalQuery,
} from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type {
  BacktestLatest,
  BacktestRunView,
  BacktestTrade,
  BacktestTradesPage,
  Candle,
  CandleInterval,
  Instrument,
  Provider,
  SignalPage,
} from "@/lib/api/types.gen";
import {
  CHART_TRADE_LIMIT,
  backtestMarkers,
  chartBacktest,
  parseBacktestMarkerId,
  type ChartBacktest,
  type TradeLeg,
} from "@/lib/backtests";
import {
  CANDLE_INTERVALS,
  CHART_COLORS,
  EMA_FAST,
  EMA_SLOW,
  INTERVAL_SECONDS,
  MARKER_SIGNAL_TYPES,
  mergeCandles,
  placeSignals,
  priceFormatFor,
  signalMarkers,
  toBar,
  type ChartMarker,
  type MarkedSignal,
} from "@/lib/chart";
import { formatCompact, formatDate, formatDateTime, formatPrice, formatTime, humanize } from "@/lib/format";
import { useLiveSubscription } from "@/lib/live/provider";
import { seriesKey, useLiveStore, useSocketStatus } from "@/lib/live/store";
import { effectiveStatus } from "@/lib/status";
import { appliedOverlays, type ChartOverlay } from "@/lib/strategies";
import { errorMessage } from "@/lib/utils";

const PriceChart = dynamic(() => import("./price-chart"), {
  ssr: false,
  loading: () => <LoadingState label="Loading chart…" className="h-[420px]" />,
});

const HISTORY_LIMIT = 500;
/** The newest signals drawn per applied configuration. */
const CHART_SIGNAL_LIMIT = 200;
/** The newest marked signals in the accessible list. */
const LISTED_MARKERS = 100;
const NUMBER_CHIP =
  "flex size-5 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground";

/** A closed backtest trade drawn on the chart, with its run and its configuration's number on the chart. */
interface ChartTrade {
  number: number;
  run: BacktestRunView;
  trade: BacktestTrade;
}

/** One marker of a drawn trade: its entry or its exit. */
interface MarkedTrade extends ChartTrade {
  id: string;
  leg: TradeLeg;
}

/** An applied configuration's backtest as the chart shows it. */
interface OverlayBacktest {
  latest: UseQueryResult<BacktestLatest> | undefined;
  /** Null until its latest backtest has loaded. */
  plan: ChartBacktest | null;
  /** Its newest trades, while they are drawn and shown. */
  trades: UseQueryResult<BacktestTradesPage> | undefined;
  /** How many of its trades have a marker on these bars. */
  drawn: number;
}

/** Markers for the drawn backtests' trades, each with the trade it stands for. */
function markTrades(
  sources: readonly { number: number; run: BacktestRunView; trades: readonly BacktestTrade[] }[],
  barTimes: readonly number[],
  barSeconds: number,
): { markers: ChartMarker[]; marked: MarkedTrade[] } {
  const markers: ChartMarker[] = [];
  const marked: MarkedTrade[] = [];
  for (const { number, run, trades } of sources) {
    const byNumber = new Map(trades.map((trade) => [trade.number, trade]));
    for (const marker of backtestMarkers(run.id, trades, barTimes, barSeconds, `${number}·`)) {
      const ref = parseBacktestMarkerId(marker.id);
      const trade = ref === null ? undefined : byNumber.get(ref.trade);
      if (ref === null || trade === undefined) continue;
      markers.push(marker);
      marked.push({ id: marker.id, leg: ref.leg, number, run, trade });
    }
  }
  return { markers, marked };
}

function Toggle({
  pressed,
  onChange,
  children,
  color,
}: {
  pressed: boolean;
  onChange: (pressed: boolean) => void;
  children: string;
  color?: string;
}) {
  return (
    <Button size="sm" variant={pressed ? "secondary" : "ghost"} aria-pressed={pressed} onClick={() => onChange(!pressed)}>
      {color ? <span aria-hidden className="size-2 rounded-full" style={{ backgroundColor: color }} /> : null}
      {children}
    </Button>
  );
}

function LastBar({ candle }: { candle: Candle }) {
  const values: [string, string][] = [
    ["O", formatPrice(candle.open_price)],
    ["H", formatPrice(candle.high_price)],
    ["L", formatPrice(candle.low_price)],
    ["C", formatPrice(candle.close_price)],
    ["V", formatCompact(candle.volume)],
  ];
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
      <span className="text-muted-foreground">
        {formatTime(candle.bucket_start)} {candle.is_closed ? "closed" : "forming"}
      </span>
      {values.map(([label, value]) => (
        <span key={label} className="font-mono tabular-nums">
          <span className="text-muted-foreground">{label}</span> {value}
        </span>
      ))}
      {candle.flags.map((flag) => (
        <Badge key={flag} variant="warning" title="A data-quality flag the candle builder set on this bar">
          {humanize(flag)}
        </Badge>
      ))}
    </div>
  );
}

function NumberChip({ number }: { number: number }) {
  return (
    <span className={NUMBER_CHIP}>
      <span className="sr-only">Configuration </span>
      {number}
    </span>
  );
}

function MarkerKey() {
  const shapes: [string, string, string][] = [
    ["▲", "BUY", CHART_COLORS.up],
    ["▼", "SELL", CHART_COLORS.down],
    ["■", "EXIT", CHART_COLORS.signalExit],
  ];
  const backtestShapes: [string, string][] = [
    ["Backtest long entry", CHART_COLORS.backtestLong],
    ["Backtest short entry", CHART_COLORS.backtestShort],
    ["Backtest exit", CHART_COLORS.backtestExit],
  ];
  return (
    <div className="flex flex-col gap-1 text-xs text-muted-foreground">
      <p className="flex flex-wrap items-center gap-x-3 gap-y-1">
        {shapes.map(([glyph, label, color]) => (
          <span key={label}>
            <span aria-hidden style={{ color }}>
              {glyph}
            </span>{" "}
            {label}
          </span>
        ))}
        <span>
          <span aria-hidden style={{ color: CHART_COLORS.signalBlocked }}>
            ▲▼■
          </span>{" "}
          Blocked by the risk rules
        </span>
      </p>
      <p className="flex flex-wrap items-center gap-x-3 gap-y-1">
        {backtestShapes.map(([label, color]) => (
          <span key={label}>
            <span aria-hidden style={{ color }}>
              ●
            </span>{" "}
            {label}
          </span>
        ))}
      </p>
      <p>
        Arrows and squares are live signals. A marker sits on the bar in which its signal became known (when its
        candle closed, or earlier for a signal on a forming candle) and carries its configuration&apos;s number.
        Signals older than the first bar are only in the signal history.
      </p>
      <p>
        Muted circles, such as 1·BT3, are closed trades of a configuration&apos;s current backtest: replayed history,
        not live signals. Each sits on the bar that contains its fill. A position still open when the backtest ended
        is only in its results.
      </p>
    </div>
  );
}

/** An applied configuration's backtest: whether its trades are drawn, and why not when they are not. */
function BacktestLine({
  backtest,
  shown,
  onOpenResults,
}: {
  backtest: OverlayBacktest;
  shown: boolean;
  onOpenResults: (runId: string) => void;
}) {
  const { latest, plan, trades, drawn } = backtest;
  if (latest === undefined || latest.isPending) return <p className="pl-7 text-muted-foreground">Backtest: loading…</p>;
  if (latest.isError) {
    return (
      <p className="flex flex-wrap items-center gap-2 pl-7 text-red-300">
        {`Its backtest did not load (${errorMessage(latest.error)}).`}
        <Button size="sm" variant="ghost" onClick={() => void latest.refetch()}>
          Retry
        </Button>
      </p>
    );
  }
  if (plan === null) return <p className="pl-7 text-muted-foreground">Backtest: loading…</p>;
  const run = latest.data.current ?? latest.data.outdated;
  let text: string;
  let retry: (() => void) | null = null;
  if (!plan.drawn) {
    text = `Backtest trades not drawn: ${plan.reason}.`;
  } else if (!shown) {
    text = "Backtest trades are hidden; turn on Backtest trades above the chart to draw them.";
  } else if (trades === undefined || trades.isPending) {
    text = "Loading its backtest trades…";
  } else if (trades.isError) {
    text = `Its backtest trades did not load (${errorMessage(trades.error)}).`;
    retry = () => void trades.refetch();
  } else if (drawn === 0) {
    const loaded = plan.offset > 0 ? `newest ${CHART_TRADE_LIMIT} ` : "";
    text = `None of its ${loaded}backtest trades falls on these bars; it replayed ${formatDate(plan.run.date_from)} to ${formatDate(plan.run.date_to)}.`;
  } else {
    const limited = plan.offset > 0 ? `; only its newest ${CHART_TRADE_LIMIT} closed trades are loaded` : "";
    text = `${drawn} backtest trade${drawn === 1 ? "" : "s"} marked on these bars${limited}.`;
  }
  return (
    <div className="flex flex-wrap items-center gap-2 pl-7">
      <BacktestStateBadge state={latest.data.state} />
      {run ? <DataBadge origin={run} /> : null}
      <span className={retry ? "text-red-300" : "text-muted-foreground"}>{text}</span>
      {retry ? (
        <Button size="sm" variant="ghost" onClick={retry}>
          Retry
        </Button>
      ) : null}
      {run ? (
        <Button size="sm" variant="ghost" onClick={() => onOpenResults(run.id)}>
          {latest.data.state === "CURRENT" ? "Results…" : "Outdated results…"}
        </Button>
      ) : null}
    </div>
  );
}

function OverlayRow({
  overlay,
  page,
  drawn,
  backtest,
  showBacktests,
  onRemove,
  onOpenResults,
}: {
  overlay: ChartOverlay;
  page: UseQueryResult<SignalPage>;
  drawn: number;
  backtest: OverlayBacktest;
  showBacktests: boolean;
  onRemove: () => void;
  onOpenResults: (runId: string) => void;
}) {
  const { deployment, number } = overlay;
  const count = `${drawn} signal marker${drawn === 1 ? "" : "s"} on these bars`;
  return (
    <li className="flex flex-col gap-1 text-xs">
      <div className="flex flex-wrap items-center gap-2">
        <NumberChip number={number} />
        <span className="font-medium">{deployment.label}</span>
        <span className="text-muted-foreground">{`${deployment.strategy_id} v${deployment.strategy_version}`}</span>
        <MonitoringBadge monitoring={deployment.monitoring} />
        {page.isPending ? (
          <span className="text-muted-foreground">Loading its signals…</span>
        ) : page.isError ? (
          <>
            <span className="text-red-300">Its signals did not load.</span>
            <Button size="sm" variant="ghost" onClick={() => void page.refetch()}>
              Retry
            </Button>
          </>
        ) : (
          <span className="text-muted-foreground">
            {page.data.next_cursor ? `${count}; only its newest ${CHART_SIGNAL_LIMIT} signals are loaded` : count}
          </span>
        )}
        <Button
          size="icon-sm"
          variant="ghost"
          className="ml-auto"
          aria-label={`Remove ${deployment.label} from the chart`}
          title="Remove from the chart. Its live signals and backtests are not affected."
          onClick={onRemove}
        >
          <X aria-hidden />
        </Button>
      </div>
      <BacktestLine backtest={backtest} shown={showBacktests} onOpenResults={onOpenResults} />
    </li>
  );
}

function MarkerList({ marked, onOpen }: { marked: readonly MarkedSignal[]; onOpen: (signalId: string) => void }) {
  const [open, setOpen] = useState(false);
  const newest = marked.slice(-LISTED_MARKERS).reverse();
  return (
    <div className="flex flex-col gap-1">
      <Button size="sm" variant="ghost" className="self-start" aria-expanded={open} onClick={() => setOpen(!open)}>
        {open ? "Hide the marked signals" : `List the ${marked.length} marked signal${marked.length === 1 ? "" : "s"}`}
      </Button>
      {open ? (
        <ul className="flex max-h-60 flex-col overflow-y-auto" aria-label="Marked signals, newest first">
          {newest.map(({ signal, number }) => (
            <li key={signal.id}>
              <button
                type="button"
                className="flex w-full flex-wrap items-center gap-2 rounded px-2 py-1 text-left text-xs hover:bg-accent"
                onClick={() => onOpen(signal.id)}
              >
                <NumberChip number={number} />
                <SignalTypeBadge type={signal.signal_type} />
                <SignalStatusBadge status={signal.status} />
                <span className="font-mono text-muted-foreground tabular-nums">{formatDateTime(signal.generated_at)}</span>
              </button>
            </li>
          ))}
          {marked.length > LISTED_MARKERS ? (
            <li className="px-2 py-1 text-xs text-muted-foreground">
              {`The newest ${LISTED_MARKERS} are listed; the signal history has them all.`}
            </li>
          ) : null}
        </ul>
      ) : null}
    </div>
  );
}

/** The configurations applied to the chart, what their markers mean, and the signals marked. */
function AppliedConfigurations({
  symbol,
  overlays,
  pages,
  backtests,
  showBacktests,
  marked,
  missing,
  loadError,
  onRetry,
  onRemove,
  onOpen,
  onOpenResults,
}: {
  symbol: string;
  overlays: readonly ChartOverlay[];
  pages: readonly UseQueryResult<SignalPage>[];
  /** Each overlay's backtest, in the same order. */
  backtests: readonly OverlayBacktest[];
  showBacktests: boolean;
  marked: readonly MarkedSignal[];
  /** Applied configurations that were archived or no longer cover the instrument. */
  missing: readonly string[];
  loadError: boolean;
  onRetry: () => void;
  onRemove: (deploymentId: string) => void;
  onOpen: (signalId: string) => void;
  onOpenResults: (runId: string) => void;
}) {
  if (overlays.length === 0 && missing.length === 0 && !loadError) {
    return (
      <p className="text-xs text-muted-foreground">
        Apply a saved configuration to the chart in the Strategies panel to mark its signals and its current
        backtest&apos;s trades here. Applying starts nothing.
      </p>
    );
  }
  const one = missing.length === 1;
  return (
    <section aria-label="Configurations applied to the chart" className="flex flex-col gap-2 rounded-md border p-3">
      {loadError ? (
        <p className="flex flex-wrap items-center gap-2 text-xs text-red-300">
          The applied configurations did not load.
          <Button size="sm" variant="ghost" onClick={onRetry}>
            Retry
          </Button>
        </p>
      ) : null}
      {overlays.length > 0 ? (
        <ul className="flex flex-col gap-1">
          {overlays.map((overlay, index) => (
            <OverlayRow
              key={overlay.deployment.id}
              overlay={overlay}
              page={pages[index]}
              drawn={marked.filter((item) => item.number === overlay.number).length}
              backtest={backtests[index]}
              showBacktests={showBacktests}
              onRemove={() => onRemove(overlay.deployment.id)}
              onOpenResults={onOpenResults}
            />
          ))}
        </ul>
      ) : null}
      {missing.length > 0 ? (
        <p className="flex flex-wrap items-center gap-2 text-xs text-amber-200">
          {`${missing.length} applied configuration${one ? " was" : "s were"} archived or no longer cover${one ? "s" : ""} ${symbol}, so ${one ? "its" : "their"} markers are not drawn.`}
          <Button size="sm" variant="ghost" onClick={() => missing.forEach(onRemove)}>
            Forget {one ? "it" : "them"}
          </Button>
        </p>
      ) : null}
      {overlays.length > 0 ? <MarkerKey /> : null}
      {marked.length > 0 ? <MarkerList marked={marked} onOpen={onOpen} /> : null}
    </section>
  );
}

/** The choice when a click lands on a bar with several markers. */
function BarSignals({
  marked,
  trades,
  onOpen,
  onOpenTrade,
  onClose,
}: {
  marked: readonly MarkedSignal[];
  trades: readonly MarkedTrade[];
  onOpen: (signalId: string) => void;
  onOpenTrade: (trade: MarkedTrade) => void;
  onClose: () => void;
}) {
  return (
    <div
      role="group"
      aria-label="Markers on the clicked bar"
      className="flex flex-wrap items-center gap-2 rounded-md border p-2 text-xs"
    >
      <span className="text-muted-foreground">{`${marked.length + trades.length} markers on this bar:`}</span>
      {marked.map(({ signal, number }) => (
        <Button key={signal.id} size="sm" variant="secondary" onClick={() => onOpen(signal.id)}>
          {`${number} · ${signal.signal_type} · ${humanize(signal.status)} · ${formatTime(signal.generated_at)}`}
        </Button>
      ))}
      {trades.map((item) => (
        <Button key={item.id} size="sm" variant="outline" onClick={() => onOpenTrade(item)}>
          {`${item.number} · Backtest trade ${item.trade.number} ${item.leg} · ${formatTime(item.leg === "entry" ? item.trade.entry_at : item.trade.exit_at)}`}
        </Button>
      ))}
      <Button size="icon-sm" variant="ghost" className="ml-auto" aria-label="Close" onClick={onClose}>
        <X aria-hidden />
      </Button>
    </div>
  );
}

/**
 * Stored candle history plus the forming candle, kept current over the market socket, with the signals and the
 * current backtest trades of the saved configurations applied to it. Applying one only draws what is stored: it
 * starts nothing.
 */
export function ChartPanel({
  slug,
  instrument,
  provider,
  interval,
  onIntervalChange,
  applied,
  onToggleApplied,
}: {
  slug: string;
  instrument: Instrument;
  provider: Provider;
  interval: CandleInterval;
  onIntervalChange: (interval: CandleInterval) => void;
  /** The saved configurations applied to this chart, in the order they were applied. */
  applied: readonly string[];
  onToggleApplied: (deploymentId: string) => void;
}) {
  const [showVolume, setShowVolume] = useState(true);
  const [showEmaFast, setShowEmaFast] = useState(true);
  const [showEmaSlow, setShowEmaSlow] = useState(false);
  const [showBacktests, setShowBacktests] = useState(true);
  const [openSignal, setOpenSignal] = useState<string | null>(null);
  const [openTrade, setOpenTrade] = useState<ChartTrade | null>(null);
  const [openResults, setOpenResults] = useState<string | null>(null);
  const [clicked, setClicked] = useState<readonly string[]>([]);
  const socket = useSocketStatus("market");

  const params: CandleQuery = {
    instrument: instrument.id,
    provider,
    interval,
    limit: HISTORY_LIMIT,
    include_forming: true,
  };
  const history = useQuery({
    queryKey: queryKeys.candles(params),
    queryFn: ({ signal }) => candlesApi.series(params, signal),
    staleTime: 60_000,
  });
  useLiveSubscription("market", { channel: "candles", instrument_ids: [instrument.id], provider, interval });
  const key = seriesKey(provider, instrument.id, interval);
  const live: Record<number, Candle> | undefined = useLiveStore((state) => state.candles[key]);

  const data = history.data;
  const candles = useMemo(
    () => (data ? mergeCandles(data.candles, data.forming ? [data.forming] : [], Object.values(live ?? {})) : []),
    [data, live],
  );
  const bars = useMemo(() => candles.map(toBar), [candles]);
  const last: Candle | undefined = candles[candles.length - 1];
  const { precision, minMove } = priceFormatFor(instrument.tick_size);

  // The Strategy panel beside the chart polls this same query; the chart only reads it.
  const filters = { workspace: slug, instrument_id: instrument.id };
  const configurations = useQuery({
    queryKey: queryKeys.deployments(filters),
    queryFn: () => deploymentsApi.list(filters),
  });
  const overlays = useMemo(() => appliedOverlays(applied, configurations.data ?? []), [applied, configurations.data]);
  const missing = configurations.isSuccess
    ? applied.filter((id) => !configurations.data.some((deployment) => deployment.id === id))
    : [];
  // New and changed signals arrive over the signals socket, which refreshes every signals query.
  const pages = useQueries({
    queries: overlays.map(({ deployment }) => {
      const query: ChartSignalQuery = {
        instrument: instrument.id,
        deployment_id: deployment.id,
        signal_type: MARKER_SIGNAL_TYPES,
        limit: CHART_SIGNAL_LIMIT,
      };
      return { queryKey: queryKeys.chartSignals(query), queryFn: () => signalsApi.forChart(query) };
    }),
  });
  const barTimes = useMemo(() => bars.map((bar) => bar.time), [bars]);
  const marked = placeSignals(
    overlays.flatMap((overlay, index) => {
      const page = pages[index]?.data;
      return page ? [{ signals: page.items, number: overlay.number }] : [];
    }),
    barTimes,
  );
  // Reading a backtest never runs one. These are the Strategy panel's polled queries, not price-driven.
  const latestRuns = useQueries({
    queries: overlays.map(({ deployment }) => latestBacktestQuery(deployment.id, instrument.id)),
  });
  const plans = overlays.map((_, index) => {
    const latest = latestRuns[index]?.data;
    return latest ? chartBacktest(latest, { interval, provider }) : null;
  });
  const drawable = showBacktests
    ? overlays.flatMap(({ number }, index) => {
        const plan = plans[index];
        return plan?.drawn ? [{ number, plan }] : [];
      })
    : [];
  // A succeeded backtest's trades never change.
  const tradePages = useQueries({
    queries: drawable.map(({ plan }) => ({
      queryKey: queryKeys.backtestTrades(plan.run.id, plan.offset, plan.limit),
      queryFn: () => backtestsApi.trades(plan.run.id, plan.offset, plan.limit),
      staleTime: Infinity,
    })),
  });
  const { markers: tradeMarkers, marked: markedTrades } = markTrades(
    drawable.flatMap(({ number, plan }, index) => {
      const page = tradePages[index]?.data;
      return page ? [{ number, run: plan.run, trades: page.trades }] : [];
    }),
    barTimes,
    INTERVAL_SECONDS[interval],
  );
  const backtests: OverlayBacktest[] = overlays.map(({ number }, index) => {
    const at = drawable.findIndex((item) => item.number === number);
    return {
      latest: latestRuns[index],
      plan: plans[index] ?? null,
      trades: at === -1 ? undefined : tradePages[at],
      drawn: new Set(markedTrades.filter((item) => item.number === number).map((item) => item.trade.number)).size,
    };
  });
  const markers = [...signalMarkers(marked), ...tradeMarkers].sort((a, b) => a.time - b.time);
  const tradeMarks = new Map(markedTrades.map((item) => [item.id, item]));
  const onClickedBar = marked.filter(({ signal }) => clicked.includes(signal.id));
  const tradesOnClickedBar = markedTrades.filter((item) => clicked.includes(item.id));
  const openMarkers = (ids: string[]) => {
    if (ids.length === 1) {
      setClicked([]);
      const id = ids[0];
      if (parseBacktestMarkerId(id) === null) {
        setOpenSignal(id);
      } else {
        const item = tradeMarks.get(id);
        if (item) setOpenTrade(item);
      }
    } else {
      setClicked(ids);
    }
  };

  return (
    <Card>
      <CardHeader
        title={`${instrument.symbol} · ${provider}`}
        description="Candles the backend builds from streamed ticks; times in IST."
        actions={
          <>
            {last ? <StatusBadge status={effectiveStatus(last.data_status, socket)} /> : null}
            {data ? <StatusBadge status={effectiveStatus(data.feed_status, socket)} title="Feed status" /> : null}
          </>
        }
      />
      <CardContent className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div role="group" aria-label="Candle interval" className="flex flex-wrap gap-1">
            {CANDLE_INTERVALS.map((item) => (
              <Button
                key={item}
                size="sm"
                variant={item === interval ? "secondary" : "ghost"}
                aria-pressed={item === interval}
                onClick={() => onIntervalChange(item)}
              >
                {item}
              </Button>
            ))}
          </div>
          <div role="group" aria-label="Overlays" className="flex flex-wrap gap-1">
            <Toggle pressed={showVolume} onChange={setShowVolume}>
              Volume
            </Toggle>
            <Toggle pressed={showEmaFast} onChange={setShowEmaFast} color={CHART_COLORS.ema}>
              {`EMA ${EMA_FAST}`}
            </Toggle>
            <Toggle pressed={showEmaSlow} onChange={setShowEmaSlow} color={CHART_COLORS.emaSlow}>
              {`EMA ${EMA_SLOW}`}
            </Toggle>
            {overlays.length > 0 ? (
              <Toggle pressed={showBacktests} onChange={setShowBacktests} color={CHART_COLORS.backtestLong}>
                Backtest trades
              </Toggle>
            ) : null}
          </div>
        </div>
        {last ? <LastBar candle={last} /> : null}
        {onClickedBar.length + tradesOnClickedBar.length > 1 ? (
          <BarSignals
            marked={onClickedBar}
            trades={tradesOnClickedBar}
            onOpen={setOpenSignal}
            onOpenTrade={setOpenTrade}
            onClose={() => setClicked([])}
          />
        ) : null}
        {history.isPending ? (
          <LoadingState label="Loading candles…" className="h-[420px]" />
        ) : history.isError ? (
          <ErrorState error={history.error} onRetry={() => void history.refetch()} />
        ) : bars.length === 0 ? (
          <EmptyState title="No candles yet">
            Candles appear once ticks arrive for {instrument.symbol} from {provider}.
          </EmptyState>
        ) : (
          <PriceChart
            key={key}
            bars={bars}
            interval={interval}
            precision={precision}
            minMove={minMove}
            showVolume={showVolume}
            showEmaFast={showEmaFast}
            showEmaSlow={showEmaSlow}
            markers={markers}
            onMarkerClick={openMarkers}
          />
        )}
        <AppliedConfigurations
          symbol={instrument.symbol}
          overlays={overlays}
          pages={pages}
          backtests={backtests}
          showBacktests={showBacktests}
          marked={marked}
          missing={missing}
          loadError={configurations.isError && applied.length > 0}
          onRetry={() => void configurations.refetch()}
          onRemove={onToggleApplied}
          onOpen={setOpenSignal}
          onOpenResults={setOpenResults}
        />
        <SignalDetailDialog signalId={openSignal} onClose={() => setOpenSignal(null)} />
        {openTrade ? (
          <BacktestTradeDialog run={openTrade.run} trade={openTrade.trade} onClose={() => setOpenTrade(null)} />
        ) : null}
        {openResults !== null ? (
          <BacktestResultsDialog runId={openResults} onClose={() => setOpenResults(null)} />
        ) : null}
      </CardContent>
    </Card>
  );
}
