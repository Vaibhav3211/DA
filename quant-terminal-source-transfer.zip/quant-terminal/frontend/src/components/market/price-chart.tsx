"use client";

// Loaded only in the browser (next/dynamic, ssr: false): lightweight-charts draws on a canvas.

import {
  CandlestickSeries,
  ColorType,
  createChart,
  createSeriesMarkers,
  CrosshairMode,
  HistogramSeries,
  LineSeries,
  type IChartApi,
  type ISeriesApi,
  type ISeriesMarkersPluginApi,
  type MouseEventParams,
  type TickMarkType,
  type Time,
} from "lightweight-charts";
import { useEffect, useRef } from "react";
import type { CandleInterval } from "@/lib/api/types.gen";
import {
  CHART_COLORS,
  chartTickLabel,
  chartTimeLabel,
  EMA_FAST,
  EMA_SLOW,
  emaLine,
  volumeData,
  type ChartBar,
  type ChartMarker,
} from "@/lib/chart";

export interface PriceChartProps {
  bars: ChartBar[];
  interval: CandleInterval;
  precision: number;
  minMove: number;
  showVolume: boolean;
  showEmaFast: boolean;
  showEmaSlow: boolean;
  /** Live-signal and backtest-trade markers, oldest first, each on one of ``bars``. */
  markers: ChartMarker[];
  /** Called with the marker a click hit, or else with every marker on the clicked bar; never with none. */
  onMarkerClick: (ids: string[]) => void;
}

interface ChartHandles {
  chart: IChartApi;
  candles: ISeriesApi<"Candlestick">;
  volume: ISeriesApi<"Histogram">;
  emaFast: ISeriesApi<"Line">;
  emaSlow: ISeriesApi<"Line">;
  markers: ISeriesMarkersPluginApi<Time>;
}

export default function PriceChart({
  bars,
  interval,
  precision,
  minMove,
  showVolume,
  showEmaFast,
  showEmaSlow,
  markers,
  onMarkerClick,
}: PriceChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const handlesRef = useRef<ChartHandles | null>(null);
  // Read by the click handler, which is subscribed once per chart.
  const markersRef = useRef<ChartMarker[]>(markers);
  const onMarkerClickRef = useRef(onMarkerClick);

  useEffect(() => {
    onMarkerClickRef.current = onMarkerClick;
  }, [onMarkerClick]);

  // The parent remounts this component for each instrument, provider and interval.
  useEffect(() => {
    const element = containerRef.current;
    if (element === null) return;
    const priceFormat = { type: "price" as const, precision, minMove };
    const chart = createChart(element, {
      autoSize: true,
      layout: {
        background: { type: ColorType.Solid, color: CHART_COLORS.background },
        textColor: CHART_COLORS.text,
      },
      grid: { vertLines: { color: CHART_COLORS.grid }, horzLines: { color: CHART_COLORS.grid } },
      crosshair: { mode: CrosshairMode.Normal },
      rightPriceScale: { borderColor: CHART_COLORS.border },
      timeScale: {
        borderColor: CHART_COLORS.border,
        timeVisible: interval !== "1d",
        secondsVisible: interval === "1s",
        tickMarkFormatter: (time: Time, tickMarkType: TickMarkType) =>
          typeof time === "number" ? chartTickLabel(time, tickMarkType) : null,
      },
      localization: {
        timeFormatter: (time: Time) => (typeof time === "number" ? chartTimeLabel(time, interval) : String(time)),
      },
    });
    const candles = chart.addSeries(CandlestickSeries, {
      upColor: CHART_COLORS.up,
      downColor: CHART_COLORS.down,
      borderUpColor: CHART_COLORS.up,
      borderDownColor: CHART_COLORS.down,
      wickUpColor: CHART_COLORS.up,
      wickDownColor: CHART_COLORS.down,
      priceFormat,
    });
    candles.priceScale().applyOptions({ scaleMargins: { top: 0.08, bottom: 0.25 } });
    const volume = chart.addSeries(HistogramSeries, {
      priceScaleId: "volume",
      priceFormat: { type: "volume" },
      lastValueVisible: false,
      priceLineVisible: false,
    });
    volume.priceScale().applyOptions({ scaleMargins: { top: 0.8, bottom: 0 } });
    const line = (color: string) =>
      chart.addSeries(LineSeries, {
        color,
        lineWidth: 1,
        priceFormat,
        lastValueVisible: false,
        priceLineVisible: false,
        crosshairMarkerVisible: false,
      });
    const emaFast = line(CHART_COLORS.ema);
    const emaSlow = line(CHART_COLORS.emaSlow);
    const seriesMarkers = createSeriesMarkers(candles, []);
    const onClick = (param: MouseEventParams<Time>) => {
      const shown = markersRef.current;
      const hit = param.hoveredObjectId;
      if (typeof hit === "string" && shown.some((marker) => marker.id === hit)) {
        onMarkerClickRef.current([hit]);
        return;
      }
      if (typeof param.time !== "number") return;
      const onBar = shown.filter((marker) => marker.time === param.time).map((marker) => marker.id);
      if (onBar.length > 0) onMarkerClickRef.current(onBar);
    };
    chart.subscribeClick(onClick);
    handlesRef.current = { chart, candles, volume, emaFast, emaSlow, markers: seriesMarkers };
    return () => {
      chart.unsubscribeClick(onClick);
      handlesRef.current = null;
      chart.remove();
    };
  }, [interval, precision, minMove]);

  // setData on every change: an update can revise any recent bar, which series.update() cannot.
  useEffect(() => {
    const handles = handlesRef.current;
    if (handles === null) return;
    handles.candles.setData(bars);
    handles.volume.setData(showVolume ? volumeData(bars) : []);
    handles.emaFast.setData(showEmaFast ? emaLine(bars, EMA_FAST) : []);
    handles.emaSlow.setData(showEmaSlow ? emaLine(bars, EMA_SLOW) : []);
  }, [bars, showVolume, showEmaFast, showEmaSlow, interval, precision, minMove]);

  // Declared after the data effect so the bars are set first: every marker sits on one of them.
  useEffect(() => {
    markersRef.current = markers;
    handlesRef.current?.markers.setMarkers(markers);
  }, [markers, interval, precision, minMove]);

  return (
    <div
      ref={containerRef}
      className="h-[420px] w-full"
      role="img"
      aria-label={
        markers.length === 0
          ? "Candlestick price chart"
          : `Candlestick price chart with ${markers.length} marker${markers.length === 1 ? "" : "s"}`
      }
    />
  );
}
