"use client";

import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { useShallow } from "zustand/react/shallow";
import { StatusBadge } from "@/components/status/status-badge";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/feedback";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { quotes as quotesApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { SkipReason, UniverseEntry } from "@/lib/api/types.gen";
import {
  formatAge,
  formatCompact,
  formatInteger,
  formatPercent,
  formatPrice,
  formatSigned,
  priceChange,
} from "@/lib/format";
import { useNow } from "@/lib/hooks";
import { quoteKey, useLiveStore, useSocketStatus, useStaleAfterSeconds } from "@/lib/live/store";
import { quoteStatus } from "@/lib/status";
import { cn } from "@/lib/utils";
import type { LiveQuote } from "@/lib/ws/protocol";

export type QuotesByInstrument = Partial<Record<string, LiveQuote>>;

const SKIP_LABEL: Record<SkipReason, string> = {
  streaming_disabled: "Streaming off",
  no_enabled_account: "No enabled account",
  account_not_enabled: "Account disabled",
  not_listed: "Not listed",
  unsupported: "Unsupported",
};

/** Whether an entry streams, and why not. */
export function EntryStatusBadge({ entry }: { entry: UniverseEntry }) {
  if (entry.status === "PLANNED") {
    return (
      <Badge variant="outline" title={entry.streamed_by ? `Streamed by ${entry.streamed_by.label}` : undefined}>
        Streaming
      </Badge>
    );
  }
  if (entry.status === "WORKSPACE_DISABLED") {
    return (
      <Badge variant="secondary" title="The workspace is disabled, so nothing in it streams.">
        Workspace off
      </Badge>
    );
  }
  return (
    <Badge variant="warning" title={entry.detail ?? undefined}>
      {entry.skip_reason ? SKIP_LABEL[entry.skip_reason] : "Not streaming"}
    </Badge>
  );
}

/** The latest quote per instrument of a universe: pushed over the socket or read over REST, newest wins. */
export function useWorkspaceQuotes(slug: string, entries: readonly UniverseEntry[]): QuotesByInstrument {
  const socket = useSocketStatus("market");
  const rest = useQuery({
    queryKey: queryKeys.quotes(slug),
    queryFn: () => quotesApi.latest({ workspace: slug }),
    enabled: entries.length > 0,
    // The socket pushes every change; poll only while it is down so values are not frozen.
    refetchInterval: socket === "open" ? false : 15_000,
  });
  const live = useLiveStore(
    useShallow((state): (LiveQuote | undefined)[] =>
      entries.map((entry) => state.quotes[quoteKey(entry.provider, entry.instrument.id)]),
    ),
  );
  const restItems = rest.data?.items;
  return useMemo(() => {
    const fromRest = new Map((restItems ?? []).map((quote) => [quoteKey(quote.provider, quote.instrument_id), quote] as const));
    const result: QuotesByInstrument = {};
    entries.forEach((entry, index) => {
      const pushed = live[index];
      const read = fromRest.get(quoteKey(entry.provider, entry.instrument.id));
      const quote =
        pushed && read ? (Date.parse(read.received_at) > Date.parse(pushed.received_at) ? read : pushed) : (pushed ?? read);
      if (quote) result[entry.instrument.id] = quote;
    });
    return result;
  }, [entries, live, restItems]);
}

function Change({ quote }: { quote: LiveQuote | undefined }) {
  const change = priceChange(quote?.last_price, quote?.previous_close);
  if (!change) return <span className="text-muted-foreground">—</span>;
  return (
    <span className={cn(change.change > 0 && "text-emerald-300", change.change < 0 && "text-red-300")}>
      {formatSigned(change.change)} <span className="text-xs">({formatPercent(change.ratio)})</span>
    </span>
  );
}

export function QuoteTable({
  entries,
  quotes,
  selectedId,
  onSelect,
}: {
  entries: readonly UniverseEntry[];
  quotes: QuotesByInstrument;
  selectedId: string | null;
  onSelect: (instrumentId: string) => void;
}) {
  const now = useNow(1000);
  const socket = useSocketStatus("market");
  const staleAfter = useStaleAfterSeconds();
  if (entries.length === 0) {
    return (
      <EmptyState title="No instruments in this workspace">
        Add some under Universe below, or search with Ctrl+K.
      </EmptyState>
    );
  }
  return (
    <Table aria-label="Quotes">
      <TableHeader>
        <TableRow>
          <TableHead>Instrument</TableHead>
          <TableHead className="text-right">Last</TableHead>
          <TableHead className="text-right">Change</TableHead>
          <TableHead className="text-right">Bid</TableHead>
          <TableHead className="text-right">Ask</TableHead>
          <TableHead className="text-right">Volume</TableHead>
          <TableHead className="text-right">OI</TableHead>
          <TableHead className="text-right">Received</TableHead>
          <TableHead>Data</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {entries.map((entry) => {
          const { instrument } = entry;
          const quote = quotes[instrument.id];
          const status = quoteStatus(quote, now, staleAfter, socket);
          return (
            <TableRow
              key={instrument.id}
              data-selected={instrument.id === selectedId}
              className="cursor-pointer"
              onClick={() => onSelect(instrument.id)}
            >
              <TableCell>
                <button
                  type="button"
                  className="font-mono font-medium underline-offset-2 hover:underline"
                  aria-label={`Show ${instrument.symbol}`}
                  onClick={(event) => {
                    event.stopPropagation();
                    onSelect(instrument.id);
                  }}
                >
                  {instrument.symbol}
                </button>
                <span className="ml-1 text-xs text-muted-foreground">
                  {instrument.exchange} · {entry.provider}
                </span>
              </TableCell>
              <TableCell className="text-right font-mono tabular-nums">{formatPrice(quote?.last_price)}</TableCell>
              <TableCell className="text-right font-mono text-xs tabular-nums">
                <Change quote={quote} />
              </TableCell>
              <TableCell className="text-right font-mono text-xs tabular-nums">{formatPrice(quote?.bid)}</TableCell>
              <TableCell className="text-right font-mono text-xs tabular-nums">{formatPrice(quote?.ask)}</TableCell>
              <TableCell
                className="text-right font-mono text-xs tabular-nums"
                title={quote?.volume_semantics === "CUMULATIVE_DAY" ? "Day volume so far" : undefined}
              >
                {formatCompact(quote?.volume)}
              </TableCell>
              <TableCell className="text-right font-mono text-xs tabular-nums">
                {formatInteger(quote?.open_interest)}
              </TableCell>
              <TableCell className="text-right text-xs text-muted-foreground tabular-nums">
                {formatAge(quote?.received_at, now)}
              </TableCell>
              <TableCell>
                {entry.status === "PLANNED" ? <StatusBadge status={status} /> : <EntryStatusBadge entry={entry} />}
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}
