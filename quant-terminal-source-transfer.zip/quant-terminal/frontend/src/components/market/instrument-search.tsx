"use client";

import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { Fragment, useId, useMemo, useState, type KeyboardEvent, type ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/feedback";
import { Field, Input, NativeSelect } from "@/components/ui/input";
import { instruments as instrumentsApi, workspaces as workspacesApi, type InstrumentSearch } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type { Instrument, InstrumentHit, Provider, SubscriptionMode } from "@/lib/api/types.gen";
import { formatDate, formatInteger, formatPrice, humanize } from "@/lib/format";
import { useDebounced } from "@/lib/hooks";
import { useLiveSockets } from "@/lib/live/provider";
import { instrumentSubtitle, universeProblem } from "@/lib/universe";
import { cn, errorMessage } from "@/lib/utils";

const SEARCH_LIMIT = 20;

export function useInstrumentSearch(text: string, filters: Omit<InstrumentSearch, "q" | "limit"> = {}) {
  const q = useDebounced(text.trim(), 250);
  const params: InstrumentSearch = { ...filters, q, limit: SEARCH_LIMIT };
  return useQuery({
    queryKey: queryKeys.instrumentSearch(params),
    queryFn: ({ signal }) => instrumentsApi.search(params, signal),
    enabled: q.length > 0,
    staleTime: 60_000,
    placeholderData: keepPreviousData,
  });
}

/** A search box with a keyboard-navigable result list. */
export function InstrumentPicker({
  onPick,
  filters,
  autoFocus,
  placeholder = "Symbol, name or ISIN",
  renderAction,
}: {
  onPick: (hit: InstrumentHit) => void;
  filters?: Omit<InstrumentSearch, "q" | "limit">;
  autoFocus?: boolean;
  placeholder?: string;
  renderAction?: (hit: InstrumentHit) => ReactNode;
}) {
  const listId = useId();
  const [text, setText] = useState("");
  const [active, setActive] = useState(0);
  const search = useInstrumentSearch(text, filters);
  const hits = text.trim() ? (search.data?.items ?? []) : [];
  const current = Math.min(active, Math.max(hits.length - 1, 0));

  const onKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActive(Math.min(current + 1, hits.length - 1));
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setActive(Math.max(current - 1, 0));
    } else if (event.key === "Enter" && hits[current]) {
      event.preventDefault();
      onPick(hits[current]);
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="relative">
        <Input
          role="combobox"
          aria-label="Search instruments"
          aria-expanded={hits.length > 0}
          aria-controls={listId}
          aria-activedescendant={hits[current] ? `${listId}-${current}` : undefined}
          autoFocus={autoFocus}
          placeholder={placeholder}
          value={text}
          onChange={(event) => {
            setText(event.target.value);
            setActive(0);
          }}
          onKeyDown={onKeyDown}
        />
        {search.isFetching ? <Spinner className="absolute top-2.5 right-2.5 text-muted-foreground" /> : null}
      </div>
      {search.isError ? <p className="text-sm text-red-300">{errorMessage(search.error)}</p> : null}
      {text.trim() && search.isSuccess && hits.length === 0 ? (
        <p className="px-1 text-sm text-muted-foreground">No instruments match “{text.trim()}”.</p>
      ) : null}
      <ul id={listId} role="listbox" aria-label="Instruments" className="flex max-h-80 flex-col overflow-y-auto">
        {hits.map((hit, index) => (
          <li
            key={hit.instrument.id}
            id={`${listId}-${index}`}
            role="option"
            aria-selected={index === current}
            onMouseEnter={() => setActive(index)}
            className={cn(
              "flex cursor-pointer items-center gap-3 rounded-md px-2 py-1.5",
              index === current && "bg-accent",
              !hit.instrument.is_active && "opacity-60",
            )}
            onClick={() => onPick(hit)}
          >
            <div className="min-w-0 flex-1">
              <p className="truncate font-mono text-sm font-medium">{hit.instrument.symbol}</p>
              <p className="truncate text-xs text-muted-foreground">{instrumentSubtitle(hit.instrument) || "\u00a0"}</p>
            </div>
            <span className="shrink-0 text-xs text-muted-foreground">
              {hit.instrument.exchange} · {humanize(hit.instrument.instrument_type)}
            </span>
            <span className="flex shrink-0 gap-1">
              {hit.providers.map((provider) => (
                <Badge key={provider} variant="outline">
                  {provider}
                </Badge>
              ))}
            </span>
            {renderAction ? renderAction(hit) : null}
          </li>
        ))}
      </ul>
      {search.data?.has_more && hits.length > 0 ? (
        <p className="px-1 text-xs text-muted-foreground">Showing the first {SEARCH_LIMIT}; type more to narrow it down.</p>
      ) : null}
    </div>
  );
}

export function InstrumentInfo({ instrument }: { instrument: Instrument }) {
  const rows: [string, ReactNode][] = [
    ["Key", <span key="key" className="font-mono text-xs break-all">{instrument.canonical_key}</span>],
    ["Exchange", `${instrument.exchange} · ${humanize(instrument.segment)}`],
    ["Type", humanize(instrument.instrument_type)],
    ["Name", instrument.name],
    ["Underlying", instrument.underlying],
    ["Expiry", instrument.expiry ? formatDate(instrument.expiry) : null],
    ["Strike", instrument.strike ? formatPrice(instrument.strike) : null],
    ["Option", instrument.option_type],
    ["Lot size", instrument.lot_size === null ? null : formatInteger(instrument.lot_size)],
    ["Tick size", instrument.tick_size],
    ["Currency", instrument.currency],
    ["ISIN", instrument.isin],
    ["Status", instrument.is_active ? "Active" : "Inactive (delisted or expired)"],
  ];
  return (
    <dl className="grid grid-cols-[max-content_1fr] gap-x-4 gap-y-1 text-sm">
      {rows
        .filter(([, value]) => value !== null && value !== undefined && value !== "")
        .map(([label, value]) => (
          <Fragment key={label}>
            <dt className="text-muted-foreground">{label}</dt>
            <dd className="min-w-0">{value}</dd>
          </Fragment>
        ))}
    </dl>
  );
}

export const SUBSCRIPTION_MODES: { value: SubscriptionMode; label: string }[] = [
  { value: "LTP", label: "LTP: last price only" },
  { value: "QUOTE", label: "Quote: prices and volume" },
  { value: "FULL", label: "Full: quote and market depth" },
];

/** Adds one instrument to a workspace's universe, streamed from the chosen provider. */
export function AddToWorkspace({ hit, onAdded }: { hit: InstrumentHit; onAdded?: () => void }) {
  const sockets = useLiveSockets();
  const list = useQuery({ queryKey: queryKeys.workspaces, queryFn: workspacesApi.list });
  const options = useMemo(
    () =>
      (list.data ?? [])
        .map((workspace) => ({ workspace, problem: universeProblem(workspace.accepts, hit.instrument) }))
        .sort(
          (a, b) =>
            Number(a.problem !== null) - Number(b.problem !== null) || a.workspace.sort_order - b.workspace.sort_order,
        ),
    [list.data, hit.instrument],
  );
  const [picked, setPicked] = useState("");
  const [provider, setProvider] = useState<Provider | "">(hit.providers[0] ?? "");
  const [mode, setMode] = useState<SubscriptionMode>("QUOTE");
  const slug = picked || options.find((option) => option.problem === null)?.workspace.slug || "";
  const problem = options.find((option) => option.workspace.slug === slug)?.problem ?? null;

  const add = useApiMutation({
    mutationFn: () => {
      if (!provider) throw new Error("Choose a provider");
      return workspacesApi.addInstruments(slug, { instruments: [hit.instrument.id], provider, mode });
    },
    invalidate: [queryKeys.workspaces],
    success: (change) =>
      change.added.length > 0
        ? `Added ${hit.instrument.symbol} to ${change.workspace.name}`
        : change.changed.length > 0
          ? `${hit.instrument.symbol} now streams from ${provider} in ${change.workspace.name}`
          : `${hit.instrument.symbol} is already in ${change.workspace.name}`,
    errorTitle: `Could not add ${hit.instrument.symbol}`,
    onSuccess: () => {
      // The open quote subscription only covers the universe as it was when it was made.
      sockets.market.resubscribe("quotes");
      onAdded?.();
    },
  });

  if (hit.providers.length === 0) {
    return <p className="text-sm text-muted-foreground">No connected provider lists this instrument.</p>;
  }
  return (
    <form
      className="grid gap-3 sm:grid-cols-3"
      onSubmit={(event) => {
        event.preventDefault();
        add.mutate();
      }}
    >
      <Field label="Workspace" htmlFor="add-workspace" error={problem ? `This workspace ${problem}.` : undefined}>
        <NativeSelect id="add-workspace" value={slug} onChange={(event) => setPicked(event.target.value)}>
          {options.length === 0 ? <option value="">Loading…</option> : null}
          {options.map(({ workspace, problem: reason }) => (
            <option key={workspace.id} value={workspace.slug}>
              {workspace.name}
              {reason ? ` (${reason})` : ""}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="Provider" htmlFor="add-provider">
        <NativeSelect
          id="add-provider"
          value={provider}
          onChange={(event) => setProvider(event.target.value as Provider)}
        >
          {hit.providers.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="Data" htmlFor="add-mode">
        <NativeSelect id="add-mode" value={mode} onChange={(event) => setMode(event.target.value as SubscriptionMode)}>
          {SUBSCRIPTION_MODES.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <div className="sm:col-span-3">
        <Button type="submit" disabled={!slug || !provider || add.isPending}>
          {add.isPending ? <Spinner /> : null}
          Add to workspace
        </Button>
      </div>
    </form>
  );
}
