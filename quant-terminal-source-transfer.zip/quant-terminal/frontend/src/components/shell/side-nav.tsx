"use client";

import { useQuery } from "@tanstack/react-query";
import { Activity, ChartCandlestick, FlaskConical, LayoutDashboard, PlugZap, Radio } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { Spinner } from "@/components/ui/feedback";
import { workspaces as workspacesApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { MarketRegion, WorkspaceView } from "@/lib/api/types.gen";
import { cn } from "@/lib/utils";

const REGIONS: { region: MarketRegion; label: string }[] = [
  { region: "INDIA", label: "India" },
  { region: "FOREX", label: "Forex" },
  { region: "CRYPTO", label: "Crypto" },
  { region: "LAB", label: "Simulation lab" },
];

const PAGES = [
  { href: "/", label: "Overview", icon: LayoutDashboard },
  { href: "/signals", label: "Signals", icon: Radio },
  { href: "/strategies", label: "Strategy lab", icon: FlaskConical },
  { href: "/providers", label: "Providers", icon: PlugZap },
  { href: "/system", label: "System", icon: Activity },
];

function NavLink({ href, active, children, muted }: { href: string; active: boolean; children: ReactNode; muted?: boolean }) {
  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      className={cn(
        "flex items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors hover:bg-accent [&_svg]:size-4 [&_svg]:shrink-0",
        active ? "bg-accent font-medium text-foreground" : "text-muted-foreground",
        muted && !active && "opacity-60",
      )}
    >
      {children}
    </Link>
  );
}

function WorkspaceLink({ workspace, active }: { workspace: WorkspaceView; active: boolean }) {
  return (
    <NavLink href={`/workspaces/${encodeURIComponent(workspace.slug)}`} active={active} muted={!workspace.is_enabled}>
      <span
        aria-hidden
        className={cn("size-1.5 shrink-0 rounded-full", workspace.is_enabled ? "bg-emerald-400" : "bg-zinc-600")}
      />
      <span className="min-w-0 flex-1 truncate">{workspace.name}</span>
      <span className="text-[11px] tabular-nums text-muted-foreground" title="Instruments in the universe">
        {workspace.instrument_count}
      </span>
      {workspace.is_enabled ? null : <span className="sr-only">(disabled)</span>}
    </NavLink>
  );
}

export function SideNav() {
  const pathname = usePathname();
  const list = useQuery({ queryKey: queryKeys.workspaces, queryFn: workspacesApi.list });
  const sorted = [...(list.data ?? [])].sort((a, b) => a.sort_order - b.sort_order || a.name.localeCompare(b.name));

  return (
    <aside className="flex w-60 shrink-0 flex-col border-r bg-card/40">
      <div className="flex h-12 items-center gap-2 border-b px-3">
        <ChartCandlestick className="size-5 text-primary" aria-hidden />
        <span className="font-semibold tracking-tight">Quant Terminal</span>
      </div>
      <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto p-2">
        <nav aria-label="Main" className="flex flex-col gap-0.5">
          {PAGES.map(({ href, label, icon: Icon }) => (
            <NavLink key={href} href={href} active={href === "/" ? pathname === "/" : pathname.startsWith(href)}>
              <Icon aria-hidden />
              {label}
            </NavLink>
          ))}
        </nav>
        <nav aria-label="Workspaces" className="flex flex-col gap-3">
          {list.isPending ? (
            <div className="flex items-center gap-2 px-2 text-xs text-muted-foreground">
              <Spinner className="size-3" /> Loading workspaces…
            </div>
          ) : list.isError ? (
            <p className="px-2 text-xs text-red-300">Workspaces could not be loaded.</p>
          ) : (
            REGIONS.map(({ region, label }) => {
              const items = sorted.filter((workspace) => workspace.market_region === region);
              if (items.length === 0) return null;
              return (
                <div key={region} className="flex flex-col gap-0.5">
                  <p className="px-2 pb-1 text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">
                    {label}
                  </p>
                  {items.map((workspace) => (
                    <WorkspaceLink
                      key={workspace.id}
                      workspace={workspace}
                      active={pathname === `/workspaces/${encodeURIComponent(workspace.slug)}`}
                    />
                  ))}
                </div>
              );
            })
          )}
        </nav>
      </div>
    </aside>
  );
}
