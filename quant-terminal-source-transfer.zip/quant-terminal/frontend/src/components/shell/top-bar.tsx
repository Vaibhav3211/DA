"use client";

import { useQuery } from "@tanstack/react-query";
import { CircleUser, LogOut, Search, TriangleAlert } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { AddToWorkspace, InstrumentInfo, InstrumentPicker } from "@/components/market/instrument-search";
import { StatusBadge } from "@/components/status/status-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Disclosure } from "@/components/ui/disclosure";
import { isUnauthorized } from "@/lib/api/client";
import { auth, providers as providersApi, system as systemApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { InstrumentHit } from "@/lib/api/types.gen";
import { useLiveStore, useSocketStatus, type SocketName } from "@/lib/live/store";
import { notify } from "@/lib/notifications";
import { effectiveStatus } from "@/lib/status";
import { cn, errorMessage } from "@/lib/utils";
import type { SocketStatus } from "@/lib/ws/socket";
import { NotificationBell } from "./notifications";

export const SOCKET_LABEL: Record<SocketName, string> = {
  market: "Market data",
  signals: "Signals",
  system: "System status",
};

const SOCKET_DOT: Record<SocketStatus, string> = {
  idle: "bg-zinc-500",
  connecting: "animate-pulse bg-sky-400",
  open: "bg-emerald-400",
  reconnecting: "animate-pulse bg-amber-400",
  closed: "bg-red-500",
  unauthorized: "bg-red-500",
};

export function useSystemHealth() {
  return useQuery({ queryKey: queryKeys.health, queryFn: systemApi.health, refetchInterval: 30_000 });
}

function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [picked, setPicked] = useState<InstrumentHit | null>(null);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const onOpenChange = (next: boolean) => {
    setOpen(next);
    if (!next) setPicked(null);
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="w-72 justify-start text-muted-foreground"
        onClick={() => setOpen(true)}
        aria-keyshortcuts="Control+K"
      >
        <Search className="size-4" />
        Search instruments…
        <kbd className="ml-auto rounded border px-1 font-mono text-[10px]">Ctrl K</kbd>
      </Button>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{picked ? picked.instrument.symbol : "Search instruments"}</DialogTitle>
            <DialogDescription>
              {picked
                ? "Instrument details. Add it to a workspace to stream it."
                : "Find an instrument by symbol, name or ISIN. Use the arrow keys and Enter to pick one."}
            </DialogDescription>
          </DialogHeader>
          {picked ? (
            <div className="flex flex-col gap-4">
              <InstrumentInfo instrument={picked.instrument} />
              <AddToWorkspace key={picked.instrument.id} hit={picked} onAdded={() => onOpenChange(false)} />
              <Button variant="ghost" size="sm" className="w-fit" onClick={() => setPicked(null)}>
                ← Back to results
              </Button>
            </div>
          ) : (
            <InstrumentPicker autoFocus onPick={setPicked} />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

function ProviderStatus() {
  const list = useQuery({ queryKey: queryKeys.providers, queryFn: providersApi.list, refetchInterval: 30_000 });
  const feed = useLiveStore((state) => state.feed);
  const market = useSocketStatus("market");
  const configured = (list.data ?? []).filter((summary) => summary.accounts.length > 0);

  return (
    <Link
      href="/providers"
      title="Provider feeds: open the provider page"
      className="flex items-center gap-3 rounded-md px-2 py-1 text-xs hover:bg-accent"
    >
      {list.isSuccess && configured.length === 0 ? (
        <span className="text-muted-foreground">No provider accounts</span>
      ) : null}
      {configured.map((summary) => {
        const status = effectiveStatus(feed?.providers[summary.provider] ?? summary.data_status, market);
        const attention = summary.accounts.filter(
          (account) => account.is_enabled && (account.status === "AUTH_REQUIRED" || account.status === "NEEDS_CREDENTIALS"),
        );
        return (
          <span key={summary.provider} className="flex items-center gap-1.5">
            <span className="text-muted-foreground">{summary.display_name}</span>
            <StatusBadge status={status} />
            {attention.length > 0 ? (
              <span title={`${attention.map((account) => account.label).join(", ")} needs sign-in or credentials`}>
                <TriangleAlert aria-hidden className="size-3.5 text-amber-300" />
                <span className="sr-only">An account needs attention</span>
              </span>
            ) : null}
          </span>
        );
      })}
    </Link>
  );
}

function SocketStatusDots() {
  const sockets = useLiveStore((state) => state.sockets);
  const names = Object.keys(SOCKET_LABEL) as SocketName[];
  const allOpen = names.every((name) => sockets[name] === "open");
  const summary = names.map((name) => `${SOCKET_LABEL[name]}: ${sockets[name]}`).join("\n");
  return (
    <span className="flex items-center gap-1.5 px-2 text-xs text-muted-foreground" title={summary} role="status">
      {names.map((name) => (
        <span key={name} aria-hidden className={cn("size-2 rounded-full", SOCKET_DOT[sockets[name]])} />
      ))}
      <span>{allOpen ? "Streaming" : "Live updates degraded"}</span>
      <span className="sr-only">{summary}</span>
    </span>
  );
}

const HEALTH_STYLE = {
  ok: { label: "Healthy", dot: "bg-emerald-400" },
  degraded: { label: "Degraded", dot: "bg-amber-400" },
  down: { label: "Down", dot: "bg-red-500" },
} as const;

function HealthIndicator() {
  const health = useSystemHealth();
  const data = health.data;
  const style = data ? HEALTH_STYLE[data.status] : null;
  return (
    <span className="flex items-center gap-1">
      <Link href="/system" className="flex items-center gap-1.5 rounded-md px-2 py-1 text-xs hover:bg-accent">
        <span aria-hidden className={cn("size-2 rounded-full", style?.dot ?? (health.isError ? "bg-red-500" : "bg-zinc-500"))} />
        System {style ? style.label.toLowerCase() : health.isError ? "unreachable" : "checking"}
      </Link>
      {data?.simulated_mode ? <StatusBadge status="SIMULATED" title="The API runs in simulated mode" /> : null}
      {data?.kill_switch?.engaged ? (
        <Badge variant="destructive" title={data.kill_switch.reason ?? undefined}>
          KILL SWITCH
        </Badge>
      ) : null}
    </span>
  );
}

function UserMenu({ username }: { username: string }) {
  const [busy, setBusy] = useState(false);
  const signOut = async () => {
    setBusy(true);
    try {
      await auth.logout();
    } catch (error) {
      // 401: the session had already ended. Anything else leaves the session cookie valid.
      if (!isUnauthorized(error)) {
        notify("error", "Sign-out failed", errorMessage(error));
        setBusy(false);
        return;
      }
    }
    // A full load drops every cached query, the live store and the sockets.
    window.location.assign("/login");
  };
  return (
    <Disclosure
      label="Account menu"
      panelClassName="w-60"
      button={
        <>
          <CircleUser className="size-4" />
          <span className="max-w-32 truncate">{username}</span>
        </>
      }
    >
      {(close) => (
        <div className="flex flex-col gap-0.5 text-sm">
          <p className="px-2 py-1 text-xs text-muted-foreground">
            Signed in as <span className="font-medium text-foreground">{username}</span>
          </p>
          <Link href="/providers" onClick={close} className="rounded-md px-2 py-1.5 hover:bg-accent">
            Provider accounts
          </Link>
          <Link href="/system" onClick={close} className="rounded-md px-2 py-1.5 hover:bg-accent">
            System, risk and kill switch
          </Link>
          <Button variant="ghost" size="sm" className="justify-start" disabled={busy} onClick={() => void signOut()}>
            <LogOut className="size-4" />
            Sign out
          </Button>
        </div>
      )}
    </Disclosure>
  );
}

export function TopBar({ username }: { username: string }) {
  return (
    <header className="flex h-12 shrink-0 items-center gap-2 border-b bg-card/40 px-3">
      <GlobalSearch />
      <div className="ml-auto flex items-center gap-1">
        <ProviderStatus />
        <SocketStatusDots />
        <HealthIndicator />
        <NotificationBell />
        <UserMenu username={username} />
      </div>
    </header>
  );
}
