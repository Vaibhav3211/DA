"use client";

import { Bell, CircleAlert, CircleCheck, Info, TriangleAlert, X } from "lucide-react";
import { useEffect } from "react";
import { useShallow } from "zustand/react/shallow";
import { Button } from "@/components/ui/button";
import { Disclosure } from "@/components/ui/disclosure";
import { useNow } from "@/lib/hooks";
import { useNotifications, type Notice, type NoticeTone } from "@/lib/notifications";
import { cn } from "@/lib/utils";

const TONE: Record<NoticeTone, { icon: typeof Info; className: string }> = {
  info: { icon: Info, className: "text-sky-300" },
  success: { icon: CircleCheck, className: "text-emerald-300" },
  warning: { icon: TriangleAlert, className: "text-amber-200" },
  error: { icon: CircleAlert, className: "text-red-300" },
};

const TOAST_MS: Record<NoticeTone, number> = { info: 6000, success: 5000, warning: 10000, error: 12000 };
const MAX_TOASTS = 4;

function NoticeBody({ notice }: { notice: Notice }) {
  const { icon: Icon, className } = TONE[notice.tone];
  return (
    <div className="flex min-w-0 gap-2">
      <Icon aria-hidden className={cn("mt-0.5 size-4 shrink-0", className)} />
      <div className="min-w-0">
        <p className="text-sm font-medium break-words">{notice.title}</p>
        {notice.description ? <p className="text-xs break-words text-muted-foreground">{notice.description}</p> : null}
      </div>
    </div>
  );
}

function Toast({ notice }: { notice: Notice }) {
  const dismiss = useNotifications((state) => state.dismissToast);
  useEffect(() => {
    const timer = setTimeout(() => dismiss(notice.id), TOAST_MS[notice.tone]);
    return () => clearTimeout(timer);
  }, [dismiss, notice.id, notice.tone]);
  return (
    <div
      role={notice.tone === "error" ? "alert" : "status"}
      className="pointer-events-auto flex w-80 items-start justify-between gap-2 rounded-md border bg-popover p-3 shadow-xl"
    >
      <NoticeBody notice={notice} />
      <button
        type="button"
        aria-label="Dismiss"
        onClick={() => dismiss(notice.id)}
        className="text-muted-foreground hover:text-foreground"
      >
        <X className="size-4" />
      </button>
    </div>
  );
}

export function Toaster() {
  const toasts = useNotifications(useShallow((state) => state.notices.filter((n) => n.toast).slice(0, MAX_TOASTS)));
  return (
    <div aria-live="polite" className="pointer-events-none fixed right-4 bottom-4 z-[60] flex flex-col-reverse gap-2">
      {toasts.map((notice) => (
        <Toast key={notice.id} notice={notice} />
      ))}
    </div>
  );
}

function ago(at: number, now: number): string {
  const seconds = Math.max(0, Math.round((now - at) / 1000));
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  return `${Math.floor(seconds / 3600)}h`;
}

export function NotificationBell() {
  const notices = useNotifications((state) => state.notices);
  const markAllRead = useNotifications((state) => state.markAllRead);
  const clear = useNotifications((state) => state.clear);
  const unread = notices.filter((n) => !n.read).length;
  const now = useNow(15_000);
  return (
    <Disclosure
      label={unread ? `Notifications, ${unread} unread` : "Notifications"}
      onOpen={markAllRead}
      panelClassName="w-96"
      button={
        <span className="relative">
          <Bell className="size-4" />
          {unread ? (
            <span className="absolute -top-1.5 -right-2 rounded-full bg-red-500 px-1 text-[10px] leading-4 font-semibold text-white">
              {unread > 99 ? "99+" : unread}
            </span>
          ) : null}
        </span>
      }
    >
      {() => (
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between px-1">
            <p className="text-sm font-semibold">Notifications</p>
            <Button variant="ghost" size="sm" onClick={clear} disabled={notices.length === 0}>
              Clear
            </Button>
          </div>
          {notices.length === 0 ? (
            <p className="px-1 pb-2 text-sm text-muted-foreground">Nothing yet.</p>
          ) : (
            <ul className="flex max-h-96 flex-col divide-y overflow-y-auto">
              {notices.map((notice) => (
                <li key={notice.id} className="flex items-start justify-between gap-2 px-1 py-2">
                  <NoticeBody notice={notice} />
                  <span className="shrink-0 text-[11px] text-muted-foreground">{ago(notice.at, now)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </Disclosure>
  );
}
