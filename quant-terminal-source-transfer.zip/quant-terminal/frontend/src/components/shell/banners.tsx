"use client";

import { FlaskConical, OctagonAlert, TriangleAlert, WifiOff } from "lucide-react";
import Link from "next/link";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { formatDateTime } from "@/lib/format";
import { useLiveSockets } from "@/lib/live/provider";
import { useLiveStore, type SocketName } from "@/lib/live/store";
import { cn } from "@/lib/utils";
import { SOCKET_LABEL, useSystemHealth } from "./top-bar";

const TONES = {
  simulated: "stripes border-fuchsia-500/60 bg-fuchsia-950/80 text-fuchsia-100",
  danger: "border-red-500/60 bg-red-950/80 text-red-100",
  warning: "border-amber-500/60 bg-amber-950/70 text-amber-100",
} as const;

function Banner({ tone, icon, children }: { tone: keyof typeof TONES; icon: ReactNode; children: ReactNode }) {
  return (
    <div
      role={tone === "warning" ? "status" : "alert"}
      className={cn("flex items-center gap-2 border-b px-4 py-1.5 text-sm [&_svg]:size-4 [&_svg]:shrink-0", TONES[tone])}
    >
      {icon}
      <div className="flex min-w-0 flex-1 flex-wrap items-center gap-x-2">{children}</div>
    </div>
  );
}

export function Banners() {
  const health = useSystemHealth().data;
  const sockets = useLiveStore((state) => state.sockets);
  const live = useLiveSockets();
  const critical = health?.alerts.filter((alert) => alert.severity === "critical") ?? [];
  const down = (Object.keys(SOCKET_LABEL) as SocketName[]).filter(
    (name) => sockets[name] === "reconnecting" || sockets[name] === "closed",
  );
  const killSwitch = health?.kill_switch;

  return (
    <>
      {health?.simulated_mode ? (
        <Banner tone="simulated" icon={<FlaskConical />}>
          <strong className="tracking-wide">SIMULATED MODE</strong>
          <span>Prices come from the simulator, not from a market. Nothing on screen is live.</span>
        </Banner>
      ) : null}
      {killSwitch?.engaged ? (
        <Banner tone="danger" icon={<OctagonAlert />}>
          <strong>Kill switch engaged.</strong>
          {killSwitch.reason ? <span>{killSwitch.reason}</span> : null}
          <span className="text-red-200/80">
            {killSwitch.updated_by ? `By ${killSwitch.updated_by}` : null}
            {killSwitch.updated_at ? ` at ${formatDateTime(killSwitch.updated_at)}` : null}
          </span>
          <Link href="/system" className="ml-auto underline underline-offset-2">
            Manage
          </Link>
        </Banner>
      ) : null}
      {critical.length > 0 ? (
        <Banner tone="danger" icon={<TriangleAlert />}>
          <span>{critical[0].message}</span>
          {critical.length > 1 ? <span>and {critical.length - 1} more critical alerts.</span> : null}
          <Link href="/system" className="ml-auto underline underline-offset-2">
            Details
          </Link>
        </Banner>
      ) : null}
      {down.length > 0 ? (
        <Banner tone="warning" icon={<WifiOff />}>
          <span>
            Live updates interrupted ({down.map((name) => SOCKET_LABEL[name]).join(", ")}). Figures on screen may be
            out of date.
          </span>
          <Button
            size="sm"
            variant="outline"
            className="ml-auto h-7"
            onClick={() => {
              for (const name of down) live[name].retryNow();
            }}
          >
            Reconnect now
          </Button>
        </Banner>
      ) : null}
    </>
  );
}
