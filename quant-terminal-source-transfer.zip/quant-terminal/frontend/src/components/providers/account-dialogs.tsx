"use client";

import { Plus } from "lucide-react";
import { useId, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Spinner } from "@/components/ui/feedback";
import { Field, Input, Label, NativeSelect } from "@/components/ui/input";
import { accounts as accountsApi, providers as providersApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type {
  AccountUpdate,
  AuthMethod,
  CredentialKind,
  GrowwConnectRequest,
  Provider,
  ProviderAccountView,
} from "@/lib/api/types.gen";
import { formatDateTime } from "@/lib/format";
import { notify } from "@/lib/notifications";
import {
  AUTH_METHOD_HINT,
  AUTH_METHOD_LABEL,
  AUTH_METHODS,
  credentialLabel,
  credentialRows,
  filledCredentials,
  growwConnectBody,
  growwModes,
  isTotpCode,
  labelError,
  normalizeLabel,
  zerodhaCallbackUrl,
  type CredentialRow,
  type GrowwMode,
} from "@/lib/providers";
import { cn } from "@/lib/utils";

/** Account changes can move feeds, and universes name the streaming account, so they refresh too. */
export const ACCOUNT_QUERIES = [queryKeys.providers, queryKeys.accounts, queryKeys.workspaces] as const;

interface DialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type ProviderName = (provider: Provider) => string;

// ---- create ------------------------------------------------------------------------------------

export function CreateAccountDialog({ providers, displayName }: { providers: readonly Provider[]; displayName: ProviderName }) {
  const [open, setOpen] = useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" disabled={providers.length === 0}>
          <Plus aria-hidden className="size-4" />
          Add account
        </Button>
      </DialogTrigger>
      <DialogContent>
        <CreateAccountForm providers={providers} displayName={displayName} onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

function CreateAccountForm({
  providers,
  displayName,
  onDone,
}: {
  providers: readonly Provider[];
  displayName: ProviderName;
  onDone: () => void;
}) {
  const providerId = useId();
  const labelId = useId();
  const methodId = useId();
  const first: Provider = providers[0] ?? "ZERODHA";
  const [provider, setProvider] = useState<Provider>(first);
  const [method, setMethod] = useState<AuthMethod>(AUTH_METHODS[first][0]);
  const [label, setLabel] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const error = submitted ? labelError(label) : null;
  const methods = AUTH_METHODS[provider];

  const create = useApiMutation({
    mutationFn: () => accountsApi.create({ provider, label: normalizeLabel(label), auth_method: method }),
    invalidate: ACCOUNT_QUERIES,
    success: (view) =>
      view.missing_credentials.length > 0
        ? `Added ${view.label}; add its credentials next`
        : `Added ${view.label}; sign in next`,
    errorTitle: "Could not add the account",
    onSuccess: onDone,
  });

  return (
    <form
      className="flex flex-col gap-4"
      noValidate
      onSubmit={(event) => {
        event.preventDefault();
        setSubmitted(true);
        if (labelError(label) === null) create.mutate();
      }}
    >
      <DialogHeader>
        <DialogTitle>Add a provider account</DialogTitle>
        <DialogDescription>
          New accounts start disabled: add credentials, sign in, then enable the account to stream.
        </DialogDescription>
      </DialogHeader>
      <Field label="Provider" htmlFor={providerId}>
        <NativeSelect
          id={providerId}
          value={provider}
          onChange={(event) => {
            const next = event.target.value as Provider;
            setProvider(next);
            setMethod(AUTH_METHODS[next][0]);
          }}
        >
          {providers.map((option) => (
            <option key={option} value={option}>
              {displayName(option)}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="Label" htmlFor={labelId} hint="How the terminal names this account, for example 'Main'." error={error}>
        <Input
          id={labelId}
          value={label}
          maxLength={80}
          autoComplete="off"
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? `${labelId}-error` : undefined}
          onChange={(event) => setLabel(event.target.value)}
        />
      </Field>
      {methods.length > 1 ? (
        <Field label="Sign-in method" htmlFor={methodId} hint={AUTH_METHOD_HINT[method]}>
          <NativeSelect id={methodId} value={method} onChange={(event) => setMethod(event.target.value as AuthMethod)}>
            {methods.map((option) => (
              <option key={option} value={option}>
                {AUTH_METHOD_LABEL[option]}
              </option>
            ))}
          </NativeSelect>
        </Field>
      ) : (
        <p className="text-xs text-muted-foreground">{AUTH_METHOD_HINT[method]}</p>
      )}
      <DialogFooter>
        <Button type="button" variant="ghost" onClick={onDone}>
          Cancel
        </Button>
        <Button type="submit" disabled={create.isPending}>
          {create.isPending ? <Spinner /> : null}
          Add account
        </Button>
      </DialogFooter>
    </form>
  );
}

// ---- edit --------------------------------------------------------------------------------------

export function EditAccountDialog({ account, open, onOpenChange }: { account: ProviderAccountView } & DialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <EditAccountForm account={account} onDone={() => onOpenChange(false)} />
      </DialogContent>
    </Dialog>
  );
}

function EditAccountForm({ account, onDone }: { account: ProviderAccountView; onDone: () => void }) {
  const labelId = useId();
  const methodId = useId();
  const [label, setLabel] = useState(account.label);
  const [method, setMethod] = useState<AuthMethod>(account.auth_method);
  const [submitted, setSubmitted] = useState(false);
  const error = submitted ? labelError(label) : null;
  const methods = AUTH_METHODS[account.provider];
  const cleaned = normalizeLabel(label);
  const changes: AccountUpdate = {
    ...(cleaned !== account.label ? { label: cleaned } : {}),
    ...(method !== account.auth_method ? { auth_method: method } : {}),
  };
  const changed = Object.keys(changes).length > 0;

  const update = useApiMutation({
    mutationFn: (body: AccountUpdate) => accountsApi.update(account.id, body),
    invalidate: ACCOUNT_QUERIES,
    success: (view) => `Saved ${view.label}`,
    errorTitle: "Could not save the account",
    onSuccess: onDone,
  });

  return (
    <form
      className="flex flex-col gap-4"
      noValidate
      onSubmit={(event) => {
        event.preventDefault();
        setSubmitted(true);
        if (labelError(label) === null && changed) update.mutate(changes);
      }}
    >
      <DialogHeader>
        <DialogTitle>{`Edit ${account.label}`}</DialogTitle>
        <DialogDescription>Renaming or switching the sign-in method keeps the current session.</DialogDescription>
      </DialogHeader>
      <Field label="Label" htmlFor={labelId} error={error}>
        <Input
          id={labelId}
          value={label}
          maxLength={80}
          autoComplete="off"
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? `${labelId}-error` : undefined}
          onChange={(event) => setLabel(event.target.value)}
        />
      </Field>
      {methods.length > 1 ? (
        <Field label="Sign-in method" htmlFor={methodId} hint={AUTH_METHOD_HINT[method]}>
          <NativeSelect id={methodId} value={method} onChange={(event) => setMethod(event.target.value as AuthMethod)}>
            {methods.map((option) => (
              <option key={option} value={option}>
                {AUTH_METHOD_LABEL[option]}
              </option>
            ))}
          </NativeSelect>
        </Field>
      ) : null}
      <DialogFooter>
        <Button type="button" variant="ghost" onClick={onDone}>
          Cancel
        </Button>
        <Button type="submit" disabled={!changed || update.isPending}>
          {update.isPending ? <Spinner /> : null}
          Save
        </Button>
      </DialogFooter>
    </form>
  );
}

// ---- credentials -------------------------------------------------------------------------------

export function CredentialsDialog({ account, open, onOpenChange }: { account: ProviderAccountView } & DialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <CredentialsForm account={account} onDone={() => onOpenChange(false)} />
      </DialogContent>
    </Dialog>
  );
}

function storedText(row: CredentialRow): { text: string; className: string; title?: string } {
  const masked = row.masked ? ` · ${row.masked}` : "";
  if (row.origin === "ACCOUNT") return { text: `Stored${masked}`, className: "text-emerald-300" };
  if (row.origin === "ENVIRONMENT") {
    return {
      text: `From the server's .env${masked}`,
      className: "text-sky-300",
      title: "A value saved here overrides it for this account",
    };
  }
  return row.required
    ? { text: "Missing", className: "text-amber-300" }
    : { text: "Not set", className: "text-muted-foreground" };
}

function ZerodhaRedirectHint() {
  const origin = typeof window === "undefined" ? "" : window.location.origin;
  return (
    <p className="rounded-md border border-sky-500/30 bg-sky-500/10 p-2 text-xs text-sky-100">
      Register <code className="font-mono break-all">{zerodhaCallbackUrl(origin)}</code> as the Kite Connect
      app&apos;s redirect URL, and set the same address as the server&apos;s ZERODHA_REDIRECT_URL.
    </p>
  );
}

function CredentialsForm({ account, onDone }: { account: ProviderAccountView; onDone: () => void }) {
  const baseId = useId();
  const [values, setValues] = useState<Partial<Record<CredentialKind, string>>>({});
  const [confirming, setConfirming] = useState<CredentialKind | null>(null);
  const rows = credentialRows(account);
  const filled = filledCredentials(values);
  const hasValues = Object.keys(filled).length > 0;

  const save = useApiMutation({
    mutationFn: (body: Partial<Record<CredentialKind, string>>) => accountsApi.setCredentials(account.id, body),
    invalidate: ACCOUNT_QUERIES,
    success: null,
    errorTitle: "Could not save the credentials",
    onSuccess: (view) => {
      const ended = account.has_access_token && !view.has_access_token;
      notify(
        ended ? "warning" : "success",
        `Saved the credentials of ${view.label}`,
        ended ? "The API key changed, so the Kite session ended. Sign in again." : null,
      );
      onDone();
    },
  });
  const clear = useApiMutation({
    mutationFn: (kind: CredentialKind) => accountsApi.clearCredential(account.id, kind),
    invalidate: ACCOUNT_QUERIES,
    success: null,
    errorTitle: "Could not remove the credential",
    onSuccess: (view, kind) => {
      setConfirming(null);
      const ended = account.has_access_token && !view.has_access_token;
      notify(
        ended ? "warning" : "success",
        `Removed the ${credentialLabel(view.auth_method, kind)} of ${view.label}`,
        ended ? "The Kite session ended with the API key." : null,
      );
    },
  });

  return (
    <form
      className="flex flex-col gap-4"
      onSubmit={(event) => {
        event.preventDefault();
        if (hasValues) save.mutate(filled);
      }}
    >
      <DialogHeader>
        <DialogTitle>{`Credentials of ${account.label}`}</DialogTitle>
        <DialogDescription>
          Values are encrypted on the server and never shown again; API keys appear masked. Leave a field empty to keep
          what is stored.
        </DialogDescription>
      </DialogHeader>
      {account.provider === "ZERODHA" ? <ZerodhaRedirectHint /> : null}
      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          {`The ${AUTH_METHOD_LABEL[account.auth_method].toLowerCase()} method stores no credentials; sign in from the account instead.`}
        </p>
      ) : null}
      {rows.map((row) => {
        const id = `${baseId}-${row.kind}`;
        const stored = storedText(row);
        return (
          <div key={row.kind} className="flex flex-col gap-1.5 rounded-md border p-3">
            <div className="flex flex-wrap items-center gap-2">
              {row.used ? (
                <Label htmlFor={id}>{row.label}</Label>
              ) : (
                <span className="text-xs font-medium text-muted-foreground">{row.label}</span>
              )}
              <Badge variant={row.required ? "outline" : "secondary"}>
                {row.required ? "Required" : row.used ? "Optional" : "Not used by this method"}
              </Badge>
              <span className={cn("text-xs", stored.className)} title={stored.title}>
                {stored.text}
              </span>
              {row.origin === "ACCOUNT" ? (
                confirming === row.kind ? (
                  <span className="ml-auto flex items-center gap-1">
                    <span className="text-xs text-muted-foreground">Remove it?</span>
                    <Button
                      type="button"
                      size="sm"
                      variant="destructive"
                      disabled={clear.isPending}
                      onClick={() => clear.mutate(row.kind)}
                    >
                      Remove
                    </Button>
                    <Button type="button" size="sm" variant="ghost" onClick={() => setConfirming(null)}>
                      Keep
                    </Button>
                  </span>
                ) : (
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    className="ml-auto text-red-300"
                    onClick={() => setConfirming(row.kind)}
                  >
                    Remove
                  </Button>
                )
              ) : null}
            </div>
            {row.used ? (
              <Input
                id={id}
                type="password"
                autoComplete="new-password"
                spellCheck={false}
                maxLength={4096}
                placeholder={row.origin ? "Enter a new value to replace it" : "Not set"}
                value={values[row.kind] ?? ""}
                onChange={(event) => setValues((current) => ({ ...current, [row.kind]: event.target.value }))}
              />
            ) : null}
            {row.kind === "TOTP_SECRET" && row.used ? (
              <p className="text-xs text-muted-foreground">
                The base32 secret behind the authenticator QR code. With it stored, codes are generated automatically.
              </p>
            ) : null}
          </div>
        );
      })}
      <DialogFooter>
        <Button type="button" variant="ghost" onClick={onDone}>
          Close
        </Button>
        {rows.some((row) => row.used) ? (
          <Button type="submit" disabled={!hasValues || save.isPending}>
            {save.isPending ? <Spinner /> : null}
            Save
          </Button>
        ) : null}
      </DialogFooter>
    </form>
  );
}

// ---- Groww sign-in -----------------------------------------------------------------------------

function modeText(mode: GrowwMode, method: AuthMethod): { label: string; hint: string; submit: string } {
  if (mode === "create") {
    return {
      label:
        method === "GROWW_TOTP"
          ? "Create a token with the stored TOTP secret"
          : "Create a token with the stored API key and secret",
      hint: "The terminal asks Groww for a new access token.",
      submit: "Create access token",
    };
  }
  if (mode === "code") {
    return {
      label: "Use an authenticator code",
      hint: "The current code of the TOTP token, from your authenticator app.",
      submit: "Sign in",
    };
  }
  return {
    label: "Paste an access token",
    hint: "Generated in Groww Cloud. Groww checks it before the terminal stores it.",
    submit: "Save token",
  };
}

export function GrowwConnectDialog({
  account,
  tokenExpiry,
  open,
  onOpenChange,
}: { account: ProviderAccountView; tokenExpiry?: string } & DialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <GrowwConnectForm account={account} tokenExpiry={tokenExpiry} onDone={() => onOpenChange(false)} />
      </DialogContent>
    </Dialog>
  );
}

function GrowwConnectForm({
  account,
  tokenExpiry,
  onDone,
}: {
  account: ProviderAccountView;
  tokenExpiry?: string;
  onDone: () => void;
}) {
  const inputId = useId();
  const groupName = useId();
  const modes = growwModes(account);
  const [mode, setMode] = useState<GrowwMode>(modes[0] ?? "token");
  const [value, setValue] = useState("");
  // The modes follow the stored credentials, which can change while the dialog is open.
  const active: GrowwMode = modes.includes(mode) ? mode : (modes[0] ?? "token");
  const text = modeText(active, account.auth_method);
  const blockedBy: readonly CredentialKind[] = active === "token" ? [] : account.missing_credentials;
  const ready =
    blockedBy.length === 0 &&
    (active === "create" || (active === "code" ? isTotpCode(value) : value.trim().length > 0));

  const connect = useApiMutation({
    mutationFn: (body: GrowwConnectRequest) => providersApi.growwConnect(body),
    invalidate: ACCOUNT_QUERIES,
    success: (view) =>
      view.token_expires_at
        ? `Signed in ${view.label}; the token expires ${formatDateTime(view.token_expires_at)}`
        : `Signed in ${view.label}`,
    errorTitle: "Groww sign-in failed",
    onSuccess: onDone,
  });

  return (
    <form
      className="flex flex-col gap-4"
      onSubmit={(event) => {
        event.preventDefault();
        if (ready) connect.mutate(growwConnectBody(account.id, active, value));
      }}
    >
      <DialogHeader>
        <DialogTitle>{`Groww sign-in: ${account.label}`}</DialogTitle>
        <DialogDescription>{tokenExpiry ?? "Groww access tokens expire; renew them here."}</DialogDescription>
      </DialogHeader>
      {modes.length > 1 ? (
        <fieldset className="flex flex-col gap-2">
          <legend className="mb-1.5 text-xs font-medium text-muted-foreground">How to get the token</legend>
          {modes.map((option) => {
            const optionText = modeText(option, account.auth_method);
            return (
              <label
                key={option}
                className={cn(
                  "flex cursor-pointer items-start gap-2 rounded-md border p-2",
                  option === active && "border-primary/60 bg-accent/40",
                )}
              >
                <input
                  type="radio"
                  name={groupName}
                  value={option}
                  checked={option === active}
                  onChange={() => {
                    setMode(option);
                    setValue("");
                  }}
                  className="mt-1 accent-primary"
                />
                <span className="flex flex-col">
                  <span className="text-sm">{optionText.label}</span>
                  <span className="text-xs text-muted-foreground">{optionText.hint}</span>
                </span>
              </label>
            );
          })}
        </fieldset>
      ) : (
        <p className="text-xs text-muted-foreground">{text.hint}</p>
      )}
      {active === "token" ? (
        <Field label="Access token" htmlFor={inputId}>
          <Input
            id={inputId}
            type="password"
            autoComplete="off"
            spellCheck={false}
            maxLength={4200}
            value={value}
            onChange={(event) => setValue(event.target.value)}
          />
        </Field>
      ) : null}
      {active === "code" ? (
        <Field label="Authenticator code" htmlFor={inputId}>
          <Input
            id={inputId}
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={10}
            className="w-40 font-mono tracking-widest"
            value={value}
            onChange={(event) => setValue(event.target.value)}
          />
        </Field>
      ) : null}
      {blockedBy.length > 0 ? (
        <p role="alert" className="text-xs text-amber-300">
          {`Add the ${blockedBy.map((kind) => credentialLabel(account.auth_method, kind)).join(" and ")} under Credentials first.`}
        </p>
      ) : null}
      <DialogFooter>
        <Button type="button" variant="ghost" onClick={onDone}>
          Cancel
        </Button>
        <Button type="submit" disabled={!ready || connect.isPending}>
          {connect.isPending ? <Spinner /> : null}
          {text.submit}
        </Button>
      </DialogFooter>
    </form>
  );
}
