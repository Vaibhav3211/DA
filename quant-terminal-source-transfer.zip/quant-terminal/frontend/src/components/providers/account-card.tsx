"use client";

import { KeyRound, LogIn, LogOut, Pencil, Trash2 } from "lucide-react";
import { useId, useState, type ReactNode } from "react";
import { ConnectionBadge } from "@/components/status/status-badge";
import { Badge, type BadgeVariant } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Spinner } from "@/components/ui/feedback";
import { Stat, StatGrid } from "@/components/ui/stat";
import { Switch } from "@/components/ui/switch";
import { accounts as accountsApi, providers as providersApi } from "@/lib/api/endpoints";
import { useApiMutation } from "@/lib/api/hooks";
import type { AccountStatus, ProviderAccountView, StreamHealth } from "@/lib/api/types.gen";
import { formatAge, formatDateTime, formatDuration, formatInteger } from "@/lib/format";
import { useNow } from "@/lib/hooks";
import { notify } from "@/lib/notifications";
import { AUTH_METHOD_LABEL, credentialLabel, tokenSecondsLeft } from "@/lib/providers";
import { cn, httpUrl } from "@/lib/utils";
import { ACCOUNT_QUERIES, CredentialsDialog, EditAccountDialog, GrowwConnectDialog } from "./account-dialogs";

export const ACCOUNT_STATUS: Record<AccountStatus, { label: string; variant: BadgeVariant; hint: string }> = {
  AUTHENTICATED: { label: "Signed in", variant: "success", hint: "Holds a valid access token" },
  AUTH_REQUIRED: { label: "Sign-in needed", variant: "warning", hint: "No valid access token: sign in" },
  NEEDS_CREDENTIALS: {
    label: "Credentials needed",
    variant: "warning",
    hint: "Add the credentials its sign-in method needs",
  },
  DISCONNECTED: { label: "Signed out", variant: "secondary", hint: "Signed out on purpose; sign in to stream again" },
};

/** The newest of some timestamps, ignoring missing and unreadable ones. */
function latestTime(values: readonly (string | null)[]): string | null {
  let latest: string | null = null;
  let latestAt = -Infinity;
  for (const value of values) {
    const at = value === null ? Number.NaN : Date.parse(value);
    if (at > latestAt) {
      latest = value;
      latestAt = at;
    }
  }
  return latest;
}

function Age({ value }: { value: string | null }) {
  const now = useNow();
  return <span title={formatDateTime(value)}>{formatAge(value, now)}</span>;
}

function TokenExpiry({ account }: { account: ProviderAccountView }) {
  const now = useNow(30_000);
  const left = tokenSecondsLeft(account, now);
  if (left === null) return <span className="text-muted-foreground">No token</span>;
  const at = formatDateTime(account.token_expires_at);
  if (left <= 0) {
    return (
      <span className="text-red-300" title={at}>
        {`Expired ${formatDuration(-left)} ago`}
      </span>
    );
  }
  return (
    <span className={cn(left < 3600 && "text-amber-300")} title={at}>
      {`In ${formatDuration(left)}`}
    </span>
  );
}

function Notice({ tone, children, title }: { tone: "warn" | "error"; children: ReactNode; title?: string }) {
  return (
    <p
      title={title}
      className={cn(
        "rounded-md border px-2 py-1 text-xs",
        tone === "warn" ? "border-amber-500/30 bg-amber-500/10 text-amber-200" : "border-red-500/30 bg-red-500/10 text-red-200",
      )}
    >
      {children}
    </p>
  );
}

function ConfirmDialog({
  open,
  onOpenChange,
  title,
  description,
  confirm,
  pending,
  onConfirm,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  confirm: string;
  pending: boolean;
  onConfirm: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button variant="destructive" disabled={pending} onClick={onConfirm}>
            {pending ? <Spinner /> : null}
            {confirm}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

type AccountDialog = "edit" | "credentials" | "groww" | "sign-out" | "delete";

/** One provider account: its sign-in state, feed, and the actions that change them. */
export function AccountCard({
  account,
  streams,
  otherEnabled,
  tokenExpiry,
}: {
  account: ProviderAccountView;
  /** The feed's streams that run on this account. */
  streams: readonly StreamHealth[];
  /** The label of another enabled account of the same provider; only one streams at a time. */
  otherEnabled: string | null;
  /** The provider's documented token lifetime. */
  tokenExpiry?: string;
}) {
  const switchId = useId();
  const [dialog, setDialog] = useState<AccountDialog | null>(null);
  const dialogProps = (name: AccountDialog) => ({
    open: dialog === name,
    onOpenChange: (open: boolean) => setDialog(open ? name : null),
  });
  const status = ACCOUNT_STATUS[account.status];
  const simulator = account.provider === "SIMULATOR";
  const zerodha = account.provider === "ZERODHA";
  const signedIn = account.status === "AUTHENTICATED";
  const missing = account.missing_credentials.map((kind) => credentialLabel(account.auth_method, kind));
  const blocked = !account.is_enabled && otherEnabled !== null;
  const subscribed = streams.reduce((sum, stream) => sum + stream.subscribed_instruments, 0);
  const desired = streams.reduce((sum, stream) => sum + stream.desired_instruments, 0);
  const reconnects = streams.reduce((sum, stream) => sum + stream.reconnect_count, 0);

  const toggle = useApiMutation({
    mutationFn: (enabled: boolean) => (enabled ? accountsApi.enable(account.id) : accountsApi.disable(account.id)),
    invalidate: ACCOUNT_QUERIES,
    success: (view) =>
      !view.is_enabled
        ? `${view.label} stopped streaming`
        : view.status === "AUTHENTICATED"
          ? `${view.label} is starting its feed`
          : `Enabled ${view.label}; sign in to start its feed`,
    errorTitle: "Could not change the account",
  });
  const kite = useApiMutation({
    mutationFn: async () => {
      const href = httpUrl((await providersApi.zerodhaConnect(account.id)).login_url);
      if (href === null) throw new Error("The API returned an unusable Kite login address");
      return href;
    },
    success: null,
    errorTitle: "Could not start the Kite login",
    onSuccess: (href) => window.location.assign(href),
  });
  const signOut = useApiMutation({
    mutationFn: () => providersApi.disconnect(account.provider, account.id),
    invalidate: ACCOUNT_QUERIES,
    success: null,
    errorTitle: "Could not sign out",
    onSuccess: (result) => {
      setDialog(null);
      if (result.remote_revoked === false) {
        notify(
          "warning",
          `Signed out ${account.label}`,
          "Kite did not confirm that its session ended; the session still expires on its own.",
        );
      } else {
        notify("success", `Signed out ${account.label}`, result.remote_revoked ? "The Kite session ended too." : null);
      }
    },
  });
  const remove = useApiMutation({
    mutationFn: () => accountsApi.remove(account.id),
    invalidate: ACCOUNT_QUERIES,
    success: `Deleted ${account.label}`,
    errorTitle: "Could not delete the account",
    onSuccess: () => setDialog(null),
  });

  const deleteNotes = [
    "The account and its stored credentials are deleted.",
    account.is_enabled ? "Its feed stops." : "",
    zerodha && account.has_access_token ? "Sign out first to also end the Kite session." : "",
  ];
  const signOutNotes = [
    zerodha
      ? "The terminal deletes the access token and ends the Kite session."
      : "The terminal deletes the access token; it stays valid at Groww until it expires.",
    account.is_enabled ? "The feed stops until you sign in again." : "",
  ];

  return (
    <article aria-label={account.label} className="flex flex-col gap-3 rounded-md border p-3">
      <header className="flex flex-wrap items-center gap-2">
        <h3 className="text-sm font-semibold">{account.label}</h3>
        <Badge variant={status.variant} title={status.hint}>
          {status.label}
        </Badge>
        <span className="text-xs text-muted-foreground">{AUTH_METHOD_LABEL[account.auth_method]}</span>
        <span
          className="ml-auto flex items-center gap-2"
          title={blocked ? `Disable ${otherEnabled} first: one account per provider streams at a time` : undefined}
        >
          <Switch
            id={switchId}
            checked={account.is_enabled}
            disabled={toggle.isPending || blocked}
            onCheckedChange={(checked) => toggle.mutate(checked)}
          />
          <label htmlFor={switchId} className="text-xs text-muted-foreground">
            Stream
          </label>
        </span>
      </header>

      {account.streaming_disabled_reason ? (
        <Notice tone="warn">{`Streaming is off for this provider: ${account.streaming_disabled_reason}`}</Notice>
      ) : null}
      {missing.length > 0 ? <Notice tone="warn">{`Missing: ${missing.join(", ")}`}</Notice> : null}
      {account.last_error_message || account.last_error_code ? (
        <Notice tone="error" title={account.last_error_code ?? undefined}>
          {account.last_error_message ?? account.last_error_code}
        </Notice>
      ) : null}

      <StatGrid className="xl:grid-cols-5">
        <Stat
          label="Feed"
          value={
            streams.length === 0 ? (
              <span className="text-muted-foreground">{account.is_enabled ? "No stream yet" : "Off"}</span>
            ) : (
              <span className="flex flex-wrap gap-1">
                {streams.map((stream) => (
                  <span key={stream.stream_id} title={stream.stream_id}>
                    <ConnectionBadge state={stream.state} />
                  </span>
                ))}
              </span>
            )
          }
        />
        <Stat
          label="Instruments"
          title="Subscribed now / wanted by workspace universes"
          value={streams.length === 0 ? "—" : `${formatInteger(subscribed)} / ${formatInteger(desired)}`}
        />
        <Stat label="Last event" value={<Age value={latestTime(streams.map((stream) => stream.last_event_at))} />} />
        <Stat
          label="Reconnects"
          title="Since each stream started; the connection changes below list them"
          value={streams.length === 0 ? "—" : formatInteger(reconnects)}
        />
        {simulator ? null : (
          <>
            <Stat label="Token expires" value={<TokenExpiry account={account} />} />
            <Stat label="Last sign-in" value={formatDateTime(account.last_auth_at)} />
            <Stat label="Provider user" value={account.provider_user_ref ?? "—"} />
            <Stat label="API key" value={account.masked_api_key ?? "—"} />
          </>
        )}
        <Stat label="Last connected" value={formatDateTime(account.last_connected_at)} />
        <Stat label="Last disconnected" value={formatDateTime(account.last_disconnected_at)} />
      </StatGrid>

      <div className="flex flex-wrap gap-2">
        {zerodha ? (
          <Button
            size="sm"
            variant={signedIn ? "outline" : "default"}
            disabled={kite.isPending || missing.length > 0}
            title={missing.length > 0 ? "Add the API key and secret first" : "Opens the Kite login page"}
            onClick={() => kite.mutate()}
          >
            {kite.isPending ? <Spinner /> : <LogIn aria-hidden className="size-4" />}
            {signedIn ? "Sign in again" : "Sign in with Kite"}
          </Button>
        ) : null}
        {account.provider === "GROWW" ? (
          <Button size="sm" variant={signedIn ? "outline" : "default"} onClick={() => setDialog("groww")}>
            <LogIn aria-hidden className="size-4" />
            {signedIn ? "Renew token" : "Sign in"}
          </Button>
        ) : null}
        {!simulator && account.has_access_token ? (
          <Button size="sm" variant="outline" onClick={() => setDialog("sign-out")}>
            <LogOut aria-hidden className="size-4" />
            Sign out
          </Button>
        ) : null}
        {simulator ? null : (
          <Button size="sm" variant="outline" onClick={() => setDialog("credentials")}>
            <KeyRound aria-hidden className="size-4" />
            Credentials
          </Button>
        )}
        <Button size="sm" variant="ghost" onClick={() => setDialog("edit")}>
          <Pencil aria-hidden className="size-4" />
          Edit
        </Button>
        <Button size="sm" variant="ghost" className="text-red-300" onClick={() => setDialog("delete")}>
          <Trash2 aria-hidden className="size-4" />
          Delete
        </Button>
      </div>

      <EditAccountDialog account={account} {...dialogProps("edit")} />
      {simulator ? null : <CredentialsDialog account={account} {...dialogProps("credentials")} />}
      {account.provider === "GROWW" ? (
        <GrowwConnectDialog account={account} tokenExpiry={tokenExpiry} {...dialogProps("groww")} />
      ) : null}
      <ConfirmDialog
        {...dialogProps("sign-out")}
        title={`Sign out ${account.label}?`}
        description={signOutNotes.filter(Boolean).join(" ")}
        confirm="Sign out"
        pending={signOut.isPending}
        onConfirm={() => signOut.mutate()}
      />
      <ConfirmDialog
        {...dialogProps("delete")}
        title={`Delete ${account.label}?`}
        description={deleteNotes.filter(Boolean).join(" ")}
        confirm="Delete"
        pending={remove.isPending}
        onConfirm={() => remove.mutate()}
      />
    </article>
  );
}
