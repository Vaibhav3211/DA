"use client";

import { useQuery } from "@tanstack/react-query";
import { ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { CodeList, DetailList, DetailRow } from "@/components/ui/details";
import { Stat, StatGrid } from "@/components/ui/stat";
import { providers as providersApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { ProviderAccountView, ProviderCapabilities, ProviderSummary } from "@/lib/api/types.gen";
import { formatDate, formatInteger, humanize, segmentLabel } from "@/lib/format";
import { httpUrl } from "@/lib/utils";

function yesNo(value: boolean): string {
  return value ? "Yes" : "No";
}

function Lines({ values }: { values: readonly string[] }) {
  return (
    <ul className="flex list-disc flex-col gap-0.5 pl-4">
      {values.map((value) => (
        <li key={value}>{value}</li>
      ))}
    </ul>
  );
}

function CapabilityDetails({ capabilities: caps }: { capabilities: ProviderCapabilities }) {
  const limits = Object.entries(caps.rest_rate_limits);
  const docs = caps.documentation_urls.map((url) => ({ url, href: httpUrl(url) }));
  return (
    <div className="flex flex-col gap-4 pt-3">
      {caps.needs_live_verification.length > 0 ? (
        <div className="rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
          <p className="font-medium">Not yet verified against a live account:</p>
          <Lines values={caps.needs_live_verification} />
        </div>
      ) : null}
      <StatGrid className="xl:grid-cols-6">
        <Stat label="Streaming" value={yesNo(caps.streaming)} />
        <Stat label="REST quotes" value={yesNo(caps.rest_quotes)} />
        <Stat label="Modes" value={caps.subscription_modes.join(" · ") || "—"} />
        <Stat label="Depth levels" value={formatInteger(caps.depth_levels)} />
        <Stat label="Per connection" title="Instruments per connection" value={formatInteger(caps.max_instruments_per_connection)} />
        <Stat label="Connections" title="Connections per account" value={formatInteger(caps.max_connections_per_account)} />
      </StatGrid>
      <DetailList>
        <DetailRow label="Exchanges">
          <CodeList values={caps.exchanges} />
        </DetailRow>
        <DetailRow label="Segments">
          <CodeList values={caps.segments} format={segmentLabel} />
        </DetailRow>
        <DetailRow label="Instrument types">
          <CodeList values={caps.instrument_types} format={humanize} />
        </DetailRow>
        <DetailRow label="Quote fields">
          {caps.quote_fields.length > 0 ? (
            <span className="font-mono text-muted-foreground">{caps.quote_fields.join(", ")}</span>
          ) : (
            "—"
          )}
        </DetailRow>
        <DetailRow label="Token expiry">{caps.token_expiry}</DetailRow>
        <DetailRow label="Token refresh">{caps.token_refresh}</DetailRow>
        <DetailRow label="Entitlement">{caps.entitlement}</DetailRow>
        {limits.length > 0 ? (
          <DetailRow label="Rate limits">
            <ul className="flex flex-col gap-0.5">
              {limits.map(([name, limit]) => (
                <li key={name}>
                  <span className="font-mono">{name}</span>
                  <span className="text-muted-foreground">{` · ${limit}`}</span>
                </li>
              ))}
            </ul>
          </DetailRow>
        ) : null}
        {caps.restrictions.length > 0 ? (
          <DetailRow label="Restrictions">
            <Lines values={caps.restrictions} />
          </DetailRow>
        ) : null}
        {docs.length > 0 ? (
          <DetailRow label="Documentation">
            <ul className="flex flex-col gap-0.5">
              {docs.map(({ url, href }) => (
                <li key={url} className="break-all">
                  {href ? (
                    <a href={href} target="_blank" rel="noreferrer noopener" className="underline underline-offset-2">
                      {url}
                      <ExternalLink aria-hidden className="ml-1 inline size-3" />
                      <span className="sr-only"> (opens in a new tab)</span>
                    </a>
                  ) : (
                    <span className="text-muted-foreground">{url}</span>
                  )}
                </li>
              ))}
            </ul>
          </DetailRow>
        ) : null}
        <DetailRow label="Verified">
          {`${caps.verified_on ? formatDate(caps.verified_on) : "Not verified"}${caps.verification_source ? ` · ${caps.verification_source}` : ""}`}
        </DetailRow>
      </DetailList>
    </div>
  );
}

/** The provider's documented capabilities, with the streaming account's own overrides when it has one. */
export function CapabilitiesPanel({
  summary,
  account,
}: {
  summary: ProviderSummary;
  /** The account to show overrides for; the provider's defaults without one. */
  account: ProviderAccountView | null;
}) {
  const accountId = account?.id ?? null;
  const scoped = useQuery({
    queryKey: queryKeys.capabilities(summary.provider, accountId),
    queryFn: () => providersApi.capabilities(summary.provider, accountId ?? undefined),
    enabled: accountId !== null,
    staleTime: 5 * 60_000,
  });
  const caps = (accountId === null ? undefined : scoped.data) ?? summary.capabilities;
  const scope =
    account === null
      ? "Provider defaults"
      : scoped.data
        ? `As configured for ${account.label}`
        : scoped.isError
          ? `Provider defaults; ${account.label}'s overrides did not load`
          : "Provider defaults";
  return (
    <details className="rounded-md border px-3 py-2 text-sm">
      <summary className="cursor-pointer select-none">
        <span className="font-medium">Capabilities</span>
        <span className="ml-2 text-xs text-muted-foreground">{scope}</span>
        {caps.needs_live_verification.length > 0 ? (
          <Badge variant="warning" className="ml-2">
            Needs live verification
          </Badge>
        ) : null}
      </summary>
      <CapabilityDetails capabilities={caps} />
    </details>
  );
}
