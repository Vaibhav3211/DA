"use client";

import { RefreshCw } from "lucide-react";
import { useId, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Spinner } from "@/components/ui/feedback";
import { ApiError } from "@/lib/api/client";
import { instruments as instrumentsApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type { Provider, ProviderAccountView, RefreshReport } from "@/lib/api/types.gen";
import { formatInteger } from "@/lib/format";

/** "3 new, 2 updated", skipping zeros; the wording follows the CLI's refresh report. */
function counts(pairs: readonly (readonly [string, number])[], none = "no changes"): string {
  const shown = pairs.filter(([, count]) => count > 0).map(([label, count]) => `${formatInteger(count)} ${label}`);
  return shown.length > 0 ? shown.join(", ") : none;
}

function sourceText(report: RefreshReport, accounts: readonly ProviderAccountView[]): string {
  if (report.source === "FILE") return "Uploaded file";
  if (report.source === "BUILT_IN") return "Built-in list";
  if (report.provider === "GROWW") return "Download (public)";
  if (report.account_id === null) return "Download (API key from the server's ZERODHA_API_KEY)";
  const label = accounts.find((account) => account.id === report.account_id)?.label ?? report.account_id;
  return `Download (API key of ${label})`;
}

function reportRows(report: RefreshReport, accounts: readonly ProviderAccountView[]): [string, string][] {
  const stats = report.stats;
  const skipped = Object.entries(report.skipped).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  const rows: [string, string][] = [
    ["Source", sourceText(report, accounts)],
    ["Rows", `${formatInteger(report.rows)} read, ${formatInteger(report.accepted)} accepted`],
    ["Skipped", counts(skipped.map(([reason, count]) => [reason.replaceAll("_", " "), count] as const), "none")],
    [
      "Instruments",
      counts([
        ["new", stats.instruments_created],
        ["updated", stats.instruments_updated],
        ["renamed", stats.instruments_renamed],
        ["reactivated", stats.instruments_activated],
        ["deactivated", stats.instruments_deactivated],
      ]),
    ],
    [
      "Mappings",
      counts([
        ["new", stats.mappings_created],
        ["updated", stats.mappings_updated],
        ["unchanged", stats.mappings_unchanged],
        ["moved", stats.mappings_moved],
        ["closed", stats.mappings_closed],
        ["left as they were (rows skipped)", stats.mappings_held],
      ]),
    ],
  ];
  if (report.forced) rows.push(["Forced", "Yes"]);
  if (report.cache_path !== null) rows.push(["Saved copy", report.cache_path]);
  else if (report.cache_error !== null) rows.push(["Saved copy", `Failed: ${report.cache_error}`]);
  rows.push([
    "Workers",
    report.published
      ? "Asked to re-resolve their subscriptions"
      : "Not notified (Redis unavailable); they catch up when they next reconcile",
  ]);
  rows.push(["Took", `${report.duration_seconds.toFixed(1)} s`]);
  return rows;
}

function describe(provider: Provider, displayName: string, accounts: readonly ProviderAccountView[]): string {
  if (provider === "SIMULATOR") return "Reloads the simulator's built-in instrument list. Nothing is downloaded.";
  const download =
    provider === "ZERODHA"
      ? `Downloads Kite's instrument list with ${
          accounts.find((account) => account.is_enabled)?.label ?? "the enabled account"
        }'s API key (the server's ZERODHA_API_KEY without one)`
      : `Downloads ${displayName}'s public instrument list`;
  return `${download} and updates the instrument master. This contacts ${displayName}; feeds then re-resolve their subscriptions.`;
}

/** Downloads a provider's instrument list into the instrument master, and shows what changed. */
export function InstrumentRefreshDialog({
  provider,
  displayName,
  accounts,
}: {
  provider: Provider;
  displayName: string;
  accounts: readonly ProviderAccountView[];
}) {
  const forceId = useId();
  const [open, setOpen] = useState(false);
  const [force, setForce] = useState(false);
  const [report, setReport] = useState<RefreshReport | null>(null);
  // Lives outside the dialog's content so a refresh still reports if the dialog is closed meanwhile.
  const refresh = useApiMutation({
    mutationFn: (forced: boolean) => instrumentsApi.refresh({ provider, force: forced }),
    invalidate: [queryKeys.instruments, queryKeys.workspaces],
    success: (result) => `${displayName}: ${formatInteger(result.accepted)} instruments applied`,
    errorTitle: `Could not refresh ${displayName}'s instruments`,
    onSuccess: (result) => setReport(result),
  });
  const onOpenChange = (next: boolean) => {
    setOpen(next);
    if (next && !refresh.isPending) {
      setForce(false);
      setReport(null);
      refresh.reset();
    }
  };
  const incomplete = refresh.error instanceof ApiError && refresh.error.code === "instrument_dump_incomplete";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <RefreshCw aria-hidden className="size-4" />
          Refresh instruments
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{`Refresh ${displayName} instruments`}</DialogTitle>
          <DialogDescription>{describe(provider, displayName, accounts)}</DialogDescription>
        </DialogHeader>
        {report ? (
          <dl className="grid grid-cols-[minmax(6rem,auto)_1fr] gap-x-4 gap-y-1.5 text-sm">
            {reportRows(report, accounts).map(([label, value]) => (
              <div key={label} className="contents">
                <dt className="text-muted-foreground">{label}</dt>
                <dd className="min-w-0 break-words">{value}</dd>
              </div>
            ))}
          </dl>
        ) : (
          <div className="flex flex-col gap-3 text-sm">
            <label htmlFor={forceId} className="flex items-start gap-2">
              <input
                id={forceId}
                type="checkbox"
                className="mt-1 accent-primary"
                checked={force}
                disabled={refresh.isPending}
                onChange={(event) => setForce(event.target.checked)}
              />
              <span>
                Apply even if the list looks incomplete
                <span className="block text-xs text-muted-foreground">
                  A list that would close more than half of an exchange segment is normally refused: a truncated
                  download is far likelier than a mass delisting.
                </span>
              </span>
            </label>
            {incomplete ? (
              <p className="rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
                {`${refresh.error?.message ?? ""} Tick the box above to apply it anyway.`}
              </p>
            ) : null}
          </div>
        )}
        <DialogFooter>
          {report ? (
            <Button onClick={() => setOpen(false)}>Done</Button>
          ) : (
            <>
              <Button variant="ghost" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button disabled={refresh.isPending} onClick={() => refresh.mutate(force)}>
                {refresh.isPending ? <Spinner /> : <RefreshCw aria-hidden className="size-4" />}
                {provider === "SIMULATOR" ? "Reload" : "Download and apply"}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
