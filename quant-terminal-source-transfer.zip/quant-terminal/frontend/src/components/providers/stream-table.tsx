"use client";

import { useQuery } from "@tanstack/react-query";
import { ConnectionBadge, StatusBadge } from "@/components/status/status-badge";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { providers as providersApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { Provider, StreamHealth } from "@/lib/api/types.gen";
import {
  ageSeconds,
  formatAge,
  formatDateTime,
  formatDuration,
  formatInteger,
  formatLatency,
  formatTime,
  humanize,
} from "@/lib/format";
import { useNow } from "@/lib/hooks";
import { useLiveStore } from "@/lib/live/store";
import { cn } from "@/lib/utils";

/** Provider streams from whichever is newer: the live feed snapshot or the REST provider list. */
export function useFeedStreams() {
  const list = useQuery({ queryKey: queryKeys.providers, queryFn: providersApi.list, refetchInterval: 30_000 });
  const feed = useLiveStore((state) => state.feed);
  const restAt = list.data?.[0]?.generated_at ?? null;
  if (feed !== null && (restAt === null || Date.parse(feed.generatedAt) >= Date.parse(restAt))) {
    return { list, live: true, generatedAt: feed.generatedAt, streams: feed.streams };
  }
  return { list, live: false, generatedAt: restAt, streams: list.data?.flatMap((summary) => summary.feeds) };
}

function eventsTitle(stream: StreamHealth): string {
  return [
    `${formatInteger(stream.events_received)} received`,
    `${formatInteger(stream.malformed_events)} malformed`,
    `${formatInteger(stream.dropped_events)} dropped`,
    `${formatInteger(stream.duplicate_events)} duplicates`,
  ].join(", ");
}

export function StreamTable({ streams }: { streams: readonly StreamHealth[] }) {
  const now = useNow();
  if (streams.length === 0) {
    return (
      <EmptyState title="No provider streams">
        Streams start once an enabled account has a valid session and a workspace universe needs its data.
      </EmptyState>
    );
  }
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Stream</TableHead>
          <TableHead>Connection</TableHead>
          <TableHead>Data</TableHead>
          <TableHead className="text-right">Events/s</TableHead>
          <TableHead className="text-right">Instruments</TableHead>
          <TableHead className="text-right">Latency</TableHead>
          <TableHead>Last event</TableHead>
          <TableHead className="text-right">Reconnects</TableHead>
          <TableHead>Notes</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {streams.map((stream) => {
          const short = stream.subscribed_instruments < stream.desired_instruments;
          const lost = stream.malformed_events + stream.dropped_events;
          return (
            <TableRow key={`${stream.provider}:${stream.stream_id}`}>
              <TableCell>
                <span className="font-medium">{humanize(stream.provider)}</span>
                <span className="block font-mono text-[11px] text-muted-foreground">{stream.stream_id}</span>
              </TableCell>
              <TableCell>
                <ConnectionBadge state={stream.state} />
                <span className="block text-[11px] text-muted-foreground" title={formatDateTime(stream.state_since)}>
                  for {formatDuration(ageSeconds(stream.state_since, now))}
                </span>
              </TableCell>
              <TableCell>
                <StatusBadge status={stream.data_status} />
                {stream.stale_seconds !== null ? (
                  <span className="block text-[11px] text-muted-foreground">
                    quiet {formatDuration(stream.stale_seconds)}
                  </span>
                ) : null}
              </TableCell>
              <TableCell className="text-right font-mono tabular-nums" title={eventsTitle(stream)}>
                {stream.events_per_second.toFixed(1)}
                {lost > 0 ? (
                  <span className="block text-[11px] text-amber-200">{formatInteger(lost)} lost</span>
                ) : null}
              </TableCell>
              <TableCell
                className={cn("text-right font-mono tabular-nums", short && "text-amber-200")}
                title="Subscribed at the provider / wanted by the workspaces"
              >
                {formatInteger(stream.subscribed_instruments)}/{formatInteger(stream.desired_instruments)}
              </TableCell>
              <TableCell
                className="text-right font-mono text-[11px] tabular-nums"
                title="Exchange to provider (source) and provider to this server (processing)"
              >
                <span className="block">src {formatLatency(stream.source_latency_ms)}</span>
                <span className="block text-muted-foreground">proc {formatLatency(stream.processing_latency_ms)}</span>
              </TableCell>
              <TableCell className="text-xs" title={formatDateTime(stream.last_event_at)}>
                {formatAge(stream.last_event_at, now)}
              </TableCell>
              <TableCell className="text-right font-mono tabular-nums">{formatInteger(stream.reconnect_count)}</TableCell>
              <TableCell className="max-w-xs text-xs">
                <span className="flex flex-wrap gap-1">
                  {stream.auth_required ? <Badge variant="warning">Sign-in needed</Badge> : null}
                  {stream.session_open === false ? (
                    <Badge variant="outline" title="No subscribed exchange is in session, so quiet data is expected">
                      Session closed
                    </Badge>
                  ) : null}
                </span>
                {stream.last_error ? <span className="block break-words text-red-300">{stream.last_error}</span> : null}
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

/** Connection state changes pushed while this tab has been open, newest first. */
export function FeedChanges({ providers, limit = 50 }: { providers?: ReadonlySet<Provider>; limit?: number }) {
  const changes = useLiveStore((state) => state.feedChanges);
  const shown = (providers ? changes.filter((change) => providers.has(change.provider)) : changes).slice(0, limit);
  if (shown.length === 0) {
    return (
      <EmptyState title="No state changes yet">
        Connects, drops and reconnects are listed here as they happen while this tab is open.
      </EmptyState>
    );
  }
  return (
    <ol className="flex flex-col divide-y text-xs">
      {shown.map((change) => (
        <li
          key={`${change.at}|${change.stream_id}|${change.previous_state}|${change.state}`}
          className="flex flex-wrap items-center gap-2 py-1.5"
        >
          <time dateTime={change.at} title={formatDateTime(change.at)} className="font-mono text-muted-foreground">
            {formatTime(change.at)}
          </time>
          <span>{humanize(change.provider)}</span>
          <span className="font-mono text-muted-foreground">{change.stream_id}</span>
          <ConnectionBadge state={change.previous_state} />
          <span aria-hidden>→</span>
          <span className="sr-only">to</span>
          <ConnectionBadge state={change.state} />
          {change.reason ? <span className="text-muted-foreground">{change.reason}</span> : null}
        </li>
      ))}
    </ol>
  );
}

/** Streams and their recent state changes, optionally limited to some providers. */
export function FeedPanel({ providers }: { providers?: ReadonlySet<Provider> }) {
  const feed = useFeedStreams();
  const streams = providers ? feed.streams?.filter((stream) => providers.has(stream.provider)) : feed.streams;
  const reported = feed.generatedAt
    ? `Reported at ${formatTime(feed.generatedAt)} ${feed.live ? "over the live socket" : "by the API"}.`
    : undefined;
  return (
    <div className="flex flex-col gap-4">
      <Card>
        <CardHeader title="Provider streams" description={reported} />
        <CardContent>
          {streams ? (
            <StreamTable streams={streams} />
          ) : feed.list.isError ? (
            <ErrorState error={feed.list.error} onRetry={() => void feed.list.refetch()} />
          ) : (
            <LoadingState />
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader title="Connection changes" />
        <CardContent>
          <FeedChanges providers={providers} />
        </CardContent>
      </Card>
    </div>
  );
}
