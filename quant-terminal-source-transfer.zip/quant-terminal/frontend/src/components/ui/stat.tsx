import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function StatGrid({ className, children }: { className?: string; children: ReactNode }) {
  return <dl className={cn("grid grid-cols-2 gap-3 sm:grid-cols-4", className)}>{children}</dl>;
}

export function Stat({
  label,
  value,
  title,
  className,
}: {
  label: ReactNode;
  value: ReactNode;
  title?: string;
  className?: string;
}) {
  return (
    <div className={cn("min-w-0", className)} title={title}>
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="truncate font-mono text-sm tabular-nums">{value}</dd>
    </div>
  );
}

/** Pretty-printed JSON for diagnostic details; nothing for an empty object. */
export function JsonBlock({ value, className }: { value: unknown; className?: string }) {
  if (value === null || value === undefined) return null;
  if (typeof value === "object" && Object.keys(value).length === 0) return null;
  return (
    <pre
      className={cn(
        "max-h-60 overflow-auto rounded-md border bg-background/60 p-2 font-mono text-[11px] leading-relaxed text-muted-foreground",
        className,
      )}
    >
      {JSON.stringify(value, null, 2)}
    </pre>
  );
}
