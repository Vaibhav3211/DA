import { Inbox, LoaderCircle, TriangleAlert } from "lucide-react";
import type { ReactNode } from "react";
import { ApiError } from "@/lib/api/client";
import { cn, errorMessage } from "@/lib/utils";
import { Button } from "./button";

export function Spinner({ className }: { className?: string }) {
  return <LoaderCircle aria-hidden className={cn("size-4 animate-spin", className)} />;
}

export function LoadingState({ label = "Loading…", className }: { label?: string; className?: string }) {
  return (
    <div role="status" className={cn("flex items-center gap-2 p-4 text-sm text-muted-foreground", className)}>
      <Spinner />
      {label}
    </div>
  );
}

export function ErrorState({
  error,
  title = "Could not load this",
  onRetry,
  className,
}: {
  error: unknown;
  title?: string;
  onRetry?: () => void;
  className?: string;
}) {
  return (
    <div
      role="alert"
      className={cn("flex flex-col items-start gap-2 rounded-md border border-red-500/40 bg-red-500/10 p-3 text-sm", className)}
    >
      <div className="flex items-center gap-2 font-medium text-red-300">
        <TriangleAlert className="size-4" aria-hidden />
        {title}
      </div>
      <p className="text-muted-foreground">{errorMessage(error)}</p>
      {error instanceof ApiError && error.correlationId ? (
        <p className="font-mono text-xs text-muted-foreground">Reference {error.correlationId}</p>
      ) : null}
      {onRetry ? (
        <Button size="sm" variant="outline" onClick={onRetry}>
          Try again
        </Button>
      ) : null}
    </div>
  );
}

export function EmptyState({
  title,
  children,
  icon,
  className,
}: {
  title: string;
  children?: ReactNode;
  icon?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center gap-2 px-4 py-8 text-center text-sm", className)}>
      <span className="text-muted-foreground [&_svg]:size-6">{icon ?? <Inbox aria-hidden />}</span>
      <p className="font-medium">{title}</p>
      {children ? <div className="max-w-md text-muted-foreground">{children}</div> : null}
    </div>
  );
}
