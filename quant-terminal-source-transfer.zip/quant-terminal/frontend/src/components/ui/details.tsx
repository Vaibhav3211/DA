import type { ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

/** A two-column label/value list of ``DetailRow``s. */
export function DetailList({ className, children }: { className?: string; children: ReactNode }) {
  return <dl className={cn("grid grid-cols-[minmax(7rem,auto)_1fr] gap-x-4 gap-y-2 text-xs", className)}>{children}</dl>;
}

export function DetailRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="min-w-0 break-words">{children}</dd>
    </>
  );
}

/** Enum codes as outline badges. */
export function CodeList({
  values,
  format,
  empty = "None listed",
}: {
  values: readonly string[];
  format?: (value: string) => string;
  empty?: string;
}) {
  if (values.length === 0) return <span className="text-muted-foreground">{empty}</span>;
  return (
    <span className="flex flex-wrap gap-1">
      {values.map((value) => (
        <Badge key={value} variant="outline" className="font-mono">
          {format ? format(value) : value}
        </Badge>
      ))}
    </span>
  );
}
