"use client";

import { keepPreviousData, useQuery } from "@tanstack/react-query";
import dynamic from "next/dynamic";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DetailList, DetailRow } from "@/components/ui/details";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ErrorState, LoadingState, Spinner } from "@/components/ui/feedback";
import { Stat, StatGrid } from "@/components/ui/stat";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { backtests as backtestsApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { BacktestDetail, BacktestRunView, BacktestSummary, BacktestTrade, Measure } from "@/lib/api/types.gen";
import {
  EXIT_REASON_TEXT,
  METRIC_DEFINITIONS,
  changedLabel,
  coverageRows,
  coverageText,
  formatPnl,
  isActive,
  isSimulated,
  measureText,
  recordedRules,
  ruleRows,
  settingsRows,
  sourceText,
} from "@/lib/backtests";
import { formatDate, formatInteger, formatPrice } from "@/lib/format";
import { BacktestTradeDialog, SignalRefDetails } from "./backtest-trade-dialog";
import {
  DataBadge,
  Hash,
  Notice,
  OutcomeBadge,
  PnlText,
  RowList,
  RunStatusBadge,
  Section,
  SimulatedNotice,
  momentText,
  runReplayText,
} from "./common";
import { ACTIVE_POLL_MS } from "./latest-backtest";

const EquityChart = dynamic(() => import("./equity-chart"), {
  ssr: false,
  loading: () => <LoadingState label="Loading the equity curve…" className="h-[260px]" />,
});

const TRADES_PAGE = 100;

const DEFINITION_LABELS: Readonly<Record<keyof typeof METRIC_DEFINITIONS, string>> = {
  closedTrades: "Closed trades",
  outcome: "Win, loss, breakeven",
  winRate: "Win rate",
  averageWin: "Average win",
  averageLoss: "Average loss",
  net: "Net result",
  gross: "Gross result",
  profitFactor: "Profit factor",
  maxDrawdown: "Maximum drawdown",
};

function plural(count: number, one: string, many = `${one}s`): string {
  return `${formatInteger(count)} ${count === 1 ? one : many}`;
}

// ---- state banners ---------------------------------------------------------------------------------------

function RunBanners({ detail }: { detail: BacktestDetail }) {
  const { run, changed, current_problem: currentProblem } = detail;
  return (
    <>
      {isSimulated(run) ? <SimulatedNotice /> : null}
      {run.outdated === true ? (
        <Notice title="Outdated">
          <p>
            {changed.length > 0
              ? `Changed since this backtest: ${changed.map(changedLabel).join(", ")}.`
              : "The configuration's settings changed since this backtest."}{" "}
            It is kept for comparison; run the backtest again for results with the current settings.
          </p>
        </Notice>
      ) : null}
      {currentProblem !== null ? (
        <Notice tone="info" title="Whether these results are current is unknown">
          <p>{`The configuration's current settings cannot be worked out: ${currentProblem}`}</p>
        </Notice>
      ) : null}
      {run.status === "QUEUED" ? (
        <Notice tone="info" title="Queued">
          <p className="flex items-center gap-2">
            <Spinner className="size-3" />
            Waiting for the backtest worker. This page updates by itself.
          </p>
        </Notice>
      ) : null}
      {run.status === "RUNNING" ? (
        <Notice tone="info" title="Running">
          <p className="flex items-center gap-2">
            <Spinner className="size-3" />
            {`On the backtest worker since ${momentText(run.started_at)}. This page updates by itself.`}
          </p>
        </Notice>
      ) : null}
      {run.status === "FAILED" ? (
        <Notice tone="destructive" title="The backtest failed">
          <p>{run.error ?? "No reason recorded."}</p>
        </Notice>
      ) : null}
      {run.status === "SUCCEEDED" && run.summary === null ? (
        <Notice tone="destructive" title="The results cannot be shown">
          <p>{run.error ?? "The stored results are missing."}</p>
        </Notice>
      ) : null}
    </>
  );
}

// ---- summary ---------------------------------------------------------------------------------------------

function MeasureStat({
  label,
  measure,
  unit = "",
  definition,
}: {
  label: string;
  measure: Measure;
  unit?: string;
  definition: string;
}) {
  const { text, reason } = measureText(measure, unit);
  return <Stat label={label} value={text} title={reason === null ? definition : `Undefined: ${reason}`} />;
}

function PeriodText({ run, summary }: { run: BacktestRunView; summary: BacktestSummary }) {
  const period = summary.period;
  return (
    <p className="text-sm">
      {period.evaluated_from === null
        ? `No candle was evaluated: the ${plural(period.warmup_candles, "warm-up candle")} took the whole dataset.`
        : `Evaluated ${momentText(period.evaluated_from)} to ${momentText(period.evaluated_to)}: ` +
          `${plural(period.evaluated_candles, "candle")} of ${run.interval}, after ` +
          `${plural(period.warmup_candles, "warm-up candle")} that only fed the indicators.`}{" "}
      <span className="text-muted-foreground">{`${sourceText(run)}.`}</span>
    </p>
  );
}

function SummaryTab({ detail, summary }: { detail: BacktestDetail; summary: BacktestSummary }) {
  const { run } = detail;
  const metrics = summary.metrics;
  const signals = summary.signals;
  const position = summary.open_position;
  const capital = recordedRules(run.settings)?.initial_capital ?? null;
  const undefinedMeasures = (
    [
      ["Win rate", metrics.win_rate_pct],
      ["Average win", metrics.average_win],
      ["Average loss", metrics.average_loss],
      ["Profit factor", metrics.profit_factor],
      ["Maximum drawdown %", metrics.max_drawdown_pct],
    ] as const
  ).filter(([, measure]) => measure.value === null);
  const blocked = Object.entries(signals.blocked_by_rule)
    .map(([rule, count]) => `${rule} ${formatInteger(count)}`)
    .join(", ");
  const drawdown = measureText(metrics.max_drawdown_pct, "%");
  return (
    <div className="flex flex-col gap-4">
      <PeriodText run={run} summary={summary} />
      {metrics.closed_trades === 0 ? (
        <Notice tone="info" title="No closed trades">
          <p>
            No trade closed in the evaluated period, so the win rate, averages and profit factor are undefined.
            {position !== null ? " A position was still open at the end; it is not a closed trade." : ""}
            {` Signals are not trades: the strategy proposed ${plural(signals.proposed, "signal")}.`}
          </p>
        </Notice>
      ) : null}
      <StatGrid>
        <Stat
          label="Closed trades"
          value={formatInteger(metrics.closed_trades)}
          title={METRIC_DEFINITIONS.closedTrades}
        />
        <Stat
          label="Wins · losses · breakeven"
          value={`${formatInteger(metrics.wins)} · ${formatInteger(metrics.losses)} · ${formatInteger(metrics.breakevens)}`}
          title={METRIC_DEFINITIONS.outcome}
        />
        <MeasureStat label="Win rate" measure={metrics.win_rate_pct} unit="%" definition={METRIC_DEFINITIONS.winRate} />
        <MeasureStat label="Profit factor" measure={metrics.profit_factor} definition={METRIC_DEFINITIONS.profitFactor} />
        <MeasureStat label="Average win" measure={metrics.average_win} definition={METRIC_DEFINITIONS.averageWin} />
        <MeasureStat label="Average loss" measure={metrics.average_loss} definition={METRIC_DEFINITIONS.averageLoss} />
        <Stat
          label="Net result"
          value={
            <>
              <PnlText value={metrics.net_pnl} />
              {` (${formatPnl(metrics.net_return_pct)}%)`}
            </>
          }
          title={METRIC_DEFINITIONS.net}
        />
        <Stat
          label="Gross result"
          value={
            <>
              <PnlText value={metrics.gross_pnl} />
              {` (${formatPnl(metrics.gross_return_pct)}%)`}
            </>
          }
          title={METRIC_DEFINITIONS.gross}
        />
        <Stat
          label="Maximum drawdown"
          value={`${formatPrice(metrics.max_drawdown)} (${drawdown.text})`}
          title={drawdown.reason === null ? METRIC_DEFINITIONS.maxDrawdown : `Undefined: ${drawdown.reason}`}
        />
        <Stat label="Fees · slippage" value={`${formatPrice(metrics.fees)} · ${formatPrice(metrics.slippage)}`} />
        <Stat label="Initial capital" value={formatPrice(capital)} />
        <Stat
          label="Final equity"
          value={formatPrice(metrics.final_equity)}
          title="The equity at the last close, the open position included at its mark"
        />
      </StatGrid>
      {undefinedMeasures.length > 0 ? (
        <DetailList>
          {undefinedMeasures.map(([label, measure]) => (
            <DetailRow key={label} label={`${label} undefined`}>
              {measure.reason ?? "No reason recorded"}
            </DetailRow>
          ))}
        </DetailList>
      ) : null}
      <ul className="flex flex-col gap-1 text-xs text-muted-foreground">
        {metrics.drawdown_peak_at !== null && metrics.drawdown_trough_at !== null ? (
          <li>{`The maximum drawdown ran from the peak at ${momentText(metrics.drawdown_peak_at)} to the trough at ${momentText(metrics.drawdown_trough_at)}.`}</li>
        ) : null}
        {metrics.both_touched_trades > 0 ? (
          <li>{`${plural(metrics.both_touched_trades, "trade")}: one candle reached the stop-loss and the target, and the stop-loss was assumed.`}</li>
        ) : null}
        {metrics.gap_exits > 0 ? (
          <li>{`${plural(metrics.gap_exits, "trade")} exited at the open, beyond their level (gap exits).`}</li>
        ) : null}
      </ul>
      <details className="text-xs">
        <summary className="cursor-pointer text-muted-foreground">How these are calculated</summary>
        <DetailList className="mt-2">
          {(Object.keys(METRIC_DEFINITIONS) as (keyof typeof METRIC_DEFINITIONS)[]).map((key) => (
            <DetailRow key={key} label={DEFINITION_LABELS[key]}>
              {METRIC_DEFINITIONS[key]}
            </DetailRow>
          ))}
        </DetailList>
      </details>

      <Section title="Equity curve">
        {detail.curve_problem !== null ? (
          <Notice tone="destructive" title="The equity curve cannot be shown">
            <p>{detail.curve_problem}</p>
          </Notice>
        ) : detail.equity_curve.length === 0 ? (
          <p className="text-sm text-muted-foreground">No equity curve was stored.</p>
        ) : (
          <>
            <EquityChart points={detail.equity_curve} interval={run.interval} baseline={capital} />
            <p className="text-xs text-muted-foreground">
              {`The equity at each candle's close, the open position marked to the close; the dashed line is the initial capital.${
                summary.equity_points > detail.equity_curve.length
                  ? ` Drawn from ${formatInteger(detail.equity_curve.length)} of ${formatInteger(summary.equity_points)} points: each stretch keeps its lowest and highest equity.`
                  : ""
              }`}
            </p>
          </>
        )}
      </Section>

      {position !== null ? (
        <Section title="Open at the end: not a closed trade">
          <p className="text-sm">
            {`${position.side} ${formatInteger(position.quantity)} units from ${momentText(position.entry_at)} at ${formatPrice(position.entry_price)}, held ${plural(position.candles_held, "candle")}. Stop-loss ${formatPrice(position.stop_loss)}, target ${formatPrice(position.target)}.`}
          </p>
          <p className="text-sm">
            {`Marked at ${formatPrice(position.mark_price)} at ${momentText(position.marked_at)}: `}
            <PnlText value={position.unrealized_pnl} />
            {" unrealized, after the entry's fees and before exit costs. It is in the final equity and the drawdown, not in the trade counts."}
          </p>
          <details className="text-xs">
            <summary className="cursor-pointer text-muted-foreground">Its entry signal</summary>
            <div className="mt-2">
              <SignalRefDetails signal={position.entry_signal} />
            </div>
          </details>
        </Section>
      ) : null}
      {summary.pending_at_end.length > 0 ? (
        <Section title="Decided but not filled">
          <ul className="list-disc pl-5 text-xs text-muted-foreground">
            {summary.pending_at_end.map((item, index) => (
              <li key={`${index}:${item}`}>{item}</li>
            ))}
          </ul>
        </Section>
      ) : null}

      <Section title="Signals: not trades">
        <DetailList>
          <DetailRow label="Proposed">{formatInteger(signals.proposed)}</DetailRow>
          <DetailRow label="Allowed">{`${formatInteger(signals.allowed)} (${formatInteger(signals.updates)} of them updates)`}</DetailRow>
          <DetailRow label="Blocked by risk rules">
            {`${formatInteger(signals.blocked)}${blocked ? ` (${blocked})` : ""}`}
          </DetailRow>
          <DetailRow label="Duplicates">{formatInteger(signals.duplicates)}</DetailRow>
          <DetailRow label="Invalidations">{formatInteger(signals.invalidations)}</DetailRow>
          <DetailRow label="Expired">{formatInteger(signals.expired)}</DetailRow>
        </DetailList>
      </Section>
      {summary.notes.length > 0 ? (
        <Section title="Notes">
          <ul className="list-disc pl-5 text-xs text-muted-foreground">
            {summary.notes.map((note, index) => (
              <li key={`${index}:${note}`}>{note}</li>
            ))}
          </ul>
        </Section>
      ) : null}
    </div>
  );
}

// ---- trades ----------------------------------------------------------------------------------------------

function TradesTab({
  run,
  summary,
  offset,
  onOffset,
}: {
  run: BacktestRunView;
  summary: BacktestSummary;
  offset: number;
  onOffset: (offset: number) => void;
}) {
  const [open, setOpen] = useState<BacktestTrade | null>(null);
  const page = useQuery({
    queryKey: queryKeys.backtestTrades(run.id, offset, TRADES_PAGE),
    queryFn: () => backtestsApi.trades(run.id, offset, TRADES_PAGE),
    enabled: run.trade_count > 0,
    placeholderData: keepPreviousData,
  });
  const skipped = summary.skipped_entries;
  return (
    <div className="flex flex-col gap-3">
      {run.trade_count === 0 ? (
        <p className="text-sm text-muted-foreground">
          No trade closed in the evaluated period.
          {summary.open_position !== null ? " The position open at the end is on the Summary tab." : ""}
        </p>
      ) : page.isPending ? (
        <LoadingState label="Loading the trades…" />
      ) : page.isError ? (
        <ErrorState error={page.error} title="The trades did not load" onRetry={() => void page.refetch()} />
      ) : (
        <>
          <p className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            {`Closed trades ${formatInteger(page.data.offset + 1)} to ${formatInteger(page.data.offset + page.data.trades.length)} of ${formatInteger(page.data.total)}, in order. Select one for its fills and signals.`}
            {page.isPlaceholderData ? <Spinner className="size-3" /> : null}
          </p>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>#</TableHead>
                <TableHead>Side</TableHead>
                <TableHead>Entry candle</TableHead>
                <TableHead className="text-right">Entry</TableHead>
                <TableHead>Exit candle</TableHead>
                <TableHead className="text-right">Exit</TableHead>
                <TableHead>Exit reason</TableHead>
                <TableHead className="text-right">Held</TableHead>
                <TableHead className="text-right">Net</TableHead>
                <TableHead className="text-right">Return</TableHead>
                <TableHead>Outcome</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {page.data.trades.map((trade) => (
                <TableRow key={trade.number} className="cursor-pointer" onClick={() => setOpen(trade)}>
                  <TableCell>
                    <button
                      type="button"
                      className="font-mono underline-offset-2 hover:underline"
                      aria-label={`Trade ${trade.number}: fills and signals`}
                      onClick={() => setOpen(trade)}
                    >
                      {trade.number}
                    </button>
                  </TableCell>
                  <TableCell>{trade.side}</TableCell>
                  <TableCell className="text-xs">{momentText(trade.entry_at)}</TableCell>
                  <TableCell className="text-right font-mono">{formatPrice(trade.entry_price)}</TableCell>
                  <TableCell className="text-xs">{momentText(trade.exit_at)}</TableCell>
                  <TableCell className="text-right font-mono">{formatPrice(trade.exit_price)}</TableCell>
                  <TableCell className="text-xs">
                    {EXIT_REASON_TEXT[trade.exit_reason]}
                    {trade.both_touched ? " · both touched" : ""}
                    {trade.gap_exit ? " · gap" : ""}
                  </TableCell>
                  <TableCell className="text-right font-mono">{formatInteger(trade.candles_held)}</TableCell>
                  <TableCell className="text-right">
                    <PnlText value={trade.net_pnl} />
                  </TableCell>
                  <TableCell className="text-right font-mono">{`${formatPnl(trade.return_pct)}%`}</TableCell>
                  <TableCell>
                    <OutcomeBadge outcome={trade.outcome} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {page.data.total > TRADES_PAGE ? (
            <div className="flex items-center justify-end gap-2">
              <Button
                size="sm"
                variant="outline"
                disabled={offset === 0 || page.isPlaceholderData}
                onClick={() => onOffset(Math.max(0, offset - TRADES_PAGE))}
              >
                Previous
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={offset + TRADES_PAGE >= page.data.total || page.isPlaceholderData}
                onClick={() => onOffset(offset + TRADES_PAGE)}
              >
                Next
              </Button>
            </div>
          ) : null}
        </>
      )}
      {summary.skipped_entries_total > 0 ? (
        <details className="text-xs">
          <summary className="cursor-pointer text-muted-foreground">
            {`Entries not taken (${formatInteger(summary.skipped_entries_total)})`}
          </summary>
          <ul className="mt-2 flex flex-col gap-1 text-muted-foreground">
            {skipped.map((entry, index) => (
              <li key={`${index}:${entry.at}`}>{`${momentText(entry.at)} · ${entry.signal_type}: ${entry.reason}`}</li>
            ))}
            {summary.skipped_entries_total > skipped.length ? (
              <li>{`… and ${formatInteger(summary.skipped_entries_total - skipped.length)} more, not listed`}</li>
            ) : null}
          </ul>
        </details>
      ) : null}
      {open !== null ? <BacktestTradeDialog run={run} trade={open} onClose={() => setOpen(null)} /> : null}
    </div>
  );
}

// ---- data and settings -----------------------------------------------------------------------------------

function DataTab({ detail }: { detail: BacktestDetail }) {
  const { run, dataset } = detail;
  const rules = recordedRules(run.settings);
  return (
    <div className="flex flex-col gap-4">
      <Section title="Data">
        <DetailList>
          <DetailRow label="Source">{sourceText(run)}</DetailRow>
          <DetailRow label="Dataset">
            {`${run.interval} candles of ${dataset.symbol} (${dataset.exchange}), ${formatDate(dataset.date_from)} to ${formatDate(dataset.date_to)}: ${plural(dataset.candle_count, "candle")}`}
          </DetailRow>
          <DetailRow label="First and last">
            {`${momentText(dataset.first_candle_at)} to ${momentText(dataset.last_candle_at)}`}
          </DetailRow>
          <DetailRow label="Content hash">
            <Hash value={run.dataset_sha} />
          </DetailRow>
          <DetailRow label="Coverage">
            {dataset.coverage === null ? "Not worked out" : coverageText(dataset.coverage)}
          </DetailRow>
        </DetailList>
        {dataset.coverage !== null ? <RowList rows={coverageRows(dataset.coverage)} /> : null}
      </Section>
      <Section title="Strategy and settings">
        <DetailList>
          <DetailRow label="Configuration">{run.label}</DetailRow>
          <DetailRow label="Strategy">{`${run.strategy_id} v${run.strategy_version}`}</DetailRow>
          <DetailRow label="Code fingerprint">
            <Hash value={run.code_fingerprint} />
          </DetailRow>
          <DetailRow label="Settings hash">
            <Hash value={run.settings_hash} />
          </DetailRow>
          <DetailRow label="Instrument">{`${run.symbol} (${run.instrument_key})`}</DetailRow>
        </DetailList>
        <RowList rows={settingsRows(run.settings)} />
      </Section>
      <Section title="Trade rules">
        {rules === null ? (
          <p className="text-sm text-muted-foreground">This backtest did not record its trade rules in a readable form.</p>
        ) : (
          <RowList rows={ruleRows(rules)} />
        )}
      </Section>
      <Section title="Run">
        <DetailList>
          <DetailRow label="Requested">
            {`${momentText(run.created_at)}${run.requested_by ? ` by ${run.requested_by}` : ""}`}
          </DetailRow>
          <DetailRow label="Started">{momentText(run.started_at)}</DetailRow>
          <DetailRow label="Finished">{momentText(run.finished_at)}</DetailRow>
          <DetailRow label="Worker">{run.worker_id ?? "—"}</DetailRow>
          <DetailRow label="Engine">{run.summary ? `Version ${run.summary.engine_version}` : "—"}</DetailRow>
          <DetailRow label="Backtest id">
            <span className="font-mono">{run.id}</span>
          </DetailRow>
        </DetailList>
      </Section>
    </div>
  );
}

// ---- dialog ----------------------------------------------------------------------------------------------

function ResultsBody({ detail }: { detail: BacktestDetail }) {
  const { run } = detail;
  const [offset, setOffset] = useState(0);
  const summary = run.status === "SUCCEEDED" ? run.summary : null;
  return (
    <>
      <DialogHeader>
        <DialogTitle>{`Backtest of ${run.label} on ${run.symbol}`}</DialogTitle>
        <DialogDescription>{`${run.strategy_id} v${run.strategy_version} · ${runReplayText(run)}`}</DialogDescription>
      </DialogHeader>
      <div className="flex flex-wrap items-center gap-2">
        <RunStatusBadge status={run.status} />
        <DataBadge origin={run} />
        {run.outdated === true ? (
          <Badge variant="warning" title="The configuration's settings changed since this backtest">
            Outdated
          </Badge>
        ) : run.outdated === false ? (
          <Badge variant="success" title="Run with the configuration's current settings">
            Current settings
          </Badge>
        ) : null}
        <span className="text-xs text-muted-foreground">{`Requested ${momentText(run.created_at)}`}</span>
      </div>
      <RunBanners detail={detail} />
      {summary === null ? (
        <DataTab detail={detail} />
      ) : (
        <Tabs defaultValue="summary">
          <TabsList>
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="trades">{`Trades (${formatInteger(run.trade_count)})`}</TabsTrigger>
            <TabsTrigger value="data">Data & settings</TabsTrigger>
          </TabsList>
          <TabsContent value="summary">
            <SummaryTab detail={detail} summary={summary} />
          </TabsContent>
          <TabsContent value="trades">
            <TradesTab run={run} summary={summary} offset={offset} onOffset={setOffset} />
          </TabsContent>
          <TabsContent value="data">
            <DataTab detail={detail} />
          </TabsContent>
        </Tabs>
      )}
    </>
  );
}

/**
 * One backtest's results: its period and data, the metrics with their definitions, the equity curve, the
 * closed trades and the open position kept apart. Reading results never reruns a backtest.
 */
export function BacktestResultsDialog({ runId, onClose }: { runId: string; onClose: () => void }) {
  const detail = useQuery({
    queryKey: queryKeys.backtest(runId),
    queryFn: () => backtestsApi.get(runId),
    refetchInterval: (query: { state: { data: BacktestDetail | undefined } }) => {
      const status = query.state.data?.run.status;
      return status !== undefined && isActive(status) ? ACTIVE_POLL_MS : false;
    },
  });
  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="max-w-4xl">
        {detail.isSuccess ? (
          <ResultsBody key={detail.data.run.id} detail={detail.data} />
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Backtest</DialogTitle>
              <DialogDescription>
                {detail.isError ? "The backtest could not be loaded." : "Loading the backtest…"}
              </DialogDescription>
            </DialogHeader>
            {detail.isError ? (
              <ErrorState error={detail.error} onRetry={() => void detail.refetch()} />
            ) : (
              <LoadingState />
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
