"use client";

import type { ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { DetailList, DetailRow } from "@/components/ui/details";
import type {
  BacktestRunView,
  BacktestState,
  BacktestStatus,
  DatasetSource,
  DatasetStatus,
  Provider,
  TradeOutcome,
} from "@/lib/api/types.gen";
import {
  OUTCOME_TONE,
  STATE_TEXT,
  STATUS_TONE,
  dataLabel,
  formatPnl,
  isSimulated,
  sourceText,
  type Row,
} from "@/lib/backtests";
import { formatDate, formatTime, humanize } from "@/lib/format";
import { cn } from "@/lib/utils";

export function Section({ title, children, className }: { title: string; children: ReactNode; className?: string }) {
  return (
    <section className={cn("flex flex-col gap-2", className)}>
      <h3 className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">{title}</h3>
      {children}
    </section>
  );
}

/** Label/value rows; a row with an empty label continues the one above it. */
export function RowList({ rows, className }: { rows: readonly Row[]; className?: string }) {
  return (
    <DetailList className={className}>
      {rows.map((row, index) => (
        <DetailRow key={`${index}:${row.label}`} label={row.label}>
          {row.value}
        </DetailRow>
      ))}
    </DetailList>
  );
}

const NOTICE_TONE = {
  warning: "border-amber-500/40 bg-amber-500/10 text-amber-200",
  info: "border-sky-500/40 bg-sky-500/10 text-sky-200",
  destructive: "border-red-500/40 bg-red-500/10 text-red-300",
} as const;

export function Notice({
  tone = "warning",
  title,
  children,
  className,
}: {
  tone?: keyof typeof NOTICE_TONE;
  title?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-1 rounded-md border p-3 text-xs", NOTICE_TONE[tone], className)}>
      {title ? <p className="font-semibold">{title}</p> : null}
      {children}
    </div>
  );
}

export function SimulatedNotice() {
  return (
    <Notice title="SIMULATED data">
      <p>
        These candles were recorded from the development simulator. They are not market prices, so the results say
        nothing about how the strategy would have done in a real market.
      </p>
    </Notice>
  );
}

export function BacktestStateBadge({ state }: { state: BacktestState }) {
  const text = STATE_TEXT[state];
  return (
    <Badge variant={text.tone} title={text.meaning}>
      {text.label}
    </Badge>
  );
}

export function RunStatusBadge({ status }: { status: BacktestStatus | DatasetStatus }) {
  return <Badge variant={STATUS_TONE[status]}>{humanize(status)}</Badge>;
}

export function DataBadge({ origin }: { origin: { provider: Provider; source: DatasetSource; simulated: boolean } }) {
  return (
    <Badge variant={isSimulated(origin) ? "warning" : "outline"} title={sourceText(origin)}>
      {dataLabel(origin)}
    </Badge>
  );
}

export function OutcomeBadge({ outcome }: { outcome: TradeOutcome }) {
  return <Badge variant={OUTCOME_TONE[outcome]}>{humanize(outcome)}</Badge>;
}

/** A profit or loss with its sign, green above zero and red below. */
export function PnlText({ value, className }: { value: string; className?: string }) {
  const sign = Number(value);
  return (
    <span
      className={cn(
        "font-mono tabular-nums",
        sign > 0 ? "text-emerald-300" : sign < 0 ? "text-red-300" : undefined,
        className,
      )}
    >
      {formatPnl(value)}
    </span>
  );
}

/** A hash shortened to 12 characters; all of it on hover. */
export function Hash({ value }: { value: string }) {
  return (
    <span className="font-mono" title={value}>
      {value.slice(0, 12)}
    </span>
  );
}

/** "02 Nov 2026 09:15:00" in IST: a moment with its year, since a backtest can span years. */
export function momentText(iso: string | null | undefined): string {
  return iso ? `${formatDate(iso)} ${formatTime(iso)}` : "—";
}

/** "5m candles · Zerodha history · 01 Jan 2026 to 31 Oct 2026": what a run replayed. */
export function runReplayText(run: BacktestRunView): string {
  return `${run.interval} candles · ${dataLabel(run)} · ${formatDate(run.date_from)} to ${formatDate(run.date_to)}`;
}
