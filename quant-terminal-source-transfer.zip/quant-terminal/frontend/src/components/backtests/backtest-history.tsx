"use client";

import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { backtests as backtestsApi, type BacktestFilters } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { BacktestRunView, DeploymentView } from "@/lib/api/types.gen";
import { METRIC_DEFINITIONS, isActive, measureText } from "@/lib/backtests";
import { formatDate, formatInteger } from "@/lib/format";
import { BacktestResultsDialog } from "./backtest-results";
import { DataBadge, PnlText, RunStatusBadge, momentText } from "./common";
import { ACTIVE_POLL_MS } from "./latest-backtest";

const HISTORY_LIMIT = 50;

function SettingsBadge({ outdated }: { outdated: boolean | null }) {
  if (outdated === true) {
    return (
      <Badge variant="warning" title="The configuration's settings changed since this backtest">
        Outdated
      </Badge>
    );
  }
  if (outdated === false) {
    return (
      <Badge variant="success" title="Run with the configuration's current settings">
        Current
      </Badge>
    );
  }
  return <span title="The configuration's current settings cannot be worked out">—</span>;
}

function HistoryRow({ run, onOpen }: { run: BacktestRunView; onOpen: (runId: string) => void }) {
  const metrics = run.summary?.metrics ?? null;
  const winRate = metrics ? measureText(metrics.win_rate_pct, "%") : null;
  const drawdown = metrics ? measureText(metrics.max_drawdown_pct, "%") : null;
  return (
    <TableRow>
      <TableCell className="text-xs">{momentText(run.created_at)}</TableCell>
      <TableCell title={run.error ?? undefined}>
        <RunStatusBadge status={run.status} />
      </TableCell>
      <TableCell>
        <DataBadge origin={run} />
      </TableCell>
      <TableCell className="text-xs">{`${formatDate(run.date_from)} to ${formatDate(run.date_to)}`}</TableCell>
      <TableCell>{run.interval}</TableCell>
      <TableCell className="text-right font-mono" title={METRIC_DEFINITIONS.closedTrades}>
        {metrics ? formatInteger(metrics.closed_trades) : "—"}
      </TableCell>
      <TableCell
        className="text-right font-mono"
        title={winRate?.reason ? `Undefined: ${winRate.reason}` : METRIC_DEFINITIONS.winRate}
      >
        {winRate ? winRate.text : "—"}
      </TableCell>
      <TableCell className="text-right">{metrics ? <PnlText value={metrics.net_pnl} /> : "—"}</TableCell>
      <TableCell
        className="text-right font-mono"
        title={drawdown?.reason ? `Undefined: ${drawdown.reason}` : METRIC_DEFINITIONS.maxDrawdown}
      >
        {drawdown ? drawdown.text : "—"}
      </TableCell>
      <TableCell>
        <SettingsBadge outdated={run.outdated} />
      </TableCell>
      <TableCell className="text-right">
        <Button size="sm" variant="outline" onClick={() => onOpen(run.id)}>
          Open
        </Button>
      </TableCell>
    </TableRow>
  );
}

/** Every backtest of a configuration on one instrument, newest first; older and outdated ones are kept. */
export function BacktestHistoryDialog({
  deployment,
  instrumentId,
  symbol,
  onClose,
}: {
  deployment: DeploymentView;
  instrumentId: string;
  symbol: string;
  onClose: () => void;
}) {
  const [openId, setOpenId] = useState<string | null>(null);
  const filters: BacktestFilters = { deployment_id: deployment.id, instrument: instrumentId, limit: HISTORY_LIMIT };
  const list = useQuery({
    queryKey: queryKeys.backtestList(filters),
    queryFn: () => backtestsApi.list(filters),
    refetchInterval: (query: { state: { data: BacktestRunView[] | undefined } }) =>
      query.state.data?.some((run) => isActive(run.status)) ? ACTIVE_POLL_MS : false,
  });
  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>{`Backtests of ${deployment.label} on ${symbol}`}</DialogTitle>
          <DialogDescription>
            Newest first. Earlier runs are kept for comparison; an outdated one ran with settings that have changed
            since.
          </DialogDescription>
        </DialogHeader>
        {list.isPending ? (
          <LoadingState label="Loading its backtests…" />
        ) : list.isError ? (
          <ErrorState error={list.error} title="The backtests did not load" onRetry={() => void list.refetch()} />
        ) : list.data.length === 0 ? (
          <EmptyState title="Not backtested">{`No backtest of ${deployment.label} on ${symbol} has been requested.`}</EmptyState>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Requested</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Period</TableHead>
                  <TableHead>Candles</TableHead>
                  <TableHead className="text-right">Closed trades</TableHead>
                  <TableHead className="text-right">Win rate</TableHead>
                  <TableHead className="text-right">Net</TableHead>
                  <TableHead className="text-right">Max drawdown</TableHead>
                  <TableHead>Settings</TableHead>
                  <TableHead>
                    <span className="sr-only">Results</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {list.data.map((run) => (
                  <HistoryRow key={run.id} run={run} onOpen={setOpenId} />
                ))}
              </TableBody>
            </Table>
            {list.data.length >= HISTORY_LIMIT ? (
              <p className="text-xs text-muted-foreground">
                {`Showing the newest ${formatInteger(HISTORY_LIMIT)}. To see older ones: qt backtests list --offset ${HISTORY_LIMIT}`}
              </p>
            ) : null}
          </>
        )}
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
        {openId !== null ? <BacktestResultsDialog runId={openId} onClose={() => setOpenId(null)} /> : null}
      </DialogContent>
    </Dialog>
  );
}
