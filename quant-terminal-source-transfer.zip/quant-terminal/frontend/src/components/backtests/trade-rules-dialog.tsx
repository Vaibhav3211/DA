"use client";

import { useId, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ErrorState, LoadingState } from "@/components/ui/feedback";
import { Field, Input, NativeSelect } from "@/components/ui/input";
import { backtests as backtestsApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type { DeploymentView, TradeRulesBody, TradeRulesView } from "@/lib/api/types.gen";
import {
  NUMBER_RULES,
  RULE_CHOICES,
  RULE_FIELDS,
  RULES_SOURCE_TEXT,
  checkTradeRules,
  draftFromRules,
  isChoiceField,
  rangeText,
  ruleApplies,
  type RuleField,
  type TradeRulesDraft,
} from "@/lib/backtests";
import { errorMessage } from "@/lib/utils";
import { Notice } from "./common";

/** Every backtest query: a change to trade rules can make any of them outdated. */
export const BACKTEST_QUERIES = [["backtests"]] as const;

const GROUPS: readonly { title: string; fields: readonly RuleField[] }[] = [
  { title: "Signals", fields: ["sides", "opposite_signal"] },
  { title: "Fills", fields: ["fill", "exit_check"] },
  { title: "Stop-loss, target and holding", fields: ["stop_target", "stop_pct", "target_pct", "max_holding_candles"] },
  { title: "Sizing", fields: ["sizing", "quantity", "amount", "risk_pct", "initial_capital"] },
  { title: "Costs", fields: ["fee_pct_per_side", "fee_per_order", "slippage_ticks"] },
];

/** A draft of rules stored with a configuration that no longer validate, so they can be corrected. */
function draftFromStored(stored: Record<string, unknown>): TradeRulesDraft {
  const draft = draftFromRules(null);
  for (const field of RULE_FIELDS) {
    const value = stored[field];
    if (typeof value === "string" || typeof value === "number") draft[field] = String(value);
  }
  return draft;
}

/** The rules the form starts from: the configuration's own, else the strategy's declared ones, else none. */
function initialDraft(view: TradeRulesView): TradeRulesDraft {
  if (view.source === "CONFIGURATION") return draftFromRules(view.effective);
  if (view.configuration !== null) return draftFromStored(view.configuration);
  return draftFromRules(view.strategy);
}

function RuleInput({
  field,
  value,
  error,
  idPrefix,
  onChange,
}: {
  field: RuleField;
  value: string;
  error: string | undefined;
  idPrefix: string;
  onChange: (field: RuleField, value: string) => void;
}) {
  const id = `${idPrefix}-${field}`;
  const describedBy = error ? `${id}-error` : undefined;
  if (isChoiceField(field)) {
    const rule = RULE_CHOICES[field];
    const picked = rule.choices.find((choice) => choice.value === value);
    return (
      <Field label={rule.label} htmlFor={id} hint={picked ? picked.meaning : rule.meaning} error={error}>
        <NativeSelect
          id={id}
          value={value}
          aria-invalid={error !== undefined}
          aria-describedby={describedBy}
          onChange={(event) => onChange(field, event.target.value)}
        >
          <option value="">Choose…</option>
          {rule.choices.map((choice) => (
            <option key={choice.value} value={choice.value}>
              {choice.label}
            </option>
          ))}
        </NativeSelect>
      </Field>
    );
  }
  const rule = NUMBER_RULES[field];
  return (
    <Field
      label={rule.optional ? `${rule.label} (optional)` : rule.label}
      htmlFor={id}
      hint={`${rule.meaning} ${rangeText(field)}.`}
      error={error}
    >
      <Input
        id={id}
        value={value}
        inputMode={rule.kind === "integer" ? "numeric" : "decimal"}
        autoComplete="off"
        aria-invalid={error !== undefined}
        aria-describedby={describedBy}
        onChange={(event) => onChange(field, event.target.value)}
      />
    </Field>
  );
}

function RulesForm({
  deployment,
  view,
  onClose,
}: {
  deployment: DeploymentView;
  view: TradeRulesView;
  onClose: () => void;
}) {
  const formId = useId();
  const [draft, setDraft] = useState<TradeRulesDraft>(() => initialDraft(view));
  const [errors, setErrors] = useState<Partial<Record<RuleField, string>>>({});
  const [problems, setProblems] = useState<string[]>([]);
  const archived = deployment.archived_at !== null;

  const save = useApiMutation({
    mutationFn: (body: TradeRulesBody) => backtestsApi.setRules(deployment.id, body),
    invalidate: BACKTEST_QUERIES,
    success: `Trade rules of ${deployment.label} saved. Backtests with other rules are now outdated; their results are kept for comparison.`,
    errorTitle: `Could not save the trade rules of ${deployment.label}`,
    onSuccess: onClose,
  });
  const clear = useApiMutation({
    mutationFn: () => backtestsApi.clearRules(deployment.id),
    invalidate: BACKTEST_QUERIES,
    success: (cleared) =>
      cleared.effective
        ? `${deployment.label} now uses the strategy's declared trade rules`
        : `${deployment.label} has no trade rules: set some before backtesting it`,
    errorTitle: `Could not remove the trade rules of ${deployment.label}`,
    onSuccess: onClose,
  });
  const pending = save.isPending || clear.isPending;
  const failed = save.error ?? clear.error;

  const change = (field: RuleField, value: string) => {
    setDraft((current) => ({ ...current, [field]: value }));
    setErrors((current) => {
      if (!(field in current)) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
    setProblems([]);
  };

  const submit = () => {
    const check = checkTradeRules(draft);
    setErrors(check.errors);
    setProblems(check.problems);
    if (check.body !== null) save.mutate(check.body);
  };

  return (
    <>
      <div className="flex flex-col gap-2">
        {archived ? (
          <Notice tone="info">
            <p>This configuration is archived, so its trade rules cannot change. Its backtests stay readable.</p>
          </Notice>
        ) : null}
        <p className="text-xs text-muted-foreground">
          {view.source
            ? `Backtests now use: ${RULES_SOURCE_TEXT[view.source]}.`
            : `Backtests cannot run now: ${view.problem ?? "no trade rules are set"}.`}
        </p>
        {view.configuration !== null && view.source !== "CONFIGURATION" ? (
          <Notice title="The saved rules no longer validate">
            <p>They are filled in below as saved; correct them and save again.</p>
          </Notice>
        ) : null}
        {view.configuration === null && view.strategy !== null ? (
          <p className="text-xs text-muted-foreground">
            The form starts from the strategy&apos;s declared rules. Saving makes them this configuration&apos;s own, so
            later changes to the strategy&apos;s defaults no longer apply to it.
          </p>
        ) : null}
      </div>
      <form
        id={formId}
        noValidate
        className="flex flex-col gap-5"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        {GROUPS.map((group) => (
          <fieldset key={group.title} className="flex flex-col gap-3" disabled={archived || pending}>
            <legend className="mb-1 text-sm font-medium">{group.title}</legend>
            <div className="grid gap-3 sm:grid-cols-2">
              {group.fields
                .filter((field) => ruleApplies(field, draft))
                .map((field) => (
                  <RuleInput
                    key={field}
                    field={field}
                    value={draft[field]}
                    error={errors[field]}
                    idPrefix={formId}
                    onChange={change}
                  />
                ))}
            </div>
          </fieldset>
        ))}
      </form>
      {problems.length > 0 ? (
        <Notice tone="destructive">
          {problems.map((problem) => (
            <p key={problem} role="alert">
              {problem}
            </p>
          ))}
        </Notice>
      ) : null}
      {failed ? (
        <Notice tone="destructive" title="Not saved">
          <p role="alert">{errorMessage(failed)}</p>
        </Notice>
      ) : null}
      <DialogFooter className="flex-wrap gap-2">
        {view.strategy !== null ? (
          <Button
            type="button"
            variant="ghost"
            disabled={archived || pending}
            onClick={() => {
              setDraft(draftFromRules(view.strategy));
              setErrors({});
              setProblems([]);
            }}
          >
            Start from the strategy&apos;s rules
          </Button>
        ) : null}
        {view.configuration !== null ? (
          <Button
            type="button"
            variant="ghost"
            disabled={archived || pending}
            title={
              view.strategy
                ? "Backtests then use the strategy's declared rules"
                : "Backtests then cannot run until rules are set again"
            }
            onClick={() => clear.mutate()}
          >
            {clear.isPending ? "Removing…" : "Remove its own rules"}
          </Button>
        ) : null}
        <Button type="button" variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit" form={formId} disabled={archived || pending}>
          {save.isPending ? "Saving…" : "Save rules"}
        </Button>
      </DialogFooter>
    </>
  );
}

/**
 * The trade rules a configuration's backtests use: which sides, fills, stop-loss and target, sizing, fees and
 * slippage. They apply to backtests only; the chart and live signals are unaffected.
 */
export function TradeRulesDialog({ deployment, onClose }: { deployment: DeploymentView; onClose: () => void }) {
  const query = useQuery({
    queryKey: queryKeys.backtestRules(deployment.id),
    queryFn: () => backtestsApi.rules(deployment.id),
  });
  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{`Trade rules of ${deployment.label}`}</DialogTitle>
          <DialogDescription>
            How its backtests turn signals into trades. They apply to backtests only: the chart and live signals are
            unaffected. Changing them marks earlier backtests outdated; their results are kept for comparison.
          </DialogDescription>
        </DialogHeader>
        {query.isPending ? (
          <LoadingState label="Loading the trade rules…" />
        ) : query.isError ? (
          <ErrorState error={query.error} title="The trade rules did not load" onRetry={() => void query.refetch()} />
        ) : (
          <RulesForm key={deployment.id} deployment={deployment} view={query.data} onClose={onClose} />
        )}
      </DialogContent>
    </Dialog>
  );
}
