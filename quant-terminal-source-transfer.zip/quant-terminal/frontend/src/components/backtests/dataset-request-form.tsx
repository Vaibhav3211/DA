"use client";

import { useId, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ErrorState, LoadingState } from "@/components/ui/feedback";
import { Field, Input, NativeSelect } from "@/components/ui/input";
import { datasets as datasetsApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type {
  CandleInterval,
  DatasetRequest,
  DatasetSourceOption,
  DatasetSources,
  DatasetView,
} from "@/lib/api/types.gen";
import { DATASET_SOURCE_TEXT, dataLabel } from "@/lib/backtests";
import { IST, formatDate, formatInteger, humanize } from "@/lib/format";
import { cn, errorMessage } from "@/lib/utils";
import { Notice } from "./common";

/** Every dataset query: a new dataset appears in the lists. */
export const DATASET_QUERIES = [["datasets"]] as const;

/** How many days a provider-history request covers by default: two years of daily candles, a year of hourly. */
const DEFAULT_DAYS: Partial<Record<CandleInterval, number>> = { "1d": 730, "1h": 365 };
const DEFAULT_INTRADAY_DAYS = 90;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const DAY_MS = 86_400_000;

const istDay = new Intl.DateTimeFormat("en-CA", { timeZone: IST, year: "numeric", month: "2-digit", day: "2-digit" });

/** The IST calendar date of a moment, as YYYY-MM-DD. */
function istDate(epochMs: number): string {
  const parts = Object.fromEntries(istDay.formatToParts(new Date(epochMs)).map((part) => [part.type, part.value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}

/** A YYYY-MM-DD date moved by whole days. */
function shiftDays(date: string, days: number): string {
  return new Date(Date.parse(`${date}T00:00:00Z`) + days * DAY_MS).toISOString().slice(0, 10);
}

/** Calendar days from one YYYY-MM-DD date to another, both included. */
function spanDays(from: string, to: string): number {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / DAY_MS) + 1;
}

function optionKey(option: DatasetSourceOption): string {
  return `${option.provider}:${option.source}`;
}

function originOf(option: DatasetSourceOption) {
  return { provider: option.provider, source: option.source, simulated: option.source === "SIMULATED" };
}

/** Why an option cannot supply this interval's candles; null when it can. */
function unusableReason(option: DatasetSourceOption, interval: CandleInterval): string | null {
  if (!option.available) return option.reason ?? "unavailable";
  if (!option.intervals.includes(interval)) return `it has no ${interval} candles`;
  return null;
}

interface Draft {
  key: string;
  account: string;
  from: string;
  to: string;
}

type DraftField = "key" | "account" | "from" | "to";

/** Recorded candles default to the whole recorded range; provider history to a recent span ending today. */
function draftFor(option: DatasetSourceOption, interval: CandleInterval, sources: DatasetSources): Draft {
  const usable = option.accounts.filter((account) => account.problem === null);
  const account = option.source === "PROVIDER_HISTORY" && usable.length === 1 ? usable[0].account_id : "";
  const series = option.recorded.find((item) => item.interval === interval);
  if (option.source !== "PROVIDER_HISTORY" && series) {
    // The last candle ends at its bucket's end; the second before it is still on the candle's day.
    return {
      key: optionKey(option),
      account,
      from: istDate(Date.parse(series.first_candle_at)),
      to: istDate(Date.parse(series.last_candle_at) - 1000),
    };
  }
  const days = Math.min(DEFAULT_DAYS[interval] ?? DEFAULT_INTRADAY_DAYS, sources.max_span_days);
  return { key: optionKey(option), account, from: shiftDays(sources.today, 1 - days), to: sources.today };
}

/** Nothing is picked unless exactly one source can supply the interval. */
function initialDraft(sources: DatasetSources, interval: CandleInterval): Draft {
  const usable = sources.options.filter((option) => unusableReason(option, interval) === null);
  return usable.length === 1 ? draftFor(usable[0], interval, sources) : { key: "", account: "", from: "", to: "" };
}

function RequestFields({
  sources,
  interval,
  onRequested,
  onCancel,
}: {
  sources: DatasetSources;
  interval: CandleInterval;
  onRequested: (dataset: DatasetView) => void;
  onCancel?: () => void;
}) {
  const formId = useId();
  const [draft, setDraft] = useState<Draft>(() => initialDraft(sources, interval));
  const [errors, setErrors] = useState<Partial<Record<DraftField, string>>>({});
  const option = sources.options.find((item) => optionKey(item) === draft.key) ?? null;
  const history = option?.source === "PROVIDER_HISTORY";

  const request = useApiMutation({
    mutationFn: (body: DatasetRequest) => datasetsApi.request(body),
    invalidate: DATASET_QUERIES,
    success: (result) =>
      result.created
        ? `Candles of ${sources.symbol} requested: the backtest worker gets them and checks their coverage`
        : `That dataset of ${sources.symbol} was already requested; using it`,
    errorTitle: `Could not request candles of ${sources.symbol}`,
    onSuccess: (result) => onRequested(result.dataset),
  });

  const edit = (field: DraftField, value: string) => {
    setDraft((current) => ({ ...current, [field]: value }));
    setErrors((current) => {
      if (!(field in current)) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
  };

  const submit = () => {
    const found: Partial<Record<DraftField, string>> = {};
    if (option === null) found.key = "Choose where the candles come from.";
    else if (history && draft.account === "") found.account = "Choose the account to download with.";
    if (!ISO_DATE.test(draft.from)) found.from = "Enter a date.";
    if (!ISO_DATE.test(draft.to)) found.to = "Enter a date.";
    else if (draft.to > sources.today) found.to = `Must be ${formatDate(sources.today)} or earlier.`;
    if (found.from === undefined && found.to === undefined) {
      if (draft.from > draft.to) found.from = "Must be on or before the last date.";
      else if (spanDays(draft.from, draft.to) > sources.max_span_days) {
        found.from = `The dates span more than ${formatInteger(sources.max_span_days)} days.`;
      }
    }
    setErrors(found);
    if (option === null || Object.keys(found).length > 0) return;
    request.mutate({
      instrument: sources.instrument_id,
      provider: option.provider,
      source: option.source,
      interval,
      date_from: draft.from,
      date_to: draft.to,
      account_id: history ? draft.account : undefined,
    });
  };

  const perRequest = history ? option.max_days_per_request[interval] : undefined;
  return (
    <form
      id={formId}
      noValidate
      className="flex flex-col gap-4 rounded-md border p-3"
      aria-label={`Get ${interval} candles of ${sources.symbol}`}
      onSubmit={(event) => {
        event.preventDefault();
        submit();
      }}
    >
      <fieldset className="flex flex-col gap-2" disabled={request.isPending}>
        <legend className="mb-1 text-sm font-medium">{`Where the ${interval} candles come from`}</legend>
        {sources.options.map((item) => {
          const key = optionKey(item);
          const id = `${formId}-${key}`;
          const why = unusableReason(item, interval);
          const days = item.max_days_per_request[interval];
          return (
            <label
              key={key}
              htmlFor={id}
              className={cn("flex items-start gap-2 rounded-md border p-2 text-sm", why !== null && "opacity-70")}
            >
              <input
                id={id}
                type="radio"
                name={`${formId}-source`}
                className="mt-0.5 accent-primary"
                checked={draft.key === key}
                disabled={why !== null}
                onChange={() => {
                  setDraft(draftFor(item, interval, sources));
                  setErrors({});
                }}
              />
              <span className="flex min-w-0 flex-col gap-0.5">
                <span className="font-medium">{dataLabel(originOf(item))}</span>
                <span className="text-xs text-muted-foreground">{DATASET_SOURCE_TEXT[item.source]}</span>
                {why !== null ? <span className="text-xs text-amber-200">{`Unavailable: ${why}.`}</span> : null}
                {item.source === "PROVIDER_HISTORY" && days !== undefined ? (
                  <span className="text-xs text-muted-foreground">{`Downloaded in requests of up to ${formatInteger(days)} days each.`}</span>
                ) : null}
                {item.recorded.map((series) => (
                  <span key={series.interval} className="text-xs text-muted-foreground">
                    {`Recorded ${series.interval}: ${formatInteger(series.candles)} candles, ${formatDate(series.first_candle_at)} to ${formatDate(series.last_candle_at)}`}
                  </span>
                ))}
                {item.note ? <span className="text-xs text-muted-foreground">{item.note}</span> : null}
              </span>
            </label>
          );
        })}
        {errors.key ? (
          <p role="alert" className="text-xs text-red-300">
            {errors.key}
          </p>
        ) : null}
      </fieldset>

      {option?.source === "SIMULATED" ? (
        <Notice>
          <p>Simulator candles are not market prices. Backtests over them are labelled SIMULATED everywhere.</p>
        </Notice>
      ) : null}

      {history ? (
        option.accounts.length === 1 ? (
          <p className="text-xs text-muted-foreground">
            {`Downloaded with ${option.accounts[0].label}${option.accounts[0].problem ? `: ${option.accounts[0].problem}` : ""}.`}
          </p>
        ) : (
          <Field
            label="Account"
            htmlFor={`${formId}-account`}
            hint={`The ${humanize(option.provider)} account to download with; it needs a current access token.`}
            error={errors.account}
          >
            <NativeSelect
              id={`${formId}-account`}
              value={draft.account}
              disabled={request.isPending}
              aria-invalid={errors.account !== undefined}
              aria-describedby={errors.account ? `${formId}-account-error` : undefined}
              onChange={(event) => edit("account", event.target.value)}
            >
              <option value="">Choose…</option>
              {option.accounts.map((account) => (
                <option key={account.account_id} value={account.account_id} disabled={account.problem !== null}>
                  {account.problem ? `${account.label} (${account.problem})` : account.label}
                </option>
              ))}
            </NativeSelect>
          </Field>
        )
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="From" htmlFor={`${formId}-from`} error={errors.from}>
          <Input
            id={`${formId}-from`}
            type="date"
            value={draft.from}
            max={sources.today}
            disabled={request.isPending}
            aria-invalid={errors.from !== undefined}
            aria-describedby={errors.from ? `${formId}-from-error` : undefined}
            onChange={(event) => edit("from", event.target.value)}
          />
        </Field>
        <Field label="To" htmlFor={`${formId}-to`} error={errors.to}>
          <Input
            id={`${formId}-to`}
            type="date"
            value={draft.to}
            max={sources.today}
            disabled={request.isPending}
            aria-invalid={errors.to !== undefined}
            aria-describedby={errors.to ? `${formId}-to-error` : undefined}
            onChange={(event) => edit("to", event.target.value)}
          />
        </Field>
      </div>
      <p className="text-xs text-muted-foreground">
        {`IST calendar dates, both included. A dataset spans at most ${formatInteger(sources.max_span_days)} days and ${formatInteger(sources.max_candles)} candles.${perRequest ? ` ${humanize(option?.provider ?? "")} history is downloaded ${formatInteger(perRequest)} days at a time.` : ""} Coverage and missing candles are measured against the exchange calendar once it is built.`}
      </p>
      {sources.worker_problem ? <p className="text-xs text-amber-200">{`${sources.worker_problem}.`}</p> : null}
      {request.error ? (
        <Notice tone="destructive" title="Not requested">
          <p role="alert">{errorMessage(request.error)}</p>
        </Notice>
      ) : null}
      <div className="flex flex-wrap justify-end gap-2">
        {onCancel ? (
          <Button type="button" size="sm" variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
        ) : null}
        <Button type="submit" size="sm" disabled={request.isPending}>
          {request.isPending ? "Requesting…" : "Request candles"}
        </Button>
      </div>
    </form>
  );
}

/**
 * Asks for a dataset: candles of one instrument and interval over a date range, from a provider's history API
 * or the candles recorded from a feed. Sources that cannot supply them are listed with the reason, never
 * substituted. The backtest worker gets the candles and measures their coverage.
 */
export function DatasetRequestForm({
  instrumentId,
  interval,
  onRequested,
  onCancel,
}: {
  instrumentId: string;
  interval: CandleInterval;
  onRequested: (dataset: DatasetView) => void;
  onCancel?: () => void;
}) {
  const query = useQuery({
    queryKey: queryKeys.datasetSources(instrumentId),
    queryFn: () => datasetsApi.sources(instrumentId),
  });
  if (query.isPending) return <LoadingState label="Loading where candles can come from…" />;
  if (query.isError) {
    return (
      <ErrorState error={query.error} title="The candle sources did not load" onRetry={() => void query.refetch()} />
    );
  }
  return (
    <RequestFields
      key={`${instrumentId}:${interval}`}
      sources={query.data}
      interval={interval}
      onRequested={onRequested}
      onCancel={onCancel}
    />
  );
}
