"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { DetailList, DetailRow } from "@/components/ui/details";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ErrorState, LoadingState, Spinner } from "@/components/ui/feedback";
import { backtests as backtestsApi, datasets as datasetsApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type {
  BacktestDetail,
  BacktestLatest,
  BacktestQueueResult,
  BacktestRunView,
  DatasetView,
  DeploymentView,
} from "@/lib/api/types.gen";
import { RULES_SOURCE_TEXT, coverageText, isActive, isSimulated } from "@/lib/backtests";
import { formatDate, formatDateTime, formatInteger } from "@/lib/format";
import { cn } from "@/lib/utils";
import { BacktestStateBadge, DataBadge, Hash, Notice, RunStatusBadge, Section } from "./common";
import { DatasetRequestForm } from "./dataset-request-form";
import { ACTIVE_POLL_MS, latestBacktestQuery } from "./latest-backtest";
import { BACKTEST_QUERIES, TradeRulesDialog } from "./trade-rules-dialog";

const DATASET_LIMIT = 50;

function DatasetChoice({
  dataset,
  name,
  checked,
  onPick,
}: {
  dataset: DatasetView;
  name: string;
  checked: boolean;
  onPick: () => void;
}) {
  const id = `${name}-${dataset.id}`;
  return (
    <label htmlFor={id} className={cn("flex items-start gap-2 rounded-md border p-2 text-sm", checked && "border-primary")}>
      <input id={id} type="radio" name={name} className="mt-0.5 accent-primary" checked={checked} onChange={onPick} />
      <span className="flex min-w-0 flex-col gap-0.5">
        <span className="flex flex-wrap items-center gap-2">
          <DataBadge origin={dataset} />
          <span>{`${formatDate(dataset.date_from)} to ${formatDate(dataset.date_to)}`}</span>
          <span className="text-xs text-muted-foreground">{`${formatInteger(dataset.candle_count)} candles`}</span>
        </span>
        <span className="text-xs text-muted-foreground">
          {dataset.coverage ? `Coverage ${coverageText(dataset.coverage)}` : "Coverage not measured"}
        </span>
        <span className="text-xs text-muted-foreground">
          {`Built ${formatDateTime(dataset.finished_at)} · content `}
          {dataset.content_sha ? <Hash value={dataset.content_sha} /> : "—"}
        </span>
      </span>
    </label>
  );
}

function FollowedRun({
  result,
  run,
  onOpenResults,
}: {
  result: BacktestQueueResult;
  run: BacktestRunView;
  onOpenResults: (runId: string) => void;
}) {
  const active = isActive(run.status);
  const text = result.created
    ? "Queued just now."
    : run.status === "SUCCEEDED"
      ? "This exact backtest (the same settings and dataset) already succeeded, so it was not run again."
      : "This exact backtest (the same settings and dataset) was already queued; following that one.";
  return (
    <Notice tone={run.status === "FAILED" ? "destructive" : "info"} title="Backtest">
      <p className="flex flex-wrap items-center gap-2">
        {active ? <Spinner className="size-3" /> : null}
        <RunStatusBadge status={run.status} />
        <span>{text}</span>
      </p>
      {active ? (
        <p>
          It runs on the backtest worker, not in the browser: you can close this dialog, and the configuration&apos;s
          panel shows the result when it is done.
        </p>
      ) : null}
      {active && result.worker_problem ? <p className="text-amber-200">{`${result.worker_problem}.`}</p> : null}
      {run.status === "FAILED" ? <p>{`It failed: ${run.error ?? "no reason recorded"}`}</p> : null}
      {run.status === "SUCCEEDED" ? (
        <div>
          <Button size="sm" onClick={() => onOpenResults(run.id)}>
            View results
          </Button>
        </div>
      ) : null}
    </Notice>
  );
}

function RunPanel({
  deployment,
  instrumentId,
  symbol,
  latest,
  onOpenRules,
  onOpenResults,
  onClose,
}: {
  deployment: DeploymentView;
  instrumentId: string;
  symbol: string;
  latest: BacktestLatest;
  onOpenRules: () => void;
  onOpenResults: (runId: string) => void;
  onClose: () => void;
}) {
  const interval = latest.interval;
  const [picked, setPicked] = useState<string | null>(null);
  const [requesting, setRequesting] = useState(false);
  const [queued, setQueued] = useState<BacktestQueueResult | null>(null);

  const filters = { instrument: instrumentId, interval: interval ?? undefined, limit: DATASET_LIMIT };
  const list = useQuery({
    queryKey: queryKeys.datasetList(filters),
    queryFn: () => datasetsApi.list(filters),
    enabled: interval !== null,
    refetchInterval: (query: { state: { data: DatasetView[] | undefined } }) =>
      query.state.data?.some((dataset) => isActive(dataset.status)) ? ACTIVE_POLL_MS : false,
  });
  const queuedId = queued?.run.id ?? "";
  const followed = useQuery({
    queryKey: queryKeys.backtest(queuedId),
    queryFn: () => backtestsApi.get(queuedId),
    enabled: queued !== null,
    refetchInterval: (query: { state: { data: BacktestDetail | undefined } }) => {
      const status = query.state.data?.run.status;
      return status !== undefined && isActive(status) ? ACTIVE_POLL_MS : false;
    },
  });
  const queue = useApiMutation({
    mutationFn: (datasetId: string) =>
      backtestsApi.queue({ deployment_id: deployment.id, instrument: instrumentId, dataset_id: datasetId }),
    invalidate: BACKTEST_QUERIES,
    success: (result) => (result.created ? `Backtest of ${deployment.label} on ${symbol} queued` : null),
    errorTitle: `Could not queue a backtest of ${deployment.label} on ${symbol}`,
    onSuccess: (result) => setQueued(result),
  });

  const datasets = list.data ?? [];
  const ready = datasets.filter((dataset) => dataset.status === "READY");
  const working = datasets.filter((dataset) => isActive(dataset.status));
  const failed = datasets.filter((dataset) => dataset.status === "FAILED");
  const pickedDataset = picked === null ? undefined : datasets.find((dataset) => dataset.id === picked);
  // A requested dataset is chosen once it is READY; until then nothing is, so an older one is not run by mistake.
  const selected =
    pickedDataset === undefined ? (ready[0] ?? null) : pickedDataset.status === "READY" ? pickedDataset : null;
  const showRequest = interval !== null && (requesting || (list.isSuccess && datasets.length === 0));
  const run = followed.data?.run ?? queued?.run ?? null;
  const blocked = latest.problem !== null;

  return (
    <>
      <DetailList>
        <DetailRow label="Configuration">
          {`${deployment.label}: ${deployment.strategy_id} v${deployment.strategy_version}`}
        </DetailRow>
        <DetailRow label="Instrument">{symbol}</DetailRow>
        <DetailRow label="Candles">{interval ?? "No single interval"}</DetailRow>
        <DetailRow label="Trade rules">
          <span className="flex flex-wrap items-center gap-2">
            {latest.rules.source ? RULES_SOURCE_TEXT[latest.rules.source] : "None apply"}
            <Button size="sm" variant="ghost" onClick={onOpenRules}>
              Trade rules…
            </Button>
          </span>
        </DetailRow>
        <DetailRow label="Latest result">
          <BacktestStateBadge state={latest.state} />
        </DetailRow>
      </DetailList>
      {latest.problem ? (
        <Notice tone="destructive">
          <p>{`It cannot be backtested on ${symbol} now: ${latest.problem}.`}</p>
        </Notice>
      ) : null}
      {latest.worker_problem ? (
        <Notice>
          <p>{`${latest.worker_problem}. Requested candles and queued backtests wait until it runs.`}</p>
        </Notice>
      ) : null}

      {interval !== null ? (
        <Section title={`${interval} candles of ${symbol}`}>
          <p className="text-xs text-muted-foreground">
            A backtest replays a stored dataset: fixed candles with a content hash, so the same dataset and settings
            give the same result. Choose one, or get candles for the dates you want.
          </p>
          {list.isPending ? (
            <LoadingState label="Loading datasets…" />
          ) : list.isError ? (
            <ErrorState error={list.error} title="The datasets did not load" onRetry={() => void list.refetch()} />
          ) : (
            <>
              {ready.length > 0 ? (
                <fieldset className="flex flex-col gap-2">
                  <legend className="sr-only">Dataset to replay</legend>
                  {ready.map((dataset) => (
                    <DatasetChoice
                      key={dataset.id}
                      dataset={dataset}
                      name={`dataset-${deployment.id}`}
                      checked={selected?.id === dataset.id}
                      onPick={() => setPicked(dataset.id)}
                    />
                  ))}
                </fieldset>
              ) : (
                <p className="text-sm text-muted-foreground">{`No ${interval} dataset of ${symbol} is ready.`}</p>
              )}
              {working.map((dataset) => (
                <p key={dataset.id} className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  <Spinner className="size-3" />
                  <RunStatusBadge status={dataset.status} />
                  <DataBadge origin={dataset} />
                  {`${formatDate(dataset.date_from)} to ${formatDate(dataset.date_to)}: the backtest worker is getting the candles`}
                </p>
              ))}
              {pickedDataset?.status === "FAILED" ? (
                <Notice tone="destructive" title="The requested candles could not be stored">
                  <p>{pickedDataset.error ?? "No reason recorded."}</p>
                </Notice>
              ) : null}
              {failed.length > 0 ? (
                <details className="text-xs text-muted-foreground">
                  <summary className="cursor-pointer">{`${failed.length} failed request${failed.length === 1 ? "" : "s"}`}</summary>
                  <ul className="mt-1 flex flex-col gap-1">
                    {failed.map((dataset) => (
                      <li key={dataset.id}>
                        {`${formatDate(dataset.date_from)} to ${formatDate(dataset.date_to)}, requested ${formatDateTime(dataset.created_at)}: ${dataset.error ?? "no reason recorded"}`}
                      </li>
                    ))}
                  </ul>
                </details>
              ) : null}
              {selected && isSimulated(selected) ? (
                <Notice title="SIMULATED data">
                  <p>The chosen candles come from the development simulator. Its results are labelled SIMULATED.</p>
                </Notice>
              ) : null}
              {selected?.coverage && selected.coverage.missing > 0 ? (
                <p className="text-xs text-amber-200">
                  {`The chosen dataset misses ${formatInteger(selected.coverage.missing)} candles the calendar expects; a backtest replays the candles it has and shows the gaps with its results.`}
                </p>
              ) : null}
              {showRequest ? (
                <DatasetRequestForm
                  instrumentId={instrumentId}
                  interval={interval}
                  onCancel={datasets.length > 0 ? () => setRequesting(false) : undefined}
                  onRequested={(dataset) => {
                    setPicked(dataset.id);
                    setRequesting(false);
                  }}
                />
              ) : (
                <div>
                  <Button size="sm" variant="outline" onClick={() => setRequesting(true)}>
                    Get candles…
                  </Button>
                </div>
              )}
            </>
          )}
        </Section>
      ) : null}

      {queued && run ? <FollowedRun result={queued} run={run} onOpenResults={onOpenResults} /> : null}

      <DialogFooter>
        <Button type="button" variant="ghost" onClick={onClose}>
          Close
        </Button>
        <Button
          type="button"
          disabled={selected === null || blocked || queue.isPending}
          title={
            blocked
              ? "It cannot be backtested now; see why above"
              : selected === null
                ? "Choose a ready dataset first"
                : undefined
          }
          onClick={() => {
            if (selected) queue.mutate(selected.id);
          }}
        >
          {queue.isPending ? "Queueing…" : "Run backtest"}
        </Button>
      </DialogFooter>
    </>
  );
}

/**
 * Runs a backtest of a saved configuration on one instrument. It replays stored candles on the backtest
 * worker: nothing is sent to a broker and live signals are unaffected. Asking twice for the same backtest
 * returns the one already queued, running or done.
 */
export function RunBacktestDialog({
  deployment,
  instrumentId,
  symbol,
  onClose,
  onOpenResults,
}: {
  deployment: DeploymentView;
  instrumentId: string;
  symbol: string;
  onClose: () => void;
  onOpenResults: (runId: string) => void;
}) {
  const latest = useQuery(latestBacktestQuery(deployment.id, instrumentId));
  const [rulesOpen, setRulesOpen] = useState(false);
  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>{`Backtest ${deployment.label} on ${symbol}`}</DialogTitle>
          <DialogDescription>
            Replays the saved configuration over stored candles on the backtest worker. Nothing is sent to a broker,
            and live signals are unaffected.
          </DialogDescription>
        </DialogHeader>
        {latest.isPending ? (
          <LoadingState label="Loading its backtest state…" />
        ) : latest.isError ? (
          <ErrorState error={latest.error} title="Its backtest state did not load" onRetry={() => void latest.refetch()} />
        ) : (
          <RunPanel
            deployment={deployment}
            instrumentId={instrumentId}
            symbol={symbol}
            latest={latest.data}
            onOpenRules={() => setRulesOpen(true)}
            onOpenResults={onOpenResults}
            onClose={onClose}
          />
        )}
        {rulesOpen ? <TradeRulesDialog deployment={deployment} onClose={() => setRulesOpen(false)} /> : null}
      </DialogContent>
    </Dialog>
  );
}
