"use client";

import { SignalTypeBadge } from "@/components/signals/signal-badges";
import { Badge } from "@/components/ui/badge";
import { DetailList, DetailRow } from "@/components/ui/details";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Stat, StatGrid } from "@/components/ui/stat";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { BacktestRunView, BacktestTrade, SignalRef } from "@/lib/api/types.gen";
import { EXIT_REASON_TEXT, formatPnl, isSimulated, recordedParams } from "@/lib/backtests";
import { formatInteger, formatPrice } from "@/lib/format";
import {
  DataBadge,
  Hash,
  Notice,
  OutcomeBadge,
  PnlText,
  Section,
  SimulatedNotice,
  momentText,
  runReplayText,
} from "./common";

/** What the strategy proposed at a candle's close, with its levels, reasons and indicator values. */
export function SignalRefDetails({ signal }: { signal: SignalRef }) {
  const indicators = Object.entries(signal.indicators);
  const levels = signal.entry_price !== null || signal.stop_loss !== null || signal.targets.length > 0;
  return (
    <div className="flex flex-col gap-2">
      <p className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <SignalTypeBadge type={signal.signal_type} />
        {`decided at ${momentText(signal.decided_at)}, the close of the candle from ${momentText(signal.candle_start)}`}
      </p>
      {levels ? (
        <StatGrid>
          <Stat label="Entry" value={formatPrice(signal.entry_price)} />
          <Stat label="Stop-loss" value={formatPrice(signal.stop_loss)} />
          {signal.targets.map((target) => (
            <Stat key={target.label} label={target.label} value={formatPrice(target.price)} />
          ))}
        </StatGrid>
      ) : null}
      {signal.reasons.length > 0 ? (
        <ul className="list-disc pl-5 text-sm text-muted-foreground">
          {signal.reasons.map((reason, index) => (
            <li key={`${index}:${reason}`}>{reason}</li>
          ))}
        </ul>
      ) : (
        <p className="text-xs text-muted-foreground">The strategy gave no reasons.</p>
      )}
      {indicators.length > 0 ? (
        <DetailList>
          {indicators.map(([name, value]) => (
            <DetailRow key={name} label={name}>
              <span className="font-mono">{value ?? "—"}</span>
            </DetailRow>
          ))}
        </DetailList>
      ) : (
        <p className="text-xs text-muted-foreground">The strategy recorded no indicator values.</p>
      )}
    </div>
  );
}

/** One closed backtest trade: its fills, result, the signals behind it and the settings it ran with. */
export function BacktestTradeDialog({
  run,
  trade,
  onClose,
}: {
  run: BacktestRunView;
  trade: BacktestTrade;
  onClose: () => void;
}) {
  const reason = EXIT_REASON_TEXT[trade.exit_reason];
  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2">
            <span>{`Backtest trade ${formatInteger(trade.number)}`}</span>
            <Badge variant="outline">{trade.side}</Badge>
            <span className="font-mono">{run.symbol}</span>
          </DialogTitle>
          <DialogDescription>
            {`${run.label} · ${run.strategy_id} v${run.strategy_version} · ${runReplayText(run)}`}
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-wrap items-center gap-2">
          <OutcomeBadge outcome={trade.outcome} />
          <Badge variant="outline">{reason}</Badge>
          <DataBadge origin={run} />
          <Badge variant="secondary">Backtest, not a live signal</Badge>
        </div>
        {isSimulated(run) ? <SimulatedNotice /> : null}
        <p className="text-xs text-muted-foreground">
          A fill simulated by replaying stored candles with the trade rules this backtest recorded. No order was
          placed.
        </p>
        <StatGrid>
          <Stat label="Net result" value={<PnlText value={trade.net_pnl} />} title="After fees and slippage" />
          <Stat
            label="Return"
            value={`${formatPnl(trade.return_pct)}%`}
            title="The net result as a percentage of the entry's reference value"
          />
          <Stat
            label="Gross result"
            value={<PnlText value={trade.gross_pnl} />}
            title="At reference prices, before fees and slippage"
          />
          <Stat label="Fees · slippage" value={`${formatPrice(trade.fees)} · ${formatPrice(trade.slippage)}`} />
        </StatGrid>
        <Section title="Fills">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Leg</TableHead>
                <TableHead>In the candle from</TableHead>
                <TableHead className="text-right">Reference</TableHead>
                <TableHead className="text-right">Fill</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>{`Entry: ${trade.side === "LONG" ? "buy" : "sell"} ${formatInteger(trade.quantity)} units`}</TableCell>
                <TableCell>{momentText(trade.entry_at)}</TableCell>
                <TableCell className="text-right font-mono">{formatPrice(trade.entry_reference)}</TableCell>
                <TableCell className="text-right font-mono">{formatPrice(trade.entry_price)}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>{`Exit: ${reason}`}</TableCell>
                <TableCell>{momentText(trade.exit_at)}</TableCell>
                <TableCell className="text-right font-mono">{formatPrice(trade.exit_reference)}</TableCell>
                <TableCell className="text-right font-mono">{formatPrice(trade.exit_price)}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
          <p className="text-xs text-muted-foreground">
            The reference is the open, close or level a fill is based on; the fill price adds the slippage.
          </p>
          <DetailList>
            <DetailRow label="Levels">
              {`Stop-loss ${formatPrice(trade.stop_loss)}, target ${formatPrice(trade.target)}, as in force when it closed`}
            </DetailRow>
            <DetailRow label="Held">{`${formatInteger(trade.candles_held)} candles`}</DetailRow>
          </DetailList>
        </Section>
        {trade.both_touched ? (
          <Notice tone="info" title="Stop-loss and target in one candle">
            <p>
              One candle reached both. The order of prices inside a candle is unknown, so the stop-loss was assumed.
            </p>
          </Notice>
        ) : null}
        {trade.gap_exit ? (
          <Notice tone="info" title="Gap exit">
            <p>The candle opened beyond the level, so the exit filled at the open.</p>
          </Notice>
        ) : null}
        <Section title="Entry signal">
          <SignalRefDetails signal={trade.entry_signal} />
        </Section>
        {trade.exit_signal ? (
          <Section title="Exit signal">
            <SignalRefDetails signal={trade.exit_signal} />
          </Section>
        ) : null}
        <Section title="Recorded with">
          <DetailList>
            <DetailRow label="Configuration">{run.label}</DetailRow>
            <DetailRow label="Strategy">{`${run.strategy_id} v${run.strategy_version}`}</DetailRow>
            <DetailRow label="Code fingerprint">
              <Hash value={run.code_fingerprint} />
            </DetailRow>
            <DetailRow label="Parameters">{recordedParams(run.settings)}</DetailRow>
            <DetailRow label="Settings hash">
              <Hash value={run.settings_hash} />
            </DetailRow>
            <DetailRow label="Dataset hash">
              <Hash value={run.dataset_sha} />
            </DetailRow>
            <DetailRow label="Backtest">
              <span className="font-mono">{run.id}</span>
            </DetailRow>
          </DetailList>
        </Section>
      </DialogContent>
    </Dialog>
  );
}
