"use client";

// Loaded only in the browser (next/dynamic, ssr: false): lightweight-charts draws on a canvas.

import {
  ColorType,
  createChart,
  CrosshairMode,
  LineSeries,
  LineStyle,
  type TickMarkType,
  type Time,
} from "lightweight-charts";
import { useEffect, useRef } from "react";
import type { CandleInterval, EquityPoint } from "@/lib/api/types.gen";
import { equitySeries } from "@/lib/backtests";
import { CHART_COLORS, chartTickLabel, chartTimeLabel } from "@/lib/chart";

export interface EquityChartProps {
  points: readonly EquityPoint[];
  interval: CandleInterval;
  /** The initial capital, drawn as a dashed line; null when it is not known. */
  baseline: string | null;
}

/** A backtest's equity at each candle's close, the open position marked to the close. */
export default function EquityChart({ points, interval, baseline }: EquityChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = containerRef.current;
    if (element === null) return;
    const chart = createChart(element, {
      autoSize: true,
      layout: {
        background: { type: ColorType.Solid, color: CHART_COLORS.background },
        textColor: CHART_COLORS.text,
      },
      grid: { vertLines: { color: CHART_COLORS.grid }, horzLines: { color: CHART_COLORS.grid } },
      crosshair: { mode: CrosshairMode.Normal },
      rightPriceScale: { borderColor: CHART_COLORS.border },
      timeScale: {
        borderColor: CHART_COLORS.border,
        timeVisible: interval !== "1d",
        secondsVisible: interval === "1s",
        tickMarkFormatter: (time: Time, tickMarkType: TickMarkType) =>
          typeof time === "number" ? chartTickLabel(time, tickMarkType) : null,
      },
      localization: {
        timeFormatter: (time: Time) => (typeof time === "number" ? chartTimeLabel(time, interval) : String(time)),
      },
    });
    const equity = chart.addSeries(LineSeries, {
      color: CHART_COLORS.equity,
      lineWidth: 2,
      priceFormat: { type: "price", precision: 2, minMove: 0.01 },
      priceLineVisible: false,
    });
    equity.setData(equitySeries(points));
    const start = baseline === null ? Number.NaN : Number(baseline);
    if (Number.isFinite(start)) {
      equity.createPriceLine({
        price: start,
        color: CHART_COLORS.text,
        lineWidth: 1,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: "Initial capital",
      });
    }
    chart.timeScale().fitContent();
    return () => chart.remove();
  }, [points, interval, baseline]);

  return (
    <div
      ref={containerRef}
      role="img"
      aria-label="Equity curve: the equity at each candle's close"
      className="h-[260px] w-full"
    />
  );
}
