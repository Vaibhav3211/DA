"use client";

import type { UseQueryResult } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/feedback";
import { backtests as backtestsApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { BacktestLatest, BacktestRunView } from "@/lib/api/types.gen";
import { METRIC_DEFINITIONS, changedLabel, formatPnl, measureText } from "@/lib/backtests";
import { formatDateTime, formatInteger } from "@/lib/format";
import { errorMessage } from "@/lib/utils";
import { BacktestStateBadge, DataBadge, PnlText, RunStatusBadge, runReplayText } from "./common";

/** While a backtest waits or runs, its state is polled this often. */
export const ACTIVE_POLL_MS = 3_000;
const LATEST_POLL_MS = 60_000;

/**
 * A configuration's latest backtest on one instrument, measured against its current settings. Reading it never
 * runs a backtest, and price updates do not refresh it: it is polled, faster while a backtest waits or runs.
 */
export function latestBacktestQuery(deploymentId: string, instrumentId: string) {
  return {
    queryKey: queryKeys.latestBacktest(deploymentId, instrumentId),
    queryFn: () => backtestsApi.latest(deploymentId, instrumentId),
    refetchInterval: (query: { state: { data: BacktestLatest | undefined } }) =>
      query.state.data?.in_progress ? ACTIVE_POLL_MS : LATEST_POLL_MS,
  };
}

/** A backtest dialog a configuration can open. */
export type BacktestDialogRequest =
  | { kind: "run" }
  | { kind: "rules" }
  | { kind: "results"; runId: string }
  | { kind: "history" };

/** A succeeded run's headline numbers, each with its definition on hover. */
export function RunHeadline({ run }: { run: BacktestRunView }) {
  const metrics = run.summary?.metrics;
  if (!metrics) return null;
  if (metrics.closed_trades === 0) {
    return (
      <p className="text-muted-foreground" title={METRIC_DEFINITIONS.closedTrades}>
        No closed trades, so its win rate and other trade metrics are undefined (not zero).
      </p>
    );
  }
  const winRate = measureText(metrics.win_rate_pct, "%");
  const drawdown = measureText(metrics.max_drawdown_pct, "%");
  return (
    <p className="flex flex-wrap gap-x-3 gap-y-1 font-mono tabular-nums">
      <span title={METRIC_DEFINITIONS.closedTrades}>
        {`${formatInteger(metrics.closed_trades)} closed trades (${metrics.wins} W, ${metrics.losses} L, ${metrics.breakevens} BE)`}
      </span>
      <span title={winRate.reason ?? METRIC_DEFINITIONS.winRate}>{`Win rate ${winRate.text}`}</span>
      <span title={METRIC_DEFINITIONS.net}>
        Net <PnlText value={metrics.net_pnl} /> {`(${formatPnl(metrics.net_return_pct)}%)`}
      </span>
      <span title={drawdown.reason ?? METRIC_DEFINITIONS.maxDrawdown}>{`Max drawdown ${drawdown.text}`}</span>
    </p>
  );
}

/** Where a waiting or running backtest is. */
export function ActiveRunLine({ run, workerProblem }: { run: BacktestRunView; workerProblem: string | null }) {
  return (
    <div className="flex flex-col gap-1">
      <p className="flex flex-wrap items-center gap-2">
        <Spinner className="size-3" />
        <RunStatusBadge status={run.status} />
        <span className="text-muted-foreground">
          {run.status === "RUNNING"
            ? `Running since ${formatDateTime(run.started_at)} on ${runReplayText(run)}`
            : `Queued ${formatDateTime(run.created_at)} on ${runReplayText(run)}; waiting for the backtest worker`}
        </span>
      </p>
      {workerProblem ? <p className="text-amber-200">{`${workerProblem}.`}</p> : null}
    </div>
  );
}

/**
 * A configuration's backtest beside the chart: its latest result against the current settings ("Not
 * backtested" when none succeeded), whether it is outdated and why, and any backtest waiting or running.
 */
export function LatestBacktestSummary({
  query,
  symbol,
  onOpen,
}: {
  query: UseQueryResult<BacktestLatest>;
  symbol: string;
  onOpen: (request: BacktestDialogRequest) => void;
}) {
  if (query.isPending) return <p className="text-xs text-muted-foreground">Backtest: loading…</p>;
  if (query.isError) {
    return (
      <p className="flex flex-wrap items-center gap-2 text-xs text-red-300">
        {`Backtest: did not load (${errorMessage(query.error)}).`}
        <Button size="sm" variant="ghost" onClick={() => void query.refetch()}>
          Retry
        </Button>
      </p>
    );
  }
  const latest = query.data;
  const shown = latest.current ?? latest.outdated;
  const others = latest.outdated_runs;
  return (
    <div className="flex flex-col gap-1.5 rounded-md bg-muted/30 p-2 text-xs" aria-label="Backtest">
      <p className="flex flex-wrap items-center gap-2">
        <span className="text-muted-foreground">Backtest</span>
        <BacktestStateBadge state={latest.state} />
        {shown ? (
          <>
            <DataBadge origin={shown} />
            <span className="text-muted-foreground">{runReplayText(shown)}</span>
          </>
        ) : null}
      </p>
      {shown ? (
        <RunHeadline run={shown} />
      ) : (
        <p className="text-muted-foreground">
          {`No backtest of this configuration on ${symbol} has succeeded. Nothing runs until you run one.`}
        </p>
      )}
      {latest.state === "OUTDATED" ? (
        <p className="text-amber-200">
          {`Changed since that backtest: ${latest.changed.map(changedLabel).join(", ") || "its settings"}. Its results are kept for comparison; run a new backtest for the current settings.`}
        </p>
      ) : null}
      {latest.in_progress ? <ActiveRunLine run={latest.in_progress} workerProblem={latest.worker_problem} /> : null}
      {latest.last_failed ? (
        <p className="text-red-300">{`The latest backtest failed: ${latest.last_failed.error ?? "no reason recorded"}`}</p>
      ) : null}
      {latest.problem ? (
        <p className="text-amber-200">{`It cannot be backtested on ${symbol} now: ${latest.problem}.`}</p>
      ) : null}
      <div className="flex flex-wrap gap-1">
        {shown ? (
          <Button size="sm" variant="ghost" onClick={() => onOpen({ kind: "results", runId: shown.id })}>
            {latest.state === "CURRENT" ? "Results…" : "Outdated results…"}
          </Button>
        ) : null}
        {shown || others > 0 || latest.last_failed || latest.in_progress ? (
          <Button
            size="sm"
            variant="ghost"
            title={
              others > 0
                ? `${others} succeeded run${others === 1 ? "" : "s"} with other settings ${others === 1 ? "is" : "are"} kept for comparison`
                : undefined
            }
            onClick={() => onOpen({ kind: "history" })}
          >
            All runs…
          </Button>
        ) : null}
        <Button size="sm" variant="ghost" onClick={() => onOpen({ kind: "rules" })}>
          Trade rules…
        </Button>
      </div>
    </div>
  );
}
