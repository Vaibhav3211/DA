import { describe, expect, it } from "vitest";
import { workspacePause } from "@/components/risk/risk-rules";
import { WORKSPACE_PAUSE } from "@/lib/api/endpoints";
import type { RiskRuleView } from "@/lib/api/types.gen";

function pauseRule(enabled: boolean, params: Record<string, unknown>): RiskRuleView {
  return {
    rule_key: WORKSPACE_PAUSE,
    description: "Pause the workspace's signals",
    mandatory: false,
    workspace_slug: "nifty",
    enabled,
    source: "workspace",
    params,
    defaults: { paused: false, reason: null },
    error: null,
    updated_by: "admin",
    updated_at: "2025-01-01T03:45:00Z",
  };
}

describe("workspacePause", () => {
  it("pauses only for an enabled rule that says so", () => {
    expect(workspacePause([pauseRule(true, { paused: true, reason: "Budget day" })])).toEqual({
      paused: true,
      reason: "Budget day",
    });
    expect(workspacePause([pauseRule(true, { paused: true, reason: "" })])).toEqual({ paused: true, reason: null });
    expect(workspacePause([pauseRule(false, { paused: true, reason: "Budget day" })])).toEqual({
      paused: false,
      reason: null,
    });
    expect(workspacePause([pauseRule(true, { paused: "true" })])).toEqual({ paused: false, reason: null });
    expect(workspacePause(undefined)).toEqual({ paused: false, reason: null });
  });
});
