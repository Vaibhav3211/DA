"use client";

import { useQuery } from "@tanstack/react-query";
import { useId, useState } from "react";
import { Badge, type BadgeVariant } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { EmptyState, ErrorState, LoadingState, Spinner } from "@/components/ui/feedback";
import { Field, Textarea } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { risk as riskApi, WORKSPACE_PAUSE } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type { RiskRuleView } from "@/lib/api/types.gen";
import { formatDateTime, humanize } from "@/lib/format";

type SourceStyle = { label: string; variant: BadgeVariant; help: string };

const SOURCE: Record<string, SourceStyle> = {
  default: { label: "Default", variant: "outline", help: "The code's default: nothing is stored for it." },
  global: { label: "Global", variant: "secondary", help: "Set for every workspace." },
  workspace: { label: "Workspace", variant: "info", help: "Set for this workspace only." },
};

/** The rules that apply to history are in each backtest's settings, so changing one can outdate backtests. */
const RISK_RULE_QUERIES = [["risk"], ["backtests"]] as const;

export function useRiskRules(workspace: string | null) {
  return useQuery({
    queryKey: queryKeys.riskRules(workspace),
    queryFn: () => riskApi.rules(workspace ?? undefined),
  });
}

/** Whether a workspace's signals are paused, from its effective rules. */
export function workspacePause(rules: readonly RiskRuleView[] | undefined): { paused: boolean; reason: string | null } {
  const rule = rules?.find((item) => item.rule_key === WORKSPACE_PAUSE);
  const paused = rule !== undefined && rule.enabled && rule.params.paused === true;
  const reason = rule?.params.reason;
  return { paused, reason: paused && typeof reason === "string" && reason ? reason : null };
}

function paramText(value: unknown): string {
  if (value === null || value === undefined) return "none";
  return typeof value === "object" ? JSON.stringify(value) : String(value);
}

function ParamList({ rule }: { rule: RiskRuleView }) {
  const entries = Object.entries(rule.params);
  if (entries.length === 0) return <span className="text-xs text-muted-foreground">No parameters</span>;
  return (
    <ul className="flex flex-col gap-0.5 font-mono text-[11px]">
      {entries.map(([key, value]) => {
        const changed = JSON.stringify(value) !== JSON.stringify(rule.defaults[key]);
        return (
          <li key={key} title={changed ? `Default: ${paramText(rule.defaults[key])}` : undefined}>
            <span className="text-muted-foreground">{key}:</span>{" "}
            <span className={changed ? "font-semibold text-amber-200" : undefined}>{paramText(value)}</span>
          </li>
        );
      })}
    </ul>
  );
}

function EditParamsDialog({
  rule,
  workspace,
  onClose,
}: {
  rule: RiskRuleView;
  workspace: string | null;
  onClose: () => void;
}) {
  const textId = useId();
  const [text, setText] = useState(() => JSON.stringify(rule.params, null, 2));
  const [error, setError] = useState<string | null>(null);
  const save = useApiMutation({
    mutationFn: (params: Record<string, unknown>) => riskApi.setRule(rule.rule_key, { params }, workspace ?? undefined),
    invalidate: RISK_RULE_QUERIES,
    success: `${humanize(rule.rule_key)} updated`,
    errorTitle: `Could not update ${humanize(rule.rule_key)}`,
    onSuccess: onClose,
  });

  const submit = () => {
    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = null;
    }
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
      setError("Enter a JSON object");
      return;
    }
    // Only the changed keys are stored, so the others keep following the layer below.
    const changed = Object.fromEntries(
      Object.entries(parsed).filter(([key, value]) => JSON.stringify(value) !== JSON.stringify(rule.params[key])),
    );
    if (Object.keys(changed).length === 0) {
      setError("Nothing changed");
      return;
    }
    setError(null);
    save.mutate(changed);
  };

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{`Tune ${humanize(rule.rule_key)}`}</DialogTitle>
          <DialogDescription>{rule.description}</DialogDescription>
        </DialogHeader>
        <form
          id={`${textId}-form`}
          onSubmit={(event) => {
            event.preventDefault();
            submit();
          }}
        >
          <Field
            label={workspace ? `Parameters for ${workspace}` : "Parameters for every workspace"}
            htmlFor={textId}
            error={error}
            hint="Changed keys are saved at this level; the rest keep their inherited values. Reset drops them all."
          >
            <Textarea
              id={textId}
              rows={10}
              spellCheck={false}
              value={text}
              aria-invalid={error ? true : undefined}
              aria-describedby={error ? `${textId}-error` : undefined}
              onChange={(event) => {
                setText(event.target.value);
                setError(null);
              }}
            />
          </Field>
        </form>
        <details className="text-xs">
          <summary className="cursor-pointer text-muted-foreground">Code defaults</summary>
          <pre className="mt-2 overflow-auto rounded-md border p-2 font-mono text-[11px]">
            {JSON.stringify(rule.defaults, null, 2)}
          </pre>
        </details>
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form={`${textId}-form`} disabled={save.isPending}>
            {save.isPending ? <Spinner /> : null}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Risk rules at one level: a workspace's effective rules, or the global layer when workspace is null. */
export function RiskRulesTable({ workspace }: { workspace: string | null }) {
  const rules = useRiskRules(workspace);
  const [editing, setEditing] = useState<RiskRuleView | null>(null);
  const level = workspace === null ? "global" : "workspace";
  const scope = workspace ?? undefined;
  const toggle = useApiMutation({
    mutationFn: ({ rule, enabled }: { rule: RiskRuleView; enabled: boolean }) =>
      riskApi.setRule(rule.rule_key, { enabled }, scope),
    invalidate: RISK_RULE_QUERIES,
    success: (view) => `${humanize(view.rule_key)} ${view.enabled ? "enabled" : "disabled"}`,
    errorTitle: "Could not switch the rule",
  });
  const reset = useApiMutation({
    mutationFn: (rule: RiskRuleView) => riskApi.resetRule(rule.rule_key, scope),
    invalidate: RISK_RULE_QUERIES,
    success: (view) => `${humanize(view.rule_key)} now follows the ${view.source === "global" ? "global setting" : "default"}`,
    errorTitle: "Could not reset the rule",
  });

  if (rules.isPending) return <LoadingState />;
  if (rules.isError) return <ErrorState error={rules.error} onRetry={() => void rules.refetch()} />;
  if (rules.data.length === 0) return <EmptyState title="No risk rules" />;
  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Rule</TableHead>
            <TableHead>Enabled</TableHead>
            <TableHead>Parameters</TableHead>
            <TableHead>Set at</TableHead>
            <TableHead className="text-right">
              <span className="sr-only">Actions</span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rules.data.map((rule) => {
            const source: SourceStyle = SOURCE[rule.source] ?? {
              label: humanize(rule.source),
              variant: "outline",
              help: "",
            };
            const name = humanize(rule.rule_key);
            const busy =
              (toggle.isPending && toggle.variables?.rule.rule_key === rule.rule_key) ||
              (reset.isPending && reset.variables?.rule_key === rule.rule_key);
            return (
              <TableRow key={rule.rule_key}>
                <TableCell className="max-w-sm">
                  <span className="font-medium">{name}</span>
                  {rule.mandatory ? (
                    <Badge variant="outline" className="ml-1" title="Mandatory rules cannot be disabled">
                      Mandatory
                    </Badge>
                  ) : null}
                  <span className="block text-xs text-muted-foreground">{rule.description}</span>
                  {rule.error ? <span className="block text-xs text-red-300">{rule.error}</span> : null}
                </TableCell>
                <TableCell>
                  <Switch
                    checked={rule.enabled}
                    disabled={busy || (rule.mandatory && rule.enabled)}
                    title={rule.mandatory ? "Mandatory: tune its parameters instead" : undefined}
                    aria-label={`${rule.enabled ? "Disable" : "Enable"} ${name}`}
                    onCheckedChange={(enabled) => toggle.mutate({ rule, enabled })}
                  />
                </TableCell>
                <TableCell>
                  <ParamList rule={rule} />
                </TableCell>
                <TableCell className="text-xs">
                  <Badge variant={source.variant} title={source.help}>
                    {source.label}
                  </Badge>
                  {rule.updated_at ? (
                    <span className="mt-1 block text-muted-foreground">
                      {formatDateTime(rule.updated_at)}
                      {rule.updated_by ? ` by ${rule.updated_by}` : ""}
                    </span>
                  ) : null}
                </TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  <Button
                    size="sm"
                    variant="ghost"
                    disabled={Object.keys(rule.defaults).length === 0}
                    onClick={() => setEditing(rule)}
                  >
                    Tune
                  </Button>
                  {rule.source === level ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      disabled={busy}
                      title={`Drop this ${level} setting so the ${level === "workspace" ? "global setting or default" : "default"} applies`}
                      onClick={() => reset.mutate(rule)}
                    >
                      Reset
                    </Button>
                  ) : null}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      {editing ? (
        <EditParamsDialog key={editing.rule_key} rule={editing} workspace={workspace} onClose={() => setEditing(null)} />
      ) : null}
    </>
  );
}
