import type { ConnectionState, DataStatus } from "@/lib/api/types.gen";
import { humanize } from "@/lib/format";
import { CONNECTION_STATE_STYLE, DATA_STATUS_STYLE } from "@/lib/status";
import { cn } from "@/lib/utils";

const pill =
  "inline-flex items-center gap-1 rounded border px-1.5 py-0.5 font-mono text-[10px] font-semibold tracking-wider whitespace-nowrap";

export function StatusBadge({ status, className, title }: { status: DataStatus; className?: string; title?: string }) {
  const style = DATA_STATUS_STYLE[status];
  return (
    <span data-status={status} title={title ?? style.description} className={cn(pill, style.className, className)}>
      <span aria-hidden className="size-1.5 rounded-full bg-current" />
      {style.label}
    </span>
  );
}

export function ConnectionBadge({ state, className }: { state: ConnectionState; className?: string }) {
  return (
    <span data-state={state} className={cn(pill, CONNECTION_STATE_STYLE[state], className)}>
      {humanize(state).toUpperCase()}
    </span>
  );
}
