"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { useId, useMemo, useState } from "react";
import { ConfigurationsTable } from "@/components/strategies/configurations-table";
import { DeploymentDialog, type ConfigurationTarget } from "@/components/strategies/deployment-dialog";
import { MONITORING_POLL_MS } from "@/components/strategies/monitoring";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/feedback";
import { NativeSelect } from "@/components/ui/input";
import { deployments as deploymentsApi, strategies as strategiesApi } from "@/lib/api/endpoints";
import { queryKeys } from "@/lib/api/hooks";
import type { MarketRegion, StrategyView, UniverseEntry } from "@/lib/api/types.gen";
import { strategyRequirements, supportsMarket } from "@/lib/strategies";

/** A workspace's saved strategy configurations: their live monitoring, settings and instruments. */
export function DeploymentsPanel({
  slug,
  entries,
  marketRegion,
}: {
  slug: string;
  entries: readonly UniverseEntry[];
  marketRegion: MarketRegion;
}) {
  const pickerId = useId();
  const [target, setTarget] = useState<ConfigurationTarget | null>(null);
  const [choice, setChoice] = useState("");
  const filters = { workspace: slug };
  const deployments = useQuery({
    queryKey: queryKeys.deployments(filters),
    queryFn: () => deploymentsApi.list(filters),
    refetchInterval: MONITORING_POLL_MS,
  });
  const strategies = useQuery({
    queryKey: queryKeys.strategies,
    queryFn: () => strategiesApi.list(),
    staleTime: 60_000,
  });

  const byId = useMemo(
    () => new Map<string, StrategyView>((strategies.data ?? []).map((strategy) => [strategy.strategy_id, strategy])),
    [strategies.data],
  );
  const symbols = useMemo(
    () => new Map(entries.map((entry) => [entry.instrument.id, entry.instrument.symbol] as const)),
    [entries],
  );
  const eligible = (strategies.data ?? []).filter(
    (strategy) => strategy.is_available && supportsMarket(strategyRequirements(strategy.metadata), marketRegion),
  );
  const close = () => {
    setTarget(null);
    setChoice("");
  };

  return (
    <Card>
      <CardHeader
        title="Strategies"
        description="Saved configurations of your strategies. Live signals run on the server until you stop them; nothing here places orders."
        actions={
          <span className="flex items-center gap-2">
            <label htmlFor={pickerId} className="sr-only">
              Strategy to configure
            </label>
            <NativeSelect
              id={pickerId}
              className="h-8 w-48 text-xs"
              value={choice}
              onChange={(event) => setChoice(event.target.value)}
              disabled={eligible.length === 0}
            >
              <option value="">
                {strategies.isPending
                  ? "Loading strategies…"
                  : eligible.length === 0
                    ? `No strategy supports ${marketRegion}`
                    : "Choose a strategy…"}
              </option>
              {eligible.map((strategy) => (
                <option key={strategy.strategy_id} value={strategy.strategy_id}>
                  {`${strategy.name} v${strategy.version}`}
                </option>
              ))}
            </NativeSelect>
            <Button
              size="sm"
              disabled={!byId.has(choice)}
              onClick={() => {
                const strategy = byId.get(choice);
                if (strategy) setTarget({ strategy, deployment: null });
              }}
            >
              New configuration…
            </Button>
          </span>
        }
      />
      <CardContent className="flex flex-col gap-2">
        {deployments.isPending ? (
          <LoadingState />
        ) : deployments.isError ? (
          <ErrorState error={deployments.error} onRetry={() => void deployments.refetch()} />
        ) : deployments.data.length === 0 ? (
          <EmptyState title="No saved configurations">
            Choose a strategy above, or use the Strategy panel beside the chart. Saving a configuration starts nothing:
            enabling live signals is a separate step.
          </EmptyState>
        ) : (
          <ConfigurationsTable
            deployments={deployments.data}
            strategies={byId}
            context={{ symbolOf: (id) => symbols.get(id) }}
            onEdit={(strategy, deployment) => setTarget({ strategy, deployment })}
          />
        )}
        <Link className="text-xs underline" href="/strategies">
          Strategy catalogue and run history
        </Link>
      </CardContent>
      {target ? (
        <DeploymentDialog
          key={`${target.strategy.strategy_id}:${target.deployment?.id ?? "new"}`}
          slug={slug}
          strategy={target.strategy}
          deployment={target.deployment}
          entries={entries}
          onClose={close}
        />
      ) : null}
    </Card>
  );
}
