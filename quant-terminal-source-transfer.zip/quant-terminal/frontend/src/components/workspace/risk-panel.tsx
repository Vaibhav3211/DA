"use client";

import { useId, useState } from "react";
import { RiskRulesTable, useRiskRules, workspacePause } from "@/components/risk/risk-rules";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ErrorState, LoadingState, Spinner } from "@/components/ui/feedback";
import { Field, Input } from "@/components/ui/input";
import { risk as riskApi } from "@/lib/api/endpoints";
import { useApiMutation } from "@/lib/api/hooks";

const REASON_MAX = 200;

function PauseControl({ slug }: { slug: string }) {
  const rules = useRiskRules(slug);
  const reasonId = useId();
  const [reason, setReason] = useState("");
  const pause = useApiMutation({
    mutationFn: (text: string) => riskApi.pause(slug, text.trim() || undefined),
    invalidate: [["risk"]],
    success: "Signals paused",
    errorTitle: "Could not pause the workspace",
    onSuccess: () => setReason(""),
  });
  const resume = useApiMutation({
    mutationFn: () => riskApi.resume(slug),
    invalidate: [["risk"]],
    success: "Signals resumed",
    errorTitle: "Could not resume the workspace",
  });

  if (rules.isPending) return <LoadingState />;
  if (rules.isError) return <ErrorState error={rules.error} onRetry={() => void rules.refetch()} />;
  const state = workspacePause(rules.data);
  if (state.paused) {
    return (
      <div className="flex flex-wrap items-center gap-3">
        <Badge variant="warning">Paused</Badge>
        <span className="text-sm">{state.reason ?? "No reason given"}</span>
        <Button className="ml-auto" disabled={resume.isPending} onClick={() => resume.mutate()}>
          {resume.isPending ? <Spinner /> : null}
          Resume signals
        </Button>
      </div>
    );
  }
  return (
    <form
      className="flex flex-wrap items-end gap-3"
      onSubmit={(event) => {
        event.preventDefault();
        pause.mutate(reason);
      }}
    >
      <Field label="Reason" htmlFor={reasonId} hint="Optional; shown on every blocked signal." className="min-w-64 flex-1">
        <Input
          id={reasonId}
          value={reason}
          maxLength={REASON_MAX}
          placeholder="e.g. results day"
          onChange={(event) => setReason(event.target.value)}
        />
      </Field>
      <Button type="submit" variant="destructive" disabled={pause.isPending}>
        {pause.isPending ? <Spinner /> : null}
        Pause signals
      </Button>
    </form>
  );
}

export function RiskPanel({ slug }: { slug: string }) {
  return (
    <div className="flex flex-col gap-4">
      <Card>
        <CardHeader
          title="Signal pause"
          description="Pausing blocks new signals for this workspace; they are kept for audit as blocked. Market data and strategies keep running."
        />
        <CardContent>
          <PauseControl slug={slug} />
        </CardContent>
      </Card>
      <Card>
        <CardHeader
          title="Risk rules"
          description="Effective rules for this workspace: its own settings, then the global ones, then the code defaults."
        />
        <CardContent>
          <RiskRulesTable workspace={slug} />
        </CardContent>
      </Card>
    </div>
  );
}
