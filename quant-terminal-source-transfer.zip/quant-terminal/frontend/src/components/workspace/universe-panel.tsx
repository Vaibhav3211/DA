"use client";

import { useState } from "react";
import { InstrumentPicker, SUBSCRIPTION_MODES } from "@/components/market/instrument-search";
import { EntryStatusBadge } from "@/components/market/quote-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { EmptyState, Spinner } from "@/components/ui/feedback";
import { Field, NativeSelect } from "@/components/ui/input";
import { JsonBlock } from "@/components/ui/stat";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { workspaces as workspacesApi, type InstrumentSearch } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type {
  InstrumentHit,
  Provider,
  SubscriptionMode,
  UniverseAdd,
  UniverseChange,
  UniverseEntry,
  UniverseRules,
  WorkspaceView,
} from "@/lib/api/types.gen";
import { formatDateTime, humanize } from "@/lib/format";
import { useLiveSockets } from "@/lib/live/provider";
import { instrumentSubtitle, universeProblem } from "@/lib/universe";

// What streams changes with the universe: refresh it, its quotes and the deployments scoped to it.
const UNIVERSE_QUERIES = [queryKeys.workspaces, ["quotes"], ["deployments"]];

function describeChange(change: UniverseChange): string {
  const symbols = (items: readonly { symbol: string }[]) => items.map((item) => item.symbol).join(", ");
  const name = change.workspace.name;
  if (change.added.length > 0) return `Added ${symbols(change.added)} to ${name}`;
  if (change.changed.length > 0) {
    return `${symbols(change.changed.map((previous) => previous.instrument))} now streams differently in ${name}`;
  }
  if (change.removed.length > 0) return `Removed ${symbols(change.removed)} from ${name}`;
  return `Nothing changed in ${name}`;
}

/** Search filters for what the workspace accepts; a rule with several values is left to the hints. */
function searchFilters(rules: UniverseRules): Omit<InstrumentSearch, "q" | "limit"> {
  return {
    exchange: rules.exchanges.length === 1 ? rules.exchanges[0] : undefined,
    segment: rules.segments.length === 1 ? rules.segments[0] : undefined,
    instrument_type: rules.instrument_types.length === 1 ? rules.instrument_types[0] : undefined,
  };
}

function RulesSummary({ rules }: { rules: UniverseRules }) {
  const rows: [string, string][] = [
    ["Exchanges", rules.exchanges.join(", ") || "none"],
    ["Segments", rules.segments.join(", ") || "any"],
    ["Instrument types", rules.instrument_types.map(humanize).join(", ") || "any"],
  ];
  if (rules.underlying_kind !== null) rows.push(["Underlyings", `${humanize(rules.underlying_kind)} only`]);
  return (
    <dl className="grid gap-x-4 gap-y-1 text-xs sm:grid-cols-[auto_1fr]">
      {rows.map(([label, value]) => (
        <div key={label} className="contents">
          <dt className="text-muted-foreground">{label}</dt>
          <dd>{value}</dd>
        </div>
      ))}
    </dl>
  );
}

function AddInstrument({ workspace, entries }: { workspace: WorkspaceView; entries: readonly UniverseEntry[] }) {
  const sockets = useLiveSockets();
  const [hit, setHit] = useState<InstrumentHit | null>(null);
  const [provider, setProvider] = useState<Provider | "">("");
  const [mode, setMode] = useState<SubscriptionMode>("QUOTE");
  const add = useApiMutation({
    mutationFn: (body: UniverseAdd) => workspacesApi.addInstruments(workspace.slug, body),
    invalidate: UNIVERSE_QUERIES,
    success: describeChange,
    errorTitle: "Could not add the instrument",
    onSuccess: () => {
      // The open quote subscription covers the universe as it was when it was made.
      sockets.market.resubscribe("quotes");
      setHit(null);
    },
  });

  if (hit === null) {
    return (
      <InstrumentPicker
        filters={searchFilters(workspace.accepts)}
        placeholder={`Add to ${workspace.name}: symbol, name or ISIN`}
        onPick={(picked) => {
          setHit(picked);
          setProvider(picked.providers[0] ?? "");
        }}
      />
    );
  }
  const problem = universeProblem(workspace.accepts, hit.instrument);
  const existing = entries.find((entry) => entry.instrument.id === hit.instrument.id);
  return (
    <form
      className="flex flex-col gap-3 rounded-md border p-3"
      onSubmit={(event) => {
        event.preventDefault();
        if (provider) add.mutate({ instruments: [hit.instrument.id], provider, mode });
      }}
    >
      <div>
        <p className="font-mono text-sm font-medium">{hit.instrument.symbol}</p>
        <p className="text-xs text-muted-foreground">
          {instrumentSubtitle(hit.instrument) || hit.instrument.exchange}
        </p>
      </div>
      {problem ? <p className="text-xs text-amber-200">{`This workspace ${problem}.`}</p> : null}
      {existing ? (
        <p className="text-xs text-muted-foreground">
          {`Already streams from ${existing.provider} in ${humanize(existing.mode)} mode; adding it again switches it.`}
        </p>
      ) : null}
      {hit.providers.length === 0 ? (
        <p className="text-xs text-muted-foreground">No connected provider lists this instrument.</p>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Provider" htmlFor="universe-add-provider">
            <NativeSelect
              id="universe-add-provider"
              value={provider}
              onChange={(event) => setProvider(event.target.value as Provider)}
            >
              {hit.providers.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </NativeSelect>
          </Field>
          <Field label="Data" htmlFor="universe-add-mode">
            <NativeSelect
              id="universe-add-mode"
              value={mode}
              onChange={(event) => setMode(event.target.value as SubscriptionMode)}
            >
              {SUBSCRIPTION_MODES.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </NativeSelect>
          </Field>
        </div>
      )}
      <div className="flex gap-2">
        <Button type="submit" size="sm" disabled={!provider || add.isPending}>
          {add.isPending ? <Spinner /> : null}
          {existing ? "Switch" : "Add"}
        </Button>
        <Button type="button" size="sm" variant="ghost" onClick={() => setHit(null)}>
          Choose another
        </Button>
      </div>
    </form>
  );
}

function UniverseTable({ workspace, entries }: { workspace: WorkspaceView; entries: readonly UniverseEntry[] }) {
  const sockets = useLiveSockets();
  const [removing, setRemoving] = useState<UniverseEntry | null>(null);
  const changeMode = useApiMutation({
    mutationFn: ({ entry, mode }: { entry: UniverseEntry; mode: SubscriptionMode }) =>
      workspacesApi.addInstruments(workspace.slug, {
        instruments: [entry.instrument.id],
        provider: entry.provider,
        account_id: entry.account?.id ?? null,
        mode,
      }),
    invalidate: UNIVERSE_QUERIES,
    success: (_change, { entry, mode }) => `${entry.instrument.symbol} now streams in ${humanize(mode)} mode`,
    errorTitle: "Could not change the data mode",
    onSuccess: () => sockets.market.resubscribe("quotes"),
  });
  const remove = useApiMutation({
    mutationFn: (entry: UniverseEntry) => workspacesApi.removeInstruments(workspace.slug, [entry.instrument.id]),
    invalidate: UNIVERSE_QUERIES,
    success: describeChange,
    errorTitle: "Could not remove the instrument",
    onSuccess: () => {
      sockets.market.resubscribe("quotes");
      setRemoving(null);
    },
  });

  if (entries.length === 0) {
    return <EmptyState title="The universe is empty">Search above to add the instruments this workspace streams.</EmptyState>;
  }
  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Instrument</TableHead>
            <TableHead>Source</TableHead>
            <TableHead>Data</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Added</TableHead>
            <TableHead className="text-right">
              <span className="sr-only">Actions</span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {entries.map((entry) => {
            const { instrument } = entry;
            const busy = changeMode.isPending && changeMode.variables?.entry.instrument.id === instrument.id;
            return (
              <TableRow key={instrument.id}>
                <TableCell>
                  <span className="font-mono font-medium">{instrument.symbol}</span>
                  <span className="block text-xs text-muted-foreground">
                    {instrumentSubtitle(instrument) || instrument.exchange}
                  </span>
                </TableCell>
                <TableCell className="text-xs">
                  <Badge variant="outline">{entry.provider}</Badge>
                  <span className="ml-1 text-muted-foreground">{entry.account?.label ?? "enabled account"}</span>
                </TableCell>
                <TableCell>
                  <NativeSelect
                    aria-label={`Data mode for ${instrument.symbol}`}
                    className="h-8 w-28 text-xs"
                    value={entry.mode}
                    disabled={busy}
                    onChange={(event) =>
                      changeMode.mutate({ entry, mode: event.target.value as SubscriptionMode })
                    }
                  >
                    {SUBSCRIPTION_MODES.map((item) => (
                      <option key={item.value} value={item.value}>
                        {humanize(item.value)}
                      </option>
                    ))}
                  </NativeSelect>
                </TableCell>
                <TableCell>
                  <EntryStatusBadge entry={entry} />
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">
                  {formatDateTime(entry.added_at)}
                  {entry.added_by ? ` by ${entry.added_by}` : ""}
                </TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="ghost" onClick={() => setRemoving(entry)}>
                    Remove
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      <Dialog
        open={removing !== null}
        onOpenChange={(open) => {
          if (!open) setRemoving(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{`Remove ${removing?.instrument.symbol ?? ""}?`}</DialogTitle>
            <DialogDescription>
              {`It stops streaming for ${workspace.name}. You can add it again at any time.`}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRemoving(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={remove.isPending}
              onClick={() => {
                if (removing) remove.mutate(removing);
              }}
            >
              {remove.isPending ? <Spinner /> : null}
              Remove
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

/** The instruments a workspace streams, and the rules for what it takes. */
export function UniversePanel({ workspace, entries }: { workspace: WorkspaceView; entries: readonly UniverseEntry[] }) {
  return (
    <Card>
      <CardHeader
        title="Universe"
        description={`${entries.length} instruments. Full mode adds market depth; LTP is the lightest.`}
      />
      <CardContent className="flex flex-col gap-4">
        <div className="grid gap-4 lg:grid-cols-2">
          <section aria-labelledby="universe-rules" className="flex flex-col gap-2">
            <h3 id="universe-rules" className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
              Accepts
            </h3>
            <RulesSummary rules={workspace.accepts} />
            <JsonBlock value={workspace.settings} />
          </section>
          <section aria-labelledby="universe-add" className="flex flex-col gap-2">
            <h3 id="universe-add" className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
              Add an instrument
            </h3>
            <AddInstrument workspace={workspace} entries={entries} />
          </section>
        </div>
        <UniverseTable workspace={workspace} entries={entries} />
      </CardContent>
    </Card>
  );
}
