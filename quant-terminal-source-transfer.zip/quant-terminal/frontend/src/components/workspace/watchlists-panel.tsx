"use client";

import { useQuery } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, X } from "lucide-react";
import { useId, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { EmptyState, ErrorState, LoadingState, Spinner } from "@/components/ui/feedback";
import { Input, NativeSelect } from "@/components/ui/input";
import { watchlists as watchlistsApi, workspaces as workspacesApi } from "@/lib/api/endpoints";
import { queryKeys, useApiMutation } from "@/lib/api/hooks";
import type { UniverseEntry, WatchlistView } from "@/lib/api/types.gen";
import { cn } from "@/lib/utils";

export function useWatchlists(slug: string) {
  return useQuery({ queryKey: queryKeys.watchlists(slug), queryFn: () => workspacesApi.watchlists(slug) });
}

function moved<T>(items: readonly T[], from: number, to: number): T[] {
  const next = [...items];
  const [item] = next.splice(from, 1);
  next.splice(to, 0, item);
  return next;
}

function CreateWatchlist({ slug, onCreated }: { slug: string; onCreated: (id: string) => void }) {
  const inputId = useId();
  const [name, setName] = useState("");
  const create = useApiMutation({
    mutationFn: (value: string) => workspacesApi.createWatchlist(slug, value),
    invalidate: [queryKeys.watchlists(slug)],
    success: (view) => `Created ${view.name}`,
    errorTitle: "Could not create the watchlist",
    onSuccess: (view) => {
      setName("");
      onCreated(view.id);
    },
  });
  return (
    <form
      className="flex gap-2"
      onSubmit={(event) => {
        event.preventDefault();
        if (name.trim()) create.mutate(name.trim());
      }}
    >
      <label htmlFor={inputId} className="sr-only">
        New watchlist name
      </label>
      <Input
        id={inputId}
        className="h-8 text-xs"
        placeholder="New watchlist"
        maxLength={100}
        value={name}
        onChange={(event) => setName(event.target.value)}
      />
      <Button type="submit" size="sm" variant="outline" disabled={!name.trim() || create.isPending}>
        Create
      </Button>
    </form>
  );
}

function WatchlistEditor({
  slug,
  watchlist,
  entries,
  onDeleted,
}: {
  slug: string;
  watchlist: WatchlistView;
  entries: readonly UniverseEntry[];
  onDeleted: () => void;
}) {
  const nameId = useId();
  const addId = useId();
  const [name, setName] = useState(watchlist.name);
  const [adding, setAdding] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const invalidate = [queryKeys.watchlists(slug)];
  const ids = watchlist.items.map((item) => item.instrument.id);
  const candidates = entries.filter((entry) => !ids.includes(entry.instrument.id));

  const rename = useApiMutation({
    mutationFn: (value: string) => watchlistsApi.update(watchlist.id, { name: value }),
    invalidate,
    success: (view) => `Renamed to ${view.name}`,
    errorTitle: "Could not rename the watchlist",
  });
  const setItems = useApiMutation({
    mutationFn: (instrumentIds: string[]) => watchlistsApi.setItems(watchlist.id, instrumentIds),
    invalidate,
    success: null,
    errorTitle: "Could not change the watchlist",
  });
  const remove = useApiMutation({
    mutationFn: () => watchlistsApi.remove(watchlist.id),
    invalidate,
    success: `Deleted ${watchlist.name}`,
    errorTitle: "Could not delete the watchlist",
    onSuccess: onDeleted,
  });

  return (
    <div className="flex flex-col gap-3">
      <form
        className="flex flex-wrap items-end gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          if (name.trim() && name.trim() !== watchlist.name) rename.mutate(name.trim());
        }}
      >
        <div className="flex min-w-48 flex-1 flex-col gap-1.5">
          <label htmlFor={nameId} className="text-xs font-medium text-muted-foreground">
            Name
          </label>
          <Input id={nameId} className="h-8" maxLength={100} value={name} onChange={(event) => setName(event.target.value)} />
        </div>
        <Button
          type="submit"
          size="sm"
          variant="outline"
          disabled={!name.trim() || name.trim() === watchlist.name || rename.isPending}
        >
          Rename
        </Button>
        <Button type="button" size="sm" variant="ghost" className="text-red-300" onClick={() => setConfirmDelete(true)}>
          Delete
        </Button>
      </form>

      {watchlist.items.length === 0 ? (
        <EmptyState title="This watchlist is empty">Add instruments from the workspace universe below.</EmptyState>
      ) : (
        <ol aria-label={`Instruments in ${watchlist.name}`} className={cn("flex flex-col", setItems.isPending && "opacity-60")}>
          {watchlist.items.map((item, index) => {
            const { symbol } = item.instrument;
            return (
              <li key={item.instrument.id} className="flex items-center gap-2 border-b py-1 last:border-b-0">
                <span className="w-6 text-right text-xs text-muted-foreground tabular-nums">{index + 1}</span>
                <span className="min-w-0 flex-1 truncate">
                  <span className="font-mono text-sm font-medium">{symbol}</span>
                  <span className="ml-1 text-xs text-muted-foreground">{item.instrument.exchange}</span>
                </span>
                {item.in_universe ? null : (
                  <Badge variant="warning" title="It is not in this workspace's universe, so it has no live data here">
                    Not streaming
                  </Badge>
                )}
                <Button
                  size="icon-sm"
                  variant="ghost"
                  aria-label={`Move ${symbol} up`}
                  disabled={index === 0 || setItems.isPending}
                  onClick={() => setItems.mutate(moved(ids, index, index - 1))}
                >
                  <ArrowUp />
                </Button>
                <Button
                  size="icon-sm"
                  variant="ghost"
                  aria-label={`Move ${symbol} down`}
                  disabled={index === ids.length - 1 || setItems.isPending}
                  onClick={() => setItems.mutate(moved(ids, index, index + 1))}
                >
                  <ArrowDown />
                </Button>
                <Button
                  size="icon-sm"
                  variant="ghost"
                  aria-label={`Remove ${symbol} from the watchlist`}
                  disabled={setItems.isPending}
                  onClick={() => setItems.mutate(ids.filter((id) => id !== item.instrument.id))}
                >
                  <X />
                </Button>
              </li>
            );
          })}
        </ol>
      )}

      <form
        className="flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          if (adding) setItems.mutate([...ids, adding], { onSuccess: () => setAdding("") });
        }}
      >
        <label htmlFor={addId} className="sr-only">
          Instrument to add
        </label>
        <NativeSelect
          id={addId}
          className="h-8 text-xs"
          value={adding}
          disabled={candidates.length === 0}
          onChange={(event) => setAdding(event.target.value)}
        >
          <option value="">
            {entries.length === 0
              ? "The universe is empty"
              : candidates.length === 0
                ? "Every universe instrument is listed"
                : "Add from the universe…"}
          </option>
          {candidates.map((entry) => (
            <option key={entry.instrument.id} value={entry.instrument.id}>
              {`${entry.instrument.symbol} · ${entry.instrument.exchange}`}
            </option>
          ))}
        </NativeSelect>
        <Button type="submit" size="sm" variant="outline" disabled={!adding || setItems.isPending}>
          Add
        </Button>
      </form>

      <Dialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{`Delete ${watchlist.name}?`}</DialogTitle>
            <DialogDescription>The list goes; the instruments stay in the workspace universe.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmDelete(false)}>
              Cancel
            </Button>
            <Button variant="destructive" disabled={remove.isPending} onClick={() => remove.mutate()}>
              {remove.isPending ? <Spinner /> : null}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** Named, ordered lists of a workspace's instruments; the quote table can show one at a time. */
export function WatchlistsPanel({ slug, entries }: { slug: string; entries: readonly UniverseEntry[] }) {
  const lists = useWatchlists(slug);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const items = lists.data ?? [];
  const selected: WatchlistView | undefined = items.find((watchlist) => watchlist.id === selectedId) ?? items[0];

  return (
    <Card>
      <CardHeader title="Watchlists" description="Order instruments your way; they do not change what streams." />
      <CardContent>
        {lists.isPending ? (
          <LoadingState />
        ) : lists.isError ? (
          <ErrorState error={lists.error} onRetry={() => void lists.refetch()} />
        ) : (
          <div className="grid gap-4 md:grid-cols-[220px_minmax(0,1fr)]">
            <nav aria-label="Watchlists" className="flex flex-col gap-2">
              <ul className="flex flex-col gap-0.5">
                {items.map((watchlist) => (
                  <li key={watchlist.id}>
                    <button
                      type="button"
                      aria-current={watchlist.id === selected?.id ? "true" : undefined}
                      onClick={() => setSelectedId(watchlist.id)}
                      className={cn(
                        "flex w-full items-center justify-between gap-2 rounded-md px-2 py-1.5 text-left text-sm hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring/60 focus-visible:outline-none",
                        watchlist.id === selected?.id && "bg-accent",
                      )}
                    >
                      <span className="truncate">{watchlist.name}</span>
                      <span className="text-xs text-muted-foreground tabular-nums">{watchlist.items.length}</span>
                    </button>
                  </li>
                ))}
              </ul>
              <CreateWatchlist slug={slug} onCreated={setSelectedId} />
            </nav>
            {selected ? (
              <WatchlistEditor
                key={selected.id}
                slug={slug}
                watchlist={selected}
                entries={entries}
                onDeleted={() => setSelectedId(null)}
              />
            ) : (
              <EmptyState title="No watchlists yet">Create one to keep a short list of instruments.</EmptyState>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
