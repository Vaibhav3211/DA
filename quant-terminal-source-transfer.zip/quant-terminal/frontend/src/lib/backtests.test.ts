import { describe, expect, it } from "vitest";
import type { BacktestRunView, BacktestTrade, DatasetCoverage, SignalRef, TradeRules } from "@/lib/api/types.gen";
import {
  CHART_TRADE_LIMIT,
  backtestMarkers,
  changedLabel,
  chartBacktest,
  checkTradeRules,
  compareDecimals,
  coverageText,
  dataLabel,
  draftFromRules,
  equitySeries,
  measureText,
  parseBacktestMarkerId,
  ruleRows,
  settingsRows,
  type TradeRulesDraft,
} from "@/lib/backtests";
import { CHART_COLORS } from "@/lib/chart";

function rules(overrides: Partial<TradeRules> = {}): TradeRules {
  return {
    sides: "LONG_ONLY",
    opposite_signal: "CLOSE",
    fill: "NEXT_OPEN",
    exit_check: "INTRABAR",
    stop_target: "PERCENT",
    stop_pct: "1.5",
    target_pct: "3",
    max_holding_candles: null,
    sizing: "RISK_PERCENT",
    quantity: null,
    amount: null,
    risk_pct: "1",
    initial_capital: "100000",
    fee_pct_per_side: "0.03",
    fee_per_order: "20",
    slippage_ticks: 1,
    ...overrides,
  };
}

const SIGNAL: SignalRef = {
  signal_type: "BUY",
  decided_at: "2026-10-01T04:00:00Z",
  candle_start: "2026-10-01T03:55:00Z",
  entry_price: null,
  stop_loss: null,
  targets: [],
  reasons: [],
  indicators: {},
};

function trade(overrides: Partial<BacktestTrade>): BacktestTrade {
  return {
    number: 1,
    side: "LONG",
    quantity: 10,
    entry_at: "2026-10-01T04:00:00Z",
    entry_reference: "100",
    entry_price: "100.05",
    exit_at: "2026-10-01T04:10:00Z",
    exit_reference: "103",
    exit_price: "102.95",
    exit_reason: "TARGET",
    stop_loss: "98.5",
    target: "103",
    both_touched: false,
    gap_exit: false,
    candles_held: 2,
    gross_pnl: "30.00",
    fees: "40.62",
    slippage: "1.00",
    net_pnl: "-11.62",
    return_pct: "-1.16",
    outcome: "LOSS",
    entry_signal: SIGNAL,
    exit_signal: null,
    ...overrides,
  };
}

describe("checkTradeRules", () => {
  it("assumes nothing: an empty draft needs every choice and the required amounts", () => {
    const check = checkTradeRules(draftFromRules(null));
    expect(check.body).toBeNull();
    for (const field of ["sides", "opposite_signal", "fill", "exit_check", "stop_target", "sizing"] as const) {
      expect(check.errors[field]).toBe("Choose one.");
    }
    expect(check.errors.initial_capital).toBe("Required.");
    expect(check.errors.slippage_ticks).toBe("Required.");
    expect(check.errors.max_holding_candles).toBeUndefined();
  });

  it("sends decimals as typed and leaves out the rules the chosen methods do not use", () => {
    const draft = { ...draftFromRules(rules()), quantity: "50", amount: "25000" };
    const check = checkTradeRules(draft);
    expect(check.errors).toEqual({});
    expect(check.body).toEqual({
      sides: "LONG_ONLY",
      opposite_signal: "CLOSE",
      fill: "NEXT_OPEN",
      exit_check: "INTRABAR",
      stop_target: "PERCENT",
      stop_pct: "1.5",
      target_pct: "3",
      max_holding_candles: null,
      sizing: "RISK_PERCENT",
      quantity: null,
      amount: null,
      risk_pct: "1",
      initial_capital: "100000",
      fee_pct_per_side: "0.03",
      fee_per_order: "20",
      slippage_ticks: 1,
    });
  });

  it("applies the API's bounds exactly", () => {
    const errors = (overrides: Partial<TradeRulesDraft>) =>
      checkTradeRules({ ...draftFromRules(rules()), ...overrides }).errors;
    expect(errors({ stop_pct: "100" }).stop_pct).toBe("Must be less than 100.");
    expect(errors({ stop_pct: "99.9999999999999999" }).stop_pct).toBeUndefined();
    expect(errors({ stop_pct: "0" }).stop_pct).toBe("Must be more than 0.");
    expect(errors({ target_pct: "1000" }).target_pct).toBeUndefined();
    expect(errors({ target_pct: "1000.01" }).target_pct).toBe("Must be at most 1000.");
    expect(errors({ fee_pct_per_side: "10.5" }).fee_pct_per_side).toBe("Must be at most 10.");
    expect(errors({ fee_per_order: "0" }).fee_per_order).toBeUndefined();
    expect(errors({ slippage_ticks: "1001" }).slippage_ticks).toBe("Must be at most 1000.");
    expect(errors({ slippage_ticks: "1.5" }).slippage_ticks).toBe("Enter a whole number.");
    expect(errors({ initial_capital: "1e5" }).initial_capital).toBe("Enter a plain number, such as 1.5.");
    expect(errors({ initial_capital: "-5" }).initial_capital).toBe("Enter a plain number, such as 1.5.");
    expect(errors({ max_holding_candles: "0" }).max_holding_candles).toBe("Must be at least 1.");
  });

  it("checks the rules against each other as the API does", () => {
    const problems = (overrides: Partial<TradeRules>) => checkTradeRules(draftFromRules(rules(overrides))).problems;
    expect(problems({ stop_pct: null, target_pct: null })).toEqual([
      "Fixed percentages need a stop-loss %, a target % or both.",
      "Sizing by equity at risk needs a stop-loss: the signal's levels, or a stop-loss %.",
    ]);
    expect(problems({ stop_target: "NONE", stop_pct: null, target_pct: null })).toEqual([
      "Sizing by equity at risk needs a stop-loss: the signal's levels, or a stop-loss %.",
    ]);
    expect(problems({ stop_target: "SIGNAL", stop_pct: null, target_pct: null })).toEqual([]);
    expect(problems({ stop_pct: null })).toHaveLength(1);
  });
});

describe("compareDecimals", () => {
  it("compares exactly, ignoring leading and trailing zeros", () => {
    expect(compareDecimals("99.9999999999999999", "100")).toBeLessThan(0);
    expect(compareDecimals("007.50", "7.5")).toBe(0);
    expect(compareDecimals("10", "9.99")).toBeGreaterThan(0);
  });
});

describe("ruleRows", () => {
  it("lists only the rules the chosen methods use", () => {
    const rows = ruleRows(rules({ stop_target: "SIGNAL", stop_pct: null, target_pct: null }));
    const labels = rows.map((row) => row.label);
    expect(labels).not.toContain("Stop-loss %");
    expect(labels).not.toContain("Quantity");
    expect(rows.find((row) => row.label === "Holding limit (candles)")?.value).toBe("No limit");
    expect(rows.find((row) => row.label === "Fills")?.value).toBe("Next open");
  });
});

describe("display helpers", () => {
  it("shows an undefined metric with its reason instead of a number", () => {
    expect(measureText({ value: null, reason: "No closed trades" }, "%")).toEqual({
      text: "Undefined",
      reason: "No closed trades",
    });
    expect(measureText({ value: "55.56", reason: null }, "%")).toEqual({ text: "55.56%", reason: null });
  });

  it("always labels simulator candles SIMULATED", () => {
    expect(dataLabel({ provider: "SIMULATOR", source: "SIMULATED", simulated: true })).toBe("SIMULATED");
    expect(dataLabel({ provider: "ZERODHA", source: "PROVIDER_HISTORY", simulated: false })).toBe("Zerodha history");
    expect(dataLabel({ provider: "GROWW", source: "RECORDED", simulated: false })).toBe("Groww recorded feed");
  });

  it("names changed settings in words", () => {
    expect(changedLabel("trade_rules.fill")).toBe("Trade rule: Fills");
    expect(changedLabel("configuration.config.fast_period")).toBe("Parameter fast_period");
    expect(changedLabel("strategy.fingerprint")).toBe("Strategy code (fingerprint)");
    expect(changedLabel("risk.max_signals_per_day.params.limit")).toBe("Risk rule max_signals_per_day");
    expect(changedLabel("something.new")).toBe("something.new");
  });

  it("reads a run's recorded settings, including rules that do not apply to history", () => {
    const rows = settingsRows({
      configuration: { config_hash: "abc", config: { fast: 9 } },
      instrument: { lot_size: 1, tick_size: "0.05" },
      signal_validity_seconds: 300,
      engine_version: "1",
      trade_rules_source: "STRATEGY",
      risk: { session: { enabled: false }, price_sanity: { enabled: true, params: { max_jump_pct: "5" } } },
      risk_not_applied: ["kill_switch", "freshness"],
    });
    expect(rows[0]?.value).toBe("fast=9 (configuration hash abc)");
    expect(rows.filter((row) => row.value.startsWith("price_sanity"))[0]?.value).toBe('price_sanity: on (max_jump_pct="5")');
    expect(rows.find((row) => row.value.startsWith("session"))?.value).toBe("session: off");
    expect(rows.at(-1)?.value).toBe("kill_switch, freshness: rules about the live system do not apply to history");
  });

  it("says so when the calendar expects no candles", () => {
    const empty = { expected: 0 } as DatasetCoverage;
    expect(coverageText(empty)).toBe("The calendar expects no candles on these dates");
  });
});

describe("equitySeries", () => {
  it("sorts the points and keeps one per second", () => {
    const series = equitySeries([
      { at: "2026-10-01T04:10:00Z", equity: "100100" },
      { at: "2026-10-01T04:05:00Z", equity: "99950.5" },
      { at: "2026-10-01T04:10:00.400Z", equity: "100200" },
    ]);
    expect(series.map((point) => point.value)).toEqual([99950.5, 100200]);
  });
});

describe("backtestMarkers", () => {
  const minute = (iso: string) => Date.parse(iso) / 1000;
  const bars = [minute("2026-10-01T04:00:00Z"), minute("2026-10-01T04:05:00Z"), minute("2026-10-01T04:10:00Z")];

  it("draws muted BT circles on the bars that contain the fills, ids pointing back at the trade", () => {
    const markers = backtestMarkers("run-1", [trade({})], bars, 300);
    expect(markers).toHaveLength(2);
    expect(markers[0]).toMatchObject({ position: "belowBar", shape: "circle", text: "BT1", time: bars[0] });
    expect(markers[0]?.color).toBe(CHART_COLORS.backtestLong);
    expect(markers[1]).toMatchObject({ position: "aboveBar", color: CHART_COLORS.backtestExit, time: bars[2] });
    expect(parseBacktestMarkerId(markers[1]?.id ?? "")).toEqual({ runId: "run-1", trade: 1, leg: "exit" });
    expect(parseBacktestMarkerId("8d1c6f3e-signal")).toBeNull();
  });

  it("leaves out fills outside the chart's bars", () => {
    const early = trade({ number: 2, side: "SHORT", entry_at: "2026-09-30T09:00:00Z", exit_at: "2026-10-01T04:06:00Z" });
    const late = trade({ number: 3, entry_at: "2026-10-01T04:20:00Z", exit_at: "2026-10-01T04:25:00Z" });
    const markers = backtestMarkers("run-1", [early, late], bars, 300);
    expect(markers).toHaveLength(1);
    expect(markers[0]).toMatchObject({ text: "BT2", position: "belowBar", time: bars[1] });
  });

  it("prefixes the text with the configuration's chart number", () => {
    expect(backtestMarkers("run-1", [trade({ number: 4 })], bars, 300, "2·")[0]?.text).toBe("2·BT4");
  });
});

describe("chartBacktest", () => {
  const chart = { interval: "5m", provider: "ZERODHA" } as const;
  const run = (overrides: Partial<BacktestRunView>) =>
    ({
      id: "run-1",
      interval: "5m",
      provider: "ZERODHA",
      source: "PROVIDER_HISTORY",
      simulated: false,
      trade_count: 250,
      ...overrides,
    }) as BacktestRunView;

  it("draws only the newest trades of a current backtest on its own interval and provider", () => {
    expect(chartBacktest({ state: "CURRENT", current: run({}) }, chart)).toMatchObject({
      drawn: true,
      offset: 250 - CHART_TRADE_LIMIT,
      limit: CHART_TRADE_LIMIT,
    });
    expect(chartBacktest({ state: "CURRENT", current: run({ trade_count: 3 }) }, chart)).toMatchObject({ offset: 0 });
  });

  it("says why it draws nothing", () => {
    const reason = (latest: Parameters<typeof chartBacktest>[0]) => {
      const result = chartBacktest(latest, chart);
      return result.drawn ? null : result.reason;
    };
    expect(reason({ state: "OUTDATED", current: null })).toMatch(/^its backtests are outdated/);
    expect(reason({ state: "NOT_BACKTESTED", current: null })).toBe("not backtested");
    expect(reason({ state: "CURRENT", current: run({ interval: "15m" }) })).toMatch(/switch the chart to 15m/);
    const simulated = run({ provider: "SIMULATOR", source: "SIMULATED", simulated: true });
    expect(reason({ state: "CURRENT", current: simulated })).toBe(
      "its backtest replayed SIMULATED candles, not this chart's Zerodha feed",
    );
    expect(reason({ state: "CURRENT", current: run({ trade_count: 0 }) })).toBe("its backtest closed no trades");
  });
});
