import { describe, expect, it } from "vitest";
import {
  barTimeAtOrBefore,
  CHART_COLORS,
  ema,
  mergeCandles,
  newer,
  placeSignals,
  priceFormatFor,
  signalMarkers,
  signalMarkerTime,
  toBar,
  toSeconds,
  volumeData,
} from "@/lib/chart";
import { candle, signal } from "@/test/fixtures";

const minute = (value: number) => `2025-01-01T03:${String(value).padStart(2, "0")}:00Z`;

describe("priceFormatFor", () => {
  it("takes the precision from the tick size, with at least two places", () => {
    expect(priceFormatFor("0.05")).toEqual({ precision: 2, minMove: 0.01 });
    expect(priceFormatFor("0.0025")).toEqual({ precision: 4, minMove: 0.0001 });
    expect(priceFormatFor("0.050")).toEqual({ precision: 2, minMove: 0.01 });
    expect(priceFormatFor("1")).toEqual({ precision: 2, minMove: 0.01 });
  });

  it("caps the precision and tolerates a missing or odd tick size", () => {
    expect(priceFormatFor("0.0000000001")).toEqual({ precision: 8, minMove: 0.00000001 });
    expect(priceFormatFor(null)).toEqual({ precision: 2, minMove: 0.01 });
    expect(priceFormatFor("abc")).toEqual({ precision: 2, minMove: 0.01 });
  });
});

describe("candle merging", () => {
  it("never lets a late forming update reopen a closed candle", () => {
    const closed = candle({ is_closed: true, revision: 3 });
    const forming = candle({ is_closed: false, revision: 4 });
    expect(newer(closed, forming)).toBe(closed);
    expect(newer(forming, closed)).toBe(closed);
  });

  it("keeps the higher revision, and the incoming candle on a tie", () => {
    const current = candle({ revision: 2 });
    const tie = candle({ revision: 2 });
    expect(newer(current, candle({ revision: 1 }))).toBe(current);
    expect(newer(current, tie)).toBe(tie);
  });

  it("keeps one candle per bucket, oldest first, and skips unreadable buckets", () => {
    const history = [
      candle({ bucket_start: minute(45), is_closed: true }),
      candle({ bucket_start: minute(46), revision: 1 }),
    ];
    const live = [
      candle({ bucket_start: minute(46), revision: 2 }),
      candle({ bucket_start: minute(44), is_closed: true }),
      candle({ bucket_start: "garbage" }),
    ];
    expect(mergeCandles(history, live).map((item) => [item.bucket_start, item.revision])).toEqual([
      [minute(44), 1],
      [minute(45), 1],
      [minute(46), 2],
    ]);
  });
});

describe("chart series", () => {
  it("converts candles to bars and volume columns coloured by direction", () => {
    const up = toBar(candle({ bucket_start: minute(45), open_price: "100.5", close_price: "101", volume: 10 }));
    expect(up).toMatchObject({ time: 1735703100, open: 100.5, close: 101, volume: 10, closed: false });
    const down = toBar(candle({ bucket_start: minute(46), open_price: "101", close_price: "99", volume: 5 }));
    const noVolume = toBar(candle({ bucket_start: minute(47), volume: null }));
    expect(volumeData([up, down, noVolume])).toEqual([
      { time: up.time, value: 10, color: CHART_COLORS.upVolume },
      { time: down.time, value: 5, color: CHART_COLORS.downVolume },
    ]);
  });

  it("seeds the EMA with the simple average of the first period", () => {
    expect(ema([1, 2, 3, 4, 5], 3)).toEqual([null, null, 2, 3, 4]);
    expect(ema([1, 2], 0)).toEqual([null, null]);
  });
});

describe("signal markers", () => {
  it("places a candle-close signal on its candle, and a partial-candle one when it happened", () => {
    const fromCandle = { source_candle_start: minute(45), source_candle_interval: "5m" as const };
    expect(signalMarkerTime(signal({ generated_at: minute(50), ...fromCandle }))).toBe(toSeconds(minute(45)) + 299);
    expect(signalMarkerTime(signal({ generated_at: "2025-01-01T03:47:30Z", ...fromCandle }))).toBe(
      toSeconds("2025-01-01T03:47:30Z"),
    );
    expect(signalMarkerTime(signal({ generated_at: minute(50) }))).toBe(toSeconds(minute(50)));
    expect(signalMarkerTime(signal({ generated_at: "garbage" }))).toBeNull();
  });

  it("finds the bar a moment falls on, or the bar before a gap", () => {
    const times = [100, 160, 280];
    expect(barTimeAtOrBefore(times, 99)).toBeNull();
    expect(barTimeAtOrBefore(times, 100)).toBe(100);
    expect(barTimeAtOrBefore(times, 159)).toBe(100);
    expect(barTimeAtOrBefore(times, 250)).toBe(160);
    expect(barTimeAtOrBefore(times, 10_000)).toBe(280);
    expect(barTimeAtOrBefore([], 100)).toBeNull();
  });

  it("draws BUY, SELL and EXIT on loaded bars, numbered by configuration and grey when blocked", () => {
    const bars = [minute(45), minute(46), minute(47)].map(toSeconds);
    const marked = placeSignals(
      [
        {
          number: 1,
          signals: [
            signal({ id: "sell", signal_type: "SELL", generated_at: "2025-01-01T03:47:10Z" }),
            signal({ id: "watch", signal_type: "WATCH", generated_at: minute(46) }),
            signal({ id: "before-the-chart", generated_at: "2025-01-01T03:00:00Z" }),
          ],
        },
        { number: 2, signals: [signal({ id: "buy", status: "BLOCKED", generated_at: "2025-01-01T03:45:30Z" })] },
      ],
      bars,
    );
    expect(marked.map((item) => [item.signal.id, item.time, item.number])).toEqual([
      ["buy", bars[0], 2],
      ["sell", bars[2], 1],
    ]);
    expect(signalMarkers(marked)).toEqual([
      { id: "buy", time: bars[0], position: "belowBar", shape: "arrowUp", color: CHART_COLORS.signalBlocked, text: "2" },
      { id: "sell", time: bars[2], position: "aboveBar", shape: "arrowDown", color: CHART_COLORS.down, text: "1" },
    ]);
  });
});
