// Strategy settings forms, built from the strategy's JSON schema (Pydantic's ``model_json_schema``).
// Anything the form cannot represent falls back to a JSON text field; the API validates either way.

import { humanize } from "@/lib/format";

export type FieldKind = "boolean" | "integer" | "number" | "decimal" | "string" | "enum" | "json";
export type EnumOption = string | number | boolean;
export type FormValues = Record<string, string | boolean>;

type Json = Record<string, unknown>;

export interface SchemaField {
  name: string;
  label: string;
  description: string | null;
  kind: FieldKind;
  required: boolean;
  nullable: boolean;
  options: EnumOption[];
  minimum: number | null;
  maximum: number | null;
  exclusiveMinimum: number | null;
  exclusiveMaximum: number | null;
  defaultValue: unknown;
}

export interface ParsedForm {
  config: Record<string, unknown>;
  errors: Record<string, string>;
}

function isObject(value: unknown): value is Json {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function withoutKey(node: Json, key: string): Json {
  const copy = { ...node };
  delete copy[key];
  return copy;
}

function lookup(root: Json, ref: string): Json {
  if (!ref.startsWith("#/")) return {};
  let node: unknown = root;
  for (const part of ref.slice(2).split("/")) {
    node = isObject(node) ? node[part.replace(/~1/g, "/").replace(/~0/g, "~")] : undefined;
  }
  return isObject(node) ? node : {};
}

/** Inlines ``$ref`` and a single-entry ``allOf``, which is how Pydantic annotates a referenced type. */
function resolve(node: unknown, root: Json): Json {
  let current: Json = isObject(node) ? node : {};
  for (let depth = 0; depth < 16; depth += 1) {
    if (typeof current.$ref === "string") {
      // A definition's title names its type (an enum or model class), not the field that uses it.
      current = { ...withoutKey(lookup(root, current.$ref), "title"), ...withoutKey(current, "$ref") };
    } else if (Array.isArray(current.allOf) && current.allOf.length === 1) {
      current = { ...resolve(current.allOf[0], root), ...withoutKey(current, "allOf") };
    } else {
      break;
    }
  }
  return current;
}

function isNullSchema(node: unknown): boolean {
  return isObject(node) && node.type === "null";
}

/** Splits ``Optional[X]`` (``anyOf: [X, {type: null}]`` or ``type: [X, "null"]``) into X and a flag. */
function splitNullable(node: Json, root: Json): { schema: Json; nullable: boolean } {
  for (const key of ["anyOf", "oneOf"]) {
    const variants = node[key];
    if (!Array.isArray(variants) || !variants.some(isNullSchema)) continue;
    const others = variants.filter((variant) => !isNullSchema(variant));
    const outer = withoutKey(node, key);
    const schema = others.length === 1 ? { ...resolve(others[0], root), ...outer } : { ...outer, [key]: others };
    return { schema, nullable: true };
  }
  if (Array.isArray(node.type) && node.type.includes("null")) {
    const types = node.type.filter((type) => type !== "null");
    return { schema: { ...node, type: types.length === 1 ? types[0] : types }, nullable: true };
  }
  return { schema: node, nullable: false };
}

function numberOrNull(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

/** Pydantic writes a Decimal as ``anyOf: [{type: number, ...bounds}, {type: string}]``. */
function decimalBounds(schema: Json, root: Json): Json | null {
  const variants = Array.isArray(schema.anyOf) ? schema.anyOf.map((variant) => resolve(variant, root)) : null;
  if (!variants || variants.length !== 2) return null;
  const numeric = variants.find((variant) => variant.type === "number");
  const text = variants.find((variant) => variant.type === "string");
  return numeric && text ? numeric : null;
}

function isEnumOption(value: unknown): value is EnumOption {
  return typeof value === "string" || typeof value === "number" || typeof value === "boolean";
}

function describe(name: string, field: Json, required: boolean, nullable: boolean, root: Json): SchemaField {
  const decimal = decimalBounds(field, root);
  const bounds = decimal ?? field;
  const enumValues: unknown[] | null = Array.isArray(field.enum) ? field.enum : "const" in field ? [field.const] : null;
  let kind: FieldKind;
  let options: EnumOption[] = [];
  if (decimal) {
    kind = "decimal";
  } else if (enumValues && enumValues.length > 0 && enumValues.every(isEnumOption)) {
    kind = "enum";
    options = enumValues;
  } else if (field.type === "boolean") {
    kind = nullable ? "enum" : "boolean";
    options = nullable ? [true, false] : [];
  } else if (field.type === "integer" || field.type === "number" || field.type === "string") {
    kind = field.type;
  } else {
    kind = "json";
  }
  return {
    name,
    label: typeof field.title === "string" && field.title ? field.title : humanize(name),
    description: typeof field.description === "string" ? field.description : null,
    kind,
    required,
    nullable,
    options,
    minimum: numberOrNull(bounds.minimum),
    maximum: numberOrNull(bounds.maximum),
    exclusiveMinimum: numberOrNull(bounds.exclusiveMinimum),
    exclusiveMaximum: numberOrNull(bounds.exclusiveMaximum),
    defaultValue: field.default,
  };
}

export function schemaFields(schema: Record<string, unknown>): SchemaField[] {
  const top = resolve(schema, schema);
  const properties = isObject(top.properties) ? top.properties : {};
  const required = new Set(
    Array.isArray(top.required) ? top.required.filter((name): name is string => typeof name === "string") : [],
  );
  return Object.entries(properties).map(([name, raw]) => {
    const { schema: field, nullable } = splitNullable(resolve(raw, schema), schema);
    return describe(name, field, required.has(name), nullable, schema);
  });
}

export function toFormValues(fields: readonly SchemaField[], config: Record<string, unknown>): FormValues {
  const values: FormValues = {};
  for (const field of fields) {
    const value = field.name in config ? config[field.name] : field.defaultValue;
    if (field.kind === "boolean") values[field.name] = value === true;
    else if (value === undefined || value === null) values[field.name] = "";
    else if (field.kind === "json") values[field.name] = JSON.stringify(value, null, 2);
    else values[field.name] = String(value);
  }
  return values;
}

function checkBounds(field: SchemaField, number: number): string | null {
  if (field.minimum !== null && number < field.minimum) return `Must be at least ${field.minimum}`;
  if (field.maximum !== null && number > field.maximum) return `Must be at most ${field.maximum}`;
  if (field.exclusiveMinimum !== null && number <= field.exclusiveMinimum) {
    return `Must be more than ${field.exclusiveMinimum}`;
  }
  if (field.exclusiveMaximum !== null && number >= field.exclusiveMaximum) {
    return `Must be less than ${field.exclusiveMaximum}`;
  }
  return null;
}

function parseValue(field: SchemaField, text: string): { value: unknown } | { error: string } {
  switch (field.kind) {
    case "integer": {
      if (!/^[-+]?\d+$/.test(text)) return { error: "Enter a whole number" };
      const error = checkBounds(field, Number(text));
      return error ? { error } : { value: Number(text) };
    }
    case "number":
    case "decimal": {
      const number = Number(text);
      if (!/^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/.test(text) || !Number.isFinite(number)) {
        return { error: "Enter a number" };
      }
      const error = checkBounds(field, number);
      if (error) return { error };
      // Decimals travel as strings so no digit is lost to floating point.
      return { value: field.kind === "decimal" ? text : number };
    }
    case "enum": {
      const option = field.options.find((candidate) => String(candidate) === text);
      return option === undefined ? { error: "Choose one of the options" } : { value: option };
    }
    case "json":
      try {
        return { value: JSON.parse(text) as unknown };
      } catch {
        return { error: "Enter valid JSON" };
      }
    default:
      return { value: text };
  }
}

/** The config to send, or per-field errors. An empty field means null where allowed, else an error. */
export function parseFormValues(fields: readonly SchemaField[], values: FormValues): ParsedForm {
  const config: Record<string, unknown> = {};
  const errors: Record<string, string> = {};
  for (const field of fields) {
    const raw = values[field.name];
    if (field.kind === "boolean") {
      config[field.name] = raw === true;
      continue;
    }
    const text = typeof raw === "string" ? raw.trim() : "";
    if (text === "") {
      if (field.nullable) config[field.name] = null;
      else errors[field.name] = "Enter a value";
      continue;
    }
    const result = parseValue(field, text);
    if ("error" in result) errors[field.name] = result.error;
    else config[field.name] = result.value;
  }
  return { config, errors };
}
