import { describe, expect, it } from "vitest";
import type { SchemaField } from "@/lib/schema-form";
import {
  appliedOverlays,
  compatibilityVerdict,
  fieldConstraint,
  scopeSummary,
  strategyRequirements,
  syncSummary,
  toggleApplied,
} from "@/lib/strategies";
import { deployment } from "@/test/fixtures";

function setting(overrides: Partial<SchemaField>): SchemaField {
  return {
    name: "setting",
    label: "Setting",
    description: null,
    kind: "number",
    required: false,
    nullable: false,
    options: [],
    minimum: null,
    maximum: null,
    exclusiveMinimum: null,
    exclusiveMaximum: null,
    defaultValue: undefined,
    ...overrides,
  };
}

describe("fieldConstraint", () => {
  it("lists bounds in reading order", () => {
    expect(fieldConstraint(setting({ kind: "integer", minimum: 2, maximum: 200 }))).toBe("≥ 2, ≤ 200");
    expect(
      fieldConstraint(setting({ kind: "decimal", exclusiveMinimum: 0, exclusiveMaximum: 1, nullable: true })),
    ).toBe("> 0, < 1, or null");
    expect(fieldConstraint(setting({ kind: "string" }))).toBe("");
  });

  it("lists the options of a choice", () => {
    expect(fieldConstraint(setting({ kind: "enum", options: ["ema", "sma"] }))).toBe('"ema" | "sma"');
    expect(fieldConstraint(setting({ kind: "enum", options: [true, false], nullable: true }))).toBe(
      "true | false, or null",
    );
  });
});

describe("strategyRequirements", () => {
  it("reads declared needs and treats malformed entries as absent", () => {
    expect(
      strategyRequirements({
        markets: ["INDIA", 3],
        exchanges: ["NSE"],
        instrument_keys: ["NSE:CASH:EQUITY:INFY"],
        candle_intervals: "5m",
        indicators: [{ indicator: "ema", params: { period: 20 } }, { alias: "orphan" }, "rsi"],
        warmup_candles: 50.7,
        required_data: ["VOLUME", 1],
        signal_conditions: [
          { signal_type: "BUY", description: "Fast EMA crosses above slow", inputs: ["ema_fast", "ema_slow"] },
          { description: "No signal type" },
          "EXIT",
        ],
        uses_partial_candles: "yes",
        risk_profile: "",
      }),
    ).toEqual({
      markets: ["INDIA"],
      exchanges: ["NSE"],
      segments: [],
      instrumentTypes: [],
      instrumentKeys: ["NSE:CASH:EQUITY:INFY"],
      eventTypes: [],
      candleIntervals: [],
      indicators: [{ alias: "ema", indicator: "ema", interval: "", params: { period: 20 } }],
      warmupCandles: 50,
      requiredData: ["VOLUME"],
      signalConditions: [
        { signalType: "BUY", description: "Fast EMA crosses above slow", inputs: ["ema_fast", "ema_slow"] },
      ],
      usesPartialCandles: false,
      resourceProfile: null,
      riskProfile: null,
    });
  });
});

describe("scopeSummary", () => {
  const symbols: Record<string, string> = { a: "INFY", b: "TCS", c: "SBIN", d: "ITC" };
  const symbolOf = (id: string) => symbols[id];

  it("names a whole-workspace scope whatever the instrument", () => {
    expect(scopeSummary(deployment({ scope_kind: "WORKSPACE", instrument_ids: [] }), { instrumentId: "a" })).toBe(
      "Whole workspace",
    );
  });

  it("speaks of the instrument in view when the scope lists it", () => {
    expect(scopeSummary(deployment({ instrument_ids: ["a"] }), { instrumentId: "a" })).toBe("This instrument");
    expect(scopeSummary(deployment({ instrument_ids: ["a", "b"] }), { instrumentId: "a" })).toBe(
      "This instrument and 1 more",
    );
  });

  it("lists a few known symbols, and counts otherwise", () => {
    expect(scopeSummary(deployment({ instrument_ids: ["a", "b"] }), { symbolOf })).toBe("INFY, TCS");
    expect(scopeSummary(deployment({ instrument_ids: ["a", "b", "c", "d"] }), { symbolOf })).toBe("4 instruments");
    expect(scopeSummary(deployment({ instrument_ids: ["a", "unknown"] }), { symbolOf })).toBe("2 instruments");
    expect(scopeSummary(deployment({ instrument_ids: [] }))).toBe("No instruments");
  });
});

describe("compatibilityVerdict", () => {
  const check = (status: "PASSED" | "WARNING" | "FAILED") => ({ aspect: "DATA" as const, status, detail: "" });

  it("rules a strategy out on any failed check, and flags warnings", () => {
    expect(compatibilityVerdict({ compatible: true, checks: [check("PASSED")] }).label).toBe("Compatible");
    expect(compatibilityVerdict({ compatible: true, checks: [check("PASSED"), check("WARNING")] })).toEqual({
      label: "Compatible with warnings",
      tone: "warning",
    });
    expect(compatibilityVerdict({ compatible: false, checks: [check("FAILED"), check("WARNING")] }).label).toBe(
      "Not compatible",
    );
    expect(compatibilityVerdict({ compatible: true, checks: [check("FAILED")] }).label).toBe("Not compatible");
  });
});

describe("chart overlays", () => {
  const one = deployment({ id: "one", label: "Fast" });
  const two = deployment({ id: "two", label: "Slow" });

  it("numbers the applied configurations that still exist, in the order applied", () => {
    expect(
      appliedOverlays(["two", "gone", "one", "two"], [one, two]).map(({ deployment: item, number }) => [item.label, number]),
    ).toEqual([
      ["Slow", 1],
      ["Fast", 2],
    ]);
    expect(appliedOverlays([], [one])).toEqual([]);
  });

  it("toggles one configuration without touching the others", () => {
    expect(toggleApplied(["one"], "two")).toEqual(["one", "two"]);
    expect(toggleApplied(["one", "two"], "one")).toEqual(["two"]);
  });
});

describe("syncSummary", () => {
  it("names only the groups that changed", () => {
    expect(
      syncSummary({ added: ["ema_cross@1"], restored: [], upgraded: ["rsi@2"], code_changed: [], unavailable: ["old@1"] }),
    ).toBe("added: ema_cross@1; upgraded: rsi@2; no longer in the code: old@1.");
    expect(syncSummary({ added: [], restored: [], upgraded: [], code_changed: [], unavailable: [] })).toBe(
      "The catalogue already matches the code.",
    );
  });
});
