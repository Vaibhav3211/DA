"use client";

import { useMutation, useQueryClient, type QueryKey } from "@tanstack/react-query";
import { notify } from "@/lib/notifications";
import { errorMessage } from "@/lib/utils";
import type {
  BacktestFilters,
  CandleQuery,
  ChartSignalQuery,
  CompatibilityQuery,
  DatasetFilters,
  DeploymentFilters,
  InstrumentSearch,
  RunQuery,
  SignalFilters,
} from "./endpoints";
import type { Provider } from "./types.gen";

// Prefixes are shared on purpose: invalidating ["workspaces"] also refreshes universes and watchlists.
export const queryKeys = {
  me: ["auth", "me"],
  providers: ["providers"],
  capabilities: (provider: Provider, accountId: string | null) => ["providers", provider, "capabilities", accountId],
  accounts: ["accounts"],
  markets: ["markets"],
  marketAvailability: ["markets", "availability"],
  workspaces: ["workspaces"],
  universe: (ws: string) => ["workspaces", ws, "universe"],
  watchlists: (ws: string) => ["workspaces", ws, "watchlists"],
  /** Every deployments query shares the ["deployments"] prefix, so one invalidation refreshes them all. */
  deployments: (filters: DeploymentFilters) => ["deployments", filters],
  instruments: ["instruments"],
  instrumentSearch: (params: InstrumentSearch) => ["instruments", "search", params],
  instrument: (ref: string) => ["instruments", "detail", ref],
  candles: (params: CandleQuery) => ["candles", params],
  quotes: (scope: string) => ["quotes", scope],
  strategies: ["strategies"],
  compatibility: (params: CompatibilityQuery) => ["strategy-compatibility", params],
  runs: (params: RunQuery) => ["strategy-runs", params],
  signals: ["signals"],
  signalList: (filters: SignalFilters) => ["signals", "list", filters],
  chartSignals: (params: ChartSignalQuery) => ["signals", "chart", params],
  signal: (id: string) => ["signals", "detail", id],
  riskRules: (ws: string | null) => ["risk", "rules", ws],
  /** Every dataset query shares the ["datasets"] prefix. */
  datasetSources: (instrument: string) => ["datasets", "sources", instrument],
  datasetList: (filters: DatasetFilters) => ["datasets", "list", filters],
  /** Every backtest query shares the ["backtests"] prefix, so one invalidation refreshes them all. */
  backtestRules: (deploymentId: string) => ["backtests", "rules", deploymentId],
  latestBacktest: (deploymentId: string, instrument: string) => ["backtests", "latest", deploymentId, instrument],
  backtestList: (filters: BacktestFilters) => ["backtests", "list", filters],
  backtest: (id: string) => ["backtests", "detail", id],
  backtestTrades: (id: string, offset: number, limit: number) => ["backtests", "trades", id, offset, limit],
  health: ["system", "health"],
  metrics: ["system", "metrics"],
  killSwitch: ["system", "kill-switch"],
} as const;

export interface ApiMutationOptions<TData, TVariables> {
  mutationFn: (variables: TVariables) => Promise<TData>;
  /** Queries to refresh once the change succeeds. */
  invalidate?: readonly QueryKey[] | ((data: TData, variables: TVariables) => readonly QueryKey[]);
  /** A success notice; null for none. */
  success?: string | null | ((data: TData, variables: TVariables) => string | null);
  errorTitle?: string;
  onSuccess?: (data: TData, variables: TVariables) => void;
}

/** A mutation that refreshes the queries it affects and reports the outcome as a notice. */
export function useApiMutation<TData, TVariables = void>(options: ApiMutationOptions<TData, TVariables>) {
  const queryClient = useQueryClient();
  return useMutation<TData, Error, TVariables>({
    mutationFn: options.mutationFn,
    onSuccess: async (data, variables) => {
      const keys =
        typeof options.invalidate === "function" ? options.invalidate(data, variables) : (options.invalidate ?? []);
      await Promise.all(keys.map((queryKey) => queryClient.invalidateQueries({ queryKey })));
      const message = typeof options.success === "function" ? options.success(data, variables) : options.success;
      if (message) notify("success", message);
      options.onSuccess?.(data, variables);
    },
    onError: (error) => {
      notify("error", options.errorTitle ?? "The change failed", errorMessage(error));
    },
  });
}
