// Generated from the backend's API models by `python -m app.api.contract`. Do not edit.

export interface AccountChoice {
  account_id: string;
  label: string;
  problem: string | null;
}

export interface AccountCreate {
  provider: Provider;
  label: string;
  auth_method?: AuthMethod | null;
}

export interface AccountHealth {
  account_id: string;
  provider: string;
  label: string;
  status: AccountStatus;
  is_enabled: boolean;
  token_expires_at: string | null;
}

export interface AccountRef {
  id: string;
  label: string;
}

export interface AccountRequest {
  account_id: string;
}

/** Credential/authentication state of a provider account. */
export type AccountStatus = "NEEDS_CREDENTIALS" | "AUTH_REQUIRED" | "AUTHENTICATED" | "DISCONNECTED";

export interface AccountUpdate {
  label?: string | null;
  auth_method?: AuthMethod | null;
}

export interface Alert {
  severity: "critical" | "warning" | "info";
  code: string;
  message: string;
  subject: string | null;
}

export type AuthMethod = "ZERODHA_LOGIN_REDIRECT" | "GROWW_ACCESS_TOKEN" | "GROWW_API_KEY_SECRET" | "GROWW_TOTP" | "NONE";

export interface BacktestDetail {
  run: BacktestRunView;
  dataset: DatasetView;
  equity_curve: EquityPoint[];
  curve_problem: string | null;
  changed: string[];
  current_problem: string | null;
}

/** A configuration's backtests on one instrument against its current settings. */
export interface BacktestLatest {
  deployment_id: string;
  label: string;
  instrument_id: string;
  instrument_key: string;
  interval: CandleInterval | null;
  state: BacktestState;
  current: BacktestRunView | null;
  outdated: BacktestRunView | null;
  changed: string[];
  outdated_runs: number;
  in_progress: BacktestRunView | null;
  last_failed: BacktestRunView | null;
  settings_hash: string | null;
  rules: TradeRulesView;
  problem: string | null;
  worker_problem: string | null;
}

export interface BacktestMetrics {
  closed_trades: number;
  wins: number;
  losses: number;
  breakevens: number;
  win_rate_pct: Measure;
  average_win: Measure;
  average_loss: Measure;
  gross_pnl: string;
  net_pnl: string;
  gross_return_pct: string;
  net_return_pct: string;
  fees: string;
  slippage: string;
  profit_factor: Measure;
  max_drawdown: string;
  max_drawdown_pct: Measure;
  drawdown_peak_at: string | null;
  drawdown_trough_at: string | null;
  final_equity: string;
  both_touched_trades: number;
  gap_exits: number;
}

export interface BacktestPeriod {
  dataset_from: string;
  dataset_to: string;
  warmup_candles: number;
  evaluated_from: string | null;
  evaluated_to: string | null;
  evaluated_candles: number;
}

export interface BacktestQueueResult {
  run: BacktestRunView;
  created: boolean;
  worker_problem: string | null;
}

export interface BacktestRequest {
  deployment_id: string;
  instrument: string;
  dataset_id: string;
}

/** One backtest. ``summary`` is filled in once it SUCCEEDED; the trades are paged separately. */
export interface BacktestRunView {
  id: string;
  deployment_id: string;
  label: string;
  workspace_slug: string;
  instrument_id: string;
  instrument_key: string;
  symbol: string;
  dataset_id: string;
  dataset_sha: string;
  provider: Provider;
  source: DatasetSource;
  simulated: boolean;
  date_from: string;
  date_to: string;
  strategy_id: string;
  strategy_version: string;
  code_fingerprint: string;
  configuration_id: string;
  config_hash: string;
  interval: CandleInterval;
  settings: Record<string, unknown>;
  settings_hash: string;
  status: BacktestStatus;
  requested_by: string | null;
  worker_id: string | null;
  started_at: string | null;
  finished_at: string | null;
  error: string | null;
  summary: BacktestSummary | null;
  trade_count: number;
  outdated: boolean | null;
  created_at: string;
  updated_at: string;
}

/** How a saved configuration's backtests on one instrument relate to its current settings. */
export type BacktestState = "CURRENT" | "OUTDATED" | "NOT_BACKTESTED";

export type BacktestStatus = "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED";

/** Everything about a finished backtest except its trades and equity curve. */
export interface BacktestSummary {
  engine_version: string;
  period: BacktestPeriod;
  metrics: BacktestMetrics;
  signals: SignalStats;
  open_position: OpenPosition | null;
  pending_at_end: string[];
  skipped_entries: SkippedEntry[];
  skipped_entries_total: number;
  equity_points: number;
  notes: string[];
}

/** A closed trade. Gross results use reference prices (the open, close or level a fill is based on); net results use fill prices, after slippage, minus fees. ``entry_at`` and ``exit_at`` are the starts of the candles the fills happened in: at the open (NEXT_OPEN, or a gap through a level), at the close (SAME_CLOSE, or exits decided on closes) or inside the candle (a stop-loss or target touched). */
export interface BacktestTrade {
  number: number;
  side: PositionSide;
  quantity: number;
  entry_at: string;
  entry_reference: string;
  entry_price: string;
  exit_at: string;
  exit_reference: string;
  exit_price: string;
  exit_reason: ExitReason;
  stop_loss: string | null;
  target: string | null;
  both_touched: boolean;
  gap_exit: boolean;
  candles_held: number;
  gross_pnl: string;
  fees: string;
  slippage: string;
  net_pnl: string;
  return_pct: string;
  outcome: TradeOutcome;
  entry_signal: SignalRef;
  exit_signal: SignalRef | null;
}

export interface BacktestTradesPage {
  run_id: string;
  total: number;
  offset: number;
  limit: number;
  trades: BacktestTrade[];
}

export interface Candle {
  provider: Provider;
  account_id: string | null;
  instrument_id: string;
  symbol: string;
  exchange: Exchange;
  segment: Segment;
  interval: CandleInterval;
  bucket_start: string;
  bucket_end: string;
  open_price: string;
  high_price: string;
  low_price: string;
  close_price: string;
  volume: number | null;
  event_count: number;
  is_closed: boolean;
  data_status: DataStatus;
  flags: CandleFlag[];
  first_event_at: string;
  last_event_at: string;
  revision: number;
  builder_version: string;
}

export type CandleFlag = "PARTIAL_START" | "GAP_BEFORE" | "DISCONNECTED_DURING" | "LATE_EVENTS_IGNORED" | "VOLUME_INCOMPLETE" | "VOLUME_RESET" | "VOLUME_UNAVAILABLE" | "RECEIVE_TIME_BASIS" | "OUTSIDE_SESSION";

export type CandleInterval = "1s" | "1m" | "3m" | "5m" | "15m" | "30m" | "1h" | "1d";

export interface CandleSeries {
  instrument: Instrument;
  provider: Provider;
  interval: CandleInterval;
  candles: Candle[];
  forming: Candle | null;
  feed_status: DataStatus;
  generated_at: string;
}

/** What ``sync_catalogue`` changed. */
export interface CatalogueSync {
  added: string[];
  restored: string[];
  upgraded: string[];
  code_changed: string[];
  unavailable: string[];
}

export type CheckStatus = "PASSED" | "WARNING" | "FAILED";

/** What one check of a strategy against an instrument looks at. */
export type CompatibilityAspect = "MARKET" | "INSTRUMENT" | "TIMEFRAME" | "DATA" | "WARMUP";

export interface CompatibilityCheck {
  aspect: CompatibilityAspect;
  status: CheckStatus;
  detail: string;
}

export interface ComponentHealth {
  name: string;
  ok: boolean;
  latency_ms: number | null;
  error: string | null;
}

export interface ConfigurationCreate {
  workspace: string;
  strategy_id: string;
  scope: ScopeBody;
  label?: string | null;
  config?: Record<string, unknown> | null;
}

export interface ConfigurationUpdate {
  label?: string | null;
  scope?: ScopeBody | null;
  config?: Record<string, unknown> | null;
  reset_config?: boolean;
}

export type ConnectionState = "IDLE" | "CONNECTING" | "CONNECTED" | "RECONNECTING" | "DISCONNECTED" | "AUTH_REQUIRED" | "STOPPED";

export interface CredentialInfo {
  kind: CredentialKind;
  label: string;
  origin: CredentialOrigin;
  masked: string | null;
}

export type CredentialKind = "API_KEY" | "API_SECRET" | "ACCESS_TOKEN" | "TOTP_SECRET";

export type CredentialOrigin = "ACCOUNT" | "ENVIRONMENT";

export interface CredentialsUpdate {
  values: Partial<Record<CredentialKind, string>>;
}

/** Market data a strategy needs besides prices. */
export type DataRequirement = "VOLUME" | "OPEN_INTEREST" | "MARKET_DEPTH";

export type DataStatus = "LIVE" | "DELAYED" | "STALE" | "DISCONNECTED" | "RECONNECTING" | "SIMULATED" | "UNKNOWN";

/** How completely a dataset covers its dates, measured against the exchange calendar. */
export interface DatasetCoverage {
  anchor: string | null;
  session_days: number;
  expected: number;
  present: number;
  missing: number;
  coverage_pct: string | null;
  gaps: GapRange[];
  gap_total: number;
  assumed_days: string[];
  assumed_days_total: number;
  unknown_days: string[];
  unknown_days_total: number;
  left_out: number;
  left_out_by_reason: Record<string, number>;
  left_out_examples: string[];
  duplicates: number;
  requests: number;
  inconsistent: number;
  without_volume: number;
  incomplete: number;
  notes: string[];
}

export interface DatasetRequest {
  instrument: string;
  provider: Provider;
  source: DatasetSource;
  interval: CandleInterval;
  date_from: string;
  date_to: string;
  account_id?: string | null;
}

export interface DatasetRequestResult {
  dataset: DatasetView;
  created: boolean;
}

/** Where a dataset's candles come from. */
export type DatasetSource = "PROVIDER_HISTORY" | "RECORDED" | "SIMULATED";

export interface DatasetSourceOption {
  provider: Provider;
  source: DatasetSource;
  available: boolean;
  reason: string | null;
  intervals: CandleInterval[];
  max_days_per_request: Record<string, number>;
  note: string | null;
  accounts: AccountChoice[];
  recorded: RecordedSeries[];
}

/** Where an instrument's dataset can come from, and the limits on it. */
export interface DatasetSources {
  instrument_id: string;
  instrument_key: string;
  symbol: string;
  exchange: Exchange;
  segment: Segment;
  today: string;
  max_candles: number;
  max_span_days: number;
  options: DatasetSourceOption[];
  worker_problem: string | null;
}

export type DatasetStatus = "PENDING" | "BUILDING" | "READY" | "FAILED";

/** A backtest dataset. ``coverage`` is filled in once it is READY. */
export interface DatasetView {
  id: string;
  instrument_id: string;
  instrument_key: string;
  symbol: string;
  exchange: Exchange;
  provider: Provider;
  account_id: string | null;
  source: DatasetSource;
  simulated: boolean;
  interval: CandleInterval;
  date_from: string;
  date_to: string;
  status: DatasetStatus;
  requested_by: string | null;
  worker_id: string | null;
  started_at: string | null;
  finished_at: string | null;
  error: string | null;
  candle_count: number;
  first_candle_at: string | null;
  last_candle_at: string | null;
  content_sha: string | null;
  coverage: DatasetCoverage | null;
  created_at: string;
  updated_at: string;
}

export type DayKind = "SESSION" | "HOLIDAY" | "WEEKEND" | "UNKNOWN";

/** A saved strategy configuration. */
export interface DeploymentView {
  id: string;
  workspace_id: string;
  workspace_slug: string;
  market_region: MarketRegion;
  strategy_id: string;
  strategy_version: string;
  code_fingerprint: string | null;
  label: string;
  configuration_id: string;
  config: Record<string, unknown>;
  config_hash: string;
  scope_kind: ScopeKind;
  instrument_ids: string[];
  is_enabled: boolean;
  enabled_by: string | null;
  enabled_at: string | null;
  disabled_at: string | null;
  archived_at: string | null;
  created_at: string;
  updated_at: string;
  blocked_reason: string | null;
  last_run: RunView | null;
  monitoring: Monitoring | null;
}

export interface DepthLevel {
  price: string;
  quantity: number;
  orders: number | null;
}

export type DumpSource = "DOWNLOAD" | "FILE" | "BUILT_IN";

export type EntryStatus = "PLANNED" | "SKIPPED" | "WORKSPACE_DISABLED";

export interface EquityPoint {
  at: string;
  equity: string;
}

export type EventType = "LTP" | "QUOTE" | "DEPTH" | "INDEX_VALUE";

export type Exchange = "NSE" | "BSE" | "MCX" | "SIM";

export type ExitCheck = "INTRABAR" | "CLOSE";

export type ExitReason = "STOP_LOSS" | "TARGET" | "EXIT_SIGNAL" | "OPPOSITE_SIGNAL" | "MAX_HOLDING";

export interface FeedStateChange {
  provider: Provider;
  account_id: string | null;
  stream_id: string;
  previous_state: ConnectionState;
  state: ConnectionState;
  reason: string;
  at: string;
}

export type FillTiming = "NEXT_OPEN" | "SAME_CLOSE";

/** Consecutive candles the exchange calendar expects and the dataset does not have. */
export interface GapRange {
  start: string;
  end: string;
  candles: number;
}

/** Sign a Groww account in. */
export interface GrowwConnectRequest {
  account_id: string;
  access_token?: string | null;
  totp_code?: string | null;
}

export interface HTTPValidationError {
  detail: ValidationError[];
}

/** An indicator reading with enough provenance to trace it back to its input candles. */
export interface IndicatorValue {
  name: string;
  indicator: string;
  version: string;
  params: Record<string, unknown>;
  value: string | null;
  interval: CandleInterval | null;
  input_from: string | null;
  input_to: string | null;
  input_count: number;
  data_status: DataStatus;
}

/** Canonical, provider-independent instrument. */
export interface Instrument {
  id: string;
  canonical_key: string;
  exchange: Exchange;
  segment: Segment;
  instrument_type: InstrumentType;
  symbol: string;
  name: string | null;
  underlying: string | null;
  expiry: string | null;
  strike: string | null;
  option_type: OptionType | null;
  lot_size: number | null;
  tick_size: string | null;
  currency: string;
  isin: string | null;
  is_active: boolean;
  updated_at: string | null;
}

/** How each strategy in the code suits one instrument of a workspace. */
export interface InstrumentCompatibility {
  workspace_slug: string;
  market_region: MarketRegion;
  instrument_id: string;
  canonical_key: string;
  provider: Provider;
  subscription_mode: SubscriptionMode;
  chart_interval: CandleInterval | null;
  built_intervals: CandleInterval[];
  strategies: StrategyCompatibility[];
}

export interface InstrumentDetail {
  instrument: Instrument;
  mappings: InstrumentMapping[];
}

export interface InstrumentHit {
  instrument: Instrument;
  providers: Provider[];
}

/** Versioned link between a canonical instrument and one provider identifier. */
export interface InstrumentMapping {
  id: string;
  instrument_id: string;
  provider: Provider;
  provider_token: string;
  exchange_token: string | null;
  provider_symbol: string;
  provider_exchange: string;
  provider_segment: string;
  is_active: boolean;
  valid_from: string;
  valid_to: string | null;
  metadata: Record<string, unknown>;
}

export interface InstrumentPage {
  items: InstrumentHit[];
  has_more: boolean;
}

export type InstrumentType = "EQUITY" | "INDEX" | "FUTURE" | "OPTION" | "OTHER";

export interface KillSwitchState {
  engaged: boolean;
  reason: string | null;
  updated_by: string | null;
  updated_at: string | null;
}

export interface KillSwitchUpdate {
  engaged: boolean;
  reason?: string | null;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LogoutResult {
  account: ProviderAccountView;
  remote_revoked: boolean | null;
}

export interface MarketAvailability {
  key: string;
  name: string;
  region: MarketRegion | null;
  available: boolean;
  providers: Provider[];
  reason: string;
  planned_milestone: string | null;
  notes: string[];
}

export interface MarketDepth {
  bids: DepthLevel[];
  asks: DepthLevel[];
}

export interface MarketOverview {
  markets: MarketSession[];
  generated_at: string;
}

export type MarketRegion = "INDIA" | "FOREX" | "CRYPTO" | "LAB";

export interface MarketSession {
  exchange: Exchange;
  timezone: string;
  state: MarketSessionState;
  session_date: string;
  day_kind: DayKind;
  open_at: string | null;
  close_at: string | null;
  special: boolean;
  verified: boolean;
  calendar_covered_until: string | null;
}

export type MarketSessionState = "PRE_OPEN" | "OPEN" | "POST_CLOSE" | "CLOSED" | "HOLIDAY" | "UNKNOWN";

/** A metric that may be undefined; ``reason`` says why ``value`` is missing. */
export interface Measure {
  value: string | null;
  reason: string | null;
}

export interface MetricsSummary {
  workers: Record<string, unknown>[];
  feeds: Record<string, unknown>[];
  websocket_clients: number;
  prometheus_endpoint: string;
}

/** How live monitoring of a saved configuration is doing. */
export interface Monitoring {
  state: MonitoringState;
  reasons: string[];
  warnings: string[];
  warmup: MonitoringWarmup | null;
}

/** Live monitoring of a saved configuration, as shown to the user. */
export type MonitoringState = "STOPPED" | "STARTING" | "WARMING_UP" | "RUNNING" | "BLOCKED" | "FAILED";

/** How far the current run's warm-up is. */
export interface MonitoringWarmup {
  instruments: number;
  of: number;
  remaining: Record<string, number>;
}

export interface OkResponse {
  ok: boolean;
}

/** The position still open when the data ends, valued at the last close. Not a closed trade. */
export interface OpenPosition {
  side: PositionSide;
  quantity: number;
  entry_at: string;
  entry_price: string;
  stop_loss: string | null;
  target: string | null;
  candles_held: number;
  marked_at: string;
  mark_price: string;
  unrealized_pnl: string;
  entry_signal: SignalRef;
}

/** What a signal against the open position does. */
export type OppositeSignal = "REVERSE" | "CLOSE";

export type OptionType = "CE" | "PE";

export interface PauseRequest {
  reason?: string | null;
}

export type PositionSide = "LONG" | "SHORT";

/** Where an instrument came from before it was added again with another source. */
export interface PreviousSource {
  instrument: Instrument;
  provider: Provider;
  account: AccountRef | null;
  mode: SubscriptionMode;
}

export type Provider = "ZERODHA" | "GROWW" | "SIMULATOR";

export interface ProviderAccountHealth {
  account_id: string;
  label: string;
  is_enabled: boolean;
  status: AccountStatus;
  has_access_token: boolean;
  token_expires_at: string | null;
  data_status: DataStatus;
  last_error_code: string | null;
  last_error_message: string | null;
  streaming_disabled_reason: string | null;
}

export interface ProviderAccountView {
  id: string;
  provider: Provider;
  label: string;
  auth_method: AuthMethod;
  status: AccountStatus;
  is_enabled: boolean;
  masked_api_key: string | null;
  credentials: CredentialInfo[];
  missing_credentials: CredentialKind[];
  has_access_token: boolean;
  provider_user_ref: string | null;
  last_auth_at: string | null;
  token_expires_at: string | null;
  last_connected_at: string | null;
  last_disconnected_at: string | null;
  last_error_code: string | null;
  last_error_message: string | null;
  streaming_disabled_reason: string | null;
  created_by: string | null;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
}

/** What a provider supports, as verified from official documentation on ``verified_on``. */
export interface ProviderCapabilities {
  provider: Provider;
  display_name: string;
  exchanges: Exchange[];
  segments: Segment[];
  instrument_types: InstrumentType[];
  streaming: boolean;
  rest_quotes: boolean;
  subscription_modes: SubscriptionMode[];
  quote_fields: string[];
  depth_levels: number | null;
  max_instruments_per_connection: number | null;
  max_connections_per_account: number | null;
  rest_rate_limits: Record<string, string>;
  token_expiry: string;
  token_refresh: string;
  entitlement: string;
  restrictions: string[];
  documentation_urls: string[];
  verified_on: string | null;
  verification_source: string;
  needs_live_verification: string[];
}

export interface ProviderHealth {
  provider: Provider;
  data_status: DataStatus;
  accounts: ProviderAccountHealth[];
  feeds: StreamHealth[];
  generated_at: string;
}

export interface ProviderSummary {
  provider: Provider;
  display_name: string;
  data_status: DataStatus;
  accounts: ProviderAccountView[];
  feeds: StreamHealth[];
  capabilities: ProviderCapabilities;
  generated_at: string;
}

export interface QuoteList {
  items: QuoteView[];
  missing: string[];
  generated_at: string;
}

/** A stored quote whose ``data_status`` is recomputed when read; ``stored_status`` is as written. */
export interface QuoteView {
  last_price: string | null;
  last_quantity: number | null;
  average_price: string | null;
  volume: number | null;
  volume_semantics: VolumeSemantics;
  open_price: string | null;
  high_price: string | null;
  low_price: string | null;
  close_price: string | null;
  previous_close: string | null;
  bid: string | null;
  ask: string | null;
  bid_quantity: number | null;
  ask_quantity: number | null;
  total_buy_quantity: number | null;
  total_sell_quantity: number | null;
  open_interest: number | null;
  open_interest_day_high: number | null;
  open_interest_day_low: number | null;
  market_depth: MarketDepth | null;
  source_timestamp: string | null;
  last_trade_time: string | null;
  provider_timestamp: string | null;
  provider: Provider;
  account_id: string | null;
  instrument_id: string;
  symbol: string;
  exchange: Exchange;
  segment: Segment;
  last_event_type: EventType;
  received_at: string;
  processed_at: string;
  data_status: DataStatus;
  sequence_number: number | null;
  depth_received_at: string | null;
  stored_status: DataStatus;
  feed_status: DataStatus;
  age_seconds: number;
}

/** Closed candles recorded from one source at one interval. */
export interface RecordedSeries {
  interval: CandleInterval;
  candles: number;
  first_candle_at: string;
  last_candle_at: string;
}

export interface RefreshReport {
  provider: Provider;
  source: DumpSource;
  account_id: string | null;
  rows: number;
  accepted: number;
  skipped: Record<string, number>;
  stats: SyncStats;
  forced: boolean;
  cache_path: string | null;
  cache_error: string | null;
  published: boolean;
  duration_seconds: number;
}

export interface RefreshRequest {
  provider: Provider;
  account_id?: string | null;
  force?: boolean;
}

export interface RiskCheck {
  rule: string;
  passed: boolean;
  severity: "BLOCK" | "WARN";
  message: string;
  details: Record<string, unknown>;
}

export interface RiskDecision {
  outcome: RiskOutcome;
  checks: RiskCheck[];
  evaluated_at: string;
}

/** One pass through the risk gate; a signal is gated again whenever it is updated. */
export interface RiskDecisionView {
  id: string;
  outcome: RiskOutcome;
  checks: RiskCheck[];
  evaluated_at: string;
}

export type RiskOutcome = "ALLOW" | "BLOCK";

export interface RiskRuleView {
  rule_key: string;
  description: string;
  mandatory: boolean;
  workspace_slug: string | null;
  enabled: boolean;
  source: string;
  params: Record<string, unknown>;
  defaults: Record<string, unknown>;
  error: string | null;
  updated_by: string | null;
  updated_at: string | null;
}

export interface RuleUpdate {
  enabled?: boolean | null;
  params?: Record<string, unknown> | null;
}

export interface RunView {
  id: string;
  deployment_id: string;
  deployment_label: string;
  workspace_slug: string;
  strategy_id: string;
  strategy_version: string;
  configuration_id: string;
  config_hash: string;
  code_fingerprint: string | null;
  status: StrategyRunStatus;
  worker_id: string;
  started_at: string;
  stopped_at: string | null;
  heartbeat_at: string | null;
  instruments: number;
  excluded: number;
  instruments_warming: number;
  warmup_remaining: Record<string, number>;
  events_processed: number;
  candles_processed: number;
  signals_emitted: number;
  failures: number;
  timeouts: number;
  last_error: string | null;
  circuit_opened_at: string | null;
}

/** What a configuration watches. There is no default: list its instruments, or choose the whole workspace (including instruments added later) explicitly. */
export interface ScopeBody {
  kind: ScopeKind;
  instrument_ids?: string[];
}

/** What a saved strategy configuration watches: listed instruments, or the whole workspace. */
export type ScopeKind = "INSTRUMENTS" | "WORKSPACE";

export type Segment = "CASH" | "FNO" | "CURRENCY" | "COMMODITY" | "INDEX";

export interface SessionResponse {
  user_id: string;
  username: string;
  expires_at: string;
}

export interface Signal {
  id: string;
  workspace_id: string;
  market_region: MarketRegion;
  instrument_id: string;
  symbol: string;
  exchange: Exchange;
  segment: Segment;
  provider: Provider;
  account_id: string | null;
  strategy_id: string;
  strategy_version: string;
  deployment_id: string;
  strategy_run_id: string;
  signal_type: SignalType;
  status: SignalStatus;
  is_actionable: boolean;
  entry_price: string | null;
  stop_loss: string | null;
  targets: TargetLevel[];
  risk_reward: string | null;
  score: string | null;
  score_definition: string | null;
  generated_at: string;
  updated_at: string;
  valid_until: string | null;
  closed_at: string | null;
  source_event_time: string | null;
  source_candle_interval: CandleInterval | null;
  source_candle_start: string | null;
  data_status: DataStatus;
  reasons: string[];
  indicator_values: IndicatorValue[];
  invalidation_conditions: string[];
  explanation: string;
  risk_decision: RiskDecision;
  superseded_by: string | null;
  update_count: number;
  disclaimer: string;
}

/** The saved configuration the signal's run used, as it was when the run started: editing the saved configuration later does not change it. */
export interface SignalConfiguration {
  deployment_label: string;
  configuration_id: string;
  config: Record<string, unknown>;
  config_hash: string;
  code_fingerprint: string | null;
  run_started_at: string;
  is_current: boolean;
}

export interface SignalDetail {
  signal: SignalView;
  configuration: SignalConfiguration;
  events: SignalEventView[];
  decisions: RiskDecisionView[];
}

export type SignalEventType = "GENERATED" | "ACTIVATED" | "UPDATED" | "INVALIDATED" | "EXPIRED" | "SUPERSEDED" | "CLOSED" | "BLOCKED";

export interface SignalEventView {
  id: number;
  event_type: SignalEventType;
  from_status: SignalStatus | null;
  to_status: SignalStatus;
  details: Record<string, unknown>;
  occurred_at: string;
}

export interface SignalPage {
  items: SignalView[];
  next_cursor: string | null;
}

/** The signal behind a fill, as the strategy proposed it at a candle's close. */
export interface SignalRef {
  signal_type: SignalType;
  decided_at: string;
  candle_start: string;
  entry_price: string | null;
  stop_loss: string | null;
  targets: TargetLevel[];
  reasons: string[];
  indicators: Record<string, string | null>;
}

/** What happened to the strategy's proposals during the evaluated period. */
export interface SignalStats {
  proposed: number;
  allowed: number;
  blocked: number;
  blocked_by_rule: Record<string, number>;
  duplicates: number;
  updates: number;
  invalidations: number;
  expired: number;
}

export type SignalStatus = "GENERATED" | "ACTIVE" | "UPDATED" | "INVALIDATED" | "EXPIRED" | "SUPERSEDED" | "CLOSED" | "BLOCKED";

export type SignalType = "BUY" | "SELL" | "EXIT" | "HOLD" | "WATCH" | "INVALIDATED";

/** A signal and the slug of its workspace. */
export interface SignalView {
  id: string;
  workspace_id: string;
  market_region: MarketRegion;
  instrument_id: string;
  symbol: string;
  exchange: Exchange;
  segment: Segment;
  provider: Provider;
  account_id: string | null;
  strategy_id: string;
  strategy_version: string;
  deployment_id: string;
  strategy_run_id: string;
  signal_type: SignalType;
  status: SignalStatus;
  is_actionable: boolean;
  entry_price: string | null;
  stop_loss: string | null;
  targets: TargetLevel[];
  risk_reward: string | null;
  score: string | null;
  score_definition: string | null;
  generated_at: string;
  updated_at: string;
  valid_until: string | null;
  closed_at: string | null;
  source_event_time: string | null;
  source_candle_interval: CandleInterval | null;
  source_candle_start: string | null;
  data_status: DataStatus;
  reasons: string[];
  indicator_values: IndicatorValue[];
  invalidation_conditions: string[];
  explanation: string;
  risk_decision: RiskDecision;
  superseded_by: string | null;
  update_count: number;
  disclaimer: string;
  workspace_slug: string;
}

export type SizingMethod = "FIXED_QUANTITY" | "FIXED_AMOUNT" | "RISK_PERCENT";

export type SkipReason = "streaming_disabled" | "no_enabled_account" | "account_not_enabled" | "not_listed" | "unsupported";

export interface SkippedEntry {
  at: string;
  signal_type: SignalType;
  reason: string;
}

export type StopTargetSource = "SIGNAL" | "PERCENT" | "NONE";

export interface StrategyCompatibility {
  strategy_id: string;
  version: string;
  compatible: boolean;
  checks: CompatibilityCheck[];
  warmup: WarmupCoverage[];
}

export type StrategyRunStatus = "STARTING" | "RUNNING" | "CIRCUIT_OPEN" | "STOPPED" | "FAILED";

export interface StrategyView {
  strategy_id: string;
  name: string;
  description: string;
  author: string;
  version: string;
  is_example: boolean;
  is_available: boolean;
  can_emit_actionable: boolean;
  code_fingerprint: string;
  metadata: Record<string, unknown>;
  data_requirements: DataRequirement[];
  config_schema: Record<string, unknown>;
  default_config: Record<string, unknown>;
  deployments: number;
  enabled_deployments: number;
}

/** Health of one provider stream (one provider account connection or shard). */
export interface StreamHealth {
  provider: Provider;
  account_id: string | null;
  stream_id: string;
  state: ConnectionState;
  data_status: DataStatus;
  state_since: string;
  connected_since: string | null;
  last_message_at: string | null;
  last_event_at: string | null;
  last_heartbeat_at: string | null;
  events_received: number;
  events_per_second: number;
  malformed_events: number;
  dropped_events: number;
  duplicate_events: number;
  reconnect_count: number;
  subscribed_instruments: number;
  desired_instruments: number;
  source_latency_ms: number | null;
  processing_latency_ms: number | null;
  stale_seconds: number | null;
  last_error: string | null;
  auth_required: boolean;
  session_open: boolean | null;
  updated_at: string;
}

export type SubscriptionMode = "LTP" | "QUOTE" | "FULL";

export interface SyncStats {
  instruments_created: number;
  instruments_updated: number;
  instruments_renamed: number;
  instruments_activated: number;
  instruments_deactivated: number;
  mappings_created: number;
  mappings_updated: number;
  mappings_unchanged: number;
  mappings_moved: number;
  mappings_closed: number;
  mappings_held: number;
}

export interface SystemHealth {
  status: "ok" | "degraded" | "down";
  version: string;
  app_env: string;
  simulated_mode: boolean;
  flags: Record<string, boolean>;
  kill_switch: KillSwitchState | null;
  components: ComponentHealth[];
  workers: WorkerStatus[];
  feeds: StreamHealth[];
  accounts: AccountHealth[];
  alerts: Alert[];
  generated_at: string;
}

export interface TargetLevel {
  label: string;
  price: string;
}

export type TradeOutcome = "WIN" | "LOSS" | "BREAKEVEN";

/** How a backtest trades the signals. Fees are a percentage of each fill's value plus a fixed amount per order; slippage moves every fill against the trade by whole ticks. */
export interface TradeRules {
  sides: TradeSides;
  opposite_signal: OppositeSignal;
  fill: FillTiming;
  exit_check: ExitCheck;
  stop_target: StopTargetSource;
  stop_pct: string | null;
  target_pct: string | null;
  max_holding_candles: number | null;
  sizing: SizingMethod;
  quantity: number | null;
  amount: string | null;
  risk_pct: string | null;
  initial_capital: string;
  fee_pct_per_side: string;
  fee_per_order: string;
  slippage_ticks: number;
}

/** Trade rules to save with a configuration: the request form of ``TradeRules``, whose decimal amounts may be sent as numbers or strings. */
export interface TradeRulesBody {
  sides: TradeSides;
  opposite_signal: OppositeSignal;
  fill: FillTiming;
  exit_check: ExitCheck;
  stop_target: StopTargetSource;
  stop_pct?: number | string | null;
  target_pct?: number | string | null;
  max_holding_candles?: number | null;
  sizing: SizingMethod;
  quantity?: number | null;
  amount?: number | string | null;
  risk_pct?: number | string | null;
  initial_capital: number | string;
  fee_pct_per_side: number | string;
  fee_per_order: number | string;
  slippage_ticks: number;
}

export type TradeRulesSource = "CONFIGURATION" | "STRATEGY";

/** The trade rules a configuration's backtests use: its own when set, else the strategy's declared defaults. */
export interface TradeRulesView {
  deployment_id: string;
  effective: TradeRules | null;
  source: TradeRulesSource | null;
  configuration: Record<string, unknown> | null;
  strategy: TradeRules | null;
  problem: string | null;
}

export type TradeSides = "LONG_ONLY" | "SHORT_ONLY" | "BOTH";

export type UnderlyingKind = "INDEX" | "STOCK";

export interface Universe {
  workspace: WorkspaceView;
  entries: UniverseEntry[];
}

export interface UniverseAdd {
  instruments: string[];
  provider: Provider;
  account_id?: string | null;
  mode?: SubscriptionMode;
}

export interface UniverseChange {
  workspace: WorkspaceView;
  added: Instrument[];
  changed: PreviousSource[];
  unchanged: Instrument[];
  removed: Instrument[];
  absent: Instrument[];
  published: boolean | null;
}

export interface UniverseEntry {
  instrument: Instrument;
  provider: Provider;
  account: AccountRef | null;
  mode: SubscriptionMode;
  added_at: string;
  added_by: string | null;
  status: EntryStatus;
  streamed_by: AccountRef | null;
  skip_reason: SkipReason | null;
  detail: string | null;
}

export interface UniverseRemove {
  instruments: string[];
}

/** Which instruments a workspace takes, read from its settings. */
export interface UniverseRules {
  exchanges: Exchange[];
  segments: Segment[];
  instrument_types: InstrumentType[];
  underlying_kind: UnderlyingKind | null;
  index_underlyings: string[];
}

export interface ValidationError {
  loc: (string | number)[];
  msg: string;
  type: string;
  input: unknown;
  ctx: Record<string, unknown>;
}

/** How the provider reports volume. Cumulative snapshots must never be summed. */
export type VolumeSemantics = "CUMULATIVE_DAY" | "INCREMENTAL" | "UNAVAILABLE";

export interface WarmupCoverage {
  interval: CandleInterval;
  needed: number;
  stored: number;
}

export interface WatchlistCreate {
  name: string;
}

export interface WatchlistItemView {
  instrument: Instrument;
  sort_order: number;
  added_at: string;
  in_universe: boolean;
}

export interface WatchlistItems {
  instrument_ids: string[];
}

export interface WatchlistUpdate {
  name?: string | null;
  sort_order?: number | null;
}

export interface WatchlistView {
  id: string;
  workspace_id: string;
  workspace_slug: string;
  name: string;
  sort_order: number;
  items: WatchlistItemView[];
  created_at: string;
  updated_at: string;
}

export interface WorkerStatus {
  worker: string;
  alive: boolean;
  instance: string | null;
  version: string | null;
  started_at: string | null;
  heartbeat_at: string | null;
  details: Record<string, unknown>;
}

export type WorkspaceKind = "EQUITY_TRADING" | "INDEX_TRADING" | "INDEX_FUTURES" | "INDEX_OPTIONS" | "STOCK_FUTURES" | "STOCK_OPTIONS" | "LONG_TERM_INVESTING" | "FOREX_MAJOR_PAIRS" | "FOREX_MINOR_PAIRS" | "FOREX_OTHER_PAIRS" | "FOREX_SESSIONS" | "FOREX_ANALYTICS" | "FOREX_ECONOMIC_CALENDAR" | "CRYPTO_SPOT" | "CRYPTO_FUTURES" | "CRYPTO_PERPETUALS" | "CRYPTO_SCANNER" | "CRYPTO_FUNDING_RATES" | "CRYPTO_OPEN_INTEREST" | "CRYPTO_PORTFOLIO" | "SIMULATION_LAB";

export interface WorkspaceToggle {
  workspace: WorkspaceView;
  changed: boolean;
  published: boolean | null;
}

export interface WorkspaceView {
  id: string;
  slug: string;
  name: string;
  market_region: MarketRegion;
  kind: WorkspaceKind;
  description: string | null;
  is_enabled: boolean;
  sort_order: number;
  settings: Record<string, unknown>;
  accepts: UniverseRules;
  instrument_count: number;
  updated_at: string;
}

export interface ZerodhaLoginStart {
  account_id: string;
  login_url: string;
  redirect_url: string;
  expires_at: string;
}
