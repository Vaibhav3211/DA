import { describe, expect, it, vi } from "vitest";
import { ApiError, buildQuery, isUnauthorized, request } from "@/lib/api/client";

function reply(status: number, body = "", statusText = ""): Response {
  return { ok: status >= 200 && status < 300, status, statusText, text: () => Promise.resolve(body) } as Response;
}

describe("buildQuery", () => {
  it("drops empty values and repeats array values", () => {
    expect(
      buildQuery({
        market: "NSE",
        empty: "",
        none: null,
        missing: undefined,
        page: 0,
        open: false,
        status: ["ACTIVE", "UPDATED"],
      }),
    ).toBe("?market=NSE&page=0&open=false&status=ACTIVE&status=UPDATED");
    expect(buildQuery({ none: null })).toBe("");
    expect(buildQuery()).toBe("");
  });
});

describe("request", () => {
  it("sends JSON to the proxied API path with the session cookie", async () => {
    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(reply(200, '{"id":"ws-1"}'));
    vi.stubGlobal("fetch", fetchMock);
    await expect(request("POST", "/workspaces", { body: { name: "Nifty" }, query: { dry_run: true } })).resolves.toEqual({
      id: "ws-1",
    });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/workspaces?dry_run=true",
      expect.objectContaining({
        method: "POST",
        body: '{"name":"Nifty"}',
        credentials: "same-origin",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
      }),
    );
  });

  it("resolves an empty 204 response to undefined", async () => {
    vi.stubGlobal("fetch", vi.fn<typeof fetch>().mockResolvedValue(reply(204)));
    await expect(request("DELETE", "/workspaces/ws-1")).resolves.toBeUndefined();
  });

  it("raises the API's error envelope", async () => {
    const body = JSON.stringify({
      error: { code: "unauthenticated", message: "Sign in again", details: null, correlation_id: "req-1" },
    });
    vi.stubGlobal("fetch", vi.fn<typeof fetch>().mockResolvedValue(reply(401, body, "Unauthorized")));
    const error: unknown = await request("GET", "/auth/me").catch((caught: unknown) => caught);
    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ status: 401, code: "unauthenticated", message: "Sign in again", correlationId: "req-1" });
    expect(isUnauthorized(error)).toBe(true);
  });

  it("falls back to the status text when the body is not an error envelope", async () => {
    vi.stubGlobal("fetch", vi.fn<typeof fetch>().mockResolvedValue(reply(502, "<html>bad gateway</html>", "Bad Gateway")));
    await expect(request("GET", "/health")).rejects.toMatchObject({ status: 502, code: "http_502", message: "Bad Gateway" });
  });

  it("reports an unreachable API as a network error but passes an abort through", async () => {
    vi.stubGlobal("fetch", vi.fn<typeof fetch>().mockRejectedValue(new TypeError("Failed to fetch")));
    await expect(request("GET", "/health")).rejects.toMatchObject({ status: 0, code: "network_error" });

    const controller = new AbortController();
    controller.abort();
    const abort = new DOMException("The operation was aborted.", "AbortError");
    vi.stubGlobal("fetch", vi.fn<typeof fetch>().mockRejectedValue(abort));
    await expect(request("GET", "/health", { signal: controller.signal })).rejects.toBe(abort);
  });
});
