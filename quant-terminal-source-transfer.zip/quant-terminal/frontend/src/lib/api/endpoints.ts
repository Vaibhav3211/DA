// One typed function per REST route (see the backend's OpenAPI schema under /api/v1).

import { request } from "./client";
import type * as T from "./types.gen";

const seg = encodeURIComponent;

export const auth = {
  login: (body: T.LoginRequest) => request<T.SessionResponse>("POST", "/auth/login", { body }),
  logout: () => request<T.OkResponse>("POST", "/auth/logout"),
  me: () => request<T.SessionResponse>("GET", "/auth/me"),
};

export const providers = {
  list: () => request<T.ProviderSummary[]>("GET", "/providers"),
  get: (provider: T.Provider) => request<T.ProviderSummary>("GET", `/providers/${seg(provider)}`),
  capabilities: (provider: T.Provider, accountId?: string) =>
    request<T.ProviderCapabilities>("GET", `/providers/${seg(provider)}/capabilities`, {
      query: { account_id: accountId },
    }),
  /** Starts Kite's login redirect; the browser then goes to ``login_url``. */
  zerodhaConnect: (accountId: string) =>
    request<T.ZerodhaLoginStart>("POST", "/providers/zerodha/connect", { body: { account_id: accountId } }),
  growwConnect: (body: T.GrowwConnectRequest) =>
    request<T.ProviderAccountView>("POST", "/providers/groww/connect", { body }),
  disconnect: (provider: T.Provider, accountId: string) =>
    request<T.LogoutResult>("POST", `/providers/${seg(provider)}/disconnect`, { body: { account_id: accountId } }),
};

export const accounts = {
  list: (provider?: T.Provider) => request<T.ProviderAccountView[]>("GET", "/accounts", { query: { provider } }),
  create: (body: T.AccountCreate) => request<T.ProviderAccountView>("POST", "/accounts", { body }),
  update: (id: string, body: T.AccountUpdate) =>
    request<T.ProviderAccountView>("PATCH", `/accounts/${seg(id)}`, { body }),
  remove: (id: string) => request<void>("DELETE", `/accounts/${seg(id)}`),
  enable: (id: string) => request<T.ProviderAccountView>("POST", `/accounts/${seg(id)}/enable`),
  disable: (id: string) => request<T.ProviderAccountView>("POST", `/accounts/${seg(id)}/disable`),
  setCredentials: (id: string, values: T.CredentialsUpdate["values"]) =>
    request<T.ProviderAccountView>("PUT", `/accounts/${seg(id)}/credentials`, { body: { values } }),
  clearCredential: (id: string, kind?: T.CredentialKind) =>
    request<T.ProviderAccountView>("DELETE", `/accounts/${seg(id)}/credentials`, { query: { kind } }),
};

export interface InstrumentSearch {
  q?: string;
  exchange?: T.Exchange;
  segment?: T.Segment;
  instrument_type?: T.InstrumentType;
  underlying?: string;
  expiry?: string;
  option_type?: T.OptionType;
  provider?: T.Provider;
  include_inactive?: boolean;
  limit?: number;
  offset?: number;
}

export const instruments = {
  search: (params: InstrumentSearch, signal?: AbortSignal) =>
    request<T.InstrumentPage>("GET", "/instruments/search", { query: { ...params }, signal }),
  get: (ref: string) => request<T.InstrumentDetail>("GET", `/instruments/${seg(ref)}`),
  /** Downloads the provider's instrument dump: this contacts the provider. */
  refresh: (body: T.RefreshRequest) => request<T.RefreshReport>("POST", "/instruments/refresh", { body }),
};

export const markets = {
  overview: () => request<T.MarketOverview>("GET", "/markets"),
  /** Which markets the platform can serve now, and why the others cannot. */
  availability: () => request<T.MarketAvailability[]>("GET", "/markets/availability"),
};

export const workspaces = {
  list: () => request<T.WorkspaceView[]>("GET", "/workspaces"),
  universe: (ws: string) => request<T.Universe>("GET", `/workspaces/${seg(ws)}`),
  enable: (ws: string) => request<T.WorkspaceToggle>("POST", `/workspaces/${seg(ws)}/enable`),
  disable: (ws: string) => request<T.WorkspaceToggle>("POST", `/workspaces/${seg(ws)}/disable`),
  addInstruments: (ws: string, body: T.UniverseAdd) =>
    request<T.UniverseChange>("POST", `/workspaces/${seg(ws)}/instruments`, { body }),
  removeInstruments: (ws: string, instrumentRefs: string[]) =>
    request<T.UniverseChange>("POST", `/workspaces/${seg(ws)}/instruments/remove`, {
      body: { instruments: instrumentRefs } satisfies T.UniverseRemove,
    }),
  watchlists: (ws: string) => request<T.WatchlistView[]>("GET", `/workspaces/${seg(ws)}/watchlists`),
  createWatchlist: (ws: string, name: string) =>
    request<T.WatchlistView>("POST", `/workspaces/${seg(ws)}/watchlists`, { body: { name } }),
};

export const watchlists = {
  update: (id: string, body: T.WatchlistUpdate) =>
    request<T.WatchlistView>("PATCH", `/watchlists/${seg(id)}`, { body }),
  remove: (id: string) => request<void>("DELETE", `/watchlists/${seg(id)}`),
  setItems: (id: string, instrumentIds: string[]) =>
    request<T.WatchlistView>("PUT", `/watchlists/${seg(id)}/items`, { body: { instrument_ids: instrumentIds } }),
};

export const quotes = {
  latest: (params: { workspace?: string; instrument_id?: string[]; provider?: T.Provider }) =>
    request<T.QuoteList>("GET", "/quotes/latest", { query: { ...params } }),
};

export interface CandleQuery {
  instrument: string;
  provider: T.Provider;
  interval?: T.CandleInterval;
  limit?: number;
  until?: string;
  include_forming?: boolean;
}

export const candles = {
  series: (params: CandleQuery, signal?: AbortSignal) =>
    request<T.CandleSeries>("GET", "/candles", { query: { ...params }, signal }),
};

export interface RunQuery {
  workspace?: string;
  strategy_id?: string;
  deployment_id?: string;
  limit?: number;
}

export interface CompatibilityQuery {
  workspace: string;
  instrument_id: string;
  chart_interval?: T.CandleInterval;
}

export const strategies = {
  list: () => request<T.StrategyView[]>("GET", "/strategies"),
  get: (id: string) => request<T.StrategyView>("GET", `/strategies/${seg(id)}`),
  sync: () => request<T.CatalogueSync>("POST", "/strategies/sync"),
  runs: (params: RunQuery) => request<T.RunView[]>("GET", "/strategy-runs", { query: { ...params } }),
  /** How each strategy in the code suits one instrument of a workspace. */
  compatibility: (params: CompatibilityQuery) =>
    request<T.InstrumentCompatibility>("GET", "/strategy-compatibility", { query: { ...params } }),
};

export interface DeploymentFilters {
  workspace?: string;
  strategy_id?: string;
  /** Only configurations whose scope covers this instrument. */
  instrument_id?: string;
  include_archived?: boolean;
}

/** Saved strategy configurations. Saving one never starts live signals: only ``enable`` does. */
export const deployments = {
  list: (filters: DeploymentFilters = {}) =>
    request<T.DeploymentView[]>("GET", "/deployments", { query: { ...filters } }),
  get: (id: string) => request<T.DeploymentView>("GET", `/deployments/${seg(id)}`),
  create: (body: T.ConfigurationCreate) => request<T.DeploymentView>("POST", "/deployments", { body }),
  update: (id: string, body: T.ConfigurationUpdate) =>
    request<T.DeploymentView>("PATCH", `/deployments/${seg(id)}`, { body }),
  /** Starts live signals; asking again changes nothing. */
  enable: (id: string) => request<T.DeploymentView>("POST", `/deployments/${seg(id)}/enable`),
  disable: (id: string) => request<T.DeploymentView>("POST", `/deployments/${seg(id)}/disable`),
  archive: (id: string) => request<T.DeploymentView>("POST", `/deployments/${seg(id)}/archive`),
};

export interface SignalFilters {
  workspace?: string;
  strategy_id?: string;
  instrument?: string;
  deployment_id?: string;
  status?: T.SignalStatus;
  signal_type?: T.SignalType;
  open_only?: boolean;
  actionable?: boolean;
  since?: string;
  until?: string;
  limit?: number;
}

/** The signals one saved configuration produced for one instrument, for chart markers. */
export interface ChartSignalQuery {
  instrument: string;
  deployment_id: string;
  signal_type: readonly T.SignalType[];
  limit: number;
}

export const signals = {
  list: (filters: SignalFilters, cursor?: string | null) =>
    request<T.SignalPage>("GET", "/signals", { query: { ...filters, cursor } }),
  forChart: (params: ChartSignalQuery) => request<T.SignalPage>("GET", "/signals", { query: { ...params } }),
  get: (id: string) => request<T.SignalDetail>("GET", `/signals/${seg(id)}`),
};

export interface DatasetFilters {
  instrument?: string;
  interval?: T.CandleInterval;
  status?: T.DatasetStatus;
  limit?: number;
  offset?: number;
}

/** Stored candle history for backtests. Requesting one queues it for the backtest worker. */
export const datasets = {
  /** Where the instrument's datasets can come from, and why a source cannot supply one. */
  sources: (instrument: string) => request<T.DatasetSources>("GET", "/datasets/sources", { query: { instrument } }),
  /** Asking again while the same dataset waits or builds returns that one. */
  request: (body: T.DatasetRequest) => request<T.DatasetRequestResult>("POST", "/datasets", { body }),
  list: (filters: DatasetFilters) => request<T.DatasetView[]>("GET", "/datasets", { query: { ...filters } }),
  get: (id: string) => request<T.DatasetView>("GET", `/datasets/${seg(id)}`),
};

export interface BacktestFilters {
  deployment_id?: string;
  instrument?: string;
  status?: T.BacktestStatus;
  limit?: number;
  offset?: number;
}

/** Backtests replay a saved configuration over a dataset. Reading a result never runs one: only ``queue`` does. */
export const backtests = {
  rules: (deploymentId: string) =>
    request<T.TradeRulesView>("GET", `/deployments/${seg(deploymentId)}/backtest-rules`),
  setRules: (deploymentId: string, body: T.TradeRulesBody) =>
    request<T.TradeRulesView>("PUT", `/deployments/${seg(deploymentId)}/backtest-rules`, { body }),
  clearRules: (deploymentId: string) =>
    request<T.TradeRulesView>("DELETE", `/deployments/${seg(deploymentId)}/backtest-rules`),
  /** Asking again while the same backtest waits, runs or has succeeded returns that one. */
  queue: (body: T.BacktestRequest) => request<T.BacktestQueueResult>("POST", "/backtests", { body }),
  list: (filters: BacktestFilters) => request<T.BacktestRunView[]>("GET", "/backtests", { query: { ...filters } }),
  latest: (deploymentId: string, instrument: string) =>
    request<T.BacktestLatest>("GET", "/backtests/latest", { query: { deployment_id: deploymentId, instrument } }),
  get: (id: string) => request<T.BacktestDetail>("GET", `/backtests/${seg(id)}`),
  trades: (id: string, offset: number, limit: number) =>
    request<T.BacktestTradesPage>("GET", `/backtests/${seg(id)}/trades`, { query: { offset, limit } }),
};

export const WORKSPACE_PAUSE = "workspace_pause";

export const risk = {
  rules: (workspace?: string) => request<T.RiskRuleView[]>("GET", "/risk/rules", { query: { workspace } }),
  setRule: (key: string, body: T.RuleUpdate, workspace?: string) =>
    request<T.RiskRuleView>("PUT", `/risk/rules/${seg(key)}`, { body, query: { workspace } }),
  resetRule: (key: string, workspace?: string) =>
    request<T.RiskRuleView>("POST", `/risk/rules/${seg(key)}/reset`, { query: { workspace } }),
  pause: (ws: string, reason?: string) =>
    request<T.RiskRuleView>("POST", `/risk/workspaces/${seg(ws)}/pause`, {
      body: { reason: reason || null } satisfies T.PauseRequest,
    }),
  resume: (ws: string) => request<T.RiskRuleView>("POST", `/risk/workspaces/${seg(ws)}/resume`),
};

export const system = {
  health: () => request<T.SystemHealth>("GET", "/system/health"),
  metrics: () => request<T.MetricsSummary>("GET", "/system/metrics"),
  killSwitch: () => request<T.KillSwitchState>("GET", "/system/kill-switch"),
  setKillSwitch: (body: T.KillSwitchUpdate) => request<T.KillSwitchState>("PUT", "/system/kill-switch", { body }),
};
