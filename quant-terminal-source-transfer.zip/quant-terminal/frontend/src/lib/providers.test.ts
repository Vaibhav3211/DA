import { describe, expect, it } from "vitest";
import {
  credentialRows,
  filledCredentials,
  growwConnectBody,
  growwModes,
  isTotpCode,
  labelError,
  tokenSecondsLeft,
  zerodhaCallbackUrl,
  zerodhaReturn,
} from "@/lib/providers";

describe("credentialRows", () => {
  it("shows the credentials a sign-in method needs", () => {
    const rows = credentialRows({ provider: "ZERODHA", auth_method: "ZERODHA_LOGIN_REDIRECT", credentials: [] });
    expect(rows.map((row) => [row.kind, row.label, row.required])).toEqual([
      ["API_KEY", "API key", true],
      ["API_SECRET", "API secret", true],
    ]);
    expect(credentialRows({ provider: "GROWW", auth_method: "GROWW_ACCESS_TOKEN", credentials: [] })).toEqual([]);
  });

  it("keeps showing a stored credential the method does not use", () => {
    expect(
      credentialRows({
        provider: "GROWW",
        auth_method: "GROWW_TOTP",
        credentials: [{ kind: "API_SECRET", label: "API secret", origin: "ACCOUNT", masked: "****3f" }],
      }),
    ).toEqual([
      { kind: "API_KEY", label: "TOTP token (API key)", required: true, used: true, origin: null, masked: null },
      { kind: "API_SECRET", label: "API secret", required: false, used: false, origin: "ACCOUNT", masked: "****3f" },
      { kind: "TOTP_SECRET", label: "TOTP secret", required: false, used: true, origin: null, masked: null },
    ]);
  });
});

describe("account form rules", () => {
  it("sends only filled, storable credentials, trimmed", () => {
    expect(filledCredentials({ API_KEY: " key ", API_SECRET: "   ", ACCESS_TOKEN: "token" })).toEqual({ API_KEY: "key" });
  });

  it("validates labels after collapsing spaces", () => {
    expect(labelError("   ")).toBe("Enter a label");
    expect(labelError("  Main   account ")).toBeNull();
    expect(labelError("-main")).toMatch(/starting with a letter or digit/);
    expect(labelError("a".repeat(81))).toMatch(/1-80/);
  });

  it("counts token time left, negative once expired", () => {
    const now = Date.parse("2025-01-01T00:00:00Z");
    expect(tokenSecondsLeft({ has_access_token: true, token_expires_at: "2025-01-01T01:00:00Z" }, now)).toBe(3600);
    expect(tokenSecondsLeft({ has_access_token: true, token_expires_at: "2024-12-31T23:59:00Z" }, now)).toBe(-60);
    expect(tokenSecondsLeft({ has_access_token: false, token_expires_at: null }, now)).toBeNull();
  });
});

describe("Groww sign-in", () => {
  it("offers only the ways to get a token that the account supports", () => {
    const totpSecret = { kind: "TOTP_SECRET" as const, label: "TOTP secret", origin: "ACCOUNT" as const, masked: null };
    expect(growwModes({ auth_method: "GROWW_API_KEY_SECRET", credentials: [] })).toEqual(["create", "token"]);
    expect(growwModes({ auth_method: "GROWW_TOTP", credentials: [] })).toEqual(["code", "token"]);
    expect(growwModes({ auth_method: "GROWW_TOTP", credentials: [totpSecret] })).toEqual(["create", "code", "token"]);
    expect(growwModes({ auth_method: "GROWW_ACCESS_TOKEN", credentials: [] })).toEqual(["token"]);
  });

  it("sends exactly one of the token or the code", () => {
    expect(growwConnectBody("acc-1", "token", "  eyJ.abc  ")).toEqual({ account_id: "acc-1", access_token: "eyJ.abc" });
    expect(growwConnectBody("acc-1", "code", "123 456")).toEqual({ account_id: "acc-1", totp_code: "123456" });
    expect(growwConnectBody("acc-1", "create", "ignored")).toEqual({ account_id: "acc-1" });
    expect(isTotpCode("123 456")).toBe(true);
    expect(isTotpCode("12345")).toBe(false);
    expect(isTotpCode("12a456")).toBe(false);
  });
});

describe("Kite sign-in", () => {
  it("builds the redirect URL the Kite app must be configured with", () => {
    expect(zerodhaCallbackUrl("http://localhost:3000/")).toBe("http://localhost:3000/api/v1/providers/zerodha/callback");
  });

  it("reads the outcome the callback passes back", () => {
    const read = (query: string) => zerodhaReturn(new URLSearchParams(query));
    expect(read("zerodha=connected&account_id=acc-1")).toEqual({ ok: true, accountId: "acc-1" });
    expect(read("zerodha=error&code=login_state_invalid")).toEqual({
      ok: false,
      code: "login_state_invalid",
      message: "That login has expired or was already used. Start the Kite login again.",
    });
    expect(read("zerodha=error")).toEqual({
      ok: false,
      code: "unknown",
      message: "Kite sign-in failed (unknown). Start the Kite login again.",
    });
    expect(read("tab=accounts")).toBeNull();
  });
});
