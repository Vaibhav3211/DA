// One reconnecting WebSocket to the live API. It remembers the subscriptions made on it and sends
// them again after every (re)connect, once the server's welcome frame has arrived.

import {
  CLOSE_UNAUTHENTICATED,
  DEFAULT_RECONNECT,
  parseFrame,
  subscribeMessage,
  type Channel,
  type ReconnectGuidance,
  type ServerFrame,
  type Subscription,
} from "./protocol";

export type SocketStatus = "idle" | "connecting" | "open" | "reconnecting" | "closed" | "unauthorized";

export interface LiveSocketOptions {
  url: () => string;
  onFrame: (frame: ServerFrame) => void;
  onStatus?: (status: SocketStatus) => void;
  /** Called after a connection is re-established: anything pushed meanwhile was missed. */
  onReconnect?: () => void;
  onUnauthorized?: () => void;
  createSocket?: (url: string) => WebSocket;
  random?: () => number;
}

const OPEN = 1;
const WATCHDOG_CLOSE = 4000;
const DEFAULT_HEARTBEAT_SECONDS = 15;

/** Exponential backoff with jitter: half to all of ``initial * 2^attempt``, capped at the maximum. */
export function backoffDelayMs(attempt: number, guidance: ReconnectGuidance, random: () => number): number {
  const base = Math.min(guidance.max_delay_seconds, guidance.initial_delay_seconds * 2 ** attempt);
  return base * (0.5 + random() * 0.5) * 1000;
}

export class LiveSocket {
  private readonly options: LiveSocketOptions;
  private readonly subscriptions = new Map<Channel, Subscription>();
  private socket: WebSocket | null = null;
  private status: SocketStatus = "idle";
  private running = false;
  private welcomed = false;
  private connectedBefore = false;
  private attempt = 0;
  private requests = 0;
  private guidance: ReconnectGuidance = DEFAULT_RECONNECT;
  private heartbeatSeconds = DEFAULT_HEARTBEAT_SECONDS;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private watchdogTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(options: LiveSocketOptions) {
    this.options = options;
  }

  getStatus(): SocketStatus {
    return this.status;
  }

  start(): void {
    if (this.running) return;
    this.running = true;
    this.attempt = 0;
    this.connect();
  }

  stop(): void {
    this.running = false;
    this.clearTimers();
    this.discardSocket(1000, "client stopped");
    this.setStatus("closed");
  }

  /** Reconnects at once instead of waiting for the backoff, e.g. when the browser comes back online. */
  retryNow(): void {
    if (this.socket !== null) return;
    this.running = true;
    this.attempt = 0;
    this.connect();
  }

  /** Replaces this connection's subscription to the channel. */
  subscribe(subscription: Subscription): void {
    this.subscriptions.set(subscription.channel, subscription);
    if (this.welcomed) this.sendSubscribe(subscription);
  }

  unsubscribe(channel: Channel): void {
    if (!this.subscriptions.delete(channel)) return;
    if (this.welcomed) this.send({ action: "unsubscribe", channel, request_id: this.nextRequestId(channel) });
  }

  /** Subscribes again with the same options, so the server re-reads them (e.g. after a universe edit). */
  resubscribe(channel: Channel): void {
    const subscription = this.subscriptions.get(channel);
    if (subscription && this.welcomed) this.sendSubscribe(subscription);
  }

  private connect(): void {
    this.clearTimers();
    this.discardSocket(1000, "reconnecting");
    this.welcomed = false;
    this.setStatus(this.connectedBefore ? "reconnecting" : "connecting");
    let socket: WebSocket;
    try {
      socket = (this.options.createSocket ?? ((url: string) => new WebSocket(url)))(this.options.url());
    } catch {
      this.scheduleReconnect();
      return;
    }
    this.socket = socket;
    socket.onopen = () => {
      if (socket === this.socket) this.armWatchdog();
    };
    socket.onmessage = (event: MessageEvent) => {
      if (socket !== this.socket) return;
      this.armWatchdog();
      if (typeof event.data === "string") this.handleText(event.data);
    };
    socket.onclose = (event: CloseEvent) => {
      if (socket === this.socket) this.handleClose(event.code);
    };
    // A close event always follows an error; reconnecting is handled there.
    socket.onerror = () => undefined;
  }

  private handleText(text: string): void {
    const frame = parseFrame(text);
    if (frame === null) return;
    if (frame.type === "welcome") {
      this.guidance = frame.reconnect ?? DEFAULT_RECONNECT;
      this.heartbeatSeconds = frame.heartbeat_interval_seconds || DEFAULT_HEARTBEAT_SECONDS;
      this.welcomed = true;
      this.attempt = 0;
      this.armWatchdog();
      this.setStatus("open");
      for (const subscription of this.subscriptions.values()) this.sendSubscribe(subscription);
      const reconnected = this.connectedBefore;
      this.connectedBefore = true;
      this.options.onFrame(frame);
      if (reconnected) this.options.onReconnect?.();
      return;
    }
    this.options.onFrame(frame);
  }

  private handleClose(code: number): void {
    this.socket = null;
    this.welcomed = false;
    this.clearTimers();
    if (!this.running) {
      this.setStatus("closed");
    } else if (code === CLOSE_UNAUTHENTICATED) {
      this.running = false;
      this.setStatus("unauthorized");
      this.options.onUnauthorized?.();
    } else if (this.guidance.final_close_codes.includes(code)) {
      this.running = false;
      this.setStatus("closed");
    } else {
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect(): void {
    if (!this.running) return;
    const delay = backoffDelayMs(this.attempt, this.guidance, this.options.random ?? Math.random);
    this.attempt += 1;
    this.setStatus("reconnecting");
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, delay);
  }

  /** Server heartbeats arrive every interval; three missed ones mean the connection is dead. */
  private armWatchdog(): void {
    if (this.watchdogTimer !== null) clearTimeout(this.watchdogTimer);
    this.watchdogTimer = setTimeout(() => {
      this.watchdogTimer = null;
      this.discardSocket(WATCHDOG_CLOSE, "heartbeat timeout");
      this.welcomed = false;
      this.scheduleReconnect();
    }, this.heartbeatSeconds * 3000);
  }

  private discardSocket(code: number, reason: string): void {
    const socket = this.socket;
    this.socket = null;
    if (socket === null) return;
    socket.onopen = null;
    socket.onmessage = null;
    socket.onclose = null;
    socket.onerror = null;
    try {
      socket.close(code, reason);
    } catch {
      // already closing
    }
  }

  private clearTimers(): void {
    if (this.reconnectTimer !== null) clearTimeout(this.reconnectTimer);
    if (this.watchdogTimer !== null) clearTimeout(this.watchdogTimer);
    this.reconnectTimer = null;
    this.watchdogTimer = null;
  }

  private sendSubscribe(subscription: Subscription): void {
    this.send(subscribeMessage(subscription, this.nextRequestId(subscription.channel)));
  }

  private nextRequestId(channel: Channel): string {
    this.requests += 1;
    return `${channel}.${this.requests}`;
  }

  private send(message: Record<string, unknown>): void {
    if (this.socket !== null && this.socket.readyState === OPEN) this.socket.send(JSON.stringify(message));
  }

  private setStatus(status: SocketStatus): void {
    if (status === this.status) return;
    this.status = status;
    this.options.onStatus?.(status);
  }
}
