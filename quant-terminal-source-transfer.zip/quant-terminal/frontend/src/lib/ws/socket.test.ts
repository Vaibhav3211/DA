import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { channelOf, DEFAULT_RECONNECT, parseFrame, type ServerFrame, type WelcomeFrame } from "@/lib/ws/protocol";
import { backoffDelayMs, LiveSocket, type SocketStatus } from "@/lib/ws/socket";

/** The parts of a browser WebSocket that LiveSocket uses, driven by the test. */
class FakeSocket {
  readyState = 0;
  onopen: (() => void) | null = null;
  onmessage: ((event: MessageEvent) => void) | null = null;
  onclose: ((event: CloseEvent) => void) | null = null;
  onerror: (() => void) | null = null;
  readonly url: string;
  readonly sent: unknown[] = [];
  closedWith: number | null = null;

  constructor(url: string) {
    this.url = url;
  }

  send(data: string): void {
    this.sent.push(JSON.parse(data));
  }

  close(code?: number): void {
    this.closedWith = code ?? null;
    this.readyState = 3;
  }

  open(): void {
    this.readyState = 1;
    this.onopen?.();
  }

  receive(frame: ServerFrame): void {
    this.onmessage?.({ data: JSON.stringify(frame) } as MessageEvent);
  }

  drop(code: number): void {
    this.readyState = 3;
    this.onclose?.({ code } as CloseEvent);
  }
}

function welcome(heartbeatSeconds = 15): WelcomeFrame {
  return {
    type: "welcome",
    connection_id: "connection-1",
    channels: ["quotes", "candles", "feed", "signals", "system"],
    server_time: "2025-01-01T03:45:00Z",
    heartbeat_interval_seconds: heartbeatSeconds,
    max_updates_per_second: 20,
    stale_after_seconds: 30,
    max_instruments: 200,
    reconnect: DEFAULT_RECONNECT,
  };
}

function setup() {
  const sockets: FakeSocket[] = [];
  const statuses: SocketStatus[] = [];
  const frames: ServerFrame[] = [];
  const onReconnect = vi.fn();
  const onUnauthorized = vi.fn();
  const live = new LiveSocket({
    url: () => "ws://localhost:8000/ws/market",
    onFrame: (frame) => frames.push(frame),
    onStatus: (status) => statuses.push(status),
    onReconnect,
    onUnauthorized,
    createSocket: (url) => {
      const socket = new FakeSocket(url);
      sockets.push(socket);
      return socket as unknown as WebSocket;
    },
    // No jitter: every delay is half of the backoff step.
    random: () => 0,
  });
  const latest = (): FakeSocket => {
    const socket = sockets.at(-1);
    if (socket === undefined) throw new Error("No socket was created");
    return socket;
  };
  return { live, sockets, statuses, frames, onReconnect, onUnauthorized, latest };
}

beforeEach(() => {
  vi.useFakeTimers();
});

afterEach(() => {
  vi.useRealTimers();
});

describe("LiveSocket", () => {
  it("subscribes only once the server has welcomed the connection", () => {
    const { live, statuses, frames, latest } = setup();
    live.subscribe({ channel: "quotes", workspace_id: "ws-1", instrument_ids: [] });
    live.start();
    const socket = latest();
    expect(socket.url).toBe("ws://localhost:8000/ws/market");
    socket.open();
    expect(socket.sent).toEqual([]);
    socket.receive(welcome());
    expect(socket.sent).toEqual([{ action: "subscribe", request_id: "quotes.1", channel: "quotes", workspace_id: "ws-1" }]);
    expect(statuses).toEqual(["connecting", "open"]);
    expect(frames.map((frame) => frame.type)).toEqual(["welcome"]);
  });

  it("reconnects with backoff, subscribes again and reports the reconnect", () => {
    const { live, sockets, statuses, onReconnect, latest } = setup();
    live.subscribe({ channel: "signals", workspace_id: "ws-1" });
    live.start();
    latest().open();
    latest().receive(welcome());
    expect(onReconnect).not.toHaveBeenCalled();

    latest().drop(1006);
    expect(statuses.at(-1)).toBe("reconnecting");
    vi.advanceTimersByTime(499);
    expect(sockets).toHaveLength(1);
    vi.advanceTimersByTime(1);
    expect(sockets).toHaveLength(2);

    latest().open();
    latest().receive(welcome());
    expect(latest().sent).toEqual([
      { action: "subscribe", request_id: "signals.2", channel: "signals", workspace_id: "ws-1" },
    ]);
    expect(onReconnect).toHaveBeenCalledTimes(1);
    expect(statuses).toEqual(["connecting", "open", "reconnecting", "open"]);
  });

  it("sends new subscriptions and unsubscribes on an open connection", () => {
    const { live, latest } = setup();
    live.start();
    latest().open();
    latest().receive(welcome());
    live.subscribe({ channel: "candles", instrument_ids: ["inst-1"], interval: "5m" });
    live.unsubscribe("candles");
    live.unsubscribe("candles");
    expect(latest().sent).toEqual([
      { action: "subscribe", request_id: "candles.1", channel: "candles", instrument_ids: ["inst-1"], interval: "5m" },
      { action: "unsubscribe", channel: "candles", request_id: "candles.2" },
    ]);
  });

  it("treats three missed heartbeats as a dead connection", () => {
    const { live, sockets, statuses, latest } = setup();
    live.start();
    const first = latest();
    first.open();
    first.receive(welcome(5));
    vi.advanceTimersByTime(14_999);
    expect(first.closedWith).toBeNull();
    vi.advanceTimersByTime(1);
    expect(first.closedWith).toBe(4000);
    expect(statuses.at(-1)).toBe("reconnecting");
    vi.advanceTimersByTime(500);
    expect(sockets).toHaveLength(2);
  });

  it("stops for good when the server rejects the session", () => {
    const { live, sockets, statuses, onUnauthorized, latest } = setup();
    live.start();
    latest().open();
    latest().drop(4401);
    vi.advanceTimersByTime(60_000);
    expect(sockets).toHaveLength(1);
    expect(statuses.at(-1)).toBe("unauthorized");
    expect(onUnauthorized).toHaveBeenCalledTimes(1);
  });

  it("does not retry a final close code", () => {
    const { live, sockets, latest } = setup();
    live.start();
    latest().open();
    latest().drop(1008);
    vi.advanceTimersByTime(60_000);
    expect(sockets).toHaveLength(1);
    expect(live.getStatus()).toBe("closed");
  });

  it("closes cleanly when stopped", () => {
    const { live, sockets, latest } = setup();
    live.start();
    latest().open();
    live.stop();
    vi.advanceTimersByTime(60_000);
    expect(latest().closedWith).toBe(1000);
    expect(sockets).toHaveLength(1);
    expect(live.getStatus()).toBe("closed");
  });
});

describe("protocol helpers", () => {
  it("backs off exponentially with jitter, up to the maximum", () => {
    expect(backoffDelayMs(0, DEFAULT_RECONNECT, () => 0)).toBe(500);
    expect(backoffDelayMs(3, DEFAULT_RECONNECT, () => 1)).toBe(8000);
    expect(backoffDelayMs(10, DEFAULT_RECONNECT, () => 0.5)).toBe(22_500);
  });

  it("ignores frames that are not JSON objects with a type", () => {
    expect(parseFrame("not json")).toBeNull();
    expect(parseFrame('{"channel":"quotes"}')).toBeNull();
    expect(parseFrame('{"type":"heartbeat","server_time":"t","request_id":null}')).toEqual({
      type: "heartbeat",
      server_time: "t",
      request_id: null,
    });
  });

  it("reads the channel back from a request id", () => {
    expect(channelOf("candles.3")).toBe("candles");
    expect(channelOf("orders.1")).toBeNull();
    expect(channelOf(null)).toBeNull();
  });
});
