// The live WebSocket protocol (backend app/api/ws). REST and WebSocket share the generated models.

import type {
  Candle,
  CandleInterval,
  DataStatus,
  FeedStateChange,
  MarketDepth,
  Provider,
  QuoteView,
  Signal,
  SignalEventType,
  StreamHealth,
  SystemHealth,
} from "@/lib/api/types.gen";

export type Channel = "quotes" | "candles" | "feed" | "signals" | "system";

// Each subscription carries only the options its channel takes: the server rejects any other.
export interface QuotesSubscription {
  channel: "quotes";
  workspace_id?: string;
  instrument_ids?: string[];
  provider?: Provider;
  depth?: boolean;
}

export interface CandlesSubscription {
  channel: "candles";
  workspace_id?: string;
  instrument_ids?: string[];
  provider?: Provider;
  interval: CandleInterval;
}

export interface FeedSubscription {
  channel: "feed";
  provider?: Provider;
}

export interface SignalsSubscription {
  channel: "signals";
  workspace_id?: string;
  instrument_ids?: string[];
}

export interface SystemSubscription {
  channel: "system";
}

export type Subscription =
  | QuotesSubscription
  | CandlesSubscription
  | FeedSubscription
  | SignalsSubscription
  | SystemSubscription;

/** A quote as streamed: ``market_depth`` is only present on subscriptions with ``depth``. */
export type LiveQuote = Omit<QuoteView, "market_depth"> & { market_depth?: MarketDepth | null };

export interface ReconnectGuidance {
  retry_close_codes: number[];
  final_close_codes: number[];
  initial_delay_seconds: number;
  max_delay_seconds: number;
  advice?: string;
}

export interface WelcomeFrame {
  type: "welcome";
  connection_id: string;
  channels: Channel[];
  server_time: string;
  heartbeat_interval_seconds: number;
  max_updates_per_second: number;
  stale_after_seconds: number;
  max_instruments: number;
  reconnect: ReconnectGuidance;
}

export interface ErrorFrame {
  type: "error";
  code: string;
  message: string;
  details: unknown;
  request_id: string | null;
}

export interface SignalUpdateFrame {
  type: "signal.update";
  event_type: SignalEventType;
  at: string;
  signal: Signal;
}

export type FeedStateChangeFrame = { type: "feed.state_change" } & FeedStateChange;

export type ServerFrame =
  | WelcomeFrame
  | ErrorFrame
  | SignalUpdateFrame
  | FeedStateChangeFrame
  | {
      type: "subscribed";
      channel: Channel;
      request_id: string | null;
      workspace: { id: string; slug: string } | null;
      instrument_ids: string[];
      provider: Provider | null;
      interval: CandleInterval | null;
      depth: boolean;
    }
  | { type: "unsubscribed"; channel: Channel; request_id: string | null }
  | { type: "heartbeat"; server_time: string; request_id: string | null }
  | { type: "quote.snapshot"; items: LiveQuote[]; missing: string[]; generated_at: string; request_id: string | null }
  | { type: "quote.update"; items: LiveQuote[] }
  | {
      type: "candle.snapshot";
      items: Candle[];
      interval: CandleInterval;
      generated_at: string;
      request_id: string | null;
    }
  | { type: "candle.update"; items: Candle[] }
  | { type: "candle.closed"; candle: Candle }
  | {
      type: "feed.status";
      streams: StreamHealth[];
      providers: Partial<Record<Provider, DataStatus>>;
      generated_at: string;
    }
  | { type: "system.status"; health: SystemHealth };

// Used until the welcome frame brings the server's own guidance.
export const DEFAULT_RECONNECT: ReconnectGuidance = {
  retry_close_codes: [1001, 1006, 1011, 1012, 1013],
  final_close_codes: [1003, 1008, 4401],
  initial_delay_seconds: 1,
  max_delay_seconds: 30,
};

export const CLOSE_UNAUTHENTICATED = 4401;

export function subscribeMessage(subscription: Subscription, requestId: string): Record<string, unknown> {
  const message: Record<string, unknown> = { action: "subscribe", request_id: requestId };
  for (const [key, value] of Object.entries(subscription)) {
    if (value === undefined || value === null || (Array.isArray(value) && value.length === 0)) continue;
    message[key] = value;
  }
  return message;
}

export function parseFrame(text: string): ServerFrame | null {
  try {
    const frame: unknown = JSON.parse(text);
    if (typeof frame === "object" && frame !== null && typeof (frame as { type?: unknown }).type === "string") {
      return frame as ServerFrame;
    }
  } catch {
    // not JSON: ignored, the server only sends JSON text frames
  }
  return null;
}

/** The channel a request id was minted for (``<channel>.<n>``). */
export function channelOf(requestId: string | null | undefined): Channel | null {
  const channel = requestId?.split(".", 1)[0];
  return channel === "quotes" ||
    channel === "candles" ||
    channel === "feed" ||
    channel === "signals" ||
    channel === "system"
    ? channel
    : null;
}
