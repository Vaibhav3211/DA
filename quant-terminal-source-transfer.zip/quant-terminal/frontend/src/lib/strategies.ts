// Readers for strategy plugin metadata, which the API passes through as a loose JSON object.

import type { CatalogueSync, DeploymentView, StrategyCompatibility } from "@/lib/api/types.gen";
import type { SchemaField } from "@/lib/schema-form";

export interface IndicatorNeed {
  alias: string;
  indicator: string;
  interval: string;
  params: Record<string, unknown>;
}

/** When a strategy proposes one signal type, and the inputs that decide it. */
export interface SignalConditionInfo {
  signalType: string;
  description: string;
  inputs: string[];
}

/** What a strategy needs from the platform, as its plugin metadata declares. */
export interface StrategyRequirements {
  markets: string[];
  /** Empty: every exchange of the markets. */
  exchanges: string[];
  segments: string[];
  instrumentTypes: string[];
  /** Empty: every matching instrument. */
  instrumentKeys: string[];
  eventTypes: string[];
  candleIntervals: string[];
  indicators: IndicatorNeed[];
  warmupCandles: number;
  requiredData: string[];
  signalConditions: SignalConditionInfo[];
  usesPartialCandles: boolean;
  resourceProfile: string | null;
  riskProfile: string | null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function strings(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
}

function text(value: unknown): string | null {
  return typeof value === "string" && value !== "" ? value : null;
}

/** The requirements in ``metadata``; missing or malformed fields read as empty. */
export function strategyRequirements(metadata: Record<string, unknown>): StrategyRequirements {
  const indicators: IndicatorNeed[] = Array.isArray(metadata.indicators)
    ? metadata.indicators.filter(isRecord).flatMap((item) => {
        const indicator = text(item.indicator);
        if (indicator === null) return [];
        return [
          {
            alias: text(item.alias) ?? indicator,
            indicator,
            interval: text(item.interval) ?? "",
            params: isRecord(item.params) ? item.params : {},
          },
        ];
      })
    : [];
  const warmup = metadata.warmup_candles;
  const signalConditions: SignalConditionInfo[] = Array.isArray(metadata.signal_conditions)
    ? metadata.signal_conditions.filter(isRecord).flatMap((item) => {
        const signalType = text(item.signal_type);
        if (signalType === null) return [];
        return [{ signalType, description: text(item.description) ?? "", inputs: strings(item.inputs) }];
      })
    : [];
  return {
    markets: strings(metadata.markets),
    exchanges: strings(metadata.exchanges),
    segments: strings(metadata.segments),
    instrumentTypes: strings(metadata.instrument_types),
    instrumentKeys: strings(metadata.instrument_keys),
    eventTypes: strings(metadata.event_types),
    candleIntervals: strings(metadata.candle_intervals),
    indicators,
    warmupCandles: typeof warmup === "number" && Number.isFinite(warmup) && warmup > 0 ? Math.floor(warmup) : 0,
    requiredData: strings(metadata.required_data),
    signalConditions,
    usesPartialCandles: metadata.uses_partial_candles === true,
    resourceProfile: text(metadata.resource_profile),
    riskProfile: text(metadata.risk_profile),
  };
}

/** ``period=14, source="close"``: an indicator's parameters on one line. */
export function formatParams(params: Record<string, unknown>): string {
  return Object.entries(params)
    .map(([key, value]) => `${key}=${JSON.stringify(value) ?? String(value)}`)
    .join(", ");
}

/** Whether a strategy supports a workspace's market; one that declares no markets supports none. */
export function supportsMarket(requirements: Pick<StrategyRequirements, "markets">, market: string): boolean {
  return requirements.markets.includes(market);
}

/** One line describing what a catalogue sync changed. */
export function syncSummary(result: CatalogueSync): string {
  const groups: [string, string[]][] = [
    ["added", result.added],
    ["restored", result.restored],
    ["upgraded", result.upgraded],
    ["code changed without a version bump", result.code_changed],
    ["no longer in the code", result.unavailable],
  ];
  const parts = groups.filter(([, ids]) => ids.length > 0).map(([label, ids]) => `${label}: ${ids.join(", ")}`);
  return parts.length > 0 ? `${parts.join("; ")}.` : "The catalogue already matches the code.";
}

/** The values a setting accepts beyond its type, such as ``≥ 2, ≤ 200`` or ``"ema" | "sma"``. */
export function fieldConstraint(field: SchemaField): string {
  const parts: (string | null)[] =
    field.kind === "enum"
      ? [field.options.map((option) => JSON.stringify(option)).join(" | ")]
      : [
          field.minimum === null ? null : `≥ ${field.minimum}`,
          field.exclusiveMinimum === null ? null : `> ${field.exclusiveMinimum}`,
          field.maximum === null ? null : `≤ ${field.maximum}`,
          field.exclusiveMaximum === null ? null : `< ${field.exclusiveMaximum}`,
        ];
  if (field.nullable) parts.push("or null");
  return parts.filter((part): part is string => part !== null && part !== "").join(", ");
}

/** A configuration value for display: strings as they are, anything else as JSON. */
export function formatConfigValue(value: unknown): string {
  if (value === undefined) return "—";
  if (typeof value === "string") return value;
  return JSON.stringify(value) ?? String(value);
}

export interface ScopeContext {
  /** The instrument the reader is looking at, such as the chart's. */
  instrumentId?: string | null;
  /** An instrument's symbol, when known. */
  symbolOf?: (instrumentId: string) => string | null | undefined;
}

const LISTED_SYMBOLS = 3;

/** What a saved configuration watches, in a few words. */
export function scopeSummary(
  deployment: Pick<DeploymentView, "scope_kind" | "instrument_ids">,
  context: ScopeContext = {},
): string {
  if (deployment.scope_kind === "WORKSPACE") return "Whole workspace";
  const ids = deployment.instrument_ids;
  if (ids.length === 0) return "No instruments";
  const focus = context.instrumentId ?? null;
  if (focus !== null && ids.includes(focus)) {
    return ids.length === 1 ? "This instrument" : `This instrument and ${ids.length - 1} more`;
  }
  const symbols = ids.map((id) => context.symbolOf?.(id) ?? null);
  if (ids.length <= LISTED_SYMBOLS && symbols.every((symbol) => symbol !== null)) return symbols.join(", ");
  return `${ids.length} instruments`;
}

export interface Verdict {
  label: "Compatible" | "Compatible with warnings" | "Not compatible";
  tone: "success" | "warning" | "destructive";
}

/** A strategy's fit with an instrument in one word: any failed check rules it out; warnings do not. */
export function compatibilityVerdict(compatibility: Pick<StrategyCompatibility, "compatible" | "checks">): Verdict {
  if (!compatibility.compatible || compatibility.checks.some((check) => check.status === "FAILED")) {
    return { label: "Not compatible", tone: "destructive" };
  }
  if (compatibility.checks.some((check) => check.status === "WARNING")) {
    return { label: "Compatible with warnings", tone: "warning" };
  }
  return { label: "Compatible", tone: "success" };
}

export interface ChartOverlay {
  deployment: DeploymentView;
  /** The configuration's number on the chart: its markers carry it. */
  number: number;
}

/** The applied configurations that still exist, numbered in the order they were applied. */
export function appliedOverlays(applied: readonly string[], deployments: readonly DeploymentView[]): ChartOverlay[] {
  const byId = new Map(deployments.map((deployment) => [deployment.id, deployment]));
  return [...new Set(applied)]
    .flatMap((id) => {
      const deployment = byId.get(id);
      return deployment ? [deployment] : [];
    })
    .map((deployment, index) => ({ deployment, number: index + 1 }));
}

/** ``applied`` with ``id`` added, or removed if it was there. */
export function toggleApplied(applied: readonly string[], id: string): string[] {
  return applied.includes(id) ? applied.filter((item) => item !== id) : [...applied, id];
}
