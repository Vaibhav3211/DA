import { describe, expect, it } from "vitest";
import type { UniverseRules } from "@/lib/api/types.gen";
import { instrumentSubtitle, universeProblem } from "@/lib/universe";
import { instrument } from "@/test/fixtures";

const indexDerivatives: UniverseRules = {
  exchanges: ["NSE"],
  segments: ["FNO"],
  instrument_types: ["OPTION", "FUTURE"],
  underlying_kind: "INDEX",
  index_underlyings: ["NIFTY", "BANKNIFTY"],
};

describe("universeProblem", () => {
  it("accepts an instrument that meets every rule", () => {
    expect(universeProblem(indexDerivatives, instrument({ underlying: " nifty " }))).toBeNull();
    expect(universeProblem({ ...indexDerivatives, underlying_kind: null }, instrument({ underlying: null }))).toBeNull();
  });

  it("explains the first rule an instrument breaks", () => {
    expect(universeProblem({ ...indexDerivatives, exchanges: [] }, instrument())).toBe("takes no instruments");
    expect(universeProblem(indexDerivatives, instrument({ exchange: "BSE" }))).toBe("takes NSE only");
    expect(universeProblem(indexDerivatives, instrument({ segment: "CASH" }))).toBe("takes the FNO segment only");
    expect(universeProblem(indexDerivatives, instrument({ instrument_type: "EQUITY" }))).toBe(
      "takes OPTION, FUTURE only",
    );
    expect(universeProblem(indexDerivatives, instrument({ underlying: null }))).toBe(
      "takes derivatives with an underlying only",
    );
    expect(universeProblem(indexDerivatives, instrument({ underlying: "RELIANCE" }))).toBe(
      "takes index derivatives only",
    );
    expect(universeProblem({ ...indexDerivatives, underlying_kind: "STOCK" }, instrument())).toBe(
      "takes stock derivatives only",
    );
  });
});

describe("instrumentSubtitle", () => {
  it("shows contract terms for derivatives and the name otherwise", () => {
    expect(instrumentSubtitle(instrument())).toBe("NIFTY · 2025-01-30 · 22000 · CE");
    expect(instrumentSubtitle(instrument({ instrument_type: "EQUITY", name: "Infosys" }))).toBe("Infosys");
    expect(instrumentSubtitle(instrument({ instrument_type: "EQUITY", name: null }))).toBe("");
  });
});
