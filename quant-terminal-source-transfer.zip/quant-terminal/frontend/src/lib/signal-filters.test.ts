import { describe, expect, it } from "vitest";
import { signalSearch, withParam } from "@/lib/signal-filters";

// Filter days are local days, so expected instants are built the same way in any timezone.
const localMidnight = (year: number, month: number, day: number) => new Date(year, month - 1, day).toISOString();

describe("signalSearch", () => {
  it("reads the filters from the page URL", () => {
    const search = signalSearch(
      new URLSearchParams(
        "workspace=nifty&strategy_id=%20&instrument=inst-1&status=ACTIVE&type=BUY&open=1&actionable=false&from=2025-01-01&to=2025-01-31",
      ),
    );
    expect(search.filters).toEqual({
      limit: 50,
      workspace: "nifty",
      instrument: "inst-1",
      status: "ACTIVE",
      signal_type: "BUY",
      open_only: true,
      actionable: false,
      since: localMidnight(2025, 1, 1),
      until: localMidnight(2025, 2, 1),
    });
    expect(search.problem).toBeNull();
  });

  it("ignores values it does not know", () => {
    expect(
      signalSearch(new URLSearchParams("status=WHATEVER&type=buy&open=true&actionable=yes&from=2025-02-30")).filters,
    ).toEqual({ limit: 50 });
  });

  it("includes the whole last day and rejects an inverted range", () => {
    expect(signalSearch(new URLSearchParams("from=2025-01-30&to=2025-01-30")).problem).toBeNull();
    expect(signalSearch(new URLSearchParams("from=2025-01-31&to=2025-01-30")).problem).toBe(
      "The start date is after the end date.",
    );
  });
});

describe("withParam", () => {
  it("sets or removes one parameter and keeps the rest", () => {
    expect(withParam("status=ACTIVE&type=BUY", "status", "CLOSED")).toBe("status=CLOSED&type=BUY");
    expect(withParam("status=ACTIVE&type=BUY", "status", null)).toBe("type=BUY");
    expect(withParam("", "open", "1")).toBe("open=1");
  });
});
