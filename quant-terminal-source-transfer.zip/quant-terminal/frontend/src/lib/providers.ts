// Provider-account rules mirrored from backend/app/services/provider_accounts.py, so forms only
// offer valid choices. The API enforces the same rules either way.

import type {
  AuthMethod,
  CredentialKind,
  CredentialOrigin,
  GrowwConnectRequest,
  Provider,
  ProviderAccountView,
} from "@/lib/api/types.gen";

/** Providers whose accounts are added in the UI; simulator accounts come from development setups. */
export const ACCOUNT_PROVIDERS: readonly Provider[] = ["ZERODHA", "GROWW"];

/** Sign-in methods per provider; the first one is the default for new accounts. */
export const AUTH_METHODS: Record<Provider, readonly AuthMethod[]> = {
  ZERODHA: ["ZERODHA_LOGIN_REDIRECT"],
  GROWW: ["GROWW_ACCESS_TOKEN", "GROWW_API_KEY_SECRET", "GROWW_TOTP"],
  SIMULATOR: ["NONE"],
};

export const AUTH_METHOD_LABEL: Record<AuthMethod, string> = {
  ZERODHA_LOGIN_REDIRECT: "Kite login",
  GROWW_ACCESS_TOKEN: "Access token",
  GROWW_API_KEY_SECRET: "API key and secret",
  GROWW_TOTP: "TOTP",
  NONE: "No sign-in",
};

export const AUTH_METHOD_HINT: Record<AuthMethod, string> = {
  ZERODHA_LOGIN_REDIRECT:
    "Store the Kite Connect app's API key and secret, then sign in through Kite whenever the session expires.",
  GROWW_ACCESS_TOKEN: "Paste an access token generated in Groww Cloud; nothing else is stored.",
  GROWW_API_KEY_SECRET: "Store an API key and secret from Groww Cloud; the terminal creates access tokens with them.",
  GROWW_TOTP:
    "Store the TOTP token (API key). Access tokens are created with an authenticator code, or automatically when the TOTP secret is stored too.",
  NONE: "Simulated data needs no sign-in.",
};

const STORABLE: Record<Provider, readonly CredentialKind[]> = {
  ZERODHA: ["API_KEY", "API_SECRET"],
  GROWW: ["API_KEY", "API_SECRET", "TOTP_SECRET"],
  SIMULATOR: [],
};

const METHOD_KINDS: Record<AuthMethod, { required: readonly CredentialKind[]; optional: readonly CredentialKind[] }> = {
  ZERODHA_LOGIN_REDIRECT: { required: ["API_KEY", "API_SECRET"], optional: [] },
  GROWW_ACCESS_TOKEN: { required: [], optional: [] },
  GROWW_API_KEY_SECRET: { required: ["API_KEY", "API_SECRET"], optional: [] },
  GROWW_TOTP: { required: ["API_KEY"], optional: ["TOTP_SECRET"] },
  NONE: { required: [], optional: [] },
};

const KIND_LABEL: Record<CredentialKind, string> = {
  API_KEY: "API key",
  API_SECRET: "API secret",
  ACCESS_TOKEN: "Access token",
  TOTP_SECRET: "TOTP secret",
};

const STORABLE_ORDER: readonly CredentialKind[] = ["API_KEY", "API_SECRET", "TOTP_SECRET"];

export function credentialLabel(method: AuthMethod, kind: CredentialKind): string {
  return method === "GROWW_TOTP" && kind === "API_KEY" ? "TOTP token (API key)" : KIND_LABEL[kind];
}

export interface CredentialRow {
  kind: CredentialKind;
  label: string;
  required: boolean;
  /** Whether the account's sign-in method reads this credential at all. */
  used: boolean;
  origin: CredentialOrigin | null;
  masked: string | null;
}

type CredentialSource = Pick<ProviderAccountView, "provider" | "auth_method" | "credentials">;

/** The credentials worth showing for an account: the ones its method uses, plus any it still holds. */
export function credentialRows(account: CredentialSource): CredentialRow[] {
  const { required, optional } = METHOD_KINDS[account.auth_method];
  return STORABLE[account.provider].flatMap((kind): CredentialRow[] => {
    const info = account.credentials.find((credential) => credential.kind === kind);
    const used = required.includes(kind) || optional.includes(kind);
    if (!used && !info) return [];
    return [
      {
        kind,
        label: info?.label ?? credentialLabel(account.auth_method, kind),
        required: required.includes(kind),
        used,
        origin: info?.origin ?? null,
        masked: info?.masked ?? null,
      },
    ];
  });
}

/** Trimmed, non-empty credential values only: empty fields keep what is stored. */
export function filledCredentials(values: Partial<Record<CredentialKind, string>>): Partial<Record<CredentialKind, string>> {
  const filled: Partial<Record<CredentialKind, string>> = {};
  for (const kind of STORABLE_ORDER) {
    const value = values[kind]?.trim();
    if (value) filled[kind] = value;
  }
  return filled;
}

export function normalizeLabel(label: string): string {
  return label.split(/\s+/).filter(Boolean).join(" ");
}

const LABEL = /^[A-Za-z0-9][A-Za-z0-9 _.-]{0,79}$/;

export function labelError(label: string): string | null {
  const cleaned = normalizeLabel(label);
  if (!cleaned) return "Enter a label";
  return LABEL.test(cleaned)
    ? null
    : "Use 1-80 letters, digits, spaces, '.', '_' or '-', starting with a letter or digit";
}

/** Seconds until the access token expires (negative once it has); null without a token. */
export function tokenSecondsLeft(
  account: Pick<ProviderAccountView, "has_access_token" | "token_expires_at">,
  now: number,
): number | null {
  if (!account.has_access_token || !account.token_expires_at) return null;
  const expires = Date.parse(account.token_expires_at);
  return Number.isNaN(expires) ? null : Math.round((expires - now) / 1000);
}

/** How a Groww account gets an access token: create one from stored secrets, use a code, or paste one. */
export type GrowwMode = "create" | "code" | "token";

export function growwModes(account: Pick<ProviderAccountView, "auth_method" | "credentials">): GrowwMode[] {
  if (account.auth_method === "GROWW_API_KEY_SECRET") return ["create", "token"];
  if (account.auth_method === "GROWW_TOTP") {
    const hasSecret = account.credentials.some((credential) => credential.kind === "TOTP_SECRET");
    return hasSecret ? ["create", "code", "token"] : ["code", "token"];
  }
  return ["token"];
}

/** The connect request for a mode: exactly one of the token or the code, or neither to create one. */
export function growwConnectBody(accountId: string, mode: GrowwMode, value: string): GrowwConnectRequest {
  if (mode === "token") return { account_id: accountId, access_token: value.trim() };
  if (mode === "code") return { account_id: accountId, totp_code: value.replace(/\s+/g, "") };
  return { account_id: accountId };
}

export function isTotpCode(value: string): boolean {
  return /^\d{6,8}$/.test(value.replace(/\s+/g, ""));
}

/** The address Kite must redirect to: the API callback, reached through this app's proxy. */
export function zerodhaCallbackUrl(origin: string): string {
  return `${origin.replace(/\/+$/, "")}/api/v1/providers/zerodha/callback`;
}

const ZERODHA_ERRORS = new Map<string, string>([
  ["unauthenticated", "Your terminal session ended before Kite sent you back. Sign in here, then start the Kite login again."],
  ["login_state_missing", "Kite sent you back without the login reference. Start the Kite login again."],
  ["login_state_invalid", "That login has expired or was already used. Start the Kite login again."],
  ["login_state_mismatch", "That Kite login was started by another user."],
  ["provider_user_mismatch", "Kite signed in a different Zerodha user than the one this account belongs to."],
  ["encryption_not_configured", "The server cannot store the access token: its credential encryption key is not set."],
  ["credentials_missing", "The account's API key or secret is missing. Add it, then sign in again."],
  ["credential_unreadable", "A stored credential cannot be decrypted with the server's keys. Enter it again, then sign in."],
  ["not_found", "The account was deleted before the login finished."],
]);

export type ZerodhaReturn =
  | { ok: true; accountId: string | null }
  | { ok: false; code: string; message: string };

/** The outcome the Kite callback passes back in the providers page's query string, if any. */
export function zerodhaReturn(params: { get(name: string): string | null }): ZerodhaReturn | null {
  const outcome = params.get("zerodha");
  if (outcome === "connected") return { ok: true, accountId: params.get("account_id") };
  if (outcome !== "error") return null;
  const code = (params.get("code") ?? "").slice(0, 64) || "unknown";
  const message = ZERODHA_ERRORS.get(code) ?? `Kite sign-in failed (${code}). Start the Kite login again.`;
  return { ok: false, code, message };
}
