// Candle data for lightweight-charts. Chart times are UTC seconds; labels are formatted in IST.

import type { CandlestickData, HistogramData, LineData, UTCTimestamp } from "lightweight-charts";
import type { Candle, CandleInterval, SignalType, SignalView } from "@/lib/api/types.gen";
import { IST } from "@/lib/format";

export const CHART_COLORS = {
  background: "#11131a",
  text: "#a1a7b8",
  grid: "#1f2330",
  border: "#2b3040",
  up: "#34d399",
  down: "#f87171",
  upVolume: "rgba(52, 211, 153, 0.35)",
  downVolume: "rgba(248, 113, 113, 0.35)",
  ema: "#60a5fa",
  emaSlow: "#f59e0b",
  signalExit: "#facc15",
  signalBlocked: "#8b93a7",
  // Backtest trades are muted so they never pass for live signals.
  backtestLong: "#5b9a84",
  backtestShort: "#b07b7b",
  backtestExit: "#a8996b",
  equity: "#60a5fa",
} as const;

export const CANDLE_INTERVALS: readonly CandleInterval[] = ["1s", "1m", "3m", "5m", "15m", "30m", "1h", "1d"];
export const EMA_FAST = 20;
export const EMA_SLOW = 50;

export const INTERVAL_SECONDS: Readonly<Record<CandleInterval, number>> = {
  "1s": 1,
  "1m": 60,
  "3m": 180,
  "5m": 300,
  "15m": 900,
  "30m": 1800,
  "1h": 3600,
  "1d": 86_400,
};

/** The chart's price precision from an instrument's tick size ("0.05" -> 2 places, "0.0025" -> 4). */
export function priceFormatFor(tickSize: string | null | undefined): { precision: number; minMove: number } {
  const match = /^\d*\.?(\d*?)0*$/.exec(tickSize?.trim() ?? "");
  const decimals = match && Number(tickSize) > 0 ? (match[1] ?? "").length : 0;
  const precision = Math.min(Math.max(2, decimals), 8);
  return { precision, minMove: Number((10 ** -precision).toFixed(precision)) };
}

export interface ChartBar extends CandlestickData<UTCTimestamp> {
  volume: number | null;
  closed: boolean;
}

export function toSeconds(iso: string): UTCTimestamp {
  return Math.floor(Date.parse(iso) / 1000) as UTCTimestamp;
}

/**
 * Which of two versions of one bucket to keep: a closed candle beats a forming one (a late forming
 * update must not reopen it), then the higher revision; the incoming candle wins ties.
 */
export function newer(current: Candle, incoming: Candle): Candle {
  if (current.is_closed !== incoming.is_closed) return current.is_closed ? current : incoming;
  return incoming.revision >= current.revision ? incoming : current;
}

/** One candle per bucket, oldest first, from any number of sources (history, then live updates). */
export function mergeCandles(...sources: readonly (readonly Candle[])[]): Candle[] {
  const byBucket = new Map<number, Candle>();
  for (const source of sources) {
    for (const candle of source) {
      const bucket = Date.parse(candle.bucket_start);
      if (Number.isNaN(bucket)) continue;
      const existing = byBucket.get(bucket);
      byBucket.set(bucket, existing ? newer(existing, candle) : candle);
    }
  }
  return [...byBucket.entries()].sort((a, b) => a[0] - b[0]).map(([, candle]) => candle);
}

export function toBar(candle: Candle): ChartBar {
  return {
    time: toSeconds(candle.bucket_start),
    open: Number(candle.open_price),
    high: Number(candle.high_price),
    low: Number(candle.low_price),
    close: Number(candle.close_price),
    volume: candle.volume,
    closed: candle.is_closed,
  };
}

export function volumeData(bars: readonly ChartBar[]): HistogramData<UTCTimestamp>[] {
  return bars
    .filter((bar) => bar.volume !== null)
    .map((bar) => ({
      time: bar.time,
      value: bar.volume ?? 0,
      color: bar.close >= bar.open ? CHART_COLORS.upVolume : CHART_COLORS.downVolume,
    }));
}

/** Exponential moving average seeded with the simple average of the first ``period`` values. */
export function ema(values: readonly number[], period: number): (number | null)[] {
  if (!Number.isInteger(period) || period < 1) return values.map(() => null);
  const k = 2 / (period + 1);
  const result: (number | null)[] = [];
  let sum = 0;
  let previous: number | null = null;
  values.forEach((value, index) => {
    if (previous === null) {
      sum += value;
      if (index === period - 1) previous = sum / period;
      result.push(previous);
    } else {
      previous = value * k + previous * (1 - k);
      result.push(previous);
    }
  });
  return result;
}

export function emaLine(bars: readonly ChartBar[], period: number): LineData<UTCTimestamp>[] {
  const values = ema(
    bars.map((bar) => bar.close),
    period,
  );
  const line: LineData<UTCTimestamp>[] = [];
  bars.forEach((bar, index) => {
    const value = values[index];
    if (value !== null && value !== undefined) line.push({ time: bar.time, value });
  });
  return line;
}

const formats = {
  month: new Intl.DateTimeFormat("en-IN", { timeZone: IST, month: "short", year: "numeric" }),
  day: new Intl.DateTimeFormat("en-IN", { timeZone: IST, day: "2-digit", month: "short" }),
  minute: new Intl.DateTimeFormat("en-IN", { timeZone: IST, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }),
  second: new Intl.DateTimeFormat("en-IN", {
    timeZone: IST,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }),
  date: new Intl.DateTimeFormat("en-IN", { timeZone: IST, day: "2-digit", month: "short", year: "numeric" }),
  dateMinute: new Intl.DateTimeFormat("en-IN", {
    timeZone: IST,
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }),
};

/** Axis labels; ``tickMarkType`` is lightweight-charts' TickMarkType (0 year, 1 month, 2 day, 3 time, 4 seconds). */
export function chartTickLabel(seconds: number, tickMarkType: number): string {
  const date = new Date(seconds * 1000);
  if (tickMarkType <= 1) return formats.month.format(date);
  if (tickMarkType === 2) return formats.day.format(date);
  if (tickMarkType === 3) return formats.minute.format(date);
  return formats.second.format(date);
}

/** The crosshair label for a bar. */
export function chartTimeLabel(seconds: number, interval: CandleInterval): string {
  const date = new Date(seconds * 1000);
  if (interval === "1d") return formats.date.format(date);
  if (interval === "1s") return `${formats.day.format(date)} ${formats.second.format(date)} IST`;
  return `${formats.dateMinute.format(date)} IST`;
}

export type MarkerSignalType = Extract<SignalType, "BUY" | "SELL" | "EXIT">;

/** A series marker as lightweight-charts draws it (structurally its ``SeriesMarker``); ``id`` is the signal's. */
export interface ChartMarker {
  id: string;
  time: UTCTimestamp;
  position: "aboveBar" | "belowBar" | "inBar";
  shape: "arrowUp" | "arrowDown" | "circle" | "square";
  color: string;
  text: string;
}

export const MARKER_STYLE: Readonly<Record<MarkerSignalType, Pick<ChartMarker, "position" | "shape" | "color">>> = {
  BUY: { position: "belowBar", shape: "arrowUp", color: CHART_COLORS.up },
  SELL: { position: "aboveBar", shape: "arrowDown", color: CHART_COLORS.down },
  EXIT: { position: "aboveBar", shape: "square", color: CHART_COLORS.signalExit },
};

/** The signal types drawn on the chart; the others stay in the signal list. */
export const MARKER_SIGNAL_TYPES: readonly MarkerSignalType[] = ["BUY", "SELL", "EXIT"];

export function isMarkerSignalType(type: SignalType): type is MarkerSignalType {
  return (MARKER_SIGNAL_TYPES as readonly SignalType[]).includes(type);
}

/**
 * Where a signal belongs in time, in UTC seconds: the last second of the candle it came from, so its marker
 * sits on that candle, or when it was generated if that is earlier (a partial-candle signal) or it names no
 * candle. A candle-close signal is known only once its candle has closed.
 */
export function signalMarkerTime(
  signal: Pick<SignalView, "generated_at" | "source_candle_start" | "source_candle_interval">,
): number | null {
  const candidates = [Date.parse(signal.generated_at)];
  if (signal.source_candle_start !== null && signal.source_candle_interval !== null) {
    const length = INTERVAL_SECONDS[signal.source_candle_interval];
    candidates.push(Date.parse(signal.source_candle_start) + (length - 1) * 1000);
  }
  const valid = candidates.filter((value) => !Number.isNaN(value));
  return valid.length === 0 ? null : Math.floor(Math.min(...valid) / 1000);
}

/** The latest of the sorted bar ``times`` that starts at or before ``seconds``; null if all start later. */
export function barTimeAtOrBefore(times: readonly number[], seconds: number): number | null {
  let low = 0;
  let high = times.length - 1;
  let found: number | null = null;
  while (low <= high) {
    const middle = (low + high) >> 1;
    const time = times[middle] as number;
    if (time <= seconds) {
      found = time;
      low = middle + 1;
    } else {
      high = middle - 1;
    }
  }
  return found;
}

export interface MarkedSignal {
  signal: SignalView;
  /** The number of its configuration on the chart. */
  number: number;
  /** The bar it is drawn on. */
  time: UTCTimestamp;
}

/**
 * The BUY, SELL and EXIT signals that fall on the chart's bars (sorted ``barTimes``), oldest first. Signals
 * from before the first bar are left out: the signal history still lists them.
 */
export function placeSignals(
  sources: readonly { signals: readonly SignalView[]; number: number }[],
  barTimes: readonly number[],
): MarkedSignal[] {
  const marked: MarkedSignal[] = [];
  const seen = new Set<string>();
  for (const { signals, number } of sources) {
    for (const signal of signals) {
      if (!isMarkerSignalType(signal.signal_type) || seen.has(signal.id)) continue;
      const at = signalMarkerTime(signal);
      const time = at === null ? null : barTimeAtOrBefore(barTimes, at);
      if (time === null) continue;
      seen.add(signal.id);
      marked.push({ signal, number, time: time as UTCTimestamp });
    }
  }
  return marked.sort(
    (a, b) => a.time - b.time || a.signal.generated_at.localeCompare(b.signal.generated_at) || a.number - b.number,
  );
}

/** Markers for placed signals: shape and side by type, grey when the risk gate blocked the signal. */
export function signalMarkers(marked: readonly MarkedSignal[]): ChartMarker[] {
  return marked.map(({ signal, number, time }) => {
    const style = isMarkerSignalType(signal.signal_type) ? MARKER_STYLE[signal.signal_type] : MARKER_STYLE.EXIT;
    return {
      id: signal.id,
      time,
      position: style.position,
      shape: style.shape,
      color: signal.status === "BLOCKED" ? CHART_COLORS.signalBlocked : style.color,
      text: String(number),
    };
  });
}
