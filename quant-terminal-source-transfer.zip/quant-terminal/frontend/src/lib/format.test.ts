import { describe, expect, it } from "vitest";
import {
  ageSeconds,
  formatAge,
  formatDuration,
  formatLatency,
  formatPrice,
  formatTime,
  humanize,
  priceChange,
  segmentLabel,
} from "@/lib/format";

describe("formatPrice", () => {
  it("groups digits the Indian way and shows at least two decimals", () => {
    expect(formatPrice("1234567.5")).toBe("12,34,567.50");
    expect(formatPrice(5)).toBe("5.00");
    expect(formatPrice("-0.5")).toBe("-0.50");
  });

  it("keeps every digit it is sent", () => {
    // 2^53 + 1: a float round trip would print ...992.
    expect(formatPrice("9007199254740993.25")).toBe("9,00,71,99,25,47,40,993.25");
    expect(formatPrice("0.000123456")).toBe("0.000123456");
  });

  it("shows a dash for missing or unreadable values", () => {
    expect(formatPrice(null)).toBe("—");
    expect(formatPrice("")).toBe("—");
    expect(formatPrice("n/a")).toBe("—");
  });
});

describe("durations and ages", () => {
  it("uses the two largest units", () => {
    expect(formatDuration(59)).toBe("59s");
    expect(formatDuration(61)).toBe("1m 01s");
    expect(formatDuration(3600)).toBe("1h 00m");
    expect(formatDuration(49 * 3600)).toBe("2d 1h");
    expect(formatDuration(null)).toBe("—");
  });

  it("measures age against the given clock and never goes negative", () => {
    const now = Date.parse("2025-01-01T00:01:30Z");
    expect(formatAge("2025-01-01T00:00:00Z", now)).toBe("1m 30s ago");
    expect(ageSeconds("2025-01-01T00:05:00Z", now)).toBe(0);
    expect(formatAge(null, now)).toBe("—");
    expect(formatAge("not a date", now)).toBe("—");
  });
});

describe("other formatters", () => {
  it("shows times in IST", () => {
    expect(formatTime("2025-01-01T03:45:10Z")).toBe("09:15:10");
    expect(formatTime("not a date")).toBe("—");
  });

  it("rounds latency to whole milliseconds", () => {
    expect(formatLatency(12.6)).toBe("13 ms");
    expect(formatLatency(null)).toBe("—");
  });

  it("computes a price change only against a non-zero base", () => {
    expect(priceChange("110", "100")).toEqual({ change: 10, ratio: 0.1 });
    expect(priceChange("110", "0")).toBeNull();
    expect(priceChange(null, "100")).toBeNull();
  });

  it("humanizes identifiers and writes FNO as F&O", () => {
    expect(humanize("AUTH_REQUIRED")).toBe("Auth required");
    expect(humanize("kill-switch")).toBe("Kill switch");
    expect(segmentLabel("FNO")).toBe("F&O");
    expect(segmentLabel("CASH")).toBe("CASH");
  });
});
