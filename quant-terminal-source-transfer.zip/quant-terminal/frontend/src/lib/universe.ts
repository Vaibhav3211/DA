import type { Instrument, UniverseRules } from "@/lib/api/types.gen";

/**
 * Why a workspace would refuse the instrument, or null when it takes it. Mirrors the backend's
 * ``UniverseRules.problem`` as a hint only: the API stays the authority.
 */
export function universeProblem(rules: UniverseRules, instrument: Instrument): string | null {
  if (rules.exchanges.length === 0) return "takes no instruments";
  if (!rules.exchanges.includes(instrument.exchange)) return `takes ${rules.exchanges.join(", ")} only`;
  if (rules.segments.length > 0 && !rules.segments.includes(instrument.segment)) {
    return `takes the ${rules.segments.join(", ")} segment only`;
  }
  if (rules.instrument_types.length > 0 && !rules.instrument_types.includes(instrument.instrument_type)) {
    return `takes ${rules.instrument_types.join(", ")} only`;
  }
  if (rules.underlying_kind === null) return null;
  if (instrument.underlying === null) return "takes derivatives with an underlying only";
  const isIndex = rules.index_underlyings.includes(instrument.underlying.trim().toUpperCase());
  if (rules.underlying_kind === "INDEX" && !isIndex) return "takes index derivatives only";
  if (rules.underlying_kind === "STOCK" && isIndex) return "takes stock derivatives only";
  return null;
}

/** A short second line for an instrument: its name or contract terms. */
export function instrumentSubtitle(instrument: Instrument): string {
  const parts: string[] = [];
  if (instrument.instrument_type === "OPTION" || instrument.instrument_type === "FUTURE") {
    if (instrument.underlying) parts.push(instrument.underlying);
    if (instrument.expiry) parts.push(instrument.expiry);
    if (instrument.strike) parts.push(instrument.strike);
    if (instrument.option_type) parts.push(instrument.option_type);
  } else if (instrument.name) {
    parts.push(instrument.name);
  }
  return parts.join(" · ");
}
