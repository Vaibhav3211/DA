import { describe, expect, it } from "vitest";
import { parseFormValues, schemaFields, toFormValues, type SchemaField } from "@/lib/schema-form";

// Shaped like Pydantic's model_json_schema() for a strategy's settings model.
const schema: Record<string, unknown> = {
  $defs: {
    PriceSource: { enum: ["close", "hl2"], title: "PriceSource", type: "string" },
  },
  properties: {
    fast_period: { default: 9, maximum: 200, minimum: 2, title: "Fast Period", type: "integer" },
    threshold: {
      anyOf: [{ exclusiveMinimum: 0, type: "number" }, { pattern: "^-?\\d*\\.?\\d*$", type: "string" }],
      default: "0.5",
      title: "Threshold",
    },
    source: { $ref: "#/$defs/PriceSource", default: "close" },
    legacy_source: { allOf: [{ $ref: "#/$defs/PriceSource" }], default: "hl2" },
    stop_loss: { anyOf: [{ minimum: 0, type: "number" }, { type: "null" }], default: null, title: "Stop Loss" },
    max_trades: { default: null, type: ["integer", "null"] },
    confirm: { default: true, title: "Confirm", type: "boolean" },
    notify: { anyOf: [{ type: "boolean" }, { type: "null" }], default: null, title: "Notify" },
    version: { const: 2, default: 2, type: "integer" },
    weights: { default: [1, 2], items: { type: "number" }, type: "array" },
    tag: { description: "Shown in alerts", type: "string" },
  },
  required: ["tag"],
  title: "Settings",
  type: "object",
};

const fields = schemaFields(schema);
const defaults = toFormValues(fields, {});

function field(name: string): SchemaField {
  const found = fields.find((candidate) => candidate.name === name);
  if (!found) throw new Error(`No field ${name}`);
  return found;
}

describe("schemaFields", () => {
  it("picks a form control for each setting", () => {
    expect(fields.map((item) => [item.name, item.kind, item.nullable])).toEqual([
      ["fast_period", "integer", false],
      ["threshold", "decimal", false],
      ["source", "enum", false],
      ["legacy_source", "enum", false],
      ["stop_loss", "number", true],
      ["max_trades", "integer", true],
      ["confirm", "boolean", false],
      ["notify", "enum", true],
      ["version", "enum", false],
      ["weights", "json", false],
      ["tag", "string", false],
    ]);
  });

  it("reads bounds, options, defaults and labels", () => {
    expect(field("fast_period")).toMatchObject({ label: "Fast Period", minimum: 2, maximum: 200, defaultValue: 9 });
    expect(field("threshold")).toMatchObject({ minimum: null, exclusiveMinimum: 0 });
    expect(field("stop_loss")).toMatchObject({ label: "Stop Loss", minimum: 0 });
    expect(field("notify").options).toEqual([true, false]);
    expect(field("version").options).toEqual([2]);
    expect(field("tag")).toMatchObject({ label: "Tag", required: true, description: "Shown in alerts" });
  });

  it("labels a field by its own name, not by the type it refers to", () => {
    // Pydantic sets no title on a field that refers to an enum or model.
    expect(field("source")).toMatchObject({ label: "Source", options: ["close", "hl2"], defaultValue: "close" });
    expect(field("legacy_source")).toMatchObject({ label: "Legacy source", options: ["close", "hl2"] });
  });
});

describe("form values", () => {
  it("fills the form from a config, falling back to the defaults", () => {
    expect(toFormValues(fields, { fast_period: 12, weights: [0.5, 0.5] })).toEqual({
      fast_period: "12",
      threshold: "0.5",
      source: "close",
      legacy_source: "hl2",
      stop_loss: "",
      max_trades: "",
      confirm: true,
      notify: "",
      version: "2",
      weights: "[\n  0.5,\n  0.5\n]",
      tag: "",
    });
  });

  it("parses the form into a config, keeping decimals as text", () => {
    expect(
      parseFormValues(fields, {
        ...defaults,
        fast_period: " 21 ",
        threshold: "0.10",
        max_trades: "3",
        notify: "false",
        weights: "[1, 2]",
        tag: " nifty ",
      }),
    ).toEqual({
      config: {
        fast_period: 21,
        threshold: "0.10",
        source: "close",
        legacy_source: "hl2",
        stop_loss: null,
        max_trades: 3,
        confirm: true,
        notify: false,
        version: 2,
        weights: [1, 2],
        tag: "nifty",
      },
      errors: {},
    });
  });

  it("explains every value it cannot accept", () => {
    const { errors } = parseFormValues(fields, {
      ...defaults,
      fast_period: "2.5",
      threshold: "0",
      source: "open",
      stop_loss: "-1",
      max_trades: "abc",
      weights: "[1,",
      tag: "   ",
    });
    expect(errors).toEqual({
      fast_period: "Enter a whole number",
      threshold: "Must be more than 0",
      source: "Choose one of the options",
      stop_loss: "Must be at least 0",
      max_trades: "Enter a whole number",
      weights: "Enter valid JSON",
      tag: "Enter a value",
    });
    expect(parseFormValues(fields, { ...defaults, fast_period: "201", stop_loss: "1e" }).errors).toMatchObject({
      fast_period: "Must be at most 200",
      stop_loss: "Enter a number",
    });
  });
});
