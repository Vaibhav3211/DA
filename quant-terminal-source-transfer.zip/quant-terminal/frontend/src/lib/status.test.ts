import { describe, expect, it } from "vitest";
import { agedStatus, countStatuses, effectiveStatus, isDegraded, quoteStatus, worstStatus } from "@/lib/status";

describe("status severity", () => {
  it("ranks simulated data worst, so anything derived from it stays marked simulated", () => {
    expect(worstStatus([])).toBeNull();
    expect(worstStatus(["LIVE", "STALE", "DELAYED"])).toBe("STALE");
    expect(worstStatus(["DISCONNECTED", "SIMULATED", "LIVE"])).toBe("SIMULATED");
  });

  it("counts statuses in severity order", () => {
    expect(countStatuses(["STALE", "LIVE", "STALE"])).toEqual([
      ["LIVE", 1],
      ["STALE", 2],
    ]);
  });

  it("treats only live and simulated data as healthy", () => {
    expect(isDegraded("LIVE")).toBe(false);
    expect(isDegraded("SIMULATED")).toBe(false);
    expect(isDegraded("DELAYED")).toBe(true);
  });
});

describe("agedStatus", () => {
  it("marks a value stale once it is older than the limit", () => {
    expect(agedStatus("LIVE", 30, 30)).toBe("LIVE");
    expect(agedStatus("LIVE", 31, 30)).toBe("STALE");
    expect(agedStatus("LIVE", null, 30)).toBe("LIVE");
  });

  it("never improves a worse status", () => {
    expect(agedStatus("DISCONNECTED", 120, 30)).toBe("DISCONNECTED");
    expect(agedStatus("SIMULATED", 120, 30)).toBe("SIMULATED");
  });
});

describe("what this browser shows", () => {
  it("caps a value by the browser's own socket", () => {
    expect(effectiveStatus("LIVE", "open")).toBe("LIVE");
    expect(effectiveStatus("LIVE", "reconnecting")).toBe("RECONNECTING");
    expect(effectiveStatus("LIVE", "connecting")).toBe("UNKNOWN");
    expect(effectiveStatus("LIVE", "closed")).toBe("DISCONNECTED");
    expect(effectiveStatus("LIVE", "unauthorized")).toBe("DISCONNECTED");
  });

  it("ages a quote from when it was received", () => {
    const quote = { data_status: "LIVE" as const, received_at: "2025-01-01T03:45:00Z" };
    const received = Date.parse(quote.received_at);
    expect(quoteStatus(quote, received + 5_000, 30, "open")).toBe("LIVE");
    expect(quoteStatus(quote, received + 45_000, 30, "open")).toBe("STALE");
    expect(quoteStatus(quote, received + 5_000, 30, "reconnecting")).toBe("RECONNECTING");
    expect(quoteStatus(undefined, received, 30, "open")).toBe("UNKNOWN");
  });
});
