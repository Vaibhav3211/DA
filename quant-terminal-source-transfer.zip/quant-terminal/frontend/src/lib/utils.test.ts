import { describe, expect, it } from "vitest";
import { httpUrl, safeNext } from "@/lib/utils";

describe("safeNext", () => {
  it("only redirects to a path on this site", () => {
    expect(safeNext("/system?tab=workers")).toBe("/system?tab=workers");
    expect(safeNext("//evil.example.com/login")).toBe("/");
    expect(safeNext("/\\evil.example.com")).toBe("/");
    expect(safeNext("https://evil.example.com")).toBe("/");
    expect(safeNext(null, "/market")).toBe("/market");
  });

  it("rejects tabs and line breaks, which browsers drop to reveal //host", () => {
    expect(safeNext("/\t/evil.example.com")).toBe("/");
    expect(safeNext("/\n\\evil.example.com")).toBe("/");
    expect(safeNext("/signals\r")).toBe("/");
  });
});

describe("httpUrl", () => {
  it("accepts absolute http and https URLs only", () => {
    expect(httpUrl("https://kite.example.com/connect/login?v=3")).toBe("https://kite.example.com/connect/login?v=3");
    expect(httpUrl("http://localhost:8000")).toBe("http://localhost:8000/");
    expect(httpUrl("javascript:alert(1)")).toBeNull();
    expect(httpUrl("/relative")).toBeNull();
    expect(httpUrl(null)).toBeNull();
  });
});
