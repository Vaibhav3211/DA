// The signals page keeps its filters in the URL so filtered views can be linked and bookmarked.

import type { SignalFilters } from "@/lib/api/endpoints";
import type { SignalStatus, SignalType } from "@/lib/api/types.gen";

// Records rather than arrays, so a value added to either enum fails to compile until it is listed.
const STATUSES: Record<SignalStatus, true> = {
  GENERATED: true,
  ACTIVE: true,
  UPDATED: true,
  INVALIDATED: true,
  EXPIRED: true,
  SUPERSEDED: true,
  CLOSED: true,
  BLOCKED: true,
};
const TYPES: Record<SignalType, true> = { BUY: true, SELL: true, EXIT: true, HOLD: true, WATCH: true, INVALIDATED: true };

export const SIGNAL_STATUSES = Object.keys(STATUSES) as SignalStatus[];
export const SIGNAL_TYPES = Object.keys(TYPES) as SignalType[];
export const SIGNAL_PAGE_SIZE = 50;

function isStatus(value: string | null): value is SignalStatus {
  return value !== null && Object.hasOwn(STATUSES, value);
}

function isType(value: string | null): value is SignalType {
  return value !== null && Object.hasOwn(TYPES, value);
}

/** Local midnight of a ``YYYY-MM-DD`` day plus ``days``, as an ISO instant; null when the day is malformed. */
export function localDayStart(day: string, days = 0): string | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(day);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]) - 1;
  const date = Number(match[3]);
  const value = new Date(year, month, date);
  if (value.getFullYear() !== year || value.getMonth() !== month || value.getDate() !== date) return null;
  value.setDate(value.getDate() + days);
  return value.toISOString();
}

export interface SignalSearch {
  filters: SignalFilters;
  /** Why the filters cannot be applied; null when they can. */
  problem: string | null;
}

/**
 * The filters in the page URL: ``workspace``, ``strategy_id``, ``instrument``, ``status``, ``type``,
 * ``open=1``, ``actionable=true|false`` and the inclusive local days ``from`` and ``to``.
 * Unknown values are ignored.
 */
export function signalSearch(params: Pick<URLSearchParams, "get">): SignalSearch {
  const text = (name: string) => params.get(name)?.trim() || undefined;
  const status = params.get("status");
  const type = params.get("type");
  const actionable = params.get("actionable");
  const from = text("from");
  const to = text("to");
  const since = from ? localDayStart(from) : null;
  const until = to ? localDayStart(to, 1) : null;
  const filters: SignalFilters = { limit: SIGNAL_PAGE_SIZE };
  const workspace = text("workspace");
  const strategyId = text("strategy_id");
  const instrument = text("instrument");
  if (workspace) filters.workspace = workspace;
  if (strategyId) filters.strategy_id = strategyId;
  if (instrument) filters.instrument = instrument;
  if (isStatus(status)) filters.status = status;
  if (isType(type)) filters.signal_type = type;
  if (params.get("open") === "1") filters.open_only = true;
  if (actionable === "true" || actionable === "false") filters.actionable = actionable === "true";
  if (since !== null) filters.since = since;
  if (until !== null) filters.until = until;
  const problem = since !== null && until !== null && since >= until ? "The start date is after the end date." : null;
  return { filters, problem };
}

/** ``search`` with ``name`` set to ``value``, or without it when the value is null or empty. */
export function withParam(search: string, name: string, value: string | null): string {
  const next = new URLSearchParams(search);
  if (value === null || value === "") next.delete(name);
  else next.set(name, value);
  return next.toString();
}
