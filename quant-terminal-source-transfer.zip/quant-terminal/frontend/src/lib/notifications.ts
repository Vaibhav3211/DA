import { create } from "zustand";

export type NoticeTone = "info" | "success" | "warning" | "error";

export interface Notice {
  id: number;
  tone: NoticeTone;
  title: string;
  description: string | null;
  /** Notices sharing a key replace each other, so a flapping feed cannot flood the list. */
  key: string | null;
  at: number;
  read: boolean;
  toast: boolean;
}

export interface NoticeInput {
  tone: NoticeTone;
  title: string;
  description?: string | null;
  key?: string | null;
}

interface NotificationState {
  notices: Notice[];
  push: (input: NoticeInput) => number;
  dismissToast: (id: number) => void;
  markAllRead: () => void;
  clear: () => void;
}

export const MAX_NOTICES = 100;
let lastId = 0;

export const useNotifications = create<NotificationState>()((set) => ({
  notices: [],
  push: (input) => {
    lastId += 1;
    const notice: Notice = {
      id: lastId,
      tone: input.tone,
      title: input.title,
      description: input.description ?? null,
      key: input.key ?? null,
      at: Date.now(),
      read: false,
      toast: true,
    };
    set((state) => ({
      notices: [notice, ...state.notices.filter((n) => notice.key === null || n.key !== notice.key)].slice(
        0,
        MAX_NOTICES,
      ),
    }));
    return notice.id;
  },
  dismissToast: (id) =>
    set((state) => ({ notices: state.notices.map((n) => (n.id === id && n.toast ? { ...n, toast: false } : n)) })),
  markAllRead: () => set((state) => ({ notices: state.notices.map((n) => (n.read ? n : { ...n, read: true })) })),
  clear: () => set({ notices: [] }),
}));

export function notify(tone: NoticeTone, title: string, description?: string | null, key?: string): number {
  return useNotifications.getState().push({ tone, title, description, key });
}
