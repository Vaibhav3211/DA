import { describe, expect, it } from "vitest";
import type { Signal } from "@/lib/api/types.gen";
import {
  initialLiveData,
  MAX_CANDLES_PER_SERIES,
  MAX_FEED_CHANGES,
  quoteKey,
  reduceFrame,
  seriesKey,
  type LiveData,
} from "@/lib/live/store";
import { DEFAULT_RECONNECT } from "@/lib/ws/protocol";
import { candle, quote } from "@/test/fixtures";

describe("reduceFrame", () => {
  it("records the server's limits from the welcome frame", () => {
    const state = reduceFrame(initialLiveData, {
      type: "welcome",
      connection_id: "connection-1",
      channels: ["quotes"],
      server_time: "2025-01-01T03:45:00Z",
      heartbeat_interval_seconds: 15,
      max_updates_per_second: 20,
      stale_after_seconds: 45,
      max_instruments: 200,
      reconnect: DEFAULT_RECONNECT,
    });
    expect(state.limits).toEqual({
      heartbeatIntervalSeconds: 15,
      maxUpdatesPerSecond: 20,
      staleAfterSeconds: 45,
      maxInstruments: 200,
    });
  });

  it("keeps the newest quote per provider and instrument without changing earlier states", () => {
    const key = quoteKey("SIMULATOR", "inst-1");
    const fresh = quote({ last_price: "101.00", received_at: "2025-01-01T03:45:02Z" });
    const snapshot = reduceFrame(initialLiveData, {
      type: "quote.snapshot",
      items: [fresh],
      missing: ["inst-9"],
      generated_at: "2025-01-01T03:45:02Z",
      request_id: "quotes.1",
    });
    expect(snapshot.quotes[key]).toBe(fresh);
    expect(snapshot.quoteMissing).toEqual(["inst-9"]);

    const late = quote({ last_price: "100.00", received_at: "2025-01-01T03:45:01Z" });
    expect(reduceFrame(snapshot, { type: "quote.update", items: [late] }).quotes[key]).toBe(fresh);

    const latest = quote({ last_price: "102.00", received_at: "2025-01-01T03:45:03Z" });
    expect(reduceFrame(snapshot, { type: "quote.update", items: [latest] }).quotes[key]).toBe(latest);
    expect(snapshot.quotes[key]).toBe(fresh);
  });

  it("merges candles per series without reopening a closed one", () => {
    const closed = candle({ is_closed: true, revision: 2 });
    let state = reduceFrame(initialLiveData, { type: "candle.closed", candle: closed });
    state = reduceFrame(state, { type: "candle.update", items: [candle({ revision: 3 })] });
    const series = state.candles[seriesKey("SIMULATOR", "inst-1", "1m")];
    expect(series?.[Date.parse(closed.bucket_start)]).toBe(closed);
  });

  it("keeps only the latest candles of a long series", () => {
    const start = Date.parse("2025-01-01T03:45:00Z");
    const items = Array.from({ length: MAX_CANDLES_PER_SERIES + 1 }, (_, index) =>
      candle({ bucket_start: new Date(start + index * 60_000).toISOString() }),
    );
    const state = reduceFrame(initialLiveData, {
      type: "candle.snapshot",
      items,
      interval: "1m",
      generated_at: "2025-01-02T00:00:00Z",
      request_id: null,
    });
    const buckets = Object.keys(state.candles[seriesKey("SIMULATOR", "inst-1", "1m")] ?? {}).map(Number);
    expect(buckets).toHaveLength(MAX_CANDLES_PER_SERIES);
    expect(Math.min(...buckets)).toBe(start + 60_000);
  });

  it("lists feed changes and signal events newest first, capped", () => {
    let state: LiveData = initialLiveData;
    for (let index = 0; index <= MAX_FEED_CHANGES; index += 1) {
      state = reduceFrame(state, {
        type: "feed.state_change",
        provider: "ZERODHA",
        account_id: "account-1",
        stream_id: "kite-ticker",
        previous_state: "CONNECTED",
        state: "RECONNECTING",
        reason: `drop ${index}`,
        at: "2025-01-01T03:45:00Z",
      });
    }
    expect(state.feedChanges).toHaveLength(MAX_FEED_CHANGES);
    expect(state.feedChanges[0]?.reason).toBe(`drop ${MAX_FEED_CHANGES}`);

    // The reducer never reads the signal itself.
    const signal = { id: "signal-1" } as unknown as Signal;
    state = reduceFrame(state, { type: "signal.update", event_type: "GENERATED", at: "2025-01-01T03:46:00Z", signal });
    expect(state.signalEvents[0]).toEqual({ eventType: "GENERATED", at: "2025-01-01T03:46:00Z", signal });
  });

  it("returns the same state for frames that carry no data", () => {
    expect(reduceFrame(initialLiveData, { type: "heartbeat", server_time: "t", request_id: null })).toBe(
      initialLiveData,
    );
  });
});
