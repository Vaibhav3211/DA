// Live data pushed over the WebSockets. ``reduceFrame`` is pure so it can be tested on its own.

import { create } from "zustand";
import type {
  Candle,
  CandleInterval,
  DataStatus,
  FeedStateChange,
  Provider,
  Signal,
  SignalEventType,
  StreamHealth,
  SystemHealth,
} from "@/lib/api/types.gen";
import { newer } from "@/lib/chart";
import type { LiveQuote, ServerFrame } from "@/lib/ws/protocol";
import type { SocketStatus } from "@/lib/ws/socket";

export type SocketName = "market" | "signals" | "system";

export interface LiveSignalEvent {
  eventType: SignalEventType;
  at: string;
  signal: Signal;
}

export interface FeedSnapshot {
  streams: StreamHealth[];
  providers: Partial<Record<Provider, DataStatus>>;
  generatedAt: string;
}

export interface ServerLimits {
  heartbeatIntervalSeconds: number;
  maxUpdatesPerSecond: number;
  staleAfterSeconds: number;
  maxInstruments: number;
}

export interface LiveData {
  quotes: Record<string, LiveQuote>;
  quoteMissing: string[];
  /** Series key -> bucket start (epoch ms) -> candle. */
  candles: Record<string, Record<number, Candle>>;
  feed: FeedSnapshot | null;
  feedChanges: FeedStateChange[];
  signalEvents: LiveSignalEvent[];
  system: SystemHealth | null;
  limits: ServerLimits | null;
}

export const MAX_FEED_CHANGES = 200;
export const MAX_SIGNAL_EVENTS = 300;
export const MAX_CANDLES_PER_SERIES = 1000;
export const DEFAULT_STALE_AFTER_SECONDS = 30;

export const quoteKey = (provider: Provider, instrumentId: string): string => `${provider}:${instrumentId}`;

export const seriesKey = (provider: Provider, instrumentId: string, interval: CandleInterval): string =>
  `${provider}:${instrumentId}:${interval}`;

export const initialLiveData: LiveData = {
  quotes: {},
  quoteMissing: [],
  candles: {},
  feed: null,
  feedChanges: [],
  signalEvents: [],
  system: null,
  limits: null,
};

function mergeQuotes(current: Record<string, LiveQuote>, items: readonly LiveQuote[]): Record<string, LiveQuote> {
  if (items.length === 0) return current;
  const next = { ...current };
  for (const quote of items) {
    const key = quoteKey(quote.provider, quote.instrument_id);
    const existing = next[key];
    // An older quote can arrive after a newer one when a snapshot races an update.
    if (existing === undefined || Date.parse(quote.received_at) >= Date.parse(existing.received_at)) next[key] = quote;
  }
  return next;
}

function mergeCandleItems(
  current: Record<string, Record<number, Candle>>,
  items: readonly Candle[],
): Record<string, Record<number, Candle>> {
  if (items.length === 0) return current;
  const next = { ...current };
  const touched = new Set<string>();
  for (const candle of items) {
    const bucket = Date.parse(candle.bucket_start);
    if (Number.isNaN(bucket)) continue;
    const key = seriesKey(candle.provider, candle.instrument_id, candle.interval);
    if (!touched.has(key)) {
      next[key] = { ...current[key] };
      touched.add(key);
    }
    const series = next[key] ?? {};
    const existing = series[bucket];
    series[bucket] = existing ? newer(existing, candle) : candle;
  }
  for (const key of touched) {
    const series = next[key];
    if (series === undefined) continue;
    const buckets = Object.keys(series).map(Number);
    if (buckets.length <= MAX_CANDLES_PER_SERIES) continue;
    buckets.sort((a, b) => a - b);
    for (const bucket of buckets.slice(0, buckets.length - MAX_CANDLES_PER_SERIES)) delete series[bucket];
  }
  return next;
}

export function reduceFrame<S extends LiveData>(state: S, frame: ServerFrame): S {
  switch (frame.type) {
    case "welcome":
      return {
        ...state,
        limits: {
          heartbeatIntervalSeconds: frame.heartbeat_interval_seconds,
          maxUpdatesPerSecond: frame.max_updates_per_second,
          staleAfterSeconds: frame.stale_after_seconds,
          maxInstruments: frame.max_instruments,
        },
      };
    case "quote.snapshot":
      return { ...state, quotes: mergeQuotes(state.quotes, frame.items), quoteMissing: frame.missing };
    case "quote.update":
      return { ...state, quotes: mergeQuotes(state.quotes, frame.items) };
    case "candle.snapshot":
    case "candle.update":
      return { ...state, candles: mergeCandleItems(state.candles, frame.items) };
    case "candle.closed":
      return { ...state, candles: mergeCandleItems(state.candles, [frame.candle]) };
    case "feed.status":
      return {
        ...state,
        feed: { streams: frame.streams, providers: frame.providers, generatedAt: frame.generated_at },
      };
    case "feed.state_change": {
      const change: FeedStateChange = {
        provider: frame.provider,
        account_id: frame.account_id,
        stream_id: frame.stream_id,
        previous_state: frame.previous_state,
        state: frame.state,
        reason: frame.reason,
        at: frame.at,
      };
      return { ...state, feedChanges: [change, ...state.feedChanges].slice(0, MAX_FEED_CHANGES) };
    }
    case "signal.update": {
      const event: LiveSignalEvent = { eventType: frame.event_type, at: frame.at, signal: frame.signal };
      return { ...state, signalEvents: [event, ...state.signalEvents].slice(0, MAX_SIGNAL_EVENTS) };
    }
    case "system.status":
      return { ...state, system: frame.health };
    default:
      return state;
  }
}

interface LiveStore extends LiveData {
  sockets: Record<SocketName, SocketStatus>;
  apply: (frame: ServerFrame) => void;
  setSocket: (name: SocketName, status: SocketStatus) => void;
  reset: () => void;
}

export const useLiveStore = create<LiveStore>()((set) => ({
  ...initialLiveData,
  sockets: { market: "idle", signals: "idle", system: "idle" },
  apply: (frame) => set((state) => reduceFrame(state, frame)),
  setSocket: (name, status) => set((state) => ({ sockets: { ...state.sockets, [name]: status } })),
  reset: () => set({ ...initialLiveData }),
}));

export function useSocketStatus(name: SocketName): SocketStatus {
  return useLiveStore((state) => state.sockets[name]);
}

export function useStaleAfterSeconds(): number {
  return useLiveStore((state) => state.limits?.staleAfterSeconds ?? DEFAULT_STALE_AFTER_SECONDS);
}
