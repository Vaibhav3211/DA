"use client";

import { useQueryClient, type QueryClient } from "@tanstack/react-query";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { queryKeys } from "@/lib/api/hooks";
import { humanize } from "@/lib/format";
import { notify } from "@/lib/notifications";
import { redirectToLogin } from "@/lib/utils";
import { channelOf, type ServerFrame, type Subscription } from "@/lib/ws/protocol";
import { LiveSocket } from "@/lib/ws/socket";
import { useLiveStore, type SocketName } from "./store";

type LiveSockets = Record<SocketName, LiveSocket>;

const LiveContext = createContext<LiveSockets | null>(null);

const SOCKET_PATHS: Record<SocketName, string> = {
  market: "/ws/v1/market",
  signals: "/ws/v1/signals",
  system: "/ws/v1/system",
};

/**
 * The API's WebSocket origin: NEXT_PUBLIC_WS_URL, else this host on port 8000. The Next.js proxy
 * does not carry WebSockets; the session cookie still reaches the API because cookies ignore ports.
 */
export function wsBaseUrl(): string {
  const configured = process.env.NEXT_PUBLIC_WS_URL;
  if (configured) return configured.replace(/\/+$/, "");
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  return `${protocol}//${window.location.hostname}:8000`;
}

function throttled(action: () => void, ms: number): () => void {
  let timer: ReturnType<typeof setTimeout> | null = null;
  return () => {
    if (timer !== null) return;
    timer = setTimeout(() => {
      timer = null;
      action();
    }, ms);
  };
}

const FEED_WAS_DOWN = new Set(["RECONNECTING", "DISCONNECTED", "AUTH_REQUIRED"]);

/** Notices for pushed events that need attention. Keys collapse repeats of the same event. */
export function noticeFor(frame: ServerFrame): void {
  switch (frame.type) {
    case "error": {
      const channel = channelOf(frame.request_id);
      notify(
        "error",
        `Live ${channel ?? "data"}: ${humanize(frame.code)}`,
        frame.message,
        `ws-error:${channel ?? ""}:${frame.code}`,
      );
      break;
    }
    case "feed.state_change": {
      const key = `feed:${frame.provider}:${frame.stream_id}`;
      if (frame.state === "AUTH_REQUIRED") {
        notify("warning", `${frame.provider} needs you to sign in again`, frame.reason, key);
      } else if (frame.state === "DISCONNECTED") {
        notify("warning", `${frame.provider} feed disconnected`, frame.reason, key);
      } else if (frame.state === "CONNECTED" && FEED_WAS_DOWN.has(frame.previous_state)) {
        notify("success", `${frame.provider} feed connected`, null, key);
      }
      break;
    }
    case "signal.update": {
      const { signal } = frame;
      if (frame.event_type === "GENERATED") {
        notify(
          "info",
          `${signal.signal_type} ${signal.symbol}`,
          `${signal.strategy_id} · ${signal.is_actionable ? "actionable" : "informational only"}`,
          `signal:${signal.id}`,
        );
      } else if (frame.event_type === "BLOCKED") {
        notify("warning", `Risk gate blocked ${signal.signal_type} ${signal.symbol}`, signal.strategy_id, `signal:${signal.id}`);
      }
      break;
    }
    default:
      break;
  }
}

function createSockets(queryClient: QueryClient): LiveSockets {
  const refreshAll = throttled(() => void queryClient.invalidateQueries(), 1000);
  const refreshSignals = throttled(() => void queryClient.invalidateQueries({ queryKey: queryKeys.signals }), 1500);
  const refreshProviders = throttled(
    () => void queryClient.invalidateQueries({ queryKey: queryKeys.providers }),
    1500,
  );

  const onFrame = (frame: ServerFrame) => {
    const engagedBefore = useLiveStore.getState().system?.kill_switch?.engaged;
    useLiveStore.getState().apply(frame);
    noticeFor(frame);
    if (frame.type === "signal.update") {
      refreshSignals();
    } else if (frame.type === "feed.state_change") {
      refreshProviders();
    } else if (frame.type === "system.status") {
      const killSwitch = frame.health.kill_switch;
      queryClient.setQueryData(queryKeys.health, frame.health);
      if (killSwitch) queryClient.setQueryData(queryKeys.killSwitch, killSwitch);
      if (killSwitch && engagedBefore !== undefined && killSwitch.engaged !== engagedBefore) {
        notify(
          killSwitch.engaged ? "error" : "success",
          killSwitch.engaged ? "Kill switch engaged" : "Kill switch released",
          killSwitch.reason,
          "kill-switch",
        );
      }
    }
  };

  const make = (name: SocketName) =>
    new LiveSocket({
      url: () => `${wsBaseUrl()}${SOCKET_PATHS[name]}`,
      onFrame,
      onStatus: (status) => useLiveStore.getState().setSocket(name, status),
      // Updates pushed while disconnected were missed: reload everything shown.
      onReconnect: refreshAll,
      onUnauthorized: redirectToLogin,
    });
  return { market: make("market"), signals: make("signals"), system: make("system") };
}

export function LiveProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [sockets] = useState(() => createSockets(queryClient));

  useEffect(() => {
    // Always on: feed health, system status and signals from every workspace.
    sockets.market.subscribe({ channel: "feed" });
    sockets.signals.subscribe({ channel: "signals" });
    sockets.system.subscribe({ channel: "system" });
    const all = Object.values(sockets);
    for (const socket of all) socket.start();
    const online = () => {
      for (const socket of all) socket.retryNow();
    };
    window.addEventListener("online", online);
    return () => {
      window.removeEventListener("online", online);
      for (const socket of all) socket.stop();
    };
  }, [sockets]);

  return <LiveContext.Provider value={sockets}>{children}</LiveContext.Provider>;
}

export function useLiveSockets(): LiveSockets {
  const sockets = useContext(LiveContext);
  if (sockets === null) throw new Error("useLiveSockets must be used inside <LiveProvider>");
  return sockets;
}

/** Holds a subscription while the component is mounted; null holds none. */
export function useLiveSubscription(name: SocketName, subscription: Subscription | null): void {
  const sockets = useLiveSockets();
  const key = subscription === null ? null : JSON.stringify(subscription);
  useEffect(() => {
    if (key === null) return;
    const parsed = JSON.parse(key) as Subscription;
    const socket = sockets[name];
    socket.subscribe(parsed);
    return () => socket.unsubscribe(parsed.channel);
  }, [sockets, name, key]);
}
