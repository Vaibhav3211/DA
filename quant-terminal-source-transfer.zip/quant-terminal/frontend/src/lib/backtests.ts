// Backtests for display: states, metrics with their definitions, the trade-rules form, dataset coverage, the
// equity curve and backtest trades on the chart. The definitions follow docs/backtesting.md. Nothing here
// runs a backtest: only queueing one does.

import type { LineData, UTCTimestamp } from "lightweight-charts";
import type {
  BacktestRunView,
  BacktestState,
  BacktestStatus,
  BacktestTrade,
  CandleInterval,
  DatasetCoverage,
  DatasetSource,
  DatasetStatus,
  EquityPoint,
  ExitCheck,
  ExitReason,
  FillTiming,
  Measure,
  OppositeSignal,
  Provider,
  SizingMethod,
  StopTargetSource,
  TradeOutcome,
  TradeRules,
  TradeRulesBody,
  TradeRulesSource,
  TradeSides,
} from "@/lib/api/types.gen";
import { CHART_COLORS, barTimeAtOrBefore, toSeconds, type ChartMarker } from "@/lib/chart";
import { formatDateTime, formatInteger, formatPrice, humanize } from "@/lib/format";
import { formatParams } from "@/lib/strategies";

export type Tone = "success" | "warning" | "destructive" | "info" | "secondary";

export interface Row {
  label: string;
  value: string;
}

// ---- states ------------------------------------------------------------------------------------------------

export const STATE_TEXT: Readonly<Record<BacktestState, { label: string; meaning: string; tone: Tone }>> = {
  CURRENT: {
    label: "Current",
    meaning: "A backtest with the configuration's current settings succeeded.",
    tone: "success",
  },
  OUTDATED: {
    label: "Outdated",
    meaning: "Backtests succeeded, but the settings changed since. The latest is kept for comparison.",
    tone: "warning",
  },
  NOT_BACKTESTED: {
    label: "Not backtested",
    meaning: "No backtest of this configuration on this instrument has succeeded.",
    tone: "secondary",
  },
};

export const STATUS_TONE: Readonly<Record<BacktestStatus | DatasetStatus, Tone>> = {
  QUEUED: "secondary",
  PENDING: "secondary",
  RUNNING: "info",
  BUILDING: "info",
  SUCCEEDED: "success",
  READY: "success",
  FAILED: "destructive",
};

/** Whether a backtest or dataset still waits or is being worked on, so its state is worth polling. */
export function isActive(status: BacktestStatus | DatasetStatus): boolean {
  return status === "QUEUED" || status === "RUNNING" || status === "PENDING" || status === "BUILDING";
}

export const RULES_SOURCE_TEXT: Readonly<Record<TradeRulesSource, string>> = {
  CONFIGURATION: "The configuration's own",
  STRATEGY: "The strategy's declared defaults (the configuration has none of its own)",
};

export const EXIT_REASON_TEXT: Readonly<Record<ExitReason, string>> = {
  STOP_LOSS: "Stop-loss",
  TARGET: "Target",
  EXIT_SIGNAL: "Exit signal",
  OPPOSITE_SIGNAL: "Opposite signal",
  MAX_HOLDING: "Holding limit",
};

export const OUTCOME_TONE: Readonly<Record<TradeOutcome, Tone>> = {
  WIN: "success",
  LOSS: "destructive",
  BREAKEVEN: "secondary",
};

// ---- data sources ----------------------------------------------------------------------------------------

interface DataOrigin {
  provider: Provider;
  source: DatasetSource;
  simulated: boolean;
}

export function isSimulated(origin: DataOrigin): boolean {
  return origin.simulated || origin.source === "SIMULATED";
}

/** Where candles came from, in a few words. Simulator candles are always SIMULATED. */
export function dataLabel(origin: DataOrigin): string {
  if (isSimulated(origin)) return "SIMULATED";
  return `${humanize(origin.provider)} ${origin.source === "RECORDED" ? "recorded feed" : "history"}`;
}

/** Where candles came from, in a sentence. */
export function sourceText(origin: DataOrigin): string {
  if (isSimulated(origin)) return "SIMULATED: candles recorded from the development simulator, not market history";
  if (origin.source === "RECORDED") return `Candles recorded from the ${humanize(origin.provider)} live feed`;
  return `The ${humanize(origin.provider)} historical-candle API`;
}

export const DATASET_SOURCE_TEXT: Readonly<Record<DatasetSource, string>> = {
  PROVIDER_HISTORY: "Downloaded from the provider's historical-candle API when you ask",
  RECORDED: "Candles the platform built from a live provider feed",
  SIMULATED: "Candles recorded from the development simulator; never real history",
};

// ---- metrics ---------------------------------------------------------------------------------------------

/** A metric that may be undefined: its value with ``unit``, or "Undefined" and the reason. */
export function measureText(measure: Measure, unit = ""): { text: string; reason: string | null } {
  if (measure.value === null) return { text: "Undefined", reason: measure.reason ?? "No reason recorded" };
  return { text: `${formatPrice(measure.value)}${unit}`, reason: null };
}

/** A profit or loss with its sign: +1,250.00, -310.50 or 0.00. */
export function formatPnl(value: string): string {
  const text = formatPrice(value);
  return Number(value) > 0 ? `+${text}` : text;
}

export const METRIC_DEFINITIONS = {
  closedTrades:
    "Trades with an entry and an exit. The position still open at the end is not one, and signals are not trades.",
  outcome: "A win, loss or breakeven is a net result (after fees and slippage) above, below or at 0.00.",
  winRate:
    "Winning closed trades ÷ all closed trades × 100. Breakeven trades count in the denominator; signals and the open position do not.",
  averageWin: "The mean net result of the winning trades.",
  averageLoss: "The mean net result of the losing trades (negative).",
  net: "The closed trades' results after fees and slippage; the return is over the initial capital.",
  gross: "The closed trades' results at reference prices, before fees and slippage; the return is over the initial capital.",
  profitFactor: "Net result of the winning trades ÷ |net result of the losing trades|.",
  maxDrawdown:
    "The largest fall of the equity from an earlier peak, with equity marked at every candle's close (the open position included). Falls inside a candle are not seen.",
} as const;

// ---- trade rules -----------------------------------------------------------------------------------------

export type RuleChoiceField = "sides" | "opposite_signal" | "fill" | "exit_check" | "stop_target" | "sizing";
export type RuleNumberField =
  | "stop_pct"
  | "target_pct"
  | "max_holding_candles"
  | "quantity"
  | "amount"
  | "risk_pct"
  | "initial_capital"
  | "fee_pct_per_side"
  | "fee_per_order"
  | "slippage_ticks";
export type RuleField = RuleChoiceField | RuleNumberField;

/** The form's values as typed: choices are "" until one is picked, and nothing is assumed. */
export type TradeRulesDraft = Record<RuleField, string>;

export interface Choice {
  value: string;
  label: string;
  meaning: string;
}

/** The trade rules in form order. */
export const RULE_FIELDS: readonly RuleField[] = [
  "sides",
  "opposite_signal",
  "fill",
  "exit_check",
  "stop_target",
  "stop_pct",
  "target_pct",
  "max_holding_candles",
  "sizing",
  "quantity",
  "amount",
  "risk_pct",
  "initial_capital",
  "fee_pct_per_side",
  "fee_per_order",
  "slippage_ticks",
];

interface ChoiceRule {
  label: string;
  meaning: string;
  choices: readonly Choice[];
}

export const RULE_CHOICES: Readonly<Record<RuleChoiceField, ChoiceRule>> = {
  sides: {
    label: "Sides",
    meaning: "Which sides may be traded.",
    choices: [
      { value: "LONG_ONLY", label: "Long only", meaning: "Only long positions are opened." },
      { value: "SHORT_ONLY", label: "Short only", meaning: "Only short positions are opened." },
      { value: "BOTH", label: "Long and short", meaning: "Positions are opened on either side." },
    ],
  },
  opposite_signal: {
    label: "Opposite signal",
    meaning: "What a signal against the open position does.",
    choices: [
      {
        value: "REVERSE",
        label: "Reverse",
        meaning: "Close it and open the other side (when that side may be traded).",
      },
      { value: "CLOSE", label: "Close only", meaning: "Only close it." },
    ],
  },
  fill: {
    label: "Fills",
    meaning: "When decisions taken at a candle's close fill.",
    choices: [
      { value: "NEXT_OPEN", label: "Next open", meaning: "At the next candle's open." },
      {
        value: "SAME_CLOSE",
        label: "Same close (optimistic)",
        meaning: "At the close they were taken at, which real orders could not do.",
      },
    ],
  },
  exit_check: {
    label: "Stop and target check",
    meaning: "How the stop-loss and target are checked.",
    choices: [
      {
        value: "INTRABAR",
        label: "Within the candle",
        meaning:
          "Against each candle's high and low. When one candle touches both, the stop-loss is assumed first; a gap through a level fills at the open.",
      },
      {
        value: "CLOSE",
        label: "At the close",
        meaning: "Against the close only; the exit then fills like any decision.",
      },
    ],
  },
  stop_target: {
    label: "Stop and target",
    meaning: "Where the stop-loss and target come from.",
    choices: [
      { value: "SIGNAL", label: "The signal's levels", meaning: "The entry signal's stop-loss and first target." },
      { value: "PERCENT", label: "Fixed percentages", meaning: "Distances from the entry fill, in %." },
      {
        value: "NONE",
        label: "None",
        meaning: "No stop-loss or target: exits come from signals or the holding limit.",
      },
    ],
  },
  sizing: {
    label: "Sizing",
    meaning: "How many units an entry takes, rounded down to the lot size.",
    choices: [
      { value: "FIXED_QUANTITY", label: "Fixed quantity", meaning: "The same units for every entry." },
      { value: "FIXED_AMOUNT", label: "Fixed amount", meaning: "As many units as the amount buys at the entry fill." },
      {
        value: "RISK_PERCENT",
        label: "Equity at risk",
        meaning: "Units whose loss at the stop-loss is this share of the equity.",
      },
    ],
  },
};

interface NumberRule {
  label: string;
  meaning: string;
  kind: "decimal" | "integer";
  min: string;
  minInclusive: boolean;
  max: string | null;
  maxInclusive: boolean;
  optional: boolean;
}

// The bounds of TradeRules in backend/app/domain/models/backtest.py.
export const NUMBER_RULES: Readonly<Record<RuleNumberField, NumberRule>> = {
  stop_pct: {
    label: "Stop-loss %",
    meaning: "Stop-loss distance from the entry fill, in %.",
    kind: "decimal",
    min: "0",
    minInclusive: false,
    max: "100",
    maxInclusive: false,
    optional: true,
  },
  target_pct: {
    label: "Target %",
    meaning: "Target distance from the entry fill, in %.",
    kind: "decimal",
    min: "0",
    minInclusive: false,
    max: "1000",
    maxInclusive: true,
    optional: true,
  },
  max_holding_candles: {
    label: "Holding limit (candles)",
    meaning: "Close a position after this many candles. Leave empty for no limit.",
    kind: "integer",
    min: "1",
    minInclusive: true,
    max: "100000",
    maxInclusive: true,
    optional: true,
  },
  quantity: {
    label: "Quantity",
    meaning: "Units per entry.",
    kind: "integer",
    min: "1",
    minInclusive: true,
    max: null,
    maxInclusive: false,
    optional: false,
  },
  amount: {
    label: "Amount per entry",
    meaning: "Value per entry.",
    kind: "decimal",
    min: "0",
    minInclusive: false,
    max: null,
    maxInclusive: false,
    optional: false,
  },
  risk_pct: {
    label: "Equity at risk %",
    meaning: "Equity lost at the stop-loss, in %.",
    kind: "decimal",
    min: "0",
    minInclusive: false,
    max: "100",
    maxInclusive: true,
    optional: false,
  },
  initial_capital: {
    label: "Initial capital",
    meaning: "Equity at the start.",
    kind: "decimal",
    min: "0",
    minInclusive: false,
    max: null,
    maxInclusive: false,
    optional: false,
  },
  fee_pct_per_side: {
    label: "Fee % per side",
    meaning: "Fee on each fill's value, in %.",
    kind: "decimal",
    min: "0",
    minInclusive: true,
    max: "10",
    maxInclusive: true,
    optional: false,
  },
  fee_per_order: {
    label: "Fee per order",
    meaning: "Fixed fee per order.",
    kind: "decimal",
    min: "0",
    minInclusive: true,
    max: null,
    maxInclusive: false,
    optional: false,
  },
  slippage_ticks: {
    label: "Slippage (ticks)",
    meaning: "Ticks each fill moves against the trade.",
    kind: "integer",
    min: "0",
    minInclusive: true,
    max: "1000",
    maxInclusive: true,
    optional: false,
  },
};

export function isChoiceField(field: RuleField): field is RuleChoiceField {
  return field in RULE_CHOICES;
}

export function ruleLabel(field: RuleField): string {
  return isChoiceField(field) ? RULE_CHOICES[field].label : NUMBER_RULES[field].label;
}

/** Whether a rule applies under the chosen stop/target source and sizing; the others are not sent. */
export function ruleApplies(field: RuleField, chosen: { stop_target: string; sizing: string }): boolean {
  switch (field) {
    case "stop_pct":
    case "target_pct":
      return chosen.stop_target === "PERCENT";
    case "quantity":
      return chosen.sizing === "FIXED_QUANTITY";
    case "amount":
      return chosen.sizing === "FIXED_AMOUNT";
    case "risk_pct":
      return chosen.sizing === "RISK_PERCENT";
    default:
      return true;
  }
}

/** "A number more than 0 and less than 100": a number rule's bounds, for the form. */
export function rangeText(field: RuleNumberField): string {
  const rule = NUMBER_RULES[field];
  const low = `${rule.minInclusive ? "at least" : "more than"} ${rule.min}`;
  const high = rule.max === null ? "" : ` and ${rule.maxInclusive ? "at most" : "less than"} ${rule.max}`;
  return `${rule.kind === "integer" ? "A whole number" : "A number"} ${low}${high}`;
}

const DECIMAL = /^\d+(\.\d+)?$/;
const INTEGER = /^\d+$/;

/** Compares two non-negative plain decimals exactly (no float rounding): negative, 0 or positive. */
export function compareDecimals(a: string, b: string): number {
  const [aWhole = "0", aFraction = ""] = a.split(".");
  const [bWhole = "0", bFraction = ""] = b.split(".");
  const left = aWhole.replace(/^0+(?=\d)/, "");
  const right = bWhole.replace(/^0+(?=\d)/, "");
  if (left.length !== right.length) return left.length - right.length;
  if (left !== right) return left < right ? -1 : 1;
  const width = Math.max(aFraction.length, bFraction.length);
  const x = aFraction.padEnd(width, "0");
  const y = bFraction.padEnd(width, "0");
  return x === y ? 0 : x < y ? -1 : 1;
}

function numberProblem(field: RuleNumberField, text: string): string | null {
  const rule = NUMBER_RULES[field];
  if (rule.kind === "integer" ? !INTEGER.test(text) : !DECIMAL.test(text)) {
    return rule.kind === "integer" ? "Enter a whole number." : "Enter a plain number, such as 1.5.";
  }
  if (rule.kind === "integer" && !Number.isSafeInteger(Number(text))) return "Too large.";
  const low = compareDecimals(text, rule.min);
  if (low < 0 || (low === 0 && !rule.minInclusive)) {
    return `Must be ${rule.minInclusive ? "at least" : "more than"} ${rule.min}.`;
  }
  if (rule.max !== null) {
    const high = compareDecimals(text, rule.max);
    if (high > 0 || (high === 0 && !rule.maxInclusive)) {
      return `Must be ${rule.maxInclusive ? "at most" : "less than"} ${rule.max}.`;
    }
  }
  return null;
}

/** A form draft of saved rules, or an empty one: every choice unpicked and every number blank. */
export function draftFromRules(rules: TradeRules | null): TradeRulesDraft {
  const draft = {} as TradeRulesDraft;
  for (const field of RULE_FIELDS) {
    const value = rules === null ? null : rules[field];
    draft[field] = value === null || value === undefined ? "" : String(value);
  }
  return draft;
}

export interface RulesCheck {
  /** The request body when the draft is complete and valid; decimals are sent as typed, never as floats. */
  body: TradeRulesBody | null;
  errors: Partial<Record<RuleField, string>>;
  /** Problems across fields. */
  problems: string[];
}

/** Checks a draft as the API does (bounds and consistency), so mistakes show before saving. */
export function checkTradeRules(draft: TradeRulesDraft): RulesCheck {
  const errors: Partial<Record<RuleField, string>> = {};
  const values: Partial<Record<RuleNumberField, string>> = {};
  for (const field of RULE_FIELDS) {
    if (!ruleApplies(field, draft)) continue;
    const text = draft[field].trim();
    if (isChoiceField(field)) {
      if (!RULE_CHOICES[field].choices.some((choice) => choice.value === text)) errors[field] = "Choose one.";
      continue;
    }
    if (text === "") {
      if (!NUMBER_RULES[field].optional) errors[field] = "Required.";
      continue;
    }
    const problem = numberProblem(field, text);
    if (problem === null) values[field] = text;
    else errors[field] = problem;
  }
  const problems: string[] = [];
  const percent = draft.stop_target === "PERCENT";
  if (percent && draft.stop_pct.trim() === "" && draft.target_pct.trim() === "") {
    problems.push("Fixed percentages need a stop-loss %, a target % or both.");
  }
  if (draft.sizing === "RISK_PERCENT" && (draft.stop_target === "NONE" || (percent && draft.stop_pct.trim() === ""))) {
    problems.push("Sizing by equity at risk needs a stop-loss: the signal's levels, or a stop-loss %.");
  }
  if (Object.keys(errors).length > 0 || problems.length > 0) return { body: null, errors, problems };
  const whole = (text: string | undefined) => (text === undefined ? null : Number(text));
  return {
    body: {
      sides: draft.sides as TradeSides,
      opposite_signal: draft.opposite_signal as OppositeSignal,
      fill: draft.fill as FillTiming,
      exit_check: draft.exit_check as ExitCheck,
      stop_target: draft.stop_target as StopTargetSource,
      stop_pct: values.stop_pct ?? null,
      target_pct: values.target_pct ?? null,
      max_holding_candles: whole(values.max_holding_candles),
      sizing: draft.sizing as SizingMethod,
      quantity: whole(values.quantity),
      amount: values.amount ?? null,
      risk_pct: values.risk_pct ?? null,
      initial_capital: values.initial_capital ?? "",
      fee_pct_per_side: values.fee_pct_per_side ?? "",
      fee_per_order: values.fee_per_order ?? "",
      slippage_ticks: Number(values.slippage_ticks),
    },
    errors,
    problems,
  };
}

/** Saved rules as label/value rows, leaving out the rules their methods do not use. */
export function ruleRows(rules: TradeRules): Row[] {
  return RULE_FIELDS.filter((field) => ruleApplies(field, rules)).map((field) => {
    const value = rules[field];
    if (isChoiceField(field)) {
      const choice = RULE_CHOICES[field].choices.find((item) => item.value === value);
      return { label: ruleLabel(field), value: choice ? choice.label : String(value) };
    }
    if (value === null) return { label: ruleLabel(field), value: field === "max_holding_candles" ? "No limit" : "—" };
    return { label: ruleLabel(field), value: String(value) };
  });
}

/** The trade rules a run recorded, when they have every rule; null when missing or from another shape. */
export function recordedRules(settings: Record<string, unknown>): TradeRules | null {
  const raw = settings.trade_rules;
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) return null;
  return RULE_FIELDS.every((field) => field in raw) ? (raw as TradeRules) : null;
}

// ---- settings and what changed ---------------------------------------------------------------------------

function mapping(value: unknown): Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}

function plain(value: unknown): string {
  return value === undefined || value === null ? "—" : String(value);
}

function riskState(state: unknown): string {
  if (typeof state !== "object" || state === null) return "not recorded";
  const item = mapping(state);
  if (!item.enabled) return "off";
  if ("error" in item) return `on, with invalid parameters: ${plain(item.error)}`;
  const params = formatParams(mapping(item.params));
  return params ? `on (${params})` : "on";
}

/** The parameters a run recorded, such as "fast=9, slow=21", or "none". */
export function recordedParams(settings: Record<string, unknown>): string {
  return formatParams(mapping(mapping(settings.configuration).config)) || "none";
}

/** What a run recorded besides its trade rules: parameters, lot and tick, signal validity, engine, risk rules. */
export function settingsRows(settings: Record<string, unknown>): Row[] {
  const configuration = mapping(settings.configuration);
  const instrument = mapping(settings.instrument);
  const source = settings.trade_rules_source;
  const params = recordedParams(settings);
  const rows: Row[] = [
    { label: "Parameters", value: `${params} (configuration hash ${plain(configuration.config_hash)})` },
    {
      label: "Lot and tick",
      value: `Lot size ${plain(instrument.lot_size)}, tick size ${plain(instrument.tick_size)}`,
    },
    {
      label: "Signal validity",
      value: `${plain(settings.signal_validity_seconds)} seconds, for signals that do not say how long they are valid`,
    },
    { label: "Engine", value: `Version ${plain(settings.engine_version)}` },
    {
      label: "Trade rules",
      value: source === "CONFIGURATION" || source === "STRATEGY" ? RULES_SOURCE_TEXT[source] : "Not recorded",
    },
  ];
  Object.entries(mapping(settings.risk))
    .sort(([a], [b]) => a.localeCompare(b))
    .forEach(([key, state], index) => {
      rows.push({ label: index === 0 ? "Risk rules" : "", value: `${key}: ${riskState(state)}` });
    });
  const notApplied = settings.risk_not_applied;
  if (Array.isArray(notApplied) && notApplied.length > 0) {
    rows.push({
      label: "Not applied",
      value: `${notApplied.map(String).join(", ")}: rules about the live system do not apply to history`,
    });
  }
  return rows;
}

/** A changed setting's dotted path, such as ``trade_rules.fill`` or ``configuration.config.fast``, in words. */
export function changedLabel(path: string): string {
  const [root = "", ...rest] = path.split(".");
  const tail = rest.join(".");
  switch (root) {
    case "engine_version":
      return "Backtest engine version";
    case "signal_validity_seconds":
      return "Signal validity";
    case "strategy":
      if (tail === "version") return "Strategy version";
      if (tail === "fingerprint") return "Strategy code (fingerprint)";
      return "Strategy";
    case "configuration":
      return rest[0] === "config" && rest.length > 1 ? `Parameter ${rest.slice(1).join(".")}` : "Parameters";
    case "instrument":
      if (tail === "interval") return "Candle interval";
      if (tail === "lot_size") return "Lot size";
      if (tail === "tick_size") return "Tick size";
      return "Instrument";
    case "trade_rules": {
      const field = RULE_FIELDS.find((name) => name === rest[0]);
      return field === undefined ? "Trade rules" : `Trade rule: ${ruleLabel(field)}`;
    }
    case "risk":
      return rest[0] ? `Risk rule ${rest[0]}` : "Risk rules";
    default:
      return path;
  }
}

// ---- dataset coverage ------------------------------------------------------------------------------------

/** The share of the candles the exchange calendar expects that a dataset has, in one line. */
export function coverageText(coverage: DatasetCoverage): string {
  if (!coverage.expected) return "The calendar expects no candles on these dates";
  const share = coverage.coverage_pct === null ? "—" : `${coverage.coverage_pct}%`;
  return (
    `${share}: ${formatInteger(coverage.present)} of the ${formatInteger(coverage.expected)} candles the calendar ` +
    `expects on ${formatInteger(coverage.session_days)} session days; ${formatInteger(coverage.missing)} missing in ` +
    `${formatInteger(coverage.gap_total)} gaps`
  );
}

function daysText(days: readonly string[], total: number): string {
  const more = total > days.length ? `, and ${formatInteger(total - days.length)} more` : "";
  return `${formatInteger(total)} days: ${days.join(", ")}${more}`;
}

/** Everything about a dataset's coverage beyond the headline, as labelled rows: gaps first. */
export function coverageRows(coverage: DatasetCoverage): Row[] {
  const rows: Row[] = [];
  if (coverage.anchor !== null) {
    rows.push({ label: "Candle grid", value: `${coverage.anchor} (intraday candles start on it)` });
  }
  coverage.gaps.forEach((gap, index) => {
    rows.push({
      label: index === 0 ? "Gaps" : "",
      value: `${formatDateTime(gap.start)} to ${formatDateTime(gap.end)}: ${formatInteger(gap.candles)} missing`,
    });
  });
  const unlisted = coverage.gap_total - coverage.gaps.length;
  if (unlisted > 0) rows.push({ label: "", value: `… and ${formatInteger(unlisted)} more gaps, not listed` });
  if (coverage.assumed_days_total) {
    rows.push({ label: "Assumed hours", value: daysText(coverage.assumed_days, coverage.assumed_days_total) });
  }
  if (coverage.unknown_days_total) {
    rows.push({
      label: "No calendar",
      value: `${daysText(coverage.unknown_days, coverage.unknown_days_total)} (their candles are kept, unverified)`,
    });
  }
  if (coverage.left_out) {
    const reasons = Object.entries(coverage.left_out_by_reason)
      .map(([reason, count]) => `${reason} ${formatInteger(count)}`)
      .join(", ");
    rows.push({ label: "Left out", value: `${formatInteger(coverage.left_out)} source candles (${reasons})` });
    coverage.left_out_examples.forEach((example) => {
      rows.push({ label: "", value: example });
    });
  }
  rows.push({
    label: "Flagged",
    value:
      `${formatInteger(coverage.duplicates)} duplicates (kept once), ` +
      `${formatInteger(coverage.inconsistent)} inconsistent (high and low do not contain the open and close), ` +
      `${formatInteger(coverage.without_volume)} without volume, ` +
      `${formatInteger(coverage.incomplete)} incomplete (recorded with partial coverage)`,
  });
  if (coverage.requests) rows.push({ label: "Requests", value: `${formatInteger(coverage.requests)} to the provider` });
  coverage.notes.forEach((note, index) => {
    rows.push({ label: index === 0 ? "Notes" : "", value: note });
  });
  return rows;
}

// ---- equity curve and chart markers ----------------------------------------------------------------------

/** The equity curve as line data, oldest first; of points in the same second, the last listed is kept. */
export function equitySeries(points: readonly EquityPoint[]): LineData<UTCTimestamp>[] {
  const bySecond = new Map<number, number>();
  for (const point of points) {
    const time = toSeconds(point.at);
    const value = Number(point.equity);
    if (Number.isFinite(time) && Number.isFinite(value)) bySecond.set(time, value);
  }
  return [...bySecond.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([time, value]) => ({ time: time as UTCTimestamp, value }));
}

export type TradeLeg = "entry" | "exit";

export interface BacktestMarkerRef {
  runId: string;
  trade: number;
  leg: TradeLeg;
}

const MARKER_ID = /^bt:([^:]+):(\d+):(entry|exit)$/;

export function backtestMarkerId(runId: string, trade: number, leg: TradeLeg): string {
  return `bt:${runId}:${trade}:${leg}`;
}

/** The backtest trade a chart marker stands for; null for a live signal's marker. */
export function parseBacktestMarkerId(id: string): BacktestMarkerRef | null {
  const match = MARKER_ID.exec(id);
  return match ? { runId: match[1], trade: Number(match[2]), leg: match[3] as TradeLeg } : null;
}

/**
 * Muted "BT" circles for a backtest's trades: the entry below a long's bar and above a short's, the exit on the
 * other side. Fills are dated by the start of the candle they happened in, so each goes on the chart bar that
 * contains that moment (sorted ``barTimes`` of ``barSeconds`` each); fills outside the bars are left out. Each
 * marker's text is ``prefix`` then BT and the trade number.
 */
export function backtestMarkers(
  runId: string,
  trades: readonly BacktestTrade[],
  barTimes: readonly number[],
  barSeconds: number,
  prefix = "",
): ChartMarker[] {
  const place = (iso: string): UTCTimestamp | null => {
    const seconds = toSeconds(iso);
    const bar = barTimeAtOrBefore(barTimes, seconds);
    return bar === null || seconds - bar >= barSeconds ? null : (bar as UTCTimestamp);
  };
  const markers: ChartMarker[] = [];
  for (const trade of trades) {
    const long = trade.side === "LONG";
    const text = `${prefix}BT${trade.number}`;
    const entry = place(trade.entry_at);
    if (entry !== null) {
      markers.push({
        id: backtestMarkerId(runId, trade.number, "entry"),
        time: entry,
        position: long ? "belowBar" : "aboveBar",
        shape: "circle",
        color: long ? CHART_COLORS.backtestLong : CHART_COLORS.backtestShort,
        text,
      });
    }
    const exit = place(trade.exit_at);
    if (exit !== null) {
      markers.push({
        id: backtestMarkerId(runId, trade.number, "exit"),
        time: exit,
        position: long ? "aboveBar" : "belowBar",
        shape: "circle",
        color: CHART_COLORS.backtestExit,
        text,
      });
    }
  }
  return markers.sort((a, b) => a.time - b.time);
}

/** The newest closed trades of an applied configuration's backtest loaded for the chart. */
export const CHART_TRADE_LIMIT = 200;

/** Whether the chart draws a configuration's backtest trades, and which page of them; else why not. */
export type ChartBacktest =
  | { drawn: true; run: BacktestRunView; offset: number; limit: number }
  | { drawn: false; reason: string };

/**
 * The chart draws only the current backtest's trades (never an outdated one's), only when it replayed the
 * chart's own interval and provider, so its trades line up with the bars shown, and only its newest
 * ``CHART_TRADE_LIMIT`` closed trades. The reason reads after "Backtest trades not drawn: ".
 */
export function chartBacktest(
  latest: { state: BacktestState; current: BacktestRunView | null },
  chart: { interval: CandleInterval; provider: Provider },
): ChartBacktest {
  const run = latest.current;
  if (run === null) {
    return {
      drawn: false,
      reason:
        latest.state === "OUTDATED"
          ? "its backtests are outdated; run one with the current settings to draw its trades"
          : "not backtested",
    };
  }
  if (run.interval !== chart.interval) {
    return {
      drawn: false,
      reason: `its backtest replayed ${run.interval} candles; switch the chart to ${run.interval} to draw its trades`,
    };
  }
  if (run.provider !== chart.provider) {
    return {
      drawn: false,
      reason: `its backtest replayed ${dataLabel(run)} candles, not this chart's ${humanize(chart.provider)} feed`,
    };
  }
  if (run.trade_count === 0) return { drawn: false, reason: "its backtest closed no trades" };
  return { drawn: true, run, offset: Math.max(0, run.trade_count - CHART_TRADE_LIMIT), limit: CHART_TRADE_LIMIT };
}
