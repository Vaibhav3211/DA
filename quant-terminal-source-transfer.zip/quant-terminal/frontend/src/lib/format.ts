// Display formatting. Prices arrive as decimal strings and are shown without a float round-trip;
// times are shown in IST, the exchanges' timezone.

export const IST = "Asia/Kolkata";
const DASH = "—";

const timeFormat = new Intl.DateTimeFormat("en-IN", {
  timeZone: IST,
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});
const dateTimeFormat = new Intl.DateTimeFormat("en-IN", {
  timeZone: IST,
  day: "2-digit",
  month: "short",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});
const dateFormat = new Intl.DateTimeFormat("en-IN", {
  timeZone: IST,
  day: "2-digit",
  month: "short",
  year: "numeric",
});
const integerFormat = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 });
const compactFormat = new Intl.NumberFormat("en-IN", { notation: "compact", maximumFractionDigits: 2 });
const percentFormat = new Intl.NumberFormat("en-IN", {
  style: "percent",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
  signDisplay: "exceptZero",
});
const signedFormat = new Intl.NumberFormat("en-IN", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
  signDisplay: "exceptZero",
});
const PLAIN_DECIMAL = /^-?\d+(\.\d+)?$/;

function toDate(value: string | null | undefined): Date | null {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export function formatTime(value: string | null | undefined): string {
  const date = toDate(value);
  return date ? timeFormat.format(date) : DASH;
}

export function formatDateTime(value: string | null | undefined): string {
  const date = toDate(value);
  return date ? dateTimeFormat.format(date) : DASH;
}

export function formatDate(value: string | null | undefined): string {
  const date = toDate(value);
  return date ? dateFormat.format(date) : DASH;
}

export function ageSeconds(value: string | null | undefined, now: number): number | null {
  const date = toDate(value);
  return date ? Math.max(0, Math.round((now - date.getTime()) / 1000)) : null;
}

export function formatDuration(seconds: number | null | undefined): string {
  if (seconds === null || seconds === undefined || !Number.isFinite(seconds)) return DASH;
  const whole = Math.max(0, Math.round(seconds));
  if (whole < 60) return `${whole}s`;
  const minutes = Math.floor(whole / 60);
  if (minutes < 60) return `${minutes}m ${String(whole % 60).padStart(2, "0")}s`;
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return `${hours}h ${String(minutes % 60).padStart(2, "0")}m`;
  return `${Math.floor(hours / 24)}d ${hours % 24}h`;
}

export function formatAge(value: string | null | undefined, now: number): string {
  const seconds = ageSeconds(value, now);
  return seconds === null ? DASH : `${formatDuration(seconds)} ago`;
}

/** A decimal string with Indian digit grouping and at least two decimals, keeping every digit sent. */
export function formatPrice(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === "") return DASH;
  const text = typeof value === "number" ? String(value) : value.trim();
  if (!PLAIN_DECIMAL.test(text)) {
    const number = Number(text);
    return Number.isFinite(number)
      ? number.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 8 })
      : DASH;
  }
  const negative = text.startsWith("-");
  const [whole = "0", fraction = ""] = (negative ? text.slice(1) : text).split(".");
  return `${negative ? "-" : ""}${integerFormat.format(BigInt(whole))}.${fraction.padEnd(2, "0")}`;
}

export function formatInteger(value: number | null | undefined): string {
  return value === null || value === undefined ? DASH : integerFormat.format(value);
}

export function formatCompact(value: number | null | undefined): string {
  return value === null || value === undefined ? DASH : compactFormat.format(value);
}

export function formatPercent(ratio: number | null | undefined): string {
  return ratio === null || ratio === undefined || !Number.isFinite(ratio) ? DASH : percentFormat.format(ratio);
}

export function formatSigned(value: number | null | undefined): string {
  return value === null || value === undefined || !Number.isFinite(value) ? DASH : signedFormat.format(value);
}

export function formatLatency(ms: number | null | undefined): string {
  return ms === null || ms === undefined ? DASH : `${Math.round(ms)} ms`;
}

export function priceChange(
  last: string | null | undefined,
  previous: string | null | undefined,
): { change: number; ratio: number } | null {
  if (!last || !previous) return null;
  const current = Number(last);
  const base = Number(previous);
  if (!Number.isFinite(current) || !Number.isFinite(base) || base === 0) return null;
  return { change: current - base, ratio: (current - base) / base };
}

export function humanize(identifier: string): string {
  const words = identifier.replace(/[_-]+/g, " ").trim().toLowerCase();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

/** A market segment as traders write it: ``FNO`` is F&O. */
export function segmentLabel(segment: string): string {
  return segment === "FNO" ? "F&O" : segment;
}
