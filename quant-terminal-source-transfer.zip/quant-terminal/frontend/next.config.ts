import type { NextConfig } from "next";

// REST goes through this same-origin proxy, so the session cookie is first-party and no CORS is needed.
// Rewrites are fixed when the app is built: set BACKEND_URL before `next build` as well as `next dev`.
const backend = (process.env.BACKEND_URL?.trim() || "http://localhost:8000").replace(/\/+$/, "");

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  async rewrites() {
    return [{ source: "/api/:path*", destination: `${backend}/api/:path*` }];
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "same-origin" },
        ],
      },
    ];
  },
};

export default nextConfig;
