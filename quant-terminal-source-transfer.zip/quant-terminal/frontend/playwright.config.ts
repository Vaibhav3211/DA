import { existsSync } from "node:fs";
import { join } from "node:path";
import { defineConfig, devices } from "@playwright/test";

// Like `next dev`, read .env.local (E2E_USERNAME, E2E_PASSWORD, E2E_BASE_URL); the shell's variables win.
const localEnv = join(__dirname, ".env.local");
if (existsSync(localEnv)) process.loadEnvFile(localEnv);

// The smoke test needs the backend running (scripts/start-dev.ps1). Without E2E_BASE_URL the
// Next.js dev server is started here, or reused when it is already running.
const configuredBaseURL = process.env.E2E_BASE_URL?.trim();
const baseURL = configuredBaseURL || "http://localhost:3000";

export default defineConfig({
  testDir: "./e2e",
  timeout: 30_000,
  retries: 0,
  reporter: "list",
  use: { baseURL, trace: "retain-on-failure" },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  webServer: configuredBaseURL
    ? undefined
    : { command: "npm run dev", url: baseURL, reuseExistingServer: true, timeout: 120_000 },
});
