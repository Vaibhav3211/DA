# Quant Terminal

A self-hosted, single-user terminal for live Indian market data and explainable strategy signals. A
FastAPI backend streams quotes from Zerodha Kite Connect and the Groww Trading API, builds candles and
runs strategy plugins behind a risk gate. A Next.js frontend shows workspaces, charts, feed health and
signals.

**Quant Terminal never places orders.** It has no order code, it refuses to start with
`ORDER_EXECUTION_ENABLED=true`, and the architecture tests fail if application code imports a broker
SDK or calls an order API ([ADR-011](docs/decisions/011-no-order-execution.md)). Signals are research
output, not investment advice.

> **Status.** The backend was tested against provider fixtures, without broker access. Live
> connectivity to Zerodha and Groww is **unverified**, and the frontend has **never been compiled**,
> because its packages could not be installed where it was written. The
> [completion report](docs/completion-report.md) lists what is implemented, how each part was tested,
> and what to verify first.

## What it does

- **Live market data** from Zerodha (Kite WebSocket) and Groww (its NATS feed) in LTP, quote or full
  (depth) mode. Every event keeps its provider: quotes from different providers are never merged, and
  the platform never switches an instrument to another provider on its own.
- **Feed health** for every connection and value: `LIVE`, `DELAYED`, `STALE`, `RECONNECTING`,
  `DISCONNECTED`, `SIMULATED` or `UNKNOWN`. The risk gate blocks signals on stale, reconnecting,
  disconnected or unknown data.
- **Candles** from 1 minute to 1 day, built from the stream and stored in PostgreSQL.
- **Strategies and signals:** a plugin contract with Decimal indicators, an example EMA-crossover
  strategy, risk rules, a global kill switch, and signals that record the reasons and data behind them.
- **Your own strategies beside the chart:** register Python strategies in code. From the **Strategy**
  panel beside each chart, save configurations of them with an explicit instrument scope, and start and
  stop their live signals explicitly. Signals appear as markers on the chart.
- **Backtests** of a saved configuration on one instrument: frozen datasets of historical candles from
  Zerodha or Groww (or the candles the platform recorded), with their coverage and gaps; explicit trade
  rules, fees and slippage; results with closed trades, win rate, profit factor, drawdown and an equity
  curve; outdated results marked and kept for comparison. See [backtesting](docs/backtesting.md).
- **Market availability:** markets without a provider, such as crypto, spot Forex and spot metals, show
  as unavailable with the reason.
- **Workspaces** for Indian equity, indices, index and stock futures and options, and long-term
  investing. You choose the provider for each instrument.
- **A development simulator** that streams synthetic instruments, always labelled `SIMULATED`, so you
  can try everything without a broker account.

## Architecture

One Python package (`backend/app`) runs as four processes that share PostgreSQL and Redis:

| Process | Role |
| --- | --- |
| `qt-api` | REST under `/api/v1` and WebSockets under `/ws/v1`, on `127.0.0.1:8000`. Handles the Kite login callback. |
| `qt-market-data-worker` | Streams every enabled provider account, normalizes and checks events, builds candles, publishes to Redis and stores candles. |
| `qt-strategy-worker` | Runs deployed strategies on closed candles, passes their proposals through the risk rules and records signals. |
| `qt-backtest-worker` | Builds requested historical datasets and runs queued backtests, one job at a time. |
| `qt` | The administration CLI. |

PostgreSQL is the system of record: accounts and encrypted credentials, instruments, workspaces,
candles, strategies, signals, risk decisions, datasets, backtests and the audit log. Redis carries the
live event streams, the latest quotes, sign-in sessions and worker heartbeats. The frontend
(`frontend/`, port 3000) proxies REST calls to the API and opens its WebSockets to the API directly.

Run exactly one market-data worker, one strategy worker and one backtest worker: there is no leader
election.

More: [system architecture](docs/architecture/system-architecture.md),
[data flow](docs/architecture/data-flow.md), [WebSocket protocol](docs/websocket-protocol.md) and the
[decision records](docs/decisions/README.md).

```text
backend/    FastAPI app, workers and CLI (app/), Alembic migrations, tests, Dockerfile
frontend/   Next.js terminal
infra/      docker-compose.yml: PostgreSQL, Redis and the optional backend containers
scripts/    setup-dev.ps1, start-dev.ps1, check.ps1 (Windows PowerShell 5.1 or 7+)
docs/       architecture, providers, security, operations and decision records
```

## Prerequisites

- Windows. The scripts are PowerShell; the backend itself is plain Python.
- Python 3.12 or 3.13.
- Docker Desktop, for PostgreSQL 18 and Redis 8.
- Node.js 22.12 or later, for the frontend.
- For live data, a paid Kite Connect app and/or an active Groww Trading API subscription. See
  [the capability matrix](docs/providers/capability-matrix.md).

## Setup

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup-dev.ps1
```

The script is safe to re-run. It:

1. creates `backend\.venv` and installs the pinned backend dependencies (`requirements.lock.txt`);
2. creates `infra\.env` and `backend\.env` with generated database and Redis passwords and a new
   `ENCRYPTION_KEY`, and never overwrites existing `.env` files;
3. starts PostgreSQL and Redis in Docker and applies the database migrations;
4. installs the frontend packages.

Use `-SkipDocker` or `-SkipFrontend` to leave out steps 3 or 4. The script never contacts Zerodha or
Groww.

**Back up `ENCRYPTION_KEY`** from `backend\.env`. Stored provider credentials cannot be decrypted
without it.

Then create the terminal's single user and check the configuration:

```powershell
backend\.venv\Scripts\Activate.ps1
qt create-admin --username admin    # prompts for a password of 12 to 256 characters
qt check-config                     # effective settings, secrets masked; tests PostgreSQL and Redis
```

`qt` reads `backend\.env` from any working directory. `qt --help` lists every command.

## Run

```powershell
powershell -ExecutionPolicy Bypass -File scripts\start-dev.ps1
```

This starts PostgreSQL and Redis, applies any new migrations, and opens one window each for `qt-api`,
`qt-market-data-worker`, `qt-strategy-worker`, `qt-backtest-worker` and the frontend (`npm run dev`).
`-NoWorkers` and `-NoFrontend` leave those out. Close a window to stop that process, and stop the
infrastructure with `docker compose -f infra\docker-compose.yml stop`.

- Terminal: <http://localhost:3000>. Use `localhost`, not `127.0.0.1`: the API accepts browser requests
  only from `ALLOWED_ORIGINS`.
- API docs: <http://localhost:8000/docs>, served only when `APP_ENV=development`.

To start the processes by hand, run each long-running command in its own terminal:

```powershell
docker compose -f infra\docker-compose.yml up -d --wait postgres redis
cd backend
.venv\Scripts\Activate.ps1
alembic upgrade head
qt-api
qt-market-data-worker
qt-strategy-worker
qt-backtest-worker
cd ..\frontend; npm run dev
```

**Containers.** `docker compose -f infra/docker-compose.yml --profile app up -d --build` also builds the
backend image and runs a one-shot `migrate` service and the `api`, `market-data-worker`,
`strategy-worker` and `backtest-worker` services. They read `backend/.env`, with the database and Redis
addresses pointed at the compose services. The frontend is not containerized; run it with `npm run dev`,
or `npm run build` then `npm start`. Every port binds to `127.0.0.1`.

## Try it with the simulator

The simulator needs no broker account. Its instruments (`SIM50`, `SIMBANK`, `ALPHA` … `HOTEL`) are
fictitious, and the `SIM` exchange trades all day, every day.

1. Set `SIMULATOR_ENABLED=true` in `backend\.env` and restart the API, the market-data worker and the
   strategy worker. `APP_ENV` must be `development` (the default) or `replay`.
2. Load the instruments, add a simulator account and choose what to stream:

   ```powershell
   qt instruments refresh simulator
   qt accounts add simulator Lab
   qt accounts enable Lab
   qt workspaces add simulation-lab simulator SIM:CASH:EQUITY:ALPHA SIM:CASH:EQUITY:BRAVO
   ```

3. Open the **Simulation Lab** workspace. Quotes and charts update and are labelled `SIMULATED`.
4. Optionally save a configuration of the example strategy and turn its live signals on, with the
   **Strategy** panel beside the chart or from the command line:

   ```powershell
   qt strategies list
   qt strategies create simulation-lab example.ema_crossover --instrument SIM:CASH:EQUITY:ALPHA
   qt strategies enable simulation-lab example.ema_crossover
   ```

   The configuration is named after the strategy unless you pass `--label`. Signals on simulated data
   stay informational and do not need `LIVE_SIGNALS_ENABLED`. See
   [live monitoring](docs/operations/live-monitoring.md).

## Live data

1. Subscribe to the provider API and create its app: [Zerodha](docs/providers/zerodha.md#subscription-requirements),
   [Groww](docs/providers/groww.md#subscription-requirements).
2. Add the account and store its credentials:
   [Zerodha](docs/providers/zerodha.md#setting-up-an-account),
   [Groww](docs/providers/groww.md#setting-up-an-account-and-daily-tokens). For Zerodha, register exactly
   `ZERODHA_REDIRECT_URL` (by default `http://localhost:3000/api/v1/providers/zerodha/callback`) as
   the Kite app's redirect URL.
3. Set `MARKET_DATA_ENABLED=true` in `backend\.env` and restart the API, the market-data worker and the
   strategy worker.
4. Follow the [live-feed runbook](docs/operations/live-feed-runbook.md): choose instruments, and log in
   and refresh the instrument masters every trading day. Kite and Groww tokens stop working overnight.

Signals on live data also need `LIVE_SIGNALS_ENABLED=true`.

## Configuration

Settings come from `backend/.env`, then a `.env` in the working directory, then environment variables;
each overrides the one before. Every process reads its settings once, at start-up, so restart it after a
change. [`backend/.env.example`](backend/.env.example) documents every setting. The main ones, with
their values after setup:

| Setting | Value | Meaning |
| --- | --- | --- |
| `APP_ENV` | `development` | `development`, `live_data`, `replay` or `production` |
| `MARKET_DATA_ENABLED` | `false` | Stream live Zerodha and Groww data. Must stay `false` in `replay`. |
| `SIMULATOR_ENABLED` | `false` | Stream the simulator; only in `development` or `replay`. |
| `LIVE_SIGNALS_ENABLED` | `false` | Allow signals on live data. |
| `ORDER_EXECUTION_ENABLED` | `false` | Must stay `false`: `true` stops start-up. |
| `ENCRYPTION_KEY` | generated | AES-256-GCM key for stored provider credentials (`qt generate-key`). |
| `ALLOWED_ORIGINS`, `FRONTEND_BASE_URL` | `http://localhost:3000` | The browser origin of the frontend. |
| `ZERODHA_REDIRECT_URL` | `http://localhost:3000/api/v1/providers/zerodha/callback` | Must match the Kite app's registered redirect URL. |
| `COOKIE_SECURE` | `false` | Must be `true` in `production` and whenever the app is served over https. |
| `CANDLE_INTERVALS` | `1m,3m,5m,15m,30m,1h,1d` | Live candle intervals (`1s` is also available). |
| `BACKTEST_MAX_CANDLES`, `BACKTEST_MAX_SECONDS` | `250000`, `600` | The most candles a dataset may hold, and the longest a backtest may run ([limits](docs/backtesting.md#limits-and-settings)). |

The frontend's own settings are in [frontend/README.md](frontend/README.md#configuration).

## Testing

```powershell
powershell -ExecutionPolicy Bypass -File scripts\check.ps1                # ruff, mypy, unit tests with coverage, frontend checks
powershell -ExecutionPolicy Bypass -File scripts\check.ps1 -Integration   # also the integration tests
powershell -ExecutionPolicy Bypass -File scripts\check.ps1 -Audit         # also pip-audit and npm audit --omit=dev
```

The frontend checks (lint, type check, tests and build) run only when `frontend\node_modules` exists;
`-SkipFrontend` skips them. By hand, from `backend` with the virtual environment active:

```powershell
ruff check .; ruff format --check .
mypy app tests
pytest                    # unit tests only: integration and live tests are excluded by default
pytest -m integration     # needs PostgreSQL and Redis running
alembic check             # the models match the migrations
```

The integration tests never touch development data. They use a separate database
(`<database name>_test`), recreated and migrated once per run, and Redis database 15, flushed before
each test.

**Live smoke tests** are opt-in and read-only. They need real credentials and connect to the providers:

```powershell
cd backend
$env:RUN_LIVE_SMOKE = "1"
pytest -m live tests/live
```

See [verifying Zerodha](docs/providers/zerodha.md#verifying-live) and
[verifying Groww](docs/providers/groww.md#verifying-live) for their options. The frontend's checks and
its Playwright smoke test are described in [frontend/README.md](frontend/README.md#checks).

## Security

- One local user with an argon2id password hash. Sessions are HttpOnly cookies checked against Redis.
  Browser requests that change data, and WebSocket handshakes, must come from `ALLOWED_ORIGINS`.
- Provider credentials and tokens are encrypted with AES-256-GCM in PostgreSQL. They are write-only:
  the API and the CLI never show them.
- Docker ports and the API bind to `127.0.0.1`. Every `.env` file is ignored by Git; commit only the
  `.env.example` files.

Details, including key rotation and production settings:
[secrets and authentication](docs/security/secrets-and-auth.md).

## Documentation

| Document | Contents |
| --- | --- |
| [System architecture](docs/architecture/system-architecture.md) | Processes, packages, storage, run modes, deployment |
| [Data flow](docs/architecture/data-flow.md) | From provider tick to candle, signal and browser |
| [WebSocket protocol](docs/websocket-protocol.md) | The `/ws/v1` endpoints, messages and limits |
| [Zerodha](docs/providers/zerodha.md), [Groww](docs/providers/groww.md) | Subscriptions, setup, daily tokens, streaming, verification |
| [Capability matrix](docs/providers/capability-matrix.md) | What each provider supports, with sources and verification dates |
| [Secrets and authentication](docs/security/secrets-and-auth.md) | Sign-in, sessions, encryption, key rotation |
| [Live-feed runbook](docs/operations/live-feed-runbook.md) | First live day and the daily routine |
| [Live monitoring](docs/operations/live-monitoring.md) | The Strategy panel, saved configurations, live signals, monitoring states and chart markers |
| [Registering your own strategy](docs/strategy-registration.md) | Writing, registering and testing your own Python strategy, with a template |
| [Backtesting](docs/backtesting.md) | Historical datasets, trade rules, running backtests, reading results and outdated runs |
| [Specification extension](docs/specification-extension.md) | The strategy workflow, backtests and markets: requirements, design and milestones M8 to M13 |
| [Troubleshooting](docs/operations/troubleshooting.md) | Symptoms, causes and fixes |
| [Decision records](docs/decisions/README.md) | Why the platform is built the way it is |
| [Completion report](docs/completion-report.md) | What is implemented and tested, and what is not |
| [Frontend](frontend/README.md) | Frontend setup, configuration, checks and first-run checklist |

## Known limitations

- Live connectivity to Zerodha and Groww has not been verified, nor have their historical-candle
  downloads; run the live smoke tests first, and check the coverage of the first real dataset.
- The frontend has never been compiled or run, the Strategy panel, chart markers and backtest views
  included; work through its [first-run checklist](frontend/README.md#first-run-checklist).
- Backtests replay one instrument at one interval, for strategies that use closed candles only, with no
  margin or contract-roll model ([known limitations](docs/backtesting.md#known-limitations)).
- The configurations applied to a chart are forgotten when the page reloads.
- Ticks are not stored (`TICK_PERSISTENCE_ENABLED` is not implemented). Candles are.
- Nothing refreshes the instrument masters on a schedule: refresh them each trading day.
- One market-data worker, one strategy worker and one backtest worker; no leader election.
- A quote that stops updating reads `STALE` after 30 seconds, even for a quiet instrument on a healthy
  feed.
- A strategy hook that blocks the event loop stalls the strategy worker; its timeout only detects this
  afterwards.
- Password sign-in only, with no second factor. `/metrics` needs no sign-in, which is why the API binds
  to `127.0.0.1`.

The [completion report](docs/completion-report.md) has the full list.
