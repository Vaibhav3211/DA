<#
.SYNOPSIS
    Starts the local stack: PostgreSQL + Redis (Docker), the API, the three workers, and the frontend,
    each in its own window. Close a window (or press Ctrl+C in it) to stop that process.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\start-dev.ps1
    powershell -ExecutionPolicy Bypass -File scripts\start-dev.ps1 -NoFrontend
#>
[CmdletBinding()]
param(
    [switch]$NoWorkers,
    [switch]$NoFrontend
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 3.0
. (Join-Path $PSScriptRoot '_common.ps1')

if (-not (Test-Path $VenvPython)) { throw 'backend\.venv is missing. Run scripts\setup-dev.ps1 first.' }
if (-not (Test-Path (Join-Path $Backend '.env'))) { throw 'backend\.env is missing. Run scripts\setup-dev.ps1 first.' }

$shellPath = (Get-Process -Id $PID).Path

function Start-Window([string]$Title, [string]$WorkingDirectory, [string]$Command) {
    $script = '$Host.UI.RawUI.WindowTitle = ' + (ConvertTo-SingleQuoted $Title) + '; ' +
    'Set-Location ' + (ConvertTo-SingleQuoted $WorkingDirectory) + '; ' + $Command
    # -EncodedCommand avoids every quoting problem with paths that contain spaces.
    $encoded = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($script))
    Start-Process -FilePath $shellPath -ArgumentList @('-NoExit', '-NoProfile', '-EncodedCommand', $encoded) | Out-Null
    Write-Host "  started $Title"
}

Write-Step 'PostgreSQL and Redis'
Assert-Docker
Invoke-Native 'docker' @('compose', '-f', $ComposeFile, 'up', '-d', '--wait', 'postgres', 'redis')
Invoke-Native (Join-Path $VenvScripts 'alembic.exe') @('upgrade', 'head') -WorkingDirectory $Backend

Write-Step 'Application processes'
Start-Window 'qt-api' $Backend ('& ' + (ConvertTo-SingleQuoted (Join-Path $VenvScripts 'qt-api.exe')))
if (-not $NoWorkers) {
    Start-Window 'qt-market-data-worker' $Backend ('& ' + (ConvertTo-SingleQuoted (Join-Path $VenvScripts 'qt-market-data-worker.exe')))
    Start-Window 'qt-strategy-worker' $Backend ('& ' + (ConvertTo-SingleQuoted (Join-Path $VenvScripts 'qt-strategy-worker.exe')))
    # As a module, so it starts even before setup-dev.ps1 reinstalls the package with its qt-backtest-worker script.
    Start-Window 'qt-backtest-worker' $Backend ('& ' + (ConvertTo-SingleQuoted $VenvPython) + ' -m app.workers.backtest_worker')
}
if (-not $NoFrontend -and (Test-Path (Join-Path $Frontend 'node_modules'))) {
    Start-Window 'qt-frontend' $Frontend 'npm run dev'
}

Write-Host ''
Write-Host 'API:      http://localhost:8000/docs'
Write-Host 'Frontend: http://localhost:3000'
Write-Host 'Stop infrastructure later with: docker compose -f infra\docker-compose.yml stop'
