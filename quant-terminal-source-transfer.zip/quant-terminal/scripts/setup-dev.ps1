<#
.SYNOPSIS
    One-time (safe to re-run) local setup on Windows.

.DESCRIPTION
    1. Creates backend\.venv with Python 3.12/3.13 and installs the pinned dependencies.
    2. Creates infra\.env and backend\.env with freshly generated local passwords and an
       encryption key. Existing .env files are never overwritten.
    3. Starts PostgreSQL and Redis in Docker and applies database migrations.
    4. Installs frontend packages.

    This script never contacts Zerodha or Groww and never asks for broker credentials.
    Works in Windows PowerShell 5.1 and PowerShell 7+.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\setup-dev.ps1
#>
[CmdletBinding()]
param(
    [switch]$SkipDocker,
    [switch]$SkipFrontend
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 3.0
. (Join-Path $PSScriptRoot '_common.ps1')

function Find-Python {
    foreach ($candidate in @('py -3.13', 'py -3.12', 'python', 'python3')) {
        $parts = $candidate.Split(' ')
        if (-not (Get-Command $parts[0] -ErrorAction SilentlyContinue)) { continue }
        $probe = @($parts | Select-Object -Skip 1) + @('-c', 'import sys; print("%d.%d" % sys.version_info[:2])')
        $version = & $parts[0] @probe 2>$null
        if ($LASTEXITCODE -eq 0 -and @('3.12', '3.13') -contains "$version".Trim()) { return , $parts }
    }
    throw 'Python 3.12 or 3.13 is required. Install it from https://www.python.org/downloads/ and re-run.'
}

Write-Step 'Python environment'
if (-not (Test-Path $VenvPython)) {
    $python = Find-Python
    $venvArgs = @($python | Select-Object -Skip 1) + @('-m', 'venv', (Join-Path $Backend '.venv'))
    Invoke-Native $python[0] $venvArgs
}
Invoke-Native $VenvPython @('-m', 'pip', 'install', '--disable-pip-version-check', '--quiet', '--upgrade', 'pip')
Invoke-Native $VenvPython @('-m', 'pip', 'install', '--disable-pip-version-check', '--quiet',
    '-c', 'requirements.lock.txt', '-e', '.[dev,sdk-crosscheck]') -WorkingDirectory $Backend

Write-Step 'Local configuration (.env files)'
$infraEnv = Join-Path $Infra '.env'
if (-not (Test-Path $infraEnv)) {
    $content = [System.IO.File]::ReadAllText((Join-Path $Infra '.env.example'))
    $content = Set-DotEnvValue $content 'POSTGRES_PASSWORD' (New-HexSecret)
    $content = Set-DotEnvValue $content 'REDIS_PASSWORD' (New-HexSecret)
    Write-Utf8NoBom $infraEnv $content
    Write-Host '  created infra\.env with generated passwords'
} else {
    Write-Host '  infra\.env exists (left unchanged)'
}
$infraValues = Read-DotEnv $infraEnv

$backendEnv = Join-Path $Backend '.env'
if (-not (Test-Path $backendEnv)) {
    $pgUser = Get-DotEnvValue $infraValues 'POSTGRES_USER' 'quant'
    $pgDb = Get-DotEnvValue $infraValues 'POSTGRES_DB' 'quant_terminal'
    $pgPort = Get-DotEnvValue $infraValues 'POSTGRES_PORT' '5432'
    $redisPort = Get-DotEnvValue $infraValues 'REDIS_PORT' '6379'
    $content = [System.IO.File]::ReadAllText((Join-Path $Backend '.env.example'))
    $content = Set-DotEnvValue $content 'DATABASE_URL' ("postgresql://{0}:{1}@localhost:{2}/{3}" -f `
            $pgUser, $infraValues['POSTGRES_PASSWORD'], $pgPort, $pgDb)
    $content = Set-DotEnvValue $content 'REDIS_URL' ("redis://:{0}@localhost:{1}/0" -f $infraValues['REDIS_PASSWORD'], $redisPort)
    $content = Set-DotEnvValue $content 'ENCRYPTION_KEY' (New-EncryptionKey)
    Write-Utf8NoBom $backendEnv $content
    Write-Host '  created backend\.env (database/redis URLs and a new ENCRYPTION_KEY)'
    Write-Host '  Back up ENCRYPTION_KEY somewhere safe: stored provider credentials cannot be decrypted without it.' -ForegroundColor Yellow
} else {
    Write-Host '  backend\.env exists (left unchanged)'
}

if (-not $SkipDocker) {
    Write-Step 'PostgreSQL and Redis (Docker)'
    Assert-Docker
    Invoke-Native 'docker' @('compose', '-f', $ComposeFile, 'up', '-d', '--wait', 'postgres', 'redis')

    Write-Step 'Database migrations'
    Invoke-Native (Join-Path $VenvScripts 'alembic.exe') @('upgrade', 'head') -WorkingDirectory $Backend
}

if (-not $SkipFrontend -and (Test-Path (Join-Path $Frontend 'package.json'))) {
    Write-Step 'Frontend packages'
    $frontendEnv = Join-Path $Frontend '.env.local'
    if (-not (Test-Path $frontendEnv)) {
        Copy-Item (Join-Path $Frontend '.env.example') $frontendEnv
    }
    if (Test-Path (Join-Path $Frontend 'package-lock.json')) {
        Invoke-Native 'npm' @('ci', '--no-fund', '--no-audit') -WorkingDirectory $Frontend
    } else {
        Invoke-Native 'npm' @('install', '--no-fund', '--no-audit') -WorkingDirectory $Frontend
    }
}

Write-Step 'Done'
Write-Host @"
Next steps:
  1. Create the single local user (prompts for a password):
       backend\.venv\Scripts\qt.exe create-admin --username admin
  2. Add your provider app credentials to backend\.env (see docs\providers\zerodha.md and groww.md),
     then set MARKET_DATA_ENABLED=true when you want live data.
  3. Start everything:
       powershell -ExecutionPolicy Bypass -File scripts\start-dev.ps1
  4. Open http://localhost:3000
"@
