# Shared helpers for the scripts in this folder. Dot-source it: . (Join-Path $PSScriptRoot '_common.ps1')
# Compatible with Windows PowerShell 5.1 and PowerShell 7+.

$Root = Split-Path -Parent $PSScriptRoot
$Backend = Join-Path $Root 'backend'
$Infra = Join-Path $Root 'infra'
$Frontend = Join-Path $Root 'frontend'
$ComposeFile = Join-Path $Infra 'docker-compose.yml'
$VenvScripts = Join-Path $Backend '.venv\Scripts'
$VenvPython = Join-Path $VenvScripts 'python.exe'

function Write-Step([string]$Message) {
    Write-Host ''
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Invoke-Native {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$Arguments = @(),
        [string]$WorkingDirectory = $Root
    )
    Push-Location $WorkingDirectory
    try {
        & $FilePath @Arguments
        if ($LASTEXITCODE -ne 0) {
            throw "Command failed (exit $LASTEXITCODE): $FilePath $($Arguments -join ' ')"
        }
    } finally {
        Pop-Location
    }
}

function Assert-Docker {
    if (-not (Get-Command 'docker' -ErrorAction SilentlyContinue)) {
        throw 'Docker is not installed. Install Docker Desktop: https://www.docker.com/products/docker-desktop/'
    }
    & docker info --format '{{.ServerVersion}}' *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Docker is installed but not running. Start Docker Desktop and re-run.' }
}

function New-RandomBytes([int]$Count) {
    $bytes = New-Object byte[] $Count
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return , $bytes
}

function New-HexSecret([int]$ByteCount = 24) {
    return -join ((New-RandomBytes $ByteCount) | ForEach-Object { $_.ToString('x2') })
}

function New-EncryptionKey {
    # 32 random bytes, url-safe base64 (the format `qt generate-key` produces).
    return [Convert]::ToBase64String((New-RandomBytes 32)).Replace('+', '-').Replace('/', '_')
}

function Write-Utf8NoBom([string]$Path, [string]$Content) {
    # .env parsers would read a byte-order mark as part of the first variable name.
    [System.IO.File]::WriteAllText($Path, $Content, (New-Object System.Text.UTF8Encoding $false))
}

function Read-DotEnv([string]$Path) {
    $values = @{}
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$') { $values[$Matches[1]] = $Matches[2] }
    }
    return $values
}

function Get-DotEnvValue([hashtable]$Values, [string]$Key, [string]$Default) {
    if ($Values.ContainsKey($Key) -and $Values[$Key]) { return $Values[$Key] }
    return $Default
}

function Set-DotEnvValue([string]$Content, [string]$Key, [string]$Value) {
    $pattern = '(?m)^' + [regex]::Escape($Key) + '=.*$'
    $replacement = ($Key + '=' + $Value).Replace('$', '$$')
    if ([regex]::IsMatch($Content, $pattern)) { return [regex]::Replace($Content, $pattern, $replacement) }
    return $Content.TrimEnd() + "`n$Key=$Value`n"
}

function ConvertTo-SingleQuoted([string]$Value) {
    return "'" + $Value.Replace("'", "''") + "'"
}
