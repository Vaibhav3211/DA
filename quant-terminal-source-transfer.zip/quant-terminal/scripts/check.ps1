<#
.SYNOPSIS
    Runs the quality gates: lint, format check, type check, tests, and optionally integration
    tests and dependency audits.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\check.ps1
    powershell -ExecutionPolicy Bypass -File scripts\check.ps1 -Integration -Audit
#>
[CmdletBinding()]
param(
    [switch]$Integration,
    [switch]$Audit,
    [switch]$SkipFrontend
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 3.0
. (Join-Path $PSScriptRoot '_common.ps1')

Write-Step 'Backend: ruff'
Invoke-Native (Join-Path $VenvScripts 'ruff.exe') @('check', '.') -WorkingDirectory $Backend
Invoke-Native (Join-Path $VenvScripts 'ruff.exe') @('format', '--check', '.') -WorkingDirectory $Backend

Write-Step 'Backend: mypy'
Invoke-Native (Join-Path $VenvScripts 'mypy.exe') @('app', 'tests') -WorkingDirectory $Backend

Write-Step 'Backend: unit tests'
Invoke-Native (Join-Path $VenvScripts 'pytest.exe') @('--cov=app', '--cov-report=term-missing:skip-covered') -WorkingDirectory $Backend

if ($Integration) {
    Write-Step 'Backend: integration tests (PostgreSQL + Redis from docker compose)'
    Invoke-Native (Join-Path $VenvScripts 'pytest.exe') @('-m', 'integration') -WorkingDirectory $Backend
}

if ($Audit) {
    Write-Step 'Backend: pip-audit'
    Invoke-Native (Join-Path $VenvScripts 'pip-audit.exe') @('-r', 'requirements.lock.txt') -WorkingDirectory $Backend
}

if (-not $SkipFrontend -and (Test-Path (Join-Path $Frontend 'node_modules'))) {
    Write-Step 'Frontend: lint, type check, tests, build'
    Invoke-Native 'npm' @('run', 'lint') -WorkingDirectory $Frontend
    Invoke-Native 'npm' @('run', 'typecheck') -WorkingDirectory $Frontend
    Invoke-Native 'npm' @('test') -WorkingDirectory $Frontend
    Invoke-Native 'npm' @('run', 'build') -WorkingDirectory $Frontend
    if ($Audit) {
        Write-Step 'Frontend: npm audit'
        Invoke-Native 'npm' @('audit', '--omit=dev') -WorkingDirectory $Frontend
    }
}

Write-Step 'All checks passed'
