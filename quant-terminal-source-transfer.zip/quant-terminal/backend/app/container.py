"""Process-wide service container, created once in the API lifespan (or by a worker/CLI)."""

from __future__ import annotations

from dataclasses import dataclass, field

from app.core.config import Settings
from app.core.logging import get_logger
from app.core.security import ENCRYPTION_NOT_CONFIGURED, EncryptionError, SecretBox
from app.persistence.database import Database
from app.streaming.redis_bus import RedisBus

log = get_logger(__name__)


@dataclass
class Container:
    settings: Settings
    db: Database
    bus: RedisBus
    secret_box: SecretBox | None = field(default=None)

    @classmethod
    def create(cls, settings: Settings) -> Container:
        try:
            secret_box: SecretBox | None = SecretBox.from_settings(settings)
        except EncryptionError as exc:
            # The app still starts (health, login, docs) but cannot store provider credentials.
            log.warning("encryption_unavailable", reason=str(exc))
            secret_box = None
        return cls(
            settings=settings,
            db=Database(settings),
            bus=RedisBus.from_url(
                settings.redis_url.get_secret_value(), default_maxlen=settings.redis_stream_maxlen
            ),
            secret_box=secret_box,
        )

    def require_secret_box(self) -> SecretBox:
        if self.secret_box is None:
            from app.core.errors import ServiceUnavailableError

            raise ServiceUnavailableError(ENCRYPTION_NOT_CONFIGURED, code="encryption_not_configured")
        return self.secret_box

    async def close(self) -> None:
        await self.bus.close()
        await self.db.dispose()
