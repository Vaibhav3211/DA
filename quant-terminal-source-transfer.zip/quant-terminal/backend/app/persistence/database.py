"""Async SQLAlchemy engine/session management and the declarative base."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any
from uuid import UUID

import pydantic_core
import sqlalchemy as sa
from sqlalchemy import MetaData, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.core.config import Settings

NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_N_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

# Prices and quantities with fractional parts are stored exactly (never as floating point).
PRICE = sa.Numeric(24, 8)


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING_CONVENTION)
    type_annotation_map = {
        datetime: sa.DateTime(timezone=True),
        date: sa.Date(),
        Decimal: PRICE,
        UUID: sa.Uuid(),
        dict[str, Any]: JSONB(),
        list[Any]: JSONB(),
        str: sa.String(),
    }


def enum_column(enum_cls: type[StrEnum], length: int = 40) -> sa.Enum:
    """Store enums as validated strings (no native PG enum types, so migrations stay simple)."""
    return sa.Enum(
        enum_cls,
        native_enum=False,
        length=length,
        values_callable=lambda members: [m.value for m in members],
        validate_strings=True,
        create_constraint=False,
    )


def json_dumps(value: Any) -> str:
    """JSONB serializer that handles UUID, datetime, Decimal (as string) and enums consistently."""
    return pydantic_core.to_json(value).decode("utf-8")


def to_async_url(url: str) -> str:
    if url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url.removeprefix("postgresql://")
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url.removeprefix("postgres://")
    return url


class Database:
    def __init__(self, settings: Settings) -> None:
        self.engine: AsyncEngine = create_async_engine(
            to_async_url(settings.database_url.get_secret_value()),
            pool_size=settings.database_pool_size,
            max_overflow=settings.database_pool_size,
            pool_pre_ping=True,
            pool_recycle=1800,
            echo=settings.database_echo,
            json_serializer=json_dumps,
            connect_args={"server_settings": {"application_name": settings.app_name, "timezone": "UTC"}},
        )
        self.sessionmaker: async_sessionmaker[AsyncSession] = async_sessionmaker(
            self.engine, expire_on_commit=False, autoflush=False
        )

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        async with self.sessionmaker() as session:
            try:
                yield session
            except BaseException:
                await session.rollback()
                raise

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[AsyncSession]:
        async with self.sessionmaker() as session, session.begin():
            yield session

    async def ping(self) -> None:
        async with self.engine.connect() as conn:
            await conn.execute(text("SELECT 1"))

    async def dispose(self) -> None:
        await self.engine.dispose()
