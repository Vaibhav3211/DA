"""Importing this package registers every table on ``Base.metadata`` (used by Alembic)."""

from app.persistence.models.auth import UserRow
from app.persistence.models.backtests import BacktestDatasetCandleRow, BacktestDatasetRow, BacktestRunRow
from app.persistence.models.instruments import (
    ExchangeRow,
    InstrumentProviderMappingRow,
    InstrumentRow,
    MarketSegmentRow,
)
from app.persistence.models.market_data import CandleRow, MarketCalendarOverrideRow, MarketEventRow
from app.persistence.models.providers import (
    ProviderAccountRow,
    ProviderCapabilityRow,
    ProviderConnectionEventRow,
    ProviderCredentialRow,
    ProviderTokenMetadataRow,
)
from app.persistence.models.signals import RiskDecisionRow, RiskRuleRow, SignalEventRow, SignalRow
from app.persistence.models.strategies import (
    StrategyConfigurationRow,
    StrategyDeploymentRow,
    StrategyRow,
    StrategyRunRow,
    StrategyVersionRow,
)
from app.persistence.models.system import AuditLogRow, SystemFlagRow, SystemMetricsSnapshotRow
from app.persistence.models.workspaces import (
    WatchlistItemRow,
    WatchlistRow,
    WorkspaceInstrumentRow,
    WorkspaceRow,
)

__all__ = [
    "AuditLogRow",
    "BacktestDatasetCandleRow",
    "BacktestDatasetRow",
    "BacktestRunRow",
    "CandleRow",
    "ExchangeRow",
    "InstrumentProviderMappingRow",
    "InstrumentRow",
    "MarketCalendarOverrideRow",
    "MarketEventRow",
    "MarketSegmentRow",
    "ProviderAccountRow",
    "ProviderCapabilityRow",
    "ProviderConnectionEventRow",
    "ProviderCredentialRow",
    "ProviderTokenMetadataRow",
    "RiskDecisionRow",
    "RiskRuleRow",
    "SignalEventRow",
    "SignalRow",
    "StrategyConfigurationRow",
    "StrategyDeploymentRow",
    "StrategyRow",
    "StrategyRunRow",
    "StrategyVersionRow",
    "SystemFlagRow",
    "SystemMetricsSnapshotRow",
    "UserRow",
    "WatchlistItemRow",
    "WatchlistRow",
    "WorkspaceInstrumentRow",
    "WorkspaceRow",
]
