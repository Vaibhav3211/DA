"""Signals, their lifecycle history, risk rules and risk decisions."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.enums import (
    CandleInterval,
    DataStatus,
    Exchange,
    MarketRegion,
    Provider,
    RiskOutcome,
    Segment,
    SignalEventType,
    SignalStatus,
    SignalType,
)
from app.persistence.database import Base, enum_column
from app.persistence.models.common import UuidPkMixin


class SignalRow(UuidPkMixin, Base):
    __tablename__ = "signals"
    __table_args__ = (
        sa.Index(None, "workspace_id", "generated_at"),
        sa.Index(None, "strategy_id", "generated_at"),
        sa.Index(None, "instrument_id", "generated_at"),
        sa.Index(
            "ix_signals_open_by_deployment",
            "deployment_id",
            "instrument_id",
            postgresql_where=sa.text("status IN ('GENERATED', 'ACTIVE', 'UPDATED')"),
        ),
        sa.Index("ix_signals_valid_until_open", "valid_until", postgresql_where=sa.text("closed_at IS NULL")),
    )

    workspace_id: Mapped[UUID] = mapped_column(sa.ForeignKey("workspaces.id", ondelete="CASCADE"))
    market_region: Mapped[MarketRegion] = mapped_column(enum_column(MarketRegion))
    instrument_id: Mapped[UUID] = mapped_column(sa.ForeignKey("instruments.id", ondelete="CASCADE"))
    symbol: Mapped[str] = mapped_column(sa.String(80))
    exchange: Mapped[Exchange] = mapped_column(enum_column(Exchange))
    segment: Mapped[Segment] = mapped_column(enum_column(Segment))
    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    account_id: Mapped[UUID | None]
    strategy_id: Mapped[str] = mapped_column(sa.String(64))
    strategy_version: Mapped[str] = mapped_column(sa.String(32))
    deployment_id: Mapped[UUID] = mapped_column(sa.ForeignKey("strategy_deployments.id", ondelete="CASCADE"))
    strategy_run_id: Mapped[UUID] = mapped_column(sa.ForeignKey("strategy_runs.id", ondelete="CASCADE"))
    signal_type: Mapped[SignalType] = mapped_column(enum_column(SignalType))
    status: Mapped[SignalStatus] = mapped_column(enum_column(SignalStatus))
    is_actionable: Mapped[bool]
    entry_price: Mapped[Decimal | None]
    stop_loss: Mapped[Decimal | None]
    targets: Mapped[list[Any]]
    risk_reward: Mapped[Decimal | None]
    score: Mapped[Decimal | None]
    score_definition: Mapped[str | None] = mapped_column(sa.String(500))
    generated_at: Mapped[datetime]
    updated_at: Mapped[datetime]
    valid_until: Mapped[datetime | None]
    closed_at: Mapped[datetime | None]
    source_event_time: Mapped[datetime | None]
    source_candle_interval: Mapped[CandleInterval | None] = mapped_column(
        enum_column(CandleInterval, length=8)
    )
    source_candle_start: Mapped[datetime | None]
    data_status: Mapped[DataStatus] = mapped_column(enum_column(DataStatus))
    reasons: Mapped[list[Any]]
    indicator_values: Mapped[list[Any]]
    invalidation_conditions: Mapped[list[Any]]
    explanation: Mapped[str] = mapped_column(sa.Text)
    risk_outcome: Mapped[RiskOutcome] = mapped_column(enum_column(RiskOutcome))
    risk_decision: Mapped[dict[str, Any]]
    superseded_by: Mapped[UUID | None]
    update_count: Mapped[int] = mapped_column(default=0, server_default="0")


class SignalEventRow(Base):
    """Append-only lifecycle log; the identity key orders events written at the same instant."""

    __tablename__ = "signal_events"
    __table_args__ = (sa.Index(None, "signal_id", "occurred_at"),)

    id: Mapped[int] = mapped_column(sa.BigInteger, sa.Identity(), primary_key=True)
    signal_id: Mapped[UUID] = mapped_column(sa.ForeignKey("signals.id", ondelete="CASCADE"))
    event_type: Mapped[SignalEventType] = mapped_column(enum_column(SignalEventType))
    from_status: Mapped[SignalStatus | None] = mapped_column(enum_column(SignalStatus))
    to_status: Mapped[SignalStatus] = mapped_column(enum_column(SignalStatus))
    details: Mapped[dict[str, Any]] = mapped_column(default=dict, server_default="{}")
    occurred_at: Mapped[datetime]


class RiskRuleRow(UuidPkMixin, Base):
    """Rule parameters. ``workspace_id`` NULL = global default; a workspace row overrides it."""

    __tablename__ = "risk_rules"
    __table_args__ = (sa.UniqueConstraint("rule_key", "workspace_id", postgresql_nulls_not_distinct=True),)

    rule_key: Mapped[str] = mapped_column(sa.String(64))
    workspace_id: Mapped[UUID | None] = mapped_column(sa.ForeignKey("workspaces.id", ondelete="CASCADE"))
    is_enabled: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    params: Mapped[dict[str, Any]] = mapped_column(default=dict, server_default="{}")
    updated_by: Mapped[str | None] = mapped_column(sa.String(64))
    updated_at: Mapped[datetime] = mapped_column(server_default=sa.func.now(), onupdate=sa.func.now())


class RiskDecisionRow(UuidPkMixin, Base):
    __tablename__ = "risk_decisions"
    __table_args__ = (sa.Index(None, "signal_id"), sa.Index(None, "evaluated_at"))

    signal_id: Mapped[UUID | None] = mapped_column(sa.ForeignKey("signals.id", ondelete="CASCADE"))
    deployment_id: Mapped[UUID]
    instrument_id: Mapped[UUID]
    outcome: Mapped[RiskOutcome] = mapped_column(enum_column(RiskOutcome))
    checks: Mapped[list[Any]]
    evaluated_at: Mapped[datetime]
