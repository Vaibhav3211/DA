"""Provider accounts, encrypted credentials, token metadata, capabilities, and connection history."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.enums import AccountStatus, AuthMethod, ConnectionState, CredentialKind, Provider
from app.persistence.database import Base, enum_column
from app.persistence.models.common import TimestampMixin, UuidPkMixin


class ProviderAccountRow(UuidPkMixin, TimestampMixin, Base):
    __tablename__ = "provider_accounts"
    __table_args__ = (
        sa.UniqueConstraint("provider", "label"),
        # At most one enabled (streaming) account per provider.
        sa.Index(
            "uq_provider_accounts_enabled_provider",
            "provider",
            unique=True,
            postgresql_where=sa.text("is_enabled"),
        ),
    )

    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    label: Mapped[str] = mapped_column(sa.String(80))
    auth_method: Mapped[AuthMethod] = mapped_column(enum_column(AuthMethod))
    status: Mapped[AccountStatus] = mapped_column(enum_column(AccountStatus))
    # Disabled by default: the market-data worker ignores accounts until explicitly enabled.
    is_enabled: Mapped[bool] = mapped_column(default=False, server_default=sa.false())
    # Masked display values only (e.g. "••••ab12"). Raw values live encrypted in provider_credentials.
    masked_api_key: Mapped[str | None] = mapped_column(sa.String(32))
    provider_user_ref: Mapped[str | None] = mapped_column(sa.String(64))
    last_auth_at: Mapped[datetime | None]
    token_expires_at: Mapped[datetime | None]
    last_connected_at: Mapped[datetime | None]
    last_disconnected_at: Mapped[datetime | None]
    last_error_code: Mapped[str | None] = mapped_column(sa.String(64))
    last_error_message: Mapped[str | None] = mapped_column(sa.String(500))
    created_by: Mapped[str | None] = mapped_column(sa.String(64))
    updated_by: Mapped[str | None] = mapped_column(sa.String(64))


class ProviderCredentialRow(UuidPkMixin, TimestampMixin, Base):
    """AES-GCM ciphertext bound to (account, kind). Never returned by any API."""

    __tablename__ = "provider_credentials"
    __table_args__ = (sa.UniqueConstraint("account_id", "kind"),)

    account_id: Mapped[UUID] = mapped_column(sa.ForeignKey("provider_accounts.id", ondelete="CASCADE"))
    kind: Mapped[CredentialKind] = mapped_column(enum_column(CredentialKind))
    ciphertext: Mapped[str] = mapped_column(sa.Text)
    key_id: Mapped[str] = mapped_column(sa.String(16))


class ProviderTokenMetadataRow(UuidPkMixin, Base):
    """Token lifecycle metadata. Holds a short fingerprint, never the token itself."""

    __tablename__ = "provider_tokens_metadata"
    __table_args__ = (sa.Index(None, "account_id", "issued_at"),)

    account_id: Mapped[UUID] = mapped_column(sa.ForeignKey("provider_accounts.id", ondelete="CASCADE"))
    token_kind: Mapped[CredentialKind] = mapped_column(enum_column(CredentialKind))
    auth_method: Mapped[AuthMethod] = mapped_column(enum_column(AuthMethod))
    fingerprint: Mapped[str] = mapped_column(sa.String(16))
    issued_at: Mapped[datetime]
    expires_at: Mapped[datetime | None]
    revoked_at: Mapped[datetime | None]
    revoked_by: Mapped[str | None] = mapped_column(sa.String(64))
    revoke_reason: Mapped[str | None] = mapped_column(sa.String(200))


class ProviderCapabilityRow(UuidPkMixin, TimestampMixin, Base):
    __tablename__ = "provider_capabilities"
    __table_args__ = (sa.UniqueConstraint("provider", "account_id", postgresql_nulls_not_distinct=True),)

    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    account_id: Mapped[UUID | None] = mapped_column(sa.ForeignKey("provider_accounts.id", ondelete="CASCADE"))
    capabilities: Mapped[dict[str, Any]]
    verified_on: Mapped[date | None]
    verification_source: Mapped[str] = mapped_column(sa.String(200))


class ProviderConnectionEventRow(UuidPkMixin, Base):
    __tablename__ = "provider_connection_events"
    __table_args__ = (
        sa.Index(None, "account_id", "occurred_at"),
        sa.Index(None, "occurred_at"),
    )

    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    account_id: Mapped[UUID | None] = mapped_column(
        sa.ForeignKey("provider_accounts.id", ondelete="SET NULL")
    )
    stream_id: Mapped[str] = mapped_column(sa.String(120))
    previous_state: Mapped[ConnectionState | None] = mapped_column(enum_column(ConnectionState))
    state: Mapped[ConnectionState] = mapped_column(enum_column(ConnectionState))
    reason: Mapped[str] = mapped_column(sa.String(300))
    actor: Mapped[str] = mapped_column(sa.String(64), default="system")
    occurred_at: Mapped[datetime]
