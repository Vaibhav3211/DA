"""Strategy catalogue, versions, configurations, deployments, and runs."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.enums import PluginKind, ScopeKind, StrategyRunStatus
from app.persistence.database import Base, enum_column
from app.persistence.models.common import TimestampMixin, UuidPkMixin


class StrategyRow(TimestampMixin, Base):
    __tablename__ = "strategies"

    id: Mapped[str] = mapped_column(sa.String(64), primary_key=True)
    kind: Mapped[PluginKind] = mapped_column(enum_column(PluginKind))
    name: Mapped[str] = mapped_column(sa.String(120))
    description: Mapped[str] = mapped_column(sa.Text)
    author: Mapped[str] = mapped_column(sa.String(120))
    is_example: Mapped[bool] = mapped_column(default=False, server_default=sa.false())
    latest_version: Mapped[str] = mapped_column(sa.String(32))
    # False when the plugin is no longer present in the code registry.
    is_available: Mapped[bool] = mapped_column(default=True, server_default=sa.true())


class StrategyVersionRow(UuidPkMixin, Base):
    __tablename__ = "strategy_versions"
    __table_args__ = (sa.UniqueConstraint("strategy_id", "version"),)

    strategy_id: Mapped[str] = mapped_column(sa.ForeignKey("strategies.id", ondelete="CASCADE"))
    version: Mapped[str] = mapped_column(sa.String(32))
    plugin_metadata: Mapped[dict[str, Any]]
    config_schema: Mapped[dict[str, Any]]
    default_config: Mapped[dict[str, Any]]
    code_fingerprint: Mapped[str] = mapped_column(sa.String(64))
    registered_at: Mapped[datetime] = mapped_column(server_default=sa.func.now())


class StrategyConfigurationRow(UuidPkMixin, Base):
    """Immutable configuration snapshots. Edits create a new row, so runs stay traceable."""

    __tablename__ = "strategy_configurations"
    __table_args__ = (sa.Index(None, "strategy_id", "created_at"),)

    strategy_id: Mapped[str] = mapped_column(sa.ForeignKey("strategies.id", ondelete="CASCADE"))
    version: Mapped[str] = mapped_column(sa.String(32))
    config: Mapped[dict[str, Any]]
    config_hash: Mapped[str] = mapped_column(sa.String(64))
    created_by: Mapped[str | None] = mapped_column(sa.String(64))
    created_at: Mapped[datetime] = mapped_column(server_default=sa.func.now())


class StrategyDeploymentRow(UuidPkMixin, TimestampMixin, Base):
    """A saved strategy configuration in a workspace. Live signals run it while it is enabled.

    A strategy can have several in one workspace. Archived ones stay, with their signal history.
    """

    __tablename__ = "strategy_deployments"
    __table_args__ = (
        sa.Index(None, "workspace_id", "strategy_id"),
        # The service also compares labels case-insensitively, under the workspace's row lock.
        sa.Index(
            "uq_strategy_deployments_workspace_label",
            "workspace_id",
            "label",
            unique=True,
            postgresql_where=sa.text("archived_at IS NULL"),
        ),
    )

    workspace_id: Mapped[UUID] = mapped_column(sa.ForeignKey("workspaces.id", ondelete="CASCADE"))
    strategy_id: Mapped[str] = mapped_column(sa.ForeignKey("strategies.id", ondelete="CASCADE"))
    label: Mapped[str] = mapped_column(sa.String(80))
    strategy_version: Mapped[str] = mapped_column(sa.String(32))
    configuration_id: Mapped[UUID] = mapped_column(sa.ForeignKey("strategy_configurations.id"))
    scope_kind: Mapped[ScopeKind] = mapped_column(enum_column(ScopeKind))
    # {"instrument_ids": [...]}: the instruments of an INSTRUMENTS scope; empty for a WORKSPACE scope.
    scope: Mapped[dict[str, Any]] = mapped_column(default=dict, server_default="{}")
    is_enabled: Mapped[bool] = mapped_column(default=False, server_default=sa.false())
    enabled_by: Mapped[str | None] = mapped_column(sa.String(64))
    enabled_at: Mapped[datetime | None]
    disabled_at: Mapped[datetime | None]
    archived_at: Mapped[datetime | None]
    # The trade rules its backtests use (a TradeRules); none means the strategy's own, if it declares them.
    backtest_rules: Mapped[dict[str, Any] | None]


class StrategyRunRow(UuidPkMixin, Base):
    """One execution of a deployment inside the strategy worker (the run/execution ID)."""

    __tablename__ = "strategy_runs"
    __table_args__ = (
        sa.Index(None, "deployment_id", "started_at"),
        sa.Index(None, "status"),
    )

    deployment_id: Mapped[UUID] = mapped_column(sa.ForeignKey("strategy_deployments.id", ondelete="CASCADE"))
    strategy_id: Mapped[str] = mapped_column(sa.String(64))
    strategy_version: Mapped[str] = mapped_column(sa.String(32))
    configuration_id: Mapped[UUID]
    config_snapshot: Mapped[dict[str, Any]]
    config_hash: Mapped[str] = mapped_column(sa.String(64))
    input_context: Mapped[dict[str, Any]]
    status: Mapped[StrategyRunStatus] = mapped_column(enum_column(StrategyRunStatus))
    worker_id: Mapped[str] = mapped_column(sa.String(120))
    started_at: Mapped[datetime]
    stopped_at: Mapped[datetime | None]
    heartbeat_at: Mapped[datetime | None]
    events_processed: Mapped[int] = mapped_column(sa.BigInteger, default=0, server_default="0")
    candles_processed: Mapped[int] = mapped_column(sa.BigInteger, default=0, server_default="0")
    signals_emitted: Mapped[int] = mapped_column(default=0, server_default="0")
    failures: Mapped[int] = mapped_column(default=0, server_default="0")
    timeouts: Mapped[int] = mapped_column(default=0, server_default="0")
    last_error: Mapped[str | None] = mapped_column(sa.String(500))
    circuit_opened_at: Mapped[datetime | None]
    # Warm-up progress, refreshed with the counters: the instruments still short of the closed candles
    # the strategy needs, and per interval the most candles any of them still needs.
    instruments_warming: Mapped[int] = mapped_column(default=0, server_default="0")
    warmup_remaining: Mapped[dict[str, Any]] = mapped_column(default=dict, server_default="{}")
