"""Workspaces, their instrument universes (with explicit source provider), and watchlists."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.enums import MarketRegion, Provider, SubscriptionMode, WorkspaceKind
from app.persistence.database import Base, enum_column
from app.persistence.models.common import TimestampMixin, UuidPkMixin


class WorkspaceRow(UuidPkMixin, TimestampMixin, Base):
    __tablename__ = "workspaces"

    slug: Mapped[str] = mapped_column(sa.String(64), unique=True)
    name: Mapped[str] = mapped_column(sa.String(120))
    market_region: Mapped[MarketRegion] = mapped_column(enum_column(MarketRegion))
    kind: Mapped[WorkspaceKind] = mapped_column(enum_column(WorkspaceKind))
    description: Mapped[str | None] = mapped_column(sa.String(500))
    # Disabled workspaces (e.g. Forex/Crypto without a provider) never drive subscriptions.
    is_enabled: Mapped[bool] = mapped_column(default=False, server_default=sa.false())
    sort_order: Mapped[int] = mapped_column(default=0, server_default="0")
    # Workspace preferences and eligibility (allowed segments/types, default interval, ...).
    # Risk parameters live in risk_rules (workspace-scoped rows override global defaults).
    settings: Mapped[dict[str, Any]] = mapped_column(default=dict, server_default="{}")


class WorkspaceInstrumentRow(Base):
    """An instrument in a workspace universe, bound to one explicitly chosen source provider.

    Changing ``provider`` is an audited action; the platform never switches sources silently.
    """

    __tablename__ = "workspace_instruments"
    __table_args__ = (sa.Index(None, "instrument_id"),)

    workspace_id: Mapped[UUID] = mapped_column(
        sa.ForeignKey("workspaces.id", ondelete="CASCADE"), primary_key=True
    )
    instrument_id: Mapped[UUID] = mapped_column(
        sa.ForeignKey("instruments.id", ondelete="CASCADE"), primary_key=True
    )
    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    account_id: Mapped[UUID | None] = mapped_column(
        sa.ForeignKey("provider_accounts.id", ondelete="SET NULL")
    )
    subscription_mode: Mapped[SubscriptionMode] = mapped_column(
        enum_column(SubscriptionMode), default=SubscriptionMode.QUOTE
    )
    added_at: Mapped[datetime] = mapped_column(server_default=sa.func.now())
    added_by: Mapped[str | None] = mapped_column(sa.String(64))


class WatchlistRow(UuidPkMixin, TimestampMixin, Base):
    __tablename__ = "watchlists"
    __table_args__ = (sa.UniqueConstraint("workspace_id", "name"),)

    workspace_id: Mapped[UUID] = mapped_column(sa.ForeignKey("workspaces.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(sa.String(80))
    sort_order: Mapped[int] = mapped_column(default=0, server_default="0")


class WatchlistItemRow(Base):
    __tablename__ = "watchlist_items"

    watchlist_id: Mapped[UUID] = mapped_column(
        sa.ForeignKey("watchlists.id", ondelete="CASCADE"), primary_key=True
    )
    instrument_id: Mapped[UUID] = mapped_column(
        sa.ForeignKey("instruments.id", ondelete="CASCADE"), primary_key=True
    )
    sort_order: Mapped[int] = mapped_column(default=0, server_default="0")
    added_at: Mapped[datetime] = mapped_column(server_default=sa.func.now())
