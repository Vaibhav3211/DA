"""Exchanges, segments, canonical instruments, and versioned provider mappings."""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.enums import Exchange, InstrumentType, OptionType, Provider, Segment
from app.persistence.database import Base, enum_column
from app.persistence.models.common import TimestampMixin, UuidPkMixin


class ExchangeRow(Base):
    __tablename__ = "exchanges"

    code: Mapped[Exchange] = mapped_column(enum_column(Exchange), primary_key=True)
    name: Mapped[str] = mapped_column(sa.String(120))
    timezone: Mapped[str] = mapped_column(sa.String(64))
    calendar_code: Mapped[str | None] = mapped_column(sa.String(32))
    country: Mapped[str] = mapped_column(sa.String(2))
    currency: Mapped[str] = mapped_column(sa.String(3))


class MarketSegmentRow(UuidPkMixin, Base):
    __tablename__ = "market_segments"
    __table_args__ = (sa.UniqueConstraint("exchange", "segment"),)

    exchange: Mapped[Exchange] = mapped_column(enum_column(Exchange), sa.ForeignKey("exchanges.code"))
    segment: Mapped[Segment] = mapped_column(enum_column(Segment))
    description: Mapped[str] = mapped_column(sa.String(200))


class InstrumentRow(UuidPkMixin, TimestampMixin, Base):
    __tablename__ = "instruments"
    __table_args__ = (
        sa.Index(None, "exchange", "segment", "symbol"),
        sa.Index(None, "underlying", "expiry"),
        sa.Index(None, "instrument_type", "is_active"),
        sa.Index(
            "ix_instruments_symbol_trgm",
            "symbol",
            postgresql_using="gin",
            postgresql_ops={"symbol": "gin_trgm_ops"},
        ),
        sa.Index(
            "ix_instruments_name_trgm",
            "name",
            postgresql_using="gin",
            postgresql_ops={"name": "gin_trgm_ops"},
        ),
    )

    canonical_key: Mapped[str] = mapped_column(sa.String(160), unique=True)
    exchange: Mapped[Exchange] = mapped_column(enum_column(Exchange))
    segment: Mapped[Segment] = mapped_column(enum_column(Segment))
    instrument_type: Mapped[InstrumentType] = mapped_column(enum_column(InstrumentType))
    symbol: Mapped[str] = mapped_column(sa.String(80))
    name: Mapped[str | None] = mapped_column(sa.String(200))
    underlying: Mapped[str | None] = mapped_column(sa.String(80))
    expiry: Mapped[date | None]
    strike: Mapped[Decimal | None]
    option_type: Mapped[OptionType | None] = mapped_column(enum_column(OptionType))
    lot_size: Mapped[int | None]
    tick_size: Mapped[Decimal | None]
    currency: Mapped[str] = mapped_column(sa.String(3), default="INR")
    isin: Mapped[str | None] = mapped_column(sa.String(12))
    is_active: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    last_seen_at: Mapped[datetime | None]


class InstrumentProviderMappingRow(UuidPkMixin, TimestampMixin, Base):
    """Provider identifier → canonical instrument. Kite reuses tokens of expired derivatives, so
    only one *active* mapping per (provider, token) may exist; closed mappings are kept for audit."""

    __tablename__ = "instrument_provider_mappings"
    __table_args__ = (
        sa.Index(
            "uq_instrument_provider_mappings_active_token",
            "provider",
            "provider_token",
            unique=True,
            postgresql_where=sa.text("is_active"),
        ),
        sa.Index(None, "instrument_id", "provider"),
        sa.Index(None, "provider", "provider_symbol"),
    )

    instrument_id: Mapped[UUID] = mapped_column(sa.ForeignKey("instruments.id", ondelete="CASCADE"))
    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    provider_token: Mapped[str] = mapped_column(sa.String(80))
    exchange_token: Mapped[str | None] = mapped_column(sa.String(40))
    provider_symbol: Mapped[str] = mapped_column(sa.String(120))
    provider_exchange: Mapped[str] = mapped_column(sa.String(16))
    provider_segment: Mapped[str] = mapped_column(sa.String(24))
    is_active: Mapped[bool] = mapped_column(default=True, server_default=sa.true())
    valid_from: Mapped[datetime]
    valid_to: Mapped[datetime | None]
    last_seen_at: Mapped[datetime | None]
    provider_metadata: Mapped[dict[str, Any]] = mapped_column(default=dict, server_default="{}")
