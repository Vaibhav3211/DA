"""Opt-in raw event persistence (partitioned), candles, and calendar overrides."""

from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal
from typing import Any
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.enums import (
    CalendarOverrideKind,
    CandleInterval,
    DataStatus,
    EventType,
    Exchange,
    Provider,
)
from app.persistence.database import Base, enum_column
from app.persistence.models.common import TimestampMixin, UuidPkMixin


class MarketEventRow(Base):
    """Raw normalized events. Disabled by default (TICK_PERSISTENCE_ENABLED); daily range partitions
    on ``received_at`` are created ahead of time and dropped after the retention period."""

    __tablename__ = "market_events"
    __table_args__ = (
        sa.PrimaryKeyConstraint("received_at", "event_id"),
        sa.Index(None, "instrument_id", "received_at"),
        {"postgresql_partition_by": "RANGE (received_at)"},
    )

    event_id: Mapped[UUID]
    received_at: Mapped[datetime]
    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    account_id: Mapped[UUID | None]
    instrument_id: Mapped[UUID]
    event_type: Mapped[EventType] = mapped_column(enum_column(EventType))
    last_price: Mapped[Decimal | None]
    volume: Mapped[int | None] = mapped_column(sa.BigInteger)
    source_timestamp: Mapped[datetime | None]
    data_status: Mapped[DataStatus] = mapped_column(enum_column(DataStatus))
    payload: Mapped[dict[str, Any]]


class CandleRow(Base):
    __tablename__ = "candles"
    __table_args__ = (
        sa.PrimaryKeyConstraint("provider", "instrument_id", "interval", "bucket_start"),
        sa.Index(None, "instrument_id", "interval", "bucket_start"),
    )

    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    instrument_id: Mapped[UUID] = mapped_column(sa.ForeignKey("instruments.id", ondelete="CASCADE"))
    interval: Mapped[CandleInterval] = mapped_column(enum_column(CandleInterval, length=8))
    bucket_start: Mapped[datetime]
    bucket_end: Mapped[datetime]
    account_id: Mapped[UUID | None]
    open_price: Mapped[Decimal]
    high_price: Mapped[Decimal]
    low_price: Mapped[Decimal]
    close_price: Mapped[Decimal]
    volume: Mapped[int | None] = mapped_column(sa.BigInteger)
    event_count: Mapped[int]
    data_status: Mapped[DataStatus] = mapped_column(enum_column(DataStatus))
    flags: Mapped[list[str]] = mapped_column(ARRAY(sa.String(32)), default=list, server_default="{}")
    is_complete: Mapped[bool]
    first_event_at: Mapped[datetime]
    last_event_at: Mapped[datetime]
    builder_version: Mapped[str] = mapped_column(sa.String(16))
    created_at: Mapped[datetime] = mapped_column(server_default=sa.func.now())
    updated_at: Mapped[datetime] = mapped_column(server_default=sa.func.now(), onupdate=sa.func.now())


class MarketCalendarOverrideRow(UuidPkMixin, TimestampMixin, Base):
    """Manual holiday/special-session corrections (e.g. Muhurat trading), applied over the library
    calendar. Times are exchange-local wall-clock times."""

    __tablename__ = "market_calendar_overrides"
    __table_args__ = (sa.UniqueConstraint("exchange", "session_date"),)

    exchange: Mapped[Exchange] = mapped_column(enum_column(Exchange))
    session_date: Mapped[date]
    kind: Mapped[CalendarOverrideKind] = mapped_column(enum_column(CalendarOverrideKind))
    open_time: Mapped[time | None] = mapped_column(sa.Time)
    close_time: Mapped[time | None] = mapped_column(sa.Time)
    note: Mapped[str] = mapped_column(sa.String(200))
    created_by: Mapped[str | None] = mapped_column(sa.String(64))
