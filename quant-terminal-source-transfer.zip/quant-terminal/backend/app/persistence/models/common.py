"""Shared ORM column helpers."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID, uuid4

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.orm.attributes import flag_modified


class UuidPkMixin:
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(server_default=sa.func.now())
    updated_at: Mapped[datetime] = mapped_column(server_default=sa.func.now(), onupdate=sa.func.now())


def stamp_updated(row: TimestampMixin, now: datetime) -> None:
    """Set ``updated_at`` explicitly, even to its current value.

    SQLAlchemy leaves an unchanged value out of the UPDATE; the server-side ``onupdate`` would then
    replace it and expire the attribute, which is unreadable once the session is closed.
    """
    row.updated_at = now
    flag_modified(row, "updated_at")
