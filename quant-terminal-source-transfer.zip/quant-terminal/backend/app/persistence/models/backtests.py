"""Historical datasets and backtests (M9; see docs/backtesting.md)."""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.enums import BacktestStatus, CandleInterval, DatasetSource, DatasetStatus, Provider
from app.persistence.database import Base, enum_column
from app.persistence.models.common import TimestampMixin, UuidPkMixin


class BacktestDatasetRow(UuidPkMixin, TimestampMixin, Base):
    """A frozen copy of one instrument's candles at one interval over a range of exchange-local dates.
    Once READY its candles never change; ``content_sha`` identifies them."""

    __tablename__ = "backtest_datasets"
    __table_args__ = (
        sa.Index(None, "instrument_id", "interval", "created_at"),
        sa.Index(None, "status"),
    )

    instrument_id: Mapped[UUID] = mapped_column(sa.ForeignKey("instruments.id", ondelete="CASCADE"))
    provider: Mapped[Provider] = mapped_column(enum_column(Provider))
    account_id: Mapped[UUID | None]  # the provider account a download used
    source: Mapped[DatasetSource] = mapped_column(enum_column(DatasetSource))
    interval: Mapped[CandleInterval] = mapped_column(enum_column(CandleInterval, length=8))
    date_from: Mapped[date]
    date_to: Mapped[date]
    status: Mapped[DatasetStatus] = mapped_column(enum_column(DatasetStatus))
    requested_by: Mapped[str | None] = mapped_column(sa.String(64))
    worker_id: Mapped[str | None] = mapped_column(sa.String(120))
    started_at: Mapped[datetime | None]
    finished_at: Mapped[datetime | None]
    error: Mapped[str | None] = mapped_column(sa.String(500))
    candle_count: Mapped[int] = mapped_column(default=0, server_default="0")
    first_candle_at: Mapped[datetime | None]
    last_candle_at: Mapped[datetime | None]
    content_sha: Mapped[str | None] = mapped_column(sa.String(64))
    coverage: Mapped[dict[str, Any]] = mapped_column(default=dict, server_default="{}")


class BacktestDatasetCandleRow(Base):
    __tablename__ = "backtest_dataset_candles"
    __table_args__ = (sa.PrimaryKeyConstraint("dataset_id", "bucket_start"),)

    dataset_id: Mapped[UUID] = mapped_column(sa.ForeignKey("backtest_datasets.id", ondelete="CASCADE"))
    bucket_start: Mapped[datetime]
    bucket_end: Mapped[datetime]
    open_price: Mapped[Decimal]
    high_price: Mapped[Decimal]
    low_price: Mapped[Decimal]
    close_price: Mapped[Decimal]
    volume: Mapped[int | None] = mapped_column(sa.BigInteger)
    open_interest: Mapped[int | None] = mapped_column(sa.BigInteger)
    flags: Mapped[list[str]] = mapped_column(ARRAY(sa.String(32)), default=list, server_default="{}")


class BacktestRunRow(UuidPkMixin, TimestampMixin, Base):
    """One backtest of a saved configuration on one instrument and dataset. ``settings`` holds everything
    that decides its results apart from the dataset; ``settings_hash`` tells whether they still match the
    configuration."""

    __tablename__ = "backtest_runs"
    __table_args__ = (
        sa.Index(None, "deployment_id", "instrument_id", "created_at"),
        sa.Index(None, "status"),
    )

    deployment_id: Mapped[UUID] = mapped_column(sa.ForeignKey("strategy_deployments.id", ondelete="CASCADE"))
    instrument_id: Mapped[UUID] = mapped_column(sa.ForeignKey("instruments.id", ondelete="CASCADE"))
    dataset_id: Mapped[UUID] = mapped_column(sa.ForeignKey("backtest_datasets.id", ondelete="CASCADE"))
    dataset_sha: Mapped[str] = mapped_column(sa.String(64))
    strategy_id: Mapped[str] = mapped_column(sa.String(64))
    strategy_version: Mapped[str] = mapped_column(sa.String(32))
    code_fingerprint: Mapped[str] = mapped_column(sa.String(64))
    configuration_id: Mapped[UUID]
    config_hash: Mapped[str] = mapped_column(sa.String(64))
    interval: Mapped[CandleInterval] = mapped_column(enum_column(CandleInterval, length=8))
    settings: Mapped[dict[str, Any]]
    settings_hash: Mapped[str] = mapped_column(sa.String(64))
    status: Mapped[BacktestStatus] = mapped_column(enum_column(BacktestStatus))
    requested_by: Mapped[str | None] = mapped_column(sa.String(64))
    worker_id: Mapped[str | None] = mapped_column(sa.String(120))
    started_at: Mapped[datetime | None]
    finished_at: Mapped[datetime | None]
    error: Mapped[str | None] = mapped_column(sa.String(500))
    summary: Mapped[dict[str, Any] | None]
    equity_curve: Mapped[list[Any] | None]
    trades: Mapped[list[Any] | None]
    trade_count: Mapped[int] = mapped_column(default=0, server_default="0")
