"""Audit log, system flags (kill switch), and periodic metric snapshots."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from app.persistence.database import Base


class AuditLogRow(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (
        sa.Index(None, "occurred_at"),
        sa.Index(None, "entity_type", "entity_id"),
        sa.Index(None, "action"),
    )

    id: Mapped[int] = mapped_column(sa.BigInteger, sa.Identity(), primary_key=True)
    occurred_at: Mapped[datetime] = mapped_column(server_default=sa.func.now())
    actor: Mapped[str] = mapped_column(sa.String(64))
    action: Mapped[str] = mapped_column(sa.String(80))
    entity_type: Mapped[str] = mapped_column(sa.String(64))
    entity_id: Mapped[str | None] = mapped_column(sa.String(80))
    # Sanitized details only: the audit writer redacts secret-looking keys before persisting.
    details: Mapped[dict[str, Any]] = mapped_column(default=dict, server_default="{}")
    correlation_id: Mapped[str | None] = mapped_column(sa.String(64))
    client_ip: Mapped[str | None] = mapped_column(sa.String(64))


class SystemFlagRow(Base):
    __tablename__ = "system_flags"

    key: Mapped[str] = mapped_column(sa.String(64), primary_key=True)
    value: Mapped[dict[str, Any]]
    updated_by: Mapped[str | None] = mapped_column(sa.String(64))
    updated_at: Mapped[datetime] = mapped_column(server_default=sa.func.now(), onupdate=sa.func.now())


class SystemMetricsSnapshotRow(Base):
    __tablename__ = "system_metrics_snapshots"
    __table_args__ = (sa.Index(None, "source", "captured_at"),)

    id: Mapped[int] = mapped_column(sa.BigInteger, sa.Identity(), primary_key=True)
    source: Mapped[str] = mapped_column(sa.String(64))
    captured_at: Mapped[datetime]
    metrics: Mapped[dict[str, Any]]
