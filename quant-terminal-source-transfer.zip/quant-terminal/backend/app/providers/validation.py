"""Plausibility checks applied to every parsed tick before it enters the pipeline.

Mappers already turn absent values (zero prices or timestamps) into ``None``. What is rejected here is
data no market produces: non-finite or non-positive prices, negative sizes, a high below the low, or
an upstream timestamp too far ahead of the local receive time (a provider or local clock problem).
"""

from __future__ import annotations

from datetime import timedelta
from decimal import Decimal

from app.domain.models import ProviderTick

_PRICE_FIELDS = (
    "last_price",
    "average_price",
    "open_price",
    "high_price",
    "low_price",
    "close_price",
    "previous_close",
    "bid",
    "ask",
)
_SIZE_FIELDS = (
    "last_quantity",
    "volume",
    "bid_quantity",
    "ask_quantity",
    "total_buy_quantity",
    "total_sell_quantity",
    "open_interest",
    "open_interest_day_high",
    "open_interest_day_low",
)
_TIME_FIELDS = ("source_timestamp", "provider_timestamp")


def tick_problem(tick: ProviderTick, *, max_future: timedelta) -> str | None:
    """Why the tick is implausible, or None when it may be published."""
    for name in _PRICE_FIELDS:
        price: Decimal | None = getattr(tick, name)
        if price is not None and (not price.is_finite() or price <= 0):
            return f"{name} is not a positive number"
    for name in _SIZE_FIELDS:
        size: int | None = getattr(tick, name)
        if size is not None and size < 0:
            return f"{name} is negative"
    if tick.high_price is not None and tick.low_price is not None and tick.high_price < tick.low_price:
        return "high_price is below low_price"
    for name in _TIME_FIELDS:
        stamp = getattr(tick, name)
        if stamp is not None and stamp - tick.received_at > max_future:
            ahead = (stamp - tick.received_at).total_seconds()
            return f"{name} is {ahead:.0f}s ahead of the receive time"
    return None
