"""Shared parsing for provider instrument dumps (the daily CSV instrument masters).

Parsers translate each provider row into a ``ProviderInstrumentRecord``. Rows that cannot be
translated are counted by reason, never silently dropped, so a refresh can report them.
"""

from __future__ import annotations

import csv
import io
from collections import Counter
from collections.abc import Iterator, Sequence
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, InvalidOperation

from app.domain.enums import Provider
from app.domain.models import ProviderInstrumentRecord
from app.providers.errors import ProviderProtocolError

# A full dump is tens of MB at most; the cap only guards against a corrupt or hostile download.
MAX_DUMP_BYTES = 256 * 1024 * 1024


@dataclass(slots=True)
class InstrumentDump:
    provider: Provider
    records: list[ProviderInstrumentRecord] = field(default_factory=list)
    skipped: Counter[str] = field(default_factory=Counter)
    rows: int = 0

    def skip(self, reason: str) -> None:
        self.skipped[reason] += 1


def read_csv(data: bytes, *, provider_name: str, required: Sequence[str]) -> Iterator[dict[str, str]]:
    """Rows keyed by (stripped) header name. Validates the header before returning."""
    if len(data) > MAX_DUMP_BYTES:
        raise ProviderProtocolError(f"the {provider_name} instrument dump exceeds {MAX_DUMP_BYTES} bytes")
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ProviderProtocolError(f"the {provider_name} instrument dump is not UTF-8 text") from None
    reader = csv.DictReader(io.StringIO(text, newline=""))
    header = [name.strip() for name in reader.fieldnames or ()]
    missing = [name for name in required if name not in header]
    if missing:
        raise ProviderProtocolError(
            f"the {provider_name} instrument dump lacks column(s): {', '.join(missing)}"
        )
    reader.fieldnames = header
    return _rows(reader)


def _rows(reader: csv.DictReader[str]) -> Iterator[dict[str, str]]:
    for row in reader:
        # Extra cells land under the key None; missing cells are None. Neither is meaningful.
        yield {key: (value or "").strip() for key, value in row.items() if isinstance(key, str)}


def finish(dump: InstrumentDump, provider_name: str) -> InstrumentDump:
    if not dump.records:
        raise ProviderProtocolError(
            f"the {provider_name} instrument dump has no usable instruments ({dump.rows} rows)"
        )
    return dump


def parse_decimal(value: str) -> Decimal | None:
    """A finite decimal, or None for an empty cell. Raises ValueError for anything else."""
    if not value:
        return None
    try:
        number = Decimal(value)
    except InvalidOperation:
        raise ValueError("not a number") from None
    if not number.is_finite():
        raise ValueError("not a finite number")
    return number


def parse_positive_decimal(value: str) -> Decimal | None:
    """Like ``parse_decimal`` but zero and negative values (placeholders) become None."""
    number = parse_decimal(value)
    return number if number is not None and number > 0 else None


def parse_int(value: str) -> int | None:
    number = parse_decimal(value)  # some dumps write integers as "75.0"
    if number is None:
        return None
    if number != number.to_integral_value():
        raise ValueError("not an integer")
    return int(number)


def parse_positive_int(value: str) -> int | None:
    number = parse_int(value)
    return number if number is not None and number > 0 else None


def parse_date(value: str) -> date | None:
    return date.fromisoformat(value) if value else None
