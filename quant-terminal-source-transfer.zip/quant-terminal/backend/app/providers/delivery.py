"""What each provider's live feed sends for an instrument, by subscription mode.

A strategy gets data only from the market events of the types it declares, and from the candles built
from the feed, which carry traded volume when the feed sends it. This table mirrors the provider
mappers (``zerodha/mapper.py``, ``groww/mapper.py`` and ``simulator/market.py``): change it with them.
It describes data only; whether an account is connected or entitled is shown elsewhere.

- Zerodha: LTP mode sends last prices. QUOTE sends quotes with the day's cumulative volume (index
  values, without volume, for indices). FULL adds five-level market depth and, for contracts of the
  derivative segments (F&O, currency and commodity), open interest.
- Groww: LTP and QUOTE both use the price feed, whose quotes carry open interest for F&O contracts and
  volume only when GROWW_FEED_VOLUME_IS_CUMULATIVE=true. A price message carrying nothing but the price
  arrives as an LTP event; that is incidental, so it is not listed. FULL adds the depth feed's DEPTH
  events. Indices stream index values only.
- Simulator: LTP mode sends last prices. QUOTE sends quotes with volume and a top-of-book bid and ask
  (index values for indices); FULL adds market depth. It has no open interest.
"""

from __future__ import annotations

from collections.abc import Callable, Collection, Iterable, Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Final

from app.domain.enums import DataRequirement, EventType, InstrumentType, Provider, Segment, SubscriptionMode

DATA_LABELS: Final[Mapping[DataRequirement, str]] = MappingProxyType(
    {
        DataRequirement.VOLUME: "traded volume",
        DataRequirement.OPEN_INTEREST: "open interest",
        DataRequirement.MARKET_DEPTH: "market depth",
    }
)
MODES: Final = tuple(SubscriptionMode)  # lowest first
# Kite's derivative exchange segments (NFO, BFO, CDS, BCD, MCX, NCO), which stream open interest.
_ZERODHA_DERIVATIVES: Final = frozenset({Segment.FNO, Segment.CURRENCY, Segment.COMMODITY})
_CONTRACTS: Final = frozenset({InstrumentType.FUTURE, InstrumentType.OPTION})
_NOTHING: Final[frozenset[DataRequirement]] = frozenset()


def is_index(segment: Segment, instrument_type: InstrumentType) -> bool:
    return segment is Segment.INDEX or instrument_type is InstrumentType.INDEX


@dataclass(frozen=True, slots=True)
class Delivery:
    """The market events a feed sends for one instrument, each with the data beyond prices it carries."""

    events: Mapping[EventType, frozenset[DataRequirement]]

    @property
    def event_types(self) -> frozenset[EventType]:
        return frozenset(self.events)

    @property
    def data(self) -> frozenset[DataRequirement]:
        return frozenset[DataRequirement]().union(*self.events.values())

    def reaching(self, event_types: Collection[EventType], *, candles: bool) -> frozenset[DataRequirement]:
        """The data a consumer of these event types gets; with ``candles``, also what the candles built
        from the feed carry (traded volume, when the feed sends it)."""
        got = {item for event_type in event_types for item in self.events.get(event_type, _NOTHING)}
        if candles and DataRequirement.VOLUME in self.data:
            got.add(DataRequirement.VOLUME)
        return frozenset(got)


@dataclass(frozen=True, slots=True)
class FeedDelivery:
    """The live feeds as configured (Groww's volume is used only when GROWW_FEED_VOLUME_IS_CUMULATIVE)."""

    groww_volume_is_cumulative: bool = False

    def of(
        self,
        provider: Provider,
        mode: SubscriptionMode,
        *,
        segment: Segment,
        instrument_type: InstrumentType,
    ) -> Delivery:
        index = is_index(segment, instrument_type)
        if provider is Provider.ZERODHA:
            return _zerodha(mode, segment, index=index)
        if provider is Provider.GROWW:
            return self._groww(mode, segment, index=index)
        return _simulator(mode, index=index)

    def shortfall(
        self,
        provider: Provider,
        mode: SubscriptionMode,
        *,
        segment: Segment,
        instrument_type: InstrumentType,
        needs: Collection[DataRequirement],
        event_types: Collection[EventType],
        candles: bool,
    ) -> str | None:
        """Why a consumer of these event types (and of candles, with ``candles``) does not get all the
        data it needs from the instrument's feed in this mode; None when it does."""

        def reached(in_mode: SubscriptionMode) -> frozenset[DataRequirement]:
            delivery = self.of(provider, in_mode, segment=segment, instrument_type=instrument_type)
            return delivery.reaching(event_types, candles=candles)

        missing = [item for item in DataRequirement if item in needs and item not in reached(mode)]
        if not missing:
            return None
        higher = MODES[MODES.index(mode) + 1 :]
        fixes: dict[DataRequirement, SubscriptionMode] = {}
        reasons: dict[str, list[DataRequirement]] = {}
        for item in missing:
            fix = None if _structural(item, segment, instrument_type) else _first(item, higher, reached)
            if fix is not None:
                fixes[item] = fix
                continue
            reason = self._why(provider, item, segment, instrument_type, event_types)
            reasons.setdefault(reason, []).append(item)
        explained: list[str] = []
        if fixes:
            # Higher modes send everything lower ones do, so the highest fix covers every fixable item.
            fix = max(fixes.values(), key=MODES.index)
            explained.append(f"subscribe the instrument in {fix.value} mode for {labels(fixes)}")
        explained.extend(reason.format(labels=labels(items)) for reason, items in reasons.items())
        return (
            f"it needs {labels(missing)}, which it does not get from the {provider.value} feed in "
            f"{mode.value} mode: {'; '.join(explained)}"
        )

    def _why(
        self,
        provider: Provider,
        item: DataRequirement,
        segment: Segment,
        instrument_type: InstrumentType,
        event_types: Collection[EventType],
    ) -> str:
        """Why no mode of the instrument's feed gets the item to the consumer: a template for its label."""
        if is_index(segment, instrument_type):
            if item is DataRequirement.OPEN_INTEREST:
                return "only futures and options have {labels}"
            return "indices have no {labels}"
        if item is DataRequirement.OPEN_INTEREST and instrument_type not in _CONTRACTS:
            return "only futures and options have {labels}"
        carriers = {
            event_type
            for mode in MODES
            for event_type, data in self.of(
                provider, mode, segment=segment, instrument_type=instrument_type
            ).events.items()
            if item in data and event_type not in event_types
        }
        if carriers:
            names = _either(event_type.value for event_type in EventType if event_type in carriers)
            feed = f"the {provider.value} feed"
            return f"{feed} sends {{labels}} only in {names} events, which it does not take"
        if provider is Provider.GROWW and item is DataRequirement.VOLUME:
            return "the GROWW feed's volume is used only when GROWW_FEED_VOLUME_IS_CUMULATIVE=true"
        return f"the {provider.value} feed does not send {{labels}} for this instrument"

    def _groww(self, mode: SubscriptionMode, segment: Segment, *, index: bool) -> Delivery:
        if index:
            return Delivery({EventType.INDEX_VALUE: _NOTHING})
        quote: set[DataRequirement] = set()
        if segment is Segment.FNO:
            quote.add(DataRequirement.OPEN_INTEREST)
        if self.groww_volume_is_cumulative:
            quote.add(DataRequirement.VOLUME)
        events = {EventType.QUOTE: frozenset(quote)}
        if mode is SubscriptionMode.FULL:
            events[EventType.DEPTH] = frozenset({DataRequirement.MARKET_DEPTH})
        return Delivery(events)


def labels(items: Iterable[DataRequirement]) -> str:
    """The items' names in a sentence, in a fixed order."""
    chosen = set(items)
    names = [DATA_LABELS[item] for item in DataRequirement if item in chosen]
    if len(names) < 2:
        return "".join(names) or "nothing"
    return f"{', '.join(names[:-1])} and {names[-1]}"


def _either(names: Iterable[str]) -> str:
    listed = list(names)
    if len(listed) < 2:
        return "".join(listed) or "none"
    return f"{', '.join(listed[:-1])} or {listed[-1]}"


def _structural(item: DataRequirement, segment: Segment, instrument_type: InstrumentType) -> bool:
    """The instrument cannot have the item in any feed."""
    if is_index(segment, instrument_type):
        return True
    return item is DataRequirement.OPEN_INTEREST and instrument_type not in _CONTRACTS


def _first(
    item: DataRequirement,
    modes: Iterable[SubscriptionMode],
    reached: Callable[[SubscriptionMode], frozenset[DataRequirement]],
) -> SubscriptionMode | None:
    return next((mode for mode in modes if item in reached(mode)), None)


def _zerodha(mode: SubscriptionMode, segment: Segment, *, index: bool) -> Delivery:
    if mode is SubscriptionMode.LTP:
        return Delivery({EventType.LTP: _NOTHING})
    if index:
        return Delivery({EventType.INDEX_VALUE: _NOTHING})
    data = {DataRequirement.VOLUME}
    if mode is SubscriptionMode.FULL:
        data.add(DataRequirement.MARKET_DEPTH)
        if segment in _ZERODHA_DERIVATIVES:
            data.add(DataRequirement.OPEN_INTEREST)
    return Delivery({EventType.QUOTE: frozenset(data)})


def _simulator(mode: SubscriptionMode, *, index: bool) -> Delivery:
    if mode is SubscriptionMode.LTP:
        return Delivery({EventType.LTP: _NOTHING})
    if index:
        return Delivery({EventType.INDEX_VALUE: _NOTHING})
    data = {DataRequirement.VOLUME}
    if mode is SubscriptionMode.FULL:
        data.add(DataRequirement.MARKET_DEPTH)
    return Delivery({EventType.QUOTE: frozenset(data)})
