"""Synthetic instrument catalog for the development simulator (SIM exchange, Simulation Lab).

These instruments exist only inside Quant Terminal. Their names are deliberately fictitious so a
simulated price can never be mistaken for a quote of a real exchange symbol.
"""

from __future__ import annotations

from collections.abc import Mapping
from decimal import Decimal
from types import MappingProxyType

from app.domain.enums import Exchange, InstrumentType, Provider, Segment
from app.domain.models import ProviderInstrumentRecord
from app.providers.instrument_dump import InstrumentDump

INDEX_TICK_SIZE = Decimal("0.01")
EQUITY_TICK_SIZE = Decimal("0.05")

# (symbol, name, instrument type, starting price)
_CATALOG: tuple[tuple[str, str, InstrumentType, str], ...] = (
    ("SIM50", "Simulator 50 Index (synthetic)", InstrumentType.INDEX, "22000.00"),
    ("SIMBANK", "Simulator Bank Index (synthetic)", InstrumentType.INDEX, "48000.00"),
    ("ALPHA", "Alpha Industries (synthetic)", InstrumentType.EQUITY, "2450.00"),
    ("BRAVO", "Bravo Financial (synthetic)", InstrumentType.EQUITY, "1580.00"),
    ("CHARLIE", "Charlie Energy (synthetic)", InstrumentType.EQUITY, "915.50"),
    ("DELTA", "Delta Technologies (synthetic)", InstrumentType.EQUITY, "3320.00"),
    ("ECHO", "Echo Consumer (synthetic)", InstrumentType.EQUITY, "288.40"),
    ("FOXTROT", "Foxtrot Pharma (synthetic)", InstrumentType.EQUITY, "1745.25"),
    ("GOLF", "Golf Metals (synthetic)", InstrumentType.EQUITY, "640.10"),
    ("HOTEL", "Hotel Telecom (synthetic)", InstrumentType.EQUITY, "112.35"),
)


def simulator_token(symbol: str) -> str:
    return f"{Exchange.SIM.value}:{symbol}"


REFERENCE_PRICES: Mapping[str, Decimal] = MappingProxyType(
    {simulator_token(symbol): Decimal(price) for symbol, _name, _kind, price in _CATALOG}
)


def synthetic_instrument_dump() -> InstrumentDump:
    """The simulator's instrument master, in the same shape as a provider dump."""
    records: list[ProviderInstrumentRecord] = []
    for symbol, name, kind, _price in _CATALOG:
        index = kind is InstrumentType.INDEX
        segment = Segment.INDEX if index else Segment.CASH
        records.append(
            ProviderInstrumentRecord(
                provider=Provider.SIMULATOR,
                provider_token=simulator_token(symbol),
                exchange_token=None,
                provider_symbol=symbol,
                provider_exchange=Exchange.SIM.value,
                provider_segment=segment.value,
                exchange=Exchange.SIM,
                segment=segment,
                instrument_type=kind,
                name=name,
                lot_size=None if index else 1,
                tick_size=INDEX_TICK_SIZE if index else EQUITY_TICK_SIZE,
                tradable=not index,
                metadata={"synthetic": True},
            )
        )
    return InstrumentDump(provider=Provider.SIMULATOR, records=records, rows=len(records))
