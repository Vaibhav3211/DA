"""Simulator stream session: synthetic ticks for the subscribed instruments on a fixed timer."""

from __future__ import annotations

import asyncio
import contextlib
import math
from collections.abc import Callable, Sequence
from datetime import datetime
from uuid import UUID

from app.core.clock import utc_now
from app.domain.models import ProviderInstrument, ProviderTick
from app.providers.base import StreamListener, StreamSession
from app.providers.errors import ProviderUnavailableError
from app.providers.simulator.market import SimulatedMarket

SIMULATED_NOTICE = "simulator stream opened: prices are synthetic and every event is labelled SIMULATED"


class SimulatorSession(StreamSession):
    """Every ``interval`` seconds, steps each subscribed instrument once through the market.

    New subscriptions get an immediate snapshot. A round in which no instrument changed sends a
    heartbeat instead, so the supervisor's watchdog sees a healthy, quiet stream.
    """

    def __init__(
        self,
        *,
        market: SimulatedMarket,
        account_id: UUID | None,
        interval: float,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if not (math.isfinite(interval) and interval > 0):
            raise ValueError("the simulator tick interval must be a positive number of seconds")
        self._market = market
        self._account_id = account_id
        self._interval = interval
        self._clock = clock
        self._listener: StreamListener | None = None
        self._subscribed: dict[str, ProviderInstrument] = {}
        self._opened = False
        self._closed = asyncio.Event()

    async def open(self, listener: StreamListener) -> None:
        if self._opened:
            raise RuntimeError("a simulator stream session can only be opened once")
        self._opened = True
        self._listener = listener
        listener.on_notice(SIMULATED_NOTICE)

    async def subscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        if not instruments:
            return
        listener = self._require_connection()
        now = self._clock()
        snapshots: list[ProviderTick] = []
        for instrument in instruments:
            self._subscribed[instrument.provider_token] = instrument
            snapshots.append(self._market.snapshot(instrument, account_id=self._account_id, now=now))
        listener.on_ticks(snapshots)

    async def unsubscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        if not instruments:
            return
        self._require_connection()
        for instrument in instruments:
            self._subscribed.pop(instrument.provider_token, None)

    async def run(self) -> None:
        listener = self._require_connection()
        while True:
            with contextlib.suppress(TimeoutError):
                async with asyncio.timeout(self._interval):
                    await self._closed.wait()
            if self._closed.is_set():
                return
            self._emit(listener)

    async def close(self) -> None:
        self._closed.set()
        self._subscribed.clear()

    # -- internals --------------------------------------------------------------------------------

    def _require_connection(self) -> StreamListener:
        if self._listener is None or self._closed.is_set():
            raise ProviderUnavailableError("the simulator stream is not connected")
        return self._listener

    def _emit(self, listener: StreamListener) -> None:
        now = self._clock()
        ticks: list[ProviderTick] = []
        for instrument in self._subscribed.values():
            tick = self._market.step(instrument, account_id=self._account_id, now=now)
            if tick is not None:
                ticks.append(tick)
        if ticks:
            listener.on_ticks(ticks)
        else:
            listener.on_heartbeat()
