"""Deterministic synthetic market behind the development simulator.

Every instrument follows a bounded log-normal random walk on its own tick grid. Prices are held as
integer numbers of ticks, so every emitted price is exact and on the grid. Indices move on every
update; other instruments move only when a synthetic trade prints, otherwise only their order book
changes. The walk is clamped to +/-20% of the previous close (like an exchange price band), and
the trading day rolls over at midnight in the exchange's time zone (UTC for the synthetic SIM
exchange, IST otherwise).

The same seed and the same sequence of calls reproduce exactly the same ticks. Nothing here is
real market data: the simulator adapter labels every event SIMULATED.
"""

from __future__ import annotations

import hashlib
import math
import random
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, date, datetime, tzinfo
from decimal import ROUND_HALF_EVEN, Decimal
from typing import Any
from uuid import UUID

from app.core.clock import IST, ensure_utc
from app.domain.enums import (
    EventType,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
    SubscriptionMode,
    VolumeSemantics,
)
from app.domain.models import DepthLevel, MarketDepth, ProviderInstrument, ProviderTick

DEFAULT_TICK_SIZE = Decimal("0.05")
INDEX_TICK_SIZE = Decimal("0.01")
DEPTH_LEVELS = 5
PRICE_BAND_PERCENT = 20

# Starting prices (whole rupees) for instruments without a reference price, derived from the token.
_INDEX_PRICE_RANGE = (5_000, 55_000)
_OTHER_PRICE_RANGE = (50, 5_000)
_MAX_TRADE_QUANTITY = 500
_MAX_LEVEL_QUANTITY = 2_000
_MAX_LEVEL_ORDERS = 25
_MAX_SPREAD_TICKS = 3
_MAX_LEVEL_GAP_TICKS = 2
# VWAP is rounded to cents, or finer when the tick size is finer, so it stays within low..high.
_VWAP_QUANTUM = Decimal("0.01")


@dataclass(slots=True)
class _InstrumentState:
    """One instrument's trading day. Prices are integer numbers of ticks."""

    tick_size: Decimal
    is_index: bool
    zone: tzinfo
    day: date
    previous_close: int
    last: int
    open: int
    high: int
    low: int
    volume: int = 0
    turnover: int = 0  # sum of quantity x price (in ticks) over the day's trades
    last_quantity: int | None = None
    last_trade_time: datetime | None = None

    def price(self, ticks: int) -> Decimal:
        return self.tick_size * ticks

    def average_price(self) -> Decimal | None:
        if not self.volume:
            return None
        return (self.tick_size * self.turnover / self.volume).quantize(
            min(self.tick_size, _VWAP_QUANTUM), rounding=ROUND_HALF_EVEN
        )

    def roll_day(self, day: date) -> None:
        self.day = day
        self.previous_close = self.open = self.high = self.low = self.last
        self.volume = self.turnover = 0
        self.last_quantity = None


class SimulatedMarket:
    """Synthetic prices, volumes and order books for any number of instruments.

    ``volatility`` is the standard deviation of one update's log return. ``update_probability`` is
    the chance that an instrument updates at all on a step, and ``trade_probability`` the chance
    that a non-index update is a trade (otherwise only the order book changes).
    """

    def __init__(
        self,
        *,
        seed: int | None = None,
        reference_prices: Mapping[str, Decimal] | None = None,
        volatility: float = 0.0005,
        update_probability: float = 0.6,
        trade_probability: float = 0.75,
    ) -> None:
        if not (math.isfinite(volatility) and 0.0 <= volatility < 1.0):
            raise ValueError("volatility must be at least 0 and below 1")
        if not 0.0 < update_probability <= 1.0:
            raise ValueError("update_probability must be above 0 and at most 1")
        if not 0.0 <= trade_probability <= 1.0:
            raise ValueError("trade_probability must be between 0 and 1")
        prices = dict(reference_prices or {})
        for token, price in prices.items():
            if not (price.is_finite() and price > 0):
                raise ValueError(f"the reference price for {token!r} must be a positive number")
        self._rng = random.Random(seed)  # noqa: S311 - synthetic prices, not security
        self._reference_prices = prices
        self._volatility = volatility
        self._update_probability = update_probability
        self._trade_probability = trade_probability
        self._states: dict[str, _InstrumentState] = {}

    def snapshot(
        self, instrument: ProviderInstrument, *, account_id: UUID | None, now: datetime
    ) -> ProviderTick:
        """The instrument's current state without moving its price (sent when a subscription starts)."""
        now = ensure_utc(now)
        return self._tick(instrument, self._state(instrument, now), account_id=account_id, now=now)

    def step(
        self, instrument: ProviderInstrument, *, account_id: UUID | None, now: datetime
    ) -> ProviderTick | None:
        """Advance the instrument by one update; None when nothing its subscribers see changed."""
        now = ensure_utc(now)
        state = self._state(instrument, now)
        if self._rng.random() >= self._update_probability:
            return None
        if state.is_index:
            self._move(state)
        elif self._rng.random() < self._trade_probability:
            self._move(state)
            self._trade(state, now)
        elif instrument.mode is SubscriptionMode.LTP:
            return None  # only the order book changed, which LTP subscribers do not see
        return self._tick(instrument, state, account_id=account_id, now=now)

    # -- internals --------------------------------------------------------------------------------

    def _state(self, instrument: ProviderInstrument, now: datetime) -> _InstrumentState:
        state = self._states.get(instrument.provider_token)
        if state is None:
            state = self._states[instrument.provider_token] = self._new_state(instrument, now)
        else:
            day = now.astimezone(state.zone).date()
            if day > state.day:
                state.roll_day(day)
        return state

    def _new_state(self, instrument: ProviderInstrument, now: datetime) -> _InstrumentState:
        is_index = instrument.instrument_type is InstrumentType.INDEX or instrument.segment is Segment.INDEX
        tick_size = instrument.tick_size
        if tick_size is None or not tick_size.is_finite() or tick_size <= 0:
            tick_size = INDEX_TICK_SIZE if is_index else DEFAULT_TICK_SIZE
        zone: tzinfo = UTC if instrument.exchange is Exchange.SIM else IST
        reference = self._reference_prices.get(instrument.provider_token)
        if reference is None:
            reference = _hashed_price(instrument.provider_token, is_index=is_index)
        ticks = max(1, int((reference / tick_size).to_integral_value(rounding=ROUND_HALF_EVEN)))
        return _InstrumentState(
            tick_size=tick_size,
            is_index=is_index,
            zone=zone,
            day=now.astimezone(zone).date(),
            previous_close=ticks,
            last=ticks,
            open=ticks,
            high=ticks,
            low=ticks,
        )

    def _move(self, state: _InstrumentState) -> None:
        target = round(state.last * math.exp(self._volatility * self._rng.gauss(0.0, 1.0)))
        band = max(1, state.previous_close * PRICE_BAND_PERCENT // 100)
        state.last = max(1, state.previous_close - band, min(state.previous_close + band, target))
        state.high = max(state.high, state.last)
        state.low = min(state.low, state.last)

    def _trade(self, state: _InstrumentState, now: datetime) -> None:
        quantity = self._rng.randint(1, _MAX_TRADE_QUANTITY)
        state.volume += quantity
        state.turnover += quantity * state.last
        state.last_quantity = quantity
        state.last_trade_time = now

    def _tick(
        self,
        instrument: ProviderInstrument,
        state: _InstrumentState,
        *,
        account_id: UUID | None,
        now: datetime,
    ) -> ProviderTick:
        fields: dict[str, Any] = {"last_price": state.price(state.last), "source_timestamp": now}
        if instrument.mode is SubscriptionMode.LTP:
            event_type = EventType.LTP
        else:
            fields.update(
                open_price=state.price(state.open),
                high_price=state.price(state.high),
                low_price=state.price(state.low),
                previous_close=state.price(state.previous_close),
            )
            if state.is_index:
                event_type = EventType.INDEX_VALUE  # indices have no trades, volume or book
            else:
                event_type = EventType.QUOTE
                fields.update(
                    last_quantity=state.last_quantity,
                    average_price=state.average_price(),
                    volume=state.volume,
                    volume_semantics=VolumeSemantics.CUMULATIVE_DAY,
                    last_trade_time=state.last_trade_time,
                )
                self._add_book(fields, state, full=instrument.mode is SubscriptionMode.FULL)
        return ProviderTick.model_construct(
            provider=Provider.SIMULATOR,
            account_id=account_id,
            provider_token=instrument.provider_token,
            event_type=event_type,
            received_at=now,
            raw_payload_hash=None,
            **fields,
        )

    def _add_book(self, fields: dict[str, Any], state: _InstrumentState, *, full: bool) -> None:
        best_bid = max(1, state.last - self._rng.randint(0, 1))
        best_ask = best_bid + self._rng.randint(1, _MAX_SPREAD_TICKS)
        depth = DEPTH_LEVELS if full else 1
        bids = self._levels(state, best_bid, -1, depth)
        asks = self._levels(state, best_ask, 1, depth)
        fields.update(
            bid=bids[0].price,
            bid_quantity=bids[0].quantity,
            ask=asks[0].price,
            ask_quantity=asks[0].quantity,
        )
        if full:
            fields["market_depth"] = MarketDepth.model_construct(bids=bids, asks=asks)

    def _levels(
        self, state: _InstrumentState, best: int, direction: int, count: int
    ) -> tuple[DepthLevel, ...]:
        levels: list[DepthLevel] = []
        price = best
        while len(levels) < count and price >= 1:
            quantity = self._rng.randint(1, _MAX_LEVEL_QUANTITY)
            orders = self._rng.randint(1, min(_MAX_LEVEL_ORDERS, quantity))
            levels.append(
                DepthLevel.model_construct(price=state.price(price), quantity=quantity, orders=orders)
            )
            price += direction * self._rng.randint(1, _MAX_LEVEL_GAP_TICKS)
        return tuple(levels)


def _hashed_price(token: str, *, is_index: bool) -> Decimal:
    """A stable starting price for a token without a reference price (independent of the seed)."""
    low, high = _INDEX_PRICE_RANGE if is_index else _OTHER_PRICE_RANGE
    digest = int.from_bytes(hashlib.blake2b(token.encode(), digest_size=8).digest(), "big")
    return Decimal(low + digest % (high - low))
