"""Development simulator adapter: synthetic SIM-exchange prices, every event labelled SIMULATED.

It streams only when APP_ENV is development or replay and SIMULATOR_ENABLED=true, needs no
credentials, and is never used as a fallback for a live provider. One ``SimulatedMarket`` per
adapter keeps prices and day volumes continuous across reconnects.
"""

from __future__ import annotations

import functools
from typing import ClassVar

from app.core.config import Settings
from app.domain.enums import Provider
from app.providers.base import MarketDataAdapter, StreamSession
from app.providers.simulator.instruments import REFERENCE_PRICES
from app.providers.simulator.market import SimulatedMarket
from app.providers.simulator.session import SimulatorSession

# Emit at least once per this share of the stream heartbeat timeout, so a quiet round's heartbeat
# always reaches the supervisor's watchdog in time.
_HEARTBEAT_SHARE = 3


class SimulatorAdapter(MarketDataAdapter):
    provider: ClassVar[Provider] = Provider.SIMULATOR
    simulated: ClassVar[bool] = True

    @classmethod
    def disabled_reason(cls, settings: Settings) -> str | None:
        if settings.is_simulated_mode:
            return None
        return "it runs only when APP_ENV is development or replay and SIMULATOR_ENABLED=true"

    @functools.cached_property
    def market(self) -> SimulatedMarket:
        return SimulatedMarket(seed=self.settings.simulator_seed, reference_prices=REFERENCE_PRICES)

    def create_session(self, shard: int) -> StreamSession:
        settings = self.settings
        interval = settings.simulator_tick_interval_seconds
        if settings.feed_heartbeat_timeout_seconds > 0:
            interval = min(interval, settings.feed_heartbeat_timeout_seconds / _HEARTBEAT_SHARE)
        return SimulatorSession(market=self.market, account_id=self.account_id, interval=interval)
