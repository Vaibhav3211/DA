"""Provider registry: which adapter streams each provider, and whether this deployment may use it.

There is deliberately no fallback between providers. When a live provider cannot stream, callers
get ``ProviderNotEnabledError`` (or the adapter reports its real connection state); simulated data
is never substituted for live data.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from types import MappingProxyType
from uuid import UUID

from app.core.config import Settings
from app.domain.enums import Exchange, Provider
from app.domain.models import ProviderCapabilities
from app.providers.base import CredentialSource, MarketDataAdapter, StateChange, StreamObserver
from app.providers.capabilities import default_capabilities
from app.providers.groww.adapter import GrowwAdapter
from app.providers.simulator.adapter import SimulatorAdapter
from app.providers.zerodha.adapter import ZerodhaAdapter

_ADAPTERS: Mapping[Provider, type[MarketDataAdapter]] = MappingProxyType(
    {
        Provider.ZERODHA: ZerodhaAdapter,
        Provider.GROWW: GrowwAdapter,
        Provider.SIMULATOR: SimulatorAdapter,
    }
)


def adapter_class(provider: Provider) -> type[MarketDataAdapter]:
    return _ADAPTERS[provider]


def disabled_reason(provider: Provider, settings: Settings) -> str | None:
    """Why these settings do not allow streaming the provider, or None when they do."""
    return adapter_class(provider).disabled_reason(settings)


def streamable_providers(settings: Settings) -> tuple[Provider, ...]:
    """Providers these settings allow to stream (account capability overrides may still refuse)."""
    return tuple(provider for provider in _ADAPTERS if disabled_reason(provider, settings) is None)


def create_adapter(
    provider: Provider,
    *,
    account_id: UUID | None,
    settings: Settings,
    capabilities: ProviderCapabilities | None = None,
    credentials: CredentialSource | None = None,
    observer: StreamObserver | None = None,
    session_open: Callable[[frozenset[Exchange]], bool | None] | None = None,
    queue_capacity: int | None = None,
    state_listener: Callable[[StateChange], None] | None = None,
) -> MarketDataAdapter:
    """A new adapter for one provider account. Raises ``ProviderNotEnabledError`` when it may not stream."""
    adapter = adapter_class(provider)(
        account_id=account_id,
        settings=settings,
        capabilities=capabilities or default_capabilities(provider),
        credentials=credentials,
        observer=observer,
        session_open=session_open,
        queue_capacity=queue_capacity,
        state_listener=state_listener,
    )
    adapter.ensure_enabled()
    return adapter
