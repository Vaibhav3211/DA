"""Shared HTTP plumbing for provider REST clients.

Provider REST calls use httpx directly; no provider SDK runs in the application (ADR-005).
Request URLs are never put into exception messages or logs because some carry credentials.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import httpx

from app import __version__
from app.providers.errors import ProviderProtocolError, ProviderUnavailableError
from app.providers.tls import tls_context

USER_AGENT = f"quant-terminal/{__version__}"


def create_http_client(
    *,
    base_url: str,
    timeout: float,
    headers: Mapping[str, str] | None = None,
    transport: httpx.AsyncBaseTransport | None = None,
) -> httpx.AsyncClient:
    """An ``AsyncClient`` with explicit timeouts, no redirects, our user agent and the shared TLS
    context (``app.providers.tls``) instead of a fresh CA bundle load per client.

    ``transport`` lets tests substitute ``httpx.MockTransport``; nothing else should pass it.
    """
    return httpx.AsyncClient(
        base_url=base_url,
        timeout=httpx.Timeout(timeout, connect=min(timeout, 10.0)),
        headers={"User-Agent": USER_AGENT, **(headers or {})},
        # A test transport opens no TLS connections, so it does not need the trust store.
        verify=tls_context() if transport is None else True,
        transport=transport,
        follow_redirects=False,
    )


def transport_error(provider_name: str, operation: str, exc: httpx.HTTPError) -> ProviderUnavailableError:
    """Translate a network failure without echoing the request (URLs may carry credentials)."""
    if isinstance(exc, httpx.TimeoutException):
        return ProviderUnavailableError(f"{provider_name} {operation} timed out")
    return ProviderUnavailableError(f"{provider_name} {operation} failed: {type(exc).__name__}")


def decode_json(provider_name: str, operation: str, response: httpx.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        raise ProviderProtocolError(
            f"{provider_name} {operation} returned invalid JSON (HTTP {response.status_code})"
        ) from None


def is_json(response: httpx.Response) -> bool:
    return "json" in response.headers.get("content-type", "").lower()


def error_body(response: httpx.Response) -> Mapping[str, Any]:
    """The JSON object of an error response, or an empty mapping when the body is anything else
    (gateways answer with HTML, plain text or malformed JSON; the status code still applies)."""
    if not is_json(response):
        return {}
    try:
        payload = response.json()
    except ValueError:
        return {}
    return payload if isinstance(payload, Mapping) else {}
