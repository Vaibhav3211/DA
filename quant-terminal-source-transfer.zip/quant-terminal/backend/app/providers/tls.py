"""The TLS trust store shared by every provider connection.

Provider REST calls (httpx), the Kite WebSocket and the Groww NATS feed verify server certificates
with one context, chosen the way httpx chooses its default: the ``SSL_CERT_FILE`` bundle, else the
``SSL_CERT_DIR`` directory, else certifi's CA bundle. These are process environment variables; the
``.env`` file only feeds application settings.

Loading a bundle is blocking file I/O plus parsing that takes milliseconds on most machines and
seconds on some, so the context is built once per process (off the event loop at API startup, see
``prepare_tls``) and shared. Sharing is safe: the only later change is httpcore setting ALPN to
``http/1.1``, which is also the protocol of a WebSocket upgrade.
"""

from __future__ import annotations

import asyncio
import functools
import os
import ssl

import certifi


@functools.cache
def tls_context() -> ssl.SSLContext:
    if cafile := os.environ.get("SSL_CERT_FILE"):
        return ssl.create_default_context(cafile=cafile)
    if capath := os.environ.get("SSL_CERT_DIR"):
        return ssl.create_default_context(capath=capath)
    return ssl.create_default_context(cafile=certifi.where())


def tls_context_for(url: str) -> ssl.SSLContext | None:
    """The shared context for a ``wss://`` URL; ``None`` for plain ``ws://`` (local test servers)."""
    return tls_context() if url.lower().startswith("wss://") else None


async def prepare_tls() -> None:
    """Build the shared context in a worker thread so that no connection blocks the event loop."""
    await asyncio.to_thread(tls_context)
