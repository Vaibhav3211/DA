"""Provider-neutral streaming contracts, the reconnecting stream supervisor, and the adapter base.

Per enabled provider account the market-data worker runs one adapter::

    MarketDataAdapter        connect / disconnect / subscribe / unsubscribe / events / health
      +-- StreamSupervisor   one per connection (shard): reconnect loop with backoff and jitter,
      |     |                desired-subscription reconciliation, watchdogs, health counters
      |     +-- StreamSession  one live provider socket (provider-specific, single use)
      +-- EventQueue         bounded, drop-oldest queue of NormalizedMarketEvent

Sessions parse provider payloads into ``ProviderTick`` objects. The adapter resolves each tick to
the instrument it subscribed and emits ``NormalizedMarketEvent``. Everything runs on one asyncio
event loop: no provider SDK and no SDK callback threads are involved (ADR-005).
"""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import random
import time
from abc import ABC, abstractmethod
from collections import deque
from collections.abc import AsyncIterator, Awaitable, Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import ClassVar, Protocol
from uuid import UUID, uuid4

from app.core.backoff import ExponentialBackoff
from app.core.clock import utc_now
from app.core.config import Settings
from app.core.logging import RateLimitedLogger, get_logger, redact_text
from app.domain.enums import (
    ConnectionState,
    DataStatus,
    EventType,
    Exchange,
    Provider,
    worst_status,
)
from app.domain.models import (
    MarketFields,
    NormalizedMarketEvent,
    ProviderCapabilities,
    ProviderHealth,
    ProviderInstrument,
    ProviderTick,
    StreamHealth,
)
from app.observability.metrics import (
    FEED_CONNECTED,
    FEED_RECONNECTS,
    FEED_SUBSCRIPTIONS,
    MARKET_EVENTS_DROPPED,
    PROVIDER_QUEUE_DEPTH,
    PROVIDER_TICKS,
    SOURCE_LATENCY,
)
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderNotEnabledError,
    SubscriptionCapacityError,
    UnsupportedInstrumentError,
)
from app.providers.validation import tick_problem

log = get_logger(__name__)
_invalid_tick_log = RateLimitedLogger(log, 10.0)

_RATE_WINDOW_SECONDS = 10
_LATENCY_SMOOTHING = 0.2
_STOP_GRACE_SECONDS = 5.0
_STATE_CHANGE_BACKLOG = 1000


def describe_error(exc: BaseException) -> str:
    """A short, credential-free description of an exception for health views and logs."""
    message = redact_text(str(exc)).strip()
    name = type(exc).__name__
    return f"{name}: {message[:200]}" if message else name


def payload_digest(payload: bytes) -> str:
    """Short digest of a raw provider payload, used to drop exact duplicate deliveries."""
    return hashlib.blake2b(payload, digest_size=8).hexdigest()


# ---- event queue ---------------------------------------------------------------------------------


class EventQueue:
    """Bounded queue between provider sockets and the pipeline.

    When full, the *oldest* event is dropped (newer prices supersede older ones) and the drop is
    counted in metrics and stream health, never silently discarded.
    """

    def __init__(self, provider: Provider, capacity: int) -> None:
        if capacity <= 0:
            raise ValueError("queue capacity must be positive")
        self._provider = provider.value
        self._queue: asyncio.Queue[NormalizedMarketEvent] = asyncio.Queue(maxsize=capacity)
        self.dropped = 0

    @property
    def capacity(self) -> int:
        return self._queue.maxsize

    def qsize(self) -> int:
        return self._queue.qsize()

    def put(self, event: NormalizedMarketEvent) -> bool:
        """Enqueue without blocking. Returns True when an older event had to be evicted."""
        evicted = False
        if self._queue.full():
            with contextlib.suppress(asyncio.QueueEmpty):
                self._queue.get_nowait()
                evicted = True
                self.dropped += 1
                MARKET_EVENTS_DROPPED.labels(self._provider, "queue_full").inc()
        self._queue.put_nowait(event)
        PROVIDER_QUEUE_DEPTH.labels(self._provider).set(self._queue.qsize())
        return evicted

    async def get(self) -> NormalizedMarketEvent:
        event = await self._queue.get()
        PROVIDER_QUEUE_DEPTH.labels(self._provider).set(self._queue.qsize())
        return event

    def drain(self, limit: int) -> list[NormalizedMarketEvent]:
        """Up to ``limit`` events that are already waiting, without blocking."""
        events: list[NormalizedMarketEvent] = []
        while len(events) < limit:
            try:
                events.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        PROVIDER_QUEUE_DEPTH.labels(self._provider).set(self._queue.qsize())
        return events


# ---- session contract ----------------------------------------------------------------------------


class StreamListener(Protocol):
    """Callbacks a session uses to report what it receives. Must be called on the event loop."""

    def on_heartbeat(self) -> None: ...

    def on_ticks(self, ticks: Sequence[ProviderTick]) -> None: ...

    def on_malformed(self, reason: str, count: int = 1) -> None: ...

    def on_notice(self, message: str, *, error: bool = False) -> None: ...


class StreamSession(ABC):
    """One live provider connection. Single use: the supervisor creates a new one per attempt."""

    @abstractmethod
    async def open(self, listener: StreamListener) -> None:
        """Connect and authenticate.

        Raise ``ProviderAuthRequiredError`` when the provider rejects the credentials: the
        supervisor then stops retrying until a human re-authenticates. Any other exception is
        retried with backoff.
        """

    @abstractmethod
    async def subscribe(self, instruments: Sequence[ProviderInstrument]) -> None: ...

    @abstractmethod
    async def unsubscribe(self, instruments: Sequence[ProviderInstrument]) -> None: ...

    @abstractmethod
    async def run(self) -> None:
        """Receive until the connection ends: return on a clean close, raise on failure."""

    @abstractmethod
    async def close(self) -> None:
        """Release the connection. Idempotent; never raises."""


async def _close_quietly(session: StreamSession) -> None:
    try:
        await session.close()
    except Exception as exc:  # close() must not mask the original outcome
        log.warning("stream_session_close_failed", error=describe_error(exc))


@dataclass(frozen=True, slots=True)
class SessionCredentials:
    """Decrypted credentials for one connection attempt. Held in memory only; never logged."""

    access_token: str = field(repr=False)
    api_key: str | None = field(default=None, repr=False)
    expires_at: datetime | None = None
    user_ref: str | None = None


type CredentialSource = Callable[[], Awaitable[SessionCredentials]]


# ---- supervisor ----------------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class StateChange:
    provider: Provider
    account_id: UUID | None
    stream_id: str
    previous: ConnectionState | None
    state: ConnectionState
    reason: str
    occurred_at: datetime


class StreamObserver(Protocol):
    """Receives connection state changes in order (e.g. to persist them and update accounts)."""

    async def on_state_change(self, change: StateChange) -> None: ...


@dataclass(frozen=True, slots=True)
class SupervisorConfig:
    heartbeat_timeout: float = 10.0
    tick_silence_timeout: float = 120.0
    stale_after: float = 30.0
    delayed_latency: float = 2.0
    reconnect_initial: float = 1.0
    reconnect_max: float = 60.0
    reconnect_max_attempts: int = 0
    connect_timeout: float = 30.0
    # A connection that stayed up this long resets the backoff; shorter ones keep escalating it.
    stable_after: float = 30.0
    # Ticks whose upstream timestamp is further ahead of the receive time are rejected as invalid.
    max_future_skew: float = 30.0
    simulated: bool = False

    @classmethod
    def from_settings(cls, settings: Settings, *, simulated: bool = False) -> SupervisorConfig:
        return cls(
            heartbeat_timeout=settings.feed_heartbeat_timeout_seconds,
            tick_silence_timeout=settings.feed_tick_silence_reconnect_seconds,
            stale_after=settings.data_stale_after_seconds,
            delayed_latency=settings.data_delayed_latency_seconds,
            reconnect_initial=settings.reconnect_initial_delay_seconds,
            reconnect_max=settings.reconnect_max_delay_seconds,
            reconnect_max_attempts=settings.reconnect_max_attempts,
            max_future_skew=settings.event_max_future_seconds,
            simulated=simulated,
        )


type TickHandler = Callable[[StreamSupervisor, Sequence[ProviderTick]], None]


class _BoundListener:
    """Routes one session's callbacks to its supervisor; late callbacks from old sessions are ignored."""

    def __init__(self, supervisor: StreamSupervisor, generation: int) -> None:
        self._supervisor = supervisor
        self._generation = generation

    def _current(self) -> bool:
        return self._supervisor._generation == self._generation

    def on_heartbeat(self) -> None:
        if self._current():
            self._supervisor._record_heartbeat()

    def on_ticks(self, ticks: Sequence[ProviderTick]) -> None:
        if self._current():
            self._supervisor._record_ticks(ticks)

    def on_malformed(self, reason: str, count: int = 1) -> None:
        if self._current():
            self._supervisor._record_malformed(reason, count)

    def on_notice(self, message: str, *, error: bool = False) -> None:
        if self._current():
            self._supervisor._record_notice(message, error=error)


class StreamSupervisor:
    """Keeps one provider stream connected and subscribed to the desired instrument set.

    * Reconnects with bounded exponential backoff and jitter; a provider credential rejection
      stops the loop in ``AUTH_REQUIRED`` instead of hammering the provider.
    * After every (re)connect the complete desired set is re-subscribed; afterwards only the
      differences are sent, so a subscription is never duplicated.
    * Watchdogs reconnect when nothing (not even a heartbeat) arrives for
      ``heartbeat_timeout`` seconds, or when no tick arrives for ``tick_silence_timeout`` seconds
      while the market is known to be open.
    """

    def __init__(
        self,
        *,
        provider: Provider,
        account_id: UUID | None,
        stream_id: str,
        session_factory: Callable[[], StreamSession],
        config: SupervisorConfig,
        tick_handler: TickHandler,
        on_state_change: Callable[[StateChange], None] | None = None,
        session_open: Callable[[], bool | None] = lambda: None,
        clock: Callable[[], datetime] = utc_now,
        monotonic: Callable[[], float] = time.monotonic,
        rng: Callable[[], float] = random.random,
    ) -> None:
        self.provider = provider
        self.account_id = account_id
        self.stream_id = stream_id
        self._session_factory = session_factory
        self._config = config
        self._max_future = timedelta(seconds=config.max_future_skew)
        self._tick_handler = tick_handler
        self._on_state_change = on_state_change
        self._session_open = session_open
        self._clock = clock
        self._monotonic = monotonic
        self._rng = rng
        self._metric_labels = (provider.value, stream_id)

        self._state = ConnectionState.IDLE
        self._state_since = clock()
        self._connected_since: datetime | None = None
        self._ever_connected = False
        self._auth_required = False
        self._generation = 0
        self._task: asyncio.Task[None] | None = None
        self._stop_requested = asyncio.Event()
        self._reconnect_requested = asyncio.Event()
        self._reconnect_reason = ""
        self._reconcile_needed = asyncio.Event()
        self._desired: dict[str, ProviderInstrument] = {}
        self._applied: dict[str, ProviderInstrument] = {}
        # Digest of the last payload per (token, event type): exact re-deliveries are dropped.
        self._last_digest: dict[tuple[str, EventType], str] = {}

        now = monotonic()
        self._last_message_mono = now
        self._last_tick_mono = now
        self._last_message_at: datetime | None = None
        self._last_event_at: datetime | None = None
        self._last_heartbeat_at: datetime | None = None
        self._events_received = 0
        self._malformed = 0
        self._duplicates = 0
        self._dropped = 0
        self._reconnects = 0
        self._latency_ms: float | None = None
        self._rate: deque[list[int]] = deque()
        self._last_error: str | None = None

    # -- lifecycle --------------------------------------------------------------------------------

    @property
    def state(self) -> ConnectionState:
        return self._state

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    def start(self) -> None:
        """Start (or restart after AUTH_REQUIRED / DISCONNECTED) the connection loop."""
        if self.running:
            return
        self._stop_requested.clear()
        self._auth_required = False
        self._task = asyncio.create_task(self._run(), name=f"feed:{self.stream_id}")

    async def stop(self, reason: str = "stopped") -> None:
        self._stop_requested.set()
        task = self._task
        if task is not None and not task.done():
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=_STOP_GRACE_SECONDS)
            except TimeoutError:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        self._applied.clear()
        FEED_SUBSCRIPTIONS.labels(*self._metric_labels).set(0)
        self._set_state(ConnectionState.STOPPED, reason)

    def request_reconnect(self, reason: str) -> None:
        """Reconnect now (e.g. after credentials were refreshed): drops the current connection or
        skips the remaining backoff delay."""
        self._reconnect_reason = reason
        self._reconnect_requested.set()

    # -- subscriptions ----------------------------------------------------------------------------

    def set_desired(self, instruments: Iterable[ProviderInstrument]) -> None:
        self._desired = {instrument.provider_token: instrument for instrument in instruments}
        self._reconcile_needed.set()

    @property
    def desired(self) -> Mapping[str, ProviderInstrument]:
        return self._desired

    # -- main loop --------------------------------------------------------------------------------

    async def _run(self) -> None:
        backoff = ExponentialBackoff(
            self._config.reconnect_initial,
            self._config.reconnect_max,
            max_attempts=self._config.reconnect_max_attempts,
            rng=self._rng,
        )
        while not self._stop_requested.is_set():
            try:
                reason, connected, stable = await self._connect_once()
            except ProviderAuthRequiredError as exc:
                self._auth_required = True
                self._last_error = exc.message
                self._set_state(ConnectionState.AUTH_REQUIRED, exc.message)
                return
            except Exception as exc:  # a bug must show up in health and be retried, not end the feed
                log.exception("stream_supervisor_error", stream_id=self.stream_id)
                reason, connected, stable = f"internal error: {describe_error(exc)}", False, False
            if self._stop_requested.is_set():
                return
            self._last_error = reason
            if stable:
                backoff.reset()
            if connected:
                self._reconnects += 1
                FEED_RECONNECTS.labels(self.provider.value).inc()
            if self._reconnect_requested.is_set():
                # Requested (e.g. fresh credentials): reconnect at once without waiting or escalating.
                self._set_state(ConnectionState.RECONNECTING, reason)
                continue
            if not await self._wait_before_retry(backoff, reason):
                return

    async def _connect_once(self) -> tuple[str, bool, bool]:
        self._generation += 1
        listener = _BoundListener(self, self._generation)
        session = self._session_factory()
        try:
            return await self._attempt(session, listener)
        finally:
            self._generation += 1  # ignore late callbacks from the closed session
            await _close_quietly(session)

    async def _attempt(self, session: StreamSession, listener: _BoundListener) -> tuple[str, bool, bool]:
        """One connection attempt. Returns (reason it ended, whether it connected, whether stable)."""
        self._reconnect_requested.clear()  # this attempt already uses the latest credentials
        if self._state is not ConnectionState.RECONNECTING:
            self._set_state(
                ConnectionState.RECONNECTING if self._ever_connected else ConnectionState.CONNECTING,
                "connecting",
            )
        try:
            async with asyncio.timeout(self._config.connect_timeout):
                await session.open(listener)
        except ProviderAuthRequiredError:
            raise
        except Exception as exc:  # retried with backoff
            return f"connect failed: {describe_error(exc)}", False, False

        started = self._monotonic()
        self._last_message_mono = started
        self._last_tick_mono = started
        self._applied.clear()
        self._last_digest.clear()
        self._last_error = None
        self._set_state(ConnectionState.CONNECTED, "connected")
        reason = await self._serve(session)
        return reason, True, self._monotonic() - started >= self._config.stable_after

    async def _serve(self, session: StreamSession) -> str:
        self._reconcile_needed.set()  # always (re)subscribe the full desired set on a new connection
        tasks = {
            asyncio.create_task(session.run()): "run",
            asyncio.create_task(self._watchdog()): "watchdog",
            asyncio.create_task(self._reconcile(session)): "reconcile",
            asyncio.create_task(self._stop_requested.wait()): "stop",
            asyncio.create_task(self._reconnect_requested.wait()): "reconnect",
        }
        try:
            done, _pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            self._applied.clear()
            FEED_SUBSCRIPTIONS.labels(*self._metric_labels).set(0)

        finished = {tasks[task]: task for task in done}
        if "stop" in finished:
            return "stopped"
        for task in done:
            error = None if task.cancelled() else task.exception()
            if isinstance(error, ProviderAuthRequiredError):
                raise error
        if "reconnect" in finished:
            return f"reconnect requested: {self._reconnect_reason}"
        if "watchdog" in finished:
            return str(finished["watchdog"].result())
        if "reconcile" in finished:
            exc = finished["reconcile"].exception()
            return f"subscription failed: {describe_error(exc)}" if exc else "subscription loop ended"
        exc = finished["run"].exception()
        return f"connection lost: {describe_error(exc)}" if exc else "connection closed by provider"

    async def _wait_before_retry(self, backoff: ExponentialBackoff, reason: str) -> bool:
        if backoff.exhausted:
            self._set_state(
                ConnectionState.DISCONNECTED, f"{reason}; gave up after {backoff.attempts} attempts"
            )
            return False
        delay = backoff.next_delay()
        # Retrying after a failure is RECONNECTING even before the first success, so a long outage
        # does not flap between states (and flood the connection-event log) on every attempt.
        self._set_state(ConnectionState.RECONNECTING, f"{reason}; retrying in {delay:.1f}s")
        log.warning(
            "feed_retry_scheduled",
            stream_id=self.stream_id,
            reason=reason,
            delay_seconds=round(delay, 2),
            attempt=backoff.attempts,
        )
        waiters = [
            asyncio.create_task(self._stop_requested.wait()),
            asyncio.create_task(self._reconnect_requested.wait()),
        ]
        try:
            await asyncio.wait(waiters, timeout=delay, return_when=asyncio.FIRST_COMPLETED)
        finally:
            for waiter in waiters:
                waiter.cancel()
            await asyncio.gather(*waiters, return_exceptions=True)
        return not self._stop_requested.is_set()

    async def _reconcile(self, session: StreamSession) -> None:
        while True:
            await self._reconcile_needed.wait()
            self._reconcile_needed.clear()
            desired = dict(self._desired)
            obsolete = [
                instrument
                for token, instrument in self._applied.items()
                if (wanted := desired.get(token)) is None or wanted.mode is not instrument.mode
            ]
            if obsolete:
                await session.unsubscribe(obsolete)
                removed = {instrument.provider_token for instrument in obsolete}
                for token in removed:
                    self._applied.pop(token, None)
                for key in [key for key in self._last_digest if key[0] in removed]:
                    del self._last_digest[key]
            missing = [instrument for token, instrument in desired.items() if token not in self._applied]
            if missing:
                await session.subscribe(missing)
                self._applied.update((instrument.provider_token, instrument) for instrument in missing)
            FEED_SUBSCRIPTIONS.labels(*self._metric_labels).set(len(self._applied))
            if obsolete or missing:
                log.info(
                    "feed_subscriptions_reconciled",
                    stream_id=self.stream_id,
                    added=len(missing),
                    removed=len(obsolete),
                    subscribed=len(self._applied),
                )

    async def _watchdog(self) -> str:
        heartbeat_timeout = self._config.heartbeat_timeout
        silence_timeout = self._config.tick_silence_timeout
        interval = min(1.0, heartbeat_timeout / 4) if heartbeat_timeout > 0 else 1.0
        while True:
            await asyncio.sleep(interval)
            now = self._monotonic()
            if heartbeat_timeout > 0 and now - self._last_message_mono > heartbeat_timeout:
                return f"no data or heartbeat for {heartbeat_timeout:g}s"
            if (
                silence_timeout > 0
                and self._applied
                and now - self._last_tick_mono > silence_timeout
                and self._session_open() is True
            ):
                return f"no ticks for {silence_timeout:g}s while the market is open"

    # -- listener callbacks -----------------------------------------------------------------------

    def _record_heartbeat(self) -> None:
        self._last_message_mono = self._monotonic()
        self._last_heartbeat_at = self._last_message_at = self._clock()

    def _record_ticks(self, ticks: Sequence[ProviderTick]) -> None:
        now = self._monotonic()
        self._last_message_mono = now
        self._last_message_at = self._clock()
        if not ticks:
            return
        PROVIDER_TICKS.labels(self.provider.value).inc(len(ticks))
        self._last_tick_mono = now
        accepted: list[ProviderTick] = []
        for tick in ticks:
            problem = tick_problem(tick, max_future=self._max_future)
            if problem is not None:
                self._malformed += 1
                MARKET_EVENTS_DROPPED.labels(self.provider.value, "invalid").inc()
                _invalid_tick_log.warning(
                    self.stream_id,
                    "feed_invalid_tick",
                    stream_id=self.stream_id,
                    token=tick.provider_token,
                    problem=problem,
                )
                continue
            digest = tick.raw_payload_hash
            if digest is not None:
                key = (tick.provider_token, tick.event_type)
                if self._last_digest.get(key) == digest:
                    self._duplicates += 1
                    MARKET_EVENTS_DROPPED.labels(self.provider.value, "duplicate").inc()
                    continue
                self._last_digest[key] = digest
            reference = tick.source_timestamp or tick.provider_timestamp
            if reference is not None:
                latency = (tick.received_at - reference).total_seconds()
                SOURCE_LATENCY.labels(self.provider.value).observe(max(latency, 0.0))
                latency_ms = latency * 1000.0
                self._latency_ms = (
                    latency_ms
                    if self._latency_ms is None
                    else self._latency_ms + _LATENCY_SMOOTHING * (latency_ms - self._latency_ms)
                )
            accepted.append(tick)
        if not accepted:
            return
        self._events_received += len(accepted)
        self._last_event_at = accepted[-1].received_at
        self._count_rate(len(accepted), now)
        self._tick_handler(self, accepted)

    def _record_malformed(self, reason: str, count: int) -> None:
        self._last_message_mono = self._monotonic()
        self._malformed += count
        MARKET_EVENTS_DROPPED.labels(self.provider.value, "malformed").inc(count)
        log.warning("feed_malformed_payload", stream_id=self.stream_id, reason=reason, count=count)

    def _record_notice(self, message: str, *, error: bool) -> None:
        clean = redact_text(message)[:300]
        if error:
            self._last_error = clean
            log.warning("feed_provider_error", stream_id=self.stream_id, message=clean)
        else:
            log.info("feed_provider_notice", stream_id=self.stream_id, message=clean)

    def count_dropped(self, count: int = 1) -> None:
        self._dropped += count

    def _count_rate(self, count: int, now: float) -> None:
        second = int(now)
        if self._rate and self._rate[-1][0] == second:
            self._rate[-1][1] += count
        else:
            self._rate.append([second, count])
        while self._rate and self._rate[0][0] <= second - _RATE_WINDOW_SECONDS:
            self._rate.popleft()

    # -- state and health -------------------------------------------------------------------------

    def _set_state(self, state: ConnectionState, reason: str) -> None:
        previous = self._state
        if state is previous:
            return
        now = self._clock()
        self._state = state
        self._state_since = now
        if state is ConnectionState.CONNECTED:
            self._connected_since = now
            self._ever_connected = True
            self._auth_required = False
            FEED_CONNECTED.labels(*self._metric_labels).set(1)
        elif previous is ConnectionState.CONNECTED:
            self._connected_since = None
            FEED_CONNECTED.labels(*self._metric_labels).set(0)
        log.info(
            "feed_state_changed",
            stream_id=self.stream_id,
            previous=previous.value,
            state=state.value,
            reason=reason,
        )
        if self._on_state_change is not None:
            self._on_state_change(
                StateChange(
                    provider=self.provider,
                    account_id=self.account_id,
                    stream_id=self.stream_id,
                    previous=previous,
                    state=state,
                    reason=reason[:300],
                    occurred_at=now,
                )
            )

    def event_status(self, tick: ProviderTick) -> DataStatus:
        """Quality of a single event as received (connection-level quality is in ``health``)."""
        if self._config.simulated:
            return DataStatus.SIMULATED
        reference = tick.source_timestamp or tick.provider_timestamp
        if (
            reference is not None
            and (tick.received_at - reference).total_seconds() > self._config.delayed_latency
        ):
            return DataStatus.DELAYED
        return DataStatus.LIVE

    def _data_status(self, stale_seconds: float | None) -> DataStatus:
        if self._config.simulated:
            return DataStatus.SIMULATED
        if self._state is ConnectionState.CONNECTED:
            if stale_seconds is None:
                return DataStatus.UNKNOWN
            if stale_seconds > self._config.stale_after:
                return DataStatus.STALE
            if self._latency_ms is not None and self._latency_ms > self._config.delayed_latency * 1000.0:
                return DataStatus.DELAYED
            return DataStatus.LIVE
        if self._state is ConnectionState.RECONNECTING:
            return DataStatus.RECONNECTING
        return DataStatus.DISCONNECTED

    def health(self) -> StreamHealth:
        now = self._clock()
        stale = (now - self._last_event_at).total_seconds() if self._last_event_at is not None else None
        cutoff = int(self._monotonic()) - _RATE_WINDOW_SECONDS
        recent = sum(count for second, count in self._rate if second > cutoff)
        return StreamHealth(
            provider=self.provider,
            account_id=self.account_id,
            stream_id=self.stream_id,
            state=self._state,
            data_status=self._data_status(stale),
            state_since=self._state_since,
            connected_since=self._connected_since,
            last_message_at=self._last_message_at,
            last_event_at=self._last_event_at,
            last_heartbeat_at=self._last_heartbeat_at,
            events_received=self._events_received,
            events_per_second=round(recent / _RATE_WINDOW_SECONDS, 2),
            malformed_events=self._malformed,
            dropped_events=self._dropped,
            duplicate_events=self._duplicates,
            reconnect_count=self._reconnects,
            subscribed_instruments=len(self._applied),
            desired_instruments=len(self._desired),
            source_latency_ms=None if self._latency_ms is None else round(self._latency_ms, 1),
            stale_seconds=None if stale is None else round(stale, 1),
            last_error=self._last_error,
            auth_required=self._auth_required,
            session_open=self._session_open(),
            updated_at=now,
        )


# ---- sharding ------------------------------------------------------------------------------------


def plan_shards(
    current: Mapping[str, int],
    desired: Iterable[ProviderInstrument],
    *,
    shard_capacity: int,
    max_shards: int,
    cost: Callable[[ProviderInstrument], int] = lambda _instrument: 1,
) -> dict[str, int]:
    """Assign instruments to connections without exceeding per-connection capacity.

    Existing assignments are kept where they still fit (no needless resubscription); new
    instruments go to the first connection with room. Raises instead of dropping anything.
    """
    usage = [0] * max_shards
    plan: dict[str, int] = {}
    pending: list[ProviderInstrument] = []
    for instrument in desired:
        shard = current.get(instrument.provider_token)
        weight = cost(instrument)
        if shard is not None and shard < max_shards and usage[shard] + weight <= shard_capacity:
            usage[shard] += weight
            plan[instrument.provider_token] = shard
        else:
            pending.append(instrument)
    for instrument in pending:
        weight = cost(instrument)
        for shard in range(max_shards):
            if usage[shard] + weight <= shard_capacity:
                usage[shard] += weight
                plan[instrument.provider_token] = shard
                break
        else:
            raise SubscriptionCapacityError(
                f"cannot subscribe {len(pending)} more instrument(s): the limit is {shard_capacity} per "
                f"connection x {max_shards} connection(s) per account",
                details={"shard_capacity": shard_capacity, "max_shards": max_shards, "in_use": sum(usage)},
            )
    return plan


# ---- adapter -------------------------------------------------------------------------------------

_MARKET_FIELDS = tuple(MarketFields.model_fields)


def unsupported_reason(capabilities: ProviderCapabilities, instrument: ProviderInstrument) -> str | None:
    """Why an account with these capabilities cannot stream the instrument, or None when it can."""
    caps = capabilities
    if instrument.provider is not caps.provider:
        return f"{instrument.symbol} is mapped for {instrument.provider.value}, not {caps.provider.value}"
    if instrument.exchange not in caps.exchanges or instrument.segment not in caps.segments:
        return (
            f"{caps.display_name} does not stream {instrument.exchange.value} "
            f"{instrument.segment.value} instruments ({instrument.symbol})"
        )
    if instrument.mode not in caps.subscription_modes:
        return f"{caps.display_name} does not support {instrument.mode.value} subscriptions"
    return None


def normalize_tick(
    tick: ProviderTick,
    instrument: ProviderInstrument,
    *,
    processed_at: datetime,
    data_status: DataStatus,
) -> NormalizedMarketEvent:
    # Both inputs are already validated models; skip re-validation on this hot path.
    values = {name: getattr(tick, name) for name in _MARKET_FIELDS}
    return NormalizedMarketEvent.model_construct(
        event_id=uuid4(),
        provider=tick.provider,
        account_id=tick.account_id,
        exchange=instrument.exchange,
        segment=instrument.segment,
        instrument_id=instrument.instrument_id,
        provider_instrument_token=tick.provider_token,
        symbol=instrument.symbol,
        event_type=tick.event_type,
        received_at=tick.received_at,
        processed_at=processed_at,
        sequence_number=None,
        data_status=data_status,
        raw_payload_hash=tick.raw_payload_hash,
        **values,
    )


def aggregate_state(states: Sequence[ConnectionState]) -> ConnectionState:
    if not states:
        return ConnectionState.IDLE
    if ConnectionState.AUTH_REQUIRED in states:
        return ConnectionState.AUTH_REQUIRED
    if all(state is ConnectionState.CONNECTED for state in states):
        return ConnectionState.CONNECTED
    if all(state is ConnectionState.STOPPED for state in states):
        return ConnectionState.STOPPED
    if ConnectionState.RECONNECTING in states:
        return ConnectionState.RECONNECTING
    # Streams that are still starting (e.g. a connection added for new instruments) are not an outage.
    starting = (ConnectionState.IDLE, ConnectionState.CONNECTING, ConnectionState.CONNECTED)
    if all(state in starting for state in states):
        return ConnectionState.CONNECTING
    return ConnectionState.DISCONNECTED


class MarketDataAdapter(ABC):
    """Provider-neutral market-data contract (connect, disconnect, subscribe, unsubscribe, events,
    health) for one provider account. Subclasses supply sessions and provider limits."""

    provider: ClassVar[Provider]
    simulated: ClassVar[bool] = False

    def __init__(
        self,
        *,
        account_id: UUID | None,
        settings: Settings,
        capabilities: ProviderCapabilities,
        credentials: CredentialSource | None = None,
        observer: StreamObserver | None = None,
        session_open: Callable[[frozenset[Exchange]], bool | None] | None = None,
        queue_capacity: int | None = None,
        state_listener: Callable[[StateChange], None] | None = None,
    ) -> None:
        if capabilities.provider is not self.provider:
            raise ValueError(
                f"{type(self).__name__} streams {self.provider.value}, but was given "
                f"{capabilities.provider.value} capabilities"
            )
        self.account_id = account_id
        self.capabilities = capabilities
        self.settings = settings
        self.token_expires_at: datetime | None = None
        self._credential_source = credentials
        self._config = SupervisorConfig.from_settings(settings, simulated=self.simulated)
        self._observer = observer
        self._state_listener = state_listener
        self._session_open = session_open
        self._queue = EventQueue(self.provider, queue_capacity or settings.provider_queue_size)
        self._desired: dict[str, ProviderInstrument] = {}
        self._assignment: dict[str, int] = {}
        self._supervisors: dict[int, StreamSupervisor] = {}
        self._changes: asyncio.Queue[StateChange] = asyncio.Queue(maxsize=_STATE_CHANGE_BACKLOG)
        self._delivery: asyncio.Task[None] | None = None
        self._background: set[asyncio.Task[None]] = set()
        self._connected = False
        self._lock = asyncio.Lock()

    # -- provider-specific hooks ------------------------------------------------------------------

    @classmethod
    def disabled_reason(cls, settings: Settings) -> str | None:
        """Why this deployment may not stream the provider, or None when it may.

        Live providers stream only with MARKET_DATA_ENABLED=true; the simulator overrides this.
        """
        if not settings.market_data_enabled:
            return "live market data is off (set MARKET_DATA_ENABLED=true)"
        return None

    @abstractmethod
    def create_session(self, shard: int) -> StreamSession:
        """A new, unopened session for connection number ``shard``."""

    def slot_cost(self, instrument: ProviderInstrument) -> int:
        """Subscription slots an instrument uses on one connection (e.g. Groww topics)."""
        return 1

    @property
    def max_connections(self) -> int:
        return self.capabilities.max_connections_per_account or 1

    @property
    def connection_capacity(self) -> int:
        capacity = self.capabilities.max_instruments_per_connection
        if capacity is None:
            raise SubscriptionCapacityError(f"{self.capabilities.display_name} has no documented capacity")
        return capacity

    async def load_credentials(self) -> SessionCredentials:
        """Latest stored credentials for a new connection attempt (never cached across attempts)."""
        if self._credential_source is None:
            raise ProviderAuthRequiredError(f"{self.capabilities.display_name} has no credential source")
        credentials = await self._credential_source()
        self.token_expires_at = credentials.expires_at
        if credentials.expires_at is not None and credentials.expires_at <= utc_now():
            raise ProviderAuthRequiredError(
                f"the {self.capabilities.display_name} access token expired at "
                f"{credentials.expires_at.isoformat()}; log in again"
            )
        return credentials

    # -- contract ---------------------------------------------------------------------------------

    def stream_id(self, shard: int) -> str:
        return f"{self.provider.value.lower()}:{self.account_id or 'none'}:{shard}"

    def ensure_enabled(self) -> None:
        """Raise ProviderNotEnabledError unless settings and capabilities allow streaming."""
        reason = type(self).disabled_reason(self.settings)
        if reason is None and not self.capabilities.streaming:
            reason = "streaming is turned off in its capability configuration"
        if reason is not None:
            raise ProviderNotEnabledError(f"{self.capabilities.display_name} cannot stream: {reason}")

    async def connect(self) -> None:
        self.ensure_enabled()
        async with self._lock:
            if self._connected:
                return
            self._connected = True
            self._supervisors.clear()
            if self._observer is not None:
                self._delivery = asyncio.create_task(self._deliver_state_changes())
            self._apply_assignment()

    async def disconnect(self) -> None:
        async with self._lock:
            if not self._connected:
                return
            self._connected = False
            await asyncio.gather(
                *(supervisor.stop("disconnected") for supervisor in self._supervisors.values())
            )
            if self._background:
                await asyncio.gather(*self._background, return_exceptions=True)
            if self._delivery is not None:
                with contextlib.suppress(TimeoutError):
                    async with asyncio.timeout(_STOP_GRACE_SECONDS):
                        await self._changes.join()
                self._delivery.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._delivery
                self._delivery = None

    async def subscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        async with self._lock:
            desired = dict(self._desired)
            for instrument in instruments:
                self._validate(instrument)
                desired[instrument.provider_token] = instrument
            self._replan(desired)

    async def unsubscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        async with self._lock:
            desired = dict(self._desired)
            for instrument in instruments:
                desired.pop(instrument.provider_token, None)
            self._replan(desired)

    async def set_subscriptions(self, instruments: Sequence[ProviderInstrument]) -> None:
        """Replace the complete desired set (used by the worker's periodic reconciliation)."""
        async with self._lock:
            for instrument in instruments:
                self._validate(instrument)
            self._replan({instrument.provider_token: instrument for instrument in instruments})

    async def events(self) -> AsyncIterator[NormalizedMarketEvent]:
        while True:
            yield await self._queue.get()

    async def next_event(self) -> NormalizedMarketEvent:
        return await self._queue.get()

    @property
    def queue(self) -> EventQueue:
        return self._queue

    @property
    def subscriptions(self) -> Mapping[str, ProviderInstrument]:
        return self._desired

    async def health(self) -> ProviderHealth:
        streams = tuple(self._supervisors[shard].health() for shard in sorted(self._supervisors))
        state = aggregate_state([stream.state for stream in streams])
        if streams:
            data_status = worst_status(*(stream.data_status for stream in streams))
        else:
            data_status = DataStatus.SIMULATED if self.simulated else DataStatus.DISCONNECTED
        return ProviderHealth(
            provider=self.provider,
            account_id=self.account_id,
            state=state,
            data_status=data_status,
            streams=streams,
            token_expires_at=self.token_expires_at,
            message=next((stream.last_error for stream in streams if stream.last_error), None),
        )

    def request_reconnect(self, reason: str) -> None:
        """Reconnect every stream now, restarting streams that stopped in AUTH_REQUIRED or gave up.

        Call after the account's credentials changed (new daily token, re-login).
        """
        for supervisor in self._supervisors.values():
            if supervisor.running:
                supervisor.request_reconnect(reason)
            elif self._connected:
                supervisor.start()

    # -- internals --------------------------------------------------------------------------------

    def _validate(self, instrument: ProviderInstrument) -> None:
        reason = unsupported_reason(self.capabilities, instrument)
        if reason is not None:
            raise UnsupportedInstrumentError(reason)

    def _replan(self, desired: dict[str, ProviderInstrument]) -> None:
        assignment = plan_shards(
            self._assignment,
            desired.values(),
            shard_capacity=self.connection_capacity,
            max_shards=self.max_connections,
            cost=self.slot_cost,
        )
        self._desired = desired
        self._assignment = assignment
        if self._connected:
            self._apply_assignment()

    def _apply_assignment(self) -> None:
        used = set(self._assignment.values()) | {0}
        for shard in sorted(used):
            if shard not in self._supervisors:
                self._supervisors[shard] = self._new_supervisor(shard)
        for shard, supervisor in list(self._supervisors.items()):
            if shard not in used:
                # An emptied extra connection is closed so it stops counting against the limit.
                del self._supervisors[shard]
                task = asyncio.create_task(supervisor.stop("no instruments assigned"))
                self._background.add(task)
                task.add_done_callback(self._background.discard)
                continue
            supervisor.set_desired(
                instrument for token, instrument in self._desired.items() if self._assignment[token] == shard
            )
            supervisor.start()

    def _new_supervisor(self, shard: int) -> StreamSupervisor:
        return StreamSupervisor(
            provider=self.provider,
            account_id=self.account_id,
            stream_id=self.stream_id(shard),
            session_factory=lambda: self.create_session(shard),
            config=self._config,
            tick_handler=self._handle_ticks,
            on_state_change=self._on_state_change,
            session_open=lambda: self._shard_session_open(shard),
        )

    def _shard_session_open(self, shard: int) -> bool | None:
        if self._session_open is None:
            return None
        exchanges = frozenset(
            instrument.exchange
            for token, instrument in self._desired.items()
            if self._assignment.get(token) == shard
        )
        return self._session_open(exchanges) if exchanges else None

    def _handle_ticks(self, supervisor: StreamSupervisor, ticks: Sequence[ProviderTick]) -> None:
        processed_at = utc_now()
        for tick in ticks:
            instrument = self._desired.get(tick.provider_token)
            if instrument is None:
                # Usually a late tick after an unsubscribe; never attributed to a guessed instrument.
                MARKET_EVENTS_DROPPED.labels(self.provider.value, "unmapped").inc()
                supervisor.count_dropped()
                continue
            event = normalize_tick(
                tick, instrument, processed_at=processed_at, data_status=supervisor.event_status(tick)
            )
            if self._queue.put(event):
                supervisor.count_dropped()

    def _on_state_change(self, change: StateChange) -> None:
        # The listener runs inside the supervisor, so it sees each change before any later tick.
        if self._state_listener is not None:
            try:
                self._state_listener(change)
            except Exception as exc:  # bookkeeping must never break a connection loop
                log.warning(
                    "feed_state_listener_failed", stream_id=change.stream_id, error=describe_error(exc)
                )
        if self._observer is not None:
            self._queue_state_change(change)

    def _queue_state_change(self, change: StateChange) -> None:
        try:
            self._changes.put_nowait(change)
        except asyncio.QueueFull:
            log.warning(
                "feed_state_change_backlog_full", stream_id=change.stream_id, state=change.state.value
            )

    async def _deliver_state_changes(self) -> None:
        assert self._observer is not None
        while True:
            change = await self._changes.get()
            try:
                await self._observer.on_state_change(change)
            except Exception as exc:  # persistence problems must not stop the feed
                log.warning(
                    "feed_state_change_not_recorded", stream_id=change.stream_id, error=describe_error(exc)
                )
            finally:
                self._changes.task_done()
