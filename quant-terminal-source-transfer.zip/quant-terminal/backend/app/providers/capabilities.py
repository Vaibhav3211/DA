"""Provider capability registry (configuration-backed defaults).

Every value below was taken from the provider's official documentation or official SDK source on
``VERIFIED_ON``. Anything that could not be confirmed without a live account is listed in
``needs_live_verification`` instead of being presented as fact. Support is never inferred from an
instrument merely appearing in a provider's symbol list.

Operators can override these defaults per provider or per account in the ``provider_capabilities``
table (see ``app.services.capabilities``); the most specific row wins.
"""

from __future__ import annotations

from datetime import date

from app.domain.enums import Exchange, InstrumentType, Provider, Segment, SubscriptionMode
from app.domain.models import ProviderCapabilities

VERIFIED_ON = date(2026, 10, 30)

ZERODHA = ProviderCapabilities(
    provider=Provider.ZERODHA,
    display_name="Zerodha Kite Connect",
    exchanges=(Exchange.NSE, Exchange.BSE, Exchange.MCX),
    segments=(Segment.CASH, Segment.FNO, Segment.CURRENCY, Segment.COMMODITY, Segment.INDEX),
    instrument_types=(
        InstrumentType.EQUITY,
        InstrumentType.INDEX,
        InstrumentType.FUTURE,
        InstrumentType.OPTION,
    ),
    streaming=True,
    rest_quotes=True,
    subscription_modes=(SubscriptionMode.LTP, SubscriptionMode.QUOTE, SubscriptionMode.FULL),
    quote_fields=(
        "last_price",
        "last_quantity",
        "average_price",
        "volume (cumulative for the day)",
        "open_price",
        "high_price",
        "low_price",
        "previous_close",
        "total_buy_quantity",
        "total_sell_quantity",
        "open_interest, open_interest_day_high, open_interest_day_low (FULL)",
        "last_trade_time (FULL)",
        "source_timestamp: exchange timestamp (FULL)",
        "market_depth, bid, ask, bid_quantity, ask_quantity (FULL)",
    ),
    depth_levels=5,
    max_instruments_per_connection=3000,
    max_connections_per_account=3,
    rest_rate_limits={
        "quote": "1 request/second; up to 500 instruments per /quote call",
        "ltp_ohlc": "up to 1000 instruments per /quote/ltp or /quote/ohlc call",
        "historical": "3 requests/second",
        "other": "10 requests/second",
    },
    token_expiry="The access token is invalidated at about 06:00 IST the next day, whatever the login time.",
    token_refresh=(
        "No refresh token for individual developer apps: complete the Kite login redirect once per "
        "trading day."
    ),
    entitlement=(
        "Paid Kite Connect plan (INR 500/month per app) for WebSocket streaming, market depth and "
        "historical candles. The free Personal plan has no market data."
    ),
    restrictions=(
        "Kite Connect terms prohibit redistributing, reselling or publicly displaying market data and "
        "using it in virtual or mock trading products: use it for the account holder only.",
        "instrument_token values of expired derivatives can be reused for new contracts: the instrument "
        "master must be refreshed daily (about 08:30 IST).",
        "Index instruments are not tradable and stream no volume or depth.",
        "Up to 3000 instruments per WebSocket connection and 3 connections per API key.",
    ),
    documentation_urls=(
        "https://kite.trade/docs/connect/v3/",
        "https://kite.trade/docs/connect/v3/user/",
        "https://kite.trade/docs/connect/v3/websocket/",
        "https://kite.trade/docs/connect/v3/market-quotes/",
        "https://kite.trade/docs/connect/v3/exceptions/",
        "https://developers.kite.trade/",
        "https://kite.trade/terms/",
    ),
    verified_on=VERIFIED_ON,
    verification_source=(
        "Kite Connect v3 documentation (user, websocket, market-quotes, exceptions), "
        "zerodha.com/products/api and the pykiteconnect 5.2.2 source (ticker.py binary parser)."
    ),
    needs_live_verification=(
        "WebSocket streaming and depth on the account's actual Kite Connect plan.",
        "Exact daily token invalidation time for the account (documented as about 06:00 IST).",
        "Historical candle downloads on the account's Kite Connect plan.",
    ),
)

GROWW = ProviderCapabilities(
    provider=Provider.GROWW,
    display_name="Groww Trading API",
    exchanges=(Exchange.NSE, Exchange.BSE),
    segments=(Segment.CASH, Segment.FNO, Segment.INDEX),
    instrument_types=(
        InstrumentType.EQUITY,
        InstrumentType.INDEX,
        InstrumentType.FUTURE,
        InstrumentType.OPTION,
    ),
    streaming=True,
    rest_quotes=True,
    # LTP and QUOTE both use the documented price feed; FULL adds the market-depth feed.
    subscription_modes=(SubscriptionMode.LTP, SubscriptionMode.QUOTE, SubscriptionMode.FULL),
    quote_fields=(
        "last_price",
        "open_price",
        "high_price",
        "low_price",
        "previous_close (feed 'close')",
        "average_price",
        "bid_quantity, ask_quantity (feed 'bidQty', 'offerQty')",
        "open_interest",
        "provider_timestamp (feed 'tsInMillis')",
        "volume (only when GROWW_FEED_VOLUME_IS_CUMULATIVE=true)",
        "market_depth, bid, ask (FULL)",
        "index value as last_price (indices)",
    ),
    depth_levels=None,
    max_instruments_per_connection=1000,
    max_connections_per_account=1,
    rest_rate_limits={
        "live_data": "10 requests/second and 300/minute; up to 50 instruments per LTP/OHLC call",
        "auth": "5 requests/second and 30/minute",
        "non_trading": "20 requests/second and 500/minute",
        "token": "150 access-token requests per 24 hours",
    },
    token_expiry=(
        "Access tokens expire daily. When a token carries no expiry claim, 06:00 IST the next day is assumed."
    ),
    token_refresh=(
        "Create a new access token daily: paste one generated in Groww Cloud, use API key + secret "
        "(requires daily approval in Groww Cloud), or use TOTP."
    ),
    entitlement=(
        "An active Groww Trading API subscription. The price is not published on an official page "
        "(third-party sources cite INR 499/month + taxes)."
    ),
    restrictions=(
        "NSE and BSE cash and F&O only: Groww documents no commodity (MCX) or currency feed.",
        "The feed allows up to 1000 subscriptions per connection; FULL uses two (price and depth).",
        "Depth is an aggregated, variable-size price-level book, not a fixed 5-level array.",
        "No Trading-API-specific redistribution terms were found: treat the data as for the account "
        "holder's own use only.",
    ),
    documentation_urls=(
        "https://groww.in/trade-api/docs",
        "https://groww.in/trade-api/docs/python-sdk",
        "https://groww.in/trade-api/docs/python-sdk/feed",
        "https://groww.in/trade-api/docs/python-sdk/instruments",
        "https://groww.in/trade-api/docs/python-sdk/annexures",
        "https://groww.in/trade-api/docs/curl",
    ),
    verified_on=VERIFIED_ON,
    verification_source=(
        "Groww Trading API documentation (python-sdk, feed, instruments, annexures, curl), the growwapi "
        "1.5.0 SDK source (feed, NATS client, protobuf schema) and the instrument CSV header."
    ),
    needs_live_verification=(
        "Feed transport is NATS over WebSocket (from the official SDK source; not stated in Groww's "
        "prose docs).",
        "TOTP token expiry: Groww's documentation conflicts ('No Expiry' versus daily approval).",
        "Meaning of the feed's tsInMillis (exchange time, last trade time or publish time).",
        "Feed 'close' is the previous session close.",
        "Feed 'bidQty'/'offerQty' are best bid/offer quantities, not total buy/sell quantities.",
        "Feed 'volume' semantics (ignored unless GROWW_FEED_VOLUME_IS_CUMULATIVE=true).",
        "Maximum concurrent feed connections per account (1 assumed).",
        "Instrument CSV expiry_date format and tick_size units.",
        "Historical candles: the time zone of timestamps without an offset (exchange-local assumed), "
        "the alignment of hourly candles and whether indices are covered.",
    ),
)

SIMULATOR = ProviderCapabilities(
    provider=Provider.SIMULATOR,
    display_name="Simulator (synthetic data)",
    # Only the synthetic SIM venue: simulated prices are never attached to real exchange symbols.
    exchanges=(Exchange.SIM,),
    segments=(Segment.CASH, Segment.INDEX),
    instrument_types=(InstrumentType.EQUITY, InstrumentType.INDEX),
    streaming=True,
    rest_quotes=False,
    subscription_modes=(SubscriptionMode.LTP, SubscriptionMode.QUOTE, SubscriptionMode.FULL),
    quote_fields=(
        "last_price",
        "last_quantity",
        "average_price (VWAP)",
        "volume (cumulative for the day)",
        "open_price",
        "high_price",
        "low_price",
        "previous_close",
        "last_trade_time",
        "bid, ask, bid_quantity, ask_quantity",
        "market_depth (FULL)",
        "source_timestamp",
        "index value as last_price with OHLC (indices)",
    ),
    depth_levels=5,
    max_instruments_per_connection=5000,
    max_connections_per_account=1,
    token_expiry="Not applicable.",
    token_refresh="Not applicable.",
    entitlement="None. Only available when APP_ENV is development or replay and SIMULATOR_ENABLED=true.",
    restrictions=(
        "Synthetic random-walk prices. Every event is labelled SIMULATED; never real market data.",
        "Streams only the synthetic SIM-exchange instruments (Simulation Lab workspace), never real "
        "exchange symbols.",
        "Never used as a fallback when a live provider is unavailable.",
    ),
    verified_on=None,
    verification_source="Built into Quant Terminal; produces no market data.",
)

_DEFAULTS: dict[Provider, ProviderCapabilities] = {
    caps.provider: caps for caps in (ZERODHA, GROWW, SIMULATOR)
}


def default_capabilities(provider: Provider) -> ProviderCapabilities:
    return _DEFAULTS[provider]


def all_default_capabilities() -> tuple[ProviderCapabilities, ...]:
    return tuple(_DEFAULTS.values())
