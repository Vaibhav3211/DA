"""Historical candles from provider REST APIs (M9; see docs/backtesting.md).

Only backtest datasets use history: nothing here feeds live charts or signals. A download asks for one
instrument at one interval over a range of exchange-local dates. It is split into windows the provider
accepts, sent one after another under the client's rate limits, and the candles come back in time order
without duplicates. Values are kept as the provider sent them; placing them on the exchange calendar is
the dataset builder's job.

Timestamps are candle starts. Kite sends them with an offset (``2017-12-15T09:15:00+0530``); one without
an offset is read as exchange-local time, and a number as a Unix time (seconds, or milliseconds when it
is too large to be seconds).
"""

from __future__ import annotations

import math
from collections.abc import Awaitable, Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta, tzinfo
from decimal import Decimal, InvalidOperation
from typing import Final

from app.domain.enums import CandleInterval, Provider, Segment
from app.providers.errors import ProviderProtocolError

_MILLISECONDS_FROM: Final = 100_000_000_000  # Unix times at or above this are milliseconds (year 5138+)

type WindowFetch = Callable[[str, date, date], Awaitable[Sequence[object]]]


@dataclass(frozen=True, slots=True)
class HistoricalCandle:
    start: datetime  # UTC
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: int | None
    open_interest: int | None


@dataclass(frozen=True, slots=True)
class HistorySupport:
    """What a provider's historical-candle API offers, from its documentation."""

    provider: Provider
    intervals: Mapping[CandleInterval, str]  # canonical interval -> the provider's name for it
    max_days: Mapping[CandleInterval, int]  # most exchange-local dates one request may cover
    segments: frozenset[Segment]
    note: str

    def problem(self, segment: Segment, interval: CandleInterval) -> str | None:
        """Why this API cannot supply the candles, or None."""
        if segment not in self.segments:
            shown = ", ".join(sorted(s.value for s in self.segments))
            return f"{self.provider.value} historical candles cover {shown} instruments, not {segment.value}"
        if interval not in self.intervals:
            shown = ", ".join(i.value for i in CandleInterval if i in self.intervals)
            return f"{self.provider.value} historical candles come in {shown}, not {interval.value}"
        return None


@dataclass(frozen=True, slots=True)
class History:
    candles: tuple[HistoricalCandle, ...]  # in time order, one per start
    requests: int
    duplicates: int  # candles received more than once (kept once)


KITE_HISTORY: Final = HistorySupport(
    provider=Provider.ZERODHA,
    intervals={
        CandleInterval.M1: "minute",
        CandleInterval.M3: "3minute",
        CandleInterval.M5: "5minute",
        CandleInterval.M15: "15minute",
        CandleInterval.M30: "30minute",
        CandleInterval.H1: "60minute",
        CandleInterval.D1: "day",
    },
    # Conservative ranges per request, below the limits Kite applies per interval.
    max_days={
        CandleInterval.M1: 30,
        CandleInterval.M3: 90,
        CandleInterval.M5: 90,
        CandleInterval.M15: 180,
        CandleInterval.M30: 180,
        CandleInterval.H1: 365,
        CandleInterval.D1: 1800,
    },
    segments=frozenset({Segment.CASH, Segment.FNO, Segment.CURRENCY, Segment.COMMODITY, Segment.INDEX}),
    note="Needs the paid Kite Connect plan. Limited to 3 requests per second.",
)

GROWW_HISTORY: Final = HistorySupport(
    provider=Provider.GROWW,
    intervals={
        CandleInterval.M1: "1minute",
        CandleInterval.M3: "3minute",
        CandleInterval.M5: "5minute",
        CandleInterval.M15: "15minute",
        CandleInterval.M30: "30minute",
        CandleInterval.H1: "1hour",
        CandleInterval.D1: "1day",
    },
    # Groww's documented limits per request: 30 days up to 5 minutes, 90 days up to 30 minutes, 180 days
    # from 1 hour.
    max_days={
        CandleInterval.M1: 30,
        CandleInterval.M3: 30,
        CandleInterval.M5: 30,
        CandleInterval.M15: 90,
        CandleInterval.M30: 90,
        CandleInterval.H1: 180,
        CandleInterval.D1: 180,
    },
    segments=frozenset({Segment.CASH, Segment.FNO}),
    note="Groww documents candles from 2020 onwards, for cash and F&O instruments only.",
)

HISTORY_SUPPORT: Final[Mapping[Provider, HistorySupport]] = {
    Provider.ZERODHA: KITE_HISTORY,
    Provider.GROWW: GROWW_HISTORY,
}


def date_windows(first: date, last: date, max_days: int) -> list[tuple[date, date]]:
    """Consecutive inclusive date ranges of at most ``max_days`` days covering ``first``..``last``."""
    if max_days < 1:
        raise ValueError("max_days must be positive")
    windows: list[tuple[date, date]] = []
    start = first
    while start <= last:
        end = min(last, start + timedelta(days=max_days - 1))
        windows.append((start, end))
        start = end + timedelta(days=1)
    return windows


async def download(
    support: HistorySupport,
    interval: CandleInterval,
    first_day: date,
    last_day: date,
    zone: tzinfo,
    fetch: WindowFetch,
) -> History:
    """Every candle of ``first_day``..``last_day``, fetched window by window with ``fetch(name, first,
    last)``. Raises ProviderProtocolError when a row cannot be read; provider errors propagate."""
    name = support.intervals.get(interval)
    if name is None:
        raise ValueError(f"{support.provider.value} has no {interval.value} historical candles")
    windows = date_windows(first_day, last_day, support.max_days[interval])
    collected: list[HistoricalCandle] = []
    for window_first, window_last in windows:
        rows = await fetch(name, window_first, window_last)
        collected.extend(parse_rows(rows, provider=support.provider, zone=zone))
    candles, duplicates = merge(collected)
    return History(candles=tuple(candles), requests=len(windows), duplicates=duplicates)


def merge(candles: Iterable[HistoricalCandle]) -> tuple[list[HistoricalCandle], int]:
    """Candles in time order, the first one kept for each start, and how many repeats were dropped."""
    by_start: dict[datetime, HistoricalCandle] = {}
    duplicates = 0
    for candle in candles:
        if candle.start in by_start:
            duplicates += 1
        else:
            by_start[candle.start] = candle
    return sorted(by_start.values(), key=lambda c: c.start), duplicates


def parse_rows(rows: Sequence[object], *, provider: Provider, zone: tzinfo) -> list[HistoricalCandle]:
    """``[timestamp, open, high, low, close, volume?, oi?]`` rows as candles."""
    candles: list[HistoricalCandle] = []
    for index, row in enumerate(rows):
        try:
            candles.append(_parse_row(row, zone))
        except ValueError as exc:
            raise ProviderProtocolError(
                f"{provider.value} historical candle {index} could not be read: {exc}"
            ) from None
    return candles


def _parse_row(row: object, zone: tzinfo) -> HistoricalCandle:
    if not isinstance(row, list | tuple) or len(row) < 5:
        raise ValueError("expected [timestamp, open, high, low, close, volume, oi]")
    return HistoricalCandle(
        start=parse_time(row[0], zone),
        open=_price(row[1], "open"),
        high=_price(row[2], "high"),
        low=_price(row[3], "low"),
        close=_price(row[4], "close"),
        volume=_count(row[5], "volume") if len(row) > 5 else None,
        open_interest=_count(row[6], "open interest") if len(row) > 6 else None,
    )


def parse_time(value: object, zone: tzinfo) -> datetime:
    """A candle timestamp as UTC: ISO text (exchange-local when it has no offset) or a Unix time."""
    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.strip())
        except ValueError:
            raise ValueError(f"unreadable timestamp {value!r}") from None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=zone)
        return parsed.astimezone(UTC)
    if isinstance(value, int | float) and not isinstance(value, bool) and math.isfinite(value) and value > 0:
        seconds = value / 1000 if value >= _MILLISECONDS_FROM else value
        return datetime.fromtimestamp(seconds, UTC)
    raise ValueError(f"unreadable timestamp {value!r}")


def _price(value: object, field: str) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, int | float | str):
        raise ValueError(f"{field} {value!r} is not a number")
    try:
        number = Decimal(str(value).strip())
    except InvalidOperation:
        raise ValueError(f"{field} {value!r} is not a number") from None
    if not number.is_finite() or number <= 0:
        raise ValueError(f"{field} {value!r} is not a positive price")
    return number


def _count(value: object, field: str) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError(f"{field} {value!r} is not a count")
    if isinstance(value, int):
        number = value
    elif isinstance(value, float) and value.is_integer():
        number = int(value)
    elif isinstance(value, str) and value.strip().isdigit():
        number = int(value.strip())
    else:
        raise ValueError(f"{field} {value!r} is not a count")
    if number < 0:
        raise ValueError(f"{field} {value!r} is negative")
    return number
