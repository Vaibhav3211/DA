"""Groww live-feed subjects and the provider token format this platform uses for Groww.

The SDK subscribes to NATS subjects built from a prefix and the instrument's exchange token
(growwapi 1.5.0 ``constants.py``)::

    /ld/eq/{nse|bse}/price.<exchange_token>        cash price feed
    /ld/fo/{nse|bse}/price.<exchange_token>        F&O price feed
    /ld/eq/{nse|bse}/book.<exchange_token>         cash market depth
    /ld/fo/{nse|bse}/book.<exchange_token>         F&O market depth
    /ld/indices/{nse|bse}/price.<exchange_token>   index value

Exchange tokens are only unique within one exchange and segment, so the platform's provider token
for a Groww instrument is ``EXCHANGE|SEGMENT|exchange_token`` (for example ``NSE|CASH|2885`` or
``NSE|INDEX|NIFTY``).

Security invariant: tokens are checked against a strict allow-list before they become subjects.
A NATS wildcard (``*``, ``>``) or an extra ``.`` could otherwise subscribe this connection to
unrelated subjects such as the account's order and position updates.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import StrEnum
from typing import Final

from app.domain.enums import Exchange, Segment, SubscriptionMode

_TOKEN: Final = re.compile(r"(NSE|BSE)\|(CASH|FNO|INDEX)\|([A-Za-z0-9_-]{1,64})")
_EXCHANGES: Final = {"NSE": Exchange.NSE, "BSE": Exchange.BSE}
_SEGMENTS: Final = {"CASH": Segment.CASH, "FNO": Segment.FNO, "INDEX": Segment.INDEX}
_SEGMENT_PREFIX: Final = {Segment.CASH: "eq", Segment.FNO: "fo"}


class FeedKind(StrEnum):
    PRICE = "price"
    INDEX = "index"
    DEPTH = "depth"


@dataclass(frozen=True, slots=True)
class FeedKey:
    exchange: Exchange
    segment: Segment
    exchange_token: str

    @property
    def provider_token(self) -> str:
        return f"{self.exchange.value}|{self.segment.value}|{self.exchange_token}"


def format_provider_token(exchange: Exchange, segment: Segment, exchange_token: str) -> str:
    """The provider token for one instrument. Raises ValueError for anything not streamable."""
    return parse_provider_token(FeedKey(exchange, segment, exchange_token).provider_token).provider_token


def parse_provider_token(token: str) -> FeedKey:
    match = _TOKEN.fullmatch(token)
    if match is None:
        raise ValueError("not a Groww provider token (expected EXCHANGE|SEGMENT|exchange_token)")
    exchange, segment, exchange_token = match.groups()
    return FeedKey(_EXCHANGES[exchange], _SEGMENTS[segment], exchange_token)


def feed_subjects(key: FeedKey, mode: SubscriptionMode) -> tuple[tuple[str, FeedKind], ...]:
    """Subjects (with their payload kind) that deliver one instrument in one subscription mode.

    LTP and QUOTE both use the price feed; FULL adds the market-depth feed. Indices have a single
    value feed and no depth.
    """
    exchange = key.exchange.value.lower()
    if key.segment is Segment.INDEX:
        return ((f"/ld/indices/{exchange}/price.{key.exchange_token}", FeedKind.INDEX),)
    prefix = f"/ld/{_SEGMENT_PREFIX[key.segment]}/{exchange}"
    subjects = [(f"{prefix}/price.{key.exchange_token}", FeedKind.PRICE)]
    if mode is SubscriptionMode.FULL:
        subjects.append((f"{prefix}/book.{key.exchange_token}", FeedKind.DEPTH))
    return tuple(subjects)
