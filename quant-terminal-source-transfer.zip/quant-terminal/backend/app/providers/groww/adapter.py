"""Groww Trading API market-data adapter.

One feed connection per account with up to 1000 NATS subscriptions (capability registry). An
instrument uses one subscription per feed: LTP/QUOTE use the price feed and FULL adds the depth
feed, so ``slot_cost`` counts subjects rather than instruments. The access token is loaded from the
encrypted account store on every connection attempt, so a new token takes effect on reconnect.
"""

from __future__ import annotations

from typing import ClassVar

from app.domain.enums import Provider
from app.domain.models import ProviderInstrument
from app.providers.base import MarketDataAdapter, StreamSession
from app.providers.errors import UnsupportedInstrumentError
from app.providers.groww.feed import GrowwFeedSession, instrument_feed_key
from app.providers.groww.topics import feed_subjects

# Send a NATS PING after this share of the stream heartbeat timeout without any message.
_HEARTBEAT_SHARE = 3
_MIN_HEARTBEAT_INTERVAL = 0.5
_MAX_HEARTBEAT_INTERVAL = 5.0


class GrowwAdapter(MarketDataAdapter):
    provider: ClassVar[Provider] = Provider.GROWW

    def create_session(self, shard: int) -> StreamSession:
        settings = self.settings
        interval = settings.feed_heartbeat_timeout_seconds / _HEARTBEAT_SHARE
        return GrowwFeedSession(
            socket_url=settings.groww_socket_url,
            api_base_url=settings.groww_api_base_url,
            credentials=self.load_credentials,
            account_id=self.account_id,
            heartbeat_interval=max(_MIN_HEARTBEAT_INTERVAL, min(_MAX_HEARTBEAT_INTERVAL, interval)),
            volume_is_cumulative=settings.groww_feed_volume_is_cumulative,
        )

    def slot_cost(self, instrument: ProviderInstrument) -> int:
        return len(feed_subjects(instrument_feed_key(instrument), instrument.mode))

    def _validate(self, instrument: ProviderInstrument) -> None:
        super()._validate(instrument)
        key = instrument_feed_key(instrument)
        if key.exchange is not instrument.exchange or key.segment is not instrument.segment:
            raise UnsupportedInstrumentError(
                f"{instrument.symbol} has a Groww feed token for another exchange or segment; "
                "refresh the instrument master"
            )
