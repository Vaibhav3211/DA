"""Decoder for the Groww live-feed protobuf messages (proto3 package ``stocksData.response``).

Every feed message is one ``StocksSocketResponseProtoDto`` (growwapi 1.5.0
``stocks_socket_response.proto`` and ``proto_parser.py``)::

    StocksSocketResponseProtoDto { string symbol = 1; StockSegmentProto segment = 2;
        StockExchangeProto exchange = 3;
        oneof livePoint { StocksLivePriceProto stockLivePrice = 4;
                          StocksMarketDepthProto stocksMarketDepth = 5;
                          StocksLiveIndicesProto stocksLiveIndices = 6; } }
    StocksLivePriceProto   doubles: tsInMillis 1, open 2, high 3, low 4, close 5, volume 6,
                           value 7, bidQty 8, offerQty 9, avgPrice 10, highPriceRange 11,
                           lowPriceRange 12, ltp 13, openInterest 14, lowTradeRange 15,
                           highTradeRange 16
    StocksLiveIndicesProto doubles: tsInMillis 1, value 2
    StocksMarketDepthProto double tsInMillis 1; map<int32, BookProto> buyBook 2, sellBook 3
    BookProto              doubles: price 1, qty 2
    StockSegmentProto      CASH 0, FNO 1, CURRENCY 2, COMMODITY 3
    StockExchangeProto     BSE 0, NSE 1, MCX 2, MCXSX 3, NCDEX 4, GLOBAL 5, US 6

The schema is small, so a strict decoder here keeps generated code and the protobuf runtime out of
the application. Semantics follow protobuf: absent fields read as zero, the last value of a repeated
scalar wins, repeated embedded messages merge, a later oneof member replaces an earlier one and
unknown fields are skipped. Structurally invalid input raises ``ProtoDecodeError``, and so does a
known field with an unexpected wire type (protobuf would ignore it): schema drift then shows up as
malformed messages instead of silent zeros. Tests cross-check this decoder against the SDK's
generated module when it is installed.
"""

from __future__ import annotations

import struct
from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from typing import Final

from app.providers.groww.exceptions import GrowwPayloadError

_MAX_VARINT_BYTES: Final = 10
_MASK64: Final = (1 << 64) - 1
_DOUBLE: Final = struct.Struct("<d")

_VARINT: Final = 0
_FIXED64: Final = 1
_LENGTH_DELIMITED: Final = 2
_FIXED32: Final = 5

SEGMENT_NAMES: Final = {0: "CASH", 1: "FNO", 2: "CURRENCY", 3: "COMMODITY"}
EXCHANGE_NAMES: Final = {0: "BSE", 1: "NSE", 2: "MCX", 3: "MCXSX", 4: "NCDEX", 5: "GLOBAL", 6: "US"}

_LIVE_PRICE_FIELDS: Final = {
    1: "ts_in_millis",
    2: "open",
    3: "high",
    4: "low",
    5: "close",
    6: "volume",
    7: "value",
    8: "bid_qty",
    9: "offer_qty",
    10: "avg_price",
    11: "high_price_range",
    12: "low_price_range",
    13: "ltp",
    14: "open_interest",
    15: "low_trade_range",
    16: "high_trade_range",
}
_INDEX_FIELDS: Final = {1: "ts_in_millis", 2: "value"}
_BOOK_FIELDS: Final = {1: "price", 2: "qty"}

_LIVE_PRICE: Final = 4
_MARKET_DEPTH: Final = 5
_LIVE_INDEX: Final = 6


class ProtoDecodeError(GrowwPayloadError):
    """The bytes are not a valid encoding of the expected feed message."""


@dataclass(frozen=True, slots=True)
class LivePrice:
    ts_in_millis: float = 0.0
    open: float = 0.0
    high: float = 0.0
    low: float = 0.0
    close: float = 0.0
    volume: float = 0.0
    value: float = 0.0
    bid_qty: float = 0.0
    offer_qty: float = 0.0
    avg_price: float = 0.0
    high_price_range: float = 0.0
    low_price_range: float = 0.0
    ltp: float = 0.0
    open_interest: float = 0.0
    low_trade_range: float = 0.0
    high_trade_range: float = 0.0


@dataclass(frozen=True, slots=True)
class IndexValue:
    ts_in_millis: float = 0.0
    value: float = 0.0


@dataclass(frozen=True, slots=True)
class BookLevel:
    price: float = 0.0
    qty: float = 0.0


@dataclass(frozen=True, slots=True)
class MarketDepthPoint:
    ts_in_millis: float
    buy_book: Mapping[int, BookLevel]
    sell_book: Mapping[int, BookLevel]


type LivePoint = LivePrice | MarketDepthPoint | IndexValue


@dataclass(frozen=True, slots=True)
class FeedMessage:
    symbol: str
    segment: int
    exchange: int
    point: LivePoint | None


def decode_feed_message(data: bytes) -> FeedMessage:
    symbol = ""
    segment = exchange = 0
    member: int | None = None
    chunks: list[bytes] = []
    for number, wire, value in _iter_fields(data):
        if number == 1:
            symbol = _text(_expect_bytes(number, wire, value))
        elif number == 2:
            segment = _int32(_expect_varint(number, wire, value))
        elif number == 3:
            exchange = _int32(_expect_varint(number, wire, value))
        elif number in (_LIVE_PRICE, _MARKET_DEPTH, _LIVE_INDEX):
            chunk = _expect_bytes(number, wire, value)
            if member != number:
                member, chunks = number, []
            chunks.append(chunk)
    point: LivePoint | None = None
    if member is not None:
        body = b"".join(chunks)
        if member == _LIVE_PRICE:
            point = LivePrice(**_doubles(body, _LIVE_PRICE_FIELDS))
        elif member == _LIVE_INDEX:
            point = IndexValue(**_doubles(body, _INDEX_FIELDS))
        else:
            point = _market_depth(body)
    return FeedMessage(symbol=symbol, segment=segment, exchange=exchange, point=point)


# ---- message bodies ------------------------------------------------------------------------------


def _doubles(data: bytes, names: Mapping[int, str]) -> dict[str, float]:
    values: dict[str, float] = {}
    for number, wire, value in _iter_fields(data):
        name = names.get(number)
        if name is not None:
            values[name] = _expect_double(number, wire, value)
    return values


def _market_depth(data: bytes) -> MarketDepthPoint:
    ts_in_millis = 0.0
    buy: dict[int, BookLevel] = {}
    sell: dict[int, BookLevel] = {}
    for number, wire, value in _iter_fields(data):
        if number == 1:
            ts_in_millis = _expect_double(number, wire, value)
        elif number in (2, 3):
            key, level = _book_entry(_expect_bytes(number, wire, value))
            (buy if number == 2 else sell)[key] = level  # a repeated key replaces the earlier entry
    return MarketDepthPoint(ts_in_millis=ts_in_millis, buy_book=buy, sell_book=sell)


def _book_entry(data: bytes) -> tuple[int, BookLevel]:
    key = 0
    chunks: list[bytes] = []
    for number, wire, value in _iter_fields(data):
        if number == 1:
            key = _int32(_expect_varint(number, wire, value))
        elif number == 2:
            chunks.append(_expect_bytes(number, wire, value))
    return key, BookLevel(**_doubles(b"".join(chunks), _BOOK_FIELDS))


# ---- wire format ---------------------------------------------------------------------------------


def _iter_fields(data: bytes) -> Iterator[tuple[int, int, int | float | bytes | None]]:
    """(field number, wire type, value) for every field. Fixed32 values are skipped (None)."""
    position, end = 0, len(data)
    while position < end:
        key, position = _read_varint(data, position)
        number, wire = key >> 3, key & 0x07
        if number == 0:
            raise ProtoDecodeError("field number 0 is invalid")
        if wire == _VARINT:
            varint, position = _read_varint(data, position)
            yield number, wire, varint
        elif wire == _FIXED64:
            if end - position < 8:
                raise ProtoDecodeError("truncated 64-bit field")
            yield number, wire, _DOUBLE.unpack_from(data, position)[0]
            position += 8
        elif wire == _LENGTH_DELIMITED:
            length, position = _read_varint(data, position)
            if length > end - position:
                raise ProtoDecodeError("truncated length-delimited field")
            yield number, wire, data[position : position + length]
            position += length
        elif wire == _FIXED32:
            if end - position < 4:
                raise ProtoDecodeError("truncated 32-bit field")
            yield number, wire, None
            position += 4
        else:  # 3 and 4 are deprecated groups; 6 and 7 do not exist
            raise ProtoDecodeError(f"unsupported wire type {wire}")


def _read_varint(data: bytes, position: int) -> tuple[int, int]:
    result = shift = 0
    for _ in range(_MAX_VARINT_BYTES):
        if position >= len(data):
            raise ProtoDecodeError("truncated varint")
        byte = data[position]
        position += 1
        result |= (byte & 0x7F) << shift
        if byte < 0x80:
            return result & _MASK64, position
        shift += 7
    raise ProtoDecodeError("varint is longer than 10 bytes")


def _expect_varint(number: int, wire: int, value: object) -> int:
    if wire != _VARINT or not isinstance(value, int):
        raise ProtoDecodeError(f"field {number} has wire type {wire}, expected a varint")
    return value


def _expect_double(number: int, wire: int, value: object) -> float:
    if wire != _FIXED64 or not isinstance(value, float):
        raise ProtoDecodeError(f"field {number} has wire type {wire}, expected a double")
    return value


def _expect_bytes(number: int, wire: int, value: object) -> bytes:
    if wire != _LENGTH_DELIMITED or not isinstance(value, bytes):
        raise ProtoDecodeError(f"field {number} has wire type {wire}, expected length-delimited")
    return value


def _int32(value: int) -> int:
    value &= 0xFFFFFFFF
    return value - (1 << 32) if value >= 1 << 31 else value


def _text(value: bytes) -> str:
    try:
        return value.decode("utf-8")
    except UnicodeDecodeError:
        raise ProtoDecodeError("string field is not valid UTF-8") from None
