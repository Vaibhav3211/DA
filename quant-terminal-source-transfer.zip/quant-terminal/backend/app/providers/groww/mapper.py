"""Groww feed and REST payloads mapped to ``ProviderTick``.

Feed semantics that the documentation does not pin down are mapped conservatively (see
docs/providers/groww.md, "Unverified behaviour"):

* ``tsInMillis`` becomes ``provider_timestamp`` (its exchange or Groww origin is undocumented).
* ``close`` is treated as the previous session close, as in other Indian broker feeds.
* ``bidQty``/``offerQty`` become best bid/ask quantities; the feed carries no bid/ask prices.
* ``volume`` is used only when GROWW_FEED_VOLUME_IS_CUMULATIVE confirms it is cumulative day
  volume; otherwise volume stays unavailable rather than guessed.
* Zero means "absent" in proto3, so zero prices and quantities become None, never 0.
"""

from __future__ import annotations

import math
from collections.abc import Iterable, Mapping
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Final
from uuid import UUID

from app.core.clock import from_epoch_millis
from app.domain.enums import EventType, Provider, Segment, VolumeSemantics
from app.domain.models import DepthLevel, MarketDepth, ProviderTick
from app.providers.base import payload_digest
from app.providers.groww.exceptions import GrowwPayloadError
from app.providers.groww.proto import BookLevel, FeedMessage, IndexValue, LivePrice, MarketDepthPoint
from app.providers.groww.topics import FeedKind

_MAX_QUANTITY: Final = 2**63 - 1
_POINT_TYPES: Final = {
    FeedKind.PRICE: LivePrice,
    FeedKind.INDEX: IndexValue,
    FeedKind.DEPTH: MarketDepthPoint,
}


def feed_message_to_tick(
    message: FeedMessage,
    *,
    kind: FeedKind,
    provider_token: str,
    segment: Segment,
    raw: bytes,
    account_id: UUID | None,
    received_at: datetime,
    volume_is_cumulative: bool = False,
) -> ProviderTick | None:
    """The tick for one feed message, or None when it carries no usable value.

    Raises ``GrowwPayloadError`` when the payload type does not belong to the subject's feed.
    """
    point = message.point
    if point is None:
        return None
    if not isinstance(point, _POINT_TYPES[kind]):
        raise GrowwPayloadError(f"the {kind.value} feed delivered a {type(point).__name__} payload")
    fields: dict[str, Any] | None
    if isinstance(point, LivePrice):
        fields, event_type = _live_price_fields(point, segment, volume_is_cumulative)
    elif isinstance(point, IndexValue):
        fields, event_type = _index_fields(point), EventType.INDEX_VALUE
    else:
        fields, event_type = _depth_fields(point), EventType.DEPTH
    if fields is None:
        return None
    return ProviderTick.model_construct(
        provider=Provider.GROWW,
        account_id=account_id,
        provider_token=provider_token,
        event_type=event_type,
        received_at=received_at,
        raw_payload_hash=payload_digest(raw),
        **fields,
    )


def _live_price_fields(
    point: LivePrice, segment: Segment, volume_is_cumulative: bool
) -> tuple[dict[str, Any] | None, EventType]:
    extra: dict[str, Any] = {
        "open_price": _price(point.open),
        "high_price": _price(point.high),
        "low_price": _price(point.low),
        "previous_close": _price(point.close),
        "average_price": _price(point.avg_price),
        "bid_quantity": _quantity(point.bid_qty),
        "ask_quantity": _quantity(point.offer_qty),
    }
    if segment is Segment.FNO:
        extra["open_interest"] = _quantity(point.open_interest)
    if volume_is_cumulative:
        volume = _quantity(point.volume)
        if volume is not None:
            extra.update(volume=volume, volume_semantics=VolumeSemantics.CUMULATIVE_DAY)
    extra = {name: value for name, value in extra.items() if value is not None}
    last_price = _price(point.ltp)
    if last_price is None and not extra:
        return None, EventType.LTP
    fields = {
        "last_price": last_price,
        "provider_timestamp": _timestamp(point.ts_in_millis),
        **extra,
    }
    return fields, EventType.QUOTE if extra else EventType.LTP


def _index_fields(point: IndexValue) -> dict[str, Any] | None:
    value = _price(point.value)
    if value is None:
        return None
    return {"last_price": value, "provider_timestamp": _timestamp(point.ts_in_millis)}


def _depth_fields(point: MarketDepthPoint) -> dict[str, Any] | None:
    bids = _levels(point.buy_book.values(), best_first_descending=True)
    asks = _levels(point.sell_book.values(), best_first_descending=False)
    timestamp = _timestamp(point.ts_in_millis)
    if not bids and not asks and timestamp is None:
        return None
    fields: dict[str, Any] = {
        "market_depth": MarketDepth.model_construct(bids=bids, asks=asks),
        "provider_timestamp": timestamp,
    }
    if bids:
        fields["bid"], fields["bid_quantity"] = bids[0].price, bids[0].quantity
    if asks:
        fields["ask"], fields["ask_quantity"] = asks[0].price, asks[0].quantity
    return fields


def _levels(levels: Iterable[BookLevel], *, best_first_descending: bool) -> tuple[DepthLevel, ...]:
    result: list[DepthLevel] = []
    for level in levels:
        price, quantity = _price(level.price), _quantity(level.qty)
        if price is None or quantity is None:
            continue  # empty book levels are zero-filled; never report them as price 0
        result.append(DepthLevel.model_construct(price=price, quantity=quantity, orders=None))
    result.sort(key=lambda level: level.price, reverse=best_first_descending)
    return tuple(result)


def _price(value: float) -> Decimal | None:
    if not math.isfinite(value) or value <= 0:
        return None
    return Decimal(repr(value))


def _quantity(value: float) -> int | None:
    if not math.isfinite(value) or value <= 0 or value > _MAX_QUANTITY:
        return None
    return int(value)


def _timestamp(millis: float) -> datetime | None:
    if not math.isfinite(millis) or millis <= 0:
        return None
    try:
        return from_epoch_millis(millis)
    except (OverflowError, OSError, ValueError):
        return None


# ---- REST (supplemental snapshots; never a substitute for the feed) ------------------------------


def rest_quote_to_tick(
    payload: Mapping[str, Any],
    *,
    provider_token: str,
    segment: Segment,
    account_id: UUID | None,
    received_at: datetime,
) -> ProviderTick:
    """Map a ``/live-data/quote`` payload. Field names are mapped tolerantly (unverified live)."""
    ohlc_value = payload.get("ohlc")
    ohlc: Mapping[str, Any] = ohlc_value if isinstance(ohlc_value, Mapping) else {}
    fields: dict[str, Any] = {
        "last_price": _json_price(payload.get("last_price")),
        "open_price": _json_price(ohlc.get("open")),
        "high_price": _json_price(ohlc.get("high")),
        "low_price": _json_price(ohlc.get("low")),
        "previous_close": _json_price(ohlc.get("close")),
        "average_price": _json_price(payload.get("average_price")),
        "last_quantity": _json_quantity(payload.get("last_trade_quantity")),
        "total_buy_quantity": _json_quantity(payload.get("total_buy_quantity")),
        "total_sell_quantity": _json_quantity(payload.get("total_sell_quantity")),
        "last_trade_time": _json_millis(payload.get("last_trade_time")),
        "bid": _json_price(payload.get("bid_price")),
        "bid_quantity": _json_quantity(payload.get("bid_quantity")),
        "ask": _json_price(payload.get("offer_price")),
        "ask_quantity": _json_quantity(payload.get("offer_quantity")),
    }
    volume = _json_quantity(payload.get("volume"))
    if volume is not None:
        fields.update(volume=volume, volume_semantics=VolumeSemantics.CUMULATIVE_DAY)
    if segment is Segment.FNO:
        fields["open_interest"] = _json_quantity(payload.get("open_interest"))
    depth = payload.get("depth")
    if isinstance(depth, Mapping):
        bids = _json_depth(depth.get("buy"), best_first_descending=True)
        asks = _json_depth(depth.get("sell"), best_first_descending=False)
        if bids or asks:
            fields["market_depth"] = MarketDepth(bids=bids, asks=asks)
        if bids and fields["bid"] is None:
            fields["bid"], fields["bid_quantity"] = bids[0].price, bids[0].quantity
        if asks and fields["ask"] is None:
            fields["ask"], fields["ask_quantity"] = asks[0].price, asks[0].quantity
    if all(value is None for value in fields.values()):
        raise GrowwPayloadError("the Groww quote has no usable values")
    if segment is Segment.INDEX:
        event_type = EventType.INDEX_VALUE
    else:
        has_extra = any(value is not None for name, value in fields.items() if name != "last_price")
        event_type = EventType.QUOTE if has_extra else EventType.LTP
    return ProviderTick(
        provider=Provider.GROWW,
        account_id=account_id,
        provider_token=provider_token,
        event_type=event_type,
        received_at=received_at,
        **fields,
    )


def rest_ltp_to_tick(
    value: object,
    *,
    provider_token: str,
    segment: Segment,
    account_id: UUID | None,
    received_at: datetime,
) -> ProviderTick:
    """Map one value of a ``/live-data/ltp`` payload (a number keyed by exchange symbol)."""
    price = _json_price(value)
    if price is None:
        raise GrowwPayloadError("the Groww LTP response has no usable price")
    return ProviderTick(
        provider=Provider.GROWW,
        account_id=account_id,
        provider_token=provider_token,
        event_type=EventType.INDEX_VALUE if segment is Segment.INDEX else EventType.LTP,
        received_at=received_at,
        last_price=price,
    )


def _json_price(value: object) -> Decimal | None:
    if value is None or isinstance(value, bool) or not isinstance(value, int | float | str):
        return None
    try:
        price = Decimal(repr(value) if isinstance(value, float) else str(value))
    except InvalidOperation:
        return None
    return price if price.is_finite() and price > 0 else None


def _json_quantity(value: object) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    if isinstance(value, int):  # JSON integers are unbounded; float() could overflow
        return value if 0 < value <= _MAX_QUANTITY else None
    return _quantity(value)


def _json_millis(value: object) -> datetime | None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    try:
        millis = float(value)
    except OverflowError:
        return None
    return _timestamp(millis)


def _json_depth(levels: object, *, best_first_descending: bool) -> tuple[DepthLevel, ...]:
    if not isinstance(levels, list):
        return ()
    result: list[DepthLevel] = []
    for level in levels:
        if not isinstance(level, Mapping):
            continue
        price, quantity = _json_price(level.get("price")), _json_quantity(level.get("quantity"))
        if price is None or quantity is None:
            continue
        result.append(DepthLevel(price=price, quantity=quantity))
    result.sort(key=lambda level: level.price, reverse=best_first_descending)
    return tuple(result)
