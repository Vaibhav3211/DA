"""Groww access-token and feed-credential helpers (pure; no I/O).

Access tokens (growwapi 1.5.0 ``GrowwAPI.get_access_token``): ``POST /token/api/access`` with
``Authorization: Bearer <api key>`` and either

* ``{"key_type": "approval", "checksum": SHA-256(secret + timestamp), "timestamp": <epoch s>}``
  (API key + secret; the key must be approved in Groww Cloud every day), or
* ``{"key_type": "totp", "totp": "<6 digits>"}`` (the TOTP token is sent as the API key).

An access token generated in Groww Cloud can also be pasted directly.

Live feed: every connection generates a fresh NKEY user key pair. ``POST
/api/apex/v1/socket/token/create/ {"socketKey": <public key>}`` returns a NATS user JWT bound to
that key, and the seed signs the server's connection nonce. The seed exists only in memory for
one connection attempt and is never stored or logged.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any, Final

import nkeys

from app.core.clock import IST, ensure_utc, from_epoch_seconds
from app.providers.errors import ProviderProtocolError
from app.providers.groww.constants import TOKEN_RESET_HOUR_IST
from app.providers.groww.exceptions import PROVIDER_NAME

# A NATS user JWT is three base64url segments; anything else (newlines in particular) could
# corrupt the credentials text handed to nats-py.
_FEED_JWT: Final = re.compile(r"[A-Za-z0-9_=-]{1,8192}\.[A-Za-z0-9_=-]{1,8192}\.[A-Za-z0-9_=-]{0,8192}")
_USER_SEED: Final = re.compile(r"SU[A-Z2-7]{56}")


def approval_checksum(api_secret: str, timestamp: int) -> str:
    return hashlib.sha256(f"{api_secret}{timestamp}".encode()).hexdigest()


def jwt_expiry(token: str) -> datetime | None:
    """The unverified ``exp`` claim of a JWT-shaped token, or None when it has none."""
    parts = token.split(".")
    if len(parts) != 3:
        return None
    try:
        claims: Any = json.loads(base64.urlsafe_b64decode(parts[1] + "=" * (-len(parts[1]) % 4)))
        expiry = claims.get("exp") if isinstance(claims, dict) else None
        if isinstance(expiry, bool) or not isinstance(expiry, int | float):
            return None
        return from_epoch_seconds(expiry)
    except (binascii.Error, ValueError, OverflowError, OSError):
        return None


def next_daily_reset(issued_at: datetime) -> datetime:
    """The first 06:00 IST strictly after ``issued_at``."""
    local = ensure_utc(issued_at).astimezone(IST)
    reset = local.replace(hour=TOKEN_RESET_HOUR_IST, minute=0, second=0, microsecond=0)
    if reset <= local:
        reset += timedelta(days=1)  # IST has no daylight saving time
    return reset.astimezone(UTC)


def token_expiry(token: str, issued_at: datetime) -> datetime:
    """The token's own expiry claim when it has a plausible one, else the next daily reset."""
    expiry = jwt_expiry(token)
    if expiry is not None and expiry > ensure_utc(issued_at):
        return expiry
    return next_daily_reset(issued_at)


@dataclass(frozen=True, slots=True)
class NkeyPair:
    public_key: str
    seed: str = field(repr=False)


def new_user_nkey() -> NkeyPair:
    """A fresh NATS user key pair (Ed25519) for one feed connection."""
    seed: bytes = nkeys.encode_seed(os.urandom(32), nkeys.PREFIX_BYTE_USER)
    key_pair = nkeys.from_seed(seed)
    try:
        public_key: bytes = key_pair.public_key
    finally:
        key_pair.wipe()
    return NkeyPair(public_key=public_key.decode("ascii"), seed=seed.decode("ascii"))


def nats_credentials(jwt: str, seed: str) -> str:
    """NATS ``.creds`` text for nats-py's ``RawCredentials`` (each value on its own line)."""
    if not _FEED_JWT.fullmatch(jwt):
        raise ProviderProtocolError(f"{PROVIDER_NAME} returned a malformed feed token")
    if not _USER_SEED.fullmatch(seed):
        raise ValueError("not an NKEY user seed")
    return (
        "-----BEGIN NATS USER JWT-----\n"
        f"{jwt}\n"
        "------END NATS USER JWT------\n"
        "\n"
        "-----BEGIN USER NKEY SEED-----\n"
        f"{seed}\n"
        "------END USER NKEY SEED------\n"
    )
