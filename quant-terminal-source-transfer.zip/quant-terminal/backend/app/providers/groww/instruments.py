"""Groww instrument master: a public CSV (about 136k rows) regenerated daily.

Columns used: exchange (NSE, BSE, ...), exchange_token (the live-feed key; numeric for stocks and
derivatives, a name such as NIFTY for indices), trading_symbol, groww_symbol, name,
instrument_type (EQ, FUT, CE, PE, IDX, ...), segment (CASH, FNO, ...), series, isin,
underlying_symbol, expiry_date, strike_price, lot_size and tick_size. Futures carry placeholder
strikes (e.g. -0.01) and the file contains exchange test instruments (NSETEST/BSETEST); both are
handled explicitly. Rows outside NSE/BSE cash, F&O and indices are skipped with a reason.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Final

from app.core.clock import IST, utc_now
from app.domain.enums import InstrumentType, OptionType, Provider, Segment
from app.domain.models import ProviderInstrumentRecord
from app.providers.groww.constants import EXCHANGES, SEGMENTS
from app.providers.groww.exceptions import PROVIDER_NAME
from app.providers.groww.topics import format_provider_token
from app.providers.instrument_dump import (
    InstrumentDump,
    finish,
    parse_decimal,
    parse_positive_decimal,
    parse_positive_int,
    read_csv,
)

COLUMNS: Final = ("exchange", "exchange_token", "trading_symbol", "segment", "instrument_type")

_TYPES: Final = {
    "EQ": (InstrumentType.EQUITY, None),
    "FUT": (InstrumentType.FUTURE, None),
    "CE": (InstrumentType.OPTION, OptionType.CE),
    "PE": (InstrumentType.OPTION, OptionType.PE),
}
_INDEX_TYPES: Final = frozenset({"IDX", "INDEX"})
_INDEX_SEGMENTS: Final = frozenset({"IDX", "INDEX", "INDICES"})
_TEST_PREFIXES: Final = ("NSETEST", "BSETEST")
# Expiries further out than this are placeholders, not tradable contracts.
_MAX_EXPIRY_AHEAD: Final = timedelta(days=3653)
_DAY_MONTH_YEAR: Final = re.compile(r"([0-9]{1,2})[-/ ]([A-Za-z]{3}|[0-9]{1,2})[-/ ]([0-9]{4})")
_MONTHS: Final = {
    name: number
    for number, name in enumerate(
        ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"), start=1
    )
}


class RowSkipped(Exception):
    """A valid row this platform does not stream; ``reason`` is reported in refresh statistics."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


def parse_instrument_dump(data: bytes, *, today: date | None = None) -> InstrumentDump:
    reference = today or utc_now().astimezone(IST).date()
    dump = InstrumentDump(Provider.GROWW)
    seen: set[str] = set()
    for row in read_csv(data, provider_name=PROVIDER_NAME, required=COLUMNS):
        dump.rows += 1
        try:
            record = parse_row(row, today=reference)
        except RowSkipped as skipped:
            dump.skip(skipped.reason)
            continue
        except ValueError:  # includes pydantic.ValidationError
            dump.skip("invalid_row")
            continue
        if record.provider_token in seen:
            dump.skip("duplicate_token")
            continue
        seen.add(record.provider_token)
        dump.records.append(record)
    return finish(dump, PROVIDER_NAME)


def parse_row(row: Mapping[str, str], *, today: date) -> ProviderInstrumentRecord:
    """One CSV row. Raises ``RowSkipped`` for unsupported rows and ValueError for invalid ones."""
    exchange = EXCHANGES.get(row["exchange"].upper())
    if exchange is None:
        raise RowSkipped("unsupported_exchange")
    symbol = row["trading_symbol"]
    if not symbol:
        raise ValueError("empty trading_symbol")
    name = row.get("name", "")
    underlying_symbol = row.get("underlying_symbol", "")
    if any(value.upper().startswith(_TEST_PREFIXES) for value in (symbol, underlying_symbol, name)):
        raise RowSkipped("test_instrument")
    raw_type = row["instrument_type"].upper()
    raw_segment = row["segment"].upper()
    is_index = raw_type in _INDEX_TYPES or raw_segment in _INDEX_SEGMENTS
    segment = Segment.INDEX if is_index else SEGMENTS.get(raw_segment)
    if segment is None:
        raise RowSkipped("unsupported_segment")
    try:
        provider_token = format_provider_token(exchange, segment, row["exchange_token"])
    except ValueError:
        raise RowSkipped("unsupported_token") from None
    common: dict[str, Any] = {
        "provider": Provider.GROWW,
        "provider_token": provider_token,
        "exchange_token": row["exchange_token"],
        "provider_symbol": symbol,
        "provider_exchange": row["exchange"],
        "provider_segment": row["segment"],
        "exchange": exchange,
        "isin": row.get("isin") or None,
        "tick_size": parse_positive_decimal(row.get("tick_size", "")),
        "metadata": _metadata(row),
    }
    if is_index:
        return ProviderInstrumentRecord(
            **common,
            segment=Segment.INDEX,
            instrument_type=InstrumentType.INDEX,
            name=name or symbol,
            tradable=False,
        )
    instrument_type, option_type = _TYPES.get(raw_type, (InstrumentType.OTHER, None))
    expiry: date | None = None
    underlying: str | None = None
    strike: Decimal | None = None
    if instrument_type in (InstrumentType.FUTURE, InstrumentType.OPTION):
        expiry = parse_expiry(row.get("expiry_date", ""))
        underlying = underlying_symbol or name
        if expiry is None or not underlying:
            raise ValueError("derivative without expiry or underlying")
        if expiry > today + _MAX_EXPIRY_AHEAD:
            raise RowSkipped("implausible_expiry")
        if option_type is not None:
            strike = parse_decimal(row.get("strike_price", ""))
            if strike is None or strike <= 0:
                raise ValueError("option without a strike")
    return ProviderInstrumentRecord(
        **common,
        segment=segment,
        instrument_type=instrument_type,
        name=name or None,
        underlying=underlying,
        expiry=expiry,
        strike=strike,
        option_type=option_type,
        lot_size=parse_positive_int(row.get("lot_size", "")),
    )


def parse_expiry(value: str) -> date | None:
    """ISO dates (optionally followed by a time) and day-month-year forms such as 27-03-2026 or
    27-Mar-2026. Raises ValueError for anything else."""
    if not value:
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        pass
    match = _DAY_MONTH_YEAR.fullmatch(value)
    if match is None:
        raise ValueError("unrecognised expiry date")
    day, month, year = match.groups()
    month_number = int(month) if month.isdigit() else _MONTHS.get(month.upper())
    if month_number is None:
        raise ValueError("unrecognised expiry month")
    return date(int(year), month_number, int(day))


def _metadata(row: Mapping[str, str]) -> dict[str, Any]:
    values = {
        "instrument_type": row["instrument_type"],
        "groww_symbol": row.get("groww_symbol", ""),
        "series": row.get("series", ""),
    }
    return {key: value for key, value in values.items() if value}
