"""Groww live feed session: NATS over WebSocket, the transport used by growwapi 1.5.0.

Connection sequence (every attempt is independent; nothing is reused across attempts):

1. Generate a fresh NKEY user key pair in memory.
2. ``POST /api/apex/v1/socket/token/create/ {"socketKey": <public key>}`` with the account's access
   token returns a NATS user JWT bound to that key (HTTP 401 means the access token is invalid).
3. Connect to ``wss://socket-api.groww.in`` with the JWT; the seed signs the server's nonce. The
   server certificate is verified with the shared provider trust store (``app.providers.tls``),
   certifi's CA bundle by default, as in the SDK.
4. Subscribe one NATS subject per feed (see ``topics``). Each message is one protobuf
   ``StocksSocketResponseProtoDto`` (see ``proto``); the subject identifies the instrument.

nats-py runs on the same asyncio event loop (no threads). Its automatic reconnect is disabled: the
stream supervisor owns reconnects, backoff and resubscription, and every connection needs a new feed
JWT anyway. Liveness is checked with a NATS PING/PONG whenever no message arrived for one heartbeat
interval.
"""

from __future__ import annotations

import asyncio
import contextlib
import math
import time
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Final
from uuid import UUID

import aiohttp
import httpx
from nats import errors as nats_errors
from nats.aio.client import Client as NATS
from nats.aio.client import RawCredentials
from nats.aio.msg import Msg
from nats.aio.subscription import Subscription

from app.core.clock import utc_now
from app.core.errors import ProviderError
from app.core.logging import get_logger, redact_text
from app.domain.enums import Segment
from app.domain.models import ProviderInstrument
from app.providers.base import SessionCredentials, StreamListener, StreamSession, describe_error
from app.providers.errors import (
    ProviderRateLimitedError,
    ProviderUnavailableError,
    UnsupportedInstrumentError,
)
from app.providers.groww.auth import nats_credentials, new_user_nkey
from app.providers.groww.client import GrowwRestClient
from app.providers.groww.constants import (
    CONNECT_TIMEOUT_SECONDS,
    FLUSH_TIMEOUT_SECONDS,
    PENDING_BYTES_LIMIT,
    PENDING_MESSAGES_LIMIT,
    PING_INTERVAL_SECONDS,
)
from app.providers.groww.exceptions import PROVIDER_NAME, GrowwPayloadError
from app.providers.groww.mapper import feed_message_to_tick
from app.providers.groww.proto import decode_feed_message
from app.providers.groww.topics import FeedKey, FeedKind, feed_subjects, parse_provider_token
from app.providers.tls import tls_context_for

log = get_logger(__name__)

CLOSE_TIMEOUT_SECONDS: Final = 5.0
_SLOW_CONSUMER_NOTICE_INTERVAL: Final = 60.0
_NOTICE_LIMIT: Final = 300
_PERMISSIONS_VIOLATION: Final = "permissions violation"
_AUTHORIZATION_VIOLATION: Final = "authorization violation"


@dataclass(frozen=True, slots=True)
class _Route:
    provider_token: str
    segment: Segment
    kind: FeedKind


class GrowwFeedSession(StreamSession):
    def __init__(
        self,
        *,
        socket_url: str,
        api_base_url: str,
        credentials: Callable[[], Awaitable[SessionCredentials]],
        account_id: UUID | None,
        heartbeat_interval: float,
        volume_is_cumulative: bool = False,
        clock: Callable[[], datetime] = utc_now,
        http_transport: httpx.AsyncBaseTransport | None = None,
        connect_timeout: float = CONNECT_TIMEOUT_SECONDS,
    ) -> None:
        if heartbeat_interval <= 0 or connect_timeout <= 0:
            raise ValueError("heartbeat_interval and connect_timeout must be positive")
        self._socket_url = socket_url
        self._api_base_url = api_base_url
        self._credentials = credentials
        self._account_id = account_id
        self._heartbeat_interval = heartbeat_interval
        self._volume_is_cumulative = volume_is_cumulative
        self._clock = clock
        self._http_transport = http_transport
        self._connect_timeout = connect_timeout
        self._client: NATS | None = None
        self._listener: StreamListener | None = None
        self._opened = False
        self._closed = asyncio.Event()
        self._last_error: Exception | None = None
        self._failure: Exception | None = None
        self._last_inbound = 0.0
        self._last_slow_notice: float | None = None
        self._routes: dict[str, _Route] = {}
        self._subscriptions: dict[str, Subscription] = {}
        self._token_subjects: dict[str, tuple[str, ...]] = {}

    async def open(self, listener: StreamListener) -> None:
        if self._opened:
            raise RuntimeError("a Groww feed session can only be opened once")
        self._opened = True
        credentials = await self._credentials()
        key_pair = new_user_nkey()
        async with GrowwRestClient(
            base_url=self._api_base_url,
            access_token=credentials.access_token,
            transport=self._http_transport,
            clock=self._clock,
        ) as rest:
            feed_token = await rest.socket_token(key_pair.public_key)
        user_credentials = RawCredentials(nats_credentials(feed_token, key_pair.seed))
        self._listener = listener
        client = NATS()
        self._client = client
        try:
            async with asyncio.timeout(self._connect_timeout):
                await client.connect(
                    servers=[self._socket_url],
                    user_credentials=user_credentials,
                    error_cb=self._on_error,
                    disconnected_cb=self._on_closed,
                    closed_cb=self._on_closed,
                    allow_reconnect=False,
                    # nats-py retries a failed transport connect inside connect() until the server
                    # exceeds max_reconnect_attempts (0 would retry forever): at most two attempts.
                    max_reconnect_attempts=1,
                    reconnect_time_wait=0,
                    # aiohttp ignores this as a connect timeout; the asyncio.timeout above bounds it.
                    connect_timeout=math.ceil(self._connect_timeout),
                    ping_interval=PING_INTERVAL_SECONDS,
                    tls=tls_context_for(self._socket_url),
                )
        except asyncio.CancelledError:
            await self.close()
            raise
        except Exception as exc:
            error = _connect_error(exc, self._last_error)
            await self.close()
            raise error from None
        self._last_inbound = time.monotonic()

    async def subscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        if not instruments:
            return
        client = self._require_client()
        try:
            for instrument in instruments:
                await self._ensure_subjects(client, instrument)
            # Round-trips a PING so a dead connection fails here. nats-py 2.16 writes the PING ahead of
            # the buffered SUBs, so a refusal (-ERR permissions violation) can arrive just after this
            # returns; _on_error reports it to the listener as a notice.
            await client.flush(FLUSH_TIMEOUT_SECONDS)
        except (nats_errors.Error, OSError) as exc:
            raise self._operation_error("subscribe", exc, client) from None

    async def unsubscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        if not instruments:
            return
        client = self._require_client()
        try:
            for instrument in instruments:
                for subject in self._token_subjects.pop(instrument.provider_token, ()):
                    await self._drop_subject(subject)
        except (nats_errors.Error, OSError) as exc:
            raise self._operation_error("unsubscribe", exc, client) from None

    async def run(self) -> None:
        client = self._require_client()
        listener = self._require_listener()
        while True:
            with contextlib.suppress(TimeoutError):
                async with asyncio.timeout(self._heartbeat_interval):
                    await self._closed.wait()
            if self._failure is not None:
                raise self._failure
            if self._closed.is_set() or not client.is_connected:
                raise ProviderUnavailableError(
                    f"the {PROVIDER_NAME} feed connection closed: {self._close_reason(client)}"
                )
            if time.monotonic() - self._last_inbound < self._heartbeat_interval:
                continue  # messages are flowing, which already proves liveness
            if not _loops_alive(client):
                raise ProviderUnavailableError(f"the {PROVIDER_NAME} feed client stopped reading")
            try:
                await client.flush(FLUSH_TIMEOUT_SECONDS)
            except (nats_errors.Error, OSError) as exc:
                raise self._operation_error("ping", exc, client) from None
            listener.on_heartbeat()

    async def close(self) -> None:
        client, self._client = self._client, None
        self._routes.clear()
        self._subscriptions.clear()
        self._token_subjects.clear()
        if client is None:
            return
        try:
            async with asyncio.timeout(CLOSE_TIMEOUT_SECONDS):
                await client.close()
        except Exception as exc:  # the connection is being discarded either way
            log.debug("groww_feed_close_failed", error=describe_error(exc))

    # -- subscriptions ----------------------------------------------------------------------------

    async def _ensure_subjects(self, client: NATS, instrument: ProviderInstrument) -> None:
        """Subscribe exactly the subjects the instrument's mode needs, dropping any others."""
        token = instrument.provider_token
        key = instrument_feed_key(instrument)
        wanted = feed_subjects(key, instrument.mode)
        wanted_subjects = tuple(subject for subject, _ in wanted)
        for subject in self._token_subjects.get(token, ()):
            if subject not in wanted_subjects:
                await self._drop_subject(subject)
        self._token_subjects[token] = wanted_subjects
        for subject, kind in wanted:
            self._routes[subject] = _Route(token, key.segment, kind)
            if subject not in self._subscriptions:
                self._subscriptions[subject] = await client.subscribe(
                    subject,
                    cb=self._on_message,
                    pending_msgs_limit=PENDING_MESSAGES_LIMIT,
                    pending_bytes_limit=PENDING_BYTES_LIMIT,
                )

    async def _drop_subject(self, subject: str) -> None:
        self._routes.pop(subject, None)  # late messages for the subject are ignored from now on
        subscription = self._subscriptions.pop(subject, None)
        if subscription is not None:
            with contextlib.suppress(nats_errors.BadSubscriptionError):
                await subscription.unsubscribe()

    # -- nats-py callbacks (coroutines on the event loop) -----------------------------------------

    async def _on_message(self, msg: Msg) -> None:
        listener = self._listener
        if listener is None or self._failure is not None:
            return
        self._last_inbound = time.monotonic()
        try:
            self._deliver(listener, msg)
        except Exception as exc:
            # A defect in mapping or in the listener. nats-py would only report it to error_cb, so
            # end the session instead: run() raises it and the supervisor reports it and reconnects.
            self._failure = exc
            self._closed.set()

    def _deliver(self, listener: StreamListener, msg: Msg) -> None:
        route = self._routes.get(msg.subject)
        if route is None:  # was in flight when its subject was unsubscribed
            listener.on_heartbeat()
            return
        try:
            tick = feed_message_to_tick(
                decode_feed_message(msg.data),
                kind=route.kind,
                provider_token=route.provider_token,
                segment=route.segment,
                raw=msg.data,
                account_id=self._account_id,
                received_at=self._clock(),
                volume_is_cumulative=self._volume_is_cumulative,
            )
        except GrowwPayloadError as exc:
            listener.on_malformed(str(exc))
            return
        listener.on_ticks((tick,) if tick is not None else ())  # an empty batch still records liveness

    async def _on_error(self, exc: Exception) -> None:
        listener = self._listener
        if isinstance(exc, nats_errors.SlowConsumerError):
            now = time.monotonic()
            last = self._last_slow_notice
            if listener is not None and (last is None or now - last >= _SLOW_CONSUMER_NOTICE_INTERVAL):
                self._last_slow_notice = now
                listener.on_notice(
                    f"{PROVIDER_NAME} feed messages were dropped because processing fell behind "
                    "(NATS slow consumer)",
                    error=True,
                )
            return
        text = redact_text(str(exc)).strip()
        if _PERMISSIONS_VIOLATION in text.lower():  # the connection stays up
            if listener is not None:
                listener.on_notice(
                    f"{PROVIDER_NAME} refused a feed subscription: {text[:_NOTICE_LIMIT]}", error=True
                )
            return
        self._last_error = exc
        log.debug("groww_feed_error", error=describe_error(exc))

    async def _on_closed(self) -> None:
        self._closed.set()

    # -- internals --------------------------------------------------------------------------------

    def _require_client(self) -> NATS:
        if self._client is None:
            raise ProviderUnavailableError(f"the {PROVIDER_NAME} feed is not connected")
        return self._client

    def _require_listener(self) -> StreamListener:
        if self._listener is None:
            raise ProviderUnavailableError(f"the {PROVIDER_NAME} feed is not connected")
        return self._listener

    def _close_reason(self, client: NATS) -> str:
        # nats-py records protocol errors such as an expired JWT without calling error_cb.
        error = client.last_error
        if error is None:
            error = self._last_error
        return describe_error(error) if error is not None else "closed by the server"

    def _operation_error(self, operation: str, exc: Exception, client: NATS) -> ProviderError:
        if isinstance(exc, nats_errors.FlushTimeoutError):
            return ProviderUnavailableError(
                f"the {PROVIDER_NAME} feed did not answer within {FLUSH_TIMEOUT_SECONDS}s ({operation})"
            )
        if isinstance(exc, nats_errors.ConnectionClosedError):
            return ProviderUnavailableError(
                f"the {PROVIDER_NAME} feed connection closed: {self._close_reason(client)}"
            )
        return ProviderUnavailableError(f"{PROVIDER_NAME} feed {operation} failed: {describe_error(exc)}")


def instrument_feed_key(instrument: ProviderInstrument) -> FeedKey:
    try:
        return parse_provider_token(instrument.provider_token)
    except ValueError:
        raise UnsupportedInstrumentError(
            f"{instrument.symbol} has no valid Groww feed token; refresh the instrument master"
        ) from None


def _loops_alive(client: NATS) -> bool:
    # nats-py 2.16 internals: flush() skips the PING/PONG round trip once its read or flush loop has
    # ended, so a dead loop must not pass for a healthy connection. Unknown internals count as alive.
    tasks = (getattr(client, "_reading_task", None), getattr(client, "_flusher_task", None))
    return not any(isinstance(task, asyncio.Task) and task.done() for task in tasks)


def _connect_error(exc: Exception, recorded: Exception | None) -> ProviderError:
    """Classify a failed NATS connect. NoServersError hides the cause, which error_cb recorded."""
    cause = recorded if isinstance(exc, nats_errors.NoServersError) and recorded is not None else exc
    if isinstance(cause, TimeoutError):
        return ProviderUnavailableError(f"the {PROVIDER_NAME} feed connection timed out")
    if isinstance(cause, aiohttp.ClientResponseError):  # includes a refused WebSocket handshake
        if cause.status == 429:
            return ProviderRateLimitedError(
                f"{PROVIDER_NAME} refused the feed connection: too many connection attempts (HTTP 429)"
            )
        return ProviderUnavailableError(f"{PROVIDER_NAME} refused the feed connection (HTTP {cause.status})")
    if isinstance(cause, nats_errors.AuthorizationError) or _AUTHORIZATION_VIOLATION in str(cause).lower():
        # The feed JWT was minted for this attempt, so an expired access token is not the cause (the
        # token request would have failed with HTTP 401); the next attempt gets a new JWT.
        return ProviderUnavailableError(
            f"the {PROVIDER_NAME} feed rejected the connection credentials (authorization violation)"
        )
    return ProviderUnavailableError(f"the {PROVIDER_NAME} feed connection failed: {describe_error(cause)}")
