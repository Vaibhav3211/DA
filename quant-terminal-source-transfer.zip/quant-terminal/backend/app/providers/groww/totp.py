"""RFC 6238 time-based one-time passwords (SHA-1, 6 digits, 30-second steps).

Groww's TOTP flow exchanges a TOTP token (used as the API key) plus a current code for an access
token. The code is computed from the base32 TOTP secret shown once in Groww Cloud.
"""

from __future__ import annotations

import base64
import binascii
import hmac
import struct
from datetime import datetime

from app.core.clock import ensure_utc
from app.core.errors import ValidationFailedError

DIGITS = 6
PERIOD_SECONDS = 30
_MIN_SECRET_BYTES = 10  # 80 bits, the RFC 4226 minimum


def secret_bytes(secret: str) -> bytes:
    """Decode a base32 TOTP secret, tolerating spaces, dashes, lower case and missing padding."""
    cleaned = "".join(secret.split()).replace("-", "").upper().rstrip("=")
    try:
        key = base64.b32decode(cleaned + "=" * (-len(cleaned) % 8))
    except (binascii.Error, ValueError):
        raise ValidationFailedError("the TOTP secret is not valid base32") from None
    if len(key) < _MIN_SECRET_BYTES:
        raise ValidationFailedError("the TOTP secret is too short")
    return key


def totp_code(secret: str, *, now: datetime) -> str:
    counter = int(ensure_utc(now).timestamp()) // PERIOD_SECONDS
    digest = hmac.new(secret_bytes(secret), struct.pack(">Q", counter), "sha1").digest()
    offset = digest[-1] & 0x0F
    (value,) = struct.unpack_from(">I", digest, offset)
    return f"{(value & 0x7FFFFFFF) % 10**DIGITS:0{DIGITS}d}"
