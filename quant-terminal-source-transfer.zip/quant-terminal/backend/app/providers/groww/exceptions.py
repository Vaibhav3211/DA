"""Groww Trading API failures translated to provider-neutral errors.

REST responses are JSON envelopes (growwapi 1.5.0 ``_parse_response``):
``{"status": "SUCCESS", "payload": {...}}`` or
``{"status": "FAILURE", "error": {"code": "...", "message": "..."}}``. The access-token endpoint
reports failures as ``{"error": {"displayMessage": "..."}}``. HTTP 401 means the access token is
invalid or expired; 403 means the account may not use the API (no active subscription).
"""

from __future__ import annotations

from app.core.errors import ProviderError
from app.core.logging import redact_text
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderProtocolError,
    ProviderRateLimitedError,
    ProviderRequestRejectedError,
    ProviderUnavailableError,
)

PROVIDER_NAME = "Groww"

_MESSAGE_LIMIT = 300
_CODE_LIMIT = 40


class GrowwPayloadError(ProviderProtocolError):
    """A feed or REST payload does not match the documented schema."""


def _clean(message: object, status_code: int) -> str:
    text = redact_text(str(message or "").strip())[:_MESSAGE_LIMIT]
    return text or f"HTTP {status_code}"


def error_from_response(status_code: int, code: str | None, message: object) -> ProviderError:
    """Map one Groww error response (any HTTP status, including FAILURE envelopes at HTTP 200)."""
    text = _clean(message, status_code)
    if code and code.strip():
        text = f"{text}; code {redact_text(code.strip())[:_CODE_LIMIT]}"
    if status_code == 429:
        return ProviderRateLimitedError(f"{PROVIDER_NAME} rate limit exceeded ({text})")
    if status_code == 401:
        return ProviderAuthRequiredError(
            f"{PROVIDER_NAME} rejected the access token ({text}); create a new Groww access token"
        )
    if status_code == 403:
        return ProviderRequestRejectedError(
            f"{PROVIDER_NAME} denied the request ({text}); check the account's active Trading API "
            "subscription"
        )
    if status_code >= 500:
        return ProviderUnavailableError(f"{PROVIDER_NAME} server error ({text})")
    return ProviderRequestRejectedError(f"{PROVIDER_NAME} rejected the request ({text})")
