"""Provider-neutral failures raised by adapters and provider clients.

Messages are written for operators and never contain credentials, tokens, or request URLs that
carry them. Provider packages subclass these in their own ``exceptions`` modules.
"""

from __future__ import annotations

from app.core.errors import AppError, ProviderError, ValidationFailedError


class ProviderAuthRequiredError(ProviderError):
    """The provider rejected or expired the account's credentials; a human must re-authenticate."""

    status_code = 409
    code = "provider_auth_required"


class ProviderRateLimitedError(ProviderError):
    status_code = 429
    code = "provider_rate_limited"


class ProviderUnavailableError(ProviderError):
    """Network failure, timeout, or a provider-side (5xx) error. Usually transient."""

    status_code = 503
    code = "provider_unavailable"


class ProviderRequestRejectedError(ProviderError):
    """The provider rejected the request itself (bad input, missing permission or entitlement)."""

    code = "provider_rejected"


class ProviderProtocolError(ProviderError):
    """The provider answered with something this adapter does not understand."""

    code = "provider_protocol_error"


class ProviderNotEnabledError(AppError):
    """This deployment may not stream the provider (feature flag, app mode or capability settings)."""

    status_code = 409
    code = "provider_not_enabled"


class SubscriptionCapacityError(AppError):
    """More instruments were requested than the provider's documented connection limits allow."""

    status_code = 409
    code = "subscription_capacity_exceeded"


class UnsupportedInstrumentError(ValidationFailedError):
    code = "unsupported_instrument"
