"""Kite Connect v3 protocol constants.

Sources: Kite Connect v3 documentation (user, websocket, market-quotes, exceptions) and the
pykiteconnect 5.2.2 source (``ticker.py``), verified on ``app.providers.capabilities.VERIFIED_ON``.
"""

from __future__ import annotations

from typing import Final

from app.domain.enums import Exchange, Segment, SubscriptionMode

KITE_VERSION: Final = "3"
VERSION_HEADER: Final = "X-Kite-Version"

# The low byte of an instrument_token identifies its exchange segment.
SEGMENT_NSE: Final = 1
SEGMENT_NFO: Final = 2
SEGMENT_CDS: Final = 3
SEGMENT_BSE: Final = 4
SEGMENT_BFO: Final = 5
SEGMENT_BCD: Final = 6
SEGMENT_MCX: Final = 7
SEGMENT_MCXSX: Final = 8
SEGMENT_INDICES: Final = 9
SEGMENT_NCO: Final = 12

# Prices arrive as unsigned integers: paise (2 decimal places) except currency and NSE commodity.
DEFAULT_PRICE_DECIMALS: Final = 2
PRICE_DECIMALS: Final[dict[int, int]] = {SEGMENT_CDS: 7, SEGMENT_BCD: 4, SEGMENT_NCO: 4}

# Segments whose open-interest fields are meaningful (derivatives).
DERIVATIVE_SEGMENTS: Final = frozenset(
    {SEGMENT_NFO, SEGMENT_CDS, SEGMENT_BFO, SEGMENT_BCD, SEGMENT_MCX, SEGMENT_MCXSX, SEGMENT_NCO}
)

MODE_NAMES: Final[dict[SubscriptionMode, str]] = {
    SubscriptionMode.LTP: "ltp",
    SubscriptionMode.QUOTE: "quote",
    SubscriptionMode.FULL: "full",
}

# Documented WebSocket limits (also in the capability registry).
MAX_INSTRUMENTS_PER_CONNECTION: Final = 3000
MAX_CONNECTIONS_PER_API_KEY: Final = 3

# REST limits.
QUOTE_BATCH_SIZE: Final = 500
LTP_OHLC_BATCH_SIZE: Final = 1000
QUOTE_RATE_PER_SECOND: Final = 1
DEFAULT_RATE_PER_SECOND: Final = 10
HISTORICAL_RATE_PER_SECOND: Final = 3

# Historical candles (Kite docs, "historical"): GET /instruments/historical/{instrument_token}/{interval}
# with ``from``/``to`` as exchange-local "yyyy-mm-dd hh:mm:ss".
HISTORICAL_PATH: Final = "/instruments/historical/{token}/{interval}"

# The access token is invalidated at about 06:00 IST the next day, whatever the login time.
TOKEN_RESET_HOUR_IST: Final = 6

# Instrument dump ``exchange`` column → canonical (exchange, segment). Other exchanges are skipped.
EXCHANGE_SEGMENTS: Final[dict[str, tuple[Exchange, Segment]]] = {
    "NSE": (Exchange.NSE, Segment.CASH),
    "BSE": (Exchange.BSE, Segment.CASH),
    "NFO": (Exchange.NSE, Segment.FNO),
    "BFO": (Exchange.BSE, Segment.FNO),
    "CDS": (Exchange.NSE, Segment.CURRENCY),
    "BCD": (Exchange.BSE, Segment.CURRENCY),
    "MCX": (Exchange.MCX, Segment.COMMODITY),
    "NCO": (Exchange.NSE, Segment.COMMODITY),
}
# Index rows have ``segment == "INDICES"`` and the publishing exchange in ``exchange``.
INDICES_SEGMENT: Final = "INDICES"
INDEX_EXCHANGES: Final[dict[str, Exchange]] = {"NSE": Exchange.NSE, "BSE": Exchange.BSE, "MCX": Exchange.MCX}

# Binary frames for 3000 instruments in FULL mode are about 560 KB.
MAX_FRAME_BYTES: Final = 2 * 1024 * 1024
