"""Kite payloads → ``ProviderTick``.

WebSocket binary frames (Kite Connect v3 websocket docs; pykiteconnect 5.2.2 ``_parse_binary``)::

    frame  := uint16 packet_count, (uint16 packet_length, packet)*          (big-endian)
    packet := 8 bytes (LTP) | 28 (index quote) | 32 (index full) | 44 (quote) | 184 (full)

A frame shorter than two bytes is a heartbeat. Prices are unsigned integers scaled by a
per-segment power of ten and converted to exact ``Decimal`` values. Zero prices, quantities that
cannot be zero, and zero timestamps mean "not available" and become ``None``. Kite's ``close`` is
the previous session's close (→ ``previous_close``); volume is cumulative for the day.
"""

from __future__ import annotations

import struct
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any
from uuid import UUID

from app.core.clock import from_epoch_seconds
from app.domain.enums import EventType, Provider, VolumeSemantics
from app.domain.models import DepthLevel, MarketDepth, ProviderTick
from app.providers.base import payload_digest
from app.providers.zerodha.auth import parse_ist_timestamp
from app.providers.zerodha.constants import (
    DEFAULT_PRICE_DECIMALS,
    DERIVATIVE_SEGMENTS,
    PRICE_DECIMALS,
    SEGMENT_INDICES,
)
from app.providers.zerodha.exceptions import KiteFrameError

LTP_PACKET = 8
INDEX_QUOTE_PACKET = 28
INDEX_FULL_PACKET = 32
QUOTE_PACKET = 44
FULL_PACKET = 184

_U16 = struct.Struct(">H")
_LTP = struct.Struct(">2I")  # token, last price
_INDEX = struct.Struct(">6I")  # token, last, high, low, open, close (bytes 24-28: change, unused)
_QUOTE = struct.Struct(
    ">11I"
)  # token, last, last qty, avg, volume, buy qty, sell qty, open, high, low, close
_FULL_EXTRA = struct.Struct(">5I")  # last trade time, oi, oi day high, oi day low, exchange time
_TIMESTAMP = struct.Struct(">I")
_DEPTH_ENTRY = struct.Struct(">IIH2x")  # quantity, price, orders, 2 bytes padding
_DEPTH_OFFSET = 64
_DEPTH_LEVELS = 5


@dataclass(frozen=True, slots=True)
class ParsedFrame:
    ticks: tuple[ProviderTick, ...]
    malformed: int = 0
    error: str | None = None


def is_heartbeat(frame: bytes) -> bool:
    return len(frame) < 2


def split_packets(frame: bytes) -> tuple[list[bytes], int, str | None]:
    """Packets of a frame, the declared packet count, and a description of any truncation."""
    if len(frame) < 2:
        return [], 0, None
    (count,) = _U16.unpack_from(frame, 0)
    packets: list[bytes] = []
    offset = 2
    for index in range(count):
        if offset + 2 > len(frame):
            return packets, count, f"frame truncated before packet {index + 1} of {count}"
        (length,) = _U16.unpack_from(frame, offset)
        start = offset + 2
        end = start + length
        if end > len(frame):
            return packets, count, f"packet {index + 1} of {count} truncated"
        packets.append(frame[start:end])
        offset = end
    return packets, count, None


def parse_frame(frame: bytes, *, account_id: UUID | None, received_at: datetime) -> ParsedFrame:
    packets, count, error = split_packets(frame)
    ticks: list[ProviderTick] = []
    malformed = count - len(packets)
    for packet in packets:
        try:
            ticks.append(parse_packet(packet, account_id=account_id, received_at=received_at))
        except KiteFrameError as exc:
            malformed += 1
            error = error or exc.message
    return ParsedFrame(tuple(ticks), malformed, error)


def parse_packet(packet: bytes, *, account_id: UUID | None, received_at: datetime) -> ProviderTick:
    size = len(packet)
    fields: dict[str, Any]
    if size == LTP_PACKET:
        token, last = _LTP.unpack(packet)
        fields = {"last_price": _price(last, _decimals(token))}
        event_type = EventType.LTP
    elif size in (INDEX_QUOTE_PACKET, INDEX_FULL_PACKET):
        token, last, high, low, open_, close = _INDEX.unpack_from(packet)
        decimals = _decimals(token)
        fields = {
            "last_price": _price(last, decimals),
            "high_price": _price(high, decimals),
            "low_price": _price(low, decimals),
            "open_price": _price(open_, decimals),
            "previous_close": _price(close, decimals),
        }
        if size == INDEX_FULL_PACKET:
            fields["source_timestamp"] = _time(_TIMESTAMP.unpack_from(packet, 28)[0])
        event_type = EventType.INDEX_VALUE
    elif size in (QUOTE_PACKET, FULL_PACKET):
        (token, last, last_qty, average, volume, buy_qty, sell_qty, open_, high, low, close) = (
            _QUOTE.unpack_from(packet)
        )
        decimals = _decimals(token)
        fields = {
            "last_price": _price(last, decimals),
            "last_quantity": last_qty or None,
            "average_price": _price(average, decimals),
            "volume": volume,
            "volume_semantics": VolumeSemantics.CUMULATIVE_DAY,
            "total_buy_quantity": buy_qty,
            "total_sell_quantity": sell_qty,
            "open_price": _price(open_, decimals),
            "high_price": _price(high, decimals),
            "low_price": _price(low, decimals),
            "previous_close": _price(close, decimals),
        }
        if size == FULL_PACKET:
            _add_full_fields(fields, packet, token, decimals)
        event_type = EventType.QUOTE
    else:
        raise KiteFrameError(f"unexpected packet length {size}")
    return ProviderTick.model_construct(
        provider=Provider.ZERODHA,
        account_id=account_id,
        provider_token=str(token),
        event_type=event_type,
        received_at=received_at,
        raw_payload_hash=payload_digest(packet),
        **fields,
    )


def _add_full_fields(fields: dict[str, Any], packet: bytes, token: int, decimals: int) -> None:
    trade_time, oi, oi_high, oi_low, stamp = _FULL_EXTRA.unpack_from(packet, QUOTE_PACKET)
    fields["last_trade_time"] = _time(trade_time)
    fields["source_timestamp"] = _time(stamp)
    if (token & 0xFF) in DERIVATIVE_SEGMENTS:
        fields["open_interest"] = oi
        fields["open_interest_day_high"] = oi_high
        fields["open_interest_day_low"] = oi_low
    bid_levels: list[DepthLevel] = []
    ask_levels: list[DepthLevel] = []
    for index, offset in enumerate(range(_DEPTH_OFFSET, FULL_PACKET, _DEPTH_ENTRY.size)):
        quantity, raw_price, orders = _DEPTH_ENTRY.unpack_from(packet, offset)
        if not raw_price:
            continue  # empty book levels are zero-filled; never report them as price 0
        level = DepthLevel.model_construct(
            price=Decimal(raw_price).scaleb(-decimals), quantity=quantity, orders=orders
        )
        (bid_levels if index < _DEPTH_LEVELS else ask_levels).append(level)
    bids, asks = tuple(bid_levels), tuple(ask_levels)
    fields["market_depth"] = MarketDepth.model_construct(bids=bids, asks=asks)
    if bids:
        fields["bid"], fields["bid_quantity"] = bids[0].price, bids[0].quantity
    if asks:
        fields["ask"], fields["ask_quantity"] = asks[0].price, asks[0].quantity


def _decimals(token: int) -> int:
    return PRICE_DECIMALS.get(token & 0xFF, DEFAULT_PRICE_DECIMALS)


def _price(raw: int, decimals: int) -> Decimal | None:
    return Decimal(raw).scaleb(-decimals) if raw else None


def _time(epoch_seconds: int) -> datetime | None:
    if not epoch_seconds:
        return None
    try:
        return from_epoch_seconds(epoch_seconds)
    except (OverflowError, OSError, ValueError):
        return None


# ---- REST quotes (supplemental snapshots; never a substitute for the stream) ---------------------


def rest_quote_to_tick(
    payload: Mapping[str, Any], *, account_id: UUID | None, received_at: datetime
) -> ProviderTick:
    """Map one entry of a ``/quote``, ``/quote/ohlc`` or ``/quote/ltp`` response."""
    token = payload.get("instrument_token")
    if not isinstance(token, int) or isinstance(token, bool) or token <= 0:
        raise KiteFrameError("quote entry has no instrument_token")
    ohlc = payload.get("ohlc") if isinstance(payload.get("ohlc"), Mapping) else None
    fields: dict[str, Any] = {"last_price": _json_price(payload.get("last_price"))}
    if ohlc is not None:
        fields.update(
            open_price=_json_price(ohlc.get("open")),
            high_price=_json_price(ohlc.get("high")),
            low_price=_json_price(ohlc.get("low")),
            previous_close=_json_price(ohlc.get("close")),
        )
    volume = _json_int(payload.get("volume"))
    if volume is not None:
        fields.update(volume=volume, volume_semantics=VolumeSemantics.CUMULATIVE_DAY)
    fields.update(
        last_quantity=_json_int(payload.get("last_quantity")) or None,
        average_price=_json_price(payload.get("average_price")),
        total_buy_quantity=_json_int(payload.get("buy_quantity")),
        total_sell_quantity=_json_int(payload.get("sell_quantity")),
        last_trade_time=parse_ist_timestamp(payload.get("last_trade_time")),
        source_timestamp=parse_ist_timestamp(payload.get("timestamp")),
    )
    if (token & 0xFF) in DERIVATIVE_SEGMENTS:
        fields.update(
            open_interest=_json_int(payload.get("oi")),
            open_interest_day_high=_json_int(payload.get("oi_day_high")),
            open_interest_day_low=_json_int(payload.get("oi_day_low")),
        )
    depth = payload.get("depth")
    if isinstance(depth, Mapping):
        bids = _json_depth(depth.get("buy"))
        asks = _json_depth(depth.get("sell"))
        fields["market_depth"] = MarketDepth(bids=bids, asks=asks)
        if bids:
            fields["bid"], fields["bid_quantity"] = bids[0].price, bids[0].quantity
        if asks:
            fields["ask"], fields["ask_quantity"] = asks[0].price, asks[0].quantity
    if ohlc is not None or volume is not None:
        event_type = EventType.INDEX_VALUE if (token & 0xFF) == SEGMENT_INDICES else EventType.QUOTE
    else:
        event_type = EventType.LTP
    return ProviderTick(
        provider=Provider.ZERODHA,
        account_id=account_id,
        provider_token=str(token),
        event_type=event_type,
        received_at=received_at,
        **fields,
    )


def _json_price(value: object) -> Decimal | None:
    if value is None or isinstance(value, bool) or not isinstance(value, int | float | str):
        return None
    try:
        price = Decimal(str(value))
    except InvalidOperation:
        return None
    return price if price.is_finite() and price > 0 else None


def _json_int(value: object) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    return int(value)


def _json_depth(levels: object) -> tuple[DepthLevel, ...]:
    if not isinstance(levels, list):
        return ()
    result: list[DepthLevel] = []
    for level in levels:
        if not isinstance(level, Mapping):
            continue
        price = _json_price(level.get("price"))
        if price is None:
            continue
        result.append(
            DepthLevel(
                price=price,
                quantity=_json_int(level.get("quantity")) or 0,
                orders=_json_int(level.get("orders")),
            )
        )
    return tuple(result)
