"""Kite Connect failures translated to provider-neutral errors.

Kite REST errors are JSON ``{"status": "error", "error_type": "...", "message": "..."}`` where
``error_type`` names the exception class (TokenException, PermissionException, InputException,
NetworkException, DataException, GeneralException, ...).
"""

from __future__ import annotations

from app.core.errors import ProviderError
from app.core.logging import redact_text
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderProtocolError,
    ProviderRateLimitedError,
    ProviderRequestRejectedError,
    ProviderUnavailableError,
)

PROVIDER_NAME = "Zerodha Kite"


class KiteFrameError(ProviderProtocolError):
    """A WebSocket binary frame does not match the documented packet layout."""


def _clean(message: object, status_code: int) -> str:
    text = redact_text(str(message or "").strip())[:300]
    return text or f"HTTP {status_code}"


def error_from_response(status_code: int, error_type: str | None, message: object) -> ProviderError:
    """Map one Kite error response to the matching provider-neutral exception."""
    text = _clean(message, status_code)
    if status_code == 429:  # Kite labels some rate-limit responses NetworkException; the status wins
        return ProviderRateLimitedError(f"{PROVIDER_NAME} rate limit exceeded ({text})")
    match error_type:
        case "TokenException":
            return ProviderAuthRequiredError(
                f"{PROVIDER_NAME} rejected the session ({text}); log in to Zerodha again"
            )
        case "PermissionException":
            return ProviderRequestRejectedError(
                f"{PROVIDER_NAME} denied the request ({text}); check the app's Kite Connect plan"
            )
        case "NetworkException" | "DataException":
            return ProviderUnavailableError(f"{PROVIDER_NAME} is temporarily unavailable ({text})")
        case _ if status_code == 401:
            return ProviderAuthRequiredError(f"{PROVIDER_NAME} rejected the credentials ({text})")
        case _ if status_code >= 500:
            return ProviderUnavailableError(f"{PROVIDER_NAME} server error ({text})")
        case _:
            return ProviderRequestRejectedError(f"{PROVIDER_NAME} rejected the request ({text})")
