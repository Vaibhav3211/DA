"""Zerodha Kite Connect market-data adapter.

Up to three WebSocket connections per API key with 3000 instruments each (capability registry).
Credentials (API key + daily access token) are loaded from the encrypted account store on every
connection attempt, so a new login takes effect on the next reconnect.
"""

from __future__ import annotations

from typing import ClassVar

from app.domain.enums import Provider
from app.domain.models import ProviderInstrument
from app.providers.base import MarketDataAdapter, StreamSession
from app.providers.errors import UnsupportedInstrumentError
from app.providers.zerodha.stream import KiteStreamSession

_MAX_TOKEN = 2**32


class ZerodhaAdapter(MarketDataAdapter):
    provider: ClassVar[Provider] = Provider.ZERODHA

    def create_session(self, shard: int) -> StreamSession:
        return KiteStreamSession(
            url=self.settings.zerodha_ws_url,
            credentials=self.load_credentials,
            account_id=self.account_id,
        )

    def _validate(self, instrument: ProviderInstrument) -> None:
        super()._validate(instrument)
        token = instrument.provider_token
        if not (token.isascii() and token.isdigit() and 0 < int(token) < _MAX_TOKEN):
            raise UnsupportedInstrumentError(
                f"{instrument.symbol} has no valid Kite instrument token; refresh the instrument master"
            )
