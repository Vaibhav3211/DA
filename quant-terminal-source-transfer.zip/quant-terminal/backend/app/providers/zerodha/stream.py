"""Kite ticker WebSocket session (Kite Connect v3 websocket API) on asyncio ``websockets``.

Connect to ``wss://ws.kite.trade?api_key=...&access_token=...`` with ``X-Kite-Version: 3``.
Requests are JSON text frames: ``{"a": "subscribe" | "unsubscribe", "v": [tokens]}`` and
``{"a": "mode", "v": ["ltp" | "quote" | "full", [tokens]]}``; a new subscription starts in quote
mode, so the mode is always set explicitly. Market data arrives as binary frames (see ``mapper``);
a 1-byte frame is a heartbeat. Text frames are JSON ``{"type": "order" | "error" | "message",
"data": ...}``. Order updates are ignored (this platform never trades) and never logged.
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable, Sequence
from datetime import datetime
from urllib.parse import urlencode
from uuid import UUID

from websockets.asyncio.client import ClientConnection, connect
from websockets.exceptions import (
    ConnectionClosed,
    ConnectionClosedError,
    InvalidHandshake,
    InvalidProxy,
    InvalidStatus,
    InvalidURI,
)

from app.core.clock import utc_now
from app.core.errors import ProviderError
from app.core.logging import get_logger, redact_text
from app.domain.enums import SubscriptionMode
from app.domain.models import ProviderInstrument
from app.providers.base import SessionCredentials, StreamListener, StreamSession, describe_error
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderProtocolError,
    ProviderRateLimitedError,
    ProviderUnavailableError,
)
from app.providers.http import USER_AGENT
from app.providers.tls import tls_context_for
from app.providers.zerodha.constants import KITE_VERSION, MAX_FRAME_BYTES, MODE_NAMES, VERSION_HEADER
from app.providers.zerodha.exceptions import PROVIDER_NAME
from app.providers.zerodha.mapper import is_heartbeat, parse_frame

log = get_logger(__name__)

OPEN_TIMEOUT_SECONDS = 15.0
CLOSE_TIMEOUT_SECONDS = 5.0
_NOTICE_LIMIT = 300


class KiteStreamSession(StreamSession):
    def __init__(
        self,
        *,
        url: str,
        credentials: Callable[[], Awaitable[SessionCredentials]],
        account_id: UUID | None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self._url = url
        self._credentials = credentials
        self._account_id = account_id
        self._clock = clock
        self._connection: ClientConnection | None = None
        self._listener: StreamListener | None = None
        self._opened = False

    async def open(self, listener: StreamListener) -> None:
        if self._opened:
            raise RuntimeError("a Kite stream session can only be opened once")
        self._opened = True
        credentials = await self._credentials()
        if not credentials.api_key:
            raise ProviderAuthRequiredError(f"no {PROVIDER_NAME} API key is stored for this account")
        query = _credential_query(credentials.api_key, credentials.access_token)
        separator = "&" if "?" in self._url else "?"
        try:
            connection = await connect(
                f"{self._url}{separator}{query}",
                additional_headers={VERSION_HEADER: KITE_VERSION},
                user_agent_header=USER_AGENT,
                compression=None,
                open_timeout=OPEN_TIMEOUT_SECONDS,
                close_timeout=CLOSE_TIMEOUT_SECONDS,
                max_size=MAX_FRAME_BYTES,
                ssl=tls_context_for(self._url),
            )
        except InvalidStatus as exc:
            raise handshake_error(exc.response.status_code) from None
        except InvalidURI:  # the message would echo the URL, which carries the access token
            raise ProviderProtocolError(f"the {PROVIDER_NAME} WebSocket URL is invalid") from None
        except InvalidProxy:  # the message may echo proxy credentials
            raise ProviderUnavailableError("the configured WebSocket proxy is invalid") from None
        except (InvalidHandshake, OSError) as exc:
            raise ProviderUnavailableError(
                f"{PROVIDER_NAME} WebSocket connection failed: {describe_error(exc)}"
            ) from None
        self._connection = connection
        self._listener = listener

    async def subscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        if not instruments:
            return
        connection = self._require_connection()
        tokens = [int(instrument.provider_token) for instrument in instruments]
        await connection.send(_request("subscribe", tokens))
        groups: dict[SubscriptionMode, list[int]] = {}
        for instrument, token in zip(instruments, tokens, strict=True):
            groups.setdefault(instrument.mode, []).append(token)
        for mode, group in groups.items():
            await connection.send(_request("mode", [MODE_NAMES[mode], group]))

    async def unsubscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        if not instruments:
            return
        connection = self._require_connection()
        await connection.send(
            _request("unsubscribe", [int(instrument.provider_token) for instrument in instruments])
        )

    async def run(self) -> None:
        connection = self._require_connection()
        try:
            async for message in connection:
                if isinstance(message, bytes):
                    self._on_binary(message)
                else:
                    self._on_text(message)
        except ConnectionClosedError as exc:
            raise ProviderUnavailableError(f"{PROVIDER_NAME} stream dropped: {close_reason(exc)}") from None

    async def close(self) -> None:
        connection, self._connection = self._connection, None
        if connection is None:
            return
        try:
            await connection.close()
        except Exception as exc:  # the connection is being discarded either way
            log.debug("kite_stream_close_failed", error=describe_error(exc))

    # -- internals --------------------------------------------------------------------------------

    def _require_connection(self) -> ClientConnection:
        if self._connection is None:
            raise ProviderUnavailableError(f"the {PROVIDER_NAME} stream is not connected")
        return self._connection

    def _on_binary(self, frame: bytes) -> None:
        listener = self._listener
        assert listener is not None
        if is_heartbeat(frame):
            listener.on_heartbeat()
            return
        parsed = parse_frame(frame, account_id=self._account_id, received_at=self._clock())
        listener.on_ticks(parsed.ticks)  # also records liveness for frames without packets
        if parsed.malformed:
            listener.on_malformed(parsed.error or "malformed packet", parsed.malformed)

    def _on_text(self, text: str) -> None:
        listener = self._listener
        assert listener is not None
        listener.on_heartbeat()
        try:
            payload = json.loads(text)
        except ValueError:
            listener.on_malformed("text frame is not JSON")
            return
        if not isinstance(payload, dict):
            listener.on_malformed("text frame is not a JSON object")
            return
        kind = payload.get("type")
        if kind == "error":
            listener.on_notice(_notice_text(payload.get("data")), error=True)
        elif kind == "message":
            listener.on_notice(_notice_text(payload.get("data")))
        # "order" updates and unknown types are ignored without inspecting their content.


def _credential_query(api_key: str, access_token: str) -> str:
    return urlencode({"api_key": api_key, "access_token": access_token})


def handshake_error(status: int) -> ProviderError:
    """Map an HTTP status that refused the WebSocket upgrade."""
    if status in (400, 401, 403):
        return ProviderAuthRequiredError(
            f"{PROVIDER_NAME} refused the WebSocket connection (HTTP {status}): the access token is "
            "invalid or expired, or the app's Kite Connect plan has no live market data. Log in to "
            "Zerodha again or check the plan."
        )
    if status == 429:
        return ProviderRateLimitedError(
            f"{PROVIDER_NAME} refused the WebSocket connection: too many connection attempts (HTTP 429)"
        )
    return ProviderUnavailableError(f"{PROVIDER_NAME} refused the WebSocket connection (HTTP {status})")


def close_reason(exc: ConnectionClosed) -> str:
    frame = exc.rcvd
    if frame is None:
        return "the connection ended without a close frame"
    reason = redact_text(frame.reason)[:100]
    return f"close code {frame.code}" + (f" ({reason})" if reason else "")


def _request(action: str, value: object) -> str:
    return json.dumps({"a": action, "v": value}, separators=(",", ":"))


def _notice_text(data: object) -> str:
    if isinstance(data, str) and data.strip():
        return redact_text(data.strip())[:_NOTICE_LIMIT]
    return "notice without text"
