"""Kite Connect login flow helpers (Kite Connect v3 "user" documentation).

1. Send the user to the login URL (``v=3&api_key=...``). ``redirect_params`` carries a one-time
   CSRF state; Kite passes it back to the app's registered redirect URL together with
   ``request_token``, ``action=login`` and ``status=success``.
2. Exchange the request token: ``POST /session/token`` with
   ``checksum = SHA-256(api_key + request_token + api_secret)``.
3. The access token is invalidated at about 06:00 IST the next day. Individual developer apps get
   no usable refresh token, so a human logs in again every trading day.

Everything here is pure (no I/O); ``client.KiteRestClient`` performs the HTTP calls and
``app.services.provider_auth`` runs the workflow with persistence.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from urllib.parse import parse_qs, urlencode, urlsplit

from app.core.clock import IST, ensure_utc
from app.core.errors import ValidationFailedError
from app.providers.errors import ProviderRequestRejectedError
from app.providers.zerodha.constants import KITE_VERSION, TOKEN_RESET_HOUR_IST

# Request tokens are short alphanumeric strings; anything else is rejected before it is sent.
_REQUEST_TOKEN = re.compile(r"[A-Za-z0-9]{8,128}")
_LOGIN_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def build_login_url(login_url: str, api_key: str, state: str) -> str:
    """Kite login URL that returns ``state`` to the redirect URL through ``redirect_params``."""
    query = urlencode({"v": KITE_VERSION, "api_key": api_key, "redirect_params": urlencode({"state": state})})
    return f"{login_url}?{query}"


def session_checksum(api_key: str, request_token: str, api_secret: str) -> str:
    return hashlib.sha256(f"{api_key}{request_token}{api_secret}".encode()).hexdigest()


@dataclass(frozen=True, slots=True)
class KiteRedirect:
    request_token: str = field(repr=False)
    state: str | None = field(repr=False)
    status: str | None
    action: str | None


def _redirect_params(value: str) -> dict[str, list[str]]:
    text = value.strip()
    query = urlsplit(text).query if "://" in text else text.lstrip("?")
    return parse_qs(query, keep_blank_values=True)


def redirect_state(value: str) -> str | None:
    """Only the login state a redirect carries (None if missing or repeated), even from a failed login."""
    values = _redirect_params(value).get("state")
    return values[0] if values is not None and len(values) == 1 and values[0] else None


def parse_redirect(value: str) -> KiteRedirect:
    """Parse the URL the browser was redirected to after login (or just its query string)."""
    params = _redirect_params(value)

    def single(name: str) -> str | None:
        values = params.get(name)
        if values is None:
            return None
        if len(values) != 1:
            raise ValidationFailedError(f"the redirect URL repeats the '{name}' parameter")
        return values[0]

    status = single("status")
    if status is not None and status != "success":
        raise ProviderRequestRejectedError(f"the Kite login did not succeed (status '{status[:40]}')")
    request_token = single("request_token")
    if not request_token:
        raise ValidationFailedError("the redirect URL has no request_token")
    if not _REQUEST_TOKEN.fullmatch(request_token):
        raise ValidationFailedError("the request_token has an unexpected format")
    return KiteRedirect(
        request_token=request_token, state=single("state"), status=status, action=single("action")
    )


def token_expiry(issued_at: datetime) -> datetime:
    """The first 06:00 IST strictly after ``issued_at`` (when Kite invalidates the token)."""
    local = ensure_utc(issued_at).astimezone(IST)
    reset = local.replace(hour=TOKEN_RESET_HOUR_IST, minute=0, second=0, microsecond=0)
    if reset <= local:
        reset += timedelta(days=1)  # IST has no daylight saving time
    return reset.astimezone(UTC)


def parse_ist_timestamp(value: object) -> datetime | None:
    """Kite REST timestamps are ``YYYY-MM-DD HH:MM:SS`` in IST without an offset."""
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.strptime(value, _LOGIN_TIME_FORMAT).replace(tzinfo=IST).astimezone(UTC)
    except ValueError:
        return None
