"""Async Kite Connect REST client (httpx). Supplemental to the WebSocket stream, never a substitute.

Every request sends ``X-Kite-Version: 3``; authenticated requests add
``Authorization: token <api_key>:<access_token>``. Errors come back as JSON with ``error_type``
(see ``exceptions``). Rate limits (Kite docs, "exceptions"): quote endpoints 1 request/second,
historical candles 3 requests/second, everything else used here 10 requests/second. Limits are
enforced per client instance.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date, datetime
from types import TracebackType
from typing import Any, Self

import httpx

from app.core.clock import utc_now
from app.core.rate_limit import SlidingWindowRateLimiter
from app.providers.errors import ProviderAuthRequiredError, ProviderProtocolError
from app.providers.http import create_http_client, decode_json, error_body, is_json, transport_error
from app.providers.zerodha.auth import parse_ist_timestamp, session_checksum, token_expiry
from app.providers.zerodha.constants import (
    DEFAULT_RATE_PER_SECOND,
    HISTORICAL_PATH,
    HISTORICAL_RATE_PER_SECOND,
    KITE_VERSION,
    LTP_OHLC_BATCH_SIZE,
    QUOTE_BATCH_SIZE,
    QUOTE_RATE_PER_SECOND,
    VERSION_HEADER,
)
from app.providers.zerodha.exceptions import PROVIDER_NAME, error_from_response

DEFAULT_TIMEOUT_SECONDS = 7.0
INSTRUMENTS_TIMEOUT_SECONDS = 120.0


@dataclass(frozen=True, slots=True)
class KiteSession:
    """Result of a request-token exchange. Only what the platform needs is kept."""

    access_token: str = field(repr=False)
    user_id: str
    issued_at: datetime
    expires_at: datetime
    exchanges: tuple[str, ...] = ()
    products: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class KiteProfile:
    user_id: str
    exchanges: tuple[str, ...]
    products: tuple[str, ...]


class KiteRestClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        access_token: str | None = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        transport: httpx.AsyncBaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if not api_key:
            raise ValueError("a Kite API key is required")
        self._api_key = api_key
        self._access_token = access_token
        self._clock = clock
        self._http = create_http_client(
            base_url=base_url,
            timeout=timeout,
            headers={VERSION_HEADER: KITE_VERSION},
            transport=transport,
        )
        self._quote_limiter = SlidingWindowRateLimiter([(QUOTE_RATE_PER_SECOND, 1.0)])
        self._historical_limiter = SlidingWindowRateLimiter([(HISTORICAL_RATE_PER_SECOND, 1.0)])
        self._default_limiter = SlidingWindowRateLimiter([(DEFAULT_RATE_PER_SECOND, 1.0)])

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, tb: TracebackType | None
    ) -> None:
        await self.aclose()

    # -- session ----------------------------------------------------------------------------------

    async def generate_session(self, request_token: str, api_secret: str) -> KiteSession:
        """Exchange a login ``request_token`` for an access token (POST /session/token)."""
        data = await self._request(
            "POST",
            "/session/token",
            operation="token exchange",
            data={
                "api_key": self._api_key,
                "request_token": request_token,
                "checksum": session_checksum(self._api_key, request_token, api_secret),
            },
            authenticated=False,
        )
        if not isinstance(data, Mapping):
            raise ProviderProtocolError(f"{PROVIDER_NAME} token exchange returned no session")
        access_token = data.get("access_token")
        user_id = data.get("user_id")
        if not isinstance(access_token, str) or not access_token or not isinstance(user_id, str):
            raise ProviderProtocolError(f"{PROVIDER_NAME} token exchange returned no access token")
        issued_at = parse_ist_timestamp(data.get("login_time")) or self._clock()
        self._access_token = access_token
        return KiteSession(
            access_token=access_token,
            user_id=user_id,
            issued_at=issued_at,
            expires_at=token_expiry(issued_at),
            exchanges=_strings(data.get("exchanges")),
            products=_strings(data.get("products")),
        )

    async def invalidate_access_token(self, access_token: str | None = None) -> None:
        """Log the session out (DELETE /session/token)."""
        token = access_token or self._access_token
        if not token:
            return
        await self._request(
            "DELETE",
            "/session/token",
            operation="logout",
            params={"api_key": self._api_key, "access_token": token},
            authenticated=False,
        )
        if token == self._access_token:
            self._access_token = None

    async def profile(self) -> KiteProfile:
        """Validates the access token and reports the exchanges enabled for the user."""
        data = await self._request("GET", "/user/profile", operation="profile request")
        if not isinstance(data, Mapping) or not isinstance(data.get("user_id"), str):
            raise ProviderProtocolError(f"{PROVIDER_NAME} profile response has no user_id")
        return KiteProfile(
            user_id=data["user_id"],
            exchanges=_strings(data.get("exchanges")),
            products=_strings(data.get("products")),
        )

    # -- market data ------------------------------------------------------------------------------

    async def instruments_csv(self, exchange: str | None = None) -> bytes:
        """The daily instrument dump (CSV) for all exchanges or one Kite exchange code."""
        path = "/instruments" if exchange is None else f"/instruments/{exchange}"
        data = await self._request(
            "GET",
            path,
            operation="instrument download",
            authenticated=self._access_token is not None,
            request_timeout=INSTRUMENTS_TIMEOUT_SECONDS,
            expect_csv=True,
        )
        if not isinstance(data, bytes):
            raise ProviderProtocolError(f"{PROVIDER_NAME} instrument download did not return CSV")
        return data

    async def quote(self, keys: Sequence[str]) -> dict[str, Any]:
        """Full quotes keyed ``EXCHANGE:TRADINGSYMBOL`` (≤500 per call, 1 call/second)."""
        return await self._batched("/quote", keys, QUOTE_BATCH_SIZE, "quote request")

    async def ohlc(self, keys: Sequence[str]) -> dict[str, Any]:
        return await self._batched("/quote/ohlc", keys, LTP_OHLC_BATCH_SIZE, "OHLC request")

    async def ltp(self, keys: Sequence[str]) -> dict[str, Any]:
        return await self._batched("/quote/ltp", keys, LTP_OHLC_BATCH_SIZE, "LTP request")

    async def historical_candles(
        self, instrument_token: str, interval: str, first_day: date, last_day: date, *, oi: bool = False
    ) -> list[Any]:
        """Raw candles ``[timestamp, open, high, low, close, volume(, oi)]`` from the start of
        ``first_day`` to the end of ``last_day`` (exchange-local dates; 3 requests/second). Needs the
        paid Kite Connect plan. Callers keep each request within Kite's per-interval range."""
        data = await self._request(
            "GET",
            HISTORICAL_PATH.format(token=instrument_token, interval=interval),
            operation="historical candle request",
            params={
                "from": f"{first_day.isoformat()} 00:00:00",
                "to": f"{last_day.isoformat()} 23:59:59",
                "oi": "1" if oi else "0",
            },
            limiter=self._historical_limiter,
        )
        candles = data.get("candles") if isinstance(data, Mapping) else None
        if not isinstance(candles, list):
            raise ProviderProtocolError(f"{PROVIDER_NAME} historical candle response has no candle list")
        return candles

    async def _batched(self, path: str, keys: Sequence[str], size: int, operation: str) -> dict[str, Any]:
        result: dict[str, Any] = {}
        unique = list(dict.fromkeys(keys))
        for start in range(0, len(unique), size):
            data = await self._request(
                "GET",
                path,
                operation=operation,
                params=httpx.QueryParams([("i", key) for key in unique[start : start + size]]),
                limiter=self._quote_limiter,
            )
            if isinstance(data, Mapping):
                result.update(data)
        return result

    # -- transport --------------------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        operation: str,
        params: Mapping[str, str] | httpx.QueryParams | None = None,
        data: Mapping[str, str] | None = None,
        authenticated: bool = True,
        limiter: SlidingWindowRateLimiter | None = None,
        request_timeout: float | None = None,
        expect_csv: bool = False,
    ) -> Any:
        headers: dict[str, str] = {}
        if authenticated:
            if not self._access_token:
                raise ProviderAuthRequiredError(f"no {PROVIDER_NAME} access token; log in to Zerodha first")
            headers["Authorization"] = f"token {self._api_key}:{self._access_token}"
        async with limiter or self._default_limiter:
            try:
                response = await self._http.request(
                    method,
                    path,
                    params=params,
                    data=data,
                    headers=headers,
                    timeout=request_timeout if request_timeout is not None else httpx.USE_CLIENT_DEFAULT,
                )
            except httpx.HTTPError as exc:
                raise transport_error(PROVIDER_NAME, operation, exc) from None
        if response.is_error:
            body = error_body(response)
            raise error_from_response(
                response.status_code, _optional_str(body.get("error_type")), body.get("message")
            )
        if is_json(response):
            payload = decode_json(PROVIDER_NAME, operation, response)
            if not isinstance(payload, Mapping):
                raise ProviderProtocolError(f"{PROVIDER_NAME} {operation} returned an unexpected payload")
            if payload.get("status") == "error" or payload.get("error_type"):
                raise error_from_response(
                    response.status_code, _optional_str(payload.get("error_type")), payload.get("message")
                )
            return payload.get("data")
        if expect_csv and "csv" in response.headers.get("content-type", "").lower():
            return response.content
        raise ProviderProtocolError(f"{PROVIDER_NAME} {operation} returned an unexpected content type")


def quote_key(provider_exchange: str, provider_symbol: str) -> str:
    """Instrument key for the quote endpoints, e.g. ``NSE:INFY`` or ``NFO:NIFTY26JANFUT``."""
    return f"{provider_exchange}:{provider_symbol}"


def _strings(value: object) -> tuple[str, ...]:
    if not isinstance(value, list):
        return ()
    return tuple(item for item in value if isinstance(item, str))


def _optional_str(value: object) -> str | None:
    return value if isinstance(value, str) else None
