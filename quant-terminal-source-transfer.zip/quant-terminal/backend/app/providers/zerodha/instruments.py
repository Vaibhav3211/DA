"""Kite instrument dump (``GET /instruments``): a CSV regenerated once a day before market open.

Columns: instrument_token, exchange_token, tradingsymbol, name, last_price, expiry, strike,
tick_size, lot_size, instrument_type (EQ, FUT, CE, PE), segment (e.g. NSE, NFO-OPT, INDICES) and
exchange (Kite exchange code). ``last_price`` is a stale snapshot and is ignored. For derivatives
``name`` holds the underlying (e.g. NIFTY). Index rows have segment INDICES, are not tradable, and
stream INDEX_VALUE packets.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import date
from decimal import Decimal
from typing import Any, Final

from app.domain.enums import InstrumentType, OptionType, Provider, Segment
from app.domain.models import ProviderInstrumentRecord
from app.providers.instrument_dump import (
    InstrumentDump,
    finish,
    parse_date,
    parse_decimal,
    parse_positive_decimal,
    parse_positive_int,
    read_csv,
)
from app.providers.zerodha.constants import EXCHANGE_SEGMENTS, INDEX_EXCHANGES, INDICES_SEGMENT
from app.providers.zerodha.exceptions import PROVIDER_NAME

COLUMNS: Final = (
    "instrument_token",
    "exchange_token",
    "tradingsymbol",
    "name",
    "expiry",
    "strike",
    "tick_size",
    "lot_size",
    "instrument_type",
    "segment",
    "exchange",
)

_TYPES: Final = {
    "EQ": (InstrumentType.EQUITY, None),
    "FUT": (InstrumentType.FUTURE, None),
    "CE": (InstrumentType.OPTION, OptionType.CE),
    "PE": (InstrumentType.OPTION, OptionType.PE),
}
_MAX_TOKEN: Final = 2**32  # tokens are unsigned 32-bit integers in the binary feed


def parse_instrument_dump(data: bytes) -> InstrumentDump:
    dump = InstrumentDump(Provider.ZERODHA)
    for row in read_csv(data, provider_name=PROVIDER_NAME, required=COLUMNS):
        dump.rows += 1
        try:
            record = parse_row(row)
        except ValueError:  # includes pydantic.ValidationError
            dump.skip("invalid_row")
            continue
        if record is None:
            dump.skip("unsupported_exchange")
        else:
            dump.records.append(record)
    return finish(dump, PROVIDER_NAME)


def parse_row(row: Mapping[str, str]) -> ProviderInstrumentRecord | None:
    """One dump row; None when its exchange is not supported. Raises ValueError when invalid."""
    token = int(row["instrument_token"])
    if not 0 < token < _MAX_TOKEN:
        raise ValueError("instrument_token out of range")
    symbol = row["tradingsymbol"]
    if not symbol:
        raise ValueError("empty tradingsymbol")
    kite_exchange, kite_segment = row["exchange"], row["segment"]
    common: dict[str, Any] = {
        "provider": Provider.ZERODHA,
        "provider_token": str(token),
        "exchange_token": row["exchange_token"] or None,
        "provider_symbol": symbol,
        "provider_exchange": kite_exchange,
        "provider_segment": kite_segment,
        "metadata": {"instrument_type": row["instrument_type"]},
    }
    if kite_segment == INDICES_SEGMENT:
        index_exchange = INDEX_EXCHANGES.get(kite_exchange)
        if index_exchange is None:
            return None
        return ProviderInstrumentRecord(
            **common,
            exchange=index_exchange,
            segment=Segment.INDEX,
            instrument_type=InstrumentType.INDEX,
            name=row["name"] or symbol,
            tradable=False,
        )
    canonical = EXCHANGE_SEGMENTS.get(kite_exchange)
    if canonical is None:
        return None
    exchange, segment = canonical
    instrument_type, option_type = _TYPES.get(row["instrument_type"], (InstrumentType.OTHER, None))
    expiry: date | None = None
    underlying: str | None = None
    strike: Decimal | None = None
    if instrument_type in (InstrumentType.FUTURE, InstrumentType.OPTION):
        expiry = parse_date(row["expiry"])
        underlying = row["name"]
        if expiry is None or not underlying:
            raise ValueError("derivative without expiry or underlying")
        if option_type is not None:
            strike = parse_decimal(row["strike"])
            if strike is None or strike <= 0:
                raise ValueError("option without a strike")
    return ProviderInstrumentRecord(
        **common,
        exchange=exchange,
        segment=segment,
        instrument_type=instrument_type,
        name=row["name"] or None,
        underlying=underlying,
        expiry=expiry,
        strike=strike,
        option_type=option_type,
        lot_size=parse_positive_int(row["lot_size"]),
        tick_size=parse_positive_decimal(row["tick_size"]),
    )
