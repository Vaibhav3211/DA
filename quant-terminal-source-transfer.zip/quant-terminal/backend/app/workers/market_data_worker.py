"""Market-data worker (``qt-market-data-worker``): streams every enabled provider account's market data
into Redis and PostgreSQL.

The worker follows the database. Every ``SUBSCRIPTION_RECONCILE_INTERVAL_SECONDS`` it moves accounts
whose access token ran out to a login-required status and reconciles its feeds with the enabled
accounts and workspace instruments; a worker command (a login, a workspace change, ...) triggers the
reconciliation at once. Commands are read from the tail of the command stream: those issued while
the worker was down need no replay, since the reconciliation at start-up reads their effect from the
database. Calendar overrides are re-read every ``CALENDAR_RELOAD_INTERVAL_SECONDS``.

Live providers stream only with ``MARKET_DATA_ENABLED=true`` and the simulator only with
``SIMULATOR_ENABLED=true``; the heartbeat reports the accounts that may not stream as idle.
Ctrl+C (or SIGTERM where the platform supports it, e.g. ``docker stop``) stops the worker: the feeds
disconnect, hand over their forming candles and the candle writer stores them before the process exits.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable, Iterable, Sequence
from functools import partial
from typing import Any, Final, Protocol
from uuid import UUID

from pydantic import ValidationError
from redis.exceptions import RedisError

from app import __version__
from app.container import Container
from app.core.config import Settings, get_settings
from app.core.logging import configure_logging, get_logger
from app.domain.events import WorkerCommand
from app.market_data.calendars.loader import load_market_calendar, load_overrides
from app.market_data.calendars.service import CalendarOverride, MarketCalendar
from app.market_data.candles.writer import CandleWriter
from app.market_data.manager import ConnectionManager, adapter_factory, forming_loader
from app.market_data.subscriptions import SubscriptionPlanner
from app.observability.heartbeat import MARKET_DATA_WORKER, HeartbeatPublisher
from app.observability.metrics import REDIS_ERRORS, serve_worker_metrics
from app.providers.base import describe_error
from app.providers.tls import prepare_tls
from app.services.capabilities import CapabilityService
from app.services.instruments import InstrumentService
from app.services.provider_accounts import ProviderAccountService
from app.streaming.redis_bus import RedisBus, StreamMessage, Streams
from app.workers.shutdown import stop_on_sigterm

log = get_logger(__name__)

_COMMAND_BATCH: Final = 100
_READ_RETRY_SECONDS: Final = 1.0  # pause after a failed command read


class Feeds(Protocol):
    """What the worker uses of the :class:`ConnectionManager`."""

    async def reconcile(self) -> set[UUID]: ...

    async def handle(self, commands: Iterable[WorkerCommand]) -> None: ...

    async def stop_all(self) -> None: ...

    def details(self) -> dict[str, Any]: ...


class Writer(Protocol):
    """What the worker uses of the :class:`CandleWriter`."""

    def start(self) -> None: ...

    async def close(self) -> None: ...


class MarketDataWorker:
    """Keeps the feeds in line with the database and the worker commands until it is cancelled."""

    def __init__(
        self,
        settings: Settings,
        bus: RedisBus,
        feeds: Feeds,
        writer: Writer,
        calendar: MarketCalendar,
        *,
        expire_tokens: Callable[[], Awaitable[list[UUID]]],
        load_overrides: Callable[[], Awaitable[Iterable[CalendarOverride]]],
        block_ms: int = 1000,
        monotonic: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self._settings = settings
        self._bus = bus
        self._feeds = feeds
        self._writer = writer
        self._calendar = calendar
        self._expire_tokens = expire_tokens
        self._load_overrides = load_overrides
        self._block_ms = block_ms
        self._monotonic = monotonic
        self._sleep = sleep
        self._offset: str | None = None  # the newest command seen (None until Redis answers)
        self._read_error: str | None = None  # why the last command read failed
        self._upkeep_due = 0.0
        self._calendar_due = 0.0

    async def run(self) -> None:
        """Run until cancelled, then stop the feeds and store their candles."""
        self._writer.start()
        try:
            await self.start()
            while True:
                await self.step()
        finally:
            try:
                await self._feeds.stop_all()
            finally:
                await self._writer.close()

    async def start(self) -> None:
        """Note where the command stream ends, then start the feeds the database asks for (in this
        order, so that no command issued after the first reconciliation is missed)."""
        try:
            self._offset = await self._bus.last_id(Streams.COMMANDS)
        except (RedisError, OSError) as exc:  # the first poll asks again
            self._read_failed(exc)
        await self._upkeep()
        self._calendar_due = self._monotonic() + self._settings.calendar_reload_interval_seconds

    async def step(self) -> None:
        """Run the upkeep that is due, then handle the commands that arrive within ``block_ms``."""
        now = self._monotonic()
        if now >= self._calendar_due:
            await self._reload_calendar()
        if now >= self._upkeep_due:
            await self._upkeep()
        commands = await self._poll()
        if commands:
            await self._feeds.handle(commands)

    def details(self) -> dict[str, Any]:
        """Heartbeat details: the feeds' state and how far each exchange calendar is verified."""
        return {
            **self._feeds.details(),
            "calendar_verified_until": {
                exchange.value: day.isoformat() for exchange, day in self._calendar.coverage().items()
            },
        }

    # ---- internals -------------------------------------------------------------------------------

    async def _upkeep(self) -> None:
        """Expire the access tokens that ran out, then reconcile the feeds with the database."""
        try:
            expired = await self._expire_tokens()
        except Exception as exc:  # e.g. the database is down; the reconciliation still runs
            log.error("token_expiry_failed", error=describe_error(exc))
        else:
            if expired:
                log.warning("access_tokens_expired", accounts=[str(account_id) for account_id in expired])
        await self._feeds.reconcile()
        self._upkeep_due = self._monotonic() + self._settings.subscription_reconcile_interval_seconds

    async def _reload_calendar(self) -> None:
        """Apply the calendar overrides added, changed or removed since they were last read."""
        try:
            overrides = frozenset(await self._load_overrides())
        except Exception as exc:  # the overrides in use stay; the next reload tries again
            log.error("calendar_reload_failed", error=describe_error(exc))
        else:
            if overrides != self._calendar.overrides:
                self._calendar.set_overrides(overrides)
                log.info("calendar_overrides_reloaded", overrides=len(overrides))
        self._calendar_due = self._monotonic() + self._settings.calendar_reload_interval_seconds

    async def _poll(self) -> list[WorkerCommand]:
        """The commands that arrive within ``block_ms``; none, after a pause, while Redis is down."""
        try:
            if self._offset is None:
                self._offset = await self._bus.last_id(Streams.COMMANDS)
            messages = await self._bus.read(
                {Streams.COMMANDS: self._offset}, count=_COMMAND_BATCH, block_ms=self._block_ms
            )
        except (RedisError, OSError) as exc:  # the periodic reconciliation still follows the database
            self._read_failed(exc)
            await self._sleep(_READ_RETRY_SECONDS)
            return []
        if self._read_error is not None:
            log.info("command_read_recovered")
            self._read_error = None
        if messages:
            self._offset = messages[-1].message_id
        return _commands(messages)

    def _read_failed(self, exc: Exception) -> None:
        REDIS_ERRORS.labels(operation="read_commands").inc()
        error = describe_error(exc)
        if error != self._read_error:  # logged once while the same failure repeats
            log.warning("command_read_failed", error=error)
            self._read_error = error


def _commands(messages: Sequence[StreamMessage]) -> list[WorkerCommand]:
    commands: list[WorkerCommand] = []
    for message in messages:
        try:
            commands.append(WorkerCommand.model_validate(message.payload))
        except ValidationError as exc:  # e.g. a command type of a newer version: skipped
            log.warning("worker_command_invalid", message_id=message.message_id, errors=exc.error_count())
    return commands


async def serve(settings: Settings) -> None:
    """Build the worker on a new container and run it until cancelled."""
    stop_on_sigterm()
    await prepare_tls()
    container = Container.create(settings)
    try:
        db, bus = container.db, container.bus
        calendar = await load_market_calendar(
            db, extend_beyond_coverage=settings.calendar_extend_beyond_coverage
        )
        accounts = ProviderAccountService.from_container(container)
        planner = SubscriptionPlanner(
            settings, InstrumentService(accounts), CapabilityService.from_container(container)
        )
        writer = CandleWriter(db, interval_seconds=settings.candle_flush_interval_seconds)
        manager = ConnectionManager(
            settings,
            planner,
            adapter_factory(settings, bus, accounts, calendar),
            bus,
            writer,
            calendar,
            forming_loader(db),
        )
        worker = MarketDataWorker(
            settings,
            bus,
            manager,
            writer,
            calendar,
            expire_tokens=accounts.expire_tokens,
            load_overrides=partial(load_overrides, db),
        )
        heartbeat = HeartbeatPublisher(bus, MARKET_DATA_WORKER, __version__, details=worker.details)
        serve_worker_metrics(settings.market_data_worker_metrics_port)
        log.info(
            "market_data_worker_started",
            version=__version__,
            app_env=settings.app_env.value,
            simulated_mode=settings.is_simulated_mode,
            market_data_enabled=settings.market_data_enabled,
            simulator_enabled=settings.simulator_enabled,
            candle_intervals=[interval.value for interval in settings.candle_intervals],
        )
        beating = asyncio.create_task(heartbeat.run(), name="heartbeat")
        try:
            await worker.run()
        finally:
            beating.cancel()
            await asyncio.gather(beating, return_exceptions=True)
    finally:
        await container.close()


def main() -> None:
    settings = get_settings()
    configure_logging(settings.log_level, json_logs=settings.log_json)
    try:
        asyncio.run(serve(settings))
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass  # a requested stop: the worker already shut down in order
    except Exception:
        log.exception("market_data_worker_failed")
        raise SystemExit(1) from None
    log.info("market_data_worker_stopped")


if __name__ == "__main__":
    main()
