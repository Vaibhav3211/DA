"""Strategy worker (``qt-strategy-worker``): runs every runnable deployment's strategy on live market data
and turns what it proposes into risk-gated signals.

The worker follows the database. Every ``DEPLOYMENT_REFRESH_SECONDS``, and at once after a worker command
that can change what should run, it compares its runs with the runnable deployments: a new one gets a run,
one that was disabled, blocked or deleted is stopped, and one whose version, configuration or instruments
changed is restarted. Each run is a ``strategy_runs`` row holding its counters and a heartbeat; the runs a
dead worker left open are closed as FAILED once their heartbeat is stale.

A run starts warm: its indicators are fed the stored candles that closed up to five minutes earlier, then
the last ten minutes of the candle stream, so the strategy is only called with candles that close while it
runs. A run that fails to start is retried with a growing delay; one that cannot run as deployed (an
invalid configuration, candles the platform does not build) waits for a redeploy or a restart. Candles,
market events and commands are read from the tail of their streams with plain XREAD: what was published
while the worker was down reaches the strategies through the warm-up, not as live data.

The worker also expires signals past their validity and re-reads calendar overrides. Run one strategy
worker per platform: two would evaluate every deployment twice.
"""

from __future__ import annotations

import asyncio
import math
import os
import socket
import time
from collections.abc import Awaitable, Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timedelta
from functools import partial
from itertools import groupby
from typing import Any, Final
from uuid import UUID

from pydantic import BaseModel, ValidationError
from redis.exceptions import RedisError

from app import __version__
from app.container import Container
from app.core.clock import utc_now
from app.core.config import Settings, get_settings
from app.core.logging import configure_logging, get_logger
from app.domain.enums import Provider, StrategyRunStatus
from app.domain.events import CommandType, WorkerCommand
from app.domain.models import Candle, Instrument, NormalizedMarketEvent
from app.market_data.calendars.loader import load_market_calendar, load_overrides
from app.market_data.calendars.service import CalendarOverride, MarketCalendar
from app.market_data.candles.store import load_recent
from app.observability.heartbeat import STRATEGY_WORKER, HeartbeatPublisher
from app.observability.metrics import REDIS_ERRORS, SIGNALS_EMITTED, serve_worker_metrics
from app.persistence.database import Database
from app.providers.base import describe_error
from app.services.strategies import DeploymentView, RunnableDeployment, StrategyService
from app.services.strategy_runs import RunStore
from app.signals.engine import EXPIRE_BATCH, DeploymentGoneError, Proposal, RunContext, SignalEngine
from app.strategies.registry import RegisteredStrategy, StrategyConfigError
from app.strategies.runtime import CircuitBreaker, MarketState, StrategyRunner, calendar_sessions
from app.streaming.redis_bus import RedisBus, StreamMessage, Streams
from app.workers.shutdown import stop_on_sigterm

log = get_logger(__name__)

_READ_BATCH: Final = 500  # entries per stream and read
_READ_RETRY_SECONDS: Final = 1.0  # pause after a failed stream read
_EXPIRY_SECONDS: Final = 15.0  # how often open signals past their validity are expired
_SETTLE: Final = timedelta(minutes=5)  # candles that closed earlier come from the database
_REPLAY_MS: Final = 10 * 60 * 1000  # how much of the candle stream a warm-up replays
_REPLAY_PAGE: Final = 1000
_EMPTY_STREAM: Final = "0-0"
_MAX_RETRY_SECONDS: Final = 3600.0
_MIN_STALE_SECONDS: Final = 60.0  # a run's heartbeat older than this (at least) marks it abandoned
_RELOADING: Final = frozenset(
    {CommandType.RELOAD_DEPLOYMENTS, CommandType.REFRESH_SUBSCRIPTIONS, CommandType.REFRESH_INSTRUMENTS}
)

# What a run is started from: the strategy version, the configuration and the (instrument, provider) pairs.
type _Signature = tuple[str, UUID, tuple[tuple[UUID, Provider], ...]]


@dataclass(frozen=True, slots=True)
class _Run:
    deployment: DeploymentView
    signature: _Signature
    runner: StrategyRunner
    event_providers: frozenset[Provider]  # whose market-event streams the strategy reads


@dataclass(frozen=True, slots=True)
class _Retry:
    signature: _Signature
    attempts: int
    due: float  # monotonic time of the next attempt; infinite until the deployment changes


@dataclass(frozen=True, slots=True)
class _Starting:
    item: RunnableDeployment
    signature: _Signature
    runner: StrategyRunner
    stored: int  # candles the warm-up took from the database


class StrategyWorker:
    """Keeps a run per runnable deployment and feeds the runs live candles and events until cancelled."""

    def __init__(
        self,
        settings: Settings,
        bus: RedisBus,
        db: Database,
        strategies: StrategyService,
        runs: RunStore,
        engine: SignalEngine,
        calendar: MarketCalendar,
        *,
        load_overrides: Callable[[], Awaitable[Iterable[CalendarOverride]]],
        worker_id: str,
        block_ms: int = 1000,
        clock: Callable[[], datetime] = utc_now,
        monotonic: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self._settings = settings
        self._bus = bus
        self._db = db
        self._strategies = strategies
        self._runs = runs
        self._engine = engine
        self._calendar = calendar
        self._load_overrides = load_overrides
        self._worker_id = worker_id
        self._block_ms = block_ms
        self._clock = clock
        self._monotonic = monotonic
        self._sleep = sleep
        self._sessions = calendar_sessions(calendar)
        self._intervals = frozenset(settings.candle_intervals)
        self._active: dict[UUID, _Run] = {}  # by deployment
        self._retries: dict[UUID, _Retry] = {}  # deployments whose last start failed
        self._offsets: dict[str, str] = {}  # the newest entry seen per stream read
        self._read_error: str | None = None  # why the last stream read failed
        self._reload = False  # a command asked for a refresh
        self._refresh_due = 0.0
        self._expire_due = 0.0
        self._calendar_due = 0.0

    async def run(self) -> None:
        """Run until cancelled, then stop every run."""
        try:
            await self.start()
            while True:
                await self.step()
        finally:
            await self.stop()

    async def start(self) -> None:
        """Note where the command and candle streams end, then start the runs the database asks for (in
        this order, so that nothing published after a warm-up is missed)."""
        try:
            for stream in (Streams.COMMANDS, Streams.CANDLES):
                self._offsets[stream] = await self._bus.last_id(stream)
        except (RedisError, OSError) as exc:  # warm-ups read the database only; the first read asks again
            self._read_failed(exc)
        await self._refresh()
        self._calendar_due = self._monotonic() + self._settings.calendar_reload_interval_seconds

    async def step(self) -> None:
        """Run the upkeep that is due, then handle what arrives on the streams within ``block_ms``."""
        now = self._monotonic()
        if now >= self._calendar_due:
            await self._reload_calendar()
        if now >= self._expire_due:
            await self._expire()
        if self._reload or now >= self._refresh_due:
            await self._refresh()
        messages = await self._poll()
        if messages:
            await self._handle(messages)

    async def stop(self) -> None:
        """Stop every run, calling each strategy's ``shutdown`` hook."""
        for deployment_id in list(self._active):
            await self._stop(deployment_id, StrategyRunStatus.STOPPED, "the worker is stopping")

    def details(self) -> dict[str, Any]:
        """Heartbeat details: the runs' state and how far each exchange calendar is verified."""
        runs = list(self._active.values())
        return {
            "runs": len(runs),
            "circuits_open": sum(run.runner.circuit_open for run in runs),
            "warming_instruments": sum(run.runner.market.warming() for run in runs),
            "failed_starts": len(self._retries),
            "calendar_verified_until": {
                exchange.value: day.isoformat() for exchange, day in self._calendar.coverage().items()
            },
        }

    # ---- deployments -----------------------------------------------------------------------------

    async def _refresh(self) -> None:
        """Bring the runs in line with the runnable deployments and record how each run is doing."""
        self._reload = False
        self._refresh_due = self._monotonic() + self._settings.deployment_refresh_seconds
        try:
            wanted = {item.deployment.id: item for item in await self._strategies.runnable_deployments()}
        except Exception as exc:  # e.g. the database is down: the runs carry on as they are
            log.error("deployment_refresh_failed", error=describe_error(exc))
            return
        for deployment_id, run in list(self._active.items()):
            item = wanted.get(deployment_id)
            if item is None:
                reason = "the deployment is no longer enabled and runnable"
                await self._stop(deployment_id, StrategyRunStatus.STOPPED, reason)
            elif _signature(item) != run.signature:
                await self._stop(deployment_id, StrategyRunStatus.STOPPED, "the deployment changed")
        await self._record()
        for deployment_id in self._retries.keys() - wanted.keys():
            del self._retries[deployment_id]
        now = self._monotonic()
        due: list[tuple[RunnableDeployment, _Signature]] = []
        for deployment_id, item in wanted.items():
            if deployment_id in self._active:
                continue
            signature = _signature(item)
            retry = self._retries.get(deployment_id)
            if retry is None or retry.signature != signature or now >= retry.due:
                due.append((item, signature))
        if due:
            await self._start(due)
        await self._close_abandoned()

    async def _record(self) -> None:
        """Store each run's counters and heartbeat; a run whose row was closed meanwhile is stopped."""
        for deployment_id, run in list(self._active.items()):
            runner = run.runner
            try:
                still_open = await self._runs.record(
                    runner.run.run_id,
                    runner.stats,
                    circuit_open=runner.circuit_open,
                    warmup=runner.market.warmup(),
                )
            except Exception as exc:  # e.g. the database is down: the next refresh records them
                log.error("strategy_run_record_failed", error=describe_error(exc))
                return
            if not still_open:
                await self._stop(deployment_id, StrategyRunStatus.STOPPED, "its run was closed elsewhere")

    async def _close_abandoned(self) -> None:
        stale = max(3 * self._settings.deployment_refresh_seconds, _MIN_STALE_SECONDS)
        keep = [run.runner.run.run_id for run in self._active.values()]
        try:
            closed = await self._runs.close_abandoned(stale_after=timedelta(seconds=stale), keep=keep)
        except Exception as exc:  # the next refresh tries again
            log.error("abandoned_runs_check_failed", error=describe_error(exc))
            return
        if closed:
            log.warning("abandoned_runs_closed", runs=[str(run_id) for run_id in closed])

    # ---- starting a run ------------------------------------------------------------------------------

    async def _start(self, due: Sequence[tuple[RunnableDeployment, _Signature]]) -> None:
        """Start runs warm: stored candles up to the cutoff, then the candle stream up to where the live
        read continues (folding only takes newer candles, so the two may overlap)."""
        offset = self._offsets.get(Streams.CANDLES)
        if offset == _EMPTY_STREAM:
            offset = None
        cutoff = self._clock() - (_SETTLE if offset is not None else timedelta(0))
        prepared: list[_Starting] = []
        for item, signature in due:
            starting = await self._prepare(item, signature, cutoff)
            if starting is not None:
                prepared.append(starting)
        streamed = [0] * len(prepared)
        if offset is not None and prepared:
            try:
                streamed = await self._replay([starting.runner.market for starting in prepared], offset)
            except Exception as exc:  # e.g. Redis is down: retried later
                if isinstance(exc, RedisError | OSError):
                    REDIS_ERRORS.labels(operation="replay_candles").inc()
                problem = f"could not replay the recent candles: {describe_error(exc)}"
                for starting in prepared:
                    await self._failed(starting.item, starting.signature, problem, starting.runner.run.run_id)
                return
        for starting, count in zip(prepared, streamed, strict=True):
            await self._activate(starting, cutoff, count)

    async def _prepare(
        self, item: RunnableDeployment, signature: _Signature, cutoff: datetime
    ) -> _Starting | None:
        """Open the run, create the strategy and fold the stored candles into its market state; None
        when that failed (and the failure is recorded)."""
        deployment = item.deployment
        entry = self._strategies.registry.get(deployment.strategy_id)
        context = {
            "code_fingerprint": entry.fingerprint,
            "worker_version": __version__,
            "instruments": {
                instrument.canonical_key: provider.value for instrument, provider in item.instruments
            },
            "excluded": dict(item.excluded),
        }
        try:
            run_id = await self._runs.open(deployment, worker_id=self._worker_id, input_context=context)
        except Exception as exc:  # e.g. the database is down
            await self._failed(item, signature, f"could not open the run: {describe_error(exc)}", None)
            return None
        missing = sorted(entry.intervals - self._intervals, key=lambda interval: interval.seconds)
        if missing:
            names = ", ".join(interval.value for interval in missing)
            problem = f"it needs {names} candles, which CANDLE_INTERVALS does not build"
            await self._failed(item, signature, problem, run_id, permanent=True)
            return None
        try:
            config = entry.validate_config(deployment.config)
        except StrategyConfigError as exc:
            await self._failed(item, signature, f"invalid configuration: {exc}", run_id, permanent=True)
            return None
        run = RunContext(
            run_id=run_id,
            deployment_id=deployment.id,
            workspace_id=deployment.workspace_id,
            market_region=deployment.market_region,
            metadata=entry.metadata,
            configuration_id=deployment.configuration_id,
        )
        try:
            market = MarketState(entry, item.instruments, sessions=self._sessions)
            runner = StrategyRunner(
                entry,
                run,
                config,
                market,
                timeout_seconds=self._settings.strategy_timeout_seconds,
                breaker=CircuitBreaker(
                    self._settings.strategy_failure_threshold,
                    self._settings.strategy_circuit_reset_seconds,
                    monotonic=self._monotonic,
                ),
                clock=self._clock,
                monotonic=self._monotonic,
            )
        except Exception as exc:  # e.g. the strategy's constructor raised
            problem = f"could not create the strategy: {describe_error(exc)}"
            await self._failed(item, signature, problem, run_id)
            return None
        try:
            stored = await self._warm_up(entry, market, cutoff)
        except Exception as exc:  # e.g. the database is down
            await self._failed(item, signature, f"warm-up failed: {describe_error(exc)}", run_id)
            return None
        return _Starting(item, signature, runner, stored)

    async def _warm_up(self, entry: RegisteredStrategy, market: MarketState, cutoff: datetime) -> int:
        """Fold the stored candles that closed by ``cutoff``: each series' warm-up, and the session so far
        on the intervals of session-anchored indicators. Returns how many were folded."""
        folded = 0
        async with self._db.session() as session:
            for instrument, provider, interval in market.series():
                since = (
                    self._session_start(instrument, cutoff) if interval in entry.session_intervals else None
                )
                candles = await load_recent(
                    session,
                    provider,
                    instrument.id,
                    instrument,
                    interval,
                    until=cutoff,
                    limit=entry.warmups[interval],
                    since=since,
                )
                for candle in candles:
                    if market.fold(candle):
                        folded += 1
        return folded

    def _session_start(self, instrument: Instrument, at: datetime) -> datetime:
        """When the session at ``at`` opened; a day earlier when its hours are unknown."""
        opened = self._sessions(instrument.exchange, at).open_at
        return opened if opened is not None else at - timedelta(days=1)

    async def _replay(self, markets: Sequence[MarketState], offset: str) -> list[int]:
        """Fold the candles published in the ``_REPLAY_MS`` up to ``offset`` into each market; returns how
        many each one took."""
        taken = [0] * len(markets)
        start = f"{max(_stream_ms(offset) - _REPLAY_MS, 0)}-0"
        while True:
            messages = await self._bus.range(Streams.CANDLES, start, offset, count=_REPLAY_PAGE)
            for candle in _parse(messages, Candle):
                for index, market in enumerate(markets):
                    if market.fold(candle):
                        taken[index] += 1
            if len(messages) < _REPLAY_PAGE:
                return taken
            start = f"({messages[-1].message_id}"

    async def _activate(self, starting: _Starting, cutoff: datetime, streamed: int) -> None:
        """Call the strategy's ``initialize`` hook and, when it succeeds, start feeding the run."""
        runner, item = starting.runner, starting.item
        problem = await runner.initialize()
        if problem is not None:
            await runner.shutdown()
            await self._failed(item, starting.signature, problem, runner.run.run_id)
            return
        progress = runner.market.warmup()
        warmup = {
            "cutoff": cutoff.isoformat(),
            "stored_candles": starting.stored,
            "stream_candles": streamed,
            "instruments_warming": progress.instruments,
        }
        try:
            await self._runs.mark_running(runner.run.run_id, context={"warmup": warmup}, warmup=progress)
        except Exception as exc:  # the next refresh records it as running
            log.error("strategy_run_update_failed", **_fields(item.deployment), error=describe_error(exc))
        has_events = bool(runner.entry.metadata.event_types)
        providers = frozenset(provider for _, provider in item.instruments) if has_events else frozenset()
        self._active[item.deployment.id] = _Run(item.deployment, starting.signature, runner, providers)
        self._retries.pop(item.deployment.id, None)
        log.info(
            "strategy_run_started",
            **_fields(item.deployment),
            run_id=str(runner.run.run_id),
            instruments=len(item.instruments),
            excluded=len(item.excluded),
            **warmup,
        )
        if not item.instruments:
            log.warning("strategy_run_has_no_instruments", **_fields(item.deployment))

    async def _failed(
        self,
        item: RunnableDeployment,
        signature: _Signature,
        problem: str,
        run_id: UUID | None,
        *,
        permanent: bool = False,
    ) -> None:
        """Record a failed start and when to try again: after a growing delay, or (``permanent``) once
        the deployment changes."""
        deployment = item.deployment
        attempts, delay = self._backoff(deployment.id, signature, permanent=permanent)
        log.error(
            "strategy_run_failed",
            **_fields(deployment),
            error=problem,
            attempts=attempts,
            retry_in_seconds=None if permanent else round(delay, 1),  # None: once the deployment changes
        )
        if run_id is not None:
            try:
                await self._runs.close(run_id, StrategyRunStatus.FAILED, error=problem)
            except Exception as exc:  # it is closed as abandoned once its heartbeat is stale
                log.error("strategy_run_close_failed", run_id=str(run_id), error=describe_error(exc))

    async def _stop(
        self, deployment_id: UUID, status: StrategyRunStatus, reason: str, *, error: str | None = None
    ) -> None:
        run = self._active.pop(deployment_id, None)
        if run is None:
            return
        runner = run.runner
        await runner.shutdown()
        try:
            await self._runs.close(runner.run.run_id, status, runner.stats, error=error)
        except Exception as exc:  # it is closed as abandoned once its heartbeat is stale
            log.error("strategy_run_close_failed", run_id=str(runner.run.run_id), error=describe_error(exc))
        log.info(
            "strategy_run_stopped",
            **_fields(run.deployment),
            run_id=str(runner.run.run_id),
            status=status.value,
            reason=reason,
            candles=runner.stats.candles,
            signals=runner.stats.signals,
        )

    # ---- live data -----------------------------------------------------------------------------------

    async def _poll(self) -> list[StreamMessage]:
        """What arrives within ``block_ms`` on the command, candle and needed market-event streams;
        nothing, after a pause, while Redis is down."""
        providers = frozenset[Provider]().union(*(run.event_providers for run in self._active.values()))
        streams = [Streams.COMMANDS, Streams.CANDLES, *sorted(map(Streams.market_events, providers))]
        for stream in self._offsets.keys() - set(streams):  # no run reads its events any more
            del self._offsets[stream]
        try:
            for stream in streams:
                if stream not in self._offsets:
                    self._offsets[stream] = await self._bus.last_id(stream)
            messages = await self._bus.read(
                {stream: self._offsets[stream] for stream in streams},
                count=_READ_BATCH,
                block_ms=self._block_ms,
            )
        except (RedisError, OSError) as exc:  # the runs wait; the deployments are still refreshed
            self._read_failed(exc)
            await self._sleep(_READ_RETRY_SECONDS)
            return []
        if self._read_error is not None:
            log.info("stream_read_recovered")
            self._read_error = None
        for message in messages:
            self._offsets[message.stream] = message.message_id
        return messages

    def _read_failed(self, exc: Exception) -> None:
        REDIS_ERRORS.labels(operation="read_strategy_streams").inc()
        error = describe_error(exc)
        if error != self._read_error:  # logged once while the same failure repeats
            log.warning("stream_read_failed", error=error)
            self._read_error = error

    async def _handle(self, messages: Sequence[StreamMessage]) -> None:
        by_stream: dict[str, list[StreamMessage]] = {}
        for message in messages:
            by_stream.setdefault(message.stream, []).append(message)
        commands = _parse(by_stream.pop(Streams.COMMANDS, ()), WorkerCommand)
        if any(command.type in _RELOADING for command in commands):
            self._reload = True  # the next step refreshes the runs before it reads again
        proposals: dict[UUID, list[Proposal]] = {}
        await self._on_candles(_parse(by_stream.pop(Streams.CANDLES, ()), Candle), proposals)
        events = [event for entries in by_stream.values() for event in _parse(entries, NormalizedMarketEvent)]
        await self._on_events(events, proposals)
        await self._submit(proposals)

    async def _on_candles(self, candles: list[Candle], proposals: dict[UUID, list[Proposal]]) -> None:
        """Call the strategies with closed candles in closing order. All candles closing at the same time
        are folded into every run before any strategy is called, so each sees every instrument and
        interval up to date."""
        candles.sort(key=_closing)
        for _, group in groupby(candles, key=_closing):
            closing = list(group)
            calls: list[tuple[_Run, Candle]] = []
            for run in list(self._active.values()):
                try:
                    accepted = [candle for candle in closing if run.runner.fold(candle)]
                except Exception as exc:  # an indicator bug: only this run stops
                    error = f"market state update failed: {describe_error(exc)}"
                    await self._stop(run.deployment.id, StrategyRunStatus.FAILED, error, error=error)
                    self._backoff(run.deployment.id, run.signature)
                    continue
                calls.extend((run, candle) for candle in accepted)
            for run, candle in calls:
                found = await run.runner.on_candle(candle)
                if found:
                    proposals.setdefault(run.deployment.id, []).extend(found)

    async def _on_events(
        self, events: Sequence[NormalizedMarketEvent], proposals: dict[UUID, list[Proposal]]
    ) -> None:
        for event in events:
            for run in self._active.values():
                if run.runner.wants(event):
                    found = await run.runner.on_event(event)
                    if found:
                        proposals.setdefault(run.deployment.id, []).extend(found)

    async def _submit(self, proposals: Mapping[UUID, list[Proposal]]) -> None:
        """Hand each run's proposals to the signal engine in one batch."""
        for deployment_id, batch in proposals.items():
            run = self._active.get(deployment_id)
            if run is None:  # it stopped after proposing them
                continue
            try:
                outcomes = await self._engine.submit(run.runner.run, batch)
            except DeploymentGoneError:
                await self._stop(deployment_id, StrategyRunStatus.STOPPED, "the deployment was deleted")
                continue
            except Exception as exc:  # e.g. the database is down: these candidates are lost
                log.error(
                    "signal_submit_failed",
                    **_fields(run.deployment),
                    candidates=len(batch),
                    error=describe_error(exc),
                )
                continue
            for proposal, outcome in zip(batch, outcomes, strict=True):
                if outcome.stored and outcome.decision is not None:
                    SIGNALS_EMITTED.labels(
                        strategy=run.deployment.strategy_id,
                        signal_type=proposal.candidate.signal_type.value,
                        risk_outcome=outcome.decision.outcome.value,
                    ).inc()
                if outcome.emitted:
                    run.runner.stats.signals += 1

    def _backoff(
        self, deployment_id: UUID, signature: _Signature, *, permanent: bool = False
    ) -> tuple[int, float]:
        """Delay the deployment's next start: doubling from ``STRATEGY_CIRCUIT_RESET_SECONDS`` while the
        deployment stays the same or, when ``permanent``, until it changes. Returns the attempt number
        and the delay."""
        previous = self._retries.get(deployment_id)
        attempts = previous.attempts + 1 if previous is not None and previous.signature == signature else 1
        delay = math.inf
        if not permanent:
            delay = min(
                self._settings.strategy_circuit_reset_seconds * 2 ** (min(attempts, 32) - 1),
                _MAX_RETRY_SECONDS,
            )
        self._retries[deployment_id] = _Retry(signature, attempts, self._monotonic() + delay)
        return attempts, delay

    # ---- upkeep --------------------------------------------------------------------------------------

    async def _expire(self) -> None:
        """Expire the open signals past their validity; a full batch makes the next sweep due at once."""
        expired = 0
        try:
            expired = await self._engine.expire()
        except Exception as exc:  # the next sweep tries again
            log.error("signal_expiry_failed", error=describe_error(exc))
        else:
            if expired:
                log.info("signals_expired", signals=expired)
        self._expire_due = self._monotonic() + (0.0 if expired >= EXPIRE_BATCH else _EXPIRY_SECONDS)

    async def _reload_calendar(self) -> None:
        """Apply the calendar overrides added, changed or removed since they were last read."""
        try:
            overrides = frozenset(await self._load_overrides())
        except Exception as exc:  # the overrides in use stay; the next reload tries again
            log.error("calendar_reload_failed", error=describe_error(exc))
        else:
            if overrides != self._calendar.overrides:
                self._calendar.set_overrides(overrides)
                log.info("calendar_overrides_reloaded", overrides=len(overrides))
        self._calendar_due = self._monotonic() + self._settings.calendar_reload_interval_seconds


def _signature(item: RunnableDeployment) -> _Signature:
    deployment = item.deployment
    instruments = tuple((instrument.id, provider) for instrument, provider in item.instruments)
    return deployment.strategy_version, deployment.configuration_id, instruments


def _fields(deployment: DeploymentView) -> dict[str, str]:
    return {
        "deployment_id": str(deployment.id),
        "strategy_id": deployment.strategy_id,
        "workspace": deployment.workspace_slug,
    }


def _closing(candle: Candle) -> datetime:
    return candle.bucket_end


def _stream_ms(message_id: str) -> int:
    """The millisecond timestamp of a stream entry ID."""
    return int(message_id.partition("-")[0])


def _parse[M: BaseModel](messages: Iterable[StreamMessage], model: type[M]) -> list[M]:
    parsed: list[M] = []
    for message in messages:
        try:
            parsed.append(model.model_validate(message.payload))
        except ValidationError as exc:  # e.g. written by a newer version: skipped
            log.warning(
                "stream_message_invalid",
                stream=message.stream,
                message_id=message.message_id,
                errors=exc.error_count(),
            )
    return parsed


def default_worker_id() -> str:
    """Names this worker process in the runs it records."""
    return f"{socket.gethostname()}:{os.getpid()}"[:120]


async def serve(settings: Settings) -> None:
    """Build the worker on a new container and run it until cancelled."""
    stop_on_sigterm()
    container = Container.create(settings)
    try:
        db, bus = container.db, container.bus
        strategies = StrategyService.from_container(container)
        synced = await strategies.sync_catalogue()
        if synced.changed:
            log.info("strategy_catalogue_synced", **synced.model_dump(exclude_defaults=True))
        calendar = await load_market_calendar(
            db, extend_beyond_coverage=settings.calendar_extend_beyond_coverage
        )
        worker_id = default_worker_id()
        worker = StrategyWorker(
            settings,
            bus,
            db,
            strategies,
            RunStore(db),
            SignalEngine(db, bus, settings, calendar),
            calendar,
            load_overrides=partial(load_overrides, db),
            worker_id=worker_id,
        )
        heartbeat = HeartbeatPublisher(bus, STRATEGY_WORKER, __version__, details=worker.details)
        serve_worker_metrics(settings.strategy_worker_metrics_port)
        log.info(
            "strategy_worker_started",
            version=__version__,
            app_env=settings.app_env.value,
            worker_id=worker_id,
            strategies=sorted(entry.strategy_id for entry in strategies.registry),
            candle_intervals=[interval.value for interval in settings.candle_intervals],
        )
        beating = asyncio.create_task(heartbeat.run(), name="heartbeat")
        try:
            await worker.run()
        finally:
            beating.cancel()
            await asyncio.gather(beating, return_exceptions=True)
    finally:
        await container.close()


def main() -> None:
    settings = get_settings()
    configure_logging(settings.log_level, json_logs=settings.log_json)
    try:
        asyncio.run(serve(settings))
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass  # a requested stop: the runs were already stopped in order
    except Exception:
        log.exception("strategy_worker_failed")
        raise SystemExit(1) from None
    log.info("strategy_worker_stopped")


if __name__ == "__main__":
    main()
