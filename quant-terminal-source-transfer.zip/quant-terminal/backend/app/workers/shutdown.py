"""Process helpers shared by the workers."""

from __future__ import annotations

import asyncio
import signal

from app.core.logging import get_logger

log = get_logger(__name__)


def stop_on_sigterm() -> None:
    """Let SIGTERM (``docker stop``) stop the current task as Ctrl+C does. Windows event loops have no
    signal handlers; Ctrl+C still works there."""
    task = asyncio.current_task()
    if task is None:
        return
    try:
        asyncio.get_running_loop().add_signal_handler(signal.SIGTERM, task.cancel)
    except NotImplementedError:
        log.debug("sigterm_handler_unavailable")
