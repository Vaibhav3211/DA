"""The backtest worker (``qt-backtest-worker``): builds queued datasets and runs queued backtests (M9; see
docs/backtesting.md).

It takes one job at a time, oldest first, and datasets before backtests, since a backtest needs a READY
dataset. While a job runs, the worker refreshes its claim every ``KEEPALIVE_SECONDS``. A job that shows no
progress for ``ABANDONED_AFTER`` (its worker stopped or lost the database) is marked FAILED, so it can be
asked for again. Stopping the worker (Ctrl+C or SIGTERM) abandons the job it is on.
"""

from __future__ import annotations

import asyncio
import os
import socket
from collections.abc import Awaitable, Callable
from datetime import datetime, timedelta
from functools import partial
from typing import Any, Final

from app import __version__
from app.container import Container
from app.core.clock import utc_now
from app.core.config import Settings, get_settings
from app.core.logging import configure_logging, get_logger
from app.observability.heartbeat import BACKTEST_WORKER, HeartbeatPublisher
from app.observability.metrics import serve_worker_metrics
from app.services.backtests import BacktestService
from app.services.datasets import DatasetService
from app.services.markets import MarketCalendarCache
from app.workers.shutdown import stop_on_sigterm

log = get_logger(__name__)

KEEPALIVE_SECONDS: Final = 15.0
ABANDONED_AFTER: Final = timedelta(minutes=5)


class BacktestWorker:
    def __init__(
        self,
        datasets: DatasetService,
        backtests: BacktestService,
        calendars: MarketCalendarCache,
        *,
        worker_id: str,
        poll_seconds: float,
        keepalive_seconds: float = KEEPALIVE_SECONDS,
        clock: Callable[[], datetime] = utc_now,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self.datasets = datasets
        self.backtests = backtests
        self.calendars = calendars
        self.worker_id = worker_id
        self.poll_seconds = poll_seconds
        self.keepalive_seconds = keepalive_seconds
        self.clock = clock
        self.sleep = sleep  # waits between polls (the keepalive always uses asyncio.sleep)
        self.job: str | None = None  # the job in progress, for the heartbeat

    def details(self) -> dict[str, Any]:
        return {"worker_id": self.worker_id, "job": self.job}

    async def run(self) -> None:
        """Process jobs until cancelled. A cycle that fails (e.g. the database is unreachable) is logged
        and tried again after ``poll_seconds``."""
        while True:
            try:
                worked = await self.run_once()
            except Exception:
                log.exception("backtest_worker_cycle_failed")
                worked = False
            if not worked:
                await self.sleep(self.poll_seconds)

    async def run_once(self) -> bool:
        """Fail abandoned jobs, then process the oldest queued dataset, else the oldest queued backtest.
        False when none was waiting."""
        stale_before = self.clock() - ABANDONED_AFTER
        for abandoned in await self.datasets.fail_abandoned(stale_before=stale_before):
            log.warning("backtest_dataset_abandoned", dataset_id=str(abandoned))
        for abandoned in await self.backtests.fail_abandoned(stale_before=stale_before):
            log.warning("backtest_run_abandoned", run_id=str(abandoned))
        calendar, _ = await self.calendars.get()
        dataset_id = await self.datasets.claim_next(self.worker_id)
        if dataset_id is not None:
            log.info("backtest_dataset_claimed", dataset_id=str(dataset_id))
            dataset_status = await self._keeping_alive(
                f"dataset {dataset_id}",
                partial(self.datasets.keep_alive, dataset_id, self.worker_id),
                self.datasets.build_claimed(dataset_id, self.worker_id, calendar),
            )
            log.info("backtest_dataset_finished", dataset_id=str(dataset_id), status=dataset_status.value)
            return True
        run_id = await self.backtests.claim_next(self.worker_id)
        if run_id is None:
            return False
        log.info("backtest_run_claimed", run_id=str(run_id))
        run_status = await self._keeping_alive(
            f"backtest {run_id}",
            partial(self.backtests.keep_alive, run_id, self.worker_id),
            self.backtests.run_claimed(run_id, self.worker_id, calendar),
        )
        log.info("backtest_run_finished", run_id=str(run_id), status=run_status.value)
        return True

    async def _keeping_alive[T](
        self, job: str, touch: Callable[[], Awaitable[bool]], work: Awaitable[T]
    ) -> T:
        """Await ``work`` while refreshing the job's claim every ``keepalive_seconds``."""
        self.job = job
        beating = asyncio.create_task(self._keep_alive(job, touch), name="backtest-keepalive")
        try:
            return await work
        finally:
            beating.cancel()
            await asyncio.gather(beating, return_exceptions=True)
            self.job = None

    async def _keep_alive(self, job: str, touch: Callable[[], Awaitable[bool]]) -> None:
        while True:
            await asyncio.sleep(self.keepalive_seconds)
            try:
                if not await touch():
                    log.warning("backtest_job_claim_lost", job=job)
                    return
            except Exception as exc:  # the next refresh tries again; the job is abandoned after a while
                log.warning("backtest_job_keepalive_failed", job=job, error=type(exc).__name__)


def default_worker_id() -> str:
    """Names this worker process in the jobs it claims."""
    return f"{socket.gethostname()}:{os.getpid()}"[:120]


async def serve(settings: Settings) -> None:
    """Build the worker on a new container and run it until cancelled."""
    stop_on_sigterm()
    container = Container.create(settings)
    try:
        calendars = MarketCalendarCache(container.db, settings)
        worker_id = default_worker_id()
        worker = BacktestWorker(
            DatasetService.from_container(container, calendars),
            BacktestService.from_container(container),
            calendars,
            worker_id=worker_id,
            poll_seconds=settings.backtest_poll_seconds,
        )
        heartbeat = HeartbeatPublisher(container.bus, BACKTEST_WORKER, __version__, details=worker.details)
        serve_worker_metrics(settings.backtest_worker_metrics_port)
        log.info(
            "backtest_worker_started",
            version=__version__,
            app_env=settings.app_env.value,
            worker_id=worker_id,
            strategies=sorted(entry.strategy_id for entry in worker.backtests.registry),
        )
        beating = asyncio.create_task(heartbeat.run(), name="heartbeat")
        try:
            await worker.run()
        finally:
            beating.cancel()
            await asyncio.gather(beating, return_exceptions=True)
    finally:
        await container.close()


def main() -> None:
    settings = get_settings()
    configure_logging(settings.log_level, json_logs=settings.log_json)
    try:
        asyncio.run(serve(settings))
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass  # a requested stop: the job in progress is failed as abandoned later
    except Exception:
        log.exception("backtest_worker_failed")
        raise SystemExit(1) from None
    log.info("backtest_worker_stopped")


if __name__ == "__main__":
    main()
