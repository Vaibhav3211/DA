"""The strategy plugin contract (spec §16).

Strategies are trusted, in-repo plugins run by the strategy worker (ADR-008). A strategy sees market
data only through its ``StrategyContext``: validated configuration, indicator readings, recent closed
candles and instrument reference data. It gets no database, bus, provider client or credentials, and
it can only *propose* signals: the runtime adds identity and provenance, the risk gate decides whether a
proposal may be presented as actionable, and nothing in Phase 1 places orders.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from datetime import datetime
from decimal import Decimal
from typing import ClassVar, Protocol
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict

from app.domain.enums import CandleInterval
from app.domain.models import (
    Candle,
    IndicatorValue,
    Instrument,
    NormalizedMarketEvent,
    SignalCandidate,
    StrategyMetadata,
)
from app.domain.models.backtest import TradeRules


class StrategyConfig(BaseModel):
    """Base class of strategy configuration schemas.

    Unknown keys are rejected and every field needs a default: a new deployment starts from the
    default configuration, which must therefore be valid.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")


class MarketView(Protocol):
    """The read-only market state the runtime keeps for one deployment."""

    @property
    def instrument_ids(self) -> frozenset[UUID]: ...

    def instrument(self, instrument_id: UUID) -> Instrument | None: ...

    def indicator_values(self, instrument_id: UUID, lag: int) -> Mapping[str, IndicatorValue]: ...

    def candles(self, instrument_id: UUID, interval: CandleInterval) -> Sequence[Candle]: ...


class StrategyContext[C: StrategyConfig]:
    """Everything a strategy may see during one run. Read-only."""

    __slots__ = ("_clock", "_config", "_deployment_id", "_log", "_market", "_run_id", "_workspace_id")

    def __init__(
        self,
        *,
        config: C,
        run_id: UUID,
        deployment_id: UUID,
        workspace_id: UUID,
        market: MarketView,
        clock: Callable[[], datetime],
        log: structlog.stdlib.BoundLogger,
    ) -> None:
        self._config = config
        self._run_id = run_id
        self._deployment_id = deployment_id
        self._workspace_id = workspace_id
        self._market = market
        self._clock = clock
        self._log = log

    @property
    def config(self) -> C:
        return self._config

    @property
    def run_id(self) -> UUID:
        return self._run_id

    @property
    def deployment_id(self) -> UUID:
        return self._deployment_id

    @property
    def workspace_id(self) -> UUID:
        return self._workspace_id

    @property
    def log(self) -> structlog.stdlib.BoundLogger:
        """A logger bound to the strategy, deployment and run."""
        return self._log

    def now(self) -> datetime:
        """The current UTC time (a fixed clock in tests)."""
        return self._clock()

    @property
    def instrument_ids(self) -> frozenset[UUID]:
        """The instruments this deployment covers."""
        return self._market.instrument_ids

    def instrument(self, instrument_id: UUID) -> Instrument | None:
        return self._market.instrument(instrument_id)

    def indicators(self, instrument_id: UUID, *, lag: int = 0) -> Mapping[str, IndicatorValue]:
        """Every indicator output by name (``alias`` or ``alias.output``) after the latest closed candle.

        ``lag=1`` gives the readings after the candle before it, e.g. to detect a crossover.
        """
        return self._market.indicator_values(instrument_id, lag)

    def indicator(self, instrument_id: UUID, name: str, *, lag: int = 0) -> IndicatorValue | None:
        return self._market.indicator_values(instrument_id, lag).get(name)

    def value(self, instrument_id: UUID, name: str, *, lag: int = 0) -> Decimal | None:
        """An indicator output's value; ``None`` while it warms up or when it is undefined."""
        reading = self.indicator(instrument_id, name, lag=lag)
        return reading.value if reading is not None else None

    def candles(
        self, instrument_id: UUID, interval: CandleInterval, count: int | None = None
    ) -> Sequence[Candle]:
        """Recent closed candles, oldest first (at most ``count``)."""
        history = self._market.candles(instrument_id, interval)
        if count is None or count >= len(history):
            return history
        return history[len(history) - count :] if count > 0 else ()


class Strategy[C: StrategyConfig]:
    """Base class of strategy plugins.

    Subclasses set ``metadata`` and ``config_model`` and override the hooks they need; the default hooks
    do nothing and propose nothing. One instance serves one deployment run, so instance state is
    private to that run. Hooks must not block: they run on the worker's event loop under a timeout.
    """

    metadata: ClassVar[StrategyMetadata]
    config_model: ClassVar[type[StrategyConfig]] = StrategyConfig
    # Optional default trade rules for backtests; rules saved with a configuration take precedence.
    trade_rules: ClassVar[TradeRules | None] = None

    async def initialize(self, context: StrategyContext[C]) -> None:
        """Called once per run, after indicators are warmed up and before any live data."""

    async def on_candle(self, candle: Candle, context: StrategyContext[C]) -> Sequence[SignalCandidate]:
        """Called for each newly closed candle on ``metadata.candle_intervals`` of an instrument in scope,
        after the deployment's indicators have been updated with it."""
        return ()

    async def on_market_event(
        self, event: NormalizedMarketEvent, context: StrategyContext[C]
    ) -> Sequence[SignalCandidate]:
        """Called for each market event of an instrument in scope when ``metadata.event_types`` is set."""
        return ()

    async def shutdown(self) -> None:
        """Called once when the run stops."""
