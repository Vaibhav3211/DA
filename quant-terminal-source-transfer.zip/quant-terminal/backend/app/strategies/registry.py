"""The strategy catalogue in the code: the examples and your own strategies (``app/strategies/custom``).

Plugins are validated once, when the registry is built, so a broken plugin fails start-up loudly instead
of failing at run time; ``qt strategies check`` runs the same validation on its own. ``config_schema`` and
``default_config`` are what the database catalogue stores and the UI renders; ``fingerprint`` (SHA-256 of
the plugin module's source) ties every run to the code it ran, including edits made without a version
bump. See docs/strategy-registration.md.
"""

from __future__ import annotations

import hashlib
import inspect
import sys
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass
from functools import cache
from types import MappingProxyType
from typing import Any, Final

from pydantic import ValidationError

from app.domain.enums import (
    EXCHANGE_MARKETS,
    CandleInterval,
    DataRequirement,
    Exchange,
    InstrumentType,
    PluginKind,
    Segment,
)
from app.domain.models import StrategyMetadata
from app.domain.models.backtest import TradeRules
from app.domain.models.strategy import CANDLE_INPUTS, EVENT_INPUTS, INPUT_REQUIREMENTS
from app.strategies.base import Strategy, StrategyConfig
from app.strategies.custom import CUSTOM_STRATEGIES
from app.strategies.examples.ema_crossover import EmaCrossover
from app.strategies.indicators import (
    INDICATORS,
    IndicatorConfigError,
    Provenance,
    create_indicator,
    describe_validation,
)

EXAMPLE_STRATEGIES: Final[tuple[type[Strategy[Any]], ...]] = (EmaCrossover,)
BUILTIN_STRATEGIES: Final[tuple[type[Strategy[Any]], ...]] = (*EXAMPLE_STRATEGIES, *CUSTOM_STRATEGIES)
# The runtime loads this many closed candles per series before a run starts.
MAX_WARMUP_CANDLES: Final = 5000
# Data that only market events carry: candles have neither.
EVENT_ONLY_DATA: Final = frozenset({DataRequirement.OPEN_INTEREST, DataRequirement.MARKET_DEPTH})
# Parts of a canonical key by instrument type (see app/market_data/instruments/canonical.py); others: 4.
_KEY_PARTS: Final = {InstrumentType.FUTURE: 5, InstrumentType.OPTION: 7}
_DECLARED_LISTS: Final = (
    "markets",
    "exchanges",
    "segments",
    "instrument_types",
    "instrument_keys",
    "event_types",
    "candle_intervals",
    "required_data",
)


class StrategyRegistrationError(ValueError):
    """A plugin breaks the strategy contract."""


class UnknownStrategyError(LookupError):
    pass


class StrategyConfigError(ValueError):
    """A configuration does not match the strategy's schema."""


@dataclass(frozen=True, slots=True)
class RegisteredStrategy:
    cls: type[Strategy[Any]]
    metadata: StrategyMetadata
    config_schema: Mapping[str, Any]
    default_config: Mapping[str, Any]
    fingerprint: str
    # Closed candles each interval needs: the strategy's warm-up on its candle intervals, and every
    # indicator's warm-up on the indicator's interval.
    warmups: Mapping[CandleInterval, int]
    # Intervals with session-anchored indicators (VWAP, opening range), which need the session so far.
    session_intervals: frozenset[CandleInterval]
    # Data beyond prices it needs: its declarations, its volume indicators and its condition inputs.
    data_requirements: frozenset[DataRequirement]
    # Its default trade rules for backtests, when it declares them.
    trade_rules: TradeRules | None = None

    @property
    def strategy_id(self) -> str:
        return self.metadata.strategy_id

    @property
    def version(self) -> str:
        return self.metadata.version

    @property
    def intervals(self) -> frozenset[CandleInterval]:
        """Every candle interval the strategy or its indicators consume."""
        return frozenset(self.warmups)

    def validate_config(self, raw: Mapping[str, Any]) -> StrategyConfig:
        try:
            return self.cls.config_model.model_validate(dict(raw))
        except ValidationError as exc:
            raise StrategyConfigError(f"{self.strategy_id}: {describe_validation(exc)}") from None

    def create(self) -> Strategy[Any]:
        return self.cls()


def register(cls: type[Strategy[Any]]) -> RegisteredStrategy:
    """Validate one plugin class against the contract."""
    qualified = f"{cls.__module__}.{cls.__qualname__}"
    if not (isinstance(cls, type) and issubclass(cls, Strategy)):
        raise StrategyRegistrationError(f"{qualified} does not subclass Strategy")
    metadata = getattr(cls, "metadata", None)
    if not isinstance(metadata, StrategyMetadata):
        raise StrategyRegistrationError(f"{qualified}.metadata must be a StrategyMetadata")

    problems = _metadata_problems(metadata)
    warmups: dict[CandleInterval, int] = dict.fromkeys(metadata.candle_intervals, metadata.warmup_candles)
    session_intervals: set[CandleInterval] = set()
    # What signal conditions may name: each indicator's alias, and alias.output for its other outputs.
    inputs: set[str] = set()
    for requirement in metadata.indicators:
        inputs.add(requirement.alias)
        try:
            indicator = create_indicator(requirement)
        except IndicatorConfigError as exc:
            problems.append(f"indicator {exc}")
            continue
        inputs.update(f"{requirement.alias}.{output}" for output in indicator.outputs[1:])
        warmups[requirement.interval] = max(warmups.get(requirement.interval, 0), indicator.warmup_candles)
        if indicator.provenance is Provenance.SESSION:
            session_intervals.add(requirement.interval)
    if metadata.candle_intervals:
        inputs |= CANDLE_INPUTS
    if metadata.event_types:
        inputs |= EVENT_INPUTS
    problems.extend(_condition_problems(metadata, inputs))
    needs = data_needs(metadata)
    event_only = sorted(requirement.value for requirement in needs & EVENT_ONLY_DATA)
    if event_only and not metadata.event_types:
        problems.append(f"market events are the only source of {', '.join(event_only)}; declare event types")

    default_config: dict[str, Any] = {}
    config_model: object = getattr(cls, "config_model", None)
    if not (isinstance(config_model, type) and issubclass(config_model, StrategyConfig)):
        problems.append("config_model must subclass StrategyConfig")
    else:
        try:
            default_config = config_model().model_dump(mode="json")
        except ValidationError as exc:
            problems.append(f"every configuration field needs a valid default ({describe_validation(exc)})")
    trade_rules: object = getattr(cls, "trade_rules", None)
    if trade_rules is not None and not isinstance(trade_rules, TradeRules):
        problems.append("trade_rules must be a TradeRules or None")
    if problems:
        raise StrategyRegistrationError(f"{metadata.strategy_id}: {'; '.join(problems)}")

    return RegisteredStrategy(
        cls=cls,
        metadata=metadata,
        config_schema=MappingProxyType(cls.config_model.model_json_schema()),
        default_config=MappingProxyType(default_config),
        fingerprint=_fingerprint(cls, metadata.strategy_id),
        warmups=MappingProxyType(warmups),
        session_intervals=frozenset(session_intervals),
        data_requirements=needs,
        trade_rules=trade_rules if isinstance(trade_rules, TradeRules) else None,
    )


class StrategyRegistry:
    def __init__(self, classes: Iterable[type[Strategy[Any]]]) -> None:
        entries: dict[str, RegisteredStrategy] = {}
        for cls in classes:
            entry = register(cls)
            if entry.strategy_id in entries:
                raise StrategyRegistrationError(f"duplicate strategy id {entry.strategy_id!r}")
            entries[entry.strategy_id] = entry
        self._entries = entries

    def __iter__(self) -> Iterator[RegisteredStrategy]:
        return iter(self._entries.values())

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, strategy_id: object) -> bool:
        return strategy_id in self._entries

    def find(self, strategy_id: str) -> RegisteredStrategy | None:
        return self._entries.get(strategy_id)

    def get(self, strategy_id: str) -> RegisteredStrategy:
        entry = self._entries.get(strategy_id)
        if entry is None:
            raise UnknownStrategyError(f"unknown strategy {strategy_id!r}")
        return entry


@cache
def builtin_registry() -> StrategyRegistry:
    return StrategyRegistry(BUILTIN_STRATEGIES)


def data_needs(metadata: StrategyMetadata) -> frozenset[DataRequirement]:
    """Data beyond prices a strategy needs: what it declares, plus volume for its volume indicators and
    whatever its signal-condition inputs need."""
    needs = set(metadata.required_data)
    if any(
        (cls := INDICATORS.get(requirement.indicator)) is not None and cls.uses_volume
        for requirement in metadata.indicators
    ):
        needs.add(DataRequirement.VOLUME)
    for condition in metadata.signal_conditions:
        needs.update(INPUT_REQUIREMENTS[name] for name in condition.inputs if name in INPUT_REQUIREMENTS)
    return frozenset(needs)


def _metadata_problems(metadata: StrategyMetadata) -> list[str]:
    problems: list[str] = []
    if metadata.kind is not PluginKind.STRATEGY:
        problems.append(f"kind must be {PluginKind.STRATEGY.value}")
    if metadata.uses_partial_candles:
        problems.append("partial (still forming) candles are not supported")
    if not (metadata.markets and metadata.segments and metadata.instrument_types):
        problems.append("supported markets, segments and instrument types must be declared")
    if not (metadata.candle_intervals or metadata.event_types):
        problems.append("neither candle intervals nor event types are declared, so it would never run")
    if metadata.warmup_candles > MAX_WARMUP_CANDLES:
        problems.append(f"warmup_candles must be at most {MAX_WARMUP_CANDLES}")
    aliases = [requirement.alias for requirement in metadata.indicators]
    duplicates = sorted({alias for alias in aliases if aliases.count(alias) > 1})
    if duplicates:
        problems.append(f"duplicate indicator aliases: {', '.join(duplicates)}")
    for name in _DECLARED_LISTS:
        values = [str(value) for value in getattr(metadata, name)]
        repeated = sorted({value for value in values if values.count(value) > 1})
        if repeated:
            problems.append(f"duplicate {name}: {', '.join(repeated)}")
    outside = sorted(
        exchange.value
        for exchange in metadata.exchanges
        if EXCHANGE_MARKETS[exchange] not in metadata.markets
    )
    if outside:
        problems.append(f"exchanges outside the declared markets: {', '.join(outside)}")
    problems.extend(problem for key in metadata.instrument_keys if (problem := _key_problem(metadata, key)))
    return problems


def _key_problem(metadata: StrategyMetadata, key: str) -> str | None:
    """Why a declared instrument key is not a canonical key the strategy's other declarations allow."""
    parts = key.split(":")
    malformed = f"instrument key {key!r} is not a canonical key such as NSE:CASH:EQUITY:INFY"
    try:
        exchange, segment, instrument_type = Exchange(parts[0]), Segment(parts[1]), InstrumentType(parts[2])
    except (IndexError, ValueError):
        return malformed
    if len(parts) != _KEY_PARTS.get(instrument_type, 4) or not all(parts):
        return malformed
    if key != key.strip().upper():
        return f"instrument key {key!r} must be upper-case, as canonical keys are"
    problem = metadata.eligibility_problem(
        market=EXCHANGE_MARKETS[exchange], exchange=exchange, segment=segment, instrument_type=instrument_type
    )
    return f"instrument key {key}: {problem}" if problem else None


def _condition_problems(metadata: StrategyMetadata, inputs: set[str]) -> list[str]:
    """Signal conditions: one per signal type the strategy can propose, naming inputs it has."""
    if not metadata.signal_conditions:
        return ["signal conditions must be declared, one for each signal type it can propose"]
    problems: list[str] = []
    types = [condition.signal_type.value for condition in metadata.signal_conditions]
    repeated = sorted({value for value in types if types.count(value) > 1})
    if repeated:
        problems.append(f"duplicate signal conditions for: {', '.join(repeated)}")
    for condition in metadata.signal_conditions:
        unknown = sorted(set(condition.inputs) - inputs)
        if unknown:
            problems.append(
                f"the {condition.signal_type.value} condition names unknown inputs: {', '.join(unknown)} "
                "(use indicator aliases, candle fields when candle intervals are declared, or market-event "
                "fields when event types are declared)"
            )
    return problems


def _fingerprint(cls: type[Strategy[Any]], strategy_id: str) -> str:
    module = sys.modules.get(cls.__module__)
    try:
        source = inspect.getsource(module) if module is not None else None
    except (OSError, TypeError) as exc:
        raise StrategyRegistrationError(f"{strategy_id}: cannot read the plugin source ({exc})") from None
    if source is None:
        raise StrategyRegistrationError(f"{strategy_id}: cannot read the plugin source (module not loaded)")
    return hashlib.sha256(source.encode()).hexdigest()
