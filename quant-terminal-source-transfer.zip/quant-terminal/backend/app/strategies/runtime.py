"""Strategy runtime (spec §16): what one deployment run sees, and how its plugin is called.

The strategy worker owns the I/O (database, Redis, signal engine); this module holds the run's state and
isolates the plugin:

* ``MarketState`` folds closed candles into each instrument's indicators and recent-candle history. It is
  the ``MarketView`` behind the strategy's context. The worker folds history into it before the run
  starts (warm-up), so the strategy only sees candles that close while it runs.
* ``StrategyRunner`` calls the plugin's hooks under a timeout, checks what they return and turns the
  candidates into signal-engine proposals carrying the market data they were computed from.
* ``CircuitBreaker`` stops calling a plugin that keeps failing and lets one trial call through after a
  pause.

A hook that awaits past its timeout is cancelled. A hook that blocks the event loop cannot be interrupted;
it is detected afterwards (it overran the timeout) and its result is discarded.
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from collections.abc import Awaitable, Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from types import MappingProxyType
from typing import Any, Final
from uuid import UUID

from app.core.clock import utc_now
from app.core.logging import get_logger
from app.domain.enums import CandleInterval, DataStatus, Exchange, Provider
from app.domain.models import Candle, IndicatorValue, Instrument, NormalizedMarketEvent, SignalCandidate
from app.market_data.calendars.service import MarketCalendar
from app.observability.metrics import STRATEGY_CIRCUIT_OPEN, STRATEGY_EVALUATION_SECONDS, STRATEGY_EVALUATIONS
from app.providers.base import describe_error
from app.risk.rules import SourceData
from app.signals.engine import Proposal, RunContext
from app.strategies.base import Strategy, StrategyConfig, StrategyContext
from app.strategies.indicators import Indicator, SessionLookup, SessionRef, create_indicator, utc_sessions
from app.strategies.registry import RegisteredStrategy

log = get_logger(__name__)

MAX_CANDIDATES_PER_CALL: Final = 50
_MAX_LAG: Final = 1

type Trigger = Candle | NormalizedMarketEvent


def calendar_sessions(calendar: MarketCalendar) -> SessionLookup:
    """Session lookup for session-anchored indicators, from the exchange calendar."""

    def lookup(exchange: Exchange, at: datetime) -> SessionRef:
        day = calendar.trading_day_at(exchange, at)
        return SessionRef(day.session_date, day.open_at)

    return lookup


# ---- market state ------------------------------------------------------------------------------------


@dataclass(slots=True)
class _Series:
    """One instrument's closed candles of one interval."""

    indicators: tuple[Indicator[Any], ...]
    warmup: int
    history: deque[Candle] | None  # kept on the strategy's own candle intervals only
    last: Candle | None = None
    folded: int = 0
    snapshot: tuple[Candle, ...] | None = None


class MarketState:
    """Indicators and recent closed candles of every instrument a deployment run covers."""

    def __init__(
        self,
        entry: RegisteredStrategy,
        universe: Iterable[tuple[Instrument, Provider]],
        *,
        sessions: SessionLookup = utc_sessions,
    ) -> None:
        metadata = entry.metadata
        self._instruments: dict[UUID, Instrument] = {}
        self._providers: dict[UUID, Provider] = {}
        for instrument, provider in universe:
            self._instruments[instrument.id] = instrument
            self._providers[instrument.id] = provider
        self._ids = frozenset(self._instruments)
        self._series: dict[tuple[UUID, CandleInterval], _Series] = {}
        self._indicators: dict[UUID, tuple[Indicator[Any], ...]] = {}
        self._latest: dict[UUID, Candle] = {}
        self._readings: dict[UUID, dict[int, Mapping[str, IndicatorValue]]] = {}
        history = max(metadata.warmup_candles, 1)
        for instrument_id in self._instruments:
            created: list[Indicator[Any]] = []
            for interval in sorted(entry.intervals):
                indicators = tuple(
                    create_indicator(requirement, sessions=sessions)
                    for requirement in metadata.indicators
                    if requirement.interval is interval
                )
                created.extend(indicators)
                kept = deque[Candle](maxlen=history) if interval in metadata.candle_intervals else None
                self._series[(instrument_id, interval)] = _Series(indicators, entry.warmups[interval], kept)
            self._indicators[instrument_id] = tuple(created)

    # ---- MarketView ----------------------------------------------------------------------------------

    @property
    def instrument_ids(self) -> frozenset[UUID]:
        return self._ids

    def instrument(self, instrument_id: UUID) -> Instrument | None:
        return self._instruments.get(instrument_id)

    def indicator_values(self, instrument_id: UUID, lag: int) -> Mapping[str, IndicatorValue]:
        if not 0 <= lag <= _MAX_LAG:
            raise ValueError(f"lag must be between 0 and {_MAX_LAG}")
        cached = self._readings.setdefault(instrument_id, {})
        readings = cached.get(lag)
        if readings is None:
            values = {
                value.name: value
                for indicator in self._indicators.get(instrument_id, ())
                for value in indicator.values(lag)
            }
            readings = cached[lag] = MappingProxyType(values)
        return readings

    def candles(self, instrument_id: UUID, interval: CandleInterval) -> Sequence[Candle]:
        series = self._series.get((instrument_id, interval))
        if series is None or series.history is None:
            return ()
        if series.snapshot is None:
            series.snapshot = tuple(series.history)
        return series.snapshot

    # ---- runtime -------------------------------------------------------------------------------------

    def series(self) -> list[tuple[Instrument, Provider, CandleInterval]]:
        """Every (instrument, provider, interval) the run consumes."""
        return [
            (self._instruments[instrument_id], self._providers[instrument_id], interval)
            for instrument_id, interval in self._series
        ]

    def provider(self, instrument_id: UUID) -> Provider | None:
        return self._providers.get(instrument_id)

    def latest(self, instrument_id: UUID) -> Candle | None:
        """The instrument's most recent closed candle on any interval."""
        return self._latest.get(instrument_id)

    def covers(self, provider: Provider, instrument_id: UUID) -> bool:
        return self._providers.get(instrument_id) is provider

    def fold(self, candle: Candle) -> bool:
        """Feed a closed candle. False (and nothing changes) unless it is newer than the last candle of a
        series the run tracks, from the provider the run uses for the instrument."""
        if not candle.is_closed or not self.covers(candle.provider, candle.instrument_id):
            return False
        series = self._series.get((candle.instrument_id, candle.interval))
        if series is None or (series.last is not None and candle.bucket_start <= series.last.bucket_start):
            return False
        for indicator in series.indicators:
            indicator.update(candle)
        if series.history is not None:
            series.history.append(candle)
            series.snapshot = None
        series.last = candle
        series.folded += 1
        latest = self._latest.get(candle.instrument_id)
        if latest is None or candle.bucket_end >= latest.bucket_end:
            self._latest[candle.instrument_id] = candle
        self._readings.pop(candle.instrument_id, None)
        return True

    def warming(self) -> int:
        """How many instruments still have fewer candles than their warm-up on some interval."""
        return self.warmup().instruments

    def warmup(self) -> WarmupProgress:
        short: set[UUID] = set()
        remaining: dict[CandleInterval, int] = {}
        for (instrument_id, interval), series in self._series.items():
            missing = series.warmup - series.folded
            if missing > 0:
                short.add(instrument_id)
                remaining[interval] = max(remaining.get(interval, 0), missing)
        return WarmupProgress(len(short), MappingProxyType(remaining))


@dataclass(frozen=True, slots=True)
class WarmupProgress:
    """The instruments still short of their warm-up on some interval and, per interval, the most closed
    candles any of them still needs."""

    instruments: int
    remaining: Mapping[CandleInterval, int]


# ---- isolation -------------------------------------------------------------------------------------


class CircuitBreaker:
    """Stops calls after ``threshold`` consecutive failures. After ``reset_seconds`` one trial call goes
    through: success closes the circuit, failure keeps it open for another ``reset_seconds``."""

    def __init__(
        self, threshold: int, reset_seconds: float, *, monotonic: Callable[[], float] = time.monotonic
    ) -> None:
        self._threshold = max(threshold, 1)
        self._reset_seconds = reset_seconds
        self._monotonic = monotonic
        self._failures = 0
        self._opened_at: float | None = None

    @property
    def is_open(self) -> bool:
        return self._opened_at is not None

    def allow(self) -> bool:
        return self._opened_at is None or self._monotonic() - self._opened_at >= self._reset_seconds

    def success(self) -> bool:
        """Record a successful call; True when it closes the circuit."""
        closed = self._opened_at is not None
        self._failures = 0
        self._opened_at = None
        return closed

    def failure(self) -> bool:
        """Record a failed call; True when it opens the circuit."""
        self._failures += 1
        if self._opened_at is not None:  # the trial call failed
            self._opened_at = self._monotonic()
            return False
        if self._failures < self._threshold:
            return False
        self._opened_at = self._monotonic()
        return True


@dataclass(slots=True)
class RunStats:
    candles: int = 0  # closed candles the strategy was called with (or skipped while the circuit was open)
    events: int = 0
    signals: int = 0  # set by the worker: proposals the gate allowed
    failures: int = 0
    timeouts: int = 0
    last_error: str | None = None
    circuit_opened_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class _Result:
    value: object = None
    error: str | None = None
    timed_out: bool = False
    elapsed: float = 0.0


class _ContractError(Exception):
    pass


class StrategyRunner:
    """The plugin instance of one deployment run, called under a timeout and a circuit breaker."""

    def __init__(
        self,
        entry: RegisteredStrategy,
        run: RunContext,
        config: StrategyConfig,
        market: MarketState,
        *,
        timeout_seconds: float,
        breaker: CircuitBreaker,
        clock: Callable[[], datetime] = utc_now,
        monotonic: Callable[[], float] = time.monotonic,
        record_metrics: bool = True,
    ) -> None:
        self.entry = entry
        self.run = run
        self.market = market
        self.stats = RunStats()
        self._timeout = timeout_seconds
        self._breaker = breaker
        self._clock = clock
        self._monotonic = monotonic
        # Off for backtests, which replay history rather than evaluate live data.
        self._metrics = record_metrics
        self._candle_intervals = frozenset(entry.metadata.candle_intervals)
        self._event_types = frozenset(entry.metadata.event_types)
        self._counted = False  # whether the open circuit is counted in STRATEGY_CIRCUIT_OPEN
        self._stopped = False
        self._log = log.bind(
            strategy_id=entry.strategy_id, deployment_id=str(run.deployment_id), run_id=str(run.run_id)
        )
        self._strategy: Strategy[Any] = entry.create()
        self._context: StrategyContext[Any] = StrategyContext(
            config=config,
            run_id=run.run_id,
            deployment_id=run.deployment_id,
            workspace_id=run.workspace_id,
            market=market,
            clock=clock,
            log=self._log,
        )

    @property
    def circuit_open(self) -> bool:
        return self._breaker.is_open

    async def initialize(self) -> str | None:
        """Call the plugin's ``initialize`` hook; returns why it failed, or None."""
        result = await self._call(lambda: self._strategy.initialize(self._context))
        problem = self._problem("initialize", result)
        if problem is not None:
            self.stats.last_error = problem
        return problem

    def fold(self, candle: Candle) -> bool:
        """Feed a live closed candle to the market state; True when the strategy should be called."""
        return self.market.fold(candle) and candle.interval in self._candle_intervals

    async def on_candle(self, candle: Candle) -> list[Proposal]:
        """Call the strategy with a candle ``fold`` accepted."""
        self.stats.candles += 1
        return await self._evaluate(
            "on_candle", lambda: self._strategy.on_candle(candle, self._context), candle
        )

    def wants(self, event: NormalizedMarketEvent) -> bool:
        return event.event_type in self._event_types and self.market.covers(
            event.provider, event.instrument_id
        )

    async def on_event(self, event: NormalizedMarketEvent) -> list[Proposal]:
        """Call the strategy with a market event ``wants`` accepted."""
        self.stats.events += 1
        return await self._evaluate(
            "on_market_event", lambda: self._strategy.on_market_event(event, self._context), event
        )

    async def shutdown(self) -> None:
        """Call the plugin's ``shutdown`` hook once; a failure is logged."""
        if self._stopped:
            return
        self._stopped = True
        problem = self._problem("shutdown", await self._call(self._strategy.shutdown))
        if problem is not None:
            self._log.warning("strategy_shutdown_failed", error=problem)
        if self._counted:
            STRATEGY_CIRCUIT_OPEN.labels(strategy=self.entry.strategy_id).dec()
            self._counted = False

    # ---- internals -------------------------------------------------------------------------------------

    async def _call(self, call: Callable[[], Awaitable[object]]) -> _Result:
        started = self._monotonic()
        scope = asyncio.timeout(self._timeout)
        try:
            async with scope:
                value = await call()
        except Exception as exc:  # plugin code: a bug must only affect its own run
            elapsed = self._monotonic() - started
            if scope.expired():
                return _Result(timed_out=True, elapsed=elapsed)
            return _Result(error=describe_error(exc), elapsed=elapsed)
        elapsed = self._monotonic() - started
        if elapsed > self._timeout:  # it blocked the event loop, so the timeout could not interrupt it
            return _Result(timed_out=True, elapsed=elapsed)
        return _Result(value, elapsed=elapsed)

    def _problem(self, hook: str, result: _Result) -> str | None:
        if result.timed_out:
            return f"{hook} timed out after {self._timeout:g}s"
        if result.error is not None:
            return f"{hook} raised {result.error}"
        return None

    async def _evaluate(
        self, hook: str, call: Callable[[], Awaitable[object]], trigger: Trigger
    ) -> list[Proposal]:
        if not self._breaker.allow():
            self._count("skipped_circuit_open")
            return []
        result = await self._call(call)
        if self._metrics:
            STRATEGY_EVALUATION_SECONDS.labels(strategy=self.entry.strategy_id).observe(result.elapsed)
        problem = self._problem(hook, result)
        if problem is None:
            try:
                proposals = self._proposals(result.value, trigger)
            except _ContractError as exc:
                problem = f"{hook} broke the contract: {exc}"
            else:
                self._count("ok")
                if self._breaker.success():
                    self._circuit_closed()
                return proposals
        self._count("timeout" if result.timed_out else "error")
        if result.timed_out:
            self.stats.timeouts += 1
        else:
            self.stats.failures += 1
        self.stats.last_error = problem
        self._log.warning("strategy_hook_failed", hook=hook, error=problem)
        if self._breaker.failure():
            self._circuit_opened()
        return []

    def _count(self, outcome: str) -> None:
        if self._metrics:
            STRATEGY_EVALUATIONS.labels(strategy=self.entry.strategy_id, outcome=outcome).inc()

    def _circuit_opened(self) -> None:
        self.stats.circuit_opened_at = self._clock()
        if self._metrics and not self._counted:
            STRATEGY_CIRCUIT_OPEN.labels(strategy=self.entry.strategy_id).inc()
            self._counted = True
        self._log.error("strategy_circuit_opened", last_error=self.stats.last_error)

    def _circuit_closed(self) -> None:
        self.stats.circuit_opened_at = None
        if self._counted:
            STRATEGY_CIRCUIT_OPEN.labels(strategy=self.entry.strategy_id).dec()
            self._counted = False
        self._log.info("strategy_circuit_closed")

    def _proposals(self, value: object, trigger: Trigger) -> list[Proposal]:
        if isinstance(value, str | bytes) or not isinstance(value, Sequence):
            raise _ContractError(f"returned {type(value).__name__}, not a sequence of SignalCandidate")
        if len(value) > MAX_CANDIDATES_PER_CALL:
            raise _ContractError(f"proposed {len(value)} candidates; the limit is {MAX_CANDIDATES_PER_CALL}")
        proposals: list[Proposal] = []
        declared = self.entry.metadata.signal_types
        for candidate in value:
            if not isinstance(candidate, SignalCandidate):
                raise _ContractError(f"returned a {type(candidate).__name__}, not a SignalCandidate")
            if candidate.signal_type not in declared:
                raise _ContractError(
                    f"proposed a {candidate.signal_type.value} signal without declaring a condition for it"
                )
            instrument = self.market.instrument(candidate.instrument_id)
            if instrument is None:
                raise _ContractError(
                    f"proposed instrument {candidate.instrument_id}, which it does not cover"
                )
            proposals.append(self._proposal(candidate, instrument, trigger))
        return proposals

    def _proposal(self, candidate: SignalCandidate, instrument: Instrument, trigger: Trigger) -> Proposal:
        """Attach the market data the candidate was computed from: the trigger when it is about the same
        instrument, otherwise the instrument's latest closed candle."""
        if trigger.instrument_id == instrument.id and isinstance(trigger, NormalizedMarketEvent):
            return Proposal(candidate, instrument, SourceData.from_event(trigger), trigger.account_id)
        source = trigger if isinstance(trigger, Candle) and trigger.instrument_id == instrument.id else None
        source = source or self.market.latest(instrument.id)
        if source is None:
            provider = self.market.provider(instrument.id)
            assert provider is not None  # the instrument is covered
            return Proposal(candidate, instrument, SourceData(provider, DataStatus.UNKNOWN, None))
        if candidate.source_candle_interval is None and candidate.source_candle_start is None:
            candidate = candidate.model_copy(
                update={"source_candle_interval": source.interval, "source_candle_start": source.bucket_start}
            )
        return Proposal(candidate, instrument, SourceData.from_candle(source), source.account_id)
