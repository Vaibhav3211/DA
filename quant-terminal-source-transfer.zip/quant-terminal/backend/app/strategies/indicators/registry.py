"""Indicator catalogue: names that strategies use in their ``IndicatorRequirement``s."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Final

from pydantic import ValidationError

from app.domain.models import IndicatorRequirement
from app.strategies.indicators.base import (
    Indicator,
    IndicatorConfigError,
    SessionLookup,
    utc_sessions,
)
from app.strategies.indicators.oscillators import Rsi
from app.strategies.indicators.session import OpeningRange
from app.strategies.indicators.trend import EmaIndicator, Macd, Sma, Supertrend
from app.strategies.indicators.volatility import Atr, AtrPercent, Bollinger, ReturnsStdev
from app.strategies.indicators.volume import RelativeVolume, VolumeSma, Vwap

INDICATORS: Final[Mapping[str, type[Indicator[Any]]]] = {
    cls.name: cls
    for cls in (
        Sma,
        EmaIndicator,
        Rsi,
        Macd,
        Vwap,
        Atr,
        AtrPercent,
        Bollinger,
        Supertrend,
        VolumeSma,
        RelativeVolume,
        ReturnsStdev,
        OpeningRange,
    )
}


def create_indicator(
    requirement: IndicatorRequirement, *, sessions: SessionLookup = utc_sessions
) -> Indicator[Any]:
    """Build the indicator a requirement asks for; raises ``IndicatorConfigError`` if it is invalid."""
    cls = INDICATORS.get(requirement.indicator)
    if cls is None:
        known = ", ".join(sorted(INDICATORS))
        raise IndicatorConfigError(
            f"{requirement.alias}: unknown indicator {requirement.indicator!r} (known: {known})"
        )
    try:
        params = cls.params_model.model_validate(requirement.params)
    except ValidationError as exc:
        raise IndicatorConfigError(f"{requirement.alias}: {describe_validation(exc)}") from None
    try:
        return cls(requirement.alias, requirement.interval, params, sessions=sessions)
    except IndicatorConfigError as exc:
        raise IndicatorConfigError(f"{requirement.alias}: {exc}") from None


def describe_validation(exc: ValidationError) -> str:
    """One line per invalid field, without echoing the rejected input values."""
    parts = []
    for error in exc.errors():
        location = ".".join(str(part) for part in error["loc"])
        parts.append(f"{location}: {error['msg']}" if location else str(error["msg"]))
    return "; ".join(parts)
