"""Volatility indicators: ATR, ATR as a percentage of price, Bollinger Bands, return dispersion."""

from __future__ import annotations

from collections import deque
from decimal import Decimal

from pydantic import Field

from app.domain.models import Candle
from app.strategies.indicators.base import (
    MAX_PERIOD,
    Indicator,
    IndicatorParams,
    PeriodParams,
    Provenance,
    Rma,
    RollingWindow,
    SourceParams,
    TrueRange,
    candle_price,
    population_stdev,
)

_HUNDRED = Decimal(100)


class Atr(Indicator[PeriodParams]):
    """Average true range (Pine ``ta.atr``): Wilder average of the true range, seeded with the simple
    average of the first ``period``; the first candle's true range is its high-low range."""

    name = "atr"
    version = "1.0"
    params_model = PeriodParams
    provenance = Provenance.RECURSIVE
    description = "Average true range (Wilder)."

    def _setup(self) -> None:
        self._true_range = TrueRange()
        self._atr = Rma(self.params.period)
        self._close: Decimal | None = None

    @property
    def warmup_candles(self) -> int:
        return self.params.period

    def _apply(self, candle: Candle) -> None:
        self._atr.push(self._true_range.push(candle))
        self._close = candle.close_price

    def _outputs(self) -> dict[str, Decimal | None]:
        return {"value": self._atr.value}


class AtrPercent(Atr):
    name = "atr_percent"
    version = "1.0"
    description = "Average true range as a percentage of the latest close."

    def _outputs(self) -> dict[str, Decimal | None]:
        atr, close = self._atr.value, self._close
        if atr is None or close is None or close <= 0:
            return {"value": None}
        return {"value": atr / close * _HUNDRED}


class BollingerParams(SourceParams):
    period: int = Field(default=20, ge=1, le=MAX_PERIOD)
    multiplier: Decimal = Field(default=Decimal(2), gt=0, le=100)


class Bollinger(Indicator[BollingerParams]):
    """Bollinger Bands (Pine ``ta.bb``): SMA middle band, bands at ``multiplier`` population
    standard deviations; bandwidth is (upper - lower) / middle, percent_b where the latest price
    sits between the bands (0 = lower, 1 = upper)."""

    name = "bollinger"
    version = "1.0"
    params_model = BollingerParams
    outputs = ("middle", "upper", "lower", "bandwidth", "percent_b")
    description = "Bollinger Bands: SMA middle, upper/lower at k standard deviations, bandwidth, %B."

    def _setup(self) -> None:
        self._window = RollingWindow(self.params.period)
        self._last: Decimal | None = None

    @property
    def warmup_candles(self) -> int:
        return self.params.period

    def _apply(self, candle: Candle) -> None:
        self._last = candle_price(candle, self.params.source)
        self._window.push(self._last)

    def _outputs(self) -> dict[str, Decimal | None]:
        middle = self._window.mean()
        if middle is None or self._last is None:
            return dict.fromkeys(self.outputs)
        deviation = self.params.multiplier * population_stdev(self._window.items, middle)
        upper, lower = middle + deviation, middle - deviation
        return {
            "middle": middle,
            "upper": upper,
            "lower": lower,
            "bandwidth": (upper - lower) / middle if middle != 0 else None,
            "percent_b": (self._last - lower) / (upper - lower) if upper != lower else None,
        }


class ReturnsStdevParams(IndicatorParams):
    period: int = Field(default=20, ge=2, le=MAX_PERIOD)


class ReturnsStdev(Indicator[ReturnsStdevParams]):
    """Sample standard deviation (n - 1) of the last ``period`` close-to-close log returns, as a
    fraction per candle (not annualised)."""

    name = "returns_stdev"
    version = "1.0"
    params_model = ReturnsStdevParams
    description = "Standard deviation of close-to-close log returns (per candle, not annualised)."

    def _setup(self) -> None:
        self._returns: deque[Decimal | None] = deque(maxlen=self.params.period)
        self._previous: Decimal | None = None

    @property
    def warmup_candles(self) -> int:
        return self.params.period + 1

    def _apply(self, candle: Candle) -> None:
        close = candle.close_price
        if self._previous is not None:
            valid = close > 0 and self._previous > 0
            self._returns.append((close / self._previous).ln() if valid else None)
        self._previous = close

    def _outputs(self) -> dict[str, Decimal | None]:
        returns = [r for r in self._returns if r is not None]
        if len(returns) < self.params.period:
            return {"value": None}
        mean = sum(returns, Decimal(0)) / len(returns)
        variance = sum(((r - mean) ** 2 for r in returns), Decimal(0)) / (len(returns) - 1)
        return {"value": variance.sqrt()}
