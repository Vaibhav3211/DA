"""Trend indicators: simple and exponential moving averages, MACD and Supertrend."""

from __future__ import annotations

from decimal import Decimal
from typing import Self

from pydantic import Field, model_validator

from app.domain.models import Candle
from app.strategies.indicators.base import (
    MAX_PERIOD,
    Ema,
    Indicator,
    IndicatorParams,
    PriceSource,
    Provenance,
    Rma,
    RollingWindow,
    SourceParams,
    TrueRange,
    candle_price,
)


class Sma(Indicator[SourceParams]):
    name = "sma"
    version = "1.0"
    params_model = SourceParams
    description = "Simple moving average of the last `period` prices."

    def _setup(self) -> None:
        self._window = RollingWindow(self.params.period)

    @property
    def warmup_candles(self) -> int:
        return self.params.period

    def _apply(self, candle: Candle) -> None:
        self._window.push(candle_price(candle, self.params.source))

    def _outputs(self) -> dict[str, Decimal | None]:
        return {"value": self._window.mean()}


class EmaIndicator(Indicator[SourceParams]):
    name = "ema"
    version = "1.0"
    params_model = SourceParams
    provenance = Provenance.RECURSIVE
    description = (
        "Exponential moving average (alpha 2/(period+1)), seeded with the SMA of the first `period`."
    )

    def _setup(self) -> None:
        self._ema = Ema(self.params.period)

    @property
    def warmup_candles(self) -> int:
        return self.params.period

    def _apply(self, candle: Candle) -> None:
        self._ema.push(candle_price(candle, self.params.source))

    def _outputs(self) -> dict[str, Decimal | None]:
        return {"value": self._ema.value}


class MacdParams(IndicatorParams):
    fast: int = Field(default=12, ge=1, le=MAX_PERIOD)
    slow: int = Field(default=26, ge=2, le=MAX_PERIOD)
    signal: int = Field(default=9, ge=1, le=MAX_PERIOD)
    source: PriceSource = PriceSource.CLOSE

    @model_validator(mode="after")
    def _fast_before_slow(self) -> Self:
        if self.fast >= self.slow:
            raise ValueError("fast must be shorter than slow")
        return self


class Macd(Indicator[MacdParams]):
    name = "macd"
    version = "1.0"
    params_model = MacdParams
    outputs = ("macd", "signal", "histogram")
    provenance = Provenance.RECURSIVE
    description = "EMA(fast) - EMA(slow), its EMA(signal) and the difference of the two (histogram)."

    def _setup(self) -> None:
        self._fast = Ema(self.params.fast)
        self._slow = Ema(self.params.slow)
        self._signal = Ema(self.params.signal)
        self._macd: Decimal | None = None

    @property
    def warmup_candles(self) -> int:
        return self.params.slow + self.params.signal - 1

    def _apply(self, candle: Candle) -> None:
        price = candle_price(candle, self.params.source)
        fast = self._fast.push(price)
        slow = self._slow.push(price)
        if fast is not None and slow is not None:
            self._macd = fast - slow
            self._signal.push(self._macd)

    def _outputs(self) -> dict[str, Decimal | None]:
        macd, signal = self._macd, self._signal.value
        histogram = macd - signal if macd is not None and signal is not None else None
        return {"macd": macd, "signal": signal, "histogram": histogram}


class SupertrendParams(IndicatorParams):
    period: int = Field(default=10, ge=1, le=MAX_PERIOD)
    multiplier: Decimal = Field(default=Decimal(3), gt=0, le=100)


class Supertrend(Indicator[SupertrendParams]):
    """Pine ``ta.supertrend`` on hl2 with a Wilder ATR, except that ``direction`` is +1 in an uptrend
    (the line is the lower band) and -1 in a downtrend (the line is the upper band); Pine reports
    the opposite sign. The first bar with an ATR starts in a downtrend with the basic bands."""

    name = "supertrend"
    version = "1.0"
    params_model = SupertrendParams
    outputs = ("supertrend", "direction", "upper", "lower")
    provenance = Provenance.RECURSIVE
    description = "ATR trailing-band trend line on hl2; direction +1 (up) or -1 (down)."

    def _setup(self) -> None:
        self._true_range = TrueRange()
        self._atr = Rma(self.params.period)
        self._previous_close: Decimal | None = None
        self._upper: Decimal | None = None
        self._lower: Decimal | None = None
        self._line: Decimal | None = None
        self._direction = 0

    @property
    def warmup_candles(self) -> int:
        return self.params.period

    def _apply(self, candle: Candle) -> None:
        had_atr = self._atr.value is not None
        atr = self._atr.push(self._true_range.push(candle))
        previous_close, self._previous_close = self._previous_close, candle.close_price
        if atr is None:
            return
        middle = (candle.high_price + candle.low_price) / 2
        upper = middle + self.params.multiplier * atr
        lower = middle - self.params.multiplier * atr
        if self._upper is not None and self._lower is not None and previous_close is not None:
            if not (lower > self._lower or previous_close < self._lower):
                lower = self._lower
            if not (upper < self._upper or previous_close > self._upper):
                upper = self._upper
        close = candle.close_price
        if not had_atr:
            direction = -1
        elif self._line == self._upper:
            direction = 1 if close > upper else -1
        else:
            direction = -1 if close < lower else 1
        self._upper, self._lower, self._direction = upper, lower, direction
        self._line = lower if direction == 1 else upper

    def _outputs(self) -> dict[str, Decimal | None]:
        return {
            "supertrend": self._line,
            "direction": Decimal(self._direction) if self._line is not None else None,
            "upper": self._upper,
            "lower": self._lower,
        }
