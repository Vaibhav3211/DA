"""Session indicators: the opening range and its breakout levels."""

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal

from pydantic import Field

from app.domain.enums import CandleFlag, DataStatus
from app.domain.models import Candle
from app.strategies.indicators.base import (
    Indicator,
    IndicatorConfigError,
    IndicatorParams,
    Provenance,
    SessionRef,
    Span,
)

_HUNDRED = Decimal(100)


class OpeningRangeParams(IndicatorParams):
    minutes: int = Field(default=15, ge=1, le=480)
    buffer_percent: Decimal = Field(default=Decimal(0), ge=0, le=10)


class OpeningRange(Indicator[OpeningRangeParams]):
    """High and low of the candles in the first ``minutes`` of the session, with breakout levels
    ``buffer_percent`` beyond them.

    Values appear once the range window is over and stay for the session. They are ``None`` when the
    session's opening time is unknown, or when the window's first candle is missing or started late
    (the range would be incomplete). ``minutes`` must be a whole number of candle intervals.
    """

    name = "opening_range"
    version = "1.0"
    params_model = OpeningRangeParams
    outputs = ("high", "low", "breakout_up", "breakout_down", "width")
    provenance = Provenance.SESSION
    description = "Opening-range high/low over the first `minutes` of the session, with breakout levels."

    def _setup(self) -> None:
        seconds = self.params.minutes * 60
        if seconds % self.interval.seconds:
            raise IndicatorConfigError(
                f"opening_range minutes ({self.params.minutes}) must be a whole number of "
                f"{self.interval.value} candles"
            )
        self._window = timedelta(seconds=seconds)
        self._range = Span()
        self._reset()

    def _reset(self) -> None:
        self._open_at: datetime | None = None
        self._window_end: datetime | None = None
        self._high: Decimal | None = None
        self._low: Decimal | None = None
        self._complete = False
        self._valid = False
        self._range.reset()

    @property
    def warmup_candles(self) -> int:
        return self.params.minutes * 60 // self.interval.seconds

    def _start_session(self, session: SessionRef) -> None:
        self._reset()
        if session.open_at is not None:
            self._open_at = session.open_at
            self._window_end = session.open_at + self._window

    def _apply(self, candle: Candle) -> None:
        if self._complete or self._open_at is None or self._window_end is None:
            return
        if candle.bucket_start < self._open_at:
            return  # before the open (pre-open or outside the session)
        if candle.bucket_end > self._window_end:
            self._complete = True  # the window is over
            return
        if self._range.count == 0:
            self._valid = (
                candle.bucket_start == self._open_at and CandleFlag.PARTIAL_START not in candle.flags
            )
        self._range.add(candle)
        self._high = candle.high_price if self._high is None else max(self._high, candle.high_price)
        self._low = candle.low_price if self._low is None else min(self._low, candle.low_price)
        if candle.bucket_end == self._window_end:
            self._complete = True

    def _outputs(self) -> dict[str, Decimal | None]:
        high, low = self._high, self._low
        if not (self._complete and self._valid) or high is None or low is None:
            return dict.fromkeys(self.outputs)
        buffer = self.params.buffer_percent / _HUNDRED
        return {
            "high": high,
            "low": low,
            "breakout_up": high * (1 + buffer),
            "breakout_down": low * (1 - buffer),
            "width": high - low,
        }

    def _provenance(self) -> tuple[datetime | None, datetime | None, int, DataStatus]:
        status = self._range.worst if self._range.worst is not None else DataStatus.UNKNOWN
        return self._range.first_start, self._range.last_end, self._range.count, status
