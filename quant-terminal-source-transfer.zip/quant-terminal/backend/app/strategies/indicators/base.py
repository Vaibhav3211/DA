"""Incremental indicator engine.

An indicator consumes the *closed* candles of one instrument and interval, oldest first, and updates
its state in constant or window-sized time per candle instead of recomputing the history. Forming
candles, other intervals and candles that are not newer than the last one are ignored.

Every reading carries its provenance: the indicator name and version, its parameters, the range and
count of input candles, and the worst data status among the candles it depends on, so a value
derived from delayed, stale or simulated data is labelled as such. Until an indicator has enough
input (its warm-up), or when an input it needs is missing (such as volume), its value is ``None``,
never zero.

Calculation semantics follow the TradingView (Pine) definitions unless an indicator says otherwise;
``version`` changes whenever an indicator's semantics change.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections import deque
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any, ClassVar, Final

from pydantic import BaseModel, ConfigDict, Field

from app.domain.enums import CandleInterval, DataStatus, Exchange, worst_status
from app.domain.models import Candle, IndicatorValue

MAX_PERIOD: Final = 1000
# Readings are rounded to this many places when they have more (internal state keeps full precision).
_OUTPUT_QUANTUM: Final = Decimal("1E-10")
_OUTPUT_EXPONENT: Final = -10
_HISTORY: Final = 2  # readings kept: the current one and the previous one (``lag=1``)


class IndicatorConfigError(ValueError):
    """An indicator requirement names an unknown indicator or has invalid parameters."""


class PriceSource(StrEnum):
    OPEN = "open"
    HIGH = "high"
    LOW = "low"
    CLOSE = "close"
    HL2 = "hl2"
    HLC3 = "hlc3"
    OHLC4 = "ohlc4"


def candle_price(candle: Candle, source: PriceSource) -> Decimal:
    match source:
        case PriceSource.OPEN:
            return candle.open_price
        case PriceSource.HIGH:
            return candle.high_price
        case PriceSource.LOW:
            return candle.low_price
        case PriceSource.CLOSE:
            return candle.close_price
        case PriceSource.HL2:
            return (candle.high_price + candle.low_price) / 2
        case PriceSource.HLC3:
            return (candle.high_price + candle.low_price + candle.close_price) / 3
        case PriceSource.OHLC4:
            return (candle.open_price + candle.high_price + candle.low_price + candle.close_price) / 4


class IndicatorParams(BaseModel):
    """Base of indicator parameter models; unknown parameters are rejected."""

    model_config = ConfigDict(frozen=True, extra="forbid")


class PeriodParams(IndicatorParams):
    period: int = Field(default=14, ge=1, le=MAX_PERIOD)


class SourceParams(PeriodParams):
    source: PriceSource = PriceSource.CLOSE


@dataclass(frozen=True, slots=True)
class SessionRef:
    """The trading session a candle belongs to."""

    day: date
    open_at: datetime | None = None  # UTC; None when the session hours are unknown


type SessionLookup = Callable[[Exchange, datetime], SessionRef]


def utc_sessions(exchange: Exchange, at: datetime) -> SessionRef:
    """Fallback session lookup: UTC calendar days, opening time unknown."""
    del exchange
    return SessionRef(at.astimezone(UTC).date())


class Provenance(StrEnum):
    """Which input candles a reading depends on."""

    # A sliding window of the last N candles (SMA, Bollinger Bands).
    WINDOW = "WINDOW"
    # Every candle since the indicator started, with decaying weight (EMA, RSI, ATR): the range covers
    # all of them, the data status the most recent ``status_window`` candles.
    RECURSIVE = "RECURSIVE"
    # Every candle of the current session with full weight (VWAP).
    SESSION = "SESSION"


class _Trail:
    """Bounds and data statuses of the last ``size`` input candles."""

    __slots__ = ("_counts", "_items", "_size")

    def __init__(self, size: int) -> None:
        self._size = size
        self._items: deque[tuple[datetime, datetime, DataStatus]] = deque()
        self._counts: dict[DataStatus, int] = {}

    def add(self, candle: Candle) -> None:
        if len(self._items) == self._size:
            _, _, old = self._items.popleft()
            remaining = self._counts[old] - 1
            if remaining:
                self._counts[old] = remaining
            else:
                del self._counts[old]
        self._items.append((candle.bucket_start, candle.bucket_end, candle.data_status))
        self._counts[candle.data_status] = self._counts.get(candle.data_status, 0) + 1

    def clear(self) -> None:
        self._items.clear()
        self._counts.clear()

    @property
    def count(self) -> int:
        return len(self._items)

    @property
    def first_start(self) -> datetime | None:
        return self._items[0][0] if self._items else None

    @property
    def last_end(self) -> datetime | None:
        return self._items[-1][1] if self._items else None

    def worst(self) -> DataStatus:
        return worst_status(*self._counts)


class Span:
    """Bounds, count and worst data status of every input candle since the last reset."""

    __slots__ = ("count", "first_start", "last_end", "worst")

    def __init__(self) -> None:
        self.first_start: datetime | None = None
        self.last_end: datetime | None = None
        self.count = 0
        self.worst: DataStatus | None = None

    def add(self, candle: Candle) -> None:
        if self.first_start is None:
            self.first_start = candle.bucket_start
        self.last_end = candle.bucket_end
        self.count += 1
        self.worst = (
            candle.data_status if self.worst is None else worst_status(self.worst, candle.data_status)
        )

    def reset(self) -> None:
        self.first_start = None
        self.last_end = None
        self.count = 0
        self.worst = None


@dataclass(frozen=True, slots=True)
class _Reading:
    outputs: Mapping[str, Decimal | None]
    input_from: datetime | None
    input_to: datetime | None
    input_count: int
    data_status: DataStatus


class Indicator[P: IndicatorParams](ABC):
    """An incremental indicator over closed candles of one instrument and interval.

    Subclasses declare ``name``, ``version``, ``params_model``, ``outputs`` (the first is the primary
    output, reported under the requirement's alias; the others as ``alias.output``),
    ``provenance`` and ``uses_volume``, and implement ``warmup_candles``, ``_apply`` and ``_outputs``.
    """

    name: ClassVar[str]
    version: ClassVar[str]
    params_model: ClassVar[type[IndicatorParams]]
    outputs: ClassVar[tuple[str, ...]] = ("value",)
    provenance: ClassVar[Provenance] = Provenance.WINDOW
    description: ClassVar[str] = ""
    # Reads candle volume, so a strategy using it needs a feed that reports volume.
    uses_volume: ClassVar[bool] = False

    def __init__(
        self,
        alias: str,
        interval: CandleInterval,
        params: P,
        *,
        sessions: SessionLookup = utc_sessions,
    ) -> None:
        self.alias = alias
        self.interval = interval
        self.params = params
        self._sessions = sessions
        self._params_json: dict[str, Any] = params.model_dump(mode="json")
        self._trail = _Trail(self.status_window)
        self._span = Span()
        self._last_start: datetime | None = None
        self._session: SessionRef | None = None
        self._readings: deque[_Reading] = deque(maxlen=_HISTORY)
        self._built: dict[int, tuple[IndicatorValue, ...]] = {}
        self._setup()

    # ---- subclass contract ---------------------------------------------------------------------------

    @abstractmethod
    def _setup(self) -> None:
        """Create the calculation state (``self.params`` is set); may raise ``IndicatorConfigError``."""

    @property
    @abstractmethod
    def warmup_candles(self) -> int:
        """Closed candles needed before every output can have a value."""

    @property
    def status_window(self) -> int:
        """How many recent candles the data status (and a WINDOW range) covers."""
        return self.warmup_candles

    @abstractmethod
    def _apply(self, candle: Candle) -> None:
        """Fold one new closed candle into the state."""

    @abstractmethod
    def _outputs(self) -> dict[str, Decimal | None]:
        """Current value of every output (``None`` while warming up or when inputs are missing)."""

    def _start_session(self, session: SessionRef) -> None:  # noqa: B027 - optional hook
        """Called before the first candle of a new session (SESSION indicators only)."""

    def _provenance(self) -> tuple[datetime | None, datetime | None, int, DataStatus]:
        """Input range, input count and data status of the current reading."""
        if self.provenance is Provenance.WINDOW:
            return self._trail.first_start, self._trail.last_end, self._trail.count, self._trail.worst()
        status = self._trail.worst()
        if self.provenance is Provenance.SESSION and self._span.worst is not None:
            status = self._span.worst
        return self._span.first_start, self._span.last_end, self._span.count, status

    # ---- public API ------------------------------------------------------------------------------------

    @property
    def session(self) -> SessionRef | None:
        return self._session

    def update(self, candle: Candle) -> bool:
        """Feed one candle. Returns False (and changes nothing) unless it is a newer closed candle
        of this indicator's interval."""
        if not candle.is_closed or candle.interval is not self.interval:
            return False
        if self._last_start is not None and candle.bucket_start <= self._last_start:
            return False
        self._last_start = candle.bucket_start
        if self.provenance is Provenance.SESSION:
            session = self._sessions(candle.exchange, candle.bucket_start)
            if self._session is None or session.day != self._session.day:
                self._session = session
                self._span.reset()
                self._trail.clear()
                self._start_session(session)
        self._trail.add(candle)
        self._span.add(candle)
        self._apply(candle)
        input_from, input_to, count, status = self._provenance()
        self._readings.append(_Reading(self._outputs(), input_from, input_to, count, status))
        self._built.clear()
        return True

    @property
    def ready(self) -> bool:
        """Whether every output currently has a value."""
        return bool(self._readings) and all(v is not None for v in self._readings[-1].outputs.values())

    def values(self, lag: int = 0) -> tuple[IndicatorValue, ...]:
        """Readings of every output after the latest candle (``lag=1``: the one before)."""
        if not 0 <= lag < _HISTORY:
            raise ValueError(f"lag must be between 0 and {_HISTORY - 1}")
        built = self._built.get(lag)
        if built is None:
            index = len(self._readings) - 1 - lag
            reading = self._readings[index] if index >= 0 else None
            built = self._built[lag] = self._build(reading)
        return built

    def output_name(self, output: str) -> str:
        return self.alias if output == self.outputs[0] else f"{self.alias}.{output}"

    # ---- internals -------------------------------------------------------------------------------------

    def _build(self, reading: _Reading | None) -> tuple[IndicatorValue, ...]:
        return tuple(
            IndicatorValue(
                name=self.output_name(output),
                indicator=self.name,
                version=self.version,
                params=self._params_json,
                value=_rounded(reading.outputs.get(output)) if reading is not None else None,
                interval=self.interval,
                input_from=reading.input_from if reading is not None else None,
                input_to=reading.input_to if reading is not None else None,
                input_count=reading.input_count if reading is not None else 0,
                data_status=reading.data_status if reading is not None else DataStatus.UNKNOWN,
            )
            for output in self.outputs
        )


def _rounded(value: Decimal | None) -> Decimal | None:
    if value is None:
        return None
    exponent = value.as_tuple().exponent
    if isinstance(exponent, int) and exponent < _OUTPUT_EXPONENT:
        return value.quantize(_OUTPUT_QUANTUM)
    return value


# ---- reusable smoothing state ----------------------------------------------------------------------------


class Ema:
    """Exponential moving average, ``alpha = 2 / (period + 1)``, seeded with the simple average of
    the first ``period`` inputs (Pine ``ta.ema``)."""

    __slots__ = ("_alpha", "_count", "_seed", "period", "value")

    def __init__(self, period: int) -> None:
        self.period = period
        self._alpha = Decimal(2) / (period + 1)
        self._seed = Decimal(0)
        self._count = 0
        self.value: Decimal | None = None

    def push(self, x: Decimal) -> Decimal | None:
        if self.value is None:
            self._seed += x
            self._count += 1
            if self._count == self.period:
                self.value = self._seed / self.period
        else:
            self.value += self._alpha * (x - self.value)
        return self.value


class Rma:
    """Wilder's moving average, ``alpha = 1 / period``, seeded with the simple average of the first
    ``period`` inputs (Pine ``ta.rma``)."""

    __slots__ = ("_count", "_seed", "period", "value")

    def __init__(self, period: int) -> None:
        self.period = period
        self._seed = Decimal(0)
        self._count = 0
        self.value: Decimal | None = None

    def push(self, x: Decimal) -> Decimal | None:
        if self.value is None:
            self._seed += x
            self._count += 1
            if self._count == self.period:
                self.value = self._seed / self.period
        else:
            self.value = (self.value * (self.period - 1) + x) / self.period
        return self.value


class RollingWindow:
    """The last ``size`` values with their exact running sum."""

    __slots__ = ("_items", "size", "total")

    def __init__(self, size: int) -> None:
        self.size = size
        self._items: deque[Decimal] = deque()
        self.total = Decimal(0)

    def push(self, x: Decimal) -> None:
        if len(self._items) == self.size:
            self.total -= self._items.popleft()
        self._items.append(x)
        self.total += x

    @property
    def full(self) -> bool:
        return len(self._items) == self.size

    @property
    def items(self) -> deque[Decimal]:
        return self._items

    def mean(self) -> Decimal | None:
        return self.total / self.size if self.full else None


class TrueRange:
    """True range of each candle; the first candle's is its high-low range (Pine ``ta.tr(true)``)."""

    __slots__ = ("_previous_close",)

    def __init__(self) -> None:
        self._previous_close: Decimal | None = None

    def push(self, candle: Candle) -> Decimal:
        high, low, previous = candle.high_price, candle.low_price, self._previous_close
        self._previous_close = candle.close_price
        if previous is None:
            return high - low
        return max(high - low, abs(high - previous), abs(low - previous))


def population_stdev(values: deque[Decimal] | list[Decimal], mean: Decimal) -> Decimal:
    variance = sum(((x - mean) ** 2 for x in values), Decimal(0)) / len(values)
    return variance.sqrt()
