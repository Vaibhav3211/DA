"""Volume indicators: session VWAP, average volume and relative volume.

A candle without volume (the provider does not report it, or a reliable delta could not be derived)
makes the reading ``None`` while it is in the indicator's input, never zero.
"""

from __future__ import annotations

from collections import deque
from decimal import Decimal

from pydantic import Field

from app.domain.models import Candle
from app.strategies.indicators.base import (
    MAX_PERIOD,
    Indicator,
    IndicatorParams,
    PeriodParams,
    PriceSource,
    Provenance,
    SessionRef,
    candle_price,
)


class VwapParams(IndicatorParams):
    source: PriceSource = PriceSource.HLC3


class Vwap(Indicator[VwapParams]):
    """Volume-weighted average price anchored at the session (Pine ``ta.vwap``). It starts from the
    first candle observed in the session: ``input_from`` shows where, so a late start is visible."""

    name = "vwap"
    version = "1.0"
    params_model = VwapParams
    provenance = Provenance.SESSION
    uses_volume = True
    description = "Session-anchored volume-weighted average price (typical price hlc3 by default)."

    def _setup(self) -> None:
        self._weighted = Decimal(0)
        self._volume = 0
        self._missing_volume = False

    @property
    def warmup_candles(self) -> int:
        return 1

    def _start_session(self, session: SessionRef) -> None:
        del session
        self._weighted = Decimal(0)
        self._volume = 0
        self._missing_volume = False

    def _apply(self, candle: Candle) -> None:
        if candle.volume is None:
            self._missing_volume = True
            return
        self._weighted += candle_price(candle, self.params.source) * candle.volume
        self._volume += candle.volume

    def _outputs(self) -> dict[str, Decimal | None]:
        if self._missing_volume or self._volume <= 0:
            return {"value": None}
        return {"value": self._weighted / self._volume}


class VolumeSma(Indicator[PeriodParams]):
    name = "volume_sma"
    version = "1.0"
    params_model = PeriodParams
    uses_volume = True
    description = "Average volume of the last `period` candles."

    def _setup(self) -> None:
        self._volumes: deque[int | None] = deque(maxlen=self.params.period)

    @property
    def warmup_candles(self) -> int:
        return self.params.period

    def _apply(self, candle: Candle) -> None:
        self._volumes.append(candle.volume)

    def _outputs(self) -> dict[str, Decimal | None]:
        volumes = [v for v in self._volumes if v is not None]
        if len(volumes) < self.params.period:
            return {"value": None}
        return {"value": Decimal(sum(volumes)) / self.params.period}


class RelativeVolumeParams(IndicatorParams):
    period: int = Field(default=20, ge=1, le=MAX_PERIOD)


class RelativeVolume(Indicator[RelativeVolumeParams]):
    name = "relative_volume"
    version = "1.0"
    params_model = RelativeVolumeParams
    uses_volume = True
    description = "Latest candle's volume divided by the average volume of the `period` candles before it."

    def _setup(self) -> None:
        self._volumes: deque[int | None] = deque(maxlen=self.params.period + 1)

    @property
    def warmup_candles(self) -> int:
        return self.params.period + 1

    def _apply(self, candle: Candle) -> None:
        self._volumes.append(candle.volume)

    def _outputs(self) -> dict[str, Decimal | None]:
        volumes = [v for v in self._volumes if v is not None]
        if len(volumes) <= self.params.period:
            return {"value": None}
        average = Decimal(sum(volumes[:-1])) / self.params.period
        if average <= 0:
            return {"value": None}
        return {"value": volumes[-1] / average}
