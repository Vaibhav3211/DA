"""Oscillators: relative strength index."""

from __future__ import annotations

from decimal import Decimal

from app.domain.models import Candle
from app.strategies.indicators.base import Indicator, Provenance, Rma, SourceParams, candle_price

_ZERO = Decimal(0)
_HUNDRED = Decimal(100)


class Rsi(Indicator[SourceParams]):
    """Wilder's RSI (Pine ``ta.rsi``): Wilder averages of gains and losses seeded with the simple
    averages of the first ``period`` changes; 100 when there were no losses, 0 when no gains."""

    name = "rsi"
    version = "1.0"
    params_model = SourceParams
    provenance = Provenance.RECURSIVE
    description = "Relative strength index (Wilder), 0-100."

    def _setup(self) -> None:
        self._gains = Rma(self.params.period)
        self._losses = Rma(self.params.period)
        self._previous: Decimal | None = None

    @property
    def warmup_candles(self) -> int:
        return self.params.period + 1

    def _apply(self, candle: Candle) -> None:
        price = candle_price(candle, self.params.source)
        if self._previous is not None:
            change = price - self._previous
            self._gains.push(max(change, _ZERO))
            self._losses.push(max(-change, _ZERO))
        self._previous = price

    def _outputs(self) -> dict[str, Decimal | None]:
        gain, loss = self._gains.value, self._losses.value
        if gain is None or loss is None:
            return {"value": None}
        if loss == 0:
            return {"value": _HUNDRED}
        if gain == 0:
            return {"value": _ZERO}
        return {"value": _HUNDRED - _HUNDRED / (1 + gain / loss)}
