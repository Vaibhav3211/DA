"""Your own strategies.

Put each strategy in a module of this package, import its class here and list it in
``CUSTOM_STRATEGIES``. ``qt strategies check`` validates every declaration without starting anything.
Then restart the API and the strategy worker so both load the new code: the strategy worker adds it to
the catalogue when it starts (``qt strategies sync`` and the Strategies page's "Sync catalogue" button do
the same), and it appears in the strategy panel. The step-by-step guide, with a template, is
docs/strategy-registration.md.

Strategies here are trusted code (ADR-008): they run inside the strategy worker with its permissions,
so the plugin rules in tests/unit/test_architecture.py apply to them as to the examples.
"""

from __future__ import annotations

from typing import Any, Final

from app.strategies.base import Strategy

CUSTOM_STRATEGIES: Final[tuple[type[Strategy[Any]], ...]] = ()
