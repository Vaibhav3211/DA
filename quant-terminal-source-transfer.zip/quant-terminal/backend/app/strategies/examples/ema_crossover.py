"""Example strategy: EMA crossover with an ATR stop-loss and target.

FOR INTEGRATION TESTING ONLY. It exercises the plugin contract end to end (indicators, configuration,
actionable proposals, the risk gate and the signal lifecycle). It is not a trading idea: it has no
demonstrated edge, was never validated, and ships disabled.

Rule, on each closed 1-minute candle: when EMA(9) crosses above EMA(21) propose BUY, when it crosses
below propose SELL. The reference entry is the candle's close; the stop-loss and target sit a configured
multiple of ATR(14) away from it, rounded to the instrument's tick size. No score is reported: the
strategy has no calibrated or otherwise documented measure of strength.
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import ROUND_HALF_UP, Decimal
from typing import Final

from pydantic import Field

from app.domain.enums import CandleInterval, InstrumentType, MarketRegion, Segment, SignalType
from app.domain.models import (
    Candle,
    IndicatorRequirement,
    SignalCandidate,
    SignalCondition,
    StrategyMetadata,
    TargetLevel,
)
from app.strategies.base import Strategy, StrategyConfig, StrategyContext

FAST: Final = 9
SLOW: Final = 21
ATR: Final = 14
INTERVAL: Final = CandleInterval.M1


class EmaCrossoverConfig(StrategyConfig):
    stop_atr_multiple: Decimal = Field(
        default=Decimal("1.5"), gt=0, le=10, description="Stop-loss distance from the close, in ATRs."
    )
    target_atr_multiple: Decimal = Field(
        default=Decimal(3), gt=0, le=20, description="Target distance from the close, in ATRs."
    )
    valid_for_minutes: int = Field(
        default=15, ge=1, le=375, description="How long a signal stays valid if nothing updates it."
    )


class EmaCrossover(Strategy[EmaCrossoverConfig]):
    metadata = StrategyMetadata(
        strategy_id="example.ema_crossover",
        name="EMA crossover (example)",
        description=(
            f"Integration-test example. Proposes BUY when EMA({FAST}) crosses above EMA({SLOW}) on closed "
            f"1-minute candles and SELL when it crosses below, with an ATR({ATR}) stop-loss and target. "
            "Not a trading recommendation."
        ),
        version="1.1.0",
        author="Quant Terminal",
        markets=(MarketRegion.INDIA, MarketRegion.LAB),
        segments=(Segment.CASH,),
        instrument_types=(InstrumentType.EQUITY,),
        candle_intervals=(INTERVAL,),
        indicators=(
            IndicatorRequirement(alias="fast", indicator="ema", interval=INTERVAL, params={"period": FAST}),
            IndicatorRequirement(alias="slow", indicator="ema", interval=INTERVAL, params={"period": SLOW}),
            IndicatorRequirement(alias="atr", indicator="atr", interval=INTERVAL, params={"period": ATR}),
        ),
        # Three slow periods, so the EMAs have converged from their seed before the first signal.
        warmup_candles=3 * SLOW,
        signal_conditions=(
            SignalCondition(
                signal_type=SignalType.BUY,
                description=(
                    f"On a closed {INTERVAL.value} candle, EMA({FAST}) is above EMA({SLOW}) after being "
                    "at or below it on the previous candle. Entry: the close. Stop-loss "
                    f"stop_atr_multiple x ATR({ATR}) below the entry, target target_atr_multiple x ATR "
                    "above it, both rounded to the tick size."
                ),
                inputs=("fast", "slow", "atr", "close"),
            ),
            SignalCondition(
                signal_type=SignalType.SELL,
                description=(
                    f"On a closed {INTERVAL.value} candle, EMA({FAST}) is below EMA({SLOW}) after being "
                    "at or above it on the previous candle. Entry: the close. Stop-loss "
                    f"stop_atr_multiple x ATR({ATR}) above the entry, target target_atr_multiple x ATR "
                    "below it, both rounded to the tick size."
                ),
                inputs=("fast", "slow", "atr", "close"),
            ),
        ),
        resource_profile="light",
        risk_profile="example only; every proposal carries a stop-loss",
        can_emit_actionable=True,
        is_example=True,
    )
    config_model = EmaCrossoverConfig

    async def on_candle(
        self, candle: Candle, context: StrategyContext[EmaCrossoverConfig]
    ) -> Sequence[SignalCandidate]:
        instrument_id = candle.instrument_id
        fast, slow, atr = (context.value(instrument_id, name) for name in ("fast", "slow", "atr"))
        prev_fast, prev_slow = (context.value(instrument_id, name, lag=1) for name in ("fast", "slow"))
        if fast is None or slow is None or atr is None or prev_fast is None or prev_slow is None:
            return ()
        if prev_fast <= prev_slow and fast > slow:
            signal_type, direction, side = SignalType.BUY, 1, "above"
        elif prev_fast >= prev_slow and fast < slow:
            signal_type, direction, side = SignalType.SELL, -1, "below"
        else:
            return ()

        config = context.config
        instrument = context.instrument(instrument_id)
        tick = instrument.tick_size if instrument is not None else None
        entry = candle.close_price
        stop = _to_tick(entry - direction * config.stop_atr_multiple * atr, tick)
        target = _to_tick(entry + direction * config.target_atr_multiple * atr, tick)
        if stop <= 0 or target <= 0 or stop == entry or target == entry:
            return ()  # ATR too small for the tick size, or too large for the price

        opposite = "below" if direction == 1 else "above"
        readings = tuple(
            reading
            for name in ("fast", "slow", "atr")
            if (reading := context.indicator(instrument_id, name)) is not None
        )
        return (
            SignalCandidate(
                instrument_id=instrument_id,
                signal_type=signal_type,
                reasons=(
                    f"EMA({FAST}) {fast} crossed {side} EMA({SLOW}) {slow} "
                    f"(previous candle: {prev_fast} vs {prev_slow})",
                    f"ATR({ATR}) {atr}: stop-loss {config.stop_atr_multiple} ATR and target "
                    f"{config.target_atr_multiple} ATR from the close",
                ),
                explanation=(
                    f"EMA({FAST}) crossed {side} EMA({SLOW}) on the {INTERVAL.value} candle that closed at "
                    f"{entry} ({candle.bucket_end:%H:%M} UTC). Reference entry {entry}, stop-loss {stop}, "
                    f"target {target}. Example strategy for integration testing; not a recommendation."
                ),
                entry_price=entry,
                stop_loss=stop,
                targets=(TargetLevel(label="T1", price=target),),
                indicator_values=readings,
                invalidation_conditions=(
                    f"price trades {opposite} the stop-loss {stop}",
                    f"EMA({FAST}) crosses back {opposite} EMA({SLOW})",
                    f"no update within {config.valid_for_minutes} minutes",
                ),
                valid_for_seconds=config.valid_for_minutes * 60,
                source_event_time=candle.last_event_at,
                source_candle_interval=candle.interval,
                source_candle_start=candle.bucket_start,
            ),
        )


def _to_tick(price: Decimal, tick: Decimal | None) -> Decimal:
    if tick is None or tick <= 0:
        return price
    rounded = (price / tick).to_integral_value(rounding=ROUND_HALF_UP) * tick
    # Keep only the tick's own decimal places: a tick read from the database carries the column's zeros.
    exponent = tick.normalize().as_tuple().exponent
    return rounded.quantize(Decimal(1).scaleb(min(exponent, 0))) if isinstance(exponent, int) else rounded
