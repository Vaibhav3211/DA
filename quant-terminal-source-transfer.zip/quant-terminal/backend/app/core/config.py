"""Typed application settings loaded from environment variables / `.env`."""

from __future__ import annotations

from enum import StrEnum
from functools import lru_cache
from pathlib import Path
from typing import Annotated, Any, Final

from pydantic import Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

from app.domain.enums import CandleInterval

# backend/.env for a source checkout, so `qt`, the API and workers find it from any working
# directory. A `.env` in the working directory (if present) overrides it; real environment
# variables override both. Installed (non-editable) packages simply never find this file.
_BACKEND_ENV_FILE = Path(__file__).resolve().parents[2] / ".env"
# Candle intervals built live unless CANDLE_INTERVALS says otherwise (1s is opt-in: it multiplies Redis
# and database writes).
DEFAULT_CANDLE_INTERVALS: Final = (
    CandleInterval.M1,
    CandleInterval.M3,
    CandleInterval.M5,
    CandleInterval.M15,
    CandleInterval.M30,
    CandleInterval.H1,
    CandleInterval.D1,
)


class AppEnv(StrEnum):
    DEVELOPMENT = "development"
    LIVE_DATA = "live_data"
    REPLAY = "replay"
    PRODUCTION = "production"


class CandleAnchor(StrEnum):
    """Where intraday buckets start: at the session open (1h: 09:15-10:15, 10:15-11:15, ...) or on
    the exchange-local clock (1h: 09:15-10:00, 10:00-11:00, ...; clipped to the session)."""

    SESSION = "session"
    CLOCK = "clock"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(_BACKEND_ENV_FILE, ".env"),
        env_file_encoding="utf-8",
        # `KEY=` placeholders in .env files mean "not set", so defaults (often None) apply.
        env_ignore_empty=True,
        extra="ignore",
    )

    app_env: AppEnv = AppEnv.DEVELOPMENT
    app_name: str = "quant-terminal"
    api_v1_prefix: str = "/api/v1"
    api_host: str = "127.0.0.1"
    api_port: int = 8000
    log_level: str = "INFO"
    log_json: bool = True

    # Infrastructure. DATABASE_URL has no default on purpose: credentials never live in code.
    database_url: SecretStr
    database_pool_size: int = 10
    database_echo: bool = False
    redis_url: SecretStr = SecretStr("redis://localhost:6379/0")

    # Security
    encryption_key: SecretStr | None = None
    encryption_previous_keys: SecretStr | None = None
    session_cookie_name: str = "qt_session"
    session_ttl_seconds: int = 12 * 3600
    cookie_secure: bool = False
    allowed_origins: Annotated[list[str], NoDecode] = Field(default_factory=lambda: ["http://localhost:3000"])
    public_base_url: str = "http://localhost:8000"
    frontend_base_url: str = "http://localhost:3000"
    login_rate_limit_per_minute: int = 10

    # Zerodha Kite Connect (values come from the environment; never commit them)
    zerodha_api_key: SecretStr | None = None
    zerodha_api_secret: SecretStr | None = None
    zerodha_redirect_url: str | None = None
    zerodha_login_url: str = "https://kite.zerodha.com/connect/login"
    zerodha_api_base_url: str = "https://api.kite.trade"
    zerodha_ws_url: str = "wss://ws.kite.trade"

    # Groww Trading API
    groww_api_key: SecretStr | None = None
    groww_api_secret: SecretStr | None = None
    groww_api_base_url: str = "https://api.groww.in/v1"
    groww_socket_url: str = "wss://socket-api.groww.in"
    groww_instruments_url: str = "https://growwapi-assets.groww.in/instruments/instrument.csv"
    # Groww documents `volume` in the LTP feed without defining it. Keep false (candles carry no
    # volume) until verified live that it is cumulative day volume.
    groww_feed_volume_is_cumulative: bool = False
    instrument_cache_dir: str = "var/instruments"

    # Feature flags. Live and execution flags are disabled by default.
    market_data_enabled: bool = False
    live_signals_enabled: bool = False
    order_execution_enabled: bool = False
    simulator_enabled: bool = False
    tick_persistence_enabled: bool = False

    # Development simulator (synthetic prices, always labelled SIMULATED). A seed makes the price
    # path reproducible; without one every run differs.
    simulator_tick_interval_seconds: float = Field(default=0.5, gt=0, allow_inf_nan=False)
    simulator_seed: int | None = None

    # Feed quality thresholds
    feed_heartbeat_timeout_seconds: float = 10.0
    data_delayed_latency_seconds: float = 2.0
    data_stale_after_seconds: float = 30.0
    feed_status_publish_interval_seconds: float = 1.0
    # During market hours, a socket that stays "connected" but delivers no ticks for this long is
    # treated as dead and reconnected (works around silently-stalled provider sockets).
    feed_tick_silence_reconnect_seconds: float = 120.0
    market_event_retention_days: int = 7

    # Provider reconnect policy
    reconnect_initial_delay_seconds: float = 1.0
    reconnect_max_delay_seconds: float = 60.0
    reconnect_max_attempts: int = 0  # 0 = retry forever

    # Pipeline sizing
    provider_queue_size: int = 20_000
    redis_stream_maxlen: int = 200_000
    candle_lateness_seconds: float = 2.0
    candle_partial_publish_interval_seconds: float = 1.0
    candle_flush_interval_seconds: float = 2.0
    # Forming candles are saved this often so a crashed worker can resume them (0 = only on shutdown).
    candle_checkpoint_interval_seconds: float = Field(default=60.0, ge=0, allow_inf_nan=False)

    # Market-data worker (M3)
    # Ticks whose exchange/provider timestamp is further ahead of the local receive time are
    # rejected as invalid (persistent rejections usually mean this machine's clock is off: check NTP).
    event_max_future_seconds: float = Field(default=30.0, gt=0, allow_inf_nan=False)
    # Candle intervals built live (see DEFAULT_CANDLE_INTERVALS).
    candle_intervals: Annotated[list[CandleInterval], NoDecode] = Field(
        default_factory=lambda: list(DEFAULT_CANDLE_INTERVALS)
    )
    candle_anchor: CandleAnchor = CandleAnchor.SESSION
    # Workspace instruments and enabled accounts are re-read this often (commands also trigger it).
    subscription_reconcile_interval_seconds: float = Field(default=30.0, gt=0, allow_inf_nan=False)
    quote_cache_ttl_seconds: int = Field(default=7 * 24 * 3600, gt=0)
    # Prometheus endpoint of the market-data worker on 127.0.0.1 (0 disables it).
    market_data_worker_metrics_port: int = Field(default=0, ge=0, le=65535)
    # Past the published exchange_calendars holiday list, assume regular weekday hours (reported as
    # unverified) instead of an unknown session. Health warns this many days before coverage ends.
    calendar_extend_beyond_coverage: bool = True
    calendar_coverage_warning_days: int = Field(default=30, ge=0)
    calendar_reload_interval_seconds: float = Field(default=300.0, gt=0, allow_inf_nan=False)

    # WebSocket gateway
    ws_max_updates_per_second: float = 4.0
    ws_client_queue_size: int = 500
    ws_slow_client_drop_limit: int = 2_000
    ws_heartbeat_interval_seconds: float = 15.0

    # Strategy runtime
    # A strategy hook that runs longer is cancelled (or, if it blocked the event loop, its result dropped).
    strategy_timeout_seconds: float = Field(default=0.5, gt=0, allow_inf_nan=False)
    # Consecutive failed calls that open a deployment's circuit, and the pause before a trial call; a
    # run that fails to start is retried after this pause, doubling up to an hour.
    strategy_failure_threshold: int = Field(default=5, ge=1)
    strategy_circuit_reset_seconds: float = Field(default=60.0, gt=0, allow_inf_nan=False)
    # Deployments are re-read this often (a RELOAD_DEPLOYMENTS command triggers it at once).
    deployment_refresh_seconds: float = Field(default=10.0, gt=0, allow_inf_nan=False)
    signal_default_validity_seconds: int = Field(default=15 * 60, gt=0)
    # Prometheus endpoint of the strategy worker on 127.0.0.1 (0 disables it).
    strategy_worker_metrics_port: int = Field(default=0, ge=0, le=65535)

    # Backtests and historical datasets (M9), processed by the backtest worker
    # The most candles one dataset may hold, and so the most one backtest replays.
    backtest_max_candles: int = Field(default=250_000, ge=1, le=5_000_000)
    # A backtest still running after this long fails (the strategy's per-call timeout still applies).
    backtest_max_seconds: float = Field(default=600.0, gt=0, allow_inf_nan=False)
    # How often an idle backtest worker looks for queued datasets and backtests.
    backtest_poll_seconds: float = Field(default=2.0, gt=0, allow_inf_nan=False)
    # Prometheus endpoint of the backtest worker on 127.0.0.1 (0 disables it).
    backtest_worker_metrics_port: int = Field(default=0, ge=0, le=65535)

    @field_validator("allowed_origins", mode="before")
    @classmethod
    def _split_origins(cls, value: Any) -> Any:
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        return value

    @field_validator("candle_intervals", mode="before")
    @classmethod
    def _split_intervals(cls, value: Any) -> Any:
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        return value

    @field_validator("candle_intervals")
    @classmethod
    def _order_intervals(cls, value: list[CandleInterval]) -> list[CandleInterval]:
        if not value:
            raise ValueError("CANDLE_INTERVALS needs at least one interval")
        return sorted(set(value), key=lambda interval: interval.seconds)

    @model_validator(mode="after")
    def _guard_modes(self) -> Settings:
        if self.order_execution_enabled:
            raise ValueError(
                "ORDER_EXECUTION_ENABLED must be false: order execution is not implemented "
                "(Phase 3 requires separate approval)."
            )
        if self.simulator_enabled and self.app_env not in (AppEnv.DEVELOPMENT, AppEnv.REPLAY):
            raise ValueError("SIMULATOR_ENABLED is only allowed when APP_ENV is development or replay.")
        if self.market_data_enabled and self.app_env is AppEnv.REPLAY:
            raise ValueError(
                "MARKET_DATA_ENABLED must be false when APP_ENV is replay: replay mode never streams "
                "live market data."
            )
        if self.app_env is AppEnv.PRODUCTION:
            if not self.cookie_secure:
                raise ValueError("COOKIE_SECURE must be true in production.")
            if self.encryption_key is None:
                raise ValueError("ENCRYPTION_KEY is required in production (load it from a secret manager).")
        return self

    @property
    def is_simulated_mode(self) -> bool:
        return self.app_env in (AppEnv.DEVELOPMENT, AppEnv.REPLAY) and self.simulator_enabled


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()  # values come from the environment / .env
