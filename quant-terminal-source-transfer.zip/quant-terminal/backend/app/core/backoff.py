"""Bounded exponential backoff with jitter."""

from __future__ import annotations

import random
from collections.abc import Callable


class ExponentialBackoff:
    """Equal-jitter exponential backoff: each delay is uniform in ``[cap/2, cap]``.

    ``cap = min(maximum, initial * multiplier**attempt)``. Equal jitter spreads reconnect storms
    across clients while guaranteeing a minimum wait, unlike full jitter which can return ~0.
    """

    def __init__(
        self,
        initial: float = 1.0,
        maximum: float = 60.0,
        multiplier: float = 2.0,
        *,
        max_attempts: int = 0,
        rng: Callable[[], float] = random.random,
    ) -> None:
        if initial <= 0 or maximum < initial or multiplier < 1:
            raise ValueError("invalid backoff parameters")
        self._initial = initial
        self._maximum = maximum
        self._multiplier = multiplier
        self._max_attempts = max_attempts
        self._rng = rng
        self._attempt = 0

    @property
    def attempts(self) -> int:
        return self._attempt

    @property
    def exhausted(self) -> bool:
        return self._max_attempts > 0 and self._attempt >= self._max_attempts

    def next_delay(self) -> float:
        cap = min(self._maximum, self._initial * (self._multiplier**self._attempt))
        self._attempt += 1
        half = cap / 2.0
        return half + self._rng() * half

    def reset(self) -> None:
        self._attempt = 0
