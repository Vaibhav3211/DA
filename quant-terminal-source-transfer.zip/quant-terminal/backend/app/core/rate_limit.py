"""Async rate limiting for provider REST calls (multiple sliding windows per limiter)."""

from __future__ import annotations

import asyncio
import time
from collections import deque
from collections.abc import Callable, Sequence


class SlidingWindowRateLimiter:
    """Allows at most ``limit`` acquisitions per ``window_seconds`` for every configured window.

    Example: Groww live-data limits are 10/second and 300/minute → ``[(10, 1.0), (300, 60.0)]``.
    Waiting callers are served in FIFO order.
    """

    def __init__(
        self,
        windows: Sequence[tuple[int, float]],
        *,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if not windows or any(limit <= 0 or seconds <= 0 for limit, seconds in windows):
            raise ValueError("rate limiter windows must be positive")
        self._windows = [(limit, seconds, deque[float]()) for limit, seconds in windows]
        self._clock = clock
        self._lock = asyncio.Lock()

    def _wait_time(self, now: float) -> float:
        wait = 0.0
        for limit, seconds, stamps in self._windows:
            while stamps and now - stamps[0] >= seconds:
                stamps.popleft()
            if len(stamps) >= limit:
                wait = max(wait, seconds - (now - stamps[0]))
        return wait

    async def acquire(self) -> None:
        async with self._lock:
            while True:
                now = self._clock()
                wait = self._wait_time(now)
                if wait <= 0:
                    for _limit, _seconds, stamps in self._windows:
                        stamps.append(now)
                    return
                await asyncio.sleep(wait)

    async def __aenter__(self) -> SlidingWindowRateLimiter:
        await self.acquire()
        return self

    async def __aexit__(self, *_exc: object) -> None:
        return None
