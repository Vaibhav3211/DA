"""Time helpers. All persisted and exchanged timestamps are timezone-aware UTC."""

from __future__ import annotations

from datetime import UTC, datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")


def utc_now() -> datetime:
    return datetime.now(UTC)


def ensure_utc(value: datetime) -> datetime:
    """Normalize an aware datetime to UTC. Naive datetimes are rejected, never guessed."""
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("naive datetime is not allowed; provide a timezone-aware value")
    return value.astimezone(UTC)


def from_epoch_seconds(seconds: int | float) -> datetime:
    return datetime.fromtimestamp(seconds, tz=UTC)


def from_epoch_millis(millis: int | float) -> datetime:
    return datetime.fromtimestamp(millis / 1000.0, tz=UTC)
