"""Structured JSON logging with secret redaction and rate limiting."""

from __future__ import annotations

import logging
import re
import sys
import time
from collections.abc import Mapping, MutableMapping
from typing import Any, TextIO

import structlog

REDACTED = "***REDACTED***"

_SENSITIVE_KEY = re.compile(
    r"(secret|password|passwd|authorization|cookie|totp|checksum|api[_-]?key|access[_-]?token|"
    r"request[_-]?token|refresh[_-]?token|public[_-]?token|enctoken|session[_-]?token|"
    r"encryption[_-]?key|credential|private[_-]?key|nkey|seed|^token$|^jwt$)",
    re.IGNORECASE,
)
_SENSITIVE_QUERY = re.compile(
    r"((?:access_token|api_key|request_token|api_secret|secret|checksum|totp|token)=)([^&\s\"']+)",
    re.IGNORECASE,
)
_AUTH_HEADER = re.compile(r"(token\s+)[^\s:]+:[^\s\"']+", re.IGNORECASE)
_BEARER = re.compile(r"(bearer\s+)[^\s\"',]+", re.IGNORECASE)
_URL_PASSWORD = re.compile(r"(\b[a-z][a-z0-9+.\-]*://[^:/@\s]*:)[^@\s/]+@", re.IGNORECASE)
# Bare credentials that providers may echo in error text: JWTs (Groww access and feed tokens) and
# NATS NKEY seeds.
_JWT = re.compile(r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*")
_NKEY_SEED = re.compile(r"\bS[A-Z2-7]{57}\b")
# Loggers keep the processor list they first logged with, so every configure_logging call refills this
# one list: a reconfiguration (each create_app() call makes one) then reaches loggers already in use.
_PROCESSORS: list[Any] = []


def redact_text(text: str) -> str:
    text = _SENSITIVE_QUERY.sub(lambda m: m.group(1) + REDACTED, text)
    text = _BEARER.sub(lambda m: m.group(1) + REDACTED, text)
    text = _URL_PASSWORD.sub(lambda m: m.group(1) + REDACTED + "@", text)
    text = _AUTH_HEADER.sub(lambda m: m.group(1) + REDACTED, text)
    text = _JWT.sub(REDACTED, text)
    return _NKEY_SEED.sub(REDACTED, text)


def redact_value(key: str | None, value: Any) -> Any:
    if key is not None and _SENSITIVE_KEY.search(key):
        return REDACTED if value not in (None, "") else value
    if isinstance(value, str):
        return redact_text(value)
    if isinstance(value, Mapping):
        return {k: redact_value(str(k), v) for k, v in value.items()}
    if isinstance(value, list | tuple):
        return [redact_value(None, v) for v in value]
    return value


def _redact_processor(
    _logger: Any, _method: str, event_dict: MutableMapping[str, Any]
) -> MutableMapping[str, Any]:
    return {k: redact_value(k, v) for k, v in event_dict.items()}


def configure_logging(level: str = "INFO", *, json_logs: bool = True, stream: TextIO | None = None) -> None:
    """Route stdlib and structlog records through one redacting handler (stdout unless ``stream``)."""
    shared: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        _redact_processor,
    ]
    renderer: Any = structlog.processors.JSONRenderer() if json_logs else structlog.dev.ConsoleRenderer()
    _PROCESSORS[:] = [*shared, structlog.stdlib.ProcessorFormatter.wrap_for_formatter]
    structlog.configure(
        processors=_PROCESSORS,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )
    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared,
        processors=[structlog.stdlib.ProcessorFormatter.remove_processors_meta, renderer],
    )
    handler = logging.StreamHandler(stream or sys.stdout)
    handler.setFormatter(formatter)
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level.upper())
    for name in ("uvicorn", "uvicorn.error"):
        uv_logger = logging.getLogger(name)
        uv_logger.handlers = []
        uv_logger.propagate = True
    # RequestContextMiddleware already logs each request (route template, status, duration, correlation
    # id). uvicorn's access log would duplicate it, including raw query strings that may carry one-time
    # OAuth tokens, so it stays off however the server is started.
    access = logging.getLogger("uvicorn.access")
    access.handlers = []
    access.propagate = False
    # Third-party HTTP clients may log full URLs; keep them quiet unless debugging.
    for name in ("httpx", "httpcore", "websockets", "nats", "asyncio"):
        logging.getLogger(name).setLevel(max(logging.WARNING, root.level))


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    return structlog.stdlib.get_logger(name)


def current_correlation_id() -> str | None:
    value = structlog.contextvars.get_contextvars().get("correlation_id")
    return str(value) if value is not None else None


class RateLimitedLogger:
    """Emits at most one record per key per interval and reports how many were suppressed."""

    def __init__(self, logger: structlog.stdlib.BoundLogger, interval_seconds: float = 10.0) -> None:
        self._logger = logger
        self._interval = interval_seconds
        self._last: dict[str, float] = {}
        self._suppressed: dict[str, int] = {}

    def _allow(self, key: str) -> int | None:
        now = time.monotonic()
        last = self._last.get(key)
        if last is not None and now - last < self._interval:
            self._suppressed[key] = self._suppressed.get(key, 0) + 1
            return None
        self._last[key] = now
        return self._suppressed.pop(key, 0)

    def warning(self, key: str, event: str, **fields: Any) -> None:
        suppressed = self._allow(key)
        if suppressed is not None:
            self._logger.warning(event, suppressed_since_last=suppressed, **fields)

    def error(self, key: str, event: str, **fields: Any) -> None:
        suppressed = self._allow(key)
        if suppressed is not None:
            self._logger.error(event, suppressed_since_last=suppressed, **fields)
