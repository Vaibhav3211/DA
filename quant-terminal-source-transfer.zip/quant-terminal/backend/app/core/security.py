"""Secret encryption (AES-GCM), password hashing, and session-token helpers."""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import os
import secrets
from collections.abc import Sequence

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from app.core.config import Settings

_TOKEN_VERSION = "v1"  # noqa: S105  (ciphertext format version, not a secret)
_NONCE_BYTES = 12
_KEY_BYTES = 32

ENCRYPTION_NOT_CONFIGURED = (
    "ENCRYPTION_KEY is not configured, so credentials cannot be stored or used. "
    "Generate one with `qt generate-key` and restart."
)


class EncryptionError(Exception):
    """Raised when a secret cannot be encrypted/decrypted. Never includes secret material."""


def generate_encryption_key() -> str:
    return base64.urlsafe_b64encode(os.urandom(_KEY_BYTES)).decode("ascii")


def _decode_key(encoded: str) -> bytes:
    try:
        key = base64.urlsafe_b64decode(encoded.strip().encode("ascii"))
    except (binascii.Error, ValueError) as exc:
        raise EncryptionError("encryption key is not valid url-safe base64") from exc
    if len(key) != _KEY_BYTES:
        raise EncryptionError("encryption key must decode to exactly 32 bytes")
    return key


def _key_id(key: bytes) -> str:
    return hashlib.sha256(key).hexdigest()[:8]


class SecretBox:
    """Authenticated encryption for provider credentials and tokens.

    Ciphertexts are bound to a context string (e.g. ``provider_account:<id>:api_secret``) through
    AES-GCM associated data, so a ciphertext copied to another record or field fails to decrypt.
    """

    def __init__(self, primary_key: bytes, previous_keys: Sequence[bytes] = ()) -> None:
        for key in (primary_key, *previous_keys):
            if len(key) != _KEY_BYTES:
                raise EncryptionError("encryption keys must be 32 bytes")
        self._primary_id = _key_id(primary_key)
        self._keys = {_key_id(k): k for k in (*previous_keys, primary_key)}

    @classmethod
    def from_settings(cls, settings: Settings) -> SecretBox:
        if settings.encryption_key is None:
            raise EncryptionError("ENCRYPTION_KEY is not configured; run `qt generate-key`")
        primary = _decode_key(settings.encryption_key.get_secret_value())
        previous: list[bytes] = []
        if settings.encryption_previous_keys is not None:
            raw = settings.encryption_previous_keys.get_secret_value()
            previous = [_decode_key(part) for part in raw.split(",") if part.strip()]
        return cls(primary, previous)

    @property
    def primary_key_id(self) -> str:
        """Short, non-secret identifier of the key used for new ciphertexts."""
        return self._primary_id

    @property
    def previous_key_count(self) -> int:
        return len(self._keys) - 1

    @staticmethod
    def key_id_of(token: str) -> str | None:
        parts = token.split(".", 2)
        return parts[1] if len(parts) == 3 else None

    def encrypt(self, plaintext: str, *, context: str) -> str:
        nonce = os.urandom(_NONCE_BYTES)
        ciphertext = AESGCM(self._keys[self._primary_id]).encrypt(
            nonce, plaintext.encode("utf-8"), context.encode("utf-8")
        )
        payload = base64.urlsafe_b64encode(nonce + ciphertext).decode("ascii")
        return f"{_TOKEN_VERSION}.{self._primary_id}.{payload}"

    def decrypt(self, token: str, *, context: str) -> str:
        try:
            version, key_id, payload = token.split(".", 2)
        except ValueError as exc:
            raise EncryptionError("malformed ciphertext") from exc
        if version != _TOKEN_VERSION:
            raise EncryptionError("unsupported ciphertext version")
        key = self._keys.get(key_id)
        if key is None:
            raise EncryptionError("ciphertext was produced with an unknown key")
        try:
            raw = base64.urlsafe_b64decode(payload.encode("ascii"))
            plaintext = AESGCM(key).decrypt(raw[:_NONCE_BYTES], raw[_NONCE_BYTES:], context.encode("utf-8"))
        except (InvalidTag, binascii.Error, ValueError) as exc:
            raise EncryptionError("ciphertext failed authentication") from exc
        return plaintext.decode("utf-8")

    def needs_rotation(self, token: str) -> bool:
        parts = token.split(".", 2)
        return len(parts) != 3 or parts[1] != self._primary_id


_password_hasher = PasswordHasher()


def hash_password(password: str) -> str:
    return _password_hasher.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    try:
        return _password_hasher.verify(password_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def password_needs_rehash(password_hash: str) -> bool:
    return _password_hasher.check_needs_rehash(password_hash)


def new_opaque_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def constant_time_equals(left: str, right: str) -> bool:
    return hmac.compare_digest(left.encode("utf-8"), right.encode("utf-8"))


def mask_secret(value: str | None, visible: int = 4) -> str | None:
    if not value:
        return None
    if len(value) <= visible * 2:
        return "•" * 4
    return "•" * 4 + value[-visible:]
