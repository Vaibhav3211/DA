"""Canonical JSON and its SHA-256: the content identity of configuration snapshots and backtest settings."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from typing import Any


def canonical_json(value: Mapping[str, Any]) -> str:
    """Sorted keys, no whitespace, text unescaped: equal values give equal text. Values JSON cannot hold
    raise TypeError."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def json_sha256(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(canonical_json(value).encode()).hexdigest()
