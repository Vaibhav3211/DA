"""Canonical enumerations shared by every layer. Provider-specific codes never leak past adapters."""

from __future__ import annotations

from collections.abc import Mapping
from enum import StrEnum
from types import MappingProxyType
from typing import Final


class Provider(StrEnum):
    ZERODHA = "ZERODHA"
    GROWW = "GROWW"
    # Development-only synthetic feed. Its data is always SIMULATED and never actionable.
    SIMULATOR = "SIMULATOR"


class Exchange(StrEnum):
    NSE = "NSE"
    BSE = "BSE"
    MCX = "MCX"
    # Synthetic venue used only by the development simulator.
    SIM = "SIM"


class Segment(StrEnum):
    CASH = "CASH"
    FNO = "FNO"
    CURRENCY = "CURRENCY"
    COMMODITY = "COMMODITY"
    INDEX = "INDEX"


class InstrumentType(StrEnum):
    EQUITY = "EQUITY"
    INDEX = "INDEX"
    FUTURE = "FUTURE"
    OPTION = "OPTION"
    OTHER = "OTHER"


class OptionType(StrEnum):
    CE = "CE"
    PE = "PE"


class DataStatus(StrEnum):
    LIVE = "LIVE"
    DELAYED = "DELAYED"
    STALE = "STALE"
    DISCONNECTED = "DISCONNECTED"
    RECONNECTING = "RECONNECTING"
    SIMULATED = "SIMULATED"
    UNKNOWN = "UNKNOWN"


# Higher rank == worse quality. Used to compute the "worst of" status of derived data.
DATA_STATUS_RANK: dict[DataStatus, int] = {
    DataStatus.LIVE: 0,
    DataStatus.DELAYED: 1,
    DataStatus.STALE: 2,
    DataStatus.RECONNECTING: 3,
    DataStatus.DISCONNECTED: 4,
    DataStatus.UNKNOWN: 5,
    DataStatus.SIMULATED: 6,
}


def worst_status(*statuses: DataStatus) -> DataStatus:
    if not statuses:
        return DataStatus.UNKNOWN
    return max(statuses, key=lambda s: DATA_STATUS_RANK[s])


class ConnectionState(StrEnum):
    IDLE = "IDLE"
    CONNECTING = "CONNECTING"
    CONNECTED = "CONNECTED"
    RECONNECTING = "RECONNECTING"
    DISCONNECTED = "DISCONNECTED"
    AUTH_REQUIRED = "AUTH_REQUIRED"
    STOPPED = "STOPPED"


class MarketSessionState(StrEnum):
    PRE_OPEN = "PRE_OPEN"
    OPEN = "OPEN"
    POST_CLOSE = "POST_CLOSE"
    CLOSED = "CLOSED"
    HOLIDAY = "HOLIDAY"
    UNKNOWN = "UNKNOWN"


class EventType(StrEnum):
    LTP = "LTP"
    QUOTE = "QUOTE"
    DEPTH = "DEPTH"
    INDEX_VALUE = "INDEX_VALUE"


class SubscriptionMode(StrEnum):
    LTP = "LTP"
    QUOTE = "QUOTE"
    FULL = "FULL"


class VolumeSemantics(StrEnum):
    """How the provider reports volume. Cumulative snapshots must never be summed."""

    CUMULATIVE_DAY = "CUMULATIVE_DAY"
    INCREMENTAL = "INCREMENTAL"
    UNAVAILABLE = "UNAVAILABLE"


class CandleInterval(StrEnum):
    S1 = "1s"
    M1 = "1m"
    M3 = "3m"
    M5 = "5m"
    M15 = "15m"
    M30 = "30m"
    H1 = "1h"
    D1 = "1d"

    @property
    def seconds(self) -> int:
        return _INTERVAL_SECONDS[self]


_INTERVAL_SECONDS: dict[CandleInterval, int] = {
    CandleInterval.S1: 1,
    CandleInterval.M1: 60,
    CandleInterval.M3: 180,
    CandleInterval.M5: 300,
    CandleInterval.M15: 900,
    CandleInterval.M30: 1800,
    CandleInterval.H1: 3600,
    CandleInterval.D1: 86400,
}


class CandleFlag(StrEnum):
    PARTIAL_START = "PARTIAL_START"  # first data arrived after the bucket started (connect/reconnect)
    GAP_BEFORE = "GAP_BEFORE"  # the feed was disconnected/stale before this bucket
    DISCONNECTED_DURING = "DISCONNECTED_DURING"  # feed dropped while the bucket was open
    LATE_EVENTS_IGNORED = "LATE_EVENTS_IGNORED"  # events beyond the lateness window were rejected
    VOLUME_INCOMPLETE = "VOLUME_INCOMPLETE"  # a volume delta could not be derived for some events
    VOLUME_RESET = "VOLUME_RESET"  # cumulative volume decreased (session reset) inside the bucket
    VOLUME_UNAVAILABLE = "VOLUME_UNAVAILABLE"  # provider/event type does not report volume
    RECEIVE_TIME_BASIS = "RECEIVE_TIME_BASIS"  # some events lacked a source timestamp
    OUTSIDE_SESSION = "OUTSIDE_SESSION"  # built while the session calendar was unknown/closed


class MarketRegion(StrEnum):
    INDIA = "INDIA"
    FOREX = "FOREX"
    CRYPTO = "CRYPTO"
    LAB = "LAB"


# The market each exchange belongs to.
EXCHANGE_MARKETS: Final[Mapping[Exchange, MarketRegion]] = MappingProxyType(
    {
        Exchange.NSE: MarketRegion.INDIA,
        Exchange.BSE: MarketRegion.INDIA,
        Exchange.MCX: MarketRegion.INDIA,
        Exchange.SIM: MarketRegion.LAB,
    }
)


class WorkspaceKind(StrEnum):
    EQUITY_TRADING = "EQUITY_TRADING"
    INDEX_TRADING = "INDEX_TRADING"
    INDEX_FUTURES = "INDEX_FUTURES"
    INDEX_OPTIONS = "INDEX_OPTIONS"
    STOCK_FUTURES = "STOCK_FUTURES"
    STOCK_OPTIONS = "STOCK_OPTIONS"
    LONG_TERM_INVESTING = "LONG_TERM_INVESTING"
    FOREX_MAJOR_PAIRS = "FOREX_MAJOR_PAIRS"
    FOREX_MINOR_PAIRS = "FOREX_MINOR_PAIRS"
    FOREX_OTHER_PAIRS = "FOREX_OTHER_PAIRS"
    FOREX_SESSIONS = "FOREX_SESSIONS"
    FOREX_ANALYTICS = "FOREX_ANALYTICS"
    FOREX_ECONOMIC_CALENDAR = "FOREX_ECONOMIC_CALENDAR"
    CRYPTO_SPOT = "CRYPTO_SPOT"
    CRYPTO_FUTURES = "CRYPTO_FUTURES"
    CRYPTO_PERPETUALS = "CRYPTO_PERPETUALS"
    CRYPTO_SCANNER = "CRYPTO_SCANNER"
    CRYPTO_FUNDING_RATES = "CRYPTO_FUNDING_RATES"
    CRYPTO_OPEN_INTEREST = "CRYPTO_OPEN_INTEREST"
    CRYPTO_PORTFOLIO = "CRYPTO_PORTFOLIO"
    # Development-only workspace fed by the simulator (never shown as live data).
    SIMULATION_LAB = "SIMULATION_LAB"


class SignalType(StrEnum):
    BUY = "BUY"
    SELL = "SELL"
    EXIT = "EXIT"
    HOLD = "HOLD"
    WATCH = "WATCH"
    INVALIDATED = "INVALIDATED"


ACTIONABLE_SIGNAL_TYPES = frozenset({SignalType.BUY, SignalType.SELL, SignalType.EXIT})


class SignalStatus(StrEnum):
    GENERATED = "GENERATED"
    ACTIVE = "ACTIVE"
    UPDATED = "UPDATED"
    INVALIDATED = "INVALIDATED"
    EXPIRED = "EXPIRED"
    SUPERSEDED = "SUPERSEDED"
    CLOSED = "CLOSED"
    BLOCKED = "BLOCKED"


OPEN_SIGNAL_STATUSES = frozenset({SignalStatus.GENERATED, SignalStatus.ACTIVE, SignalStatus.UPDATED})


class RiskOutcome(StrEnum):
    ALLOW = "ALLOW"
    BLOCK = "BLOCK"


class StrategyRunStatus(StrEnum):
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    CIRCUIT_OPEN = "CIRCUIT_OPEN"
    STOPPED = "STOPPED"
    FAILED = "FAILED"


class ScopeKind(StrEnum):
    """What a saved strategy configuration watches: listed instruments, or the whole workspace."""

    INSTRUMENTS = "INSTRUMENTS"
    WORKSPACE = "WORKSPACE"


class MonitoringState(StrEnum):
    """Live monitoring of a saved configuration, as shown to the user."""

    STOPPED = "STOPPED"  # live signals are off
    STARTING = "STARTING"  # enabled; the strategy worker has not started a run yet
    WARMING_UP = "WARMING_UP"  # running, but some instruments lack the closed candles they need
    RUNNING = "RUNNING"
    BLOCKED = "BLOCKED"  # enabled, but it cannot run or every signal it proposes is blocked
    FAILED = "FAILED"  # the run failed, its circuit is open or the strategy worker is down


class CompatibilityAspect(StrEnum):
    """What one check of a strategy against an instrument looks at."""

    MARKET = "MARKET"
    INSTRUMENT = "INSTRUMENT"
    TIMEFRAME = "TIMEFRAME"
    DATA = "DATA"
    WARMUP = "WARMUP"


class CheckStatus(StrEnum):
    PASSED = "PASSED"
    WARNING = "WARNING"  # it can be used, with a limit worth knowing
    FAILED = "FAILED"  # it cannot be used


class DataRequirement(StrEnum):
    """Market data a strategy needs besides prices."""

    VOLUME = "VOLUME"  # traded volume (candles and quotes)
    OPEN_INTEREST = "OPEN_INTEREST"  # derivatives only, from market events
    MARKET_DEPTH = "MARKET_DEPTH"  # order book levels, from market events


class PluginKind(StrEnum):
    STRATEGY = "STRATEGY"
    AGENT = "AGENT"


class AuthMethod(StrEnum):
    ZERODHA_LOGIN_REDIRECT = "ZERODHA_LOGIN_REDIRECT"
    GROWW_ACCESS_TOKEN = "GROWW_ACCESS_TOKEN"
    GROWW_API_KEY_SECRET = "GROWW_API_KEY_SECRET"
    GROWW_TOTP = "GROWW_TOTP"
    NONE = "NONE"


class AccountStatus(StrEnum):
    """Credential/authentication state of a provider account.

    Whether the account streams is controlled separately by ``is_enabled``; the live feed state of
    each connection is tracked in Redis (``StreamHealth``).
    """

    NEEDS_CREDENTIALS = "NEEDS_CREDENTIALS"
    AUTH_REQUIRED = "AUTH_REQUIRED"
    AUTHENTICATED = "AUTHENTICATED"
    # The user logged out / revoked the session; stays until the next successful authentication.
    DISCONNECTED = "DISCONNECTED"


class CredentialKind(StrEnum):
    API_KEY = "API_KEY"
    API_SECRET = "API_SECRET"
    ACCESS_TOKEN = "ACCESS_TOKEN"
    # Base32 TOTP seed for Groww's TOTP token flow (codes are generated locally, RFC 6238).
    TOTP_SECRET = "TOTP_SECRET"


class SignalEventType(StrEnum):
    GENERATED = "GENERATED"
    ACTIVATED = "ACTIVATED"
    UPDATED = "UPDATED"
    INVALIDATED = "INVALIDATED"
    EXPIRED = "EXPIRED"
    SUPERSEDED = "SUPERSEDED"
    CLOSED = "CLOSED"
    BLOCKED = "BLOCKED"


class CalendarOverrideKind(StrEnum):
    HOLIDAY = "HOLIDAY"
    SPECIAL_SESSION = "SPECIAL_SESSION"


# ---- historical datasets and backtests (M9) ------------------------------------------------------------


class DatasetSource(StrEnum):
    """Where a dataset's candles come from."""

    PROVIDER_HISTORY = "PROVIDER_HISTORY"  # downloaded from the provider's historical-candle API
    RECORDED = "RECORDED"  # candles the platform built from a live provider feed
    SIMULATED = "SIMULATED"  # candles recorded from the development simulator; never real history


class DatasetStatus(StrEnum):
    PENDING = "PENDING"  # queued for the backtest worker
    BUILDING = "BUILDING"
    READY = "READY"
    FAILED = "FAILED"


class BacktestStatus(StrEnum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


class BacktestState(StrEnum):
    """How a saved configuration's backtests on one instrument relate to its current settings."""

    CURRENT = "CURRENT"  # a succeeded backtest used the current settings
    OUTDATED = "OUTDATED"  # backtests succeeded, but the settings changed since
    NOT_BACKTESTED = "NOT_BACKTESTED"  # no backtest succeeded


class TradeSides(StrEnum):
    LONG_ONLY = "LONG_ONLY"
    SHORT_ONLY = "SHORT_ONLY"
    BOTH = "BOTH"


class OppositeSignal(StrEnum):
    """What a signal against the open position does."""

    REVERSE = "REVERSE"  # close it and open the other side (when that side may be traded)
    CLOSE = "CLOSE"  # only close it


class FillTiming(StrEnum):
    NEXT_OPEN = "NEXT_OPEN"  # decisions taken at a candle's close fill at the next candle's open
    SAME_CLOSE = "SAME_CLOSE"  # they fill at the close they were taken at (optimistic)


class ExitCheck(StrEnum):
    INTRABAR = "INTRABAR"  # stop-loss and target are checked against each candle's high and low
    CLOSE = "CLOSE"  # they are checked against the close only; the exit fills like any decision


class StopTargetSource(StrEnum):
    SIGNAL = "SIGNAL"  # the entry signal's stop-loss and first target
    PERCENT = "PERCENT"  # fixed percentages from the entry fill
    NONE = "NONE"  # no stop-loss or target: exits come from signals or the holding limit


class SizingMethod(StrEnum):
    FIXED_QUANTITY = "FIXED_QUANTITY"
    FIXED_AMOUNT = "FIXED_AMOUNT"  # as many units as the amount buys at the entry fill
    RISK_PERCENT = "RISK_PERCENT"  # units whose loss at the stop-loss is this share of equity


class TradeRulesSource(StrEnum):
    CONFIGURATION = "CONFIGURATION"  # saved with the strategy configuration
    STRATEGY = "STRATEGY"  # the strategy's declared defaults


class PositionSide(StrEnum):
    LONG = "LONG"
    SHORT = "SHORT"


class ExitReason(StrEnum):
    STOP_LOSS = "STOP_LOSS"
    TARGET = "TARGET"
    EXIT_SIGNAL = "EXIT_SIGNAL"
    OPPOSITE_SIGNAL = "OPPOSITE_SIGNAL"
    MAX_HOLDING = "MAX_HOLDING"


class TradeOutcome(StrEnum):
    WIN = "WIN"
    LOSS = "LOSS"
    BREAKEVEN = "BREAKEVEN"
