"""Shared base classes and field types for domain models."""

from __future__ import annotations

from datetime import datetime
from typing import Annotated

from pydantic import AfterValidator, AwareDatetime, BaseModel, ConfigDict

from app.core.clock import ensure_utc

# Every timestamp in the domain is timezone-aware and normalized to UTC. Naive values are rejected.
UtcDatetime = Annotated[AwareDatetime, AfterValidator(ensure_utc)]


class DomainModel(BaseModel):
    """Immutable domain value object.

    ``extra="ignore"`` keeps consumers tolerant of newer producers on the event bus.
    Decimal fields serialize to JSON strings, preserving exact precision end to end.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")


def utc_or_none(value: datetime | None) -> datetime | None:
    return ensure_utc(value) if value is not None else None
