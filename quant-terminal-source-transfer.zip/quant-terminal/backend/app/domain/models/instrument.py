"""Instrument identity: canonical instruments and provider-specific instrument records."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any
from uuid import UUID

from pydantic import Field

from app.domain.enums import Exchange, InstrumentType, OptionType, Provider, Segment, SubscriptionMode
from app.domain.models.base import DomainModel, UtcDatetime


class ProviderInstrumentRecord(DomainModel):
    """One row of a provider's official instrument master, translated to canonical vocabulary.

    ``provider_token`` is the identifier the provider's live feed uses for the instrument. It is
    never assumed to be equal across providers.
    """

    provider: Provider
    provider_token: str
    exchange_token: str | None
    provider_symbol: str
    provider_exchange: str
    provider_segment: str
    exchange: Exchange
    segment: Segment
    instrument_type: InstrumentType
    name: str | None = None
    underlying: str | None = None
    expiry: date | None = None
    strike: Decimal | None = None
    option_type: OptionType | None = None
    lot_size: int | None = None
    tick_size: Decimal | None = None
    isin: str | None = None
    tradable: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)


class Instrument(DomainModel):
    """Canonical, provider-independent instrument."""

    id: UUID
    canonical_key: str
    exchange: Exchange
    segment: Segment
    instrument_type: InstrumentType
    symbol: str
    name: str | None = None
    underlying: str | None = None
    expiry: date | None = None
    strike: Decimal | None = None
    option_type: OptionType | None = None
    lot_size: int | None = None
    tick_size: Decimal | None = None
    currency: str = "INR"
    isin: str | None = None
    is_active: bool = True
    updated_at: UtcDatetime | None = None


class InstrumentMapping(DomainModel):
    """Versioned link between a canonical instrument and one provider identifier."""

    id: UUID
    instrument_id: UUID
    provider: Provider
    provider_token: str
    exchange_token: str | None
    provider_symbol: str
    provider_exchange: str
    provider_segment: str
    is_active: bool
    valid_from: UtcDatetime
    valid_to: UtcDatetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProviderInstrument(DomainModel):
    """Everything an adapter needs to subscribe to one instrument and attribute its events."""

    instrument_id: UUID
    provider: Provider
    provider_token: str
    exchange_token: str | None
    provider_symbol: str
    provider_exchange: str
    provider_segment: str
    exchange: Exchange
    segment: Segment
    instrument_type: InstrumentType
    symbol: str
    expiry: date | None = None
    tick_size: Decimal | None = None
    mode: SubscriptionMode = SubscriptionMode.QUOTE
