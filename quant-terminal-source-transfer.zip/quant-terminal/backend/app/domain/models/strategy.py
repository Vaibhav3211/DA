"""Strategy plugin metadata: what a strategy declares about itself.

The declarations are checked when the strategy is registered (``app.strategies.registry``) and shown in
the strategy panel, so a strategy's markets, instruments, timeframes, indicators, warm-up, data needs and
signal conditions are visible before it is applied anywhere.
"""

from __future__ import annotations

from types import MappingProxyType
from typing import Any, Final, Literal

from pydantic import Field

from app.domain.enums import (
    CandleInterval,
    DataRequirement,
    EventType,
    Exchange,
    InstrumentType,
    MarketRegion,
    PluginKind,
    Segment,
    SignalType,
)
from app.domain.models.base import DomainModel

# Inputs a signal condition can name besides its strategy's indicator aliases.
CANDLE_INPUTS: Final = frozenset({"open", "high", "low", "close", "volume"})
EVENT_INPUTS: Final = frozenset({"last_price", "bid", "ask", "volume", "open_interest", "market_depth"})
# Inputs that need data a provider may not supply. Streamed best bid and ask come from the depth levels.
INPUT_REQUIREMENTS: Final = MappingProxyType(
    {
        "volume": DataRequirement.VOLUME,
        "open_interest": DataRequirement.OPEN_INTEREST,
        "market_depth": DataRequirement.MARKET_DEPTH,
        "bid": DataRequirement.MARKET_DEPTH,
        "ask": DataRequirement.MARKET_DEPTH,
    }
)


class IndicatorRequirement(DomainModel):
    alias: str = Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")
    indicator: str
    interval: CandleInterval
    params: dict[str, Any] = Field(default_factory=dict)


class SignalCondition(DomainModel):
    """When the strategy proposes one signal type, in words, and the inputs that decide it: indicator
    aliases, candle fields (open, high, low, close, volume) or market-event fields."""

    signal_type: SignalType
    description: str = Field(min_length=1, max_length=500)
    inputs: tuple[str, ...] = Field(min_length=1)


class StrategyMetadata(DomainModel):
    strategy_id: str = Field(pattern=r"^[a-z][a-z0-9_.-]{2,63}$")
    name: str
    description: str
    version: str = Field(pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$")
    author: str
    kind: PluginKind = PluginKind.STRATEGY
    markets: tuple[MarketRegion, ...]
    # Optional further limits: empty means every exchange of the markets, every matching instrument.
    exchanges: tuple[Exchange, ...] = ()
    segments: tuple[Segment, ...]
    instrument_types: tuple[InstrumentType, ...]
    instrument_keys: tuple[str, ...] = ()  # canonical keys, e.g. NSE:CASH:EQUITY:INFY
    event_types: tuple[EventType, ...] = ()
    candle_intervals: tuple[CandleInterval, ...] = ()  # the timeframes the strategy is evaluated on
    indicators: tuple[IndicatorRequirement, ...] = ()
    warmup_candles: int = Field(default=0, ge=0)
    required_data: tuple[DataRequirement, ...] = ()
    signal_conditions: tuple[SignalCondition, ...] = ()
    uses_partial_candles: bool = False
    resource_profile: Literal["light", "medium", "heavy"] = "light"
    risk_profile: str = "unspecified"
    can_emit_actionable: bool = False
    is_example: bool = False

    @property
    def signal_types(self) -> frozenset[SignalType]:
        """The signal types the strategy declares conditions for: the only ones it may propose."""
        return frozenset(condition.signal_type for condition in self.signal_conditions)

    def eligibility_problem(
        self,
        *,
        market: MarketRegion | None = None,
        exchange: Exchange | None = None,
        segment: Segment | None = None,
        instrument_type: InstrumentType | None = None,
        instrument_key: str | None = None,
    ) -> str | None:
        """Why the strategy does not support this market or instrument; None if it does."""
        if market is not None and market not in self.markets:
            return f"{self.strategy_id} does not support the {market.value} market"
        if exchange is not None and self.exchanges and exchange not in self.exchanges:
            return f"{self.strategy_id} does not support the {exchange.value} exchange"
        if segment is not None and segment not in self.segments:
            return f"{self.strategy_id} does not support the {segment.value} segment"
        if instrument_type is not None and instrument_type not in self.instrument_types:
            return f"{self.strategy_id} does not support {instrument_type.value} instruments"
        if instrument_key is not None and self.instrument_keys and instrument_key not in self.instrument_keys:
            return (
                f"{self.strategy_id} supports only the instruments it lists, and {instrument_key} is not one"
            )
        return None
