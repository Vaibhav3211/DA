"""Latest-quote snapshot kept in the Redis cache and served to REST/WebSocket clients."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from app.domain.enums import DataStatus, EventType, Exchange, Provider, Segment
from app.domain.models.base import UtcDatetime
from app.domain.models.market_event import MarketFields, NormalizedMarketEvent

_MERGE_FIELDS: tuple[str, ...] = tuple(MarketFields.model_fields)


class QuoteSnapshot(MarketFields):
    provider: Provider
    account_id: UUID | None
    instrument_id: UUID
    symbol: str
    exchange: Exchange
    segment: Segment
    last_event_type: EventType
    received_at: UtcDatetime
    processed_at: UtcDatetime
    # Status when the snapshot was written. Readers recompute it from current feed/session state.
    data_status: DataStatus
    sequence_number: int | None = None
    depth_received_at: UtcDatetime | None = None

    @classmethod
    def from_event(cls, event: NormalizedMarketEvent, previous: QuoteSnapshot | None = None) -> QuoteSnapshot:
        """Merge an event into the previous snapshot.

        Only fields the event actually carries overwrite older values; absent fields keep their
        last known value (each update's receive time is kept so readers can judge freshness).
        """
        merged: dict[str, Any] = {}
        same_instrument = previous is not None and previous.instrument_id == event.instrument_id
        for name in _MERGE_FIELDS:
            value = getattr(event, name)
            if value is None and same_instrument and previous is not None:
                value = getattr(previous, name)
            merged[name] = value
        if event.volume is None and same_instrument and previous is not None:
            merged["volume_semantics"] = previous.volume_semantics
        depth_at: datetime | None = event.received_at if event.market_depth is not None else None
        if depth_at is None and same_instrument and previous is not None:
            depth_at = previous.depth_received_at
        return cls(
            **merged,
            provider=event.provider,
            account_id=event.account_id,
            instrument_id=event.instrument_id,
            symbol=event.symbol,
            exchange=event.exchange,
            segment=event.segment,
            last_event_type=event.event_type,
            received_at=event.received_at,
            processed_at=event.processed_at,
            data_status=event.data_status,
            sequence_number=event.sequence_number,
            depth_received_at=depth_at,
        )
