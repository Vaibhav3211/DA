"""Signal, signal candidate, and risk decision models."""

from __future__ import annotations

from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from pydantic import Field, model_validator

from app.domain.enums import (
    CandleInterval,
    DataStatus,
    Exchange,
    MarketRegion,
    Provider,
    RiskOutcome,
    Segment,
    SignalStatus,
    SignalType,
)
from app.domain.models.base import DomainModel, UtcDatetime

SIGNAL_DISCLAIMER = (
    "System-generated research output for personal analysis only. Not investment advice, "
    "not a recommendation, and no guarantee of returns. Verify independently before acting."
)


class TargetLevel(DomainModel):
    label: str
    price: Decimal


class IndicatorValue(DomainModel):
    """An indicator reading with enough provenance to trace it back to its input candles."""

    name: str
    indicator: str
    version: str
    params: dict[str, Any] = Field(default_factory=dict)
    value: Decimal | None
    interval: CandleInterval | None = None
    input_from: UtcDatetime | None = None
    input_to: UtcDatetime | None = None
    input_count: int = 0
    data_status: DataStatus = DataStatus.UNKNOWN


class SignalCandidate(DomainModel):
    """What a strategy proposes. The runtime adds identity, provenance, risk and lifecycle."""

    instrument_id: UUID
    signal_type: SignalType
    reasons: tuple[str, ...] = Field(min_length=1)
    explanation: str = Field(min_length=1)
    entry_price: Decimal | None = None
    stop_loss: Decimal | None = None
    targets: tuple[TargetLevel, ...] = ()
    # Strategy-defined score. It is NOT a probability unless the strategy documents calibration.
    score: Decimal | None = None
    score_definition: str | None = None
    indicator_values: tuple[IndicatorValue, ...] = ()
    invalidation_conditions: tuple[str, ...] = ()
    valid_for_seconds: int | None = Field(default=None, gt=0)
    source_event_time: UtcDatetime | None = None
    source_candle_interval: CandleInterval | None = None
    source_candle_start: UtcDatetime | None = None

    @model_validator(mode="after")
    def _score_needs_definition(self) -> SignalCandidate:
        if self.score is not None and not self.score_definition:
            raise ValueError("score requires a documented score_definition")
        return self


class RiskCheck(DomainModel):
    rule: str
    passed: bool
    severity: Literal["BLOCK", "WARN"] = "BLOCK"
    message: str
    details: dict[str, Any] = Field(default_factory=dict)


class RiskDecision(DomainModel):
    outcome: RiskOutcome
    checks: tuple[RiskCheck, ...]
    evaluated_at: UtcDatetime

    @property
    def blocking_reasons(self) -> list[str]:
        return [c.message for c in self.checks if not c.passed and c.severity == "BLOCK"]


class Signal(DomainModel):
    id: UUID
    workspace_id: UUID
    market_region: MarketRegion
    instrument_id: UUID
    symbol: str
    exchange: Exchange
    segment: Segment
    provider: Provider
    account_id: UUID | None
    strategy_id: str
    strategy_version: str
    deployment_id: UUID
    strategy_run_id: UUID
    signal_type: SignalType
    status: SignalStatus
    is_actionable: bool
    entry_price: Decimal | None = None
    stop_loss: Decimal | None = None
    targets: tuple[TargetLevel, ...] = ()
    risk_reward: Decimal | None = None
    score: Decimal | None = None
    score_definition: str | None = None
    generated_at: UtcDatetime
    updated_at: UtcDatetime
    valid_until: UtcDatetime | None = None
    closed_at: UtcDatetime | None = None
    source_event_time: UtcDatetime | None = None
    source_candle_interval: CandleInterval | None = None
    source_candle_start: UtcDatetime | None = None
    data_status: DataStatus
    reasons: tuple[str, ...]
    indicator_values: tuple[IndicatorValue, ...] = ()
    invalidation_conditions: tuple[str, ...] = ()
    explanation: str
    risk_decision: RiskDecision
    superseded_by: UUID | None = None
    update_count: int = 0
    disclaimer: str = SIGNAL_DISCLAIMER
