"""Candle model produced by the live candle builder."""

from __future__ import annotations

from decimal import Decimal
from uuid import UUID

from app.domain.enums import CandleFlag, CandleInterval, DataStatus, Exchange, Provider, Segment
from app.domain.models.base import DomainModel, UtcDatetime

CANDLE_BUILDER_VERSION = "1.0"


class Candle(DomainModel):
    provider: Provider
    account_id: UUID | None
    instrument_id: UUID
    symbol: str
    exchange: Exchange
    segment: Segment
    interval: CandleInterval
    bucket_start: UtcDatetime
    bucket_end: UtcDatetime
    open_price: Decimal
    high_price: Decimal
    low_price: Decimal
    close_price: Decimal
    # None when the provider does not report volume, or a reliable delta could not be derived.
    volume: int | None
    event_count: int
    is_closed: bool
    # Worst status among contributing events and the feed state while the bucket was open.
    data_status: DataStatus
    flags: tuple[CandleFlag, ...] = ()
    first_event_at: UtcDatetime
    last_event_at: UtcDatetime
    revision: int = 0
    builder_version: str = CANDLE_BUILDER_VERSION

    @property
    def is_complete(self) -> bool:
        """Closed and built without gaps or partial coverage."""
        incomplete = {CandleFlag.PARTIAL_START, CandleFlag.GAP_BEFORE, CandleFlag.DISCONNECTED_DURING}
        return self.is_closed and not incomplete.intersection(self.flags)
