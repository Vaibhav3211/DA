"""Provider health and capability models."""

from __future__ import annotations

from datetime import date
from uuid import UUID

from pydantic import Field

from app.domain.enums import (
    ConnectionState,
    DataStatus,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
    SubscriptionMode,
)
from app.domain.models.base import DomainModel, UtcDatetime


class StreamHealth(DomainModel):
    """Health of one provider stream (one provider account connection or shard)."""

    provider: Provider
    account_id: UUID | None
    stream_id: str
    state: ConnectionState
    data_status: DataStatus
    state_since: UtcDatetime
    connected_since: UtcDatetime | None = None
    last_message_at: UtcDatetime | None = None
    last_event_at: UtcDatetime | None = None
    last_heartbeat_at: UtcDatetime | None = None
    events_received: int = 0
    events_per_second: float = 0.0
    malformed_events: int = 0
    dropped_events: int = 0
    duplicate_events: int = 0
    reconnect_count: int = 0
    subscribed_instruments: int = 0
    desired_instruments: int = 0
    source_latency_ms: float | None = None
    processing_latency_ms: float | None = None
    stale_seconds: float | None = None
    last_error: str | None = None
    auth_required: bool = False
    # Whether any subscribed exchange is in session; None when unknown. Staleness only alerts when open.
    session_open: bool | None = None
    updated_at: UtcDatetime


class ProviderHealth(DomainModel):
    provider: Provider
    account_id: UUID | None
    state: ConnectionState
    data_status: DataStatus
    streams: tuple[StreamHealth, ...] = ()
    token_expires_at: UtcDatetime | None = None
    message: str | None = None


class ProviderCapabilities(DomainModel):
    """What a provider supports, as verified from official documentation on ``verified_on``."""

    provider: Provider
    display_name: str
    exchanges: tuple[Exchange, ...]
    segments: tuple[Segment, ...]
    instrument_types: tuple[InstrumentType, ...]
    streaming: bool
    rest_quotes: bool
    subscription_modes: tuple[SubscriptionMode, ...]
    quote_fields: tuple[str, ...]
    depth_levels: int | None
    max_instruments_per_connection: int | None
    max_connections_per_account: int | None
    rest_rate_limits: dict[str, str] = Field(default_factory=dict)
    token_expiry: str
    token_refresh: str
    entitlement: str
    restrictions: tuple[str, ...] = ()
    documentation_urls: tuple[str, ...] = ()
    verified_on: date | None
    verification_source: str
    needs_live_verification: tuple[str, ...] = ()
