"""Backtest trade rules and results (M9; see docs/backtesting.md).

``TradeRules`` turn signals into simulated trades. Every assumption that changes the results (sides,
fills, exits, sizing, fees, slippage) is a required field, so nothing is assumed silently. The results
keep closed trades and the position still open at the end apart, and a metric that cannot be computed
carries the reason instead of a number.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal

from pydantic import ConfigDict, Field, model_validator

from app.domain.enums import (
    ExitCheck,
    ExitReason,
    FillTiming,
    OppositeSignal,
    PositionSide,
    SignalType,
    SizingMethod,
    StopTargetSource,
    TradeOutcome,
    TradeSides,
)
from app.domain.models.base import DomainModel, UtcDatetime
from app.domain.models.signal import TargetLevel


class TradeRules(DomainModel):
    """How a backtest trades the signals. Fees are a percentage of each fill's value plus a fixed amount
    per order; slippage moves every fill against the trade by whole ticks."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    sides: TradeSides = Field(description="Which sides may be traded.")
    opposite_signal: OppositeSignal = Field(description="What a signal against the open position does.")
    fill: FillTiming = Field(description="When decisions taken at a candle's close fill.")
    exit_check: ExitCheck = Field(description="How the stop-loss and target are checked.")
    stop_target: StopTargetSource = Field(description="Where the stop-loss and target come from.")
    stop_pct: Decimal | None = Field(
        default=None, gt=0, lt=100, description="PERCENT: stop-loss distance from the entry fill, in %."
    )
    target_pct: Decimal | None = Field(
        default=None, gt=0, le=1000, description="PERCENT: target distance from the entry fill, in %."
    )
    max_holding_candles: int | None = Field(
        default=None, ge=1, le=100_000, description="Close a position after this many candles (optional)."
    )
    sizing: SizingMethod = Field(description="How many units an entry takes, rounded down to the lot.")
    quantity: int | None = Field(default=None, ge=1, description="FIXED_QUANTITY: units per entry.")
    amount: Decimal | None = Field(default=None, gt=0, description="FIXED_AMOUNT: value per entry.")
    risk_pct: Decimal | None = Field(
        default=None, gt=0, le=100, description="RISK_PERCENT: equity lost at the stop-loss, in %."
    )
    initial_capital: Decimal = Field(gt=0, description="Equity at the start.")
    fee_pct_per_side: Decimal = Field(ge=0, le=10, description="Fee on each fill's value, in %.")
    fee_per_order: Decimal = Field(ge=0, description="Fixed fee per order.")
    slippage_ticks: int = Field(ge=0, le=1000, description="Ticks each fill moves against the trade.")

    @model_validator(mode="after")
    def _consistent(self) -> TradeRules:
        problems: list[str] = []
        percent = self.stop_target is StopTargetSource.PERCENT
        if percent and self.stop_pct is None and self.target_pct is None:
            problems.append("stop_target PERCENT needs stop_pct, target_pct or both")
        if not percent and (self.stop_pct is not None or self.target_pct is not None):
            problems.append("stop_pct and target_pct apply only to stop_target PERCENT")
        needed = {
            SizingMethod.FIXED_QUANTITY: "quantity",
            SizingMethod.FIXED_AMOUNT: "amount",
            SizingMethod.RISK_PERCENT: "risk_pct",
        }
        for method, name in needed.items():
            value = getattr(self, name)
            if method is self.sizing and value is None:
                problems.append(f"sizing {method.value} needs {name}")
            elif method is not self.sizing and value is not None:
                problems.append(f"{name} applies only to sizing {method.value}")
        if self.sizing is SizingMethod.RISK_PERCENT and (
            self.stop_target is StopTargetSource.NONE or (percent and self.stop_pct is None)
        ):
            problems.append(
                "sizing RISK_PERCENT needs a stop-loss (stop_target SIGNAL, or PERCENT with stop_pct)"
            )
        if problems:
            raise ValueError("; ".join(problems))
        return self


# ---- datasets --------------------------------------------------------------------------------------------


class GapRange(DomainModel):
    """Consecutive candles the exchange calendar expects and the dataset does not have."""

    start: UtcDatetime  # start of the first missing candle
    end: UtcDatetime  # end of the last missing candle
    candles: int


class DatasetCoverage(DomainModel):
    """How completely a dataset covers its dates, measured against the exchange calendar."""

    anchor: str | None = None  # SESSION or CLOCK: the grid intraday candles start on; None for daily
    session_days: int = 0  # days the calendar has a session on
    expected: int = 0  # candles the calendar expects on those days
    present: int = 0  # expected candles the dataset has
    missing: int = 0
    coverage_pct: Decimal | None = None  # present / expected x 100; None when nothing is expected
    gaps: tuple[GapRange, ...] = ()  # the first runs of missing candles
    gap_total: int = 0
    assumed_days: tuple[date, ...] = ()  # session days with assumed hours (no published calendar)
    assumed_days_total: int = 0
    unknown_days: tuple[date, ...] = ()  # days without a calendar: candles kept unchecked, OUTSIDE_SESSION
    unknown_days_total: int = 0
    left_out: int = 0  # candles not on an expected slot: outside the sessions or the dates, closed days
    left_out_by_reason: dict[str, int] = Field(default_factory=dict)  # CLOSED_DAY, OUTSIDE_HOURS, ...
    left_out_examples: tuple[str, ...] = ()
    duplicates: int = 0  # candles received more than once (kept once)
    requests: int = 0  # provider requests made
    inconsistent: int = 0  # candles whose high and low do not contain the open and close (kept, flagged)
    without_volume: int = 0
    incomplete: int = 0  # recorded candles built with partial coverage, after a gap or across a drop
    notes: tuple[str, ...] = ()


# ---- results ---------------------------------------------------------------------------------------------


class Measure(DomainModel):
    """A metric that may be undefined; ``reason`` says why ``value`` is missing."""

    value: Decimal | None = None
    reason: str | None = None


class SignalRef(DomainModel):
    """The signal behind a fill, as the strategy proposed it at a candle's close."""

    signal_type: SignalType
    decided_at: UtcDatetime  # the close of the candle it was proposed on
    candle_start: UtcDatetime
    entry_price: Decimal | None = None
    stop_loss: Decimal | None = None
    targets: tuple[TargetLevel, ...] = ()
    reasons: tuple[str, ...] = ()
    indicators: dict[str, str | None] = Field(default_factory=dict)  # name -> value when proposed


class BacktestTrade(DomainModel):
    """A closed trade. Gross results use reference prices (the open, close or level a fill is based on);
    net results use fill prices, after slippage, minus fees. ``entry_at`` and ``exit_at`` are the starts of
    the candles the fills happened in: at the open (NEXT_OPEN, or a gap through a level), at the close
    (SAME_CLOSE, or exits decided on closes) or inside the candle (a stop-loss or target touched)."""

    number: int
    side: PositionSide
    quantity: int
    entry_at: UtcDatetime
    entry_reference: Decimal
    entry_price: Decimal
    exit_at: UtcDatetime
    exit_reference: Decimal
    exit_price: Decimal
    exit_reason: ExitReason
    stop_loss: Decimal | None  # the levels in force when it closed
    target: Decimal | None
    both_touched: bool = False  # one candle touched the stop-loss and the target; the stop was assumed
    gap_exit: bool = False  # the candle opened beyond the level, so the exit filled at the open
    candles_held: int
    gross_pnl: Decimal
    fees: Decimal
    slippage: Decimal
    net_pnl: Decimal
    return_pct: Decimal  # net result over the entry's reference value
    outcome: TradeOutcome
    entry_signal: SignalRef
    exit_signal: SignalRef | None = None


class OpenPosition(DomainModel):
    """The position still open when the data ends, valued at the last close. Not a closed trade."""

    side: PositionSide
    quantity: int
    entry_at: UtcDatetime
    entry_price: Decimal
    stop_loss: Decimal | None
    target: Decimal | None
    candles_held: int
    marked_at: UtcDatetime
    mark_price: Decimal
    unrealized_pnl: Decimal  # at the mark, after the entry's fees, before any exit costs
    entry_signal: SignalRef


class SkippedEntry(DomainModel):
    at: UtcDatetime
    signal_type: SignalType
    reason: str


class EquityPoint(DomainModel):
    at: UtcDatetime
    equity: Decimal


class SignalStats(DomainModel):
    """What happened to the strategy's proposals during the evaluated period."""

    proposed: int = 0
    allowed: int = 0  # new signals and updates the risk gate allowed
    blocked: int = 0
    blocked_by_rule: dict[str, int] = Field(default_factory=dict)
    duplicates: int = 0  # dropped before the gate: same type and levels as the open signal
    updates: int = 0  # allowed updates of the open signal's levels
    invalidations: int = 0
    expired: int = 0  # open signals that reached valid_until


class BacktestMetrics(DomainModel):
    closed_trades: int
    wins: int
    losses: int
    breakevens: int
    win_rate_pct: Measure  # wins / closed trades x 100
    average_win: Measure
    average_loss: Measure
    gross_pnl: Decimal
    net_pnl: Decimal
    gross_return_pct: Decimal  # over the initial capital
    net_return_pct: Decimal
    fees: Decimal
    slippage: Decimal
    profit_factor: Measure  # net profit of wins / net loss of losses
    max_drawdown: Decimal
    max_drawdown_pct: Measure  # of the peak it fell from
    drawdown_peak_at: UtcDatetime | None = None
    drawdown_trough_at: UtcDatetime | None = None
    final_equity: Decimal  # including the open position at its mark
    both_touched_trades: int
    gap_exits: int


class BacktestPeriod(DomainModel):
    dataset_from: UtcDatetime  # the dataset's first candle start
    dataset_to: UtcDatetime  # its last candle end
    warmup_candles: int  # candles folded into the indicators before the strategy was called
    evaluated_from: UtcDatetime | None  # the first candle the strategy was called with
    evaluated_to: UtcDatetime | None
    evaluated_candles: int


class BacktestSummary(DomainModel):
    """Everything about a finished backtest except its trades and equity curve."""

    engine_version: str
    period: BacktestPeriod
    metrics: BacktestMetrics
    signals: SignalStats
    open_position: OpenPosition | None = None
    pending_at_end: tuple[str, ...] = ()  # decisions of the last close that had no candle to fill on
    skipped_entries: tuple[SkippedEntry, ...] = ()  # the first ones
    skipped_entries_total: int = 0
    equity_points: int  # points on the full curve; the stored curve is sampled down from them
    notes: tuple[str, ...] = ()
