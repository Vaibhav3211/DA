"""Canonical market event model. Every provider adapter produces exactly this schema."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from app.domain.enums import (
    DataStatus,
    EventType,
    Exchange,
    Provider,
    Segment,
    VolumeSemantics,
)
from app.domain.models.base import DomainModel, UtcDatetime


class DepthLevel(DomainModel):
    price: Decimal
    quantity: int
    orders: int | None = None


class MarketDepth(DomainModel):
    bids: tuple[DepthLevel, ...] = ()
    asks: tuple[DepthLevel, ...] = ()


class MarketFields(DomainModel):
    """Price and size fields. Missing data stays ``None``; it is never zero-filled or guessed.

    ``close_price`` is only set when a provider reports the *current* session close.
    ``previous_close`` holds the prior session close (Kite reports this as ``ohlc.close``).
    """

    last_price: Decimal | None = None
    last_quantity: int | None = None
    average_price: Decimal | None = None
    volume: int | None = None
    volume_semantics: VolumeSemantics = VolumeSemantics.UNAVAILABLE
    open_price: Decimal | None = None
    high_price: Decimal | None = None
    low_price: Decimal | None = None
    close_price: Decimal | None = None
    previous_close: Decimal | None = None
    bid: Decimal | None = None
    ask: Decimal | None = None
    bid_quantity: int | None = None
    ask_quantity: int | None = None
    total_buy_quantity: int | None = None
    total_sell_quantity: int | None = None
    open_interest: int | None = None
    open_interest_day_high: int | None = None
    open_interest_day_low: int | None = None
    market_depth: MarketDepth | None = None
    # Exchange timestamp of the update, only when the provider supplies one.
    source_timestamp: UtcDatetime | None = None
    last_trade_time: UtcDatetime | None = None
    # Timestamp supplied by the provider whose exchange/provider origin is not documented.
    provider_timestamp: UtcDatetime | None = None


class ProviderTick(MarketFields):
    """Provider-neutral parse result, before instrument resolution. Produced by adapter mappers."""

    provider: Provider
    account_id: UUID | None
    provider_token: str
    event_type: EventType
    received_at: UtcDatetime
    raw_payload_hash: str | None = None


class NormalizedMarketEvent(MarketFields):
    event_id: UUID
    provider: Provider
    account_id: UUID | None
    exchange: Exchange
    segment: Segment
    instrument_id: UUID
    provider_instrument_token: str
    symbol: str
    event_type: EventType
    received_at: UtcDatetime
    processed_at: UtcDatetime
    sequence_number: int | None = None
    data_status: DataStatus
    raw_payload_hash: str | None = None

    @property
    def reference_timestamp(self) -> datetime | None:
        """Best available upstream timestamp (exchange first, then provider). Never fabricated."""
        return self.source_timestamp or self.provider_timestamp

    @property
    def event_time(self) -> datetime:
        return self.reference_timestamp or self.received_at

    @property
    def uses_receive_time(self) -> bool:
        return self.reference_timestamp is None

    @property
    def source_latency_seconds(self) -> float | None:
        reference = self.reference_timestamp
        if reference is None:
            return None
        return (self.received_at - reference).total_seconds()
