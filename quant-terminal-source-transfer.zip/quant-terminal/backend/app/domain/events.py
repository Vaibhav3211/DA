"""Messages exchanged between processes over the Redis event bus."""

from __future__ import annotations

from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4

from pydantic import Field

from app.core.clock import utc_now
from app.domain.enums import ConnectionState, Provider, SignalEventType
from app.domain.models.base import DomainModel, UtcDatetime
from app.domain.models.signal import Signal


class FeedStateChange(DomainModel):
    provider: Provider
    account_id: UUID | None
    stream_id: str
    previous_state: ConnectionState
    state: ConnectionState
    reason: str
    at: UtcDatetime


class CommandType(StrEnum):
    CONNECT_ACCOUNT = "CONNECT_ACCOUNT"
    DISCONNECT_ACCOUNT = "DISCONNECT_ACCOUNT"
    REFRESH_SUBSCRIPTIONS = "REFRESH_SUBSCRIPTIONS"
    REFRESH_INSTRUMENTS = "REFRESH_INSTRUMENTS"
    RELOAD_DEPLOYMENTS = "RELOAD_DEPLOYMENTS"


class WorkerCommand(DomainModel):
    """Control-plane instruction from the API to a worker. Never carries secrets."""

    command_id: UUID = Field(default_factory=uuid4)
    type: CommandType
    provider: Provider | None = None
    account_id: UUID | None = None
    params: dict[str, Any] = Field(default_factory=dict)
    issued_by: str | None = None
    issued_at: UtcDatetime = Field(default_factory=utc_now)


class SignalUpdate(DomainModel):
    """Published on ``qt:signals`` after a signal lifecycle change is committed."""

    event_type: SignalEventType
    signal: Signal
    at: UtcDatetime
