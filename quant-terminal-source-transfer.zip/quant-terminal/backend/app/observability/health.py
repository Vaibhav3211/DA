"""Liveness/readiness probes and the detailed system health report with alert conditions."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from datetime import date, datetime, timedelta
from typing import TYPE_CHECKING, Any, Literal

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ValidationError
from sqlalchemy import select

from app import __version__
from app.core.clock import utc_now
from app.core.logging import get_logger
from app.domain.enums import AccountStatus, ConnectionState, DataStatus
from app.domain.models import StreamHealth
from app.observability.heartbeat import EXPECTED_WORKERS, MARKET_DATA_WORKER, WorkerHeartbeat
from app.persistence.models import ProviderAccountRow
from app.services.kill_switch import KillSwitchService, KillSwitchState
from app.streaming.redis_bus import Keys

if TYPE_CHECKING:
    from app.container import Container

log = get_logger(__name__)

_PROBE_TIMEOUT_SECONDS = 2.0
_TOKEN_EXPIRY_WARNING = timedelta(minutes=30)
_QUEUE_HIGH_RATIO = 0.8

Severity = Literal["critical", "warning", "info"]


class ComponentHealth(BaseModel):
    name: str
    ok: bool
    latency_ms: float | None = None
    error: str | None = None


class WorkerStatus(BaseModel):
    worker: str
    alive: bool
    instance: str | None = None
    version: str | None = None
    started_at: datetime | None = None
    heartbeat_at: datetime | None = None
    details: dict[str, Any] = {}


class Alert(BaseModel):
    severity: Severity
    code: str
    message: str
    subject: str | None = None


class AccountHealth(BaseModel):
    account_id: str
    provider: str
    label: str
    status: AccountStatus
    is_enabled: bool
    token_expires_at: datetime | None


class SystemHealth(BaseModel):
    status: Literal["ok", "degraded", "down"]
    version: str
    app_env: str
    simulated_mode: bool
    flags: dict[str, bool]
    kill_switch: KillSwitchState | None
    components: list[ComponentHealth]
    workers: list[WorkerStatus]
    feeds: list[StreamHealth]
    accounts: list[AccountHealth]
    alerts: list[Alert]
    generated_at: datetime


async def _probe(name: str, check: Callable[[], Awaitable[Any]]) -> ComponentHealth:
    started = time.perf_counter()
    try:
        async with asyncio.timeout(_PROBE_TIMEOUT_SECONDS):
            await check()
    except Exception as exc:
        # Exception text can contain connection details; report only the type.
        return ComponentHealth(name=name, ok=False, error=type(exc).__name__)
    return ComponentHealth(name=name, ok=True, latency_ms=round((time.perf_counter() - started) * 1000, 2))


router = APIRouter(tags=["health"])


@router.get("/health/live", include_in_schema=False)
async def live() -> dict[str, str]:
    return {"status": "alive"}


@router.get("/health/ready", include_in_schema=False)
async def ready(request: Request) -> JSONResponse:
    container: Container = request.app.state.container
    components = await asyncio.gather(
        _probe("postgres", container.db.ping), _probe("redis", container.bus.ping)
    )
    ok = all(c.ok for c in components)
    body = {"status": "ready" if ok else "not_ready", "components": [c.model_dump() for c in components]}
    return JSONResponse(body, status_code=200 if ok else 503)


class SystemHealthService:
    def __init__(self, container: Container) -> None:
        self._container = container
        self._settings = container.settings

    async def report(self) -> SystemHealth:
        db_health, redis_health = await asyncio.gather(
            _probe("postgres", self._container.db.ping), _probe("redis", self._container.bus.ping)
        )
        alerts: list[Alert] = []
        workers: list[WorkerStatus] = []
        feeds: list[StreamHealth] = []
        accounts: list[AccountHealth] = []
        kill_switch: KillSwitchState | None = None
        now = utc_now()

        if redis_health.ok:
            workers = await self._workers()
            feeds = await self._feeds()
        if db_health.ok:
            accounts = await self._accounts()
        if db_health.ok and redis_health.ok:
            try:
                kill_switch = await KillSwitchService(self._container.db, self._container.bus).get()
            except Exception as exc:
                log.warning("kill_switch_read_failed", error=type(exc).__name__)

        alerts.extend(self._component_alerts(db_health, redis_health))
        alerts.extend(self._worker_alerts(workers))
        alerts.extend(self._calendar_alerts(workers, now))
        alerts.extend(self._feed_alerts(feeds))
        alerts.extend(self._account_alerts(accounts, now))
        if kill_switch is not None and kill_switch.engaged:
            alerts.append(
                Alert(
                    severity="warning",
                    code="kill_switch_engaged",
                    message=f"Kill switch engaged: all actionable signals are blocked ({kill_switch.reason})",
                )
            )

        if not (db_health.ok and redis_health.ok):
            status: Literal["ok", "degraded", "down"] = "down"
        elif any(a.severity in ("critical", "warning") for a in alerts):
            status = "degraded"
        else:
            status = "ok"

        s = self._settings
        return SystemHealth(
            status=status,
            version=__version__,
            app_env=s.app_env.value,
            simulated_mode=s.is_simulated_mode,
            flags={
                "market_data_enabled": s.market_data_enabled,
                "live_signals_enabled": s.live_signals_enabled,
                "order_execution_enabled": s.order_execution_enabled,
                "simulator_enabled": s.simulator_enabled,
                "tick_persistence_enabled": s.tick_persistence_enabled,
            },
            kill_switch=kill_switch,
            components=[db_health, redis_health],
            workers=workers,
            feeds=feeds,
            accounts=accounts,
            alerts=alerts,
            generated_at=now,
        )

    async def _workers(self) -> list[WorkerStatus]:
        raw = await self._container.bus.scan_json(Keys.WORKER_HEARTBEAT_PATTERN)
        seen: dict[str, WorkerStatus] = {}
        for value in raw.values():
            try:
                beat = WorkerHeartbeat.model_validate(value)
            except ValidationError:
                continue
            seen[beat.worker] = WorkerStatus(
                worker=beat.worker,
                alive=True,
                instance=beat.instance,
                version=beat.version,
                started_at=beat.started_at,
                heartbeat_at=beat.heartbeat_at,
                details=beat.details,
            )
        for name in EXPECTED_WORKERS:
            seen.setdefault(name, WorkerStatus(worker=name, alive=False))
        return sorted(seen.values(), key=lambda w: w.worker)

    async def _feeds(self) -> list[StreamHealth]:
        raw = await self._container.bus.scan_json(Keys.FEED_STATE_PATTERN)
        feeds: list[StreamHealth] = []
        for value in raw.values():
            try:
                feeds.append(StreamHealth.model_validate(value))
            except ValidationError:
                continue
        return sorted(feeds, key=lambda f: (f.provider.value, f.stream_id))

    async def _accounts(self) -> list[AccountHealth]:
        try:
            async with self._container.db.session() as session:
                rows = (await session.scalars(select(ProviderAccountRow))).all()
        except Exception as exc:
            log.warning("account_health_query_failed", error=type(exc).__name__)
            return []
        return [
            AccountHealth(
                account_id=str(row.id),
                provider=row.provider.value,
                label=row.label,
                status=row.status,
                is_enabled=row.is_enabled,
                token_expires_at=row.token_expires_at,
            )
            for row in rows
        ]

    @staticmethod
    def _component_alerts(*components: ComponentHealth) -> list[Alert]:
        return [
            Alert(
                severity="critical",
                code=f"{c.name}_unavailable",
                message=f"{c.name} is unreachable ({c.error})",
            )
            for c in components
            if not c.ok
        ]

    def _worker_alerts(self, workers: list[WorkerStatus]) -> list[Alert]:
        alerts: list[Alert] = []
        for worker in workers:
            if not worker.alive:
                alerts.append(
                    Alert(
                        severity="critical",
                        code="worker_down",
                        message=f"{worker.worker} has not reported a heartbeat",
                        subject=worker.worker,
                    )
                )
                continue
            if worker.worker == MARKET_DATA_WORKER:
                depth = worker.details.get("queue_depth")
                capacity = worker.details.get("queue_capacity") or self._settings.provider_queue_size
                if isinstance(depth, int) and capacity and depth >= capacity * _QUEUE_HIGH_RATIO:
                    alerts.append(
                        Alert(
                            severity="warning",
                            code="queue_depth_high",
                            message=f"Market-data ingest queue at {depth}/{capacity}",
                            subject=worker.worker,
                        )
                    )
        return alerts

    def _calendar_alerts(self, workers: list[WorkerStatus], now: datetime) -> list[Alert]:
        """Exchange calendars the market-data worker uses that are no longer, or soon not, published."""
        worker = next((w for w in workers if w.worker == MARKET_DATA_WORKER and w.alive), None)
        coverage = None if worker is None else worker.details.get("calendar_verified_until")
        if not isinstance(coverage, dict):
            return []
        today = now.date()
        warn_within = timedelta(days=self._settings.calendar_coverage_warning_days)
        assumed = (
            "regular weekday hours are assumed"
            if self._settings.calendar_extend_beyond_coverage
            else "market sessions are unknown"
        )
        alerts: list[Alert] = []
        for exchange, value in sorted(coverage.items()):
            try:
                until = date.fromisoformat(str(value))
            except ValueError:
                continue
            if until < today:
                alerts.append(
                    Alert(
                        severity="warning",
                        code="calendar_unverified",
                        message=f"No published {exchange} trading calendar after {until.isoformat()}: "
                        f"{assumed}. Update exchange_calendars or add calendar overrides",
                        subject=str(exchange),
                    )
                )
            elif until - today <= warn_within:
                alerts.append(
                    Alert(
                        severity="info",
                        code="calendar_coverage_ending",
                        message=f"The {exchange} trading calendar is published until {until.isoformat()}; "
                        "update exchange_calendars",
                        subject=str(exchange),
                    )
                )
        return alerts

    @staticmethod
    def _feed_alerts(feeds: list[StreamHealth]) -> list[Alert]:
        alerts: list[Alert] = []
        for feed in feeds:
            subject = f"{feed.provider.value}:{feed.stream_id}"
            if feed.auth_required or feed.state is ConnectionState.AUTH_REQUIRED:
                alerts.append(
                    Alert(
                        severity="critical",
                        code="provider_auth_required",
                        message=f"{feed.provider.value} needs re-authentication",
                        subject=subject,
                    )
                )
            elif feed.state in (ConnectionState.DISCONNECTED, ConnectionState.RECONNECTING):
                alerts.append(
                    Alert(
                        severity="critical" if feed.state is ConnectionState.DISCONNECTED else "warning",
                        code="provider_disconnected",
                        message=f"{feed.provider.value} stream is {feed.state.value}"
                        + (f": {feed.last_error}" if feed.last_error else ""),
                        subject=subject,
                    )
                )
            elif feed.data_status is DataStatus.STALE and feed.session_open:
                alerts.append(
                    Alert(
                        severity="warning",
                        code="feed_stale",
                        message=f"{feed.provider.value} data is stale during market hours",
                        subject=subject,
                    )
                )
        return alerts

    @staticmethod
    def _account_alerts(accounts: list[AccountHealth], now: datetime) -> list[Alert]:
        alerts: list[Alert] = []
        for account in accounts:
            if not account.is_enabled:
                continue
            subject = f"{account.provider}:{account.label}"
            expires = account.token_expires_at
            alert: tuple[Severity, str, str] | None = None
            if account.status is AccountStatus.DISCONNECTED:
                alert = ("warning", "account_disconnected", "was disconnected; log in again to stream")
            elif account.status is AccountStatus.NEEDS_CREDENTIALS:
                alert = ("warning", "credentials_missing", "is enabled but its credentials are incomplete")
            elif expires is not None and expires <= now:
                alert = ("critical", "token_expired", "access token expired; re-authenticate")
            elif account.status is AccountStatus.AUTH_REQUIRED:
                alert = ("critical", "auth_required", "needs re-authentication")
            elif expires is not None and expires - now <= _TOKEN_EXPIRY_WARNING:
                alert = ("info", "token_expiring", f"access token expires at {expires.isoformat()}")
            if alert is not None:
                severity, code, text = alert
                alerts.append(
                    Alert(severity=severity, code=code, message=f"{subject} {text}", subject=subject)
                )
        return alerts
