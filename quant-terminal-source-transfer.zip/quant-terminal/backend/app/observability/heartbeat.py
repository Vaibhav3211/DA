"""Worker liveness published to Redis so the API can report system health without RPC."""

from __future__ import annotations

import asyncio
import os
import socket
from collections.abc import Callable
from datetime import datetime
from typing import Any

from pydantic import BaseModel

from app.core.clock import utc_now
from app.core.logging import get_logger
from app.streaming.redis_bus import Keys, RedisBus

log = get_logger(__name__)

MARKET_DATA_WORKER = "market-data-worker"
STRATEGY_WORKER = "strategy-worker"
# Optional: only queued datasets and backtests need it, so its absence is not a health alert.
BACKTEST_WORKER = "backtest-worker"
EXPECTED_WORKERS = (MARKET_DATA_WORKER, STRATEGY_WORKER)


class WorkerHeartbeat(BaseModel):
    worker: str
    instance: str
    pid: int
    started_at: datetime
    heartbeat_at: datetime
    version: str
    details: dict[str, Any] = {}


class HeartbeatPublisher:
    def __init__(
        self,
        bus: RedisBus,
        worker: str,
        version: str,
        *,
        interval_seconds: float = 5.0,
        details: Callable[[], dict[str, Any]] | None = None,
    ) -> None:
        self._bus = bus
        self._worker = worker
        self._version = version
        self._interval = interval_seconds
        self._details = details or dict
        self._started_at = utc_now()
        self._instance = f"{socket.gethostname()}:{os.getpid()}"

    def snapshot(self) -> WorkerHeartbeat:
        return WorkerHeartbeat(
            worker=self._worker,
            instance=self._instance,
            pid=os.getpid(),
            started_at=self._started_at,
            heartbeat_at=utc_now(),
            version=self._version,
            details=self._details(),
        )

    async def publish_once(self) -> None:
        await self._bus.set_json(
            Keys.worker_heartbeat(self._worker), self.snapshot(), ttl_seconds=self._interval * 3
        )

    async def run(self) -> None:
        while True:
            try:
                await self.publish_once()
            except Exception as exc:  # a Redis blip must not kill the worker
                log.warning("heartbeat_publish_failed", worker=self._worker, error=type(exc).__name__)
            await asyncio.sleep(self._interval)
