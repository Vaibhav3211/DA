"""Prometheus metrics. Labels are low-cardinality only (provider, interval, strategy, reason, ...);
instrument identifiers are never used as label values."""

from __future__ import annotations

from prometheus_client import Counter, Gauge, Histogram, start_http_server

_LATENCY_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0)
_FAST_BUCKETS = (0.0005, 0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0)

# ---- market data ------------------------------------------------------------------------------
PROVIDER_TICKS = Counter(
    "qt_provider_ticks_received_total", "Raw ticks received from providers", ["provider"]
)
MARKET_EVENTS_PUBLISHED = Counter(
    "qt_market_events_published_total", "Normalized events published", ["provider", "event_type"]
)
MARKET_EVENTS_DROPPED = Counter(
    "qt_market_events_dropped_total",
    "Events dropped before publishing",
    # queue_full | malformed | invalid | duplicate | unmapped | publish_failed
    ["provider", "reason"],
)
PROVIDER_QUEUE_DEPTH = Gauge("qt_provider_queue_depth", "Events waiting in the ingest queue", ["provider"])
# ``stream`` is "<provider>:<account id>:<connection number>" (at most a few per provider account).
FEED_CONNECTED = Gauge("qt_feed_connected", "1 when the provider stream is connected", ["provider", "stream"])
FEED_RECONNECTS = Counter("qt_feed_reconnects_total", "Provider stream reconnect attempts", ["provider"])
FEED_SUBSCRIPTIONS = Gauge("qt_feed_subscriptions", "Active instrument subscriptions", ["provider", "stream"])
SOURCE_LATENCY = Histogram(
    "qt_event_source_latency_seconds",
    "Receive time minus provider/exchange timestamp",
    ["provider"],
    buckets=_LATENCY_BUCKETS,
)
PROCESSING_LATENCY = Histogram(
    "qt_event_processing_latency_seconds",
    "Receive time to publish time inside the market-data worker",
    ["provider"],
    buckets=_FAST_BUCKETS,
)
CANDLES_CLOSED = Counter("qt_candles_closed_total", "Candles closed", ["provider", "interval"])
CANDLE_LATE_EVENTS = Counter("qt_candle_late_events_total", "Events rejected as too late", ["provider"])
CANDLE_EVENTS_SKIPPED = Counter(
    "qt_candle_events_skipped_total",
    "Events that cannot contribute to candles",
    ["provider", "reason"],  # no_price | outside_session
)
CANDLES_DROPPED = Counter(
    "qt_candles_dropped_total",
    "Closed candles lost before reaching Redis or the database",
    ["reason"],  # publish_failed | persist_backlog | persist_failed
)
INSTRUMENT_REFRESHES = Counter(
    "qt_instrument_refreshes_total", "Instrument master refreshes", ["provider", "outcome"]
)

# ---- strategies and signals -------------------------------------------------------------------
STRATEGY_EVALUATIONS = Counter(
    "qt_strategy_evaluations_total",
    "Strategy evaluations",
    ["strategy", "outcome"],  # ok | error | timeout | skipped_circuit_open
)
STRATEGY_EVALUATION_SECONDS = Histogram(
    "qt_strategy_evaluation_seconds", "Strategy evaluation time", ["strategy"], buckets=_FAST_BUCKETS
)
STRATEGY_CIRCUIT_OPEN = Gauge(
    "qt_strategy_circuit_open", "1 when a deployment's circuit is open", ["strategy"]
)
SIGNALS_EMITTED = Counter(
    "qt_signals_total", "Signals persisted", ["strategy", "signal_type", "risk_outcome"]
)

# ---- API / WebSocket ----------------------------------------------------------------------------
HTTP_REQUESTS = Counter("qt_http_requests_total", "HTTP requests", ["method", "route", "status"])
HTTP_REQUEST_SECONDS = Histogram(
    "qt_http_request_seconds", "HTTP request latency", ["method", "route"], buckets=_LATENCY_BUCKETS
)
WS_CLIENTS = Gauge("qt_ws_clients", "Connected WebSocket clients")
WS_MESSAGES_SENT = Counter("qt_ws_messages_sent_total", "WebSocket messages sent", ["channel"])
WS_MESSAGES_DROPPED = Counter(
    "qt_ws_messages_dropped_total", "WebSocket messages dropped or coalesced", ["reason"]
)
WS_SLOW_CLIENT_DISCONNECTS = Counter(
    "qt_ws_slow_client_disconnects_total", "Clients disconnected for falling behind"
)

# ---- infrastructure -----------------------------------------------------------------------------
REDIS_ERRORS = Counter("qt_redis_errors_total", "Redis operation failures", ["operation"])
DB_WRITE_ERRORS = Counter("qt_db_write_errors_total", "Database write failures", ["table"])


def serve_worker_metrics(port: int, host: str = "127.0.0.1") -> None:
    """Expose this worker process's metrics on http://host:port/metrics (0 disables it)."""
    if port > 0:
        start_http_server(port, addr=host)
