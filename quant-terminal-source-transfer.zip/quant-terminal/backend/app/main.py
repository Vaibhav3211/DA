"""FastAPI application factory and the ``qt-api`` entry point."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import make_asgi_app

from app import __version__
from app.api.middleware import OriginCheckMiddleware, RequestContextMiddleware, SecurityHeadersMiddleware
from app.api.v1.router import api_router
from app.api.ws.hub import WsHub
from app.api.ws.routes import router as ws_router
from app.container import Container
from app.core.config import AppEnv, Settings, get_settings
from app.core.errors import install_exception_handlers
from app.core.logging import configure_logging, get_logger
from app.observability.health import router as health_router
from app.providers.tls import prepare_tls
from app.services.markets import MarketCalendarCache

log = get_logger(__name__)


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    configure_logging(settings.log_level, json_logs=settings.log_json)
    # Interactive docs and the schema are for local development only.
    docs_enabled = settings.app_env is AppEnv.DEVELOPMENT

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        await prepare_tls()
        container = Container.create(settings)
        app.state.container = container
        app.state.market_calendar = MarketCalendarCache(container.db, settings)
        hub = WsHub(container)
        app.state.ws_hub = hub
        log.info(
            "api_started",
            version=__version__,
            app_env=settings.app_env.value,
            simulated_mode=settings.is_simulated_mode,
            market_data_enabled=settings.market_data_enabled,
            live_signals_enabled=settings.live_signals_enabled,
        )
        try:
            yield
        finally:
            await hub.stop()
            await container.close()
            log.info("api_stopped")

    app = FastAPI(
        title="Quant Terminal API",
        version=__version__,
        description=(
            "Live market data and explainable signals for personal research. "
            "No order execution. Signals are not investment advice."
        ),
        lifespan=lifespan,
        docs_url="/docs" if docs_enabled else None,
        redoc_url=None,
        openapi_url="/openapi.json" if docs_enabled else None,
    )
    install_exception_handlers(app)

    # Added innermost first: the last middleware added wraps all the others.
    app.add_middleware(OriginCheckMiddleware, allowed_origins=settings.allowed_origins)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["Content-Type", "X-Request-ID"],
        expose_headers=["X-Request-ID"],
        max_age=600,
    )
    app.add_middleware(SecurityHeadersMiddleware, hsts=settings.cookie_secure)
    app.add_middleware(RequestContextMiddleware)

    app.include_router(health_router)
    app.include_router(api_router, prefix=settings.api_v1_prefix)
    app.include_router(ws_router)
    app.mount("/metrics", make_asgi_app())
    return app


def run() -> None:
    settings = get_settings()
    configure_logging(settings.log_level, json_logs=settings.log_json)
    uvicorn.run(
        "app.main:create_app",
        factory=True,
        host=settings.api_host,
        port=settings.api_port,
        log_config=None,
        access_log=False,
        server_header=False,
        proxy_headers=False,
        ws_max_size=64 * 1024,
        timeout_graceful_shutdown=10,
    )


if __name__ == "__main__":
    run()
