"""Provider account commands: add, inspect, enable and remove accounts, and manage stored credentials.

Logins and access tokens are handled by ``qt zerodha`` and ``qt groww`` (``app.cli.logins``).
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Collection, Mapping, Sequence
from datetime import datetime
from types import MappingProxyType
from typing import Final

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    cli_name,
    confirm,
    enum_arg,
    format_time,
    load_settings,
    print_rows,
    print_table,
    read_secret,
    run_with_container,
    shell_arg,
    yes_no,
)
from app.container import Container
from app.core.clock import utc_now
from app.domain.enums import AccountStatus, AuthMethod, CredentialKind, Provider
from app.services.audit import CLI_ACTOR
from app.services.provider_accounts import (
    CredentialOrigin,
    ProviderAccountView,
    auth_methods,
    credential_label,
    normalize_label,
    required_kinds,
    storable_kinds,
)

PROVIDER_NAMES: Final[Mapping[Provider, str]] = MappingProxyType(
    {Provider.ZERODHA: "Zerodha", Provider.GROWW: "Groww", Provider.SIMULATOR: "Simulator"}
)
PROVIDER_ARG: Final = enum_arg(Provider)
_STATUS_TEXT: Final[Mapping[AccountStatus, str]] = MappingProxyType(
    {
        AccountStatus.NEEDS_CREDENTIALS: "needs credentials",
        AccountStatus.AUTH_REQUIRED: "login required",
        AccountStatus.AUTHENTICATED: "logged in",
        AccountStatus.DISCONNECTED: "logged out",
    }
)
_KIND_FLAGS: Final[Mapping[CredentialKind, str]] = MappingProxyType(
    {
        CredentialKind.API_KEY: "--api-key",
        CredentialKind.API_SECRET: "--api-secret",
        CredentialKind.TOTP_SECRET: "--totp-secret",
    }
)
_METHOD_HELP: Final = (
    "auth method: login-redirect (Zerodha); access-token, api-key-secret or totp (Groww). "
    "Default: the provider's first one"
)
KEY_CHANGED_NOTE: Final = (
    "The Kite access token belonged to the previous API key, so it was deleted: log in again."
)


def register(commands: Subcommands) -> None:
    parser = commands.add_parser("accounts", help="manage provider accounts and their stored credentials")
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    listing = actions.add_parser("list", help="list accounts with their status")
    listing.add_argument(
        "-p", "--provider", type=PROVIDER_ARG, metavar="PROVIDER", help="only this provider's accounts"
    )
    listing.set_defaults(handler=list_accounts)

    show = actions.add_parser("show", help="show an account's settings, credentials and token")
    _account_arguments(show)
    show.set_defaults(handler=show_account)

    add = actions.add_parser("add", help="add an account (it stays disabled until you enable it)")
    add.add_argument("provider", type=PROVIDER_ARG, metavar="PROVIDER", help="zerodha, groww or simulator")
    add.add_argument("label", help="a name for the account, e.g. Main")
    add.add_argument("--method", type=method_arg, help=_METHOD_HELP)
    add.set_defaults(handler=add_account)

    update = actions.add_parser("update", help="rename an account or change its auth method")
    _account_arguments(update)
    update.add_argument("--label", help="the new name")
    update.add_argument("--method", type=method_arg, help=_METHOD_HELP)
    update.set_defaults(handler=update_account)

    for name, handler, help_text in (
        ("enable", enable_account, "stream market data from the account (one enabled account per provider)"),
        ("disable", disable_account, "stop streaming from the account"),
    ):
        action = actions.add_parser(name, help=help_text)
        _account_arguments(action)
        action.set_defaults(handler=handler)

    remove = actions.add_parser("remove", help="delete an account and its stored credentials")
    _account_arguments(remove)
    remove.add_argument("--yes", action="store_true", help="do not ask for confirmation")
    remove.set_defaults(handler=remove_account)

    store = actions.add_parser(
        "set-credentials",
        help="store API credentials, encrypted (prompts without echo; default: those the method needs)",
    )
    _account_arguments(store)
    _kind_flags(store, "store")
    store.add_argument(
        "--stdin",
        action="store_true",
        help="read the values from stdin, one per line, in the order API key, API secret, TOTP secret",
    )
    store.set_defaults(handler=set_credentials)

    clear = actions.add_parser("clear-credentials", help="delete stored credentials (default: all of them)")
    _account_arguments(clear)
    _kind_flags(clear, "delete")
    clear.add_argument("--yes", action="store_true", help="do not ask for confirmation")
    clear.set_defaults(handler=clear_credentials)


def _account_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("account", help="account label or id")
    parser.add_argument(
        "-p",
        "--provider",
        type=PROVIDER_ARG,
        metavar="PROVIDER",
        help="the account's provider, when accounts of several providers share the label",
    )


def _kind_flags(parser: argparse.ArgumentParser, verb: str) -> None:
    for kind, flag in _KIND_FLAGS.items():
        parser.add_argument(
            flag,
            dest="kinds",
            action="append_const",
            const=kind,
            help=f"{verb} the {credential_label(AuthMethod.NONE, kind)}",
        )


# ---- naming and display ----------------------------------------------------------------------


def method_name(method: AuthMethod) -> str:
    """The ``--method`` spelling: the auth method without its provider prefix, e.g. ``totp``."""
    value = method.value
    for provider in Provider:
        value = value.removeprefix(f"{provider.value}_")
    return value.lower().replace("_", "-")


def method_arg(text: str) -> AuthMethod:
    wanted = text.strip().lower().replace("_", "-")
    for method in AuthMethod:
        if wanted in (method_name(method), cli_name(method)):
            return method
    choices = ", ".join(method_name(method) for method in AuthMethod)
    raise argparse.ArgumentTypeError(f"invalid choice: '{text}' (choose from {choices})")


def join_words(words: Sequence[str], last: str = "and") -> str:
    if len(words) < 2:
        return "".join(words)
    return f"{', '.join(words[:-1])} {last} {words[-1]}"


def describe(view: ProviderAccountView) -> str:
    return f"{PROVIDER_NAMES[view.provider]} account '{view.label}'"


def status_text(view: ProviderAccountView) -> str:
    if view.provider is Provider.SIMULATOR:
        return "ready"
    return _STATUS_TEXT[view.status]


def token_text(view: ProviderAccountView, now: datetime) -> str:
    expires_at = view.token_expires_at
    if not view.has_access_token or expires_at is None:
        return "-"
    return format_time(expires_at) + ("" if expires_at > now else " (expired)")


def account_args(view: ProviderAccountView) -> str:
    """How a ``qt accounts`` command names this account."""
    return f"{shell_arg(view.label)} -p {cli_name(view.provider)}"


def login_command(view: ProviderAccountView) -> str:
    name = shell_arg(view.label)
    if view.auth_method is AuthMethod.ZERODHA_LOGIN_REDIRECT:
        return f"qt zerodha login {name}"
    if view.auth_method is AuthMethod.GROWW_ACCESS_TOKEN:
        return f"qt groww set-token {name}"
    return f"qt groww create-token {name}"


def next_step(view: ProviderAccountView) -> str | None:
    """The command that brings the account closer to streaming, when one is needed."""
    enable = f"qt accounts enable {account_args(view)}"
    if view.provider is Provider.SIMULATOR:
        return None if view.is_enabled else enable
    if view.status is AccountStatus.NEEDS_CREDENTIALS:
        return f"qt accounts set-credentials {account_args(view)}"
    if view.status in (AccountStatus.AUTH_REQUIRED, AccountStatus.DISCONNECTED):
        return login_command(view)
    return None if view.is_enabled else enable


def print_next(view: ProviderAccountView) -> None:
    step = next_step(view)
    if step is not None:
        print(f"Next: {step}", file=sys.stderr)


def stored_kinds(view: ProviderAccountView) -> list[CredentialKind]:
    """Kinds stored with the account (not taken from .env), in display order."""
    return [info.kind for info in view.credentials if info.origin is CredentialOrigin.ACCOUNT]


def kind_labels(method: AuthMethod, kinds: Collection[CredentialKind]) -> str:
    return join_words([credential_label(method, kind) for kind in _KIND_FLAGS if kind in kinds])


def _credentials_text(view: ProviderAccountView) -> str:
    parts: list[str] = []
    for info in view.credentials:
        text = info.label if info.masked is None else f"{info.label} {info.masked}"
        parts.append(text + (" (from .env)" if info.origin is CredentialOrigin.ENVIRONMENT else ""))
    return ", ".join(parts) or "none"


def account_rows(view: ProviderAccountView, now: datetime) -> list[tuple[str, str]]:
    rows = [
        ("Account", view.label),
        ("Provider", PROVIDER_NAMES[view.provider]),
        ("ID", str(view.id)),
        ("Auth method", method_name(view.auth_method)),
        ("Status", status_text(view)),
        ("Enabled", yes_no(view.is_enabled)),
    ]
    if view.streaming_disabled_reason:
        rows.append(("Streaming", f"unavailable: {view.streaming_disabled_reason}"))
    if view.provider is not Provider.SIMULATOR:
        rows.append(("Credentials", _credentials_text(view)))
        if view.missing_credentials:
            rows.append(("Missing", kind_labels(view.auth_method, view.missing_credentials)))
        rows += [
            ("Provider user", view.provider_user_ref or "-"),
            ("Last login", format_time(view.last_auth_at)),
            ("Token valid until", token_text(view, now)),
        ]
    rows += [
        ("Last connected", format_time(view.last_connected_at)),
        ("Last disconnected", format_time(view.last_disconnected_at)),
    ]
    if view.last_error_code or view.last_error_message:
        error = ": ".join(part for part in (view.last_error_code, view.last_error_message) if part)
        rows.append(("Last error", error))
    rows += [
        ("Created", f"{format_time(view.created_at)} by {view.created_by or '-'}"),
        ("Updated", f"{format_time(view.updated_at)} by {view.updated_by or '-'}"),
    ]
    return rows


def _check_method(provider: Provider, method: AuthMethod | None) -> None:
    allowed = auth_methods(provider)
    if method is not None and method not in allowed:
        names = join_words([method_name(m) for m in allowed], "or")
        raise CliError(f"{PROVIDER_NAMES[provider]} accounts use --method {names}")


async def find_account(container: Container, ref: str, provider: Provider | None) -> ProviderAccountView:
    return await _services.provider_accounts(container).resolve_ref(ref, provider=provider)


# ---- commands --------------------------------------------------------------------------------


def list_accounts(args: argparse.Namespace) -> int:
    views = run_with_container(
        load_settings(), lambda c: _services.provider_accounts(c).list_accounts(args.provider)
    )
    if not views:
        print("No provider accounts. Add one with `qt accounts add PROVIDER LABEL`.", file=sys.stderr)
        return 0
    now = utc_now()
    print_table(
        ("PROVIDER", "LABEL", "STATUS", "ENABLED", "METHOD", "TOKEN VALID UNTIL"),
        [
            (
                cli_name(view.provider),
                view.label,
                status_text(view),
                yes_no(view.is_enabled),
                method_name(view.auth_method),
                token_text(view, now),
            )
            for view in views
        ],
    )
    return 0


def show_account(args: argparse.Namespace) -> int:
    view = run_with_container(load_settings(), lambda c: find_account(c, args.account, args.provider))
    print_rows(account_rows(view, utc_now()))
    print_next(view)
    return 0


def add_account(args: argparse.Namespace) -> int:
    provider: Provider = args.provider
    label = normalize_label(args.label)
    _check_method(provider, args.method)
    view = run_with_container(
        load_settings(),
        lambda c: _services.provider_accounts(c).create(
            provider, label, auth_method=args.method, actor=CLI_ACTOR
        ),
    )
    print(f"Added {describe(view)} (method {method_name(view.auth_method)}, disabled).")
    print_next(view)
    return 0


def update_account(args: argparse.Namespace) -> int:
    if args.label is None and args.method is None:
        raise CliError("nothing to change: give --label and/or --method")
    label = None if args.label is None else normalize_label(args.label)

    async def change(container: Container) -> ProviderAccountView:
        accounts = _services.provider_accounts(container)
        view = await accounts.resolve_ref(args.account, provider=args.provider)
        _check_method(view.provider, args.method)
        return await accounts.update(view.id, label=label, auth_method=args.method, actor=CLI_ACTOR)

    view = run_with_container(load_settings(), change)
    print(f"Updated {describe(view)}: method {method_name(view.auth_method)}, {status_text(view)}.")
    print_next(view)
    return 0


def _set_enabled(args: argparse.Namespace, enabled: bool) -> ProviderAccountView:
    async def change(container: Container) -> ProviderAccountView:
        accounts = _services.provider_accounts(container)
        view = await accounts.resolve_ref(args.account, provider=args.provider)
        return await accounts.set_enabled(view.id, enabled, actor=CLI_ACTOR)

    return run_with_container(load_settings(), change)


def enable_account(args: argparse.Namespace) -> int:
    view = _set_enabled(args, True)
    print(f"Enabled {describe(view)}.")
    if view.streaming_disabled_reason:
        print(f"Streaming is unavailable: {view.streaming_disabled_reason}", file=sys.stderr)
    elif next_step(view) is None:
        print("The market-data worker will connect it.", file=sys.stderr)
    print_next(view)
    return 0


def disable_account(args: argparse.Namespace) -> int:
    view = _set_enabled(args, False)
    print(f"Disabled {describe(view)}; the market-data worker stops streaming from it.")
    return 0


def remove_account(args: argparse.Namespace) -> int:
    settings = load_settings()
    view = run_with_container(settings, lambda c: find_account(c, args.account, args.provider))
    if view.provider is Provider.ZERODHA and view.has_access_token:
        print(
            "This deletes only the local copy of its access token: run "
            f"`qt zerodha logout {shell_arg(view.label)}` first to also end the Kite session.",
            file=sys.stderr,
        )
    if not confirm(f"Remove {describe(view)} and its stored credentials?", assume_yes=args.yes):
        print("Nothing was removed.", file=sys.stderr)
        return 1
    run_with_container(settings, lambda c: _services.provider_accounts(c).delete(view.id, actor=CLI_ACTOR))
    print(f"Removed {describe(view)}.")
    return 0


def _requested_kinds(
    view: ProviderAccountView, kinds: Sequence[CredentialKind] | None
) -> list[CredentialKind]:
    """The kinds named by flags, in display order; each must be one the provider uses."""
    requested = [kind for kind in _KIND_FLAGS if kinds and kind in kinds]
    unusable = [kind for kind in requested if kind not in storable_kinds(view.provider)]
    if unusable:
        names = kind_labels(AuthMethod.NONE, unusable)
        raise CliError(f"{PROVIDER_NAMES[view.provider]} accounts do not use the {names}")
    return requested


def _kinds_to_ask(
    view: ProviderAccountView, flags: Sequence[CredentialKind] | None
) -> tuple[list[CredentialKind], list[CredentialKind]]:
    """(kinds to ask for, kinds to offer as optional)."""
    requested = _requested_kinds(view, flags)
    if requested:
        return requested, []
    required = list(required_kinds(view.auth_method))
    optional = [CredentialKind.TOTP_SECRET] if view.auth_method is AuthMethod.GROWW_TOTP else []
    if required or optional:
        return required, optional
    if view.provider is Provider.SIMULATOR:
        raise CliError("simulator accounts need no credentials")
    raise CliError(
        f"{describe(view)} uses access tokens generated in Groww Cloud and needs no stored credentials: "
        f"store a token with `qt groww set-token {shell_arg(view.label)}`, or name the credentials to "
        "store with --api-key, --api-secret or --totp-secret"
    )


def set_credentials(args: argparse.Namespace) -> int:
    settings = load_settings()

    async def lookup(container: Container) -> ProviderAccountView:
        accounts = _services.provider_accounts(container)
        accounts.vault.require()  # before asking for any value
        return await accounts.resolve_ref(args.account, provider=args.provider)

    view = run_with_container(settings, lookup)
    wanted, optional = _kinds_to_ask(view, args.kinds)
    values: dict[CredentialKind, str] = {}
    for kind in wanted:
        values[kind] = read_secret(credential_label(view.auth_method, kind), from_stdin=args.stdin)
    for kind in optional:
        label = f"{credential_label(view.auth_method, kind)} (optional, Enter to skip)"
        value = read_secret(label, from_stdin=args.stdin, required=False)
        if value is not None:
            values[kind] = value
    updated = run_with_container(
        settings,
        lambda c: _services.provider_accounts(c).set_credentials(view.id, values, actor=CLI_ACTOR),
    )
    print(f"Stored the {kind_labels(updated.auth_method, values)} of {describe(updated)}, encrypted.")
    if view.has_access_token and not updated.has_access_token:
        print(KEY_CHANGED_NOTE, file=sys.stderr)
    print_next(updated)
    return 0


def clear_credentials(args: argparse.Namespace) -> int:
    settings = load_settings()
    view = run_with_container(settings, lambda c: find_account(c, args.account, args.provider))
    requested = _requested_kinds(view, args.kinds) or None
    targets = [kind for kind in stored_kinds(view) if requested is None or kind in requested]
    if not targets:
        which = "none of those credentials" if requested else "no credentials"
        print(f"{describe(view)} has {which} stored.", file=sys.stderr)
        return 0
    question = f"Delete the stored {kind_labels(view.auth_method, targets)} of {describe(view)}?"
    if not confirm(question, assume_yes=args.yes):
        print("Nothing was deleted.", file=sys.stderr)
        return 1
    updated = run_with_container(
        settings,
        lambda c: _services.provider_accounts(c).clear_credentials(view.id, requested, actor=CLI_ACTOR),
    )
    removed = [kind for kind in stored_kinds(view) if kind not in stored_kinds(updated)]
    if removed:
        print(f"Deleted the stored {kind_labels(updated.auth_method, removed)} of {describe(updated)}.")
    else:
        print(f"Nothing was deleted: {describe(updated)} no longer stored them.", file=sys.stderr)
    if view.has_access_token and not updated.has_access_token:
        print(KEY_CHANGED_NOTE, file=sys.stderr)
    print_next(updated)
    return 0
