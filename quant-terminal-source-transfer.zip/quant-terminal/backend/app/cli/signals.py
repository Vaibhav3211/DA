"""Signal commands: list what strategies proposed, and show why.

Signals are research output for personal analysis, not investment advice, and nothing here places,
modifies or cancels orders. Signals computed from simulated data are never actionable.
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Mapping
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from types import MappingProxyType
from typing import Final
from uuid import UUID

from pydantic import ValidationError

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    cli_name,
    date_arg,
    enum_arg,
    format_time,
    load_settings,
    print_rows,
    print_table,
    run_with_container,
    yes_no,
)
from app.core.clock import IST
from app.domain.enums import Provider, SignalStatus, SignalType
from app.domain.models.signal import RiskCheck
from app.services.signals import DEFAULT_LIMIT, MAX_LIMIT, SignalDetail, SignalQuery, SignalView

_QUERY_OPTIONS: Final[Mapping[str, str]] = MappingProxyType({"limit": "--limit", "cursor": "--cursor"})


def register(commands: Subcommands) -> None:
    parser = commands.add_parser("signals", help="signal history: what strategies proposed and why")
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    listing = actions.add_parser("list", help="list signals, newest first")
    listing.add_argument("--workspace", help="only this workspace: slug or id")
    listing.add_argument("--strategy", help="only this strategy id")
    listing.add_argument("--instrument", help="only this instrument: canonical key or id")
    listing.add_argument(
        "--status",
        dest="statuses",
        type=enum_arg(SignalStatus),
        action="append",
        default=[],
        metavar="STATUS",
        help=f"only this status (repeatable): {', '.join(cli_name(item) for item in SignalStatus)}",
    )
    listing.add_argument(
        "--type",
        dest="types",
        type=enum_arg(SignalType),
        action="append",
        default=[],
        metavar="TYPE",
        help=f"only this type (repeatable): {', '.join(cli_name(item) for item in SignalType)}",
    )
    listing.add_argument(
        "--open", action="store_true", help="only open signals: generated, active or updated"
    )
    listing.add_argument(
        "--actionable",
        action=argparse.BooleanOptionalAction,
        help="only actionable signals (--no-actionable: only the others)",
    )
    listing.add_argument(
        "--since", type=date_arg, metavar="YYYY-MM-DD", help="generated on or after this day (IST)"
    )
    listing.add_argument(
        "--until", type=date_arg, metavar="YYYY-MM-DD", help="generated on or before this day (IST)"
    )
    listing.add_argument(
        "--limit",
        type=int,
        default=DEFAULT_LIMIT,
        help=f"at most this many (1-{MAX_LIMIT}; default {DEFAULT_LIMIT})",
    )
    listing.add_argument("--cursor", help="continue a previous list from where it stopped")
    listing.set_defaults(handler=list_signals)

    show = actions.add_parser(
        "show", help="show a signal: levels, reasons, indicators, risk checks and history"
    )
    show.add_argument(
        "signal_id", type=UUID, metavar="SIGNAL_ID", help="the signal's id (see qt signals list)"
    )
    show.set_defaults(handler=show_signal)


# ---- list --------------------------------------------------------------------------------------


def _start_of(day: date) -> datetime:
    return datetime.combine(day, time(), tzinfo=IST)


def _query(args: argparse.Namespace) -> SignalQuery:
    if args.since is not None and args.until is not None and args.since > args.until:
        raise CliError("--since must not be after --until")
    try:
        return SignalQuery(
            workspace=args.workspace,
            strategy_id=args.strategy,
            instrument=args.instrument,
            statuses=frozenset(args.statuses),
            signal_types=frozenset(args.types),
            open_only=args.open,
            actionable=args.actionable,
            since=None if args.since is None else _start_of(args.since),
            until=None if args.until is None else _start_of(args.until + timedelta(days=1)),
            limit=args.limit,
            cursor=args.cursor,
        )
    except ValidationError as exc:
        # Field and message only: the rejected input is not echoed.
        error = exc.errors(include_url=False, include_input=False)[0]
        field = str(error["loc"][0]) if error["loc"] else "query"
        raise CliError(f"{_QUERY_OPTIONS.get(field, field)}: {error['msg']}") from None


def list_signals(args: argparse.Namespace) -> int:
    query = _query(args)
    page = run_with_container(load_settings(), lambda c: _services.signals(c).list_signals(query))
    if not page.items:
        print("No signals match.", file=sys.stderr)
        return 0
    print_table(
        (
            "GENERATED",
            "SIGNAL",
            "WORKSPACE",
            "SYMBOL",
            "STRATEGY",
            "TYPE",
            "STATUS",
            "ACTIONABLE",
            "ENTRY",
            "STOP",
            "DATA",
        ),
        [
            (
                format_time(signal.generated_at),
                str(signal.id),
                signal.workspace_slug,
                signal.symbol,
                signal.strategy_id,
                cli_name(signal.signal_type),
                cli_name(signal.status),
                yes_no(signal.is_actionable),
                _number(signal.entry_price),
                _number(signal.stop_loss),
                cli_name(signal.provider),
            )
            for signal in page.items
        ],
    )
    if page.next_cursor is not None:
        print(f"More signals: add --cursor {page.next_cursor}", file=sys.stderr)
    return 0


# ---- show --------------------------------------------------------------------------------------


def show_signal(args: argparse.Namespace) -> int:
    detail = run_with_container(load_settings(), lambda c: _services.signals(c).get_signal(args.signal_id))
    signal = detail.signal
    print_rows(_signal_rows(signal))

    _section("Why")
    for reason in signal.reasons:
        print(f"  - {reason}")
    print(f"  {signal.explanation}")

    if signal.indicator_values:
        _section("Indicators")
        print_table(
            ("NAME", "VALUE", "INDICATOR", "INTERVAL", "CANDLES", "DATA"),
            [
                (
                    value.name,
                    _number(value.value),
                    f"{value.indicator} {value.version}",
                    "-" if value.interval is None else cli_name(value.interval),
                    str(value.input_count),
                    cli_name(value.data_status),
                )
                for value in signal.indicator_values
            ],
        )

    if signal.invalidation_conditions:
        _section("Invalidated if")
        for condition in signal.invalidation_conditions:
            print(f"  - {condition}")

    decision = signal.risk_decision
    _section(f"Risk checks: {cli_name(decision.outcome)} at {format_time(decision.evaluated_at)}")
    print_table(("RULE", "RESULT", "MESSAGE"), [(c.rule, _result(c), c.message) for c in decision.checks])

    _print_history(detail)
    print()
    print(signal.disclaimer)
    return 0


def _signal_rows(signal: SignalView) -> list[tuple[str, str]]:
    rows = [
        ("Signal", str(signal.id)),
        ("Workspace", signal.workspace_slug),
        ("Instrument", f"{signal.symbol} ({signal.exchange.value}, {cli_name(signal.segment)})"),
        ("Data source", _source(signal.provider)),
        ("Strategy", f"{signal.strategy_id} {signal.strategy_version}"),
        ("Type", cli_name(signal.signal_type)),
        ("Status", cli_name(signal.status)),
        ("Actionable", yes_no(signal.is_actionable)),
        ("Entry", _number(signal.entry_price)),
        ("Stop loss", _number(signal.stop_loss)),
        ("Targets", ", ".join(f"{t.label} {_number(t.price)}" for t in signal.targets) or "-"),
        ("Risk/reward", _number(signal.risk_reward)),
    ]
    if signal.score is not None:
        rows.append(("Score", f"{_number(signal.score)} ({signal.score_definition})"))
    rows += [
        ("Generated", format_time(signal.generated_at)),
        ("Updated", f"{format_time(signal.updated_at)} ({signal.update_count} updates)"),
        ("Valid until", format_time(signal.valid_until)),
        ("Closed", format_time(signal.closed_at)),
        ("Candle", _candle(signal)),
        ("Data status", cli_name(signal.data_status)),
    ]
    if signal.superseded_by is not None:
        rows.append(("Superseded by", str(signal.superseded_by)))
    rows += [("Deployment", str(signal.deployment_id)), ("Run", str(signal.strategy_run_id))]
    return rows


def _print_history(detail: SignalDetail) -> None:
    if len(detail.decisions) > 1:
        print(f"\nThe risk gate evaluated this signal {len(detail.decisions)} times; above is the latest.")
    if detail.events:
        _section("History")
        print_table(
            ("TIME", "EVENT", "FROM", "TO"),
            [
                (
                    format_time(event.occurred_at),
                    cli_name(event.event_type),
                    "-" if event.from_status is None else cli_name(event.from_status),
                    cli_name(event.to_status),
                )
                for event in detail.events
            ],
        )


def _section(title: str) -> None:
    print()
    print(f"{title}:")


def _source(provider: Provider) -> str:
    if provider is Provider.SIMULATOR:
        return "simulator (simulated data: never actionable)"
    return cli_name(provider)


def _candle(signal: SignalView) -> str:
    if signal.source_candle_start is None:
        return "-"
    interval = "-" if signal.source_candle_interval is None else cli_name(signal.source_candle_interval)
    return f"{interval} from {format_time(signal.source_candle_start)}"


def _result(check: RiskCheck) -> str:
    if check.passed:
        return "pass"
    return "BLOCK" if check.severity == "BLOCK" else "warn"


def _number(value: Decimal | None) -> str:
    return "-" if value is None else format(value.normalize(), "f")
