"""Provider capability commands: show what a provider supports, and record verified corrections.

The defaults in ``app.providers.capabilities`` were verified from official documentation. When a
provider changes a limit (or a plan differs), record the verified value as an override for the whole
provider or one account, together with where it was verified.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Mapping, Sequence
from typing import Any, Final, get_origin
from uuid import UUID

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    date_arg,
    load_settings,
    run_with_container,
    yes_no,
)
from app.cli.accounts import PROVIDER_ARG, PROVIDER_NAMES, find_account
from app.container import Container
from app.core.clock import IST, utc_now
from app.domain.enums import Provider
from app.domain.models import ProviderCapabilities
from app.services.audit import CLI_ACTOR
from app.services.capabilities import OVERRIDABLE_FIELDS, CapabilityOverride

_ONE_LINE: Final = 72  # longer lists print one item per line
_SET_HELP: Final = (
    'e.g. depth_levels=20, exchanges=NSE,BSE or rest_rate_limits=\'{"quote": "1/second"}\'. Lists are '
    "comma-separated or JSON; use null for no limit"
)


def register(commands: Subcommands) -> None:
    parser = commands.add_parser(
        "capabilities", help="show what a provider supports and record verified corrections"
    )
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    show = actions.add_parser("show", help="show a provider's effective capabilities and their overrides")
    show.add_argument("provider", type=PROVIDER_ARG, metavar="PROVIDER", help="zerodha, groww or simulator")
    show.add_argument("--account", help="include the overrides of this account")
    show.add_argument("--json", action="store_true", help="print the effective capabilities as JSON")
    show.set_defaults(handler=show_capabilities)

    change = actions.add_parser(
        "set", help="override fields with values verified at the provider (merged into any existing override)"
    )
    change.add_argument("provider", type=PROVIDER_ARG, metavar="PROVIDER", help="zerodha, groww or simulator")
    change.add_argument("values", nargs="+", metavar="FIELD=VALUE", help=_SET_HELP)
    change.add_argument(
        "--source", required=True, help="where the values were verified, e.g. the documentation's address"
    )
    change.add_argument(
        "--verified-on", type=date_arg, metavar="YYYY-MM-DD", help="when they were verified (default: today)"
    )
    change.add_argument("--account", help="override only for this account (default: the whole provider)")
    change.set_defaults(handler=set_capabilities)

    clear = actions.add_parser(
        "clear", help="remove overridden fields so the documented values apply (default: all of them)"
    )
    clear.add_argument("provider", type=PROVIDER_ARG, metavar="PROVIDER", help="zerodha, groww or simulator")
    clear.add_argument("fields", nargs="*", metavar="FIELD", help="the fields to remove")
    clear.add_argument("--account", help="clear this account's override (default: the provider-wide one)")
    clear.set_defaults(handler=clear_capabilities)


# ---- values ------------------------------------------------------------------------------------


def check_field(name: str) -> None:
    if name not in OVERRIDABLE_FIELDS:
        raise CliError(
            f"'{name}' is not a capability field that can be set; use one of: {', '.join(OVERRIDABLE_FIELDS)}"
        )


def parse_value(name: str, text: str) -> Any:
    """``text`` as the field's JSON value; plain text for text fields, and comma lists for lists."""
    annotation = ProviderCapabilities.model_fields[name].annotation
    if annotation is str:
        return text
    origin = get_origin(annotation)
    if origin is tuple and not text.startswith("["):
        return [part.strip() for part in text.split(",") if part.strip()]
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        if origin in (tuple, dict):
            raise CliError(f"the value of {name} is not valid JSON") from None
        return text  # the service checks it against the field's type


def parse_assignments(items: Sequence[str]) -> dict[str, Any]:
    values: dict[str, Any] = {}
    for item in items:
        name, separator, text = item.partition("=")
        name = name.strip()
        if not separator or not name:
            raise CliError(f"expected FIELD=VALUE, not '{item}'")
        check_field(name)
        if name in values:
            raise CliError(f"{name} is given more than once")
        values[name] = parse_value(name, text.strip())
    return values


def _lines(value: Any) -> list[str]:
    """A JSON-mode value for display, over several lines when long."""
    if value is None:
        return ["-"]
    if isinstance(value, bool):
        return [yes_no(value)]
    if isinstance(value, Mapping):
        return [f"{key}: {item}" for key, item in value.items()] or ["-"]
    if isinstance(value, list | tuple):
        items = [str(item) for item in value]
        joined = ", ".join(items)
        return (items if len(joined) > _ONE_LINE else [joined]) if items else ["-"]
    return [str(value)]


def _print_fields(rows: Sequence[tuple[str, Sequence[str]]]) -> None:
    width = max((len(label) for label, _ in rows), default=0)
    for label, lines in rows:
        first, *rest = lines
        print(f"{label.ljust(width)}  {first}".rstrip())
        for line in rest:
            print(f"{' ' * width}  {line}")


def _scope(provider: Provider, label: str | None) -> str:
    name = PROVIDER_NAMES[provider]
    return f"provider-wide {name}" if label is None else f"{name} account '{label}'"


async def _account(
    container: Container, ref: str | None, provider: Provider
) -> tuple[UUID | None, str | None]:
    if ref is None:
        return None, None
    view = await find_account(container, ref, provider)
    return view.id, view.label


# ---- commands ----------------------------------------------------------------------------------


def show_capabilities(args: argparse.Namespace) -> int:
    provider: Provider = args.provider

    async def load(container: Container) -> tuple[ProviderCapabilities, list[CapabilityOverride]]:
        account_id, _ = await _account(container, args.account, provider)
        service = _services.capabilities(container)
        capabilities = await service.effective(provider, account_id)
        overrides = await service.list_overrides(provider)
        return capabilities, [o for o in overrides if o.account_id is None or o.account_id == account_id]

    capabilities, overrides = run_with_container(load_settings(), load)
    values = capabilities.model_dump(mode="json")
    if args.json:
        print(json.dumps(values, indent=2, ensure_ascii=False))
        return 0
    overridden = {name for override in overrides for name in override.values}
    rows: list[tuple[str, Sequence[str]]] = []
    for name, value in values.items():
        if name == "provider":
            continue
        lines = _lines(value)
        if name in overridden:
            lines = [f"{lines[0]}  *", *lines[1:]]
        rows.append((name, lines))
    _print_fields(rows)
    if overrides:
        print()
        print("* overridden:")
        for override in overrides:
            verified = "-" if override.verified_on is None else override.verified_on.isoformat()
            print(
                f"  {_scope(provider, override.account_label)}: {', '.join(sorted(override.values))} "
                f"(verified {verified}; source: {override.verification_source})"
            )
    return 0


def set_capabilities(args: argparse.Namespace) -> int:
    provider: Provider = args.provider
    values = parse_assignments(args.values)
    verified_on = args.verified_on or utc_now().astimezone(IST).date()

    async def change(container: Container) -> CapabilityOverride:
        account_id, _ = await _account(container, args.account, provider)
        return await _services.capabilities(container).set_override(
            provider,
            values,
            verification_source=args.source,
            verified_on=verified_on,
            account_id=account_id,
            actor=CLI_ACTOR,
        )

    override = run_with_container(load_settings(), change)
    print(f"Updated the {_scope(provider, override.account_label)} override. It now sets:")
    _print_fields([(name, _lines(override.values[name])) for name in sorted(override.values)])
    return 0


def clear_capabilities(args: argparse.Namespace) -> int:
    provider: Provider = args.provider
    fields = list(dict.fromkeys(args.fields)) or None
    for name in fields or ():
        check_field(name)

    async def clear(container: Container) -> tuple[str, str | None, list[str], CapabilityOverride | None]:
        """(scope, why nothing was cleared, the fields removed, what remains)."""
        account_id, label = await _account(container, args.account, provider)
        scope = _scope(provider, label)
        service = _services.capabilities(container)
        overrides = await service.list_overrides(provider)
        current = next((o for o in overrides if o.account_id == account_id), None)
        if current is None:
            return scope, f"There is no {scope} override.", [], None
        present = sorted(current.values if fields is None else current.values.keys() & set(fields))
        if not present:
            return scope, f"The {scope} override does not set {', '.join(fields or ())}.", [], current
        remaining = await service.clear_override(
            provider, account_id=account_id, fields=fields, actor=CLI_ACTOR
        )
        return scope, None, present, remaining

    scope, note, removed, remaining = run_with_container(load_settings(), clear)
    if note is not None:
        print(note, file=sys.stderr)
        return 0
    if remaining is None:
        print(f"Deleted the {scope} override ({', '.join(removed)}); the documented values apply.")
    else:
        print(
            f"Removed {', '.join(removed)} from the {scope} override; it still sets "
            f"{', '.join(sorted(remaining.values))}."
        )
    return 0
