"""Services for CLI commands, built on a command's container.

Provider HTTP calls use ``http_transport()``, which is None (the real network) outside tests. Tests
replace it with a fake transport, so commands must reach it through these factories.
"""

from __future__ import annotations

import httpx

from app.container import Container
from app.services.backtests import BacktestService
from app.services.capabilities import CapabilityService
from app.services.datasets import DatasetService
from app.services.instruments import InstrumentService
from app.services.markets import MarketCalendarCache
from app.services.provider_accounts import ProviderAccountService
from app.services.provider_auth import ProviderAuthService
from app.services.risk import RiskRuleService
from app.services.signals import SignalService
from app.services.strategies import StrategyService
from app.services.workspaces import WorkspaceService


def http_transport() -> httpx.AsyncBaseTransport | None:
    return None


def provider_accounts(container: Container) -> ProviderAccountService:
    return ProviderAccountService.from_container(container)


def provider_auth(container: Container) -> ProviderAuthService:
    return ProviderAuthService(provider_accounts(container), transport=http_transport())


def instruments(container: Container) -> InstrumentService:
    return InstrumentService(provider_accounts(container), transport=http_transport())


def capabilities(container: Container) -> CapabilityService:
    return CapabilityService.from_container(container)


def workspaces(container: Container) -> WorkspaceService:
    return WorkspaceService(instruments(container), capabilities(container))


def strategies(container: Container) -> StrategyService:
    return StrategyService.from_container(container)


def signals(container: Container) -> SignalService:
    return SignalService.from_container(container)


def risk_rules(container: Container) -> RiskRuleService:
    return RiskRuleService.from_container(container)


def datasets(container: Container) -> DatasetService:
    return DatasetService.from_container(
        container, MarketCalendarCache(container.db, container.settings), transport=http_transport()
    )


def backtests(container: Container) -> BacktestService:
    return BacktestService.from_container(container)
