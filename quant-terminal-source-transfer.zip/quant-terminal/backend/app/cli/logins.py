"""Login commands: ``qt zerodha`` (the Kite redirect login) and ``qt groww`` (access tokens).

Logins only obtain the access tokens that market data needs; nothing here places orders.
"""

from __future__ import annotations

import argparse
import sys
from typing import Final

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    cli_name,
    format_time,
    load_settings,
    read_line,
    read_secret,
    require_console,
    run_with_container,
    shell_arg,
)
from app.cli.accounts import PROVIDER_NAMES, account_args, describe, method_name, print_next
from app.container import Container
from app.core.clock import utc_now
from app.domain.enums import AuthMethod, CredentialKind, Provider
from app.services.audit import CLI_ACTOR
from app.services.provider_accounts import ProviderAccountService, ProviderAccountView
from app.services.provider_auth import LogoutResult, ZerodhaLoginStart

_LOGIN_HINT: Final = "run `qt zerodha login` in a terminal: it asks for the address the browser lands on"


def register(commands: Subcommands) -> None:
    zerodha = commands.add_parser("zerodha", help="log a Zerodha (Kite Connect) account in or out")
    actions = zerodha.add_subparsers(dest="action", required=True, metavar="ACTION")
    login = actions.add_parser("login", help="log in on the Kite website and store the day's access token")
    _account_argument(login, Provider.ZERODHA)
    login.set_defaults(handler=zerodha_login)
    logout = actions.add_parser("logout", help="end the Kite session and delete the access token")
    _account_argument(logout, Provider.ZERODHA)
    logout.set_defaults(handler=zerodha_logout)

    groww = commands.add_parser("groww", help="store, create or delete a Groww access token")
    actions = groww.add_subparsers(dest="action", required=True, metavar="ACTION")
    set_token = actions.add_parser(
        "set-token", help="store an access token generated in Groww Cloud (prompts without echo)"
    )
    _account_argument(set_token, Provider.GROWW)
    set_token.add_argument("--token-stdin", action="store_true", help="read the token from stdin")
    set_token.add_argument(
        "--no-verify", action="store_true", help="store the token without checking it with Groww"
    )
    set_token.set_defaults(handler=groww_set_token)
    create = actions.add_parser(
        "create-token", help="create an access token with the stored API key and secret, or TOTP"
    )
    _account_argument(create, Provider.GROWW)
    create.add_argument(
        "--code", help="the authenticator's current code (TOTP method; asked for without a TOTP secret)"
    )
    create.set_defaults(handler=groww_create_token)
    logout = actions.add_parser("logout", help="delete the access token (Groww has no logout API)")
    _account_argument(logout, Provider.GROWW)
    logout.set_defaults(handler=groww_logout)


def _account_argument(parser: argparse.ArgumentParser, provider: Provider) -> None:
    parser.add_argument(
        "account",
        nargs="?",
        help=(
            f"label or id of the {PROVIDER_NAMES[provider]} account "
            "(default: the only one, else the enabled one)"
        ),
    )


async def pick_account(
    accounts: ProviderAccountService, ref: str | None, provider: Provider
) -> ProviderAccountView:
    """The named account, else the provider's only account, else its enabled one."""
    if ref is not None:
        return await accounts.resolve_ref(ref, provider=provider)
    views = await accounts.list_accounts(provider)
    enabled = [view for view in views if view.is_enabled]
    if len(views) == 1:
        return views[0]
    if enabled:
        return enabled[0]
    name = PROVIDER_NAMES[provider]
    if not views:
        add = f"qt accounts add {cli_name(provider)} LABEL"
        raise CliError(f"there is no {name} account; add one with `{add}`")
    labels = ", ".join(shell_arg(view.label) for view in views)
    raise CliError(f"there are several {name} accounts and none is enabled; name one of: {labels}")


async def _token_account(container: Container, ref: str | None, provider: Provider) -> ProviderAccountView:
    accounts = _services.provider_accounts(container)
    accounts.vault.require()  # a token must be storable: fail before the user does anything
    return await pick_account(accounts, ref, provider)


def _token_stored(view: ProviderAccountView) -> None:
    if view.is_enabled:
        print("The market-data worker will reconnect it.", file=sys.stderr)
    print_next(view)


# ---- Zerodha -----------------------------------------------------------------------------------


def zerodha_login(args: argparse.Namespace) -> int:
    require_console(_LOGIN_HINT)  # before the login starts: its address is pasted at a prompt
    settings = load_settings()

    async def begin(container: Container) -> tuple[ProviderAccountView, ZerodhaLoginStart]:
        auth = _services.provider_auth(container)
        view = await pick_account(auth.accounts, args.account, Provider.ZERODHA)
        return view, await auth.begin_zerodha_login(view.id, actor=CLI_ACTOR)

    view, start = run_with_container(settings, begin)
    print(f"Logging in {describe(view)}.")
    print("1. Open this address in a browser and log in to Kite:")
    print(f"   {start.login_url}")
    print(f"2. Kite then sends the browser to {start.redirect_url}")
    print("   Whatever that page shows, copy the full address from the browser's address bar.")
    print(f"3. Paste it here before {format_time(start.expires_at)}.")
    callback = read_line("Address after login: ", hint=_LOGIN_HINT)
    if not callback:
        raise CliError("no address was entered; run `qt zerodha login` again")
    updated = run_with_container(
        settings, lambda c: _services.provider_auth(c).complete_zerodha_login(callback, actor=CLI_ACTOR)
    )
    print(
        f"Logged in {describe(updated)} as Zerodha user {updated.provider_user_ref or '-'}; the access "
        f"token is valid until {format_time(updated.token_expires_at)}."
    )
    _token_stored(updated)
    return 0


def zerodha_logout(args: argparse.Namespace) -> int:
    return _logout(args.account, Provider.ZERODHA)


# ---- Groww -------------------------------------------------------------------------------------


def groww_set_token(args: argparse.Namespace) -> int:
    settings = load_settings()
    view = run_with_container(settings, lambda c: _token_account(c, args.account, Provider.GROWW))
    token = read_secret("Access token", from_stdin=args.token_stdin)
    updated = run_with_container(
        settings,
        lambda c: _services.provider_auth(c).set_groww_token(
            view.id, token, verify=not args.no_verify, actor=CLI_ACTOR
        ),
    )
    print(
        f"Stored the access token of {describe(updated)}; it is valid until "
        f"{format_time(updated.token_expires_at)}."
    )
    if args.no_verify:
        print(
            "It was not checked with Groww: a rejected token shows when the account connects.",
            file=sys.stderr,
        )
    if view.auth_method is not AuthMethod.GROWW_ACCESS_TOKEN:
        print(
            f"The account now uses the access-token method (it used {method_name(view.auth_method)}).",
            file=sys.stderr,
        )
    _token_stored(updated)
    return 0


def groww_create_token(args: argparse.Namespace) -> int:
    settings = load_settings()
    view = run_with_container(settings, lambda c: _token_account(c, args.account, Provider.GROWW))
    if view.auth_method is AuthMethod.GROWW_ACCESS_TOKEN:
        raise CliError(
            f"{describe(view)} uses access tokens generated in Groww Cloud: store one with "
            f"`qt groww set-token {shell_arg(view.label)}`, or switch it to an API key method with "
            f"`qt accounts update {account_args(view)} --method api-key-secret` (or totp)"
        )
    code: str | None = args.code
    has_totp_secret = any(info.kind is CredentialKind.TOTP_SECRET for info in view.credentials)
    if code is None and view.auth_method is AuthMethod.GROWW_TOTP and not has_totp_secret:
        code = read_line("Authenticator code: ", hint="pass the authenticator's current code with --code")
        if not code:
            raise CliError("no code was entered")
    updated = run_with_container(
        settings,
        lambda c: _services.provider_auth(c).create_groww_token(view.id, code=code, actor=CLI_ACTOR),
    )
    print(
        f"Created an access token for {describe(updated)}; it is valid until "
        f"{format_time(updated.token_expires_at)}."
    )
    _token_stored(updated)
    return 0


def groww_logout(args: argparse.Namespace) -> int:
    return _logout(args.account, Provider.GROWW)


# ---- logout ------------------------------------------------------------------------------------


def _logout(ref: str | None, provider: Provider) -> int:
    async def logout(container: Container) -> tuple[ProviderAccountView, LogoutResult]:
        auth = _services.provider_auth(container)
        view = await pick_account(auth.accounts, ref, provider)
        return view, await auth.disconnect(view.id, actor=CLI_ACTOR)

    before, result = run_with_container(load_settings(), logout)
    name = describe(result.account)
    expires_at = before.token_expires_at
    if not before.has_access_token:
        print(f"{name} had no access token to log out.")
    elif expires_at is None or expires_at <= utc_now():
        print(f"Deleted the expired access token of {name}.")
    elif result.remote_revoked:
        print(f"Logged out {name}: Zerodha ended the Kite session and the access token was deleted.")
    else:
        print(f"Deleted the access token of {name}.")
        until = format_time(expires_at)
        if result.remote_revoked is None:
            warning = (
                f"Groww has no logout API: the token stays valid at Groww until {until}; revoke it in "
                "Groww Cloud if it may have leaked."
            )
        else:
            warning = f"Zerodha did not confirm the logout: the Kite session may stay valid until {until}."
        print(warning, file=sys.stderr)
    return 0
