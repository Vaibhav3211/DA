"""Risk commands: the rules that gate every signal, globally or per workspace, and workspace pauses.

Rules layer up: the code default, then the global setting, then the workspace setting. Mandatory rules
can be tuned but not disabled. The signal engine reads the rules for every candidate, so a change
applies at once. The global kill switch is ``qt kill-switch``.
"""

from __future__ import annotations

import argparse
import sys
from typing import Final

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    assignments_text,
    format_time,
    load_settings,
    parse_json_assignments,
    print_rows,
    print_table,
    run_with_container,
    yes_no,
)
from app.services.audit import CLI_ACTOR
from app.services.risk import RiskRuleView

_WORKSPACE_HELP: Final = "slug (e.g. india-equity; see qt workspaces list) or id"
_RULE_HELP: Final = "rule key (see qt risk rules)"
_PARAM_HELP: Final = (
    "a parameter value, e.g. --param max_signals=5 (repeatable). Values are read as JSON, other text as "
    "text; parameters not given keep their values"
)


def register(commands: Subcommands) -> None:
    parser = commands.add_parser(
        "risk", help="the risk rules that gate every signal, and workspace pauses (see also qt kill-switch)"
    )
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    rules = actions.add_parser("rules", help="list the effective rules, globally or for a workspace")
    rules.add_argument("--workspace", help=f"the rules this workspace gets: {_WORKSPACE_HELP}")
    rules.set_defaults(handler=list_rules)

    show = actions.add_parser("show", help="show a rule: what it checks, its parameters and their source")
    show.add_argument("rule", help=_RULE_HELP)
    show.add_argument("--workspace", help=f"as this workspace gets it: {_WORKSPACE_HELP}")
    show.set_defaults(handler=show_rule)

    change = actions.add_parser("set", help="tune a rule or turn it on or off, globally or for one workspace")
    change.add_argument("rule", help=_RULE_HELP)
    change.add_argument("--workspace", help=f"for this workspace only (default: globally): {_WORKSPACE_HELP}")
    state = change.add_mutually_exclusive_group()
    state.add_argument("--enable", dest="enabled", action="store_const", const=True, help="turn the rule on")
    state.add_argument(
        "--disable",
        dest="enabled",
        action="store_const",
        const=False,
        help="turn it off (not mandatory rules)",
    )
    change.add_argument(
        "--param", dest="params", action="append", default=[], metavar="KEY=VALUE", help=_PARAM_HELP
    )
    change.set_defaults(handler=set_rule)

    reset = actions.add_parser(
        "reset", help="remove the rule's setting at one level, so the global setting or the default applies"
    )
    reset.add_argument("rule", help=_RULE_HELP)
    reset.add_argument(
        "--workspace", help=f"this workspace's setting (default: the global one): {_WORKSPACE_HELP}"
    )
    reset.set_defaults(handler=reset_rule)

    pause = actions.add_parser("pause", help="block every new signal of a workspace until it is resumed")
    pause.add_argument("workspace", help=_WORKSPACE_HELP)
    pause.add_argument("--reason", required=True, help="shown on blocked signals and kept in the audit log")
    pause.set_defaults(handler=pause_workspace)

    resume = actions.add_parser("resume", help="let a paused workspace's signals through again")
    resume.add_argument("workspace", help=_WORKSPACE_HELP)
    resume.set_defaults(handler=resume_workspace)


def list_rules(args: argparse.Namespace) -> int:
    views = run_with_container(load_settings(), lambda c: _services.risk_rules(c).list_rules(args.workspace))
    print_table(
        ("RULE", "ENABLED", "MANDATORY", "SET BY", "PARAMETERS"),
        [
            (
                view.rule_key,
                yes_no(view.enabled),
                yes_no(view.mandatory),
                view.source,
                assignments_text(view.params),
            )
            for view in views
        ],
    )
    for view in views:
        if view.error:
            print(f"warning: {view.rule_key}: {view.error}", file=sys.stderr)
    return 0


def show_rule(args: argparse.Namespace) -> int:
    view = run_with_container(
        load_settings(), lambda c: _services.risk_rules(c).get_rule(args.rule, args.workspace)
    )
    _print_rule(view)
    return 0


def set_rule(args: argparse.Namespace) -> int:
    params = parse_json_assignments(args.params, option="--param")
    if args.enabled is None and not params:
        raise CliError("nothing to change: give --enable, --disable or --param KEY=VALUE")
    view = run_with_container(
        load_settings(),
        lambda c: _services.risk_rules(c).set_rule(
            args.rule, workspace=args.workspace, enabled=args.enabled, params=params or None, actor=CLI_ACTOR
        ),
    )
    _print_rule(view)
    return 0


def reset_rule(args: argparse.Namespace) -> int:
    view = run_with_container(
        load_settings(),
        lambda c: _services.risk_rules(c).reset_rule(args.rule, workspace=args.workspace, actor=CLI_ACTOR),
    )
    _print_rule(view)
    return 0


def pause_workspace(args: argparse.Namespace) -> int:
    reason = " ".join(args.reason.split())
    if not reason:
        raise CliError("--reason cannot be blank")
    view = run_with_container(
        load_settings(),
        lambda c: _services.risk_rules(c).pause(args.workspace, reason=reason, actor=CLI_ACTOR),
    )
    _print_rule(view)
    return 0


def resume_workspace(args: argparse.Namespace) -> int:
    view = run_with_container(
        load_settings(), lambda c: _services.risk_rules(c).resume(args.workspace, actor=CLI_ACTOR)
    )
    _print_rule(view)
    return 0


def _print_rule(view: RiskRuleView) -> None:
    rows = [
        ("Rule", view.rule_key),
        ("Checks", view.description),
        ("Scope", "global" if view.workspace_slug is None else f"workspace {view.workspace_slug}"),
        ("Enabled", yes_no(view.enabled)),
        ("Mandatory", "yes: it can be tuned but not disabled" if view.mandatory else "no"),
        ("Set by", view.source),
        ("Parameters", assignments_text(view.params)),
        ("Defaults", assignments_text(view.defaults)),
    ]
    if view.updated_by is not None:
        rows.append(("Changed", f"by {view.updated_by} at {format_time(view.updated_at)}"))
    if view.error:
        rows.append(("Problem", view.error))
    print_rows(rows)
