"""Workspace commands: list workspaces, show what each streams, enable or disable one, and add or
remove its instruments. Every instrument names its source provider; adding it again with another
source changes the source (audited), and nothing ever falls back to another provider."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Callable, Mapping
from typing import Final
from uuid import UUID

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    cli_name,
    enum_arg,
    load_settings,
    print_rows,
    print_table,
    run_with_container,
    yes_no,
)
from app.cli.accounts import PROVIDER_ARG
from app.container import Container
from app.core.errors import AppError
from app.domain.enums import Provider, SubscriptionMode
from app.services.audit import CLI_ACTOR
from app.services.workspaces import (
    TAKES_NOTHING,
    EntryStatus,
    InstrumentsRejectedError,
    PreviousSource,
    UnderlyingKind,
    Universe,
    UniverseChange,
    UniverseEntry,
    WorkspaceToggle,
    WorkspaceView,
)

_WORKSPACE_HELP: Final = "slug (e.g. india-equity; see qt workspaces list) or id"
_INSTRUMENTS_HELP: Final = "canonical keys (e.g. NSE:CASH:EQUITY:INFY; see qt instruments search) or ids"


def register(commands: Subcommands) -> None:
    parser = commands.add_parser("workspaces", help="list workspaces and choose the instruments they stream")
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    listing = actions.add_parser("list", help="list the workspaces")
    listing.set_defaults(handler=list_workspaces)

    show = actions.add_parser("show", help="show a workspace, its instruments and what streams each")
    show.add_argument("workspace", help=_WORKSPACE_HELP)
    show.set_defaults(handler=show_workspace)

    enable = actions.add_parser("enable", help="stream the workspace's instruments")
    enable.add_argument("workspace", help=_WORKSPACE_HELP)
    enable.set_defaults(handler=enable_workspace)

    disable = actions.add_parser("disable", help="stop streaming for the workspace")
    disable.add_argument("workspace", help=_WORKSPACE_HELP)
    disable.set_defaults(handler=disable_workspace)

    add = actions.add_parser(
        "add", help="add instruments, streamed from one provider (adding again changes the source)"
    )
    add.add_argument("workspace", help=_WORKSPACE_HELP)
    add.add_argument(
        "provider",
        type=PROVIDER_ARG,
        metavar="PROVIDER",
        help="zerodha, groww or simulator: where the data comes from (never switched silently)",
    )
    add.add_argument("instruments", nargs="+", metavar="INSTRUMENT", help=_INSTRUMENTS_HELP)
    add.add_argument(
        "--account", help="stream through this account of the provider (default: its enabled account)"
    )
    add.add_argument(
        "--mode",
        type=enum_arg(SubscriptionMode),
        default=SubscriptionMode.QUOTE,
        metavar="MODE",
        help="ltp, quote or full (default: quote)",
    )
    add.set_defaults(handler=add_instruments)

    remove = actions.add_parser("remove", help="remove instruments from a workspace")
    remove.add_argument("workspace", help=_WORKSPACE_HELP)
    remove.add_argument("instruments", nargs="+", metavar="INSTRUMENT", help=_INSTRUMENTS_HELP)
    remove.set_defaults(handler=remove_instruments)


# ---- list and show -----------------------------------------------------------------------------


def list_workspaces(_args: argparse.Namespace) -> int:
    async def run(container: Container) -> list[WorkspaceView]:
        return await _services.workspaces(container).list_workspaces()

    views = run_with_container(load_settings(), run)
    print_table(
        ("WORKSPACE", "NAME", "REGION", "ENABLED", "INSTRUMENTS"),
        [
            (
                view.slug,
                view.name,
                cli_name(view.market_region),
                yes_no(view.is_enabled),
                str(view.instrument_count),
            )
            for view in views
        ],
    )
    return 0


def show_workspace(args: argparse.Namespace) -> int:
    async def run(container: Container) -> Universe:
        return await _services.workspaces(container).universe(args.workspace)

    universe = run_with_container(load_settings(), run)
    view = universe.workspace
    print_rows(_workspace_rows(view))
    if universe.entries:
        print()
        print_table(
            ("KEY", "PROVIDER", "ACCOUNT", "MODE", "STATUS"),
            [_entry_row(entry) for entry in universe.entries],
        )
    elif view.accepts.takes_instruments:
        print(
            f"No instruments yet. Add some: qt workspaces add {view.slug} PROVIDER INSTRUMENT... "
            "(find keys with qt instruments search)",
            file=sys.stderr,
        )
    return 0


def _workspace_rows(view: WorkspaceView) -> list[tuple[str, str]]:
    rules = view.accepts
    rows = [
        ("Workspace", view.slug),
        ("Name", view.name),
        ("Region", cli_name(view.market_region)),
        ("Kind", cli_name(view.kind)),
        ("Enabled", yes_no(view.is_enabled)),
    ]
    if rules.takes_instruments:
        rows += [
            ("Exchanges", ", ".join(rules.exchanges)),
            ("Segments", ", ".join(rules.segments) or "any"),
            ("Types", ", ".join(rules.instrument_types) or "any"),
        ]
        if rules.underlying_kind is UnderlyingKind.INDEX:
            rows.append(("Underlyings", ", ".join(rules.index_underlyings) or "none"))
        elif rules.underlying_kind is UnderlyingKind.STOCK:
            rows.append(("Underlyings", "stocks only (no index derivatives)"))
    else:
        rows.append(("Takes", f"no instruments: {TAKES_NOTHING}"))
    rows.append(("Instruments", str(view.instrument_count)))
    if view.description:
        rows.append(("Description", view.description))
    rows.append(("ID", str(view.id)))
    return rows


def _entry_row(entry: UniverseEntry) -> tuple[str, str, str, str, str]:
    return (
        entry.instrument.canonical_key,
        cli_name(entry.provider),
        "-" if entry.account is None else entry.account.label,
        cli_name(entry.mode),
        _status(entry),
    )


def _status(entry: UniverseEntry) -> str:
    if entry.status is EntryStatus.WORKSPACE_DISABLED:
        return "workspace disabled"
    if entry.status is EntryStatus.PLANNED and entry.streamed_by is not None:
        return f"planned ({entry.streamed_by.label})"
    return f"skipped: {entry.detail}"


# ---- enable and disable ------------------------------------------------------------------------


def enable_workspace(args: argparse.Namespace) -> int:
    toggle = _set_enabled(args.workspace, True)
    slug = toggle.workspace.slug
    print(f"Enabled workspace '{slug}'." if toggle.changed else f"Workspace '{slug}' is already enabled.")
    if not toggle.workspace.instrument_count:
        print(f"It has no instruments yet: qt workspaces add {slug} PROVIDER INSTRUMENT...", file=sys.stderr)
    _worker_note(toggle.published)
    return 0


def disable_workspace(args: argparse.Namespace) -> int:
    toggle = _set_enabled(args.workspace, False)
    slug = toggle.workspace.slug
    if toggle.changed:
        print(
            f"Disabled workspace '{slug}'; its instruments stream only while another enabled workspace "
            "wants them from the same provider."
        )
    else:
        print(f"Workspace '{slug}' is already disabled.")
    _worker_note(toggle.published)
    return 0


def _set_enabled(workspace: str, enabled: bool) -> WorkspaceToggle:
    async def run(container: Container) -> WorkspaceToggle:
        return await _services.workspaces(container).set_enabled(workspace, enabled, actor=CLI_ACTOR)

    return run_with_container(load_settings(), run)


# ---- add and remove ----------------------------------------------------------------------------


def add_instruments(args: argparse.Namespace) -> int:
    provider: Provider = args.provider
    mode: SubscriptionMode = args.mode

    async def run(container: Container) -> tuple[UniverseChange, Universe | str]:
        service = _services.workspaces(container)
        account_id: UUID | None = None
        if args.account is not None:
            account_id = (await service.instruments.accounts.resolve_ref(args.account, provider=provider)).id
        change = await service.add_instruments(
            args.workspace, args.instruments, provider, account_id=account_id, mode=mode, actor=CLI_ACTOR
        )
        try:
            return change, await service.universe(change.workspace.slug)
        except AppError as exc:  # the change is made; only its status is unknown
            return change, exc.message

    change, universe = _changing(lambda: run_with_container(load_settings(), run))
    statuses = _statuses(universe)
    rows = [(item.canonical_key, "added", statuses.get(item.id, "-")) for item in change.added]
    rows += [
        (
            item.instrument.canonical_key,
            f"changed (was {_source(item)})",
            statuses.get(item.instrument.id, "-"),
        )
        for item in change.changed
    ]
    rows += [(item.canonical_key, "unchanged", statuses.get(item.id, "-")) for item in change.unchanged]
    print_table(("KEY", "CHANGE", "STATUS"), rows)
    if isinstance(universe, str):
        print(f"Their status is unknown: {universe}", file=sys.stderr)
    slug = change.workspace.slug
    if not change.workspace.is_enabled:
        print(
            f"Workspace '{slug}' is disabled: they stream once it is enabled (qt workspaces enable {slug}).",
            file=sys.stderr,
        )
    _worker_note(change.published)
    return 0


def remove_instruments(args: argparse.Namespace) -> int:
    async def run(container: Container) -> UniverseChange:
        return await _services.workspaces(container).remove_instruments(
            args.workspace, args.instruments, actor=CLI_ACTOR
        )

    change = _changing(lambda: run_with_container(load_settings(), run))
    rows = [(item.canonical_key, "removed") for item in change.removed]
    rows += [(item.canonical_key, "not in the workspace") for item in change.absent]
    print_table(("KEY", "CHANGE"), rows)
    _worker_note(change.published)
    return 0


def _changing[T](operation: Callable[[], T]) -> T:
    try:
        return operation()
    except InstrumentsRejectedError as exc:
        lines = "".join(f"\n  {key}: {reason}" for key, reason in exc.problems)
        raise CliError(f"nothing was {exc.action} workspace '{exc.workspace}':{lines}") from None


def _statuses(universe: Universe | str) -> Mapping[UUID, str]:
    if isinstance(universe, str):
        return {}
    return {entry.instrument.id: _status(entry) for entry in universe.entries}


def _source(previous: PreviousSource) -> str:
    account = "" if previous.account is None else f" ({previous.account.label})"
    return f"{cli_name(previous.provider)}{account}, {cli_name(previous.mode)}"


def _worker_note(published: bool | None) -> None:
    if published is None:
        return
    if published:
        print("Asked the market-data workers to update their subscriptions.", file=sys.stderr)
    else:
        print(
            "The market-data workers were not notified (Redis unavailable); they catch up when they next "
            "reconcile.",
            file=sys.stderr,
        )
