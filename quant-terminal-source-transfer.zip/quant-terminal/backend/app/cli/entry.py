"""Argument parsing and error handling for the ``qt`` command."""

from __future__ import annotations

import argparse
import io
import sys
from collections.abc import Sequence

from app import __version__
from app.cli import (
    accounts,
    backtests,
    capabilities,
    datasets,
    instruments,
    logins,
    risk,
    signals,
    strategies,
    system,
    workspaces,
)
from app.cli._console import CliError
from app.core.errors import AppError
from app.core.logging import configure_logging, redact_text


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qt",
        description=(
            "Quant Terminal administration. Live market data and signals only: nothing here places, "
            "modifies or cancels orders."
        ),
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="show info logs and full tracebacks on errors"
    )
    commands = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")
    for module in (
        system,
        accounts,
        logins,
        instruments,
        capabilities,
        workspaces,
        strategies,
        signals,
        risk,
        datasets,
        backtests,
    ):
        module.register(commands)
    return parser


def _tolerate_unencodable_output() -> None:
    # Redirected output on Windows uses the ANSI code page; never crash on a character it lacks.
    for stream in (sys.stdout, sys.stderr):
        if isinstance(stream, io.TextIOWrapper):
            stream.reconfigure(errors="replace")


def main(argv: Sequence[str] | None = None) -> int:
    _tolerate_unencodable_output()
    args = build_parser().parse_args(argv)
    # Logs go to stderr so stdout carries only command output (e.g. `qt generate-key > key.txt`).
    configure_logging("INFO" if args.verbose else "WARNING", json_logs=False, stream=sys.stderr)
    try:
        return int(args.handler(args))
    except CliError as exc:
        print(f"error: {exc.message}", file=sys.stderr)
        return exc.exit_code
    except AppError as exc:
        print(f"error: {exc.message}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("aborted", file=sys.stderr)
        return 130
    except Exception as exc:
        if args.verbose:
            raise
        message = redact_text(str(exc)) or "(no message)"
        print(f"error: {type(exc).__name__}: {message}  (re-run with --verbose for details)", file=sys.stderr)
        return 1
