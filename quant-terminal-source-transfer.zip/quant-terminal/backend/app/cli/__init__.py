"""The ``qt`` administration command line. It manages local setup and data; it never places orders."""

from app.cli.entry import main

__all__ = ["main"]
