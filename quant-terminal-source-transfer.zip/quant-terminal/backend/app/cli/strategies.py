"""Strategy commands: the catalogue, saved configurations and their runs.

Strategies only propose signals: nothing here places, modifies or cancels orders. A saved configuration
names a strategy, its settings and its instrument scope in a workspace, and its live signals start off.
Once they are on, the strategy worker (qt-strategy-worker) monitors it on the server, whether or not a
chart is open, until they are turned off; the worker picks up every change by itself.
"""

from __future__ import annotations

import argparse
import re
import sys
from collections.abc import Mapping, Sequence
from typing import Any, Final
from uuid import UUID

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    assignments_text,
    cli_name,
    format_time,
    json_text,
    load_settings,
    parse_json_assignments,
    print_rows,
    print_table,
    run_with_container,
    shell_arg,
    yes_no,
)
from app.container import Container
from app.domain.enums import MonitoringState, ScopeKind
from app.market_data.instruments.canonical import normalize_symbol
from app.services.audit import CLI_ACTOR
from app.services.strategies import (
    MAX_RUNS,
    CatalogueSync,
    DeploymentView,
    RunView,
    Scope,
    StrategyView,
)
from app.strategies.custom import CUSTOM_STRATEGIES
from app.strategies.registry import (
    BUILTIN_STRATEGIES,
    EXAMPLE_STRATEGIES,
    StrategyRegistrationError,
)
from app.strategies.registry import (
    register as register_strategy,
)

_WORKSPACE_HELP: Final = "slug (e.g. india-equity; see qt workspaces list) or id"
_STRATEGY_HELP: Final = "strategy id (see qt strategies list)"
_CONFIG_HELP: Final = "saved configuration: its label (see qt strategies deployments) or id"
_SET_HELP: Final = (
    "a setting, e.g. --set stop_atr_multiple=1.5 (repeatable). Values are read as JSON, other text as "
    "text. Settings not given keep their saved values (the strategy's defaults for a new configuration)"
)
_BOUNDS: Final = (("minimum", ">="), ("exclusiveMinimum", ">"), ("maximum", "<="), ("exclusiveMaximum", "<"))
_ERROR_WIDTH: Final = 60
_ATTENTION: Final = (MonitoringState.BLOCKED, MonitoringState.FAILED)
# Labels a shell passes on unchanged once double-quoted: words of letters, digits, '.', '_' and '-'.
_PLAIN_LABEL: Final = re.compile(r"\w[\w.-]*(?: [\w.-]+)*")


def register(commands: Subcommands) -> None:
    parser = commands.add_parser("strategies", help="the strategy catalogue, saved configurations and runs")
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    actions.add_parser("list", help="list the strategies in the catalogue").set_defaults(
        handler=list_strategies
    )

    show = actions.add_parser("show", help="show a strategy: what it needs and how it is configured")
    show.add_argument("strategy", help=_STRATEGY_HELP)
    show.set_defaults(handler=show_strategy)

    actions.add_parser(
        "check", help="validate every strategy in the code, yours included, without touching the database"
    ).set_defaults(handler=check_strategies)

    actions.add_parser(
        "sync", help="bring the catalogue up to date with the code (the strategy worker does it at start)"
    ).set_defaults(handler=sync_catalogue)

    deployments = actions.add_parser(
        "deployments", help="list saved configurations and how their live monitoring is doing"
    )
    deployments.add_argument("--workspace", help=f"only this workspace: {_WORKSPACE_HELP}")
    deployments.add_argument("--strategy", help="only this strategy")
    deployments.add_argument("--all", action="store_true", help="include archived configurations")
    deployments.set_defaults(handler=list_deployments)

    status = actions.add_parser(
        "status", help="show a saved configuration: settings, scope, monitoring state and last run"
    )
    _target(status)
    status.set_defaults(handler=deployment_status)

    create = actions.add_parser(
        "create", help="save a configuration of a strategy in a workspace (its live signals start off)"
    )
    create.add_argument("workspace", help=_WORKSPACE_HELP)
    create.add_argument("strategy", help=_STRATEGY_HELP)
    _scope_options(create, required=True)
    create.add_argument(
        "--label", help="its name, unique in the workspace (default: the strategy id, numbered if taken)"
    )
    _settings_option(create)
    create.set_defaults(handler=create_configuration)

    update = actions.add_parser(
        "update",
        help="save a configuration again: move it to the code's version, rename it, or change its "
        "settings or scope",
    )
    _target(update)
    _scope_options(update, required=False)
    update.add_argument("--label", help="rename it")
    _settings_option(update)
    update.add_argument(
        "--reset-config", action="store_true", help="start from the defaults rather than the saved settings"
    )
    update.set_defaults(handler=update_configuration)

    enable = actions.add_parser(
        "enable", help="turn live signals on: the strategy worker monitors it until they are turned off"
    )
    _target(enable)
    enable.set_defaults(handler=enable_deployment)

    disable = actions.add_parser("disable", help="turn live signals off (stops monitoring)")
    _target(disable)
    disable.set_defaults(handler=disable_deployment)

    archive = actions.add_parser(
        "archive", help="archive a configuration whose live signals are off; its runs and signals stay"
    )
    _target(archive)
    archive.set_defaults(handler=archive_configuration)

    runs = actions.add_parser("runs", help="list recent runs, newest first")
    runs.add_argument("--workspace", help=f"only this workspace: {_WORKSPACE_HELP}")
    runs.add_argument("--strategy", help="only this strategy")
    runs.add_argument("--config", help=f"only this {_CONFIG_HELP} (needs --workspace)")
    runs.add_argument("--limit", type=int, default=20, help=f"at most this many (1-{MAX_RUNS}; default 20)")
    runs.set_defaults(handler=list_runs)


def _target(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("workspace", help=_WORKSPACE_HELP)
    parser.add_argument("config", help=_CONFIG_HELP)


def _scope_options(parser: argparse.ArgumentParser, *, required: bool) -> None:
    scope = parser.add_mutually_exclusive_group(required=required)
    scope.add_argument(
        "--instrument",
        dest="instruments",
        action="extend",
        nargs="+",
        metavar="INSTRUMENT",
        help="watch these instruments of the workspace: canonical keys or ids (repeatable)"
        + ("" if required else "; replaces the scope"),
    )
    scope.add_argument(
        "--whole-workspace",
        action="store_true",
        help="watch every instrument of the workspace, including those added later",
    )


def _settings_option(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--set", dest="values", action="append", default=[], metavar="KEY=VALUE", help=_SET_HELP
    )


# ---- catalogue ---------------------------------------------------------------------------------


def list_strategies(_args: argparse.Namespace) -> int:
    views = run_with_container(load_settings(), lambda c: _services.strategies(c).list_strategies())
    if not views:
        print("The catalogue is empty: run qt strategies sync.", file=sys.stderr)
        return 0
    print_table(
        ("STRATEGY", "VERSION", "NAME", "AVAILABLE", "ACTIONABLE", "CONFIGURATIONS"),
        [
            (
                view.strategy_id,
                view.version,
                view.name,
                yes_no(view.is_available),
                yes_no(view.can_emit_actionable),
                _deployment_count(view),
            )
            for view in views
        ],
    )
    return 0


def show_strategy(args: argparse.Namespace) -> int:
    view = run_with_container(load_settings(), lambda c: _services.strategies(c).get_strategy(args.strategy))
    meta = view.metadata
    print_rows(
        [
            ("Strategy", view.strategy_id),
            ("Name", view.name),
            ("Version", view.version),
            ("Author", view.author),
            ("Example", yes_no(view.is_example)),
            ("Available", "yes" if view.is_available else "no: it left the code; its history stays readable"),
            ("Actionable", "can propose actionable signals" if view.can_emit_actionable else "no"),
            ("Markets", _listed(meta.get("markets"))),
            ("Exchanges", _listed(meta.get("exchanges"), empty="any in its markets")),
            ("Segments", _listed(meta.get("segments"))),
            ("Types", _listed(meta.get("instrument_types"))),
            ("Instruments", ", ".join(meta.get("instrument_keys") or ()) or "any that match the above"),
            ("Candles", _listed(meta.get("candle_intervals"))),
            ("Events", _listed(meta.get("event_types"))),
            ("Warm-up", f"{meta.get('warmup_candles', 0)} candles"),
            ("Indicators", ", ".join(_indicator(item) for item in meta.get("indicators") or ()) or "-"),
            ("Data needed", _listed(view.data_requirements, empty="prices only")),
            ("Configurations", _deployment_count(view)),
            ("Code", view.code_fingerprint[:12]),
            ("Description", view.description),
        ]
    )
    if view.default_config:
        properties = view.config_schema.get("properties", {})
        print()
        print_table(
            ("SETTING", "DEFAULT", "ALLOWED", "DESCRIPTION"),
            [
                (
                    key,
                    json_text(value),
                    _limits(properties.get(key, {})),
                    str(properties.get(key, {}).get("description", "")),
                )
                for key, value in view.default_config.items()
            ],
        )
    conditions = [item for item in meta.get("signal_conditions") or () if isinstance(item, Mapping)]
    if conditions:
        print()
        print_table(
            ("SIGNAL", "INPUTS", "CONDITION"),
            [
                (
                    str(item.get("signal_type")),
                    ", ".join(item.get("inputs") or ()),
                    str(item.get("description")),
                )
                for item in conditions
            ],
        )
    else:
        print("\nNo signal conditions are declared for this version.")
    return 0


def _deployment_count(view: StrategyView) -> str:
    """Its saved configurations that are not archived, and how many of them have live signals on."""
    return f"{view.deployments} ({view.enabled_deployments} enabled)"


def _listed(values: Any, *, empty: str = "-") -> str:
    """Enum values from the metadata, named as the rest of the CLI names them."""
    return ", ".join(str(value).lower().replace("_", "-") for value in values) if values else empty


def check_strategies(_args: argparse.Namespace) -> int:
    """Register every strategy in the code as the API and the strategy worker do, reporting every
    problem rather than stopping at the first."""
    rows: list[tuple[str, ...]] = []
    problems: list[str] = []
    seen: set[str] = set()
    for cls in BUILTIN_STRATEGIES:
        try:
            entry = register_strategy(cls)
        except StrategyRegistrationError as exc:
            problems.append(str(exc))
            continue
        if entry.strategy_id in seen:
            problems.append(f"duplicate strategy id {entry.strategy_id!r}")
        seen.add(entry.strategy_id)
        rows.append(
            (
                entry.strategy_id,
                entry.version,
                "example" if cls in EXAMPLE_STRATEGIES else "yours",
                ", ".join(sorted(signal_type.value for signal_type in entry.metadata.signal_types)),
                ", ".join(f"{interval.value}: {count}" for interval, count in entry.warmups.items()) or "-",
                _listed(sorted(entry.data_requirements), empty="prices only"),
            )
        )
    if rows:
        print_table(("STRATEGY", "VERSION", "SOURCE", "SIGNALS", "WARM-UP CANDLES", "DATA NEEDED"), rows)
    for problem in problems:
        print(f"error: {problem}", file=sys.stderr)
    if problems:
        return 1
    print(
        f"\nEvery strategy passes registration ({len(CUSTOM_STRATEGIES)} of them yours, from "
        "app/strategies/custom). Restart the API and the strategy worker to load code changes; the worker "
        "then syncs the catalogue."
    )
    return 0


def _indicator(item: Any) -> str:
    if not isinstance(item, Mapping):
        return str(item)
    params = item.get("params") or {}
    arguments = f"({assignments_text(params)})" if params else ""
    return f"{item.get('alias')}={item.get('indicator')}{arguments} {item.get('interval')}"


def _limits(prop: Mapping[str, Any]) -> str:
    """The bounds a JSON schema property sets, including those of its ``anyOf`` branches."""
    parts: list[str] = []
    for source in (prop, *(branch for branch in prop.get("anyOf", ()) if isinstance(branch, Mapping))):
        for key, sign in _BOUNDS:
            text = f"{sign} {json_text(source[key])}" if key in source else None
            if text is not None and text not in parts:
                parts.append(text)
    return ", ".join(parts) or "-"


def sync_catalogue(_args: argparse.Namespace) -> int:
    result = run_with_container(
        load_settings(), lambda c: _services.strategies(c).sync_catalogue(actor=CLI_ACTOR)
    )
    if not result.changed:
        print("The catalogue is up to date.")
        return 0
    print_rows([(label, ", ".join(items)) for label, items in _sync_rows(result) if items])
    if result.code_changed:
        print(
            "warning: strategy code changed without a version bump; bump the version so runs and signals "
            "name the code they used",
            file=sys.stderr,
        )
    return 0


def _sync_rows(result: CatalogueSync) -> list[tuple[str, tuple[str, ...]]]:
    return [
        ("Added", result.added),
        ("Restored", result.restored),
        ("New versions", result.upgraded),
        ("Code changed", result.code_changed),
        ("Unavailable", result.unavailable),
    ]


# ---- saved configurations ----------------------------------------------------------------------


def list_deployments(args: argparse.Namespace) -> int:
    views = run_with_container(
        load_settings(),
        lambda c: _services.strategies(c).list_deployments(
            args.workspace, strategy_id=args.strategy, include_archived=args.all
        ),
    )
    if not views:
        print(
            "No saved configurations. Save one: qt strategies create WORKSPACE STRATEGY "
            "--instrument INSTRUMENT (or --whole-workspace)",
            file=sys.stderr,
        )
        return 0
    print_table(
        (
            "WORKSPACE",
            "CONFIGURATION",
            "STRATEGY",
            "VERSION",
            "SCOPE",
            "LIVE SIGNALS",
            "MONITORING",
            "LAST RUN",
        ),
        [
            (
                view.workspace_slug,
                view.label,
                view.strategy_id,
                view.strategy_version,
                _scope_text(view),
                _live_text(view),
                "-" if view.monitoring is None else cli_name(view.monitoring.state),
                "-"
                if view.last_run is None
                else f"{cli_name(view.last_run.status)} {_run_time(view.last_run)}",
            )
            for view in views
        ],
    )
    attention = sum(
        1 for view in views if view.monitoring is not None and view.monitoring.state in _ATTENTION
    )
    if attention:
        print(
            f"\n{attention} blocked or failed; see why: qt strategies status WORKSPACE CONFIGURATION",
            file=sys.stderr,
        )
    return 0


def deployment_status(args: argparse.Namespace) -> int:
    async def run(container: Container) -> tuple[DeploymentView, dict[UUID, str]]:
        service = _services.strategies(container)
        view = await service.get_deployment(await service.resolve_deployment(args.workspace, args.config))
        return view, await _instrument_keys(container, view)

    _print_deployment(*run_with_container(load_settings(), run))
    return 0


def create_configuration(args: argparse.Namespace) -> int:
    config = parse_json_assignments(args.values, option="--set")

    async def run(container: Container) -> tuple[DeploymentView, dict[UUID, str]]:
        scope = await _scope(container, args)
        if scope is None:  # argparse already requires one of the scope options
            raise CliError("choose its instruments with --instrument, or --whole-workspace")
        view = await _services.strategies(container).create_configuration(
            args.workspace,
            args.strategy,
            scope=scope,
            label=args.label,
            config=config or None,
            actor=CLI_ACTOR,
        )
        return view, await _instrument_keys(container, view)

    view, keys = run_with_container(load_settings(), run)
    _print_deployment(view, keys)
    print(
        f"Its live signals are off. Turn them on: qt strategies enable {view.workspace_slug} "
        f"{_config_ref(view)}",
        file=sys.stderr,
    )
    return 0


def update_configuration(args: argparse.Namespace) -> int:
    config = parse_json_assignments(args.values, option="--set")

    async def run(container: Container) -> tuple[DeploymentView, dict[UUID, str]]:
        service = _services.strategies(container)
        deployment_id = await service.resolve_deployment(args.workspace, args.config)
        view = await service.update_configuration(
            deployment_id,
            label=args.label,
            scope=await _scope(container, args),
            config=config or None,
            reset_config=args.reset_config,
            actor=CLI_ACTOR,
        )
        return view, await _instrument_keys(container, view)

    view, keys = run_with_container(load_settings(), run)
    _print_deployment(view, keys)
    if view.is_enabled:
        print("Its live signals are on: the strategy worker picks up the change by itself.", file=sys.stderr)
    return 0


def enable_deployment(args: argparse.Namespace) -> int:
    return _set_enabled(args, enabled=True)


def disable_deployment(args: argparse.Namespace) -> int:
    return _set_enabled(args, enabled=False)


def _set_enabled(args: argparse.Namespace, *, enabled: bool) -> int:
    async def run(container: Container) -> tuple[DeploymentView, dict[UUID, str]]:
        service = _services.strategies(container)
        deployment_id = await service.resolve_deployment(args.workspace, args.config)
        view = await service.set_enabled(deployment_id, enabled, actor=CLI_ACTOR)
        return view, await _instrument_keys(container, view)

    view, keys = run_with_container(load_settings(), run)
    _print_deployment(view, keys)
    if enabled:
        print(
            "Its live signals are on. The strategy worker (qt-strategy-worker) monitors it on the server, "
            "whether or not a chart is open, until you turn them off: qt strategies disable "
            f"{view.workspace_slug} {_config_ref(view)}",
            file=sys.stderr,
        )
    else:
        print("Its live signals are off, so monitoring stops. Its runs and signals stay.", file=sys.stderr)
    return 0


def archive_configuration(args: argparse.Namespace) -> int:
    async def run(container: Container) -> DeploymentView:
        service = _services.strategies(container)
        deployment_id = await service.resolve_deployment(args.workspace, args.config)
        return await service.archive(deployment_id, actor=CLI_ACTOR)

    view = run_with_container(load_settings(), run)
    print(
        f"Configuration '{view.label}' of workspace '{view.workspace_slug}' is archived "
        f"({format_time(view.archived_at)}); its runs and signals stay. Its id: {view.id}"
    )
    return 0


async def _scope(container: Container, args: argparse.Namespace) -> Scope | None:
    """The scope the options choose; None when they choose none."""
    if args.whole_workspace:
        return Scope.workspace()
    if args.instruments:
        return Scope.instruments(await _scope_ids(container, args.workspace, args.instruments))
    return None


async def _scope_ids(container: Container, workspace: str, refs: Sequence[str]) -> list[UUID]:
    """The workspace instruments ``refs`` name (canonical keys or ids), in order, each once."""
    universe = await _services.workspaces(container).universe(workspace)
    by_key = {entry.instrument.canonical_key: entry.instrument.id for entry in universe.entries}
    members = set(by_key.values())
    chosen: dict[UUID, None] = {}
    unknown: list[str] = []
    for ref in refs:
        text = ref.strip()
        try:
            instrument_id: UUID | None = UUID(text)
        except ValueError:
            instrument_id = by_key.get(normalize_symbol(text))
        if instrument_id is None or instrument_id not in members:
            unknown.append(text)
        else:
            chosen[instrument_id] = None
    if unknown:
        slug = universe.workspace.slug
        raise CliError(
            f"not instruments of workspace '{slug}': {', '.join(unknown)} (see qt workspaces show {slug})"
        )
    return list(chosen)


async def _instrument_keys(container: Container, view: DeploymentView) -> dict[UUID, str]:
    """The canonical keys of the workspace's instruments, when the scope lists instruments."""
    if not view.instrument_ids:
        return {}
    universe = await _services.workspaces(container).universe(str(view.workspace_id))
    return {entry.instrument.id: entry.instrument.canonical_key for entry in universe.entries}


def _config_ref(view: DeploymentView) -> str:
    """How a suggested command names the configuration: its label when a shell passes it on unchanged,
    otherwise its id."""
    return shell_arg(view.label) if _PLAIN_LABEL.fullmatch(view.label) else str(view.id)


def _print_deployment(view: DeploymentView, keys: Mapping[UUID, str]) -> None:
    rows = [
        ("Configuration", view.label),
        ("Workspace", view.workspace_slug),
        ("Strategy", f"{view.strategy_id} {view.strategy_version}"),
        ("Code", view.code_fingerprint[:12] if view.code_fingerprint else "- (not in the code any more)"),
        ("Live signals", _enabled(view)),
        *_monitoring_rows(view),
    ]
    if view.scope_kind is ScopeKind.WORKSPACE:
        rows.append(("Scope", "the whole workspace, including instruments added later"))
    else:
        rows.append(("Scope", _scope_text(view)))
        rows += [("", keys.get(item, f"{item} (no longer in the workspace)")) for item in view.instrument_ids]
    rows += [("Settings", assignments_text(view.config)), ("Settings hash", view.config_hash[:12])]
    if view.last_run is not None:
        rows += _run_rows(view.last_run, view)
    rows.append(("ID", str(view.id)))
    print_rows(rows)


def _enabled(view: DeploymentView) -> str:
    if view.archived_at is not None:
        return f"off; archived {format_time(view.archived_at)}"
    if view.is_enabled:
        return f"on, by {view.enabled_by or '-'} since {format_time(view.enabled_at)}"
    return "off" if view.disabled_at is None else f"off since {format_time(view.disabled_at)}"


def _live_text(view: DeploymentView) -> str:
    if view.archived_at is not None:
        return "archived"
    return "on" if view.is_enabled else "off"


def _scope_text(view: DeploymentView) -> str:
    if view.scope_kind is ScopeKind.WORKSPACE:
        return "whole workspace"
    count = len(view.instrument_ids)
    return f"{count} instrument{'' if count == 1 else 's'}"


def _monitoring_rows(view: DeploymentView) -> list[tuple[str, str]]:
    monitoring = view.monitoring
    if monitoring is None:
        return []
    rows = [("Monitoring", cli_name(monitoring.state))]
    rows += [("Because" if index == 0 else "", reason) for index, reason in enumerate(monitoring.reasons)]
    warmup = monitoring.warmup
    if warmup is not None:
        needs = ", ".join(f"{count} more {interval}" for interval, count in warmup.remaining.items())
        rows.append(
            (
                "Warm-up",
                f"{warmup.instruments} of {warmup.of} instruments still need closed candles"
                + (f" (at most {needs} candles)" if needs else ""),
            )
        )
    rows += [("Warnings" if index == 0 else "", text) for index, text in enumerate(monitoring.warnings)]
    return rows


def _run_time(run: RunView) -> str:
    if run.stopped_at is None:
        return f"since {format_time(run.started_at)}"
    return f"{format_time(run.started_at)} to {format_time(run.stopped_at)}"


def _run_rows(run: RunView, view: DeploymentView) -> list[tuple[str, str]]:
    rows = [("Last run", f"{cli_name(run.status)} {_run_time(run)} on {run.worker_id}")]
    if (run.strategy_version, run.config_hash) != (view.strategy_version, view.config_hash):
        rows.append(
            ("", f"it ran {run.strategy_version} with settings {run.config_hash[:12]}, saved earlier")
        )
    covered = f"{run.instruments} instrument{'' if run.instruments == 1 else 's'}"
    rows += [
        ("Covered", covered + (f", {run.excluded} left out" if run.excluded else "")),
        (
            "Processed",
            f"{run.candles_processed} candles, {run.events_processed} events, {run.signals_emitted} signals",
        ),
    ]
    if run.failures or run.timeouts:
        rows.append(("Problems", f"{run.failures} failures, {run.timeouts} timeouts"))
    if run.circuit_opened_at is not None:
        rows.append(("Circuit open", format_time(run.circuit_opened_at)))
    if run.last_error:
        rows.append(("Last error", run.last_error))
    return rows


# ---- runs --------------------------------------------------------------------------------------


def list_runs(args: argparse.Namespace) -> int:
    if args.config is not None and args.workspace is None:
        raise CliError("--config needs --workspace")

    async def run(container: Container) -> list[RunView]:
        service = _services.strategies(container)
        deployment_id = (
            None if args.config is None else await service.resolve_deployment(args.workspace, args.config)
        )
        return await service.list_runs(
            args.workspace, args.strategy, deployment_id=deployment_id, limit=args.limit
        )

    runs = run_with_container(load_settings(), run)
    if not runs:
        print("No runs yet.", file=sys.stderr)
        return 0
    print_table(
        (
            "STARTED",
            "WORKSPACE",
            "CONFIGURATION",
            "STRATEGY",
            "VERSION",
            "STATUS",
            "CANDLES",
            "SIGNALS",
            "FAILURES",
            "STOPPED",
            "ERROR",
        ),
        [
            (
                format_time(run.started_at),
                run.workspace_slug,
                run.deployment_label,
                run.strategy_id,
                run.strategy_version,
                cli_name(run.status),
                str(run.candles_processed),
                str(run.signals_emitted),
                str(run.failures + run.timeouts),
                format_time(run.stopped_at),
                _shorten(run.last_error or "-"),
            )
            for run in runs
        ],
    )
    return 0


def _shorten(text: str, width: int = _ERROR_WIDTH) -> str:
    line = " ".join(text.split())
    return line if len(line) <= width else line[: width - 3].rstrip() + "..."
