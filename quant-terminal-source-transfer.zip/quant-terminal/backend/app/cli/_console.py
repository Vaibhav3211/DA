"""Helpers shared by CLI commands: user-facing errors, prompts, safe output, async execution."""

from __future__ import annotations

import argparse
import asyncio
import getpass
import json
import sys
from collections.abc import Awaitable, Callable, Iterable, Mapping, Sequence
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any, Literal, NoReturn, overload
from urllib.parse import urlsplit, urlunsplit

from pydantic import ValidationError

from app.container import Container
from app.core.clock import IST
from app.core.config import Settings, get_settings

# A lazily evaluated alias: _SubParsersAction is generic only in the type stubs, not at runtime.
type Subcommands = argparse._SubParsersAction[argparse.ArgumentParser]


class CliError(Exception):
    """A user-facing failure: printed without a traceback."""

    def __init__(self, message: str, *, exit_code: int = 1) -> None:
        super().__init__(message)
        self.message = message
        self.exit_code = exit_code


def load_settings() -> Settings:
    try:
        return get_settings()
    except ValidationError as exc:
        # Never print exc itself: pydantic includes the offending input values (e.g. URLs with passwords).
        problems = "; ".join(
            f"{'.'.join(str(p) for p in err['loc']).upper() or 'settings'}: {err['msg']}"
            for err in exc.errors()
        )
        raise CliError(
            f"configuration is invalid: {problems}. Check backend/.env (see .env.example)."
        ) from None


def run_with_container[T](settings: Settings, operation: Callable[[Container], Awaitable[T]]) -> T:
    async def runner() -> T:
        container = Container.create(settings)
        try:
            return await operation(container)
        finally:
            await container.close()

    return asyncio.run(runner())


def require_console(hint: str = "pipe the value and use the --*-stdin option") -> None:
    """Fail unless a prompt can be answered; ``hint`` says what to do instead."""
    if not sys.stdin.isatty():
        raise CliError(f"no interactive console for a prompt; {hint}")


def read_password(*, from_stdin: bool, confirm: bool = True) -> str:
    """Read a password without echo (or one line from stdin). Whitespace is kept as typed."""
    if from_stdin:
        value = sys.stdin.readline().rstrip("\r\n")
        if not value:
            raise CliError("no password received on standard input")
        return value
    require_console()
    first = getpass.getpass("Password: ")
    if confirm and getpass.getpass("Repeat password: ") != first:
        raise CliError("passwords do not match")
    return first


@overload
def read_secret(label: str, *, from_stdin: bool = ..., required: Literal[True] = ...) -> str: ...
@overload
def read_secret(label: str, *, from_stdin: bool = ..., required: bool) -> str | None: ...
def read_secret(label: str, *, from_stdin: bool = False, required: bool = True) -> str | None:
    """Read an API key, secret or token without echo. Surrounding whitespace is removed."""
    if from_stdin:
        value = sys.stdin.readline().strip()
    else:
        require_console()
        value = getpass.getpass(f"{label}: ").strip()
    if not value:
        if required:
            raise CliError(f"{label} is required")
        return None
    return value


def read_line(prompt: str, *, hint: str) -> str:
    """Read visible input (e.g. a pasted redirect URL); ``hint`` says what to do without a console."""
    require_console(hint)
    try:
        return input(prompt).strip()
    except EOFError:
        raise CliError("no input received") from None


def confirm(prompt: str, *, assume_yes: bool = False) -> bool:
    if assume_yes:
        return True
    if not sys.stdin.isatty():
        raise CliError("confirmation needed but there is no interactive console; pass --yes")
    return input(f"{prompt} [y/N]: ").strip().lower() in ("y", "yes")


def display_url(url: str) -> str:
    """The URL with any password masked and the query string dropped (it may carry tokens)."""
    parts = urlsplit(url)
    netloc = parts.netloc
    if parts.password is not None:
        host = parts.hostname or ""
        if parts.port is not None:
            host = f"{host}:{parts.port}"
        netloc = f"{parts.username or ''}:***@{host}"
    return urlunsplit((parts.scheme, netloc, parts.path, "", ""))


def print_rows(rows: Sequence[tuple[str, str]]) -> None:
    width = max((len(label) for label, _ in rows), default=0)
    for label, value in rows:
        print(f"{label.ljust(width)}  {value}")


def print_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> None:
    widths = [max([len(header), *(len(row[index]) for row in rows)]) for index, header in enumerate(headers)]
    for line in (headers, *rows):
        print("  ".join(cell.ljust(width) for cell, width in zip(line, widths, strict=True)).rstrip())


def on_off(value: bool) -> str:
    return "on" if value else "off"


def yes_no(value: bool) -> str:
    return "yes" if value else "no"


def format_time(value: datetime | None) -> str:
    """Times are shown in IST, the market's time zone."""
    return "-" if value is None else value.astimezone(IST).strftime("%Y-%m-%d %H:%M IST")


def cli_name(member: StrEnum) -> str:
    """How an enum member is typed on the command line, e.g. ``api-key-secret``."""
    return member.value.lower().replace("_", "-")


def shell_arg(text: str) -> str:
    """``text`` as one argument in a suggested command (labels never contain quotes)."""
    return f'"{text}"' if " " in text else text


def enum_arg[E: StrEnum](enum: type[E], members: Iterable[E] | None = None) -> Callable[[str], E]:
    """An argparse ``type`` that accepts member values in any case, with '-' for '_'."""
    allowed = tuple(enum if members is None else members)

    def parse(text: str) -> E:
        wanted = text.strip().upper().replace("-", "_")
        for member in allowed:
            if member.value == wanted:
                return member
        choices = ", ".join(cli_name(member) for member in allowed)
        raise argparse.ArgumentTypeError(f"invalid choice: '{text}' (choose from {choices})")

    return parse


def date_arg(text: str) -> date:
    """An argparse ``type`` for ISO dates."""
    try:
        return date.fromisoformat(text.strip())
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid date: '{text}' (use YYYY-MM-DD)") from None


def int_arg(minimum: int, maximum: int | None = None) -> Callable[[str], int]:
    """An argparse ``type`` for whole numbers from ``minimum`` to ``maximum``, both included."""

    def parse(text: str) -> int:
        try:
            value = int(text.strip())
        except ValueError:
            raise argparse.ArgumentTypeError(f"invalid number: '{text}'") from None
        if value < minimum or (maximum is not None and value > maximum):
            allowed = f"{minimum} or more" if maximum is None else f"{minimum}-{maximum}"
            raise argparse.ArgumentTypeError(f"out of range: {value} (use {allowed})")
        return value

    return parse


def decimal_text(value: Decimal | None) -> str:
    """A number as stored, e.g. ``24000.50`` rather than ``2.400050E+4``; '-' for none."""
    return "-" if value is None else format(value, "f")


def _no_constant(name: str) -> NoReturn:
    raise ValueError(f"{name} is not a JSON number")


def parse_json_assignments(items: Sequence[str], *, option: str) -> dict[str, Any]:
    """``KEY=VALUE`` items. A value is read as JSON (a number, true, false, null, a list or an object)
    and kept as text otherwise; quote it as JSON ('"true"') to keep JSON-looking text."""
    values: dict[str, Any] = {}
    for item in items:
        key, separator, text = item.partition("=")
        key, text = key.strip(), text.strip()
        if not separator or not key:
            raise CliError(f"{option} expects KEY=VALUE, not '{item}'")
        if key in values:
            raise CliError(f"{option} sets {key} more than once")
        try:
            values[key] = json.loads(text, parse_constant=_no_constant)
        except ValueError:  # includes JSONDecodeError; NaN and Infinity stay text
            values[key] = text
    return values


def json_text(value: Any) -> str:
    """A JSON value for display: text as it is, anything else as compact JSON."""
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)


def assignments_text(values: Mapping[str, Any]) -> str:
    return ", ".join(f"{key}={json_text(value)}" for key, value in values.items()) or "-"
