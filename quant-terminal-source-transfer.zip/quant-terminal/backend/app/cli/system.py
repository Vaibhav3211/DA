"""Setup and operations commands: encryption key, configuration check, local user, kill switch."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from alembic.config import Config as AlembicConfig
from alembic.script import ScriptDirectory
from pydantic import SecretStr
from sqlalchemy import text

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    display_url,
    load_settings,
    on_off,
    print_rows,
    read_password,
    run_with_container,
)
from app.container import Container
from app.core.config import Settings
from app.core.logging import redact_text
from app.core.security import EncryptionError, SecretBox, generate_encryption_key, mask_secret
from app.services.audit import CLI_ACTOR
from app.services.auth_service import AuthService, normalize_username, validate_username
from app.services.kill_switch import KillSwitchService, KillSwitchState
from app.services.provider_accounts import RotationReport

MAX_REASON_LENGTH = 300
_SOURCE_ALEMBIC_DIR = Path(__file__).resolve().parents[2] / "alembic"


def register(commands: Subcommands) -> None:
    commands.add_parser("generate-key", help="print a new ENCRYPTION_KEY").set_defaults(handler=generate_key)
    commands.add_parser(
        "rotate-encryption-key", help="re-encrypt stored provider credentials with the current ENCRYPTION_KEY"
    ).set_defaults(handler=rotate_encryption_key)
    commands.add_parser(
        "check-config", help="show the effective configuration (secrets masked) and test PostgreSQL/Redis"
    ).set_defaults(handler=check_config)

    for name, handler, help_text in (
        ("create-admin", create_admin, "create the single local user"),
        ("reset-password", reset_password, "set a new password, unlock the user and revoke its sessions"),
    ):
        parser = commands.add_parser(name, help=help_text)
        parser.add_argument("--username", default="admin")
        parser.add_argument("--password-stdin", action="store_true", help="read the password from stdin")
        parser.set_defaults(handler=handler)

    parser = commands.add_parser("kill-switch", help="show, engage or release the global signal kill switch")
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")
    actions.add_parser("status", help="show the current state").set_defaults(handler=kill_switch_status)
    for name, handler, help_text in (
        ("engage", kill_switch_engage, "block every new actionable signal"),
        (
            "release",
            kill_switch_release,
            "allow actionable signals again (all other risk checks still apply)",
        ),
    ):
        action = actions.add_parser(name, help=help_text)
        action.add_argument("--reason", required=True, help="recorded in the audit log")
        action.set_defaults(handler=handler)


# ---- encryption key --------------------------------------------------------------------------


def generate_key(_args: argparse.Namespace) -> int:
    print(generate_encryption_key())
    print(
        "Set this as ENCRYPTION_KEY in backend/.env and keep an offline backup: stored provider "
        "credentials cannot be decrypted without it. To rotate: move the current key to "
        "ENCRYPTION_PREVIOUS_KEYS, set the new key, then run `qt rotate-encryption-key`.",
        file=sys.stderr,
    )
    return 0


def rotate_encryption_key(_args: argparse.Namespace) -> int:
    report, previous_keys = run_with_container(load_settings(), _rotate_credentials)
    current = report.examined - report.rotated - len(report.failed)
    print_rows(
        [
            ("Primary key", f"key id {report.primary_key_id}"),
            ("Re-encrypted", str(report.rotated)),
            ("Already current", str(current)),
            ("Unreadable", str(len(report.failed))),
        ]
    )
    if report.failed:
        print("No configured key can decrypt these stored credentials:", file=sys.stderr)
        for item in report.failed:
            print(f"  {item}", file=sys.stderr)
        print(
            "Add the key they were encrypted with to ENCRYPTION_PREVIOUS_KEYS and run this again, or "
            "store them again (`qt accounts set-credentials`; log in again for an ACCESS_TOKEN). "
            "Keep the previous keys configured until a run reports none unreadable.",
            file=sys.stderr,
        )
        return 1
    if previous_keys:
        print(
            "Every stored credential now uses the primary key: ENCRYPTION_PREVIOUS_KEYS can be removed "
            "from backend/.env.",
            file=sys.stderr,
        )
    return 0


async def _rotate_credentials(container: Container) -> tuple[RotationReport, int]:
    report = await _services.provider_accounts(container).rotate_encryption(actor=CLI_ACTOR)
    return report, container.require_secret_box().previous_key_count


# ---- configuration check ---------------------------------------------------------------------


def check_config(_args: argparse.Namespace) -> int:
    settings = load_settings()
    print_rows(configuration_rows(settings))
    print()
    probes = run_with_container(settings, _probe_infrastructure)
    print_rows([(label, value) for label, value, _ok in probes])
    return 0 if all(ok for _label, _value, ok in probes) else 1


def configuration_rows(settings: Settings) -> list[tuple[str, str]]:
    try:
        box = SecretBox.from_settings(settings)
        encryption = f"configured (key id {box.primary_key_id}, {box.previous_key_count} previous)"
    except EncryptionError as exc:
        encryption = f"NOT USABLE: {exc}"
    simulated = " (simulated data)" if settings.is_simulated_mode else ""
    return [
        ("Environment", f"{settings.app_env.value}{simulated}"),
        ("API", f"http://{settings.api_host}:{settings.api_port} (public {settings.public_base_url})"),
        ("Allowed origins", ", ".join(settings.allowed_origins)),
        ("Secure cookies", on_off(settings.cookie_secure)),
        ("Market data", on_off(settings.market_data_enabled)),
        ("Live signals", on_off(settings.live_signals_enabled)),
        ("Simulator", on_off(settings.simulator_enabled)),
        ("Tick persistence", on_off(settings.tick_persistence_enabled)),
        ("Order execution", "off (not implemented in Phase 1)"),
        ("Encryption", encryption),
        (
            "Zerodha app (.env)",
            _app_credentials(settings.zerodha_api_key, settings.zerodha_api_secret)
            + f"; redirect {settings.zerodha_redirect_url or 'not set'}",
        ),
        ("Groww app (.env)", _app_credentials(settings.groww_api_key, settings.groww_api_secret)),
        ("Database", display_url(settings.database_url.get_secret_value())),
        ("Redis", display_url(settings.redis_url.get_secret_value())),
    ]


def _app_credentials(key: SecretStr | None, secret: SecretStr | None) -> str:
    if key is None:
        return "no defaults"
    return (
        f"api key {mask_secret(key.get_secret_value())}, secret {'set' if secret is not None else 'not set'}"
    )


def migration_head() -> str | None:
    # A source checkout keeps migrations in backend/alembic; the container image in /app/alembic (cwd).
    # In an installed (non-editable) package the first candidate is site-packages/alembic, the library
    # itself, so require the layout of a migrations directory.
    for location in (_SOURCE_ALEMBIC_DIR, Path.cwd() / "alembic"):
        if (location / "env.py").is_file() and (location / "versions").is_dir():
            config = AlembicConfig()
            config.set_main_option("script_location", str(location))
            return ScriptDirectory.from_config(config).get_current_head()
    return None


def _failure(exc: Exception) -> str:
    return f"UNREACHABLE: {type(exc).__name__}: {redact_text(str(exc))[:200]}"


async def _probe_infrastructure(container: Container) -> list[tuple[str, str, bool]]:
    results: list[tuple[str, str, bool]] = []
    schema_ok = False
    try:
        async with container.db.session() as session:
            server = await session.scalar(text("SHOW server_version"))
            has_table = await session.scalar(text("SELECT to_regclass('public.alembic_version') IS NOT NULL"))
            revision = (
                await session.scalar(text("SELECT version_num FROM alembic_version")) if has_table else None
            )
        results.append(("PostgreSQL", f"reachable (server {server})", True))
        head = migration_head()
        if revision is None:
            results.append(("Schema", "NOT MIGRATED: run `alembic upgrade head` in backend/", False))
        elif head is not None and revision != head:
            results.append(
                ("Schema", f"OUTDATED ({revision}, head {head}): run `alembic upgrade head`", False)
            )
        else:
            schema_ok = True
            results.append(("Schema", f"revision {revision}" + (" (head)" if head == revision else ""), True))
    except Exception as exc:  # reported as a failed probe
        results.append(("PostgreSQL", _failure(exc), False))

    redis_ok = False
    try:
        await container.bus.redis.ping()
        info = await container.bus.redis.info("server")
        redis_ok = True
        results.append(("Redis", f"reachable (server {info.get('redis_version', '?')})", True))
    except Exception as exc:  # reported as a failed probe
        results.append(("Redis", _failure(exc), False))

    if schema_ok:
        users = await AuthService(container.db, container.bus, container.settings).user_count()
        results.append(("Local user", "present" if users else "MISSING: run `qt create-admin`", users > 0))
    if schema_ok and redis_ok:
        state = await KillSwitchService(container.db, container.bus).get()
        results.append(("Kill switch", "ENGAGED" if state.engaged else "released", True))
    return results


# ---- local user ------------------------------------------------------------------------------


def create_admin(args: argparse.Namespace) -> int:
    settings = load_settings()
    username = normalize_username(args.username)
    validate_username(username)

    async def ensure_no_user(container: Container) -> None:
        if await AuthService(container.db, container.bus, settings).user_count() > 0:
            raise CliError("a local user already exists (single-user system); use `qt reset-password`")

    run_with_container(settings, ensure_no_user)
    password = read_password(from_stdin=args.password_stdin)
    run_with_container(
        settings,
        lambda c: AuthService(c.db, c.bus, settings).create_user(username, password, actor=CLI_ACTOR),
    )
    print(f"Created user '{username}'. Sign in at {settings.frontend_base_url}")
    return 0


def reset_password(args: argparse.Namespace) -> int:
    settings = load_settings()
    username = normalize_username(args.username)
    validate_username(username)

    async def ensure_user(container: Container) -> None:
        if not await AuthService(container.db, container.bus, settings).user_exists(username):
            raise CliError(f"user '{username}' does not exist")

    run_with_container(settings, ensure_user)
    password = read_password(from_stdin=args.password_stdin)
    revoked = run_with_container(
        settings,
        lambda c: AuthService(c.db, c.bus, settings).set_password(username, password, actor=CLI_ACTOR),
    )
    print(f"Password updated for '{username}'; {revoked} active session(s) revoked.")
    return 0


# ---- kill switch -----------------------------------------------------------------------------


def kill_switch_status(_args: argparse.Namespace) -> int:
    state = run_with_container(load_settings(), lambda c: KillSwitchService(c.db, c.bus).get())
    _print_kill_switch(state)
    return 0


def kill_switch_engage(args: argparse.Namespace) -> int:
    return _set_kill_switch(args.reason, engaged=True)


def kill_switch_release(args: argparse.Namespace) -> int:
    return _set_kill_switch(args.reason, engaged=False)


def _set_kill_switch(raw_reason: str, *, engaged: bool) -> int:
    reason = raw_reason.strip()
    if not 0 < len(reason) <= MAX_REASON_LENGTH:
        raise CliError(f"--reason must be 1-{MAX_REASON_LENGTH} characters")
    state = run_with_container(
        load_settings(),
        lambda c: KillSwitchService(c.db, c.bus).set(engaged=engaged, reason=reason, actor=CLI_ACTOR),
    )
    _print_kill_switch(state)
    return 0


def _print_kill_switch(state: KillSwitchState) -> None:
    rows = [("Kill switch", "ENGAGED: new actionable signals are blocked" if state.engaged else "released")]
    if state.reason:
        rows.append(("Reason", state.reason))
    if state.updated_by:
        rows.append(("Changed by", state.updated_by))
    if state.updated_at:
        rows.append(("Changed at", state.updated_at.isoformat(timespec="seconds")))
    print_rows(rows)
