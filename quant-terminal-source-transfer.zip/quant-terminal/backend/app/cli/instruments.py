"""Instrument master commands: refresh it from a provider's dump, search it, show one instrument."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Iterable, Mapping
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from pathlib import Path
from types import MappingProxyType
from typing import Final
from uuid import UUID

from pydantic import ValidationError

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    cli_name,
    date_arg,
    enum_arg,
    format_time,
    load_settings,
    print_rows,
    print_table,
    run_with_container,
    yes_no,
)
from app.cli.accounts import PROVIDER_ARG, PROVIDER_NAMES
from app.container import Container
from app.core.config import Settings
from app.core.errors import ConflictError, NotFoundError
from app.domain.enums import Exchange, InstrumentType, OptionType, Provider, Segment
from app.domain.models import Instrument, InstrumentMapping
from app.services.audit import CLI_ACTOR
from app.services.instruments import (
    SEARCH_LIMIT_MAX,
    DumpSource,
    InstrumentQuery,
    RefreshReport,
    read_dump_file,
)

_INCOMPLETE: Final = "instrument_dump_incomplete"
_NAME_WIDTH: Final = 40
_QUERY_OPTIONS: Final[Mapping[str, str]] = MappingProxyType(
    {"text": "the search text", "underlying": "--underlying", "limit": "--limit", "offset": "--offset"}
)


def register(commands: Subcommands) -> None:
    parser = commands.add_parser("instruments", help="refresh and search the instrument master")
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    refresh = actions.add_parser(
        "refresh", help="load a provider's instrument list: downloaded, from a file, or built in (simulator)"
    )
    refresh.add_argument(
        "provider", type=PROVIDER_ARG, metavar="PROVIDER", help="zerodha, groww or simulator"
    )
    source = refresh.add_mutually_exclusive_group()
    source.add_argument(
        "--file",
        type=Path,
        metavar="PATH",
        help="import this dump (e.g. a saved copy) instead of downloading",
    )
    source.add_argument(
        "--account",
        help="Zerodha only: the account whose API key downloads the dump (default: the enabled one)",
    )
    refresh.add_argument(
        "--force",
        action="store_true",
        help="apply a dump that lacks most instruments of a segment, closing their mappings",
    )
    refresh.set_defaults(handler=refresh_instruments)

    search = actions.add_parser("search", help="find instruments by symbol or name")
    search.add_argument(
        "text", nargs="*", help="words that must all appear in the symbol, the name or a provider's symbol"
    )
    search.add_argument("--exchange", type=enum_arg(Exchange), metavar="EXCHANGE", help=_choices(Exchange))
    search.add_argument("--segment", type=enum_arg(Segment), metavar="SEGMENT", help=_choices(Segment))
    search.add_argument(
        "--type",
        dest="instrument_type",
        type=enum_arg(InstrumentType),
        metavar="TYPE",
        help=_choices(InstrumentType),
    )
    search.add_argument("--underlying", help="derivatives of this underlying, e.g. NIFTY")
    search.add_argument("--expiry", type=date_arg, metavar="YYYY-MM-DD", help="derivatives expiring that day")
    search.add_argument("--strike", type=decimal_arg, metavar="PRICE", help="options with this strike")
    search.add_argument(
        "--option-type", type=enum_arg(OptionType), metavar="CE|PE", help="calls (ce) or puts (pe)"
    )
    search.add_argument(
        "--provider", type=PROVIDER_ARG, metavar="PROVIDER", help="only instruments this provider lists"
    )
    state = search.add_mutually_exclusive_group()
    state.add_argument(
        "--inactive",
        dest="active",
        action="store_const",
        const=False,
        help="only inactive instruments (expired or no longer listed)",
    )
    state.add_argument(
        "--all", dest="active", action="store_const", const=None, help="active and inactive instruments"
    )
    search.add_argument(
        "--limit", type=int, default=50, help=f"at most this many results (1-{SEARCH_LIMIT_MAX}; default 50)"
    )
    search.add_argument("--offset", type=int, default=0, help="skip this many results, to see the next page")
    search.set_defaults(handler=search_instruments, active=True)

    show = actions.add_parser("show", help="show an instrument and its provider mappings")
    show.add_argument("instrument", help="canonical key (e.g. NSE:CASH:EQUITY:INFY) or id")
    show.set_defaults(handler=show_instrument)


def _choices(enum: type[StrEnum]) -> str:
    return "one of " + ", ".join(cli_name(member) for member in enum)


def decimal_arg(text: str) -> Decimal:
    """An argparse ``type`` for prices."""
    try:
        value = Decimal(text.strip())
    except InvalidOperation:
        value = None
    if value is None or not value.is_finite():
        raise argparse.ArgumentTypeError(f"invalid number: '{text}'")
    return value


def _decimal(value: Decimal | None) -> str:
    """``24000`` rather than ``2.4E+4`` or ``24000.00``."""
    return "-" if value is None else format(value.normalize(), "f")


def _counts(pairs: Iterable[tuple[str, int]], empty: str = "no changes") -> str:
    return ", ".join(f"{count} {what}" for what, count in pairs if count) or empty


# ---- refresh -----------------------------------------------------------------------------------


def refresh_instruments(args: argparse.Namespace) -> int:
    provider: Provider = args.provider
    file: Path | None = args.file
    if provider is Provider.SIMULATOR and file is not None:
        raise CliError("the simulator's instruments are built in: it takes no --file")
    if args.account is not None and provider is not Provider.ZERODHA:
        raise CliError(
            "--account is for Zerodha downloads only: Groww's instrument list is public and the "
            "simulator's is built in"
        )
    settings = load_settings()
    data = None if file is None else read_dump_file(file)
    if data is None and provider is not Provider.SIMULATOR:
        print(f"Downloading the {PROVIDER_NAMES[provider]} instrument list...", file=sys.stderr)

    async def run(container: Container) -> tuple[RefreshReport, str | None]:
        service = _services.instruments(container)
        account_id: UUID | None = None
        if args.account is not None:
            account_id = (await service.accounts.resolve_ref(args.account, provider=Provider.ZERODHA)).id
        report = await service.refresh(
            provider,
            actor=CLI_ACTOR,
            data=data,
            file_name=None if file is None else file.name,
            account_id=account_id,
            force=args.force,
        )
        if report.account_id is None:
            return report, None
        try:
            return report, (await service.accounts.get(report.account_id)).label
        except NotFoundError:  # removed since: the refresh itself still happened
            return report, None

    try:
        report, label = run_with_container(settings, run)
    except ConflictError as exc:
        if exc.code != _INCOMPLETE:
            raise
        raise CliError(
            _incomplete_message(exc.message, settings, provider, downloaded=data is None)
        ) from None
    print_rows(_report_rows(report, file, label))
    return 0


def _incomplete_message(message: str, settings: Settings, provider: Provider, *, downloaded: bool) -> str:
    text = f"{message} with --force."
    cache = settings.instrument_cache_dir.strip()
    if downloaded and cache:
        text += f" The downloaded copy is kept in {Path(cache) / provider.value.lower()} for inspection."
    return text


def _source_text(report: RefreshReport, file: Path | None, label: str | None) -> str:
    if report.source is DumpSource.FILE:
        return f"file {file}"
    if report.source is DumpSource.BUILT_IN:
        return "built in"
    if report.provider is Provider.GROWW:
        return "download (public)"
    if report.account_id is None:
        return "download (API key from ZERODHA_API_KEY)"
    return f"download (API key of account '{label or report.account_id}')"


def _report_rows(report: RefreshReport, file: Path | None, label: str | None) -> list[tuple[str, str]]:
    stats = report.stats
    skipped = sorted(report.skipped.items(), key=lambda item: (-item[1], item[0]))
    rows = [
        ("Provider", PROVIDER_NAMES[report.provider]),
        ("Source", _source_text(report, file, label)),
        ("Rows", f"{report.rows} read, {report.accepted} accepted"),
        ("Skipped", _counts(((reason.replace("_", " "), count) for reason, count in skipped), "none")),
        (
            "Instruments",
            _counts(
                (
                    ("new", stats.instruments_created),
                    ("updated", stats.instruments_updated),
                    ("renamed", stats.instruments_renamed),
                    ("reactivated", stats.instruments_activated),
                    ("deactivated", stats.instruments_deactivated),
                )
            ),
        ),
        (
            "Mappings",
            _counts(
                (
                    ("new", stats.mappings_created),
                    ("updated", stats.mappings_updated),
                    ("unchanged", stats.mappings_unchanged),
                    ("moved", stats.mappings_moved),
                    ("closed", stats.mappings_closed),
                    ("left as they were (rows skipped)", stats.mappings_held),
                )
            ),
        ),
    ]
    if report.forced:
        rows.append(("Forced", "yes"))
    if report.cache_path is not None:
        rows.append(("Saved copy", report.cache_path))
    elif report.cache_error is not None:
        rows.append(("Saved copy", f"FAILED: {report.cache_error}"))
    rows += [
        (
            "Workers",
            "asked to re-resolve their subscriptions"
            if report.published
            else "not notified (Redis unavailable); they catch up when they next reconcile",
        ),
        ("Took", f"{report.duration_seconds:.1f} s"),
    ]
    return rows


# ---- search and show ---------------------------------------------------------------------------


def _query(args: argparse.Namespace) -> InstrumentQuery:
    try:
        return InstrumentQuery(
            text=" ".join(args.text) or None,
            exchange=args.exchange,
            segment=args.segment,
            instrument_type=args.instrument_type,
            underlying=args.underlying,
            expiry=args.expiry,
            strike=args.strike,
            option_type=args.option_type,
            provider=args.provider,
            active=args.active,
            limit=args.limit,
            offset=args.offset,
        )
    except ValidationError as exc:
        # Field and message only: the rejected input is not echoed.
        error = exc.errors(include_url=False, include_input=False)[0]
        field = str(error["loc"][0]) if error["loc"] else "query"
        raise CliError(f"{_QUERY_OPTIONS.get(field, field)}: {error['msg']}") from None


def _shorten(text: str, width: int = _NAME_WIDTH) -> str:
    return text if len(text) <= width else text[: width - 3].rstrip() + "..."


def search_instruments(args: argparse.Namespace) -> int:
    query = _query(args)
    page = run_with_container(load_settings(), lambda c: _services.instruments(c).search(query))
    if not page.items:
        print("No instruments match.", file=sys.stderr)
        return 0
    with_state = query.active is not True
    headers = ["KEY", "NAME", "LOT", "TICK", "PROVIDERS"] + (["ACTIVE"] if with_state else [])
    rows: list[list[str]] = []
    for hit in page.items:
        instrument = hit.instrument
        row = [
            instrument.canonical_key,
            _shorten(instrument.name or "-"),
            "-" if instrument.lot_size is None else str(instrument.lot_size),
            _decimal(instrument.tick_size),
            ",".join(cli_name(provider) for provider in hit.providers) or "-",
        ]
        if with_state:
            row.append(yes_no(instrument.is_active))
        rows.append(row)
    print_table(headers, rows)
    if page.has_more:
        print(f"More results: add --offset {query.offset + query.limit}", file=sys.stderr)
    return 0


def _instrument_rows(instrument: Instrument) -> list[tuple[str, str]]:
    rows = [
        ("Key", instrument.canonical_key),
        ("Symbol", instrument.symbol),
        ("Name", instrument.name or "-"),
        ("Exchange", instrument.exchange.value),
        ("Segment", instrument.segment.value),
        ("Type", instrument.instrument_type.value),
    ]
    if instrument.underlying is not None:
        rows.append(("Underlying", instrument.underlying))
    if instrument.expiry is not None:
        rows.append(("Expiry", instrument.expiry.isoformat()))
    if instrument.strike is not None:
        rows.append(("Strike", _decimal(instrument.strike)))
    if instrument.option_type is not None:
        rows.append(("Option type", instrument.option_type.value))
    rows += [
        ("Lot size", "-" if instrument.lot_size is None else str(instrument.lot_size)),
        ("Tick size", _decimal(instrument.tick_size)),
        ("Currency", instrument.currency),
        ("ISIN", instrument.isin or "-"),
        ("Active", yes_no(instrument.is_active)),
        ("Updated", format_time(instrument.updated_at)),
        ("ID", str(instrument.id)),
    ]
    return rows


def _mapping_row(mapping: InstrumentMapping) -> tuple[str, ...]:
    return (
        cli_name(mapping.provider),
        mapping.provider_token,
        mapping.exchange_token or "-",
        mapping.provider_symbol,
        mapping.provider_exchange,
        mapping.provider_segment,
        yes_no(mapping.is_active),
        format_time(mapping.valid_from),
        format_time(mapping.valid_to),
    )


def show_instrument(args: argparse.Namespace) -> int:
    detail = run_with_container(load_settings(), lambda c: _services.instruments(c).get(args.instrument))
    print_rows(_instrument_rows(detail.instrument))
    if not detail.mappings:
        print("No provider lists it.", file=sys.stderr)
        return 0
    print()
    print_table(
        (
            "PROVIDER",
            "TOKEN",
            "EXCHANGE TOKEN",
            "PROVIDER SYMBOL",
            "EXCHANGE",
            "SEGMENT",
            "ACTIVE",
            "VALID FROM",
            "VALID TO",
        ),
        [_mapping_row(mapping) for mapping in detail.mappings],
    )
    return 0
