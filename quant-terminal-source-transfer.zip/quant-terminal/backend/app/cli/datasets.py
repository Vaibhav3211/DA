"""Dataset commands: the historical candles a backtest replays (see docs/backtesting.md).

A dataset freezes one instrument's candles at one interval over a range of exchange dates, downloaded
from a provider's historical-candle API (ZERODHA, GROWW) or taken from the candles the platform recorded
from a feed. ``request`` only queues it: the backtest worker (qt-backtest-worker) builds it, and ``show``
then reports its coverage against the exchange calendar, gaps included. Datasets of simulator candles are
labelled SIMULATED: they are never market history.
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from datetime import date
from typing import Final
from uuid import UUID

from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    cli_name,
    date_arg,
    decimal_text,
    enum_arg,
    format_time,
    int_arg,
    load_settings,
    print_rows,
    print_table,
    run_with_container,
)
from app.container import Container
from app.domain.enums import CandleInterval, DatasetSource, DatasetStatus, Provider
from app.domain.models.backtest import DatasetCoverage
from app.services.audit import CLI_ACTOR
from app.services.datasets import LIST_LIMIT_MAX, DatasetRequestResult, DatasetSourceOption, DatasetView

INSTRUMENT_HELP: Final = "canonical key (e.g. NSE:CASH:EQUITY:INFY; see qt instruments search) or id"
_INTERVALS: Final = ", ".join(interval.value for interval in CandleInterval)
_STATUSES: Final = ", ".join(cli_name(status) for status in DatasetStatus)


def register(commands: Subcommands) -> None:
    parser = commands.add_parser(
        "datasets", help="historical candles for backtests: where they can come from, requests and coverage"
    )
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    sources = actions.add_parser(
        "sources", help="where an instrument's datasets can come from, and why a source cannot be used"
    )
    sources.add_argument("instrument", help=INSTRUMENT_HELP)
    sources.set_defaults(handler=show_sources)

    request = actions.add_parser(
        "request", help="queue a dataset; the backtest worker (qt-backtest-worker) downloads or builds it"
    )
    request.add_argument("instrument", help=INSTRUMENT_HELP)
    request.add_argument(
        "--provider",
        required=True,
        type=enum_arg(Provider),
        metavar="PROVIDER",
        help="zerodha, groww or simulator",
    )
    request.add_argument(
        "--source",
        type=enum_arg(DatasetSource),
        default=DatasetSource.PROVIDER_HISTORY,
        metavar="SOURCE",
        help=(
            "provider-history (the provider's historical-candle API; the default), recorded (candles "
            "recorded from the provider's live feed) or simulated (candles recorded from the simulator: "
            "never market history)"
        ),
    )
    request.add_argument(
        "--interval", required=True, type=interval_arg, metavar="INTERVAL", help=f"one of {_INTERVALS}"
    )
    request.add_argument(
        "--from", dest="date_from", required=True, type=date_arg, metavar="YYYY-MM-DD", help="the first date"
    )
    request.add_argument(
        "--to",
        dest="date_to",
        required=True,
        type=date_arg,
        metavar="YYYY-MM-DD",
        help="the last date, included (today on the exchange at the latest)",
    )
    request.add_argument(
        "--account",
        help=(
            "provider history only: the account to download with, its label or id (default: the provider's "
            "only enabled account). It needs a current access token (see qt zerodha login and qt groww)"
        ),
    )
    request.set_defaults(handler=request_dataset)

    listing = actions.add_parser("list", help="list datasets, newest first")
    listing.add_argument("--instrument", help=f"only this instrument: {INSTRUMENT_HELP}")
    listing.add_argument(
        "--interval", type=interval_arg, metavar="INTERVAL", help=f"only this interval: {_INTERVALS}"
    )
    listing.add_argument(
        "--status", type=enum_arg(DatasetStatus), metavar="STATUS", help=f"only this status: {_STATUSES}"
    )
    listing.add_argument(
        "--limit",
        type=int_arg(1, LIST_LIMIT_MAX),
        default=50,
        help=f"at most this many (1-{LIST_LIMIT_MAX}; default 50)",
    )
    listing.add_argument("--offset", type=int_arg(0), default=0, help="skip this many, to see the next page")
    listing.set_defaults(handler=list_datasets)

    show = actions.add_parser("show", help="show a dataset: its status, candles and coverage, gaps included")
    show.add_argument("dataset", type=UUID, help="dataset id (see qt datasets list)")
    show.set_defaults(handler=show_dataset)


def interval_arg(text: str) -> CandleInterval:
    """An argparse ``type`` for candle intervals, e.g. ``15m``."""
    wanted = text.strip().lower()
    for interval in CandleInterval:
        if interval.value == wanted:
            return interval
    raise argparse.ArgumentTypeError(f"invalid interval: '{text}' (choose from {_INTERVALS})")


def show_sources(args: argparse.Namespace) -> int:
    view = run_with_container(load_settings(), lambda c: _services.datasets(c).sources(args.instrument))
    print_rows(
        [
            ("Instrument", f"{view.instrument_key} ({view.symbol})"),
            ("Last date", f"{view.today}: today on {view.exchange.value}, the last date a dataset may cover"),
            (
                "Limits",
                f"{view.max_candles:,} candles (BACKTEST_MAX_CANDLES) and {view.max_span_days:,} dates "
                "per dataset",
            ),
        ]
    )
    for option in view.options:
        print()
        _print_option(option)
    if view.worker_problem:
        print(f"warning: {view.worker_problem}", file=sys.stderr)
    return 0


def _print_option(option: DatasetSourceOption) -> None:
    state = (
        "available" if option.available else "unavailable" + (f": {option.reason}" if option.reason else "")
    )
    print(f"{option.provider.value} {cli_name(option.source)}: {state}")
    rows: list[tuple[str, str]] = []
    if option.intervals:
        rows.append(("  Intervals", ", ".join(interval.value for interval in option.intervals)))
    if option.max_days_per_request:
        rows.append(
            (
                "  Per request",
                ", ".join(
                    f"{days:,} days of {interval}" for interval, days in option.max_days_per_request.items()
                ),
            )
        )
    for index, account in enumerate(option.accounts):
        problem = f": {account.problem}" if account.problem else ""
        rows.append(("  Accounts" if index == 0 else "", f"{account.label} ({account.account_id}){problem}"))
    for index, series in enumerate(option.recorded):
        rows.append(
            (
                "  Recorded" if index == 0 else "",
                f"{series.interval.value}: {series.candles:,} candles from "
                f"{format_time(series.first_candle_at)} to {format_time(series.last_candle_at)}",
            )
        )
    if option.note:
        rows.append(("  Note", option.note))
    print_rows(rows)


def request_dataset(args: argparse.Namespace) -> int:
    if args.account is not None and args.source is not DatasetSource.PROVIDER_HISTORY:
        raise CliError("--account applies only to --source provider-history: recorded candles use no account")

    async def run(container: Container) -> DatasetRequestResult:
        account_id = None
        if args.account is not None:
            accounts = _services.provider_accounts(container)
            account_id = (await accounts.resolve_ref(args.account, provider=args.provider)).id
        return await _services.datasets(container).request(
            args.instrument,
            provider=args.provider,
            source=args.source,
            interval=args.interval,
            date_from=args.date_from,
            date_to=args.date_to,
            account_id=account_id,
            actor=CLI_ACTOR,
        )

    result = run_with_container(load_settings(), run)
    print_dataset(result.dataset)
    follow = f"follow it with qt datasets show {result.dataset.id}"
    if result.created:
        print(f"Queued: the backtest worker (qt-backtest-worker) builds it; {follow}", file=sys.stderr)
    else:
        print(
            f"The same request was already waiting or building, so this is that one; {follow}",
            file=sys.stderr,
        )
    return 0


def list_datasets(args: argparse.Namespace) -> int:
    views = run_with_container(
        load_settings(),
        lambda c: _services.datasets(c).list_datasets(
            instrument=args.instrument,
            interval=args.interval,
            status=args.status,
            limit=args.limit,
            offset=args.offset,
        ),
    )
    if not views:
        print("No datasets match." if args.offset == 0 else "No more datasets.", file=sys.stderr)
        return 0
    print_table(
        (
            "DATASET",
            "INSTRUMENT",
            "PROVIDER",
            "SOURCE",
            "INTERVAL",
            "FROM",
            "TO",
            "STATUS",
            "CANDLES",
            "COVERAGE",
        ),
        [
            (
                str(view.id),
                view.instrument_key,
                cli_name(view.provider),
                cli_name(view.source),
                view.interval.value,
                str(view.date_from),
                str(view.date_to),
                cli_name(view.status),
                str(view.candle_count) if view.status is DatasetStatus.READY else "-",
                coverage_pct(view.coverage),
            )
            for view in views
        ],
    )
    if len(views) == args.limit:
        print(f"More datasets may follow: add --offset {args.offset + args.limit}", file=sys.stderr)
    return 0


def show_dataset(args: argparse.Namespace) -> int:
    print_dataset(run_with_container(load_settings(), lambda c: _services.datasets(c).get(args.dataset)))
    return 0


def print_dataset(view: DatasetView) -> None:
    rows = [
        ("Dataset", str(view.id)),
        ("Instrument", f"{view.instrument_key} ({view.symbol})"),
        (
            "Source",
            source_text(view.provider, view.source, simulated=view.simulated, account_id=view.account_id),
        ),
        ("Interval", view.interval.value),
        ("Dates", f"{view.date_from} to {view.date_to} (exchange dates, both included)"),
        ("Status", _status_text(view)),
    ]
    if view.status is DatasetStatus.READY:
        rows.append(
            (
                "Candles",
                f"{view.candle_count:,}, from {format_time(view.first_candle_at)} to "
                f"{format_time(view.last_candle_at)}",
            )
        )
        rows.append(("Content SHA", view.content_sha or "-"))
    rows.append(("Requested", f"by {view.requested_by or '-'} at {format_time(view.created_at)}"))
    if view.coverage is not None:
        rows.extend(_coverage_rows(view.coverage))
    print_rows(rows)


def source_text(
    provider: Provider, source: DatasetSource, *, simulated: bool, account_id: UUID | None = None
) -> str:
    """Where a dataset's candles came from; simulator candles are called SIMULATED."""
    if simulated or source is DatasetSource.SIMULATED:
        return "SIMULATED: candles recorded from the development simulator, not market history"
    if source is DatasetSource.RECORDED:
        return f"candles recorded from the {provider.value} live feed"
    account = "" if account_id is None else f", downloaded with account {account_id}"
    return f"{provider.value} historical-candle API{account}"


def _status_text(view: DatasetView) -> str:
    match view.status:
        case DatasetStatus.PENDING:
            return "PENDING: waiting for the backtest worker (qt-backtest-worker)"
        case DatasetStatus.BUILDING:
            return f"BUILDING by {view.worker_id or '-'} since {format_time(view.started_at)}"
        case DatasetStatus.READY:
            return f"READY since {format_time(view.finished_at)}"
        case DatasetStatus.FAILED:
            return f"FAILED at {format_time(view.finished_at)}: {view.error or 'no reason recorded'}"


def coverage_pct(coverage: DatasetCoverage | None) -> str:
    if coverage is None or coverage.coverage_pct is None:
        return "-"
    return f"{decimal_text(coverage.coverage_pct)}%"


def coverage_text(coverage: DatasetCoverage) -> str:
    """The share of the expected candles a dataset has, in one line."""
    if not coverage.expected:
        return "-: the calendar expects no candles on these dates"
    return (
        f"{coverage_pct(coverage)}: {coverage.present:,} of the {coverage.expected:,} candles the calendar "
        f"expects on {coverage.session_days:,} session days; {coverage.missing:,} missing in "
        f"{coverage.gap_total:,} gaps"
    )


def _coverage_rows(coverage: DatasetCoverage) -> list[tuple[str, str]]:
    """The coverage against the exchange calendar, gaps first, as labelled rows."""
    rows = [("Coverage", coverage_text(coverage))]
    if coverage.anchor is not None:
        rows.append(("Candle grid", f"{coverage.anchor} (intraday candles start on this grid)"))
    for index, gap in enumerate(coverage.gaps):
        rows.append(
            (
                "Gaps" if index == 0 else "",
                f"{format_time(gap.start)} to {format_time(gap.end)}: {gap.candles:,} missing",
            )
        )
    if coverage.gap_total > len(coverage.gaps):
        rows.append(("", f"... and {coverage.gap_total - len(coverage.gaps):,} more gaps, not listed"))
    if coverage.assumed_days_total:
        rows.append(("Assumed hours", _days_text(coverage.assumed_days, coverage.assumed_days_total)))
    if coverage.unknown_days_total:
        rows.append(("No calendar", _days_text(coverage.unknown_days, coverage.unknown_days_total)))
    if coverage.left_out:
        reasons = ", ".join(f"{reason} {count:,}" for reason, count in coverage.left_out_by_reason.items())
        rows.append(("Left out", f"{coverage.left_out:,} source candles ({reasons})"))
        rows.extend(("", example) for example in coverage.left_out_examples)
    rows.append(
        (
            "Flagged",
            f"{coverage.duplicates:,} duplicates (kept once), {coverage.inconsistent:,} inconsistent (high "
            f"and low do not contain the open and close), {coverage.without_volume:,} without volume, "
            f"{coverage.incomplete:,} incomplete (recorded with partial coverage, after a gap or across a "
            "drop)",
        )
    )
    if coverage.requests:
        rows.append(("Requests", f"{coverage.requests:,} to the provider"))
    rows.extend(("Note" if index == 0 else "", note) for index, note in enumerate(coverage.notes))
    return rows


def _days_text(days: Sequence[date], total: int) -> str:
    listed = ", ".join(str(day) for day in days)
    return f"{total:,} days: {listed}" + (f" and {total - len(days):,} more" if total > len(days) else "")
