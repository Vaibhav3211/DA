"""Backtest commands: trade rules, queueing backtests and reading their results (see docs/backtesting.md).

A backtest replays one saved strategy configuration on one instrument of its scope over a READY dataset
(see qt datasets) and trades its signals by the trade rules: the configuration's own, or else the ones the
strategy declares. ``run`` only queues it: the backtest worker (qt-backtest-worker) replays it. Every run
records the settings that decide its results, so a later change to any of them (the strategy's code or
version, its parameters, the trade rules, the risk rules applied to history, ...) makes earlier runs
OUTDATED. They are kept for comparison, and nothing reruns them by itself. Results replay the past on the
dataset's candles: they are not a forecast, and nothing here places orders.
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Mapping
from decimal import Decimal
from enum import StrEnum
from typing import Any, Final
from uuid import UUID

from pydantic import ValidationError

from app.backtest.engine import MAX_CURVE_POINTS
from app.cli import _services
from app.cli._console import (
    CliError,
    Subcommands,
    assignments_text,
    cli_name,
    decimal_text,
    enum_arg,
    format_time,
    int_arg,
    json_text,
    load_settings,
    parse_json_assignments,
    print_rows,
    print_table,
    run_with_container,
    shell_arg,
)
from app.cli.datasets import INSTRUMENT_HELP, coverage_text, source_text
from app.container import Container
from app.domain.enums import BacktestState, BacktestStatus, TradeRulesSource
from app.domain.models.backtest import BacktestMetrics, BacktestSummary, Measure, SignalRef, TradeRules
from app.services.audit import CLI_ACTOR
from app.services.backtests import (
    LIST_LIMIT_MAX,
    TRADES_LIMIT_MAX,
    BacktestLatest,
    BacktestQueueResult,
    BacktestRunView,
    TradeRulesView,
)
from app.strategies.indicators import describe_validation

_WORKSPACE_HELP: Final = "slug (e.g. india-equity; see qt workspaces list) or id"
_CONFIG_HELP: Final = "saved configuration: its label (see qt strategies deployments) or id"
_BACKTEST_HELP: Final = "backtest id (see qt backtests list)"
_SCOPE_HELP: Final = f"an instrument in the configuration's scope: {INSTRUMENT_HELP}"
_RULES: Final = tuple(TradeRules.model_fields)
_STATUSES: Final = ", ".join(cli_name(status) for status in BacktestStatus)
_SOURCES: Final[Mapping[str, str]] = {
    TradeRulesSource.CONFIGURATION: "the configuration's own",
    TradeRulesSource.STRATEGY: "the strategy's declared ones (the configuration has none of its own)",
}


def register(commands: Subcommands) -> None:
    parser = commands.add_parser(
        "backtests", help="backtests of saved configurations: trade rules, queueing, results and trades"
    )
    actions = parser.add_subparsers(dest="action", required=True, metavar="ACTION")

    rules = actions.add_parser("rules", help="the trade rules a configuration's backtests use")
    rule_actions = rules.add_subparsers(dest="rules_action", required=True, metavar="ACTION")
    show_rules = rule_actions.add_parser("show", help="show the trade rules in use and where they come from")
    _target(show_rules)
    show_rules.set_defaults(handler=show_trade_rules)
    set_rules = rule_actions.add_parser(
        "set",
        help=(
            "save trade rules with the configuration, starting from the ones in use; backtests run with "
            "other rules become outdated"
        ),
    )
    _target(set_rules)
    set_rules.add_argument(
        "--rule",
        dest="rules",
        action="append",
        required=True,
        metavar="KEY=VALUE",
        help=(
            "a rule, e.g. --rule fee_pct_per_side=0.03 or --rule fill=next-open (repeatable). null removes "
            f"an optional rule. The rules: {', '.join(_RULES)} (qt backtests rules show explains them)"
        ),
    )
    set_rules.add_argument(
        "--replace",
        action="store_true",
        help="start from no rules instead of the ones in use, so every required rule must be given",
    )
    set_rules.set_defaults(handler=set_trade_rules)
    clear_rules = rule_actions.add_parser(
        "clear",
        help="remove the configuration's own trade rules, so the strategy's declared ones apply (if any)",
    )
    _target(clear_rules)
    clear_rules.set_defaults(handler=clear_trade_rules)

    run = actions.add_parser(
        "run",
        help=(
            "queue a backtest of a configuration on one instrument over a READY dataset; the backtest "
            "worker (qt-backtest-worker) runs it"
        ),
    )
    _target(run)
    run.add_argument("--instrument", required=True, help=_SCOPE_HELP)
    run.add_argument(
        "--dataset",
        required=True,
        type=UUID,
        help="a READY dataset of that instrument at the strategy's interval (see qt datasets list)",
    )
    run.set_defaults(handler=run_backtest)

    latest = actions.add_parser(
        "latest",
        help=(
            "a configuration's latest backtest on an instrument against its current settings: current, "
            "outdated or not backtested"
        ),
    )
    _target(latest)
    latest.add_argument("--instrument", required=True, help=_SCOPE_HELP)
    latest.set_defaults(handler=latest_backtest)

    listing = actions.add_parser("list", help="list backtests, newest first; earlier runs are kept")
    listing.add_argument("--workspace", help=f"with --config: {_WORKSPACE_HELP}")
    listing.add_argument("--config", help=f"only this {_CONFIG_HELP} (needs --workspace)")
    listing.add_argument("--instrument", help=f"only this instrument: {INSTRUMENT_HELP}")
    listing.add_argument(
        "--status", type=enum_arg(BacktestStatus), metavar="STATUS", help=f"only this status: {_STATUSES}"
    )
    listing.add_argument(
        "--limit",
        type=int_arg(1, LIST_LIMIT_MAX),
        default=50,
        help=f"at most this many (1-{LIST_LIMIT_MAX}; default 50)",
    )
    listing.add_argument("--offset", type=int_arg(0), default=0, help="skip this many, to see the next page")
    listing.set_defaults(handler=list_backtests)

    show = actions.add_parser(
        "show", help="show a backtest: its settings, data, metrics with their definitions, and notes"
    )
    show.add_argument("backtest", type=UUID, help=_BACKTEST_HELP)
    show.add_argument(
        "--curve",
        action="store_true",
        help=f"also print the equity curve (sampled down to at most {MAX_CURVE_POINTS:,} points)",
    )
    show.set_defaults(handler=show_backtest)

    trades = actions.add_parser("trades", help="list a succeeded backtest's closed trades, in order")
    trades.add_argument("backtest", type=UUID, help=_BACKTEST_HELP)
    trades.add_argument(
        "--limit",
        type=int_arg(1, TRADES_LIMIT_MAX),
        default=100,
        help=f"at most this many (1-{TRADES_LIMIT_MAX}; default 100)",
    )
    trades.add_argument("--offset", type=int_arg(0), default=0, help="skip this many, to see the next page")
    trades.set_defaults(handler=list_trades)

    trade = actions.add_parser(
        "trade", help="show one closed trade: its fills, levels, costs and the signals behind it"
    )
    trade.add_argument("backtest", type=UUID, help=_BACKTEST_HELP)
    trade.add_argument("number", type=int_arg(1), help="the trade's number (see qt backtests trades)")
    trade.set_defaults(handler=show_trade)


def _target(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("workspace", help=_WORKSPACE_HELP)
    parser.add_argument("config", help=_CONFIG_HELP)


async def _deployment(container: Container, args: argparse.Namespace) -> UUID:
    return await _services.strategies(container).resolve_deployment(args.workspace, args.config)


# ---- trade rules -----------------------------------------------------------------------------------------


def show_trade_rules(args: argparse.Namespace) -> int:
    async def run(container: Container) -> TradeRulesView:
        return await _services.backtests(container).rules(await _deployment(container, args))

    _print_rules(run_with_container(load_settings(), run))
    return 0


def set_trade_rules(args: argparse.Namespace) -> int:
    changes = _rule_changes(parse_json_assignments(args.rules, option="--rule"))

    async def run(container: Container) -> tuple[TradeRulesView, bool]:
        service = _services.backtests(container)
        deployment_id = await _deployment(container, args)
        before = await service.rules(deployment_id)
        values: dict[str, Any] = {}
        if not args.replace and before.effective is not None:
            values = before.effective.model_dump(mode="json")
        elif not args.replace and before.configuration is not None:
            values = dict(before.configuration)  # saved rules that no longer validate, to be repaired
        values = {key: value for key, value in (values | changes).items() if value is not None}
        try:
            rules = TradeRules.model_validate(values)
        except ValidationError as exc:
            raise CliError(f"the trade rules are not valid: {describe_validation(exc)}") from None
        view = await service.set_rules(deployment_id, rules, actor=CLI_ACTOR)
        return view, view.configuration != before.configuration

    view, changed = run_with_container(load_settings(), run)
    _print_rules(view)
    if changed:
        print(
            "Saved. Backtests run with other trade rules are now outdated; their results stay.",
            file=sys.stderr,
        )
    else:
        print("These were already the configuration's trade rules: nothing changed.", file=sys.stderr)
    return 0


def clear_trade_rules(args: argparse.Namespace) -> int:
    async def run(container: Container) -> tuple[TradeRulesView, bool]:
        service = _services.backtests(container)
        deployment_id = await _deployment(container, args)
        before = await service.rules(deployment_id)
        return await service.clear_rules(deployment_id, actor=CLI_ACTOR), before.configuration is not None

    view, cleared = run_with_container(load_settings(), run)
    _print_rules(view)
    if not cleared:
        print("The configuration had no trade rules of its own: nothing changed.", file=sys.stderr)
    elif view.source is TradeRulesSource.STRATEGY:
        print(
            "Cleared: the strategy's declared trade rules apply now. Backtests run with other rules are now "
            "outdated; their results stay.",
            file=sys.stderr,
        )
    else:
        print(
            "Cleared: no trade rules apply now, so it cannot be backtested until they are set "
            "(qt backtests rules set).",
            file=sys.stderr,
        )
    return 0


def _rule_changes(values: Mapping[str, Any]) -> dict[str, Any]:
    """``--rule`` values checked against the rule names, with choices in any case and '-' for '_'."""
    unknown = sorted(set(values) - set(_RULES))
    if unknown:
        raise CliError(f"unknown trade rule: {', '.join(unknown)} (the rules: {', '.join(_RULES)})")
    changes: dict[str, Any] = {}
    for key, value in values.items():
        if isinstance(value, str) and _choices(key):
            value = value.strip().upper().replace("-", "_")
        changes[key] = value
    return changes


def _choices(name: str) -> tuple[StrEnum, ...]:
    annotation = TradeRules.model_fields[name].annotation
    if isinstance(annotation, type) and issubclass(annotation, StrEnum):
        return tuple(annotation)
    return ()


def _print_rules(view: TradeRulesView) -> None:
    rows = [
        ("Configuration", str(view.deployment_id)),
        ("In use", "none" if view.source is None else _SOURCES[view.source]),
    ]
    if view.problem:
        rows.append(("Problem", view.problem))
    if view.effective is None and view.configuration is not None:
        rows.append(("Saved", json_text(view.configuration)))
    if view.source is not TradeRulesSource.STRATEGY:
        rows.append(
            (
                "Strategy",
                "declares trade rules: qt backtests rules clear goes back to them"
                if view.strategy is not None
                else "declares no trade rules",
            )
        )
    print_rows(rows)
    print()
    _print_rules_table(view.effective)


def _print_rules_table(rules: TradeRules | None) -> None:
    print_table(
        ("RULE", "VALUE", "MEANING"),
        [
            (name, "-" if rules is None else _value_text(getattr(rules, name)), _meaning(name))
            for name in _RULES
        ],
    )


def _meaning(name: str) -> str:
    text = TradeRules.model_fields[name].description or ""
    choices = _choices(name)
    return f"{text} Choices: {', '.join(cli_name(choice) for choice in choices)}." if choices else text


def _value_text(value: object) -> str:
    match value:
        case None:
            return "-"
        case StrEnum():
            return cli_name(value)
        case Decimal():
            return decimal_text(value)
    return json_text(value)


def _price(value: Decimal | None) -> str:
    """``104.2`` rather than ``104.20000000``: prices are stored with 8 decimals (as in ``qt signals``)."""
    return "-" if value is None else format(value.normalize(), "f")


# ---- queueing and the latest result ---------------------------------------------------------------------


def run_backtest(args: argparse.Namespace) -> int:
    async def run(container: Container) -> BacktestQueueResult:
        return await _services.backtests(container).queue(
            await _deployment(container, args), args.instrument, args.dataset, actor=CLI_ACTOR
        )

    result = run_with_container(load_settings(), run)
    view = result.run
    print_rows(_run_rows(view))
    follow = f"qt backtests show {view.id}"
    if result.created:
        print(
            f"Queued: the backtest worker (qt-backtest-worker) runs it; follow it with {follow}",
            file=sys.stderr,
        )
    elif view.status is BacktestStatus.SUCCEEDED:
        print(
            "The same backtest (configuration, instrument, dataset and settings) already succeeded, and a "
            f"replay gives the same results, so it was not run again: {follow}",
            file=sys.stderr,
        )
    else:
        print(
            f"The same backtest was already queued or running, so this is that one; follow it with {follow}",
            file=sys.stderr,
        )
    if result.worker_problem:
        print(f"warning: {result.worker_problem}", file=sys.stderr)
    return 0


def latest_backtest(args: argparse.Namespace) -> int:
    async def run(container: Container) -> BacktestLatest:
        return await _services.backtests(container).latest(
            await _deployment(container, args), args.instrument
        )

    view = run_with_container(load_settings(), run)
    rows = [
        ("Configuration", f"'{view.label}' ({view.deployment_id})"),
        ("Instrument", view.instrument_key),
        (
            "Interval",
            "-" if view.interval is None else f"{view.interval.value} (the candles a dataset needs)",
        ),
        ("State", _state_text(view.state)),
    ]
    if view.changed:
        rows.append(("Changed", ", ".join(view.changed)))
    source = view.rules.source
    rows.append(("Trade rules", _SOURCES[source] if source is not None else view.rules.problem or "none"))
    if view.problem:
        rows.append(("Cannot run", view.problem))
    if view.in_progress is not None:
        rows.append(("In progress", f"{view.in_progress.id}: {_status_text(view.in_progress)}"))
    if view.last_failed is not None:
        rows.append(("Last failed", f"{view.last_failed.id}: {_status_text(view.last_failed)}"))
    if view.outdated_runs:
        rows.append(
            (
                "Older runs",
                f"{view.outdated_runs:,} succeeded with other settings, kept for comparison (qt backtests "
                f"list --workspace {shell_arg(args.workspace)} --config {shell_arg(args.config)} "
                f"--instrument {view.instrument_key})",
            )
        )
    print_rows(rows)
    shown = view.current or view.outdated
    if shown is not None:
        print()
        print_rows(
            [
                ("Backtest", str(shown.id) + (" (OUTDATED)" if shown.outdated else "")),
                ("Data", f"{_data_text(shown)}, {shown.date_from} to {shown.date_to}"),
                ("Finished", format_time(shown.finished_at)),
                *(_headline_rows(shown.summary.metrics) if shown.summary is not None else []),
            ]
        )
        print(f"Everything about it: qt backtests show {shown.id}", file=sys.stderr)
    if view.state is not BacktestState.CURRENT and view.problem is None and view.in_progress is None:
        interval = "" if view.interval is None else f" --interval {view.interval.value}"
        print(
            f"Run one over a READY dataset (qt datasets list --instrument {view.instrument_key}{interval} "
            f"--status ready): qt backtests run {shell_arg(args.workspace)} {shell_arg(args.config)} "
            f"--instrument {view.instrument_key} --dataset DATASET",
            file=sys.stderr,
        )
    if view.worker_problem:
        print(f"warning: {view.worker_problem}", file=sys.stderr)
    return 0


def _state_text(state: BacktestState) -> str:
    match state:
        case BacktestState.CURRENT:
            return "CURRENT: a backtest with the current settings succeeded"
        case BacktestState.OUTDATED:
            return "OUTDATED: backtests succeeded, but the settings changed since; the latest is below"
        case BacktestState.NOT_BACKTESTED:
            return "Not backtested: no backtest of this configuration on this instrument succeeded"


# ---- listing and results ----------------------------------------------------------------------------------


def list_backtests(args: argparse.Namespace) -> int:
    if (args.workspace is None) != (args.config is None):
        raise CliError("--workspace and --config go together: they name one saved configuration")

    async def run(container: Container) -> list[BacktestRunView]:
        return await _services.backtests(container).list_runs(
            deployment_id=None if args.config is None else await _deployment(container, args),
            instrument=args.instrument,
            status=args.status,
            limit=args.limit,
            offset=args.offset,
        )

    views = run_with_container(load_settings(), run)
    if not views:
        print("No backtests match." if args.offset == 0 else "No more backtests.", file=sys.stderr)
        return 0
    print_table(
        (
            "BACKTEST",
            "CREATED",
            "CONFIGURATION",
            "INSTRUMENT",
            "INTERVAL",
            "DATA",
            "DATES",
            "STATUS",
            "TRADES",
            "NET RETURN",
            "SETTINGS",
        ),
        [
            (
                str(view.id),
                format_time(view.created_at),
                f"{view.workspace_slug}/{view.label}",
                view.instrument_key,
                view.interval.value,
                _data_text(view),
                f"{view.date_from} to {view.date_to}",
                cli_name(view.status),
                "-" if view.summary is None else f"{view.summary.metrics.closed_trades:,}",
                "-" if view.summary is None else f"{decimal_text(view.summary.metrics.net_return_pct)}%",
                {False: "current", True: "OUTDATED", None: "unknown"}[view.outdated],
            )
            for view in views
        ],
    )
    if len(views) == args.limit:
        print(f"More backtests may follow: add --offset {args.offset + args.limit}", file=sys.stderr)
    return 0


def show_backtest(args: argparse.Namespace) -> int:
    detail = run_with_container(load_settings(), lambda c: _services.backtests(c).get(args.backtest))
    run, settings = detail.run, detail.run.settings
    rows = _run_rows(run, changed=detail.changed, problem=detail.current_problem)
    if detail.dataset.coverage is not None:
        rows.append(("Coverage", coverage_text(detail.dataset.coverage)))
    rows.extend(_settings_rows(settings))
    rows.append(("Requested", f"by {run.requested_by or '-'} at {format_time(run.created_at)}"))
    print_rows(rows)
    print()
    _print_recorded_rules(settings.get("trade_rules"))
    if run.summary is not None:
        print()
        print_rows(_summary_rows(run.summary))
    if args.curve:
        if detail.curve_problem:
            print(f"warning: the equity curve: {detail.curve_problem}", file=sys.stderr)
        elif detail.equity_curve:
            print()
            print_table(
                ("AT", "EQUITY"),
                [(format_time(point.at), decimal_text(point.equity)) for point in detail.equity_curve],
            )
        else:
            print("No equity curve is stored: the backtest has not succeeded.", file=sys.stderr)
    if run.trade_count:
        print(f"Its {run.trade_count:,} closed trades: qt backtests trades {run.id}", file=sys.stderr)
    if run.summary is not None:
        print(
            "These results replay the past on the dataset's candles: they are not a forecast.",
            file=sys.stderr,
        )
    return 0


def _run_rows(
    view: BacktestRunView, *, changed: tuple[str, ...] = (), problem: str | None = None
) -> list[tuple[str, str]]:
    return [
        ("Backtest", str(view.id)),
        ("Status", _status_text(view)),
        ("Configuration", f"'{view.label}' of workspace {view.workspace_slug} ({view.deployment_id})"),
        ("Strategy", f"{view.strategy_id} {view.strategy_version}, code fingerprint {view.code_fingerprint}"),
        ("Instrument", f"{view.instrument_key} ({view.symbol}), {view.interval.value} candles"),
        ("Data", source_text(view.provider, view.source, simulated=view.simulated)),
        ("Dates", f"{view.date_from} to {view.date_to} (exchange dates, both included)"),
        ("Dataset", f"{view.dataset_id}, content SHA {view.dataset_sha}"),
        ("Settings", _settings_state(view.outdated, changed, problem)),
        ("Settings hash", view.settings_hash),
    ]


def _status_text(view: BacktestRunView) -> str:
    match view.status:
        case BacktestStatus.QUEUED:
            return (
                f"QUEUED at {format_time(view.created_at)}: waiting for the backtest worker "
                "(qt-backtest-worker)"
            )
        case BacktestStatus.RUNNING:
            return f"RUNNING by {view.worker_id or '-'} since {format_time(view.started_at)}"
        case BacktestStatus.SUCCEEDED:
            return f"SUCCEEDED at {format_time(view.finished_at)}"
        case BacktestStatus.FAILED:
            return f"FAILED at {format_time(view.finished_at)}: {view.error or 'no reason recorded'}"


def _settings_state(outdated: bool | None, changed: tuple[str, ...], problem: str | None) -> str:
    if outdated is None:
        return "unknown: the configuration's current settings cannot be worked out" + (
            f" ({problem})" if problem else ""
        )
    if outdated:
        return "OUTDATED: the configuration's settings changed since" + (
            f": {', '.join(changed)}" if changed else ""
        )
    return "current: the configuration's settings are still the ones it used"


def _data_text(view: BacktestRunView) -> str:
    return "SIMULATED" if view.simulated else f"{cli_name(view.provider)} {cli_name(view.source)}"


def _settings_rows(settings: Mapping[str, Any]) -> list[tuple[str, str]]:
    """What the run recorded besides the trade rules: parameters, instrument sizes and risk rules."""
    configuration = _mapping(settings.get("configuration"))
    instrument = _mapping(settings.get("instrument"))
    rows = [
        (
            "Parameters",
            f"{assignments_text(_mapping(configuration.get('config')))} (configuration hash "
            f"{configuration.get('config_hash', '-')})",
        ),
        (
            "Lot and tick",
            f"lot size {instrument.get('lot_size', '-')}, tick size {instrument.get('tick_size', '-')}",
        ),
        (
            "Signal validity",
            f"{settings.get('signal_validity_seconds', '-')} seconds, for signals that do not say how long "
            "they are valid",
        ),
        ("Engine", f"version {settings.get('engine_version', '-')}"),
        ("Trade rules", _SOURCES.get(str(settings.get("trade_rules_source")), "-")),
    ]
    risk = _mapping(settings.get("risk"))
    rows.extend(
        ("Risk rules" if index == 0 else "", f"{key}: {_risk_state(state)}")
        for index, (key, state) in enumerate(sorted(risk.items()))
    )
    not_applied = settings.get("risk_not_applied")
    if isinstance(not_applied, list) and not_applied:
        rows.append(
            (
                "Not applied",
                f"{', '.join(map(str, not_applied))}: rules about the live system do not apply to history",
            )
        )
    return rows


def _mapping(value: object) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _risk_state(state: object) -> str:
    if not isinstance(state, Mapping):
        return "not recorded"
    if not state.get("enabled"):
        return "off"
    if "error" in state:
        return f"on, with invalid parameters: {state['error']}"
    params = _mapping(state.get("params"))
    return f"on ({assignments_text(params)})" if params else "on"


def _print_recorded_rules(raw: object) -> None:
    if not isinstance(raw, Mapping):
        print("Trade rules: not recorded")
        return
    try:
        rules = TradeRules.model_validate(raw)
    except ValidationError:  # recorded by an older version: shown as stored
        print_table(("RULE", "VALUE"), [(str(name), json_text(value)) for name, value in raw.items()])
        return
    _print_rules_table(rules)


def _summary_rows(summary: BacktestSummary) -> list[tuple[str, str]]:
    period, metrics, signals = summary.period, summary.metrics, summary.signals
    rows = [
        (
            "Evaluated",
            f"{format_time(period.evaluated_from)} to {format_time(period.evaluated_to)}: "
            f"{period.evaluated_candles:,} candles, after {period.warmup_candles:,} warm-up candles that "
            "only fed the indicators",
        ),
        *_headline_rows(metrics),
        ("Average win", f"{_measure_text(metrics.average_win)} (the mean net result of winning trades)"),
        ("Average loss", f"{_measure_text(metrics.average_loss)} (the mean net result of losing trades)"),
        (
            "Gross result",
            f"{decimal_text(metrics.gross_pnl)} ({decimal_text(metrics.gross_return_pct)}% of the initial "
            "capital), at reference prices without fees or slippage",
        ),
        ("Fees", decimal_text(metrics.fees)),
        ("Slippage", decimal_text(metrics.slippage)),
        ("Final equity", f"{decimal_text(metrics.final_equity)}, the open position included at its mark"),
    ]
    if metrics.both_touched_trades:
        rows.append(
            (
                "Both touched",
                f"{metrics.both_touched_trades:,} trades: one candle reached the stop-loss and the target, "
                "and the stop-loss was assumed",
            )
        )
    if metrics.gap_exits:
        rows.append(("Gap exits", f"{metrics.gap_exits:,} trades exited at the open, beyond their level"))
    blocked = ", ".join(f"{rule} {count:,}" for rule, count in signals.blocked_by_rule.items())
    rows.append(
        (
            "Signals",
            f"{signals.proposed:,} proposed; {signals.allowed:,} allowed ({signals.updates:,} of them "
            f"updates); {signals.blocked:,} blocked{f' ({blocked})' if blocked else ''}; "
            f"{signals.duplicates:,} duplicates; {signals.invalidations:,} invalidations; "
            f"{signals.expired:,} expired",
        )
    )
    position = summary.open_position
    if position is not None:
        rows.append(
            (
                "Open position",
                f"{position.side.value} {position.quantity:,} units from {format_time(position.entry_at)} at "
                f"{_price(position.entry_price)}, held {position.candles_held:,} candles: not a closed "
                "trade",
            )
        )
        rows.append(
            (
                "",
                f"marked at {_price(position.mark_price)} at {format_time(position.marked_at)}: "
                f"{decimal_text(position.unrealized_pnl)} unrealized, after the entry's fees and before exit "
                f"costs; stop-loss {_price(position.stop_loss)}, target {_price(position.target)}",
            )
        )
    rows.extend(
        ("Pending at end" if index == 0 else "", item) for index, item in enumerate(summary.pending_at_end)
    )
    if summary.skipped_entries_total:
        listed = len(summary.skipped_entries)
        more = f", the first {listed:,} listed" if summary.skipped_entries_total > listed else ""
        rows.append(("Skipped entries", f"{summary.skipped_entries_total:,}{more}"))
        rows.extend(
            ("", f"{format_time(item.at)} {item.signal_type.value}: {item.reason}")
            for item in summary.skipped_entries
        )
    rows.append(("Equity curve", f"{summary.equity_points:,} points (--curve prints them, sampled down)"))
    rows.extend(("Note" if index == 0 else "", note) for index, note in enumerate(summary.notes))
    return rows


def _headline_rows(metrics: BacktestMetrics) -> list[tuple[str, str]]:
    drawdown = metrics.max_drawdown_pct
    share = (
        f"{decimal_text(drawdown.value)}% of the peak before it"
        if drawdown.value is not None
        else f"share undefined: {drawdown.reason or 'no reason recorded'}"
    )
    span = (
        f", from {format_time(metrics.drawdown_peak_at)} to {format_time(metrics.drawdown_trough_at)}"
        if metrics.drawdown_peak_at is not None and metrics.drawdown_trough_at is not None
        else ""
    )
    return [
        (
            "Closed trades",
            f"{metrics.closed_trades:,}: {metrics.wins:,} wins, {metrics.losses:,} losses, "
            f"{metrics.breakevens:,} breakeven (a net result above, below or at 0.00)",
        ),
        (
            "Win rate",
            f"{_measure_text(metrics.win_rate_pct, '%')} = winning closed trades / all closed trades x 100 "
            "(breakevens count; the open position and signals do not)",
        ),
        (
            "Net result",
            f"{decimal_text(metrics.net_pnl)} ({decimal_text(metrics.net_return_pct)}% of the initial "
            "capital), after fees and slippage",
        ),
        (
            "Profit factor",
            f"{_measure_text(metrics.profit_factor)} = net result of winning trades / |net result of losing "
            "trades|",
        ),
        (
            "Max drawdown",
            f"{decimal_text(metrics.max_drawdown)} ({share}){span}; equity marked at every candle's close",
        ),
    ]


def _measure_text(measure: Measure, unit: str = "") -> str:
    if measure.value is None:
        return f"undefined: {measure.reason or 'no reason recorded'}"
    return f"{decimal_text(measure.value)}{unit}"


# ---- trades --------------------------------------------------------------------------------------------


def list_trades(args: argparse.Namespace) -> int:
    page = run_with_container(
        load_settings(),
        lambda c: _services.backtests(c).trades(args.backtest, offset=args.offset, limit=args.limit),
    )
    if not page.trades:
        if page.total:
            print("No more trades.", file=sys.stderr)
        else:
            print(
                "No closed trades: the backtest has not succeeded, or no trade closed "
                f"(qt backtests show {page.run_id} says which).",
                file=sys.stderr,
            )
        return 0
    print_table(
        (
            "#",
            "SIDE",
            "QTY",
            "ENTRY AT",
            "ENTRY",
            "EXIT AT",
            "EXIT",
            "REASON",
            "CANDLES",
            "GROSS",
            "FEES",
            "SLIPPAGE",
            "NET",
            "RETURN",
            "OUTCOME",
            "FLAGS",
        ),
        [
            (
                str(trade.number),
                cli_name(trade.side),
                f"{trade.quantity:,}",
                format_time(trade.entry_at),
                _price(trade.entry_price),
                format_time(trade.exit_at),
                _price(trade.exit_price),
                cli_name(trade.exit_reason),
                f"{trade.candles_held:,}",
                decimal_text(trade.gross_pnl),
                decimal_text(trade.fees),
                decimal_text(trade.slippage),
                decimal_text(trade.net_pnl),
                f"{decimal_text(trade.return_pct)}%",
                cli_name(trade.outcome),
                ",".join(
                    flag
                    for flag, present in (("both-touched", trade.both_touched), ("gap-exit", trade.gap_exit))
                    if present
                )
                or "-",
            )
            for trade in page.trades
        ],
    )
    end = page.offset + len(page.trades)
    print(f"Trades {page.offset + 1:,}-{end:,} of {page.total:,}.", file=sys.stderr)
    if end < page.total:
        print(f"More trades: add --offset {end}", file=sys.stderr)
    print(f"One trade in detail: qt backtests trade {page.run_id} NUMBER", file=sys.stderr)
    return 0


def show_trade(args: argparse.Namespace) -> int:
    page = run_with_container(
        load_settings(),
        lambda c: _services.backtests(c).trades(args.backtest, offset=args.number - 1, limit=1),
    )
    if not page.trades:
        raise CliError(f"backtest {args.backtest} has no closed trade {args.number}: it has {page.total:,}")
    trade = page.trades[0]
    rows = [
        ("Trade", f"{trade.number:,} of {page.total:,}: {trade.side.value} {trade.quantity:,} units"),
        (
            "Entry",
            f"filled at {_price(trade.entry_price)} in the candle from {format_time(trade.entry_at)}; "
            f"reference price {_price(trade.entry_reference)}, before slippage",
        ),
        (
            "Exit",
            f"{trade.exit_reason.value}: filled at {_price(trade.exit_price)} in the candle from "
            f"{format_time(trade.exit_at)}; reference price {_price(trade.exit_reference)}",
        ),
        (
            "Levels",
            f"stop-loss {_price(trade.stop_loss)}, target {_price(trade.target)} (in force when it closed)",
        ),
        ("Held", f"{trade.candles_held:,} candles"),
        (
            "Result",
            f"{trade.outcome.value}: net {decimal_text(trade.net_pnl)} ({decimal_text(trade.return_pct)}% of "
            f"the entry's reference value); gross {decimal_text(trade.gross_pnl)}, fees "
            f"{decimal_text(trade.fees)}, slippage {decimal_text(trade.slippage)}",
        ),
    ]
    if trade.both_touched:
        rows.append(
            (
                "Both touched",
                "one candle reached the stop-loss and the target; the order of prices inside a candle is "
                "unknown, so the stop-loss was assumed",
            )
        )
    if trade.gap_exit:
        rows.append(("Gap exit", "the candle opened beyond the level, so the exit filled at the open"))
    rows.extend(_signal_rows("Entry signal", trade.entry_signal))
    if trade.exit_signal is not None:
        rows.extend(_signal_rows("Exit signal", trade.exit_signal))
    print_rows(rows)
    return 0


def _signal_rows(title: str, signal: SignalRef) -> list[tuple[str, str]]:
    rows = [
        (
            title,
            f"{signal.signal_type.value} decided at {format_time(signal.decided_at)}, the close of the "
            f"candle from {format_time(signal.candle_start)}",
        )
    ]
    if signal.entry_price is not None or signal.stop_loss is not None or signal.targets:
        targets = ", ".join(f"{level.label} {_price(level.price)}" for level in signal.targets) or "-"
        prices = f"entry {_price(signal.entry_price)}, stop-loss {_price(signal.stop_loss)}"
        rows.append(("", f"{prices}, targets {targets}"))
    rows.extend(("", f"reason: {reason}") for reason in signal.reasons)
    if signal.indicators:
        values = ", ".join(f"{name}={value or '-'}" for name, value in signal.indicators.items())
        rows.append(("", f"indicators: {values}"))
    return rows
