"""Backtests: queueing them, running them in the backtest worker, and reading their results (M9; see
docs/backtesting.md).

A backtest replays one saved strategy configuration on one READY dataset of one instrument in the
configuration's scope (``app.backtest.engine``). Queueing checks that the replay can run and records the
settings that decide its results, with their hash (``app.backtest.identity``). Asking again while the same
backtest (configuration, instrument, dataset and settings) waits, runs or has succeeded returns that one:
a replay is deterministic, so it is not run twice. The backtest worker (``qt-backtest-worker``) claims the
oldest queued backtest, checks that the strategy's code and the recorded settings can still be reproduced,
replays the dataset and stores the summary, the trades and the equity curve (SUCCEEDED), or why it could
not (FAILED).

Runs are kept for comparison. Against a configuration's current settings on an instrument, its backtests
are CURRENT (a succeeded run used them), OUTDATED (runs succeeded with other settings; ``changed`` names
what changed) or NOT_BACKTESTED. Nothing reruns a backtest by itself.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Collection
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Final, Self
from uuid import UUID

import sqlalchemy as sa
from pydantic import ValidationError
from sqlalchemy import ColumnElement, func, select, update
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import defer

from app.backtest.dataset import dataset_sha, to_candles
from app.backtest.engine import (
    HISTORY_RULES,
    BacktestError,
    BacktestResult,
    Limits,
    Replay,
    run_backtest,
    setup_problem,
)
from app.backtest.identity import backtest_settings, changed_paths, settings_hash, snapshot_policy
from app.container import Container
from app.core.clock import utc_now
from app.core.config import Settings
from app.core.errors import AppError, ConflictError, NotFoundError, ValidationFailedError
from app.core.logging import get_logger
from app.domain.enums import (
    BacktestState,
    BacktestStatus,
    CandleInterval,
    DataRequirement,
    DatasetSource,
    DatasetStatus,
    Provider,
    ScopeKind,
    TradeRulesSource,
)
from app.domain.models import Candle, Instrument
from app.domain.models.backtest import BacktestSummary, BacktestTrade, EquityPoint, TradeRules
from app.domain.models.base import DomainModel, UtcDatetime
from app.market_data.calendars.service import MarketCalendar
from app.persistence.database import Database
from app.persistence.models import (
    BacktestDatasetRow,
    BacktestRunRow,
    InstrumentRow,
    StrategyConfigurationRow,
    StrategyDeploymentRow,
    WorkspaceInstrumentRow,
    WorkspaceRow,
)
from app.risk.engine import RiskPolicy
from app.services.audit import add_audit
from app.services.datasets import (
    MAX_ERROR,
    ClaimLostError,
    DatasetView,
    backtest_worker_problem,
    dataset_not_found,
    dataset_not_ready,
    dataset_view,
    expected_failure,
    failure_text,
    load_dataset_candles,
)
from app.services.instruments import find_instrument
from app.services.risk import load_policy
from app.services.strategies import stored_scope_ids
from app.strategies.indicators import describe_validation
from app.strategies.registry import (
    RegisteredStrategy,
    StrategyConfigError,
    StrategyRegistry,
    builtin_registry,
)
from app.streaming.redis_bus import RedisBus

log = get_logger(__name__)

ENTITY: Final = "backtest_run"
DEPLOYMENT_ENTITY: Final = "strategy_deployment"
MAX_STORED_TRADES: Final = 20_000  # closed trades one run stores; a replay that makes more fails
LIST_LIMIT_MAX: Final = 500
TRADES_LIMIT_MAX: Final = 500
ACTIVE: Final = (BacktestStatus.QUEUED, BacktestStatus.RUNNING)
UNREADABLE: Final = "the stored results cannot be read by this version; run the backtest again"
_REUSED: Final = (BacktestStatus.QUEUED, BacktestStatus.RUNNING, BacktestStatus.SUCCEEDED)
_FINISHED: Final = (BacktestStatus.SUCCEEDED, BacktestStatus.FAILED)
# Problems the configuration's state causes are conflicts (409); the others are about the request (422).
_CONFLICTS: Final = frozenset(
    {
        "deployment_archived",
        "deployment_blocked",
        "backtest_rules_missing",
        "backtest_rules_invalid",
        "backtest_risk_invalid",
    }
)
_LIGHT: Final = (
    defer(BacktestRunRow.trades, raiseload=True),
    defer(BacktestRunRow.equity_curve, raiseload=True),
)


class TradeRulesView(DomainModel):
    """The trade rules a configuration's backtests use: its own when set, else the strategy's declared
    defaults."""

    deployment_id: UUID
    effective: TradeRules | None  # what a backtest uses; None with ``problem``
    source: TradeRulesSource | None
    configuration: dict[str, Any] | None  # the rules saved with the configuration, as stored
    strategy: TradeRules | None  # the strategy's declared defaults
    problem: str | None  # why no rules apply


class BacktestRunView(DomainModel):
    """One backtest. ``summary`` is filled in once it SUCCEEDED; the trades are paged separately."""

    id: UUID
    deployment_id: UUID
    label: str
    workspace_slug: str
    instrument_id: UUID
    instrument_key: str
    symbol: str
    dataset_id: UUID
    dataset_sha: str
    provider: Provider
    source: DatasetSource
    simulated: bool  # replayed simulator candles: not market history
    date_from: date  # the dataset's exchange-local dates, both included
    date_to: date
    strategy_id: str
    strategy_version: str
    code_fingerprint: str
    configuration_id: UUID
    config_hash: str
    interval: CandleInterval
    settings: dict[str, Any]  # everything that decides the results (app.backtest.identity)
    settings_hash: str
    status: BacktestStatus
    requested_by: str | None
    worker_id: str | None
    started_at: UtcDatetime | None
    finished_at: UtcDatetime | None
    error: str | None
    summary: BacktestSummary | None
    trade_count: int  # closed trades stored
    outdated: bool | None  # its settings differ from the configuration's current ones; None: unknown
    created_at: UtcDatetime
    updated_at: UtcDatetime


class BacktestQueueResult(DomainModel):
    run: BacktestRunView
    created: bool  # False: the same backtest was already queued, running or done
    worker_problem: str | None  # why it would wait


class BacktestDetail(DomainModel):
    run: BacktestRunView
    dataset: DatasetView
    equity_curve: tuple[EquityPoint, ...]  # sampled down by the engine
    curve_problem: str | None  # why the stored curve cannot be shown
    changed: tuple[str, ...]  # the settings that differ from the configuration's current ones
    current_problem: str | None  # why the current settings cannot be worked out


class BacktestTradesPage(DomainModel):
    run_id: UUID
    total: int  # closed trades of the run
    offset: int
    limit: int
    trades: tuple[BacktestTrade, ...]


class BacktestLatest(DomainModel):
    """A configuration's backtests on one instrument against its current settings."""

    deployment_id: UUID
    label: str
    instrument_id: UUID
    instrument_key: str
    interval: CandleInterval | None  # the interval a dataset must have; None when it has no single one
    state: BacktestState
    current: BacktestRunView | None  # the latest succeeded run with the current settings
    outdated: BacktestRunView | None  # without a current one: the latest succeeded run
    changed: tuple[str, ...]  # what changed since ``outdated`` ran
    outdated_runs: int  # succeeded runs with other settings, kept for comparison
    in_progress: BacktestRunView | None  # the newest queued or running one
    last_failed: BacktestRunView | None  # the newest finished one, when it failed
    settings_hash: str | None  # of the current settings; None with ``problem``
    rules: TradeRulesView
    problem: str | None  # why it cannot be backtested on the instrument now
    worker_problem: str | None  # why queued backtests would wait


@dataclass(frozen=True, slots=True)
class _Problem:
    code: str
    text: str


@dataclass(frozen=True, slots=True)
class _Loaded:
    row: StrategyDeploymentRow
    workspace: WorkspaceRow
    configuration: StrategyConfigurationRow


@dataclass(frozen=True, slots=True)
class _Settings:
    """A configuration's current backtest settings on one instrument."""

    entry: RegisteredStrategy
    configuration: StrategyConfigurationRow
    interval: CandleInterval
    rules: TradeRules
    rules_source: TradeRulesSource
    values: dict[str, Any]
    digest: str
    policy: RiskPolicy


@dataclass(frozen=True, slots=True)
class _RunContext:
    """The names a run's view shows, from its configuration, instrument and dataset."""

    label: str
    workspace_slug: str
    instrument_key: str
    symbol: str
    provider: Provider
    source: DatasetSource
    date_from: date
    date_to: date


class BacktestService:
    def __init__(
        self,
        db: Database,
        bus: RedisBus,
        settings: Settings,
        *,
        registry: StrategyRegistry | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self.db = db
        self.bus = bus
        self.settings = settings
        self.registry = builtin_registry() if registry is None else registry
        self.clock = clock

    @classmethod
    def from_container(
        cls,
        container: Container,
        *,
        registry: StrategyRegistry | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> Self:
        return cls(container.db, container.bus, container.settings, registry=registry, clock=clock)

    # ---- queueing -------------------------------------------------------------------------------

    async def queue(
        self,
        deployment_id: UUID,
        instrument: UUID | str,
        dataset_id: UUID,
        *,
        actor: str,
        client_ip: str | None = None,
    ) -> BacktestQueueResult:
        """Queue a backtest of a saved configuration on one instrument in its scope, over a READY dataset of
        that instrument, after checking that it can run. Asking again while the same backtest waits, runs or
        has succeeded returns that one."""
        r = BacktestRunRow
        now = self.clock()
        async with self.db.transaction() as session:
            loaded = await _load(session, deployment_id)
            listing = _instrument(await find_instrument(session, instrument))
            dataset = await session.get(BacktestDatasetRow, dataset_id)
            if dataset is None:
                raise dataset_not_found(dataset_id)
            if dataset.instrument_id != listing.id:
                raise ValidationFailedError(
                    f"Dataset {dataset_id} holds another instrument's candles, not {listing.canonical_key}'s",
                    code="backtest_dataset_mismatch",
                )
            if dataset.status is not DatasetStatus.READY or dataset.content_sha is None:
                raise dataset_not_ready(dataset)
            label = loaded.row.label
            where = f"Cannot backtest '{label}' on {listing.canonical_key}"
            ready = await self._ready(session, loaded, listing, await self._current(session, loaded, listing))
            if isinstance(ready, _Problem):
                raise _refusal(where, ready)
            problem = _dataset_problem(dataset, ready)
            if problem is not None:
                raise _refusal(where, problem)
            context = _RunContext(
                label,
                loaded.workspace.slug,
                listing.canonical_key,
                listing.symbol,
                dataset.provider,
                dataset.source,
                dataset.date_from,
                dataset.date_to,
            )
            key = f"{ENTITY}:{deployment_id}:{listing.id}:{dataset_id}:{ready.digest}"
            await session.execute(select(func.pg_advisory_xact_lock(func.hashtext(key))))
            existing = await session.scalar(
                select(r)
                .options(*_LIGHT)
                .where(
                    r.deployment_id == deployment_id,
                    r.instrument_id == listing.id,
                    r.dataset_id == dataset_id,
                    r.settings_hash == ready.digest,
                    r.status.in_(_REUSED),
                )
                .order_by(r.created_at)
                .limit(1)
            )
            if existing is not None:
                view, created = _run_view(existing, context, outdated=False), False
            else:
                row = BacktestRunRow(
                    deployment_id=deployment_id,
                    instrument_id=listing.id,
                    dataset_id=dataset_id,
                    dataset_sha=dataset.content_sha,
                    strategy_id=ready.entry.strategy_id,
                    strategy_version=ready.entry.version,
                    code_fingerprint=ready.entry.fingerprint,
                    configuration_id=ready.configuration.id,
                    config_hash=ready.configuration.config_hash,
                    interval=ready.interval,
                    settings=ready.values,
                    settings_hash=ready.digest,
                    status=BacktestStatus.QUEUED,
                    requested_by=actor[:64],
                    trade_count=0,
                    created_at=now,
                    updated_at=now,
                )
                session.add(row)
                await session.flush()
                add_audit(
                    session,
                    actor=actor,
                    action="backtest.queue",
                    entity_type=ENTITY,
                    entity_id=row.id,
                    details={
                        "label": label,
                        "workspace": loaded.workspace.slug,
                        "instrument": listing.canonical_key,
                        "dataset_id": str(dataset_id),
                        "strategy": f"{ready.entry.strategy_id}@{ready.entry.version}",
                        "settings_hash": ready.digest,
                    },
                    client_ip=client_ip,
                )
                view, created = _run_view(row, context, outdated=False), True
        waits = view.status in ACTIVE
        return BacktestQueueResult(
            run=view,
            created=created,
            worker_problem=await backtest_worker_problem(self.bus) if waits else None,
        )

    # ---- trade rules ----------------------------------------------------------------------------

    async def rules(self, deployment_id: UUID) -> TradeRulesView:
        d = StrategyDeploymentRow
        async with self.db.session() as session:
            found = (
                await session.execute(select(d.strategy_id, d.backtest_rules).where(d.id == deployment_id))
            ).first()
        if found is None:
            raise _not_found(deployment_id)
        strategy_id, stored = found
        return _rules_view(deployment_id, stored, self.registry.find(strategy_id))

    async def set_rules(
        self, deployment_id: UUID, rules: TradeRules, *, actor: str, client_ip: str | None = None
    ) -> TradeRulesView:
        """Save the trade rules the configuration's backtests use instead of the strategy's defaults.
        Backtests that used other rules become outdated."""
        return await self._change_rules(
            deployment_id, rules.model_dump(mode="json"), actor=actor, client_ip=client_ip
        )

    async def clear_rules(
        self, deployment_id: UUID, *, actor: str, client_ip: str | None = None
    ) -> TradeRulesView:
        """Go back to the strategy's declared trade rules, when it declares any."""
        return await self._change_rules(deployment_id, None, actor=actor, client_ip=client_ip)

    async def _change_rules(
        self, deployment_id: UUID, stored: dict[str, Any] | None, *, actor: str, client_ip: str | None
    ) -> TradeRulesView:
        d = StrategyDeploymentRow
        now = self.clock()
        async with self.db.transaction() as session:
            row = await session.scalar(select(d).where(d.id == deployment_id).with_for_update())
            if row is None:
                raise _not_found(deployment_id)
            if row.archived_at is not None:
                raise ConflictError(
                    f"Cannot change the trade rules of '{row.label}': it is archived",
                    code="deployment_archived",
                )
            previous = row.backtest_rules
            if previous != stored:
                await session.execute(
                    update(d)
                    .where(d.id == deployment_id)
                    .values(backtest_rules=sa.null() if stored is None else stored, updated_at=now)
                    .execution_options(synchronize_session=False)
                )
                add_audit(
                    session,
                    actor=actor,
                    action="backtest_rules.clear" if stored is None else "backtest_rules.set",
                    entity_type=DEPLOYMENT_ENTITY,
                    entity_id=deployment_id,
                    details={"label": row.label, "rules": stored, "previous": previous},
                    client_ip=client_ip,
                )
            strategy_id = row.strategy_id
        return _rules_view(deployment_id, stored, self.registry.find(strategy_id))

    # ---- results --------------------------------------------------------------------------------

    async def latest(self, deployment_id: UUID, instrument: UUID | str) -> BacktestLatest:
        """A configuration's backtests on one instrument against its current settings: the latest succeeded
        run that used them (CURRENT), else the latest succeeded run (OUTDATED), else NOT_BACKTESTED. Reading
        it never queues a backtest."""
        r = BacktestRunRow
        async with self.db.session() as session:
            loaded = await _load(session, deployment_id)
            listing = _instrument(await find_instrument(session, instrument))
            current = await self._current(session, loaded, listing)
            ready = await self._ready(session, loaded, listing, current)
            digest = current.digest if isinstance(current, _Settings) else None
            mine = (r.deployment_id == deployment_id, r.instrument_id == listing.id)
            succeeded = (*mine, r.status == BacktestStatus.SUCCEEDED)
            newest = (r.finished_at.desc().nulls_last(), r.id)
            current_id: UUID | None = None
            if digest is not None:
                current_id = await session.scalar(
                    select(r.id).where(*succeeded, r.settings_hash == digest).order_by(*newest).limit(1)
                )
            outdated_id: UUID | None = None
            if current_id is None:
                outdated_id = await session.scalar(select(r.id).where(*succeeded).order_by(*newest).limit(1))
            others = [*succeeded] if digest is None else [*succeeded, r.settings_hash != digest]
            outdated_runs = await session.scalar(select(func.count()).select_from(r).where(*others)) or 0
            active_id = await session.scalar(
                select(r.id).where(*mine, r.status.in_(ACTIVE)).order_by(r.created_at.desc(), r.id).limit(1)
            )
            finished = (
                await session.execute(
                    select(r.id, r.status).where(*mine, r.status.in_(_FINISHED)).order_by(*newest).limit(1)
                )
            ).first()
            failed_id = finished[0] if finished is not None and finished[1] is BacktestStatus.FAILED else None
            wanted = [
                run_id for run_id in (current_id, outdated_id, active_id, failed_id) if run_id is not None
            ]
            found = await _fetch(session, r.id.in_(wanted)) if wanted else []
        views = {row.id: _run_view(row, context, _outdated(row, digest)) for row, context in found}
        current_view = None if current_id is None else views.get(current_id)
        outdated_view = None if outdated_id is None else views.get(outdated_id)
        changed: tuple[str, ...] = ()
        if outdated_view is not None and isinstance(current, _Settings):
            changed = tuple(changed_paths(outdated_view.settings, current.values))
        if current_view is not None:
            state = BacktestState.CURRENT
        elif outdated_view is not None:
            state = BacktestState.OUTDATED
        else:
            state = BacktestState.NOT_BACKTESTED
        entry = self.registry.find(loaded.row.strategy_id)
        interval: CandleInterval | None = None
        if isinstance(current, _Settings):
            interval = current.interval
        elif entry is not None and len(entry.intervals) == 1:
            interval = next(iter(entry.intervals))
        return BacktestLatest(
            deployment_id=deployment_id,
            label=loaded.row.label,
            instrument_id=listing.id,
            instrument_key=listing.canonical_key,
            interval=interval,
            state=state,
            current=current_view,
            outdated=outdated_view,
            changed=changed,
            outdated_runs=outdated_runs,
            in_progress=None if active_id is None else views.get(active_id),
            last_failed=None if failed_id is None else views.get(failed_id),
            settings_hash=digest,
            rules=_rules_view(deployment_id, loaded.row.backtest_rules, entry),
            problem=ready.text if isinstance(ready, _Problem) else None,
            worker_problem=await backtest_worker_problem(self.bus),
        )

    async def list_runs(
        self,
        *,
        deployment_id: UUID | None = None,
        instrument: UUID | str | None = None,
        status: BacktestStatus | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[BacktestRunView]:
        """Backtests, newest first, optionally of one configuration, instrument or status. Each says whether
        its settings are outdated against its configuration's current ones."""
        r = BacktestRunRow
        criteria: list[ColumnElement[bool]] = []
        async with self.db.session() as session:
            if deployment_id is not None:
                await _load(session, deployment_id)  # NotFoundError when there is none
                criteria.append(r.deployment_id == deployment_id)
            if instrument is not None:
                criteria.append(r.instrument_id == (await find_instrument(session, instrument)).id)
            if status is not None:
                criteria.append(r.status == status)
            found = await _fetch(
                session, *criteria, limit=max(1, min(limit, LIST_LIMIT_MAX)), offset=max(offset, 0)
            )
            digests = await self._digests(
                session, {(row.deployment_id, row.instrument_id) for row, _ in found}
            )
        return [
            _run_view(row, context, _outdated(row, digests.get((row.deployment_id, row.instrument_id))))
            for row, context in found
        ]

    async def get(self, run_id: UUID) -> BacktestDetail:
        """A backtest with its dataset, its equity curve and what changed since; ``trades`` pages its
        trades."""
        r = BacktestRunRow
        async with self.db.session() as session:
            found = await _fetch(session, r.id == run_id, with_curve=True)
            if not found:
                raise _run_not_found(run_id)
            row, context = found[0]
            dataset = await session.get(BacktestDatasetRow, row.dataset_id)
            instrument_row = await session.get(InstrumentRow, row.instrument_id)
            if dataset is None or instrument_row is None:  # deleted meanwhile, and the run with them
                raise _run_not_found(run_id)
            loaded = await _load(session, row.deployment_id)
            current = await self._current(session, loaded, _instrument(instrument_row))
        curve: tuple[EquityPoint, ...] = ()
        curve_problem: str | None = None
        if row.equity_curve is not None:
            try:
                curve = tuple(EquityPoint.model_validate(point) for point in row.equity_curve)
            except ValidationError:
                curve_problem = UNREADABLE
        changed: tuple[str, ...] = ()
        current_problem: str | None = None
        if isinstance(current, _Settings):
            changed = tuple(changed_paths(row.settings, current.values))
        else:
            current_problem = current.text
        return BacktestDetail(
            run=_run_view(
                row, context, _outdated(row, current.digest if isinstance(current, _Settings) else None)
            ),
            dataset=dataset_view(dataset, instrument_row),
            equity_curve=curve,
            curve_problem=curve_problem,
            changed=changed,
            current_problem=current_problem,
        )

    async def trades(self, run_id: UUID, *, offset: int = 0, limit: int = 100) -> BacktestTradesPage:
        """A page of a succeeded backtest's closed trades, in order. Open positions are in the summary."""
        r = BacktestRunRow
        offset, limit = max(offset, 0), max(1, min(limit, TRADES_LIMIT_MAX))
        async with self.db.session() as session:
            found = (await session.execute(select(r.status, r.trade_count).where(r.id == run_id))).first()
            if found is None:
                raise _run_not_found(run_id)
            status, total = found
            if status is not BacktestStatus.SUCCEEDED:
                total = 0
            raw: list[Any] = []
            if offset < total:
                items = (
                    func.jsonb_array_elements(r.trades)
                    .table_valued(sa.column("value", JSONB), with_ordinality="ordinality")
                    .lateral()
                )
                raw = list(
                    await session.scalars(
                        select(items.c.value)
                        .select_from(r)
                        .join(items, sa.true())
                        .where(r.id == run_id)
                        .order_by(items.c.ordinality)
                        .offset(offset)
                        .limit(limit)
                    )
                )
        try:
            trades = tuple(BacktestTrade.model_validate(item) for item in raw)
        except ValidationError:
            raise ConflictError(
                f"Backtest {run_id}: {UNREADABLE}", code="backtest_results_unreadable"
            ) from None
        return BacktestTradesPage(run_id=run_id, total=total, offset=offset, limit=limit, trades=trades)

    # ---- the backtest worker ----------------------------------------------------------------------

    async def claim_next(self, worker_id: str) -> UUID | None:
        """Claim the oldest queued backtest for this worker (RUNNING); None when none waits."""
        r = BacktestRunRow
        now = self.clock()
        async with self.db.transaction() as session:
            run_id = await session.scalar(
                select(r.id)
                .where(r.status == BacktestStatus.QUEUED)
                .order_by(r.created_at, r.id)
                .limit(1)
                .with_for_update(skip_locked=True)
            )
            if run_id is None:
                return None
            await session.execute(
                update(r)
                .where(r.id == run_id)
                .values(
                    status=BacktestStatus.RUNNING, worker_id=worker_id[:120], started_at=now, updated_at=now
                )
                .execution_options(synchronize_session=False)
            )
            return run_id

    async def keep_alive(self, run_id: UUID, worker_id: str) -> bool:
        """Show that this worker still runs the backtest; False when it is no longer its job."""
        r = BacktestRunRow
        async with self.db.transaction() as session:
            found = await session.scalar(
                update(r)
                .where(r.id == run_id, r.status == BacktestStatus.RUNNING, r.worker_id == worker_id[:120])
                .values(updated_at=self.clock())
                .returning(r.id)
            )
        return found is not None

    async def fail_abandoned(self, *, stale_before: datetime) -> list[UUID]:
        """Fail the backtests left RUNNING by a worker that stopped (no progress since ``stale_before``)."""
        r = BacktestRunRow
        now = self.clock()
        error = "The backtest worker stopped while running it; queue it again"
        async with self.db.transaction() as session:
            failed = await session.scalars(
                update(r)
                .where(r.status == BacktestStatus.RUNNING, r.updated_at < stale_before)
                .values(status=BacktestStatus.FAILED, finished_at=now, updated_at=now, error=error)
                .returning(r.id)
            )
            return list(failed)

    async def run_claimed(self, run_id: UUID, worker_id: str, calendar: MarketCalendar) -> BacktestStatus:
        """Run a backtest this worker claimed and store it SUCCEEDED, or FAILED with the reason. Returns the
        status it ended in; the claim may have been lost meanwhile (it stays as the other party left it)."""
        try:
            await self._run(run_id, worker_id, calendar)
        except ClaimLostError:
            log.warning("backtest_run_claim_lost", run_id=str(run_id))
            return BacktestStatus.FAILED
        except Exception as exc:
            if not expected_failure(exc):
                log.exception("backtest_run_crashed", run_id=str(run_id))
            text = failure_text(exc)
            log.warning("backtest_run_failed", run_id=str(run_id), error=text)
            await self._fail(run_id, worker_id, text)
            return BacktestStatus.FAILED
        return BacktestStatus.SUCCEEDED

    async def _run(self, run_id: UUID, worker_id: str, calendar: MarketCalendar) -> None:
        r = BacktestRunRow
        async with self.db.session() as session:
            run = await session.scalar(select(r).options(*_LIGHT).where(r.id == run_id))
            if run is None or run.status is not BacktestStatus.RUNNING or run.worker_id != worker_id[:120]:
                raise ClaimLostError
            loaded = await _load(session, run.deployment_id)
            dataset = await session.get(BacktestDatasetRow, run.dataset_id)
            instrument_row = await session.get(InstrumentRow, run.instrument_id)
            if dataset is None or instrument_row is None:
                raise BacktestError("its dataset or instrument was deleted")
            if (
                dataset.status is not DatasetStatus.READY
                or dataset.content_sha != run.dataset_sha
                or dataset.interval is not run.interval
            ):
                raise BacktestError("its dataset is no longer the one it was queued on; queue it again")
            stored = await load_dataset_candles(session, dataset.id)
        instrument = _instrument(instrument_row)
        entry = self.registry.find(run.strategy_id)
        if (
            entry is None
            or entry.version != run.strategy_version
            or entry.fingerprint != run.code_fingerprint
        ):
            raise BacktestError("the strategy's code changed after it was queued; queue it again")
        recorded = run.settings
        try:
            configured = recorded["configuration"]["config"]
            config = entry.validate_config(configured)
            rules = TradeRules.model_validate(recorded["trade_rules"])
            rules_source = TradeRulesSource(recorded["trade_rules_source"])
            validity = int(recorded["signal_validity_seconds"])
            policy = snapshot_policy(recorded, loaded.workspace.id)
            rebuilt = backtest_settings(
                entry,
                config=configured,
                config_hash=run.config_hash,
                instrument=instrument,
                interval=run.interval,
                rules=rules,
                rules_source=rules_source,
                policy=policy,
                signal_validity_seconds=validity,
            )
        except ValidationError as exc:
            raise BacktestError(
                f"its recorded settings cannot be read ({describe_validation(exc)}); queue it again"
            ) from None
        except StrategyConfigError as exc:
            raise BacktestError(f"its recorded parameters no longer validate ({exc})") from None
        except (KeyError, TypeError, ValueError) as exc:
            raise BacktestError(
                f"its recorded settings cannot be read ({type(exc).__name__}: {exc}); queue it again"
            ) from None
        if settings_hash(rebuilt) != run.settings_hash:
            changed = ", ".join(changed_paths(recorded, rebuilt)) or "the engine"
            raise BacktestError(
                f"its recorded settings cannot be reproduced now ({changed} changed); queue it again"
            )
        provider, source, interval = dataset.provider, dataset.source, dataset.interval
        simulated = source is DatasetSource.SIMULATED

        def prepare() -> tuple[str, list[Candle]]:
            sha = dataset_sha(provider, source, instrument.id, interval, stored)
            return sha, to_candles(
                stored, instrument=instrument, provider=provider, interval=interval, simulated=simulated
            )

        sha, candles = await asyncio.to_thread(prepare)
        if sha != run.dataset_sha:
            raise BacktestError(
                "the dataset's candles do not match its content SHA; request the dataset again"
            )
        replay = Replay(
            entry=entry,
            config=config,
            instrument=instrument,
            provider=provider,
            interval=interval,
            rules=rules,
            policy=policy,
            calendar=calendar,
            market_region=loaded.workspace.market_region,
            workspace_id=loaded.workspace.id,
            deployment_id=run.deployment_id,
            run_id=run.id,
            configuration_id=run.configuration_id,
            simulated=simulated,
        )
        limits = Limits(
            strategy_timeout_seconds=self.settings.strategy_timeout_seconds,
            max_seconds=self.settings.backtest_max_seconds,
            signal_validity_seconds=validity,
        )
        result = await run_backtest(replay, candles, limits)
        if len(result.trades) > MAX_STORED_TRADES:
            raise BacktestError(
                f"the replay made {len(result.trades):,} trades, more than the {MAX_STORED_TRADES:,} a "
                "backtest stores; use fewer dates, a longer interval or stricter rules"
            )
        summary, curve, trades = await asyncio.to_thread(_dump, result)
        await self._store(run_id, worker_id, summary, curve, trades)

    async def _store(
        self, run_id: UUID, worker_id: str, summary: dict[str, Any], curve: list[Any], trades: list[Any]
    ) -> None:
        """Store the results and mark the backtest SUCCEEDED, if it is still this worker's."""
        r = BacktestRunRow
        now = self.clock()
        async with self.db.transaction() as session:
            stored = await session.scalar(
                update(r)
                .where(r.id == run_id, r.status == BacktestStatus.RUNNING, r.worker_id == worker_id[:120])
                .values(
                    status=BacktestStatus.SUCCEEDED,
                    finished_at=now,
                    updated_at=now,
                    error=None,
                    summary=summary,
                    equity_curve=curve,
                    trades=trades,
                    trade_count=len(trades),
                )
                .returning(r.id)
            )
        if stored is None:
            raise ClaimLostError

    async def _fail(self, run_id: UUID, worker_id: str, error: str) -> None:
        r = BacktestRunRow
        now = self.clock()
        async with self.db.transaction() as session:
            await session.execute(
                update(r)
                .where(r.id == run_id, r.status == BacktestStatus.RUNNING, r.worker_id == worker_id[:120])
                .values(
                    status=BacktestStatus.FAILED, finished_at=now, updated_at=now, error=error[:MAX_ERROR]
                )
            )

    # ---- current settings -------------------------------------------------------------------------

    async def _current(
        self,
        session: AsyncSession,
        loaded: _Loaded,
        instrument: Instrument,
        policies: dict[UUID, RiskPolicy] | None = None,
    ) -> _Settings | _Problem:
        """The configuration's current backtest settings on the instrument, or why they cannot be worked
        out. ``policies`` caches workspace risk policies across calls."""
        row, configuration = loaded.row, loaded.configuration
        entry = self.registry.find(row.strategy_id)
        if entry is None:
            return _Problem("deployment_blocked", f"strategy {row.strategy_id} is no longer in the code")
        if entry.version != row.strategy_version:
            return _Problem(
                "deployment_blocked",
                f"it was saved with version {row.strategy_version} but the code has {entry.version}; "
                "save it again to upgrade",
            )
        if len(entry.intervals) != 1:
            used = ", ".join(sorted(item.value for item in entry.intervals)) or "no"
            return _Problem(
                "backtest_not_possible",
                f"{entry.strategy_id} uses {used} candles; a backtest replays the candles of one interval",
            )
        rules = _rules_view(row.id, row.backtest_rules, entry)
        if rules.effective is None or rules.source is None:
            code = "backtest_rules_missing" if row.backtest_rules is None else "backtest_rules_invalid"
            return _Problem(code, rules.problem or "no trade rules apply")
        try:
            entry.validate_config(configuration.config)
        except StrategyConfigError as exc:
            return _Problem(
                "deployment_blocked", f"its saved parameters no longer validate ({exc}); save it again"
            )
        workspace_id = loaded.workspace.id
        policy = None if policies is None else policies.get(workspace_id)
        if policy is None:
            policy = await load_policy(session, workspace_id)
            if policies is not None:
                policies[workspace_id] = policy
        interval = next(iter(entry.intervals))
        values = backtest_settings(
            entry,
            config=configuration.config,
            config_hash=configuration.config_hash,
            instrument=instrument,
            interval=interval,
            rules=rules.effective,
            rules_source=rules.source,
            policy=policy,
            signal_validity_seconds=self.settings.signal_default_validity_seconds,
        )
        return _Settings(
            entry,
            configuration,
            interval,
            rules.effective,
            rules.source,
            values,
            settings_hash(values),
            policy,
        )

    async def _ready(
        self, session: AsyncSession, loaded: _Loaded, instrument: Instrument, current: _Settings | _Problem
    ) -> _Settings | _Problem:
        """``current`` when the configuration can be backtested on the instrument now, else why not."""
        row, workspace = loaded.row, loaded.workspace
        key = instrument.canonical_key
        if row.archived_at is not None:
            return _Problem("deployment_archived", "it is archived")
        if row.scope_kind is ScopeKind.WORKSPACE:
            wi = WorkspaceInstrumentRow
            member = await session.scalar(
                select(wi.instrument_id).where(
                    wi.workspace_id == workspace.id, wi.instrument_id == instrument.id
                )
            )
            if member is None:
                return _Problem(
                    "backtest_scope_rejected",
                    f"its scope is the whole workspace, and {key} is not in workspace {workspace.slug}",
                )
        else:
            scope = stored_scope_ids(row)
            if not scope:
                return _Problem(
                    "deployment_blocked",
                    "its instrument scope is unreadable or empty; save it again with its instruments",
                )
            if instrument.id not in scope:
                return _Problem(
                    "backtest_scope_rejected",
                    f"{key} is not in its instrument scope; choose one of its instruments or change its "
                    "scope",
                )
        if isinstance(current, _Problem):
            return current
        problem = setup_problem(
            current.entry, instrument, current.interval, workspace.market_region, current.rules
        )
        if problem is not None:
            return _Problem("backtest_not_possible", problem)
        broken = [
            f"{item.rule.key}: {item.error or 'invalid parameters'}"
            for item in current.policy.rules
            if item.rule.key in HISTORY_RULES and item.enabled and item.params is None
        ]
        if broken:
            return _Problem(
                "backtest_risk_invalid",
                f"risk rules that apply to history have invalid parameters ({'; '.join(broken)}); fix them "
                "with qt risk set or qt risk reset",
            )
        return current

    async def _digests(
        self, session: AsyncSession, pairs: Collection[tuple[UUID, UUID]]
    ) -> dict[tuple[UUID, UUID], str]:
        """The current settings hash of each (configuration, instrument) pair that has one."""
        if not pairs:
            return {}
        loaded = await _load_many(session, {deployment_id for deployment_id, _ in pairs})
        i = InstrumentRow
        rows = await session.scalars(select(i).where(i.id.in_([instrument_id for _, instrument_id in pairs])))
        instruments = {row.id: _instrument(row) for row in rows}
        policies: dict[UUID, RiskPolicy] = {}
        digests: dict[tuple[UUID, UUID], str] = {}
        for deployment_id, instrument_id in pairs:
            found, instrument = loaded.get(deployment_id), instruments.get(instrument_id)
            if found is None or instrument is None:
                continue
            current = await self._current(session, found, instrument, policies)
            if isinstance(current, _Settings):
                digests[deployment_id, instrument_id] = current.digest
        return digests


async def _load_many(session: AsyncSession, deployment_ids: Collection[UUID]) -> dict[UUID, _Loaded]:
    d, w, c = StrategyDeploymentRow, WorkspaceRow, StrategyConfigurationRow
    rows = await session.execute(
        select(d, w, c)
        .join(w, w.id == d.workspace_id)
        .join(c, c.id == d.configuration_id)
        .where(d.id.in_(list(deployment_ids)))
    )
    return {row.id: _Loaded(row, workspace, configuration) for row, workspace, configuration in rows}


async def _load(session: AsyncSession, deployment_id: UUID) -> _Loaded:
    found = (await _load_many(session, (deployment_id,))).get(deployment_id)
    if found is None:
        raise _not_found(deployment_id)
    return found


async def _fetch(
    session: AsyncSession,
    *criteria: ColumnElement[bool],
    with_curve: bool = False,
    limit: int | None = None,
    offset: int = 0,
) -> list[tuple[BacktestRunRow, _RunContext]]:
    """Runs with the names their views show, newest first. Their trades are never loaded, and their equity
    curve only when asked for."""
    r, d, w, i, ds = BacktestRunRow, StrategyDeploymentRow, WorkspaceRow, InstrumentRow, BacktestDatasetRow
    options = [defer(r.trades, raiseload=True)]
    if not with_curve:
        options.append(defer(r.equity_curve, raiseload=True))
    stmt = (
        select(
            r, d.label, w.slug, i.canonical_key, i.symbol, ds.provider, ds.source, ds.date_from, ds.date_to
        )
        .join(d, d.id == r.deployment_id)
        .join(w, w.id == d.workspace_id)
        .join(i, i.id == r.instrument_id)
        .join(ds, ds.id == r.dataset_id)
        .options(*options)
        .where(*criteria)
        .order_by(r.created_at.desc(), r.id)
    )
    if offset:
        stmt = stmt.offset(offset)
    if limit is not None:
        stmt = stmt.limit(limit)
    rows = await session.execute(stmt)
    return [
        (row, _RunContext(label, slug, key, symbol, provider, source, date_from, date_to))
        for row, label, slug, key, symbol, provider, source, date_from, date_to in rows
    ]


def _rules_view(
    deployment_id: UUID, stored: dict[str, Any] | None, entry: RegisteredStrategy | None
) -> TradeRulesView:
    declared = None if entry is None else entry.trade_rules
    effective: TradeRules | None = None
    source: TradeRulesSource | None = None
    problem: str | None = None
    if stored is not None:
        try:
            effective, source = TradeRules.model_validate(stored), TradeRulesSource.CONFIGURATION
        except ValidationError as exc:
            problem = (
                f"the saved trade rules no longer validate ({describe_validation(exc)}); set them again or "
                "clear them"
            )
    elif declared is not None:
        effective, source = declared, TradeRulesSource.STRATEGY
    else:
        problem = (
            "no trade rules are set: set them for this configuration, or declare trade_rules in the strategy"
        )
    return TradeRulesView(
        deployment_id=deployment_id,
        effective=effective,
        source=source,
        configuration=stored,
        strategy=declared,
        problem=problem,
    )


def _dataset_problem(dataset: BacktestDatasetRow, current: _Settings) -> _Problem | None:
    """Why the configuration cannot replay this dataset, judged from the dataset's coverage."""
    strategy_id = current.entry.strategy_id
    if dataset.interval is not current.interval:
        return _Problem(
            "backtest_dataset_mismatch",
            f"{strategy_id} uses {current.interval.value} candles, and the dataset has "
            f"{dataset.interval.value} candles",
        )
    without_volume = dataset.coverage.get("without_volume")
    if (
        DataRequirement.VOLUME in current.entry.data_requirements
        and isinstance(without_volume, int)
        and without_volume >= dataset.candle_count
    ):
        return _Problem(
            "backtest_not_possible", f"{strategy_id} needs volume, and none of the dataset's candles has it"
        )
    return None


def _refusal(where: str, problem: _Problem) -> AppError:
    message = f"{where}: {problem.text}"
    if problem.code in _CONFLICTS:
        return ConflictError(message, code=problem.code)
    return ValidationFailedError(message, code=problem.code)


def _run_view(row: BacktestRunRow, context: _RunContext, outdated: bool | None) -> BacktestRunView:
    summary: BacktestSummary | None = None
    error = row.error
    if row.summary is not None:
        try:
            summary = BacktestSummary.model_validate(row.summary)
        except ValidationError:
            error = error or UNREADABLE
    return BacktestRunView(
        id=row.id,
        deployment_id=row.deployment_id,
        label=context.label,
        workspace_slug=context.workspace_slug,
        instrument_id=row.instrument_id,
        instrument_key=context.instrument_key,
        symbol=context.symbol,
        dataset_id=row.dataset_id,
        dataset_sha=row.dataset_sha,
        provider=context.provider,
        source=context.source,
        simulated=context.source is DatasetSource.SIMULATED,
        date_from=context.date_from,
        date_to=context.date_to,
        strategy_id=row.strategy_id,
        strategy_version=row.strategy_version,
        code_fingerprint=row.code_fingerprint,
        configuration_id=row.configuration_id,
        config_hash=row.config_hash,
        interval=row.interval,
        settings=row.settings,
        settings_hash=row.settings_hash,
        status=row.status,
        requested_by=row.requested_by,
        worker_id=row.worker_id,
        started_at=row.started_at,
        finished_at=row.finished_at,
        error=error,
        summary=summary,
        trade_count=row.trade_count,
        outdated=outdated,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def _outdated(row: BacktestRunRow, digest: str | None) -> bool | None:
    return None if digest is None else row.settings_hash != digest


def _dump(result: BacktestResult) -> tuple[dict[str, Any], list[Any], list[Any]]:
    """The results as the JSON values stored."""
    return (
        result.summary.model_dump(mode="json"),
        [point.model_dump(mode="json") for point in result.equity_curve],
        [trade.model_dump(mode="json") for trade in result.trades],
    )


def _instrument(row: InstrumentRow) -> Instrument:
    return Instrument.model_validate(row, from_attributes=True)


def _not_found(deployment_id: UUID) -> NotFoundError:
    return NotFoundError(f"Saved configuration {deployment_id} was not found", code="deployment_not_found")


def _run_not_found(run_id: UUID) -> NotFoundError:
    return NotFoundError(f"Backtest {run_id} was not found", code="backtest_not_found")
