"""Latest quotes, with their data status recomputed when read.

A stored quote keeps the status it was written with. Readers combine that with the current state of
the account's feed and with the quote's age, and show the worst of the three: a quote is never LIVE
once its feed has stopped, or once it has not been updated for ``DATA_STALE_AFTER_SECONDS``. An
instrument that simply has not traded for that long shows STALE as well, because a quiet instrument
cannot be told apart from a feed that has gone silent for it.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Self
from uuid import UUID

from pydantic import ValidationError
from sqlalchemy import select

from app.container import Container
from app.core.clock import utc_now
from app.core.config import Settings
from app.core.errors import ValidationFailedError
from app.core.logging import get_logger
from app.domain.enums import DataStatus, Provider, worst_status
from app.domain.models import QuoteSnapshot, StreamHealth
from app.domain.models.base import DomainModel, UtcDatetime
from app.persistence.database import Database
from app.persistence.models import WorkspaceInstrumentRow, WorkspaceRow
from app.services.workspaces import find_workspace
from app.streaming.redis_bus import Keys, RedisBus

log = get_logger(__name__)

MAX_QUOTE_INSTRUMENTS = 500


def effective_status(
    stored: DataStatus, feed: DataStatus, age_seconds: float, *, stale_after_seconds: float
) -> DataStatus:
    """The worst of the status written with the data, its feed's status, and STALE once it is old."""
    aged = DataStatus.STALE if age_seconds > stale_after_seconds else DataStatus.LIVE
    return worst_status(stored, feed, aged)


async def read_feed_streams(bus: RedisBus) -> list[StreamHealth]:
    """The feed streams workers report now. A stream's key expires soon after its worker stops."""
    raw = await bus.scan_json(Keys.FEED_STATE_PATTERN)
    streams: list[StreamHealth] = []
    for value in raw.values():
        try:
            streams.append(StreamHealth.model_validate(value))
        except ValidationError:
            continue
    return sorted(streams, key=lambda s: (s.provider.value, s.stream_id))


class FeedStatuses:
    """Each account's feed status: the worst of its streams, or DISCONNECTED when it has none."""

    def __init__(self, streams: Iterable[StreamHealth]) -> None:
        grouped: dict[tuple[Provider, UUID | None], list[DataStatus]] = {}
        for stream in streams:
            grouped.setdefault((stream.provider, stream.account_id), []).append(stream.data_status)
        self._status = {key: worst_status(*values) for key, values in grouped.items()}

    def status(self, provider: Provider, account_id: UUID | None) -> DataStatus:
        return self._status.get((provider, account_id), DataStatus.DISCONNECTED)

    def provider_status(self, provider: Provider) -> DataStatus:
        statuses = [status for (owner, _), status in self._status.items() if owner is provider]
        return worst_status(*statuses) if statuses else DataStatus.DISCONNECTED


class QuoteView(QuoteSnapshot):
    """A stored quote whose ``data_status`` is recomputed when read; ``stored_status`` is as written."""

    stored_status: DataStatus
    feed_status: DataStatus
    age_seconds: float

    @classmethod
    def build(
        cls, quote: QuoteSnapshot, feeds: FeedStatuses, now: datetime, *, stale_after_seconds: float
    ) -> Self:
        status, feed, age = quote_status(quote, feeds, now, stale_after_seconds=stale_after_seconds)
        return cls.model_validate(
            dict(quote)
            | {
                "data_status": status,
                "stored_status": quote.data_status,
                "feed_status": feed,
                "age_seconds": round(age, 3),
            }
        )


def quote_status(
    quote: QuoteSnapshot, feeds: FeedStatuses, now: datetime, *, stale_after_seconds: float
) -> tuple[DataStatus, DataStatus, float]:
    """A stored quote's data status as of ``now``, its feed's status, and its age in seconds."""
    feed = feeds.status(quote.provider, quote.account_id)
    age = max(0.0, (now - quote.received_at).total_seconds())
    return effective_status(quote.data_status, feed, age, stale_after_seconds=stale_after_seconds), feed, age


class QuoteList(DomainModel):
    items: tuple[QuoteView, ...]
    missing: tuple[UUID, ...]  # instruments asked for that have no quote from any provider asked
    generated_at: UtcDatetime


@dataclass(frozen=True, slots=True)
class QuoteSelection:
    """The (provider, instrument) quotes to read, and the instruments they were asked for by."""

    pairs: tuple[tuple[Provider, UUID], ...]
    instrument_ids: tuple[UUID, ...]
    workspace_id: UUID | None = None
    workspace_slug: str | None = None


class QuoteService:
    def __init__(
        self, db: Database, bus: RedisBus, settings: Settings, *, clock: Callable[[], datetime] = utc_now
    ) -> None:
        self._db = db
        self._bus = bus
        self._stale_after = settings.data_stale_after_seconds
        self._clock = clock

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(container.db, container.bus, container.settings, clock=clock)

    async def latest(
        self,
        *,
        workspace: str | None = None,
        instrument_ids: Sequence[UUID] = (),
        provider: Provider | None = None,
    ) -> QuoteList:
        """The latest quotes for a workspace's universe (optionally only ``instrument_ids``), or for
        ``instrument_ids`` from every provider (or only ``provider``)."""
        return await self.read(
            await self.select(workspace=workspace, instrument_ids=instrument_ids, provider=provider)
        )

    async def select(
        self,
        *,
        workspace: str | None = None,
        instrument_ids: Sequence[UUID] = (),
        provider: Provider | None = None,
    ) -> QuoteSelection:
        """The quotes ``latest`` reads for the same arguments."""
        wanted = list(dict.fromkeys(instrument_ids))
        if workspace is None and not wanted:
            raise ValidationFailedError(
                "Name a workspace or at least one instrument", code="quote_selection_required"
            )
        if len(wanted) > MAX_QUOTE_INSTRUMENTS:
            raise ValidationFailedError(
                f"At most {MAX_QUOTE_INSTRUMENTS} instruments can be asked for at once",
                code="too_many_instruments",
            )
        workspace_row: WorkspaceRow | None = None
        if workspace is not None:
            workspace_row, pairs = await self._universe(workspace)
            if wanted:
                keep = set(wanted)
                pairs = [pair for pair in pairs if pair[1] in keep]
        else:
            pairs = [(each, instrument_id) for instrument_id in wanted for each in Provider]
        if provider is not None:
            pairs = [pair for pair in pairs if pair[0] is provider]
        requested = wanted or list(dict.fromkeys(instrument_id for _, instrument_id in pairs))
        return QuoteSelection(
            pairs=tuple(pairs),
            instrument_ids=tuple(requested),
            workspace_id=workspace_row.id if workspace_row else None,
            workspace_slug=workspace_row.slug if workspace_row else None,
        )

    async def read(self, selection: QuoteSelection) -> QuoteList:
        quotes = await self.snapshots(selection.pairs)
        feeds = FeedStatuses(await read_feed_streams(self._bus))
        now = self._clock()
        found = {quote.instrument_id for quote in quotes}
        return QuoteList(
            items=tuple(
                QuoteView.build(quote, feeds, now, stale_after_seconds=self._stale_after) for quote in quotes
            ),
            missing=tuple(i for i in selection.instrument_ids if i not in found),
            generated_at=now,
        )

    async def snapshots(self, pairs: Sequence[tuple[Provider, UUID]]) -> list[QuoteSnapshot]:
        """The stored quotes of the (provider, instrument) pairs that have one, in the order given."""
        if not pairs:
            return []
        values = await self._bus.mget_json([Keys.quote(provider, iid) for provider, iid in pairs])
        quotes: list[QuoteSnapshot] = []
        for value in values:
            if value is None:
                continue
            try:
                quotes.append(QuoteSnapshot.model_validate(value))
            except ValidationError:
                log.warning("quote_snapshot_invalid")
        return quotes

    async def _universe(self, workspace: str) -> tuple[WorkspaceRow, list[tuple[Provider, UUID]]]:
        wi = WorkspaceInstrumentRow
        async with self._db.session() as session:
            row = await find_workspace(session, workspace)
            result = await session.execute(
                select(wi.provider, wi.instrument_id)
                .where(wi.workspace_id == row.id)
                .order_by(wi.added_at, wi.instrument_id)
            )
            return row, [(provider, instrument_id) for provider, instrument_id in result]
