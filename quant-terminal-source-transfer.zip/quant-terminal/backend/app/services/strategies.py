"""Strategy catalogue and saved configurations.

The code registry (``app.strategies.registry``) decides which strategies exist. The database catalogue
mirrors it so configurations, runs and signals can name the strategy, version and code they used;
``sync_catalogue`` brings it up to date when the strategy worker starts, on ``qt strategies sync`` or
``POST /strategies/sync``, and before saving a configuration whose code the catalogue does not have yet. A
strategy that leaves the code stays in the catalogue, marked unavailable, so its history stays readable.

A saved configuration (a deployment) puts one strategy into one workspace with a label, an immutable
settings snapshot and an explicit instrument scope: chosen instruments, or the whole workspace universe.
A strategy can have several configurations in a workspace; labels are unique among the workspace's
active configurations. A configuration starts with live signals off. Turning them on (enabling it) is a
separate, audited step; asking twice changes nothing, and it is refused while another enabled
configuration runs the same strategy version with the same settings on an overlapping scope. An enabled
configuration runs only while its workspace is enabled and the code has the strategy at the saved
version: ``blocked_reason`` says why it does not, and ``monitoring`` sums up how it is doing. Saving a
configuration again moves it to the code's version and keeps the settings that still exist. A stopped
configuration can be archived; its runs and signals stay. ``runnable_deployments`` tells the strategy
worker what to run, and ``compatibility`` shows how each strategy suits an instrument as its workspace
streams it. Nothing here places orders: strategies only propose signals.
"""

from __future__ import annotations

from collections.abc import Callable, Collection, Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from types import MappingProxyType
from typing import Any, Final, Self
from uuid import UUID

from redis.exceptions import RedisError
from sqlalchemy import and_, func, or_, select
from sqlalchemy.dialects.postgresql import distinct_on
from sqlalchemy.ext.asyncio import AsyncSession

from app.container import Container
from app.core.clock import utc_now
from app.core.config import DEFAULT_CANDLE_INTERVALS
from app.core.errors import ConflictError, NotFoundError, ValidationFailedError
from app.core.hashing import json_sha256
from app.core.logging import get_logger
from app.domain.enums import (
    CandleInterval,
    DataRequirement,
    MarketRegion,
    MonitoringState,
    Provider,
    ScopeKind,
    StrategyRunStatus,
    SubscriptionMode,
)
from app.domain.events import CommandType, WorkerCommand
from app.domain.models.base import DomainModel, UtcDatetime
from app.domain.models.instrument import Instrument
from app.domain.models.strategy import StrategyMetadata
from app.market_data.candles.store import count_recent
from app.observability.heartbeat import STRATEGY_WORKER
from app.persistence.database import Database
from app.persistence.models import (
    InstrumentRow,
    StrategyConfigurationRow,
    StrategyDeploymentRow,
    StrategyRow,
    StrategyRunRow,
    StrategyVersionRow,
    WorkspaceInstrumentRow,
    WorkspaceRow,
)
from app.persistence.models.common import stamp_updated
from app.providers.delivery import FeedDelivery
from app.risk.engine import RiskPolicy
from app.services.audit import SYSTEM_ACTOR, add_audit
from app.services.kill_switch import load_kill_switch
from app.services.provider_accounts import publish_command
from app.services.risk import load_policy
from app.services.strategy_compatibility import (
    CompatibilityInputs,
    InstrumentCompatibility,
    check_compatibility,
    instrument_problem,
)
from app.services.strategy_monitoring import Monitoring, MonitoringInputs, derive_monitoring, signal_blocks
from app.services.workspaces import find_workspace
from app.strategies.registry import (
    RegisteredStrategy,
    StrategyConfigError,
    StrategyRegistry,
    builtin_registry,
    data_needs,
)
from app.streaming.redis_bus import Keys, RedisBus

log = get_logger(__name__)

ENTITY: Final = "strategy_deployment"
CATALOGUE_ENTITY: Final = "strategy_catalogue"
MAX_SCOPE: Final = 1000
MAX_LABEL: Final = 80
MAX_RUNS: Final = 500
_SHOWN_PROBLEMS: Final = 10

type Universe = dict[UUID, tuple[InstrumentRow, Provider, SubscriptionMode]]


def config_hash(config: Mapping[str, Any]) -> str:
    """SHA-256 of the configuration's canonical JSON; equal configurations share one snapshot."""
    return json_sha256(config)


class CatalogueSync(DomainModel):
    """What ``sync_catalogue`` changed."""

    added: tuple[str, ...] = ()  # strategies new to the catalogue
    restored: tuple[str, ...] = ()  # unavailable strategies that are back in the code
    upgraded: tuple[str, ...] = ()  # "id@version": versions the catalogue did not have
    code_changed: tuple[str, ...] = ()  # "id@version": code edited without a version bump
    unavailable: tuple[str, ...] = ()  # strategies no longer in the code

    @property
    def changed(self) -> bool:
        return bool(self.added or self.restored or self.upgraded or self.code_changed or self.unavailable)


class StrategyView(DomainModel):
    strategy_id: str
    name: str
    description: str
    author: str
    version: str
    is_example: bool
    is_available: bool
    can_emit_actionable: bool
    code_fingerprint: str
    metadata: dict[str, Any]
    data_requirements: tuple[DataRequirement, ...]  # beyond prices; derived from the metadata
    config_schema: dict[str, Any]
    default_config: dict[str, Any]
    deployments: int
    enabled_deployments: int


class RunView(DomainModel):
    id: UUID
    deployment_id: UUID
    deployment_label: str
    workspace_slug: str
    strategy_id: str
    strategy_version: str
    configuration_id: UUID
    config_hash: str
    code_fingerprint: str | None
    status: StrategyRunStatus
    worker_id: str
    started_at: UtcDatetime
    stopped_at: UtcDatetime | None
    heartbeat_at: UtcDatetime | None
    instruments: int  # the instruments it covers
    excluded: int  # instruments of its scope it left out
    instruments_warming: int  # of those it covers, the ones still short of their warm-up candles
    warmup_remaining: dict[str, int]  # per candle interval, the most candles any of them still needs
    events_processed: int
    candles_processed: int
    signals_emitted: int
    failures: int
    timeouts: int
    last_error: str | None
    circuit_opened_at: UtcDatetime | None


class DeploymentView(DomainModel):
    """A saved strategy configuration."""

    id: UUID
    workspace_id: UUID
    workspace_slug: str
    market_region: MarketRegion
    strategy_id: str
    strategy_version: str
    code_fingerprint: str | None  # the code's, while the code has this version
    label: str
    configuration_id: UUID
    config: dict[str, Any]
    config_hash: str
    scope_kind: ScopeKind
    instrument_ids: tuple[UUID, ...]  # an INSTRUMENTS scope's instruments; empty for a WORKSPACE scope
    is_enabled: bool  # live signals are on
    enabled_by: str | None
    enabled_at: UtcDatetime | None
    disabled_at: UtcDatetime | None
    archived_at: UtcDatetime | None
    created_at: UtcDatetime
    updated_at: UtcDatetime
    blocked_reason: str | None  # why it does not run, even when enabled
    last_run: RunView | None = None
    monitoring: Monitoring | None = None  # filled in for people; the strategy worker does not need it

    @property
    def is_runnable(self) -> bool:
        return self.is_enabled and self.blocked_reason is None


@dataclass(frozen=True, slots=True)
class Scope:
    """What a saved configuration watches: chosen instruments, or the whole workspace universe. There is
    no default; callers choose."""

    kind: ScopeKind
    instrument_ids: tuple[UUID, ...] = ()

    @classmethod
    def instruments(cls, instrument_ids: Iterable[UUID]) -> Self:
        return cls(ScopeKind.INSTRUMENTS, tuple(dict.fromkeys(instrument_ids)))

    @classmethod
    def workspace(cls) -> Self:
        return cls(ScopeKind.WORKSPACE)


@dataclass(frozen=True, slots=True)
class RunnableDeployment:
    """A deployment the strategy worker should run, with the instruments it covers and their sources."""

    deployment: DeploymentView
    instruments: tuple[tuple[Instrument, Provider], ...]
    excluded: Mapping[str, str]  # instrument (canonical key, or id once it is gone) -> why it is left out


class StrategyService:
    def __init__(
        self,
        db: Database,
        bus: RedisBus,
        *,
        registry: StrategyRegistry | None = None,
        clock: Callable[[], datetime] = utc_now,
        live_signals_enabled: bool = False,
        feeds: FeedDelivery | None = None,
        candle_intervals: Collection[CandleInterval] = DEFAULT_CANDLE_INTERVALS,
    ) -> None:
        self.db = db
        self.bus = bus
        self.registry = builtin_registry() if registry is None else registry
        self.clock = clock
        self.live_signals_enabled = live_signals_enabled
        self.feeds = FeedDelivery() if feeds is None else feeds
        self.candle_intervals = frozenset(candle_intervals)  # what CANDLE_INTERVALS builds

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        settings = container.settings
        return cls(
            container.db,
            container.bus,
            clock=clock,
            live_signals_enabled=settings.live_signals_enabled,
            feeds=FeedDelivery(groww_volume_is_cumulative=settings.groww_feed_volume_is_cumulative),
            candle_intervals=settings.candle_intervals,
        )

    # ---- catalogue ------------------------------------------------------------------------------

    async def sync_catalogue(self, *, actor: str = SYSTEM_ACTOR) -> CatalogueSync:
        """Mirror the code registry into the database catalogue. Safe to run concurrently."""
        now = self.clock()
        added: list[str] = []
        restored: list[str] = []
        upgraded: list[str] = []
        code_changed: list[str] = []
        unavailable: list[str] = []
        async with self.db.transaction() as session:
            await session.execute(select(func.pg_advisory_xact_lock(func.hashtext(CATALOGUE_ENTITY))))
            rows = {row.id: row for row in await session.scalars(select(StrategyRow))}
            versions = {
                (row.strategy_id, row.version): row
                for row in await session.scalars(select(StrategyVersionRow))
            }
            for entry in self.registry:
                row = rows.get(entry.strategy_id)
                if row is None:
                    session.add(_strategy_row(entry))
                    added.append(entry.strategy_id)
                    continue
                if not row.is_available:
                    restored.append(entry.strategy_id)
                if _describe(row, entry):
                    stamp_updated(row, now)
            await session.flush()  # versions reference the strategies

            for entry in self.registry:
                label = f"{entry.strategy_id}@{entry.version}"
                version = versions.get((entry.strategy_id, entry.version))
                if version is None:
                    version = StrategyVersionRow(
                        strategy_id=entry.strategy_id, version=entry.version, registered_at=now
                    )
                    _store_version(version, entry)
                    session.add(version)
                    if entry.strategy_id not in added:
                        upgraded.append(label)
                elif not _version_matches(version, entry):
                    log.warning(
                        "strategy_code_changed_without_version_bump",
                        strategy_id=entry.strategy_id,
                        version=entry.version,
                        previous_fingerprint=version.code_fingerprint,
                        fingerprint=entry.fingerprint,
                    )
                    _store_version(version, entry)
                    code_changed.append(label)

            for strategy_id, row in rows.items():
                if strategy_id not in self.registry and row.is_available:
                    row.is_available = False
                    stamp_updated(row, now)
                    unavailable.append(strategy_id)

            result = CatalogueSync(
                added=tuple(added),
                restored=tuple(restored),
                upgraded=tuple(upgraded),
                code_changed=tuple(code_changed),
                unavailable=tuple(unavailable),
            )
            if result.changed:
                add_audit(
                    session,
                    actor=actor,
                    action="strategy.catalogue_sync",
                    entity_type=CATALOGUE_ENTITY,
                    details=result.model_dump(mode="json"),
                )
        if result.changed:
            log.info("strategy_catalogue_synced", **result.model_dump(mode="json"))
        return result

    async def list_strategies(self) -> list[StrategyView]:
        async with self.db.session() as session:
            return await _strategies(session)

    async def get_strategy(self, strategy_id: str) -> StrategyView:
        async with self.db.session() as session:
            found = await _strategies(session, strategy_id)
        if not found:
            raise NotFoundError(f"Strategy '{strategy_id}' was not found", code="strategy_not_found")
        return found[0]

    async def compatibility(
        self,
        workspace: UUID | str,
        instrument_id: UUID,
        *,
        chart_interval: CandleInterval | None = None,
    ) -> InstrumentCompatibility:
        """How each strategy in the code suits one instrument of a workspace, as the workspace streams it
        (see ``app.services.strategy_compatibility``); ``chart_interval`` is the one the chart shows."""
        needed: dict[CandleInterval, int] = {}
        for entry in self.registry:
            for interval, count in entry.warmups.items():
                needed[interval] = max(needed.get(interval, 0), count)
        wi, i = WorkspaceInstrumentRow, InstrumentRow
        async with self.db.session() as session:
            workspace_row = await find_workspace(session, workspace)
            listed = (
                await session.execute(
                    select(i, wi.provider, wi.subscription_mode)
                    .join(wi, wi.instrument_id == i.id)
                    .where(wi.workspace_id == workspace_row.id, i.id == instrument_id)
                )
            ).first()
            if listed is None:
                raise NotFoundError(
                    f"Instrument {instrument_id} is not in workspace '{workspace_row.slug}'",
                    code="instrument_not_in_workspace",
                )
            instrument, provider, mode = listed
            until = self.clock()
            stored: dict[CandleInterval, int] = {}
            for interval, limit in needed.items():
                stored[interval] = await count_recent(
                    session, provider, instrument.id, interval, until=until, limit=limit
                )
            inputs = CompatibilityInputs(
                market=workspace_row.market_region,
                instrument=instrument,
                provider=provider,
                mode=mode,
                built=self.candle_intervals,
                stored=stored,
                feeds=self.feeds,
                chart_interval=chart_interval,
            )
            return InstrumentCompatibility(
                workspace_slug=workspace_row.slug,
                market_region=workspace_row.market_region,
                instrument_id=instrument.id,
                canonical_key=instrument.canonical_key,
                provider=provider,
                subscription_mode=mode,
                chart_interval=chart_interval,
                built_intervals=tuple(sorted(self.candle_intervals, key=lambda interval: interval.seconds)),
                strategies=tuple(
                    check_compatibility(entry, inputs)
                    for entry in sorted(self.registry, key=lambda entry: entry.strategy_id)
                ),
            )

    # ---- saved configurations -------------------------------------------------------------------

    async def list_deployments(
        self,
        workspace: UUID | str | None = None,
        *,
        strategy_id: str | None = None,
        instrument_id: UUID | None = None,
        include_archived: bool = False,
    ) -> list[DeploymentView]:
        """Saved configurations with their monitoring state. With ``instrument_id``, those whose scope
        covers the instrument: an instrument scope that lists it, or a whole-workspace scope of a
        workspace that has it."""
        async with self.db.session() as session:
            workspace_id = None if workspace is None else (await find_workspace(session, workspace)).id
            return await self._deployments(
                session,
                workspace_id=workspace_id,
                strategy_id=strategy_id,
                instrument_id=instrument_id,
                include_archived=include_archived,
                monitor=True,
            )

    async def get_deployment(self, deployment_id: UUID) -> DeploymentView:
        """A saved configuration, archived or not, with its monitoring state."""
        async with self.db.session() as session:
            found = await self._deployments(session, deployment_id=deployment_id, monitor=True)
        if not found:
            raise _not_found(deployment_id)
        return found[0]

    async def resolve_deployment(self, workspace: UUID | str, ref: str) -> UUID:
        """The ID of one of a workspace's saved configurations, given its ID or its label (in any case).
        Labels only name configurations that are not archived."""
        d = StrategyDeploymentRow
        async with self.db.session() as session:
            workspace_row = await find_workspace(session, workspace)
            try:
                wanted: UUID | None = UUID(ref.strip())
            except ValueError:
                wanted = None
            if wanted is not None:
                found = await session.scalar(
                    select(d.id).where(d.id == wanted, d.workspace_id == workspace_row.id)
                )
                if found is not None:
                    return found
            rows = await session.execute(
                select(d.label, d.id)
                .where(d.workspace_id == workspace_row.id, d.archived_at.is_(None))
                .order_by(d.label)
            )
            labels: dict[str, UUID] = dict(rows.all())
        for label, deployment_id in labels.items():
            if label.casefold() == ref.strip().casefold():
                return deployment_id
        raise NotFoundError(
            f"Workspace '{workspace_row.slug}' has no saved configuration '{ref}' "
            f"(its configurations: {', '.join(labels) or 'none'})",
            code="deployment_not_found",
        )

    async def create_configuration(
        self,
        workspace: UUID | str,
        strategy_id: str,
        *,
        scope: Scope,
        label: str | None = None,
        config: Mapping[str, Any] | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> DeploymentView:
        """Save a new configuration of a strategy in a workspace. Its live signals stay off until it is
        enabled.

        ``config`` holds the values that differ from the strategy's defaults. ``label`` names it; without
        one it is named after the strategy, numbered when the workspace already uses that label.
        """
        entry = self._entry(strategy_id)
        scope = _checked_scope(scope)
        wanted = None if label is None else _clean_label(label)
        await self._ensure_catalogued(entry, actor)
        async with self.db.transaction() as session:
            workspace_row = await find_workspace(session, workspace, lock=True)
            _check_market(entry, workspace_row)
            values = {**entry.default_config, **(config or {})}
            configuration = await _snapshot(session, entry, _validated(entry, values), actor)
            ids = await _validated_scope(session, workspace_row, entry, scope, self.feeds, kept=False)
            taken = await _active_labels(session, workspace_row.id)
            row = StrategyDeploymentRow(
                workspace_id=workspace_row.id,
                strategy_id=entry.strategy_id,
                label=_free_label(entry.strategy_id, taken)
                if wanted is None
                else _unique_label(wanted, taken, workspace_row),
                strategy_version=entry.version,
                configuration_id=configuration.id,
                scope_kind=scope.kind,
                scope=_scope_json(ids),
                is_enabled=False,
            )
            session.add(row)
            await session.flush()
            add_audit(
                session,
                actor=actor,
                action="strategy.deploy",
                entity_type=ENTITY,
                entity_id=row.id,
                details={
                    "workspace": workspace_row.slug,
                    "strategy_id": entry.strategy_id,
                    "label": row.label,
                    "created": True,
                    "version": entry.version,
                    "configuration_id": str(configuration.id),
                    "config_hash": configuration.config_hash,
                    "scope": scope.kind.value,
                    "instruments": len(ids),
                },
                client_ip=client_ip,
            )
            deployment_id = row.id
        return await self.get_deployment(deployment_id)

    async def update_configuration(
        self,
        deployment_id: UUID,
        *,
        label: str | None = None,
        scope: Scope | None = None,
        config: Mapping[str, Any] | None = None,
        reset_config: bool = False,
        actor: str,
        client_ip: str | None = None,
    ) -> DeploymentView:
        """Save a configuration again.

        It moves to the code's version of its strategy. ``config`` holds the values to set; the others
        keep their saved values (the defaults with ``reset_config``). ``label`` renames it and ``scope``
        replaces its scope (None keeps it). When its live signals are on and what runs changes, the
        strategy worker is told to reload.
        """
        new_scope = None if scope is None else _checked_scope(scope)
        wanted = None if label is None else _clean_label(label)
        d = StrategyDeploymentRow
        async with self.db.session() as session:
            strategy_id = await session.scalar(select(d.strategy_id).where(d.id == deployment_id))
        if strategy_id is None:
            raise _not_found(deployment_id)
        entry = self._entry(strategy_id)
        await self._ensure_catalogued(entry, actor)
        now = self.clock()
        async with self.db.transaction() as session:
            row, workspace_row = await _locked(session, deployment_id, lock_workspace=True)
            if row.archived_at is not None:
                raise ConflictError(
                    f"Configuration '{row.label}' is archived; save a new configuration instead",
                    code="deployment_archived",
                )
            _check_market(entry, workspace_row)
            previous = await session.get(StrategyConfigurationRow, row.configuration_id)
            values = dict(entry.default_config)
            if previous is not None and not reset_config:
                values.update((key, value) for key, value in previous.config.items() if key in values)
            values.update(config or {})
            configuration = await _snapshot(session, entry, _validated(entry, values), actor)
            target = _kept_scope(row) if new_scope is None else new_scope
            ids = await _validated_scope(
                session, workspace_row, entry, target, self.feeds, kept=new_scope is None
            )
            new_label = row.label
            if wanted is not None and wanted != row.label:
                taken = await _active_labels(session, workspace_row.id, excluding=row.id)
                new_label = _unique_label(wanted, taken, workspace_row)
            runs_changed = (
                row.strategy_version,
                row.configuration_id,
                row.scope_kind,
                stored_scope_ids(row),
            ) != (
                entry.version,
                configuration.id,
                target.kind,
                ids,
            )
            if runs_changed and row.is_enabled:
                await _refuse_duplicate(
                    session,
                    row,
                    workspace_row,
                    version=entry.version,
                    config_hash=configuration.config_hash,
                    scope=Scope(target.kind, ids),
                )
            if runs_changed or new_label != row.label:
                add_audit(
                    session,
                    actor=actor,
                    action="strategy.deploy",
                    entity_type=ENTITY,
                    entity_id=row.id,
                    details={
                        "workspace": workspace_row.slug,
                        "strategy_id": entry.strategy_id,
                        "label": new_label,
                        "previous_label": row.label,
                        "created": False,
                        "version": entry.version,
                        "previous_version": row.strategy_version,
                        "configuration_id": str(configuration.id),
                        "config_hash": configuration.config_hash,
                        "previous_configuration_id": str(row.configuration_id),
                        "scope": target.kind.value,
                        "instruments": len(ids),
                    },
                    client_ip=client_ip,
                )
                row.label = new_label
                row.strategy_version = entry.version
                row.configuration_id = configuration.id
                row.scope_kind = target.kind
                row.scope = _scope_json(ids)
                stamp_updated(row, now)
            reload = runs_changed and row.is_enabled
        if reload:
            await self._reload(deployment_id, actor)
        return await self.get_deployment(deployment_id)

    async def set_enabled(
        self, deployment_id: UUID, enabled: bool, *, actor: str, client_ip: str | None = None
    ) -> DeploymentView:
        """Turn live signals on or off for a saved configuration; asking for its current state changes
        nothing. Turning them off always works, even once the code is gone. Turning them on is refused
        while it cannot run (it is archived, or its code or scope is unusable) and while another enabled
        configuration runs the same strategy version with the same settings on an overlapping scope.
        Monitoring then runs in the strategy worker until they are turned off, whether or not a chart
        is open."""
        now = self.clock()
        async with self.db.transaction() as session:
            row, workspace_row = await _locked(session, deployment_id, lock_workspace=enabled)
            changed = row.is_enabled != enabled
            if changed and enabled:
                where = f"'{row.label}' in workspace '{workspace_row.slug}'"
                if row.archived_at is not None:
                    raise ConflictError(
                        f"Cannot turn on live signals for {where}: it is archived", code="deployment_archived"
                    )
                problem = self._code_problem(row)
                if problem is not None:
                    raise ConflictError(
                        f"Cannot turn on live signals for {where}: {problem}", code="deployment_blocked"
                    )
                c = StrategyConfigurationRow
                digest = await session.scalar(select(c.config_hash).where(c.id == row.configuration_id))
                await _refuse_duplicate(
                    session,
                    row,
                    workspace_row,
                    version=row.strategy_version,
                    config_hash=digest or "",
                    scope=_kept_scope(row),
                )
                row.enabled_by = actor[:64]
                row.enabled_at = now
            elif changed:
                row.disabled_at = now
            if changed:
                row.is_enabled = enabled
                stamp_updated(row, now)
                add_audit(
                    session,
                    actor=actor,
                    action="strategy.enable" if enabled else "strategy.disable",
                    entity_type=ENTITY,
                    entity_id=row.id,
                    details={
                        "workspace": workspace_row.slug,
                        "strategy_id": row.strategy_id,
                        "label": row.label,
                        "version": row.strategy_version,
                        "configuration_id": str(row.configuration_id),
                    },
                    client_ip=client_ip,
                )
        if changed:
            await self._reload(deployment_id, actor)
        return await self.get_deployment(deployment_id)

    async def archive(
        self, deployment_id: UUID, *, actor: str, client_ip: str | None = None
    ) -> DeploymentView:
        """Archive a configuration whose live signals are off: it leaves the lists and frees its label,
        and its runs and signals stay. Archiving it again changes nothing."""
        now = self.clock()
        async with self.db.transaction() as session:
            row, workspace_row = await _locked(session, deployment_id, lock_workspace=False)
            if row.archived_at is None:
                if row.is_enabled:
                    raise ConflictError(
                        f"Stop the live signals of '{row.label}' in workspace '{workspace_row.slug}' "
                        "before archiving it",
                        code="deployment_enabled",
                    )
                row.archived_at = now
                stamp_updated(row, now)
                add_audit(
                    session,
                    actor=actor,
                    action="strategy.archive",
                    entity_type=ENTITY,
                    entity_id=row.id,
                    details={
                        "workspace": workspace_row.slug,
                        "strategy_id": row.strategy_id,
                        "label": row.label,
                    },
                    client_ip=client_ip,
                )
        return await self.get_deployment(deployment_id)

    async def list_runs(
        self,
        workspace: UUID | str | None = None,
        strategy_id: str | None = None,
        *,
        deployment_id: UUID | None = None,
        limit: int = 20,
    ) -> list[RunView]:
        """The latest runs first."""
        if not 1 <= limit <= MAX_RUNS:
            raise ValidationFailedError(f"limit must be between 1 and {MAX_RUNS}", code="limit_out_of_range")
        r, d, w = StrategyRunRow, StrategyDeploymentRow, WorkspaceRow
        stmt = (
            select(r, w.slug, d.label)
            .join(d, d.id == r.deployment_id)
            .join(w, w.id == d.workspace_id)
            .order_by(r.started_at.desc(), r.id)
            .limit(limit)
        )
        if strategy_id is not None:
            stmt = stmt.where(r.strategy_id == strategy_id)
        if deployment_id is not None:
            stmt = stmt.where(r.deployment_id == deployment_id)
        async with self.db.session() as session:
            if workspace is not None:
                stmt = stmt.where(d.workspace_id == (await find_workspace(session, workspace)).id)
            return [_run_view(run, slug, label) for run, slug, label in await session.execute(stmt)]

    # ---- strategy worker ------------------------------------------------------------------------

    async def runnable_deployments(self) -> list[RunnableDeployment]:
        """The enabled, unblocked configurations, each with its instruments: those of its scope (or the
        whole workspace universe) minus those that left the universe, became inactive or do not suit the
        strategy. Each instrument comes with the provider the workspace takes it from."""
        runnable: list[RunnableDeployment] = []
        async with self.db.session() as session:
            universes: dict[UUID, Universe] = {}
            for view in await self._deployments(session, include_archived=False):
                if not view.is_runnable:
                    continue
                universe = universes.get(view.workspace_id)
                if universe is None:
                    universe = universes[view.workspace_id] = await _universe(session, view.workspace_id)
                entry = self._entry(view.strategy_id)
                runnable.append(await _runnable(session, view, entry, universe, self.feeds))
        return runnable

    # ---- helpers --------------------------------------------------------------------------------

    def blocked_reason(self, row: StrategyDeploymentRow, workspace: WorkspaceRow) -> str | None:
        """Why the configuration does not run, even when enabled; None when it can."""
        if row.archived_at is not None:
            return "it is archived"
        problem = self._code_problem(row)
        if problem is None and not workspace.is_enabled:
            return f"workspace {workspace.slug} is disabled"
        return problem

    def _code_problem(self, row: StrategyDeploymentRow) -> str | None:
        entry = self.registry.find(row.strategy_id)
        if entry is None:
            return f"strategy {row.strategy_id} is no longer in the code"
        if entry.version != row.strategy_version:
            return (
                f"it was saved with version {row.strategy_version} but the code has {entry.version}; "
                "save it again to upgrade"
            )
        if not stored_scope_ids(row) and row.scope_kind is ScopeKind.INSTRUMENTS:
            return "its instrument scope is unreadable or empty; save it again with its instruments"
        return None

    def _entry(self, strategy_id: str) -> RegisteredStrategy:
        entry = self.registry.find(strategy_id)
        if entry is None:
            known = ", ".join(sorted(entry.strategy_id for entry in self.registry)) or "none"
            raise NotFoundError(
                f"Strategy '{strategy_id}' is not in the code (known: {known})", code="strategy_not_found"
            )
        return entry

    async def _ensure_catalogued(self, entry: RegisteredStrategy, actor: str) -> None:
        s, v = StrategyRow, StrategyVersionRow
        async with self.db.session() as session:
            fingerprint = await session.scalar(
                select(v.code_fingerprint)
                .join(s, s.id == v.strategy_id)
                .where(
                    v.strategy_id == entry.strategy_id,
                    v.version == entry.version,
                    s.latest_version == entry.version,
                    s.is_available,
                )
            )
        if fingerprint != entry.fingerprint:
            await self.sync_catalogue(actor=actor)

    async def _deployments(
        self,
        session: AsyncSession,
        *,
        workspace_id: UUID | None = None,
        deployment_id: UUID | None = None,
        strategy_id: str | None = None,
        instrument_id: UUID | None = None,
        include_archived: bool = True,
        monitor: bool = False,
    ) -> list[DeploymentView]:
        d, w, c, wi = StrategyDeploymentRow, WorkspaceRow, StrategyConfigurationRow, WorkspaceInstrumentRow
        stmt = (
            select(d, w, c)
            .join(w, w.id == d.workspace_id)
            .join(c, c.id == d.configuration_id)
            .order_by(w.sort_order, w.slug, d.strategy_id, d.label)
        )
        if workspace_id is not None:
            stmt = stmt.where(d.workspace_id == workspace_id)
        if deployment_id is not None:
            stmt = stmt.where(d.id == deployment_id)
        if strategy_id is not None:
            stmt = stmt.where(d.strategy_id == strategy_id)
        if not include_archived:
            stmt = stmt.where(d.archived_at.is_(None))
        if instrument_id is not None:
            in_universe = (
                select(wi.instrument_id)
                .where(wi.workspace_id == d.workspace_id, wi.instrument_id == instrument_id)
                .exists()
            )
            stmt = stmt.where(
                or_(
                    and_(d.scope_kind == ScopeKind.WORKSPACE, in_universe),
                    and_(
                        d.scope_kind == ScopeKind.INSTRUMENTS,
                        d.scope.contains({"instrument_ids": [str(instrument_id)]}),
                    ),
                )
            )
        found = (await session.execute(stmt)).all()
        runs = await _last_runs(session, [row.id for row, _, _ in found])
        views = [
            self._view(row, workspace, configuration, runs.get(row.id))
            for row, workspace, configuration in found
        ]
        return await self._monitored(session, views) if monitor else views

    def _view(
        self,
        row: StrategyDeploymentRow,
        workspace: WorkspaceRow,
        configuration: StrategyConfigurationRow,
        run: StrategyRunRow | None,
    ) -> DeploymentView:
        entry = self.registry.find(row.strategy_id)
        return DeploymentView(
            id=row.id,
            workspace_id=workspace.id,
            workspace_slug=workspace.slug,
            market_region=workspace.market_region,
            strategy_id=row.strategy_id,
            strategy_version=row.strategy_version,
            code_fingerprint=None
            if entry is None or entry.version != row.strategy_version
            else entry.fingerprint,
            label=row.label,
            configuration_id=configuration.id,
            config=configuration.config,
            config_hash=configuration.config_hash,
            scope_kind=row.scope_kind,
            instrument_ids=stored_scope_ids(row) or (),
            is_enabled=row.is_enabled,
            enabled_by=row.enabled_by,
            enabled_at=row.enabled_at,
            disabled_at=row.disabled_at,
            archived_at=row.archived_at,
            created_at=row.created_at,
            updated_at=row.updated_at,
            blocked_reason=self.blocked_reason(row, workspace),
            last_run=None if run is None else _run_view(run, workspace.slug, row.label),
        )

    async def _monitored(
        self, session: AsyncSession, views: Sequence[DeploymentView]
    ) -> list[DeploymentView]:
        """The views with their monitoring state (see ``derive_monitoring``)."""
        if not views:
            return []
        worker_problem = await self._worker_problem()
        kill_switch = await load_kill_switch(session)
        policies: dict[UUID, RiskPolicy] = {}
        universes: dict[UUID, Universe] = {}
        monitored: list[DeploymentView] = []
        for view in views:
            if view.archived_at is not None:
                stopped = Monitoring(state=MonitoringState.STOPPED)
                monitored.append(view.model_copy(update={"monitoring": stopped}))
                continue
            if view.workspace_id not in policies:
                policies[view.workspace_id] = await load_policy(session, view.workspace_id)
                universes[view.workspace_id] = await _universe(session, view.workspace_id)
            instruments: Sequence[tuple[Instrument, Provider]] = ()
            excluded: Mapping[str, str] = {}
            entry = self.registry.find(view.strategy_id)
            if entry is not None and entry.version == view.strategy_version:
                found = await _runnable(session, view, entry, universes[view.workspace_id], self.feeds)
                instruments, excluded = found.instruments, found.excluded
            inputs = MonitoringInputs(
                deployment=view,
                worker_problem=worker_problem,
                instruments=len(instruments),
                live_instruments=sum(provider is not Provider.SIMULATOR for _, provider in instruments),
                excluded=excluded,
                signal_blocks=signal_blocks(kill_switch, policies[view.workspace_id]),
                live_signals_enabled=self.live_signals_enabled,
            )
            monitored.append(view.model_copy(update={"monitoring": derive_monitoring(inputs)}))
        return monitored

    async def _worker_problem(self) -> str | None:
        """Why the strategy worker is not running configurations now; None while its heartbeat is
        fresh."""
        try:
            beat = await self.bus.get_json(Keys.worker_heartbeat(STRATEGY_WORKER))
        except (RedisError, OSError) as exc:
            return f"The strategy worker's heartbeat cannot be read from Redis ({type(exc).__name__})"
        if beat is None:
            return "The strategy worker is not running (no recent heartbeat); start qt-strategy-worker"
        return None

    async def _reload(self, deployment_id: UUID, actor: str) -> None:
        await publish_command(
            self.bus,
            WorkerCommand(
                type=CommandType.RELOAD_DEPLOYMENTS,
                params={"deployment_id": str(deployment_id)},
                issued_by=actor,
            ),
        )


async def _strategies(session: AsyncSession, strategy_id: str | None = None) -> list[StrategyView]:
    s, v, d = StrategyRow, StrategyVersionRow, StrategyDeploymentRow
    counts = (
        select(
            d.strategy_id,
            func.count().label("total"),
            func.count().filter(d.is_enabled).label("enabled"),
        )
        .where(d.archived_at.is_(None))
        .group_by(d.strategy_id)
        .subquery()
    )
    stmt = (
        select(s, v, func.coalesce(counts.c.total, 0), func.coalesce(counts.c.enabled, 0))
        .join(v, (v.strategy_id == s.id) & (v.version == s.latest_version))
        .outerjoin(counts, counts.c.strategy_id == s.id)
        .order_by(s.id)
    )
    if strategy_id is not None:
        stmt = stmt.where(s.id == strategy_id)
    return [
        StrategyView(
            strategy_id=row.id,
            name=row.name,
            description=row.description,
            author=row.author,
            version=row.latest_version,
            is_example=row.is_example,
            is_available=row.is_available,
            can_emit_actionable=bool(version.plugin_metadata.get("can_emit_actionable", False)),
            code_fingerprint=version.code_fingerprint,
            metadata=version.plugin_metadata,
            # Stored metadata is a dump of StrategyMetadata, whose later fields all have defaults.
            data_requirements=tuple(
                sorted(data_needs(StrategyMetadata.model_validate(version.plugin_metadata)))
            ),
            config_schema=version.config_schema,
            default_config=version.default_config,
            deployments=int(total),
            enabled_deployments=int(enabled),
        )
        for row, version, total, enabled in await session.execute(stmt)
    ]


def _not_found(deployment_id: UUID) -> NotFoundError:
    return NotFoundError(f"Saved configuration {deployment_id} was not found", code="deployment_not_found")


async def _locked(
    session: AsyncSession, deployment_id: UUID, *, lock_workspace: bool
) -> tuple[StrategyDeploymentRow, WorkspaceRow]:
    """The configuration, locked, and its workspace. When asked, the workspace is locked first: label
    and duplicate checks happen under its lock, and the signal engine only share-locks configurations."""
    d, w = StrategyDeploymentRow, WorkspaceRow
    workspace_id = await session.scalar(select(d.workspace_id).where(d.id == deployment_id))
    if workspace_id is None:
        raise _not_found(deployment_id)
    workspace_stmt = select(w).where(w.id == workspace_id)
    if lock_workspace:
        workspace_stmt = workspace_stmt.with_for_update()
    workspace = await session.scalar(workspace_stmt)
    row = await session.scalar(select(d).where(d.id == deployment_id).with_for_update())
    if workspace is None or row is None:  # deleted meanwhile
        raise _not_found(deployment_id)
    return row, workspace


def _checked_scope(scope: Scope) -> Scope:
    ids = tuple(dict.fromkeys(scope.instrument_ids))
    if scope.kind is ScopeKind.WORKSPACE:
        if ids:
            raise ValidationFailedError(
                "A whole-workspace scope lists no instruments", code="deployment_scope_invalid"
            )
        return scope
    if not ids:
        raise ValidationFailedError(
            "Choose at least one instrument, or choose the whole workspace explicitly",
            code="deployment_scope_invalid",
        )
    if len(ids) > MAX_SCOPE:
        raise ValidationFailedError(
            f"A configuration watches at most {MAX_SCOPE} instruments", code="deployment_scope_too_large"
        )
    return Scope(ScopeKind.INSTRUMENTS, ids)


def _check_market(entry: RegisteredStrategy, workspace: WorkspaceRow) -> None:
    problem = entry.metadata.eligibility_problem(market=workspace.market_region)
    if problem is not None:
        raise ValidationFailedError(
            f"{entry.strategy_id} cannot be used in workspace '{workspace.slug}': {problem}",
            code="strategy_not_eligible",
        )


def _clean_label(label: str) -> str:
    cleaned = label.strip()
    if not 1 <= len(cleaned) <= MAX_LABEL or not cleaned.isprintable():
        raise ValidationFailedError(
            f"A label needs 1 to {MAX_LABEL} printable characters", code="deployment_label_invalid"
        )
    return cleaned


async def _active_labels(
    session: AsyncSession, workspace_id: UUID, *, excluding: UUID | None = None
) -> set[str]:
    """The casefolded labels of the workspace's configurations that are not archived."""
    d = StrategyDeploymentRow
    stmt = select(d.label).where(d.workspace_id == workspace_id, d.archived_at.is_(None))
    if excluding is not None:
        stmt = stmt.where(d.id != excluding)
    return {label.casefold() for label in await session.scalars(stmt)}


def _unique_label(label: str, taken: set[str], workspace: WorkspaceRow) -> str:
    if label.casefold() in taken:
        raise ConflictError(
            f"Workspace '{workspace.slug}' already has a configuration labelled '{label}'; "
            "choose another label",
            code="deployment_label_taken",
        )
    return label


def _free_label(base: str, taken: set[str]) -> str:
    label, number = base, 1
    while label.casefold() in taken:
        number += 1
        label = f"{base} {number}"
    return label


async def _refuse_duplicate(
    session: AsyncSession,
    row: StrategyDeploymentRow,
    workspace: WorkspaceRow,
    *,
    version: str,
    config_hash: str,
    scope: Scope,
) -> None:
    """Refuse to run a configuration that another enabled one of the workspace already runs: the same
    strategy version with the same settings on an overlapping scope would propose every signal twice."""
    d, c = StrategyDeploymentRow, StrategyConfigurationRow
    others = await session.scalars(
        select(d)
        .join(c, c.id == d.configuration_id)
        .where(
            d.workspace_id == workspace.id,
            d.id != row.id,
            d.is_enabled,
            d.archived_at.is_(None),
            d.strategy_id == row.strategy_id,
            d.strategy_version == version,
            c.config_hash == config_hash,
        )
        .order_by(d.label)
    )
    for other in others:
        other_ids = stored_scope_ids(other)
        if other_ids is None:
            continue  # its scope is unreadable, so it does not run
        shared: tuple[UUID, ...] | None  # None: the whole workspace
        if scope.kind is ScopeKind.WORKSPACE:
            shared = None if other.scope_kind is ScopeKind.WORKSPACE else other_ids
        elif other.scope_kind is ScopeKind.WORKSPACE:
            shared = scope.instrument_ids
        else:
            theirs = set(other_ids)
            shared = tuple(instrument_id for instrument_id in scope.instrument_ids if instrument_id in theirs)
            if not shared:
                continue
        keys = [] if shared is None else await _keys(session, shared)
        where = "the whole workspace" if shared is None else _listed_keys(keys)
        raise ConflictError(
            f"Configuration '{other.label}' already runs {row.strategy_id} {version} with the same settings "
            f"on {where}; stop its live signals first, or change this configuration's settings or scope",
            code="deployment_duplicate",
            details={"deployment_id": str(other.id), "label": other.label, "instruments": keys},
        )


async def _keys(session: AsyncSession, instrument_ids: Sequence[UUID]) -> list[str]:
    """The instruments' canonical keys, in order (the ID of one that no longer exists)."""
    i = InstrumentRow
    rows = await session.execute(select(i.id, i.canonical_key).where(i.id.in_(instrument_ids)))
    keys: dict[UUID, str] = dict(rows.all())
    return [keys.get(instrument_id, str(instrument_id)) for instrument_id in instrument_ids]


def _listed_keys(keys: Sequence[str]) -> str:
    listed = ", ".join(keys[:_SHOWN_PROBLEMS])
    if len(keys) > _SHOWN_PROBLEMS:
        listed += f" and {len(keys) - _SHOWN_PROBLEMS} more"
    return listed


async def _last_runs(session: AsyncSession, deployment_ids: Sequence[UUID]) -> dict[UUID, StrategyRunRow]:
    if not deployment_ids:
        return {}
    r = StrategyRunRow
    stmt = (
        select(r)
        .where(r.deployment_id.in_(deployment_ids))
        .ext(distinct_on(r.deployment_id))
        .order_by(r.deployment_id, r.started_at.desc())
    )
    return {row.deployment_id: row for row in await session.scalars(stmt)}


async def _snapshot(
    session: AsyncSession, entry: RegisteredStrategy, config: dict[str, Any], actor: str
) -> StrategyConfigurationRow:
    """The configuration's snapshot: an existing one with the same values, or a new one."""
    digest = config_hash(config)
    c = StrategyConfigurationRow
    existing = await session.scalar(
        select(c)
        .where(c.strategy_id == entry.strategy_id, c.version == entry.version, c.config_hash == digest)
        .order_by(c.created_at)
        .limit(1)
    )
    if existing is not None:
        return existing
    row = StrategyConfigurationRow(
        strategy_id=entry.strategy_id,
        version=entry.version,
        config=config,
        config_hash=digest,
        created_by=actor[:64],
    )
    session.add(row)
    await session.flush()
    return row


async def _validated_scope(
    session: AsyncSession,
    workspace: WorkspaceRow,
    entry: RegisteredStrategy,
    scope: Scope,
    feeds: FeedDelivery,
    *,
    kept: bool,
) -> tuple[UUID, ...]:
    """An instrument scope's instruments, unique and in order; each must be in the workspace universe and
    suit the strategy as the workspace streams it. A whole-workspace scope lists none: the strategy worker
    leaves out the instruments that do not suit the strategy when it runs, and says why."""
    if scope.kind is ScopeKind.WORKSPACE:
        return ()
    ids = tuple(dict.fromkeys(scope.instrument_ids))
    wi, i = WorkspaceInstrumentRow, InstrumentRow
    rows = await session.execute(
        select(i, wi.provider, wi.subscription_mode)
        .join(wi, wi.instrument_id == i.id)
        .where(wi.workspace_id == workspace.id, i.id.in_(ids))
    )
    found = {instrument.id: (instrument, provider, mode) for instrument, provider, mode in rows}
    problems: list[tuple[str, str]] = []
    for instrument_id in ids:
        if (member := found.get(instrument_id)) is None:
            problems.append((str(instrument_id), f"it is not in workspace {workspace.slug}"))
            continue
        instrument, provider, mode = member
        problem = instrument_problem(entry, instrument, provider, mode, feeds)
        if problem is not None:
            problems.append((instrument.canonical_key, problem))
    if problems:
        listed = "; ".join(f"{key}: {reason}" for key, reason in problems[:_SHOWN_PROBLEMS])
        if len(problems) > _SHOWN_PROBLEMS:
            listed += f"; and {len(problems) - _SHOWN_PROBLEMS} more"
        hint = " (in the saved scope: give the instruments again, or choose the whole workspace)"
        raise ValidationFailedError(
            f"{entry.strategy_id} cannot watch these instruments in workspace '{workspace.slug}': {listed}"
            + (hint if kept else ""),
            code="deployment_scope_rejected",
            details={
                "workspace": workspace.slug,
                "problems": [{"instrument": key, "reason": reason} for key, reason in problems],
            },
        )
    return ids


async def _universe(session: AsyncSession, workspace_id: UUID) -> Universe:
    """The workspace's instruments, each with the provider it streams from and its subscription mode, in
    canonical-key order."""
    wi, i = WorkspaceInstrumentRow, InstrumentRow
    rows = await session.execute(
        select(i, wi.provider, wi.subscription_mode)
        .join(wi, wi.instrument_id == i.id)
        .where(wi.workspace_id == workspace_id)
        .order_by(i.canonical_key)
    )
    return {instrument.id: (instrument, provider, mode) for instrument, provider, mode in rows}


async def _runnable(
    session: AsyncSession,
    view: DeploymentView,
    entry: RegisteredStrategy,
    universe: Universe,
    feeds: FeedDelivery,
) -> RunnableDeployment:
    scope = tuple(universe) if view.scope_kind is ScopeKind.WORKSPACE else view.instrument_ids
    excluded: dict[str, str] = {}
    gone = [instrument_id for instrument_id in scope if instrument_id not in universe]
    if gone:
        i = InstrumentRow
        rows = await session.execute(select(i.id, i.canonical_key).where(i.id.in_(gone)))
        keys: dict[UUID, str] = dict(rows.all())
        for instrument_id in gone:
            excluded[keys.get(instrument_id, str(instrument_id))] = f"it left workspace {view.workspace_slug}"
    instruments: list[tuple[Instrument, Provider]] = []
    for instrument_id in scope:
        if (found := universe.get(instrument_id)) is None:
            continue
        row, provider, mode = found
        problem = instrument_problem(entry, row, provider, mode, feeds)
        if problem is None:
            instruments.append((Instrument.model_validate(row, from_attributes=True), provider))
        else:
            excluded[row.canonical_key] = problem
    return RunnableDeployment(view, tuple(instruments), MappingProxyType(excluded))


def _kept_scope(row: StrategyDeploymentRow) -> Scope:
    if row.scope_kind is ScopeKind.WORKSPACE:
        return Scope.workspace()
    ids = _scope_ids(row.scope)
    if not ids:
        raise ValidationFailedError(
            "The saved instrument scope is unreadable; give its instruments again, "
            "or choose the whole workspace",
            code="deployment_scope_rejected",
        )
    return Scope.instruments(ids)


def stored_scope_ids(row: StrategyDeploymentRow) -> tuple[UUID, ...] | None:
    """A saved scope's instruments: none for a whole-workspace scope; None when unreadable."""
    return () if row.scope_kind is ScopeKind.WORKSPACE else _scope_ids(row.scope)


def _scope_ids(scope: Mapping[str, Any]) -> tuple[UUID, ...] | None:
    """The stored instruments; None when the stored scope is unreadable."""
    raw = scope.get("instrument_ids", [])
    if not isinstance(raw, list):
        return None
    try:
        return tuple(UUID(str(value)) for value in raw)
    except ValueError:
        return None


def _scope_json(instrument_ids: Sequence[UUID]) -> dict[str, Any]:
    return {"instrument_ids": [str(instrument_id) for instrument_id in instrument_ids]}


def _validated(entry: RegisteredStrategy, values: Mapping[str, Any]) -> dict[str, Any]:
    try:
        return entry.validate_config(values).model_dump(mode="json")
    except StrategyConfigError as exc:
        raise ValidationFailedError(f"Invalid configuration: {exc}", code="strategy_config_invalid") from None


def _strategy_row(entry: RegisteredStrategy) -> StrategyRow:
    metadata = entry.metadata
    return StrategyRow(
        id=entry.strategy_id,
        kind=metadata.kind,
        name=metadata.name,
        description=metadata.description,
        author=metadata.author,
        is_example=metadata.is_example,
        latest_version=entry.version,
        is_available=True,
    )


def _describe(row: StrategyRow, entry: RegisteredStrategy) -> bool:
    """Bring a catalogue row up to date with the code; True when anything changed."""
    metadata = entry.metadata
    wanted = (
        metadata.kind,
        metadata.name,
        metadata.description,
        metadata.author,
        metadata.is_example,
        entry.version,
        True,
    )
    current = (
        row.kind,
        row.name,
        row.description,
        row.author,
        row.is_example,
        row.latest_version,
        row.is_available,
    )
    if current == wanted:
        return False
    (
        row.kind,
        row.name,
        row.description,
        row.author,
        row.is_example,
        row.latest_version,
        row.is_available,
    ) = wanted
    return True


def _store_version(row: StrategyVersionRow, entry: RegisteredStrategy) -> None:
    row.plugin_metadata = entry.metadata.model_dump(mode="json")
    row.config_schema = dict(entry.config_schema)
    row.default_config = dict(entry.default_config)
    row.code_fingerprint = entry.fingerprint


def _version_matches(row: StrategyVersionRow, entry: RegisteredStrategy) -> bool:
    return (
        row.code_fingerprint == entry.fingerprint
        and row.plugin_metadata == entry.metadata.model_dump(mode="json")
        and row.config_schema == dict(entry.config_schema)
        and row.default_config == dict(entry.default_config)
    )


def _run_view(row: StrategyRunRow, workspace_slug: str, label: str) -> RunView:
    context = row.input_context
    fingerprint = context.get("code_fingerprint")
    instruments = context.get("instruments")
    excluded = context.get("excluded")
    return RunView(
        id=row.id,
        deployment_id=row.deployment_id,
        deployment_label=label,
        workspace_slug=workspace_slug,
        strategy_id=row.strategy_id,
        strategy_version=row.strategy_version,
        configuration_id=row.configuration_id,
        config_hash=row.config_hash,
        code_fingerprint=fingerprint if isinstance(fingerprint, str) else None,
        status=row.status,
        worker_id=row.worker_id,
        started_at=row.started_at,
        stopped_at=row.stopped_at,
        heartbeat_at=row.heartbeat_at,
        instruments=len(instruments) if isinstance(instruments, dict) else 0,
        excluded=len(excluded) if isinstance(excluded, dict) else 0,
        instruments_warming=row.instruments_warming,
        warmup_remaining={
            str(interval): count for interval, count in row.warmup_remaining.items() if isinstance(count, int)
        },
        events_processed=row.events_processed,
        candles_processed=row.candles_processed,
        signals_emitted=row.signals_emitted,
        failures=row.failures,
        timeouts=row.timeouts,
        last_error=row.last_error,
        circuit_opened_at=row.circuit_opened_at,
    )
