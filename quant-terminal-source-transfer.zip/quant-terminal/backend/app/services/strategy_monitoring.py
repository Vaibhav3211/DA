"""Live-monitoring state of a saved strategy configuration (EXT-5).

Monitoring runs in the strategy worker on the server: it carries on after the chart or the browser is
closed, until live signals are turned off. ``derive_monitoring`` sums up how a configuration is doing as
one state with its reasons. It reads nothing itself; ``StrategyService`` gathers its inputs: the
deployment with its latest run, the strategy worker's heartbeat, what its scope resolves to now, the
kill switch, the workspace's risk rules and LIVE_SIGNALS_ENABLED.

Rules that block every signal (the kill switch, a paused workspace, invalid rule settings, and
LIVE_SIGNALS_ENABLED=false when every instrument uses live data) make an enabled configuration BLOCKED.
Its run carries on and stores each blocked signal with its reasons. Rules that judge each signal on its
own (data freshness, price sanity, frequency and so on) do not change the state: each blocked signal
carries its own reasons.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from app.domain.enums import MonitoringState, StrategyRunStatus
from app.domain.models.base import DomainModel
from app.risk.engine import RiskPolicy
from app.risk.rules import WORKSPACE_PAUSE, PauseParams
from app.services.kill_switch import KillSwitchState

if TYPE_CHECKING:
    from app.services.strategies import DeploymentView, RunView

LIVE_SIGNALS_OFF: Final = "Signals on live data are disabled (set LIVE_SIGNALS_ENABLED=true to allow them)"
_SHOWN: Final = 5


class MonitoringWarmup(DomainModel):
    """How far the current run's warm-up is."""

    instruments: int  # instruments still short of the closed candles the strategy needs
    of: int  # instruments the run covers
    remaining: dict[str, int]  # per candle interval, the most candles any of them still needs


class Monitoring(DomainModel):
    """How live monitoring of a saved configuration is doing."""

    state: MonitoringState
    reasons: tuple[str, ...] = ()  # why it is not RUNNING (empty when RUNNING or STOPPED)
    # What limits it without stopping it; for a STOPPED configuration, also what would block it.
    warnings: tuple[str, ...] = ()
    warmup: MonitoringWarmup | None = None


@dataclass(frozen=True, slots=True)
class MonitoringInputs:
    deployment: DeploymentView  # with its blocked reason and latest run
    worker_problem: str | None  # None while the strategy worker's heartbeat is fresh
    instruments: int  # the instruments its scope resolves to now
    live_instruments: int  # of those, the ones a live (non-simulator) provider feeds
    excluded: Mapping[str, str]  # instruments of the scope it leaves out, with why
    signal_blocks: Sequence[str]  # rules that block every signal now (see ``signal_blocks``)
    live_signals_enabled: bool


def signal_blocks(kill_switch: KillSwitchState, policy: RiskPolicy) -> list[str]:
    """What blocks every signal of the policy's workspace now, whatever the signal: the kill switch, a
    paused workspace and enabled rules whose stored settings are invalid. The kill-switch and pause
    messages match the risk gate's."""
    blocks: list[str] = []
    if kill_switch.engaged:
        blocks.append(f"Kill switch is engaged ({kill_switch.reason or 'no reason given'})")
    pause = policy.get(WORKSPACE_PAUSE)
    if pause.enabled and isinstance(pause.params, PauseParams) and pause.params.paused:
        blocks.append(f"Signals are paused for this workspace ({pause.params.reason or 'no reason given'})")
    blocks.extend(
        f"Risk rule {item.rule.key} has invalid stored parameters ({item.error}); "
        "fix with qt risk set or qt risk reset"
        for item in policy.rules
        if item.enabled and item.params is None
    )
    return blocks


def derive_monitoring(inputs: MonitoringInputs) -> Monitoring:
    """One state with its reasons; the first that applies wins:

    1. STOPPED: live signals are off (the warnings say what would block it).
    2. BLOCKED: it cannot run (``blocked_reason``), or no instrument of its scope can run.
    3. FAILED: the strategy worker's heartbeat is missing, or the current run failed or opened its
       circuit.
    4. BLOCKED: every signal it proposes would be blocked.
    5. STARTING: the worker has not started a run of the current settings, or the run is loading.
    6. WARMING_UP: some instruments still lack the closed candles the strategy needs.
    7. RUNNING.
    """
    deployment = inputs.deployment
    blocks = list(inputs.signal_blocks)
    warnings: list[str] = []
    if inputs.live_instruments and not inputs.live_signals_enabled:
        if inputs.live_instruments == inputs.instruments:
            blocks.append(LIVE_SIGNALS_OFF)
        else:
            warnings.append(
                f"{LIVE_SIGNALS_OFF}: the signals of {inputs.live_instruments} of its "
                f"{inputs.instruments} instruments are blocked"
            )
    if inputs.instruments and not inputs.live_instruments:
        warnings.append("Its instruments use simulated data: its signals are informational only")
    if inputs.excluded and inputs.instruments:
        warnings.append(f"{_count(len(inputs.excluded))} left out: {_listed(inputs.excluded)}")

    cannot_run = deployment.blocked_reason
    if cannot_run is None and not inputs.instruments:
        cannot_run = _no_instruments(inputs.excluded)
    if not deployment.is_enabled:
        would = [cannot_run] if cannot_run is not None else blocks
        return Monitoring(
            state=MonitoringState.STOPPED,
            warnings=(*(f"If enabled, it would be blocked: {reason}" for reason in would), *warnings),
        )
    if cannot_run is not None:
        return Monitoring(state=MonitoringState.BLOCKED, reasons=(cannot_run,), warnings=tuple(warnings))
    if inputs.worker_problem is not None:
        return Monitoring(
            state=MonitoringState.FAILED, reasons=(inputs.worker_problem,), warnings=tuple(warnings)
        )

    run = _current(deployment)
    if run is not None and run.status is StrategyRunStatus.FAILED:
        reason = f"Its run failed: {run.last_error or 'no error was recorded'}"
        return Monitoring(state=MonitoringState.FAILED, reasons=(reason,), warnings=tuple(warnings))
    if run is not None and run.status is StrategyRunStatus.CIRCUIT_OPEN:
        reason = (
            "The strategy kept failing, so the worker paused calling it (circuit open); "
            f"last error: {run.last_error or 'none recorded'}"
        )
        return Monitoring(state=MonitoringState.FAILED, reasons=(reason,), warnings=tuple(warnings))
    if blocks:
        return Monitoring(state=MonitoringState.BLOCKED, reasons=tuple(blocks), warnings=tuple(warnings))
    if run is None or run.status is StrategyRunStatus.STOPPED:
        reason = "Waiting for the strategy worker to start a run with the current settings"
        return Monitoring(state=MonitoringState.STARTING, reasons=(reason,), warnings=tuple(warnings))
    if run.status is StrategyRunStatus.STARTING:
        reason = "The run is loading the stored candles it warms up from"
        return Monitoring(state=MonitoringState.STARTING, reasons=(reason,), warnings=tuple(warnings))
    if run.instruments_warming:
        warmup = MonitoringWarmup(
            instruments=run.instruments_warming, of=run.instruments, remaining=dict(run.warmup_remaining)
        )
        reason = (
            f"{run.instruments_warming} of {run.instruments} instruments still lack the closed candles "
            "the strategy needs; their signals start once they have them"
        )
        return Monitoring(
            state=MonitoringState.WARMING_UP, reasons=(reason,), warnings=tuple(warnings), warmup=warmup
        )
    return Monitoring(state=MonitoringState.RUNNING, warnings=tuple(warnings))


def _current(deployment: DeploymentView) -> RunView | None:
    """The latest run, when it runs the configuration as it stands since live signals were turned on."""
    run = deployment.last_run
    if run is None:
        return None
    if deployment.enabled_at is not None and run.started_at < deployment.enabled_at:
        return None
    if (run.strategy_version, run.configuration_id) != (
        deployment.strategy_version,
        deployment.configuration_id,
    ):
        return None
    return run


def _no_instruments(excluded: Mapping[str, str]) -> str:
    if not excluded:
        return "Its scope has no instruments: the workspace has none"
    return f"None of the instruments in its scope can run: {_listed(excluded)}"


def _count(n: int) -> str:
    return f"{n} instrument" if n == 1 else f"{n} instruments"


def _listed(excluded: Mapping[str, str]) -> str:
    shown = "; ".join(f"{key}: {reason}" for key, reason in list(excluded.items())[:_SHOWN])
    if len(excluded) > _SHOWN:
        shown += f"; and {len(excluded) - _SHOWN} more"
    return shown
