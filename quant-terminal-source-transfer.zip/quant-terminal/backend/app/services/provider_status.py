"""Provider overviews for the API: accounts, live feeds and effective capabilities, without secrets."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from datetime import datetime
from typing import Self
from uuid import UUID

from app.container import Container
from app.core.clock import utc_now
from app.core.config import Settings
from app.core.errors import NotFoundError
from app.domain.enums import AccountStatus, DataStatus, Provider
from app.domain.models import ProviderCapabilities, StreamHealth
from app.domain.models.base import DomainModel, UtcDatetime
from app.services.capabilities import CapabilityService
from app.services.provider_accounts import ProviderAccountService, ProviderAccountView
from app.services.quotes import FeedStatuses, read_feed_streams


def available_providers(settings: Settings) -> tuple[Provider, ...]:
    """The simulator exists only in simulated mode (development or replay with SIMULATOR_ENABLED)."""
    return tuple(p for p in Provider if p is not Provider.SIMULATOR or settings.is_simulated_mode)


def parse_provider(value: str, settings: Settings) -> Provider:
    """A provider named in a URL, in any letter case."""
    for provider in available_providers(settings):
        if provider.value.lower() == value.lower():
            return provider
    raise NotFoundError(f"No provider is named '{value[:40]}'", code="provider_not_found")


class ProviderSummary(DomainModel):
    provider: Provider
    display_name: str
    data_status: DataStatus  # the worst of the provider's live feeds; DISCONNECTED when none runs
    accounts: tuple[ProviderAccountView, ...]
    feeds: tuple[StreamHealth, ...]
    capabilities: ProviderCapabilities  # with provider-wide overrides applied
    generated_at: UtcDatetime


class ProviderAccountHealth(DomainModel):
    account_id: UUID
    label: str
    is_enabled: bool
    status: AccountStatus
    has_access_token: bool
    token_expires_at: UtcDatetime | None
    data_status: DataStatus
    last_error_code: str | None
    last_error_message: str | None
    streaming_disabled_reason: str | None


class ProviderHealth(DomainModel):
    provider: Provider
    data_status: DataStatus
    accounts: tuple[ProviderAccountHealth, ...]
    feeds: tuple[StreamHealth, ...]
    generated_at: UtcDatetime


class ProviderStatusService:
    def __init__(
        self,
        accounts: ProviderAccountService,
        capabilities: CapabilityService,
        *,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self._accounts = accounts
        self._capabilities = capabilities
        self._clock = clock

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(
            ProviderAccountService.from_container(container, clock=clock),
            CapabilityService.from_container(container, clock=clock),
            clock=clock,
        )

    async def summaries(self) -> list[ProviderSummary]:
        streams = await read_feed_streams(self._accounts.bus)
        accounts = await self._accounts.list_accounts()
        return [
            await self._summary(provider, accounts, streams)
            for provider in available_providers(self._accounts.settings)
        ]

    async def summary(self, provider: Provider) -> ProviderSummary:
        streams = await read_feed_streams(self._accounts.bus)
        return await self._summary(provider, await self._accounts.list_accounts(provider), streams)

    async def health(self, provider: Provider) -> ProviderHealth:
        streams = [s for s in await read_feed_streams(self._accounts.bus) if s.provider is provider]
        feeds = FeedStatuses(streams)
        accounts = await self._accounts.list_accounts(provider)
        return ProviderHealth(
            provider=provider,
            data_status=feeds.provider_status(provider),
            accounts=tuple(
                ProviderAccountHealth(
                    account_id=account.id,
                    label=account.label,
                    is_enabled=account.is_enabled,
                    status=account.status,
                    has_access_token=account.has_access_token,
                    token_expires_at=account.token_expires_at,
                    data_status=feeds.status(provider, account.id),
                    last_error_code=account.last_error_code,
                    last_error_message=account.last_error_message,
                    streaming_disabled_reason=account.streaming_disabled_reason,
                )
                for account in accounts
            ),
            feeds=tuple(streams),
            generated_at=self._clock(),
        )

    async def _summary(
        self, provider: Provider, accounts: Sequence[ProviderAccountView], streams: Sequence[StreamHealth]
    ) -> ProviderSummary:
        feeds = tuple(s for s in streams if s.provider is provider)
        capabilities = await self._capabilities.effective(provider)
        return ProviderSummary(
            provider=provider,
            display_name=capabilities.display_name,
            data_status=FeedStatuses(feeds).provider_status(provider),
            accounts=tuple(a for a in accounts if a.provider is provider),
            feeds=feeds,
            capabilities=capabilities,
            generated_at=self._clock(),
        )
