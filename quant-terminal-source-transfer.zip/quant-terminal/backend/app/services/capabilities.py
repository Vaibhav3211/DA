"""Effective provider capabilities: the documented defaults plus operator overrides.

``app.providers.capabilities`` holds what was verified from official documentation. Operators can
override individual fields in ``provider_capabilities``, either for a whole provider (``account_id``
NULL) or for one account (e.g. a plan with different limits). Fields merge shallowly: the account
row wins over the provider row, which wins over the default, and a mapping such as
``rest_rate_limits`` is replaced as a whole. The provenance (``verified_on`` and
``verification_source``) of the most specific applied override replaces the default's.

Stored overrides that no longer validate fail closed: ``effective`` raises rather than silently
falling back to defaults the operator deliberately replaced.
"""

from __future__ import annotations

from collections.abc import Callable, Collection, Mapping, Sequence
from datetime import date, datetime
from typing import Any, Self
from uuid import UUID

from pydantic import ValidationError
from sqlalchemy import ColumnElement, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.container import Container
from app.core.clock import utc_now
from app.core.errors import NotFoundError, ValidationFailedError
from app.domain.enums import Provider
from app.domain.models import ProviderCapabilities
from app.domain.models.base import DomainModel, UtcDatetime
from app.persistence.database import Database
from app.persistence.models import ProviderAccountRow, ProviderCapabilityRow
from app.persistence.models.common import stamp_updated
from app.providers.capabilities import default_capabilities
from app.services.audit import add_audit

ENTITY = "provider_capability"
INVALID = "capability_override_invalid"
# Provenance belongs to an override as a whole and is given with every change, never as a value.
_PROVENANCE = frozenset({"provider", "verified_on", "verification_source"})
OVERRIDABLE_FIELDS: tuple[str, ...] = tuple(
    name for name in ProviderCapabilities.model_fields if name not in _PROVENANCE
)
_SOURCE_MAX = 200


class CapabilityOverride(DomainModel):
    id: UUID
    provider: Provider
    account_id: UUID | None
    account_label: str | None
    values: dict[str, Any]
    verified_on: date | None
    verification_source: str
    updated_at: UtcDatetime


def apply_overrides(
    base: ProviderCapabilities, overrides: Sequence[CapabilityOverride]
) -> ProviderCapabilities:
    """``base`` with ``overrides`` applied in order, least specific first."""
    if not overrides:
        return base
    merged = base.model_dump(mode="json")
    for override in overrides:
        merged.update({k: v for k, v in override.values.items() if k in OVERRIDABLE_FIELDS})
        merged["verified_on"] = override.verified_on
        merged["verification_source"] = override.verification_source
    try:
        return ProviderCapabilities.model_validate(merged)
    except ValidationError as exc:
        raise ValidationFailedError(
            f"The stored {base.provider.value} capability overrides are invalid ({_describe(exc)}); "
            "correct or clear them",
            code=INVALID,
        ) from None


class CapabilityService:
    def __init__(self, db: Database, *, clock: Callable[[], datetime] = utc_now) -> None:
        self.db = db
        self.clock = clock

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(container.db, clock=clock)

    async def effective(self, provider: Provider, account_id: UUID | None = None) -> ProviderCapabilities:
        scope: ColumnElement[bool] = ProviderCapabilityRow.account_id.is_(None)
        if account_id is not None:
            scope = scope | (ProviderCapabilityRow.account_id == account_id)
        async with self.db.session() as session:
            overrides = await _select(session, ProviderCapabilityRow.provider == provider, scope)
        return apply_overrides(default_capabilities(provider), overrides)

    async def list_overrides(self, provider: Provider | None = None) -> list[CapabilityOverride]:
        conditions = [] if provider is None else [ProviderCapabilityRow.provider == provider]
        async with self.db.session() as session:
            return await _select(session, *conditions)

    async def set_override(
        self,
        provider: Provider,
        values: Mapping[str, Any],
        *,
        verification_source: str,
        verified_on: date | None,
        account_id: UUID | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> CapabilityOverride:
        """Merge ``values`` into the provider's (or one account's) override."""
        _check_fields(values.keys())
        source = " ".join(verification_source.split())
        if not 0 < len(source) <= _SOURCE_MAX:
            raise ValidationFailedError(
                f"Say where the values were verified (1-{_SOURCE_MAX} characters)", code=INVALID
            )
        now = self.clock()
        async with self.db.transaction() as session:
            label = await self._lock(session, provider, account_id)
            row = await self._row(session, provider, account_id)
            normalized = _normalized(provider, {**(row.capabilities if row else {}), **values})
            if row is None:
                row = ProviderCapabilityRow(
                    provider=provider,
                    account_id=account_id,
                    capabilities=normalized,
                    verified_on=verified_on,
                    verification_source=source,
                    created_at=now,
                    updated_at=now,
                )
                session.add(row)
                await session.flush()
            else:
                row.capabilities = normalized
                row.verified_on = verified_on
                row.verification_source = source
                stamp_updated(row, now)
            add_audit(
                session,
                actor=actor,
                action="provider_capability.set",
                entity_type=ENTITY,
                entity_id=row.id,
                details={
                    **_scope_details(provider, account_id),
                    "values": {name: normalized[name] for name in sorted(values)},
                    "verified_on": None if verified_on is None else verified_on.isoformat(),
                    "verification_source": source,
                },
                client_ip=client_ip,
            )
        return _view(row, label)

    async def clear_override(
        self,
        provider: Provider,
        *,
        account_id: UUID | None = None,
        fields: Collection[str] | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> CapabilityOverride | None:
        """Drop some fields of an override, or all of it. Returns what remains, if anything."""
        if fields is not None:
            _check_fields(fields)
        now = self.clock()
        async with self.db.transaction() as session:
            label = await self._lock(session, provider, account_id)
            row = await self._row(session, provider, account_id)
            if row is None:
                return None
            stored = row.capabilities
            removed = sorted(stored if fields is None else stored.keys() & set(fields))
            if not removed:
                return _view(row, label)
            remaining = {name: value for name, value in stored.items() if name not in removed}
            if remaining:
                row.capabilities = remaining
                stamp_updated(row, now)
            else:
                await session.delete(row)
            add_audit(
                session,
                actor=actor,
                action="provider_capability.clear",
                entity_type=ENTITY,
                entity_id=row.id,
                details={**_scope_details(provider, account_id), "fields": removed},
                client_ip=client_ip,
            )
        return _view(row, label) if remaining else None

    @staticmethod
    async def _lock(session: AsyncSession, provider: Provider, account_id: UUID | None) -> str | None:
        """Serialize override changes per provider; returns the account label for account overrides."""
        await session.execute(select(func.pg_advisory_xact_lock(func.hashtext(f"{ENTITY}:{provider.value}"))))
        if account_id is None:
            return None
        # FOR SHARE keeps the account from being deleted before the override is written.
        account = await session.get(ProviderAccountRow, account_id, with_for_update={"read": True})
        if account is None:
            raise NotFoundError(
                f"Provider account {account_id} does not exist", code="provider_account_not_found"
            )
        if account.provider is not provider:
            raise ValidationFailedError(
                f"Account '{account.label}' is a {account.provider.value} account, not {provider.value}",
                code="wrong_provider",
            )
        return account.label

    @staticmethod
    async def _row(
        session: AsyncSession, provider: Provider, account_id: UUID | None
    ) -> ProviderCapabilityRow | None:
        column = ProviderCapabilityRow.account_id
        stmt = select(ProviderCapabilityRow).where(
            ProviderCapabilityRow.provider == provider,
            column.is_(None) if account_id is None else column == account_id,
        )
        return await session.scalar(stmt.with_for_update())


async def _select(session: AsyncSession, *conditions: ColumnElement[bool]) -> list[CapabilityOverride]:
    stmt = (
        select(ProviderCapabilityRow, ProviderAccountRow.label)
        .outerjoin(ProviderAccountRow, ProviderAccountRow.id == ProviderCapabilityRow.account_id)
        .where(*conditions)
        # Provider-wide rows first, so ``effective`` applies them before account rows.
        .order_by(
            ProviderCapabilityRow.provider,
            ProviderCapabilityRow.account_id.is_not(None),
            func.lower(ProviderAccountRow.label),
        )
    )
    return [_view(row, label) for row, label in (await session.execute(stmt)).all()]


def _view(row: ProviderCapabilityRow, label: str | None) -> CapabilityOverride:
    return CapabilityOverride(
        id=row.id,
        provider=row.provider,
        account_id=row.account_id,
        account_label=label,
        values=dict(row.capabilities),
        verified_on=row.verified_on,
        verification_source=row.verification_source,
        updated_at=row.updated_at,
    )


def _check_fields(fields: Collection[str]) -> None:
    if not fields:
        raise ValidationFailedError("Name at least one capability field", code=INVALID)
    unknown = sorted(set(fields) - set(OVERRIDABLE_FIELDS))
    if unknown:
        raise ValidationFailedError(
            f"These capability fields cannot be overridden: {', '.join(unknown)}. "
            f"Overridable fields: {', '.join(OVERRIDABLE_FIELDS)}",
            code=INVALID,
        )


def _normalized(provider: Provider, values: Mapping[str, Any]) -> dict[str, Any]:
    """``values`` checked against the field types, in their canonical JSON form."""
    try:
        caps = ProviderCapabilities.model_validate(
            {**default_capabilities(provider).model_dump(mode="json"), **values}
        )
    except ValidationError as exc:
        raise ValidationFailedError(f"Invalid capability values: {_describe(exc)}", code=INVALID) from None
    dumped = caps.model_dump(mode="json")
    return {name: dumped[name] for name in values}


def _scope_details(provider: Provider, account_id: UUID | None) -> dict[str, Any]:
    return {"provider": provider.value, "account_id": None if account_id is None else str(account_id)}


def _describe(exc: ValidationError) -> str:
    """Field paths and messages only: the rejected input is not echoed."""
    errors = exc.errors(include_url=False, include_input=False)
    return "; ".join(f"{'.'.join(str(part) for part in e['loc'])}: {e['msg']}" for e in errors[:5])
