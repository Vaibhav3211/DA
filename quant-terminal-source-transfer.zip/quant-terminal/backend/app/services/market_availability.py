"""Which markets the platform can stream, from the providers' effective capabilities (EXT-6).

A market is available when a provider streams every venue (exchange and segment) it lists. Markets no
provider adapter covers are unavailable, with the milestone planned to add one, and nothing stands in for
them: spot XAUUSD is not MCX gold, and spot Forex is not an NSE currency future. An exchange without a
trading calendar is noted, because its sessions show as UNKNOWN. Whether an account is connected is shown
with the providers.
"""

from __future__ import annotations

from collections.abc import Collection, Iterable
from dataclasses import dataclass
from typing import Final

from app.domain.enums import Exchange, MarketRegion, Provider, Segment
from app.domain.models import ProviderCapabilities
from app.domain.models.base import DomainModel


class MarketAvailability(DomainModel):
    key: str
    name: str
    region: MarketRegion | None  # None: no market region exists for it yet
    available: bool
    providers: tuple[Provider, ...]  # those that stream every venue of the market
    reason: str
    planned_milestone: str | None  # for an unavailable market, the milestone planned to add a provider
    notes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Market:
    key: str
    name: str
    region: MarketRegion | None
    venues: tuple[tuple[Exchange, Segment], ...] = ()  # none: no exchange the platform knows lists it
    missing: str = ""  # for a market without venues: what no provider adapter streams yet
    milestone: str | None = None
    notes: tuple[str, ...] = ()


MARKETS: Final[tuple[Market, ...]] = (
    Market(
        "india-equity",
        "NSE and BSE cash, F&O and indices",
        MarketRegion.INDIA,
        venues=tuple(
            (exchange, segment)
            for exchange in (Exchange.NSE, Exchange.BSE)
            for segment in (Segment.CASH, Segment.FNO, Segment.INDEX)
        ),
    ),
    Market(
        "mcx-commodities",
        "MCX commodity contracts",
        MarketRegion.INDIA,
        venues=((Exchange.MCX, Segment.COMMODITY),),
        notes=(
            "They include exchange-traded gold and silver contracts, priced in rupees: these are not the "
            "spot XAUUSD and XAGUSD prices.",
        ),
    ),
    Market(
        "nse-currency",
        "NSE currency derivatives",
        MarketRegion.INDIA,
        venues=((Exchange.NSE, Segment.CURRENCY),),
        notes=(
            "These are exchange-traded futures and options on rupee pairs such as USDINR, not spot Forex.",
        ),
    ),
    Market("crypto", "Crypto", MarketRegion.CRYPTO, missing="crypto", milestone="M11"),
    Market("spot-forex", "Spot Forex", MarketRegion.FOREX, missing="spot Forex", milestone="M12"),
    Market(
        "spot-metals",
        "Spot metals (XAUUSD, XAGUSD)",
        None,
        missing="spot metals",
        milestone="M13",
        notes=(
            "MCX gold and silver are exchange-traded contracts, listed with MCX: they are not spot prices.",
        ),
    ),
)


def market_availability(
    capabilities: Iterable[ProviderCapabilities], *, calendars: Collection[Exchange]
) -> tuple[MarketAvailability, ...]:
    """Each market with the providers that stream it; ``calendars`` are the exchanges with a trading
    calendar."""
    providers = tuple(capabilities)
    return tuple(_availability(market, providers, calendars) for market in MARKETS)


def _availability(
    market: Market, providers: tuple[ProviderCapabilities, ...], calendars: Collection[Exchange]
) -> MarketAvailability:
    if not market.venues:
        return MarketAvailability(
            key=market.key,
            name=market.name,
            region=market.region,
            available=False,
            providers=(),
            reason=f"No provider adapter streams {market.missing} yet",
            planned_milestone=market.milestone,
            notes=market.notes,
        )
    covering = [caps for caps in providers if all(_streams(caps, venue) for venue in market.venues)]
    exchanges = dict.fromkeys(exchange for exchange, _segment in market.venues)
    unknown = [
        f"{exchange.value} has no trading calendar yet, so its sessions show as UNKNOWN"
        for exchange in exchanges
        if exchange not in calendars
    ]
    if covering:
        reason = f"Streamed by {_all(caps.display_name for caps in covering)}"
    else:
        venues = _all(f"{exchange.value} {segment.value}" for exchange, segment in market.venues)
        reason = f"No provider's capabilities include streaming {venues}"
    return MarketAvailability(
        key=market.key,
        name=market.name,
        region=market.region,
        available=bool(covering),
        providers=tuple(caps.provider for caps in covering),
        reason=reason,
        planned_milestone=None,
        notes=(*market.notes, *unknown),
    )


def _streams(capabilities: ProviderCapabilities, venue: tuple[Exchange, Segment]) -> bool:
    exchange, segment = venue
    return capabilities.streaming and exchange in capabilities.exchanges and segment in capabilities.segments


def _all(names: Iterable[str]) -> str:
    listed = list(names)
    if len(listed) < 2:
        return "".join(listed)
    return f"{', '.join(listed[:-1])} and {listed[-1]}"
