"""Strategy run records: one row per execution of a deployment in the strategy worker.

The worker opens a run (STARTING) before it warms the strategy up and marks it RUNNING once the strategy
is ready. While it runs, the worker records its counters and heartbeat (CIRCUIT_OPEN while the plugin's
circuit is open), then closes it STOPPED or FAILED. A worker that dies leaves its runs open:
``close_abandoned`` fails the runs whose heartbeat stopped.
"""

from __future__ import annotations

from collections.abc import Callable, Collection, Mapping
from datetime import datetime, timedelta
from typing import Any, Final
from uuid import UUID

from sqlalchemy import func, update

from app.core.clock import utc_now
from app.domain.enums import StrategyRunStatus
from app.persistence.database import Database
from app.persistence.models import StrategyRunRow
from app.services.strategies import DeploymentView
from app.strategies.runtime import RunStats, WarmupProgress

OPEN_RUN_STATUSES: Final = (
    StrategyRunStatus.STARTING,
    StrategyRunStatus.RUNNING,
    StrategyRunStatus.CIRCUIT_OPEN,
)
_ERROR_LENGTH: Final = 500


class RunStore:
    def __init__(self, db: Database, *, clock: Callable[[], datetime] = utc_now) -> None:
        self.db = db
        self.clock = clock

    async def open(
        self, deployment: DeploymentView, *, worker_id: str, input_context: Mapping[str, Any]
    ) -> UUID:
        """A STARTING run of the deployment with its current version and configuration snapshot."""
        now = self.clock()
        async with self.db.transaction() as session:
            row = StrategyRunRow(
                deployment_id=deployment.id,
                strategy_id=deployment.strategy_id,
                strategy_version=deployment.strategy_version,
                configuration_id=deployment.configuration_id,
                config_snapshot=deployment.config,
                config_hash=deployment.config_hash,
                input_context=dict(input_context),
                status=StrategyRunStatus.STARTING,
                worker_id=worker_id[:120],
                started_at=now,
                heartbeat_at=now,
            )
            session.add(row)
            await session.flush()
            return row.id

    async def mark_running(
        self, run_id: UUID, *, context: Mapping[str, Any], warmup: WarmupProgress | None = None
    ) -> bool:
        """STARTING -> RUNNING, adding ``context`` (e.g. how the warm-up went) to the input context."""
        async with self.db.transaction() as session:
            row = await session.get(StrategyRunRow, run_id, with_for_update=True)
            if row is None or row.status is not StrategyRunStatus.STARTING:
                return False
            row.status = StrategyRunStatus.RUNNING
            row.heartbeat_at = self.clock()
            row.input_context = {**row.input_context, **context}
            if warmup is not None:
                row.instruments_warming, row.warmup_remaining = _warmup_values(warmup)
            return True

    async def record(
        self, run_id: UUID, stats: RunStats, *, circuit_open: bool, warmup: WarmupProgress | None = None
    ) -> bool:
        """Store an open run's counters, warm-up progress and heartbeat; False when the run is no longer
        open (it was closed as abandoned or deleted with its deployment)."""
        status = StrategyRunStatus.CIRCUIT_OPEN if circuit_open else StrategyRunStatus.RUNNING
        return await self._update(run_id, stats, status=status, stopped=False, warmup=warmup)

    async def close(
        self,
        run_id: UUID,
        status: StrategyRunStatus,
        stats: RunStats | None = None,
        *,
        error: str | None = None,
    ) -> bool:
        """Close an open run as STOPPED or FAILED; ``error`` replaces the last error the run saw."""
        if status in OPEN_RUN_STATUSES:
            raise ValueError(f"{status} does not close a run")
        return await self._update(run_id, stats, status=status, stopped=True, error=error)

    async def close_abandoned(self, *, stale_after: timedelta, keep: Collection[UUID] = ()) -> list[UUID]:
        """Fail the open runs (other than ``keep``) whose heartbeat is older than ``stale_after``."""
        now = self.clock()
        r = StrategyRunRow
        stmt = (
            update(r)
            .where(
                r.status.in_(OPEN_RUN_STATUSES),
                func.coalesce(r.heartbeat_at, r.started_at) < now - stale_after,
            )
            .values(
                status=StrategyRunStatus.FAILED,
                stopped_at=now,
                last_error="abandoned: its worker stopped reporting",
            )
            .returning(r.id)
            .execution_options(synchronize_session=False)
        )
        if keep:
            stmt = stmt.where(r.id.not_in(list(keep)))
        async with self.db.transaction() as session:
            return list(await session.scalars(stmt))

    async def _update(
        self,
        run_id: UUID,
        stats: RunStats | None,
        *,
        status: StrategyRunStatus,
        stopped: bool,
        error: str | None = None,
        warmup: WarmupProgress | None = None,
    ) -> bool:
        now = self.clock()
        r = StrategyRunRow
        values: dict[str, Any] = {"status": status, "heartbeat_at": now}
        if stopped:
            values["stopped_at"] = now
        if warmup is not None:
            values["instruments_warming"], values["warmup_remaining"] = _warmup_values(warmup)
        if stats is not None:
            values |= {
                "candles_processed": stats.candles,
                "events_processed": stats.events,
                "signals_emitted": stats.signals,
                "failures": stats.failures,
                "timeouts": stats.timeouts,
                "last_error": _clip(stats.last_error),
                "circuit_opened_at": stats.circuit_opened_at,
            }
        if error is not None:
            values["last_error"] = _clip(error)
        stmt = (
            update(r)
            .where(r.id == run_id, r.status.in_(OPEN_RUN_STATUSES))
            .values(values)
            .returning(r.id)
            .execution_options(synchronize_session=False)
        )
        async with self.db.transaction() as session:
            return await session.scalar(stmt) is not None


def _clip(error: str | None) -> str | None:
    return None if error is None else error[:_ERROR_LENGTH]


def _warmup_values(warmup: WarmupProgress) -> tuple[int, dict[str, int]]:
    ordered = sorted(warmup.remaining.items(), key=lambda item: item[0].seconds)
    return warmup.instruments, {interval.value: count for interval, count in ordered}
