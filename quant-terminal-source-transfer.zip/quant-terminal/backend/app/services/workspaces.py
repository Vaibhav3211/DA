"""Workspace universes: the instruments each workspace streams, and the provider each comes from.

Every instrument in a workspace names its source provider and may pin one of the provider's accounts;
unpinned instruments follow the provider's enabled account. The source is chosen explicitly when an
instrument is added and changes only when it is added again with another source. The platform never
falls back to another provider (``app.market_data.subscriptions``), and each change is audited with
the source it replaced.

A workspace's ``settings`` say which instruments it takes: ``exchanges``; ``segments`` and
``instrument_types`` (absent or empty: any); and, for derivatives, ``underlying_kind`` (INDEX or STOCK)
with the ``index_underlyings`` that tell the two apart. Values the platform does not know are ignored.
A workspace without exchanges takes nothing (no market-data provider serves Forex or Crypto yet), so it
can be neither enabled nor given instruments.

Changes are all or nothing: when one instrument cannot be added or removed, none is, and the error
lists every problem. After a change the market-data workers are asked to re-plan their subscriptions.
"""

from __future__ import annotations

from collections.abc import Callable, Collection, Mapping, Sequence
from datetime import datetime
from enum import StrEnum
from typing import Any, Final, NamedTuple, Self
from uuid import UUID

from sqlalchemy import delete, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.container import Container
from app.core.clock import utc_now
from app.core.errors import NotFoundError, ValidationFailedError
from app.domain.enums import (
    Exchange,
    InstrumentType,
    MarketRegion,
    Provider,
    Segment,
    SubscriptionMode,
    WorkspaceKind,
)
from app.domain.events import CommandType, WorkerCommand
from app.domain.models import Instrument
from app.domain.models.base import DomainModel, UtcDatetime
from app.market_data.instruments.canonical import normalize_symbol
from app.market_data.subscriptions import (
    Skipped,
    SkipReason,
    StreamAccount,
    SubscriptionPlan,
    SubscriptionPlanner,
)
from app.persistence.database import Database
from app.persistence.models import (
    InstrumentRow,
    ProviderAccountRow,
    WorkspaceInstrumentRow,
    WorkspaceRow,
)
from app.persistence.models.common import stamp_updated
from app.providers.base import unsupported_reason
from app.services.audit import add_audit
from app.services.capabilities import CapabilityService
from app.services.instruments import InstrumentService
from app.services.provider_accounts import publish_command
from app.streaming.redis_bus import RedisBus

ENTITY: Final = "workspace"
MAX_BATCH: Final = 1000
TAKES_NOTHING: Final = "no market-data provider serves it yet"
INACTIVE: Final = "it is inactive (expired or no longer listed)"
NOT_IN_PLAN: Final = "it is not in the current plan; show the workspace again"
_NOT_FOUND: Final = "workspace_not_found"
_UNAVAILABLE: Final = "workspace_unavailable"
_INVALID: Final = "workspace_instruments_invalid"
_REJECTED: Final = "workspace_instruments_rejected"
_MODE_UNSUPPORTED: Final = "subscription_mode_unsupported"
_ACCOUNT_MISMATCH: Final = "workspace_account_mismatch"
_SHOWN_PROBLEMS: Final = 10


class UnderlyingKind(StrEnum):
    INDEX = "INDEX"  # derivatives of the workspace's index underlyings
    STOCK = "STOCK"  # derivatives of anything else


class UniverseRules(DomainModel):
    """Which instruments a workspace takes, read from its settings."""

    exchanges: tuple[Exchange, ...] = ()
    segments: tuple[Segment, ...] = ()  # empty: any
    instrument_types: tuple[InstrumentType, ...] = ()  # empty: any
    underlying_kind: UnderlyingKind | None = None  # None: no rule on underlyings
    index_underlyings: tuple[str, ...] = ()

    @classmethod
    def from_settings(cls, settings: object) -> Self:
        values: Mapping[Any, Any] = settings if isinstance(settings, Mapping) else {}
        return cls(
            exchanges=_members(Exchange, values.get("exchanges")),
            segments=_members(Segment, values.get("segments")),
            instrument_types=_members(InstrumentType, values.get("instrument_types")),
            underlying_kind=_member(UnderlyingKind, values.get("underlying_kind")),
            index_underlyings=_words(values.get("index_underlyings")),
        )

    @property
    def takes_instruments(self) -> bool:
        return bool(self.exchanges)

    def problem(self, instrument: Instrument) -> str | None:
        """Why the workspace does not take ``instrument``, or None when it does."""
        if not self.exchanges:
            return f"the workspace takes no instruments: {TAKES_NOTHING}"
        if instrument.exchange not in self.exchanges:
            return _not_taken("exchange", instrument.exchange, self.exchanges)
        if self.segments and instrument.segment not in self.segments:
            return _not_taken("segment", instrument.segment, self.segments)
        if self.instrument_types and instrument.instrument_type not in self.instrument_types:
            return _not_taken("type", instrument.instrument_type, self.instrument_types)
        if self.underlying_kind is None:
            return None
        if instrument.underlying is None:
            return "it has no underlying"
        underlying = normalize_symbol(instrument.underlying)
        is_index = underlying in self.index_underlyings
        if self.underlying_kind is UnderlyingKind.INDEX and not is_index:
            return (
                f"its underlying {underlying} is not an index this workspace takes "
                f"({_listed(self.index_underlyings)})"
            )
        if self.underlying_kind is UnderlyingKind.STOCK and is_index:
            return f"its underlying {underlying} is an index; this workspace takes stock derivatives"
        return None


class WorkspaceView(DomainModel):
    id: UUID
    slug: str
    name: str
    market_region: MarketRegion
    kind: WorkspaceKind
    description: str | None
    is_enabled: bool
    sort_order: int
    settings: dict[str, Any]
    accepts: UniverseRules
    instrument_count: int
    updated_at: UtcDatetime


class AccountRef(DomainModel):
    id: UUID
    label: str


class EntryStatus(StrEnum):
    PLANNED = "PLANNED"  # an enabled account of its provider is to stream it
    SKIPPED = "SKIPPED"  # nothing streams it: see ``detail``
    WORKSPACE_DISABLED = "WORKSPACE_DISABLED"  # the workspace does not drive subscriptions


class UniverseEntry(DomainModel):
    instrument: Instrument
    provider: Provider
    account: AccountRef | None  # the pinned account; None follows the provider's enabled account
    mode: SubscriptionMode
    added_at: UtcDatetime
    added_by: str | None
    status: EntryStatus
    streamed_by: AccountRef | None = None  # PLANNED: the account whose subscriptions include it
    skip_reason: SkipReason | None = None  # SKIPPED: None when the plan has not caught up yet
    detail: str | None = None


class Universe(DomainModel):
    workspace: WorkspaceView
    entries: tuple[UniverseEntry, ...]  # oldest first


class PreviousSource(DomainModel):
    """Where an instrument came from before it was added again with another source."""

    instrument: Instrument
    provider: Provider
    account: AccountRef | None
    mode: SubscriptionMode


class UniverseChange(DomainModel):
    workspace: WorkspaceView
    added: tuple[Instrument, ...] = ()
    changed: tuple[PreviousSource, ...] = ()  # the instruments whose source changed, as they were
    unchanged: tuple[Instrument, ...] = ()  # already in the workspace with this source
    removed: tuple[Instrument, ...] = ()
    absent: tuple[Instrument, ...] = ()  # asked to be removed, but not in the workspace
    published: bool | None = None  # whether the workers were told; None when nothing changed


class WorkspaceToggle(DomainModel):
    workspace: WorkspaceView
    changed: bool
    published: bool | None  # whether the workers were told; None when they had nothing to re-plan


class InstrumentsRejectedError(ValidationFailedError):
    """Instruments that cannot be added to (or removed from) a workspace. Nothing was changed."""

    def __init__(self, workspace: str, action: str, problems: Sequence[tuple[str, str]]) -> None:
        self.workspace = workspace
        self.action = action  # "added to" or "removed from"
        self.problems = tuple(problems)  # (instrument key, reason), in the order given
        listed = "; ".join(f"{key}: {reason}" for key, reason in self.problems[:_SHOWN_PROBLEMS])
        if len(self.problems) > _SHOWN_PROBLEMS:
            listed += f"; and {len(self.problems) - _SHOWN_PROBLEMS} more"
        super().__init__(
            f"Nothing was {action} workspace '{workspace}': {listed}",
            code=_REJECTED,
            details={
                "workspace": workspace,
                "problems": [{"instrument": key, "reason": reason} for key, reason in self.problems],
            },
        )


class _Row(NamedTuple):
    entry: WorkspaceInstrumentRow
    instrument: InstrumentRow
    label: str | None  # of the pinned account


class WorkspaceService:
    def __init__(self, instruments: InstrumentService, capabilities: CapabilityService) -> None:
        self.instruments = instruments
        self.capabilities = capabilities
        self._planner = SubscriptionPlanner(instruments.settings, instruments, capabilities)

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(
            InstrumentService.from_container(container, clock=clock),
            CapabilityService.from_container(container, clock=clock),
        )

    @property
    def db(self) -> Database:
        return self.instruments.db

    @property
    def bus(self) -> RedisBus:
        return self.instruments.bus

    @property
    def clock(self) -> Callable[[], datetime]:
        return self.instruments.clock

    async def list_workspaces(self) -> list[WorkspaceView]:
        w, wi = WorkspaceRow, WorkspaceInstrumentRow
        counts = (
            select(wi.workspace_id, func.count().label("instruments")).group_by(wi.workspace_id).subquery()
        )
        async with self.db.session() as session:
            result = await session.execute(
                select(w, func.coalesce(counts.c.instruments, 0))
                .outerjoin(counts, counts.c.workspace_id == w.id)
                .order_by(w.sort_order, w.slug)
            )
            return [_view(row, count) for row, count in result]

    async def universe(self, ref: str) -> Universe:
        """The workspace's instruments and, while it is enabled, what streams each of them."""
        async with self.db.session() as session:
            workspace = await _find(session, ref)
            rows = await _rows(session, workspace.id)
        plan = await self._planner.plan() if workspace.is_enabled and rows else None
        return Universe(workspace=_view(workspace, len(rows)), entries=_entries(rows, plan))

    async def set_enabled(
        self, ref: str, enabled: bool, *, actor: str, client_ip: str | None = None
    ) -> WorkspaceToggle:
        """Enabled workspaces drive the subscriptions of the market-data workers."""
        async with self.db.transaction() as session:
            workspace = await _find(session, ref, lock=True)
            count = await _count(session, workspace.id)
            changed = workspace.is_enabled != enabled
            if changed:
                if enabled and not UniverseRules.from_settings(workspace.settings).takes_instruments:
                    raise ValidationFailedError(
                        f"Workspace '{workspace.slug}' cannot be enabled: {TAKES_NOTHING}", code=_UNAVAILABLE
                    )
                workspace.is_enabled = enabled
                stamp_updated(workspace, self.clock())
                add_audit(
                    session,
                    actor=actor,
                    action="workspace.enable" if enabled else "workspace.disable",
                    entity_type=ENTITY,
                    entity_id=workspace.id,
                    details={"slug": workspace.slug, "instruments": count},
                    client_ip=client_ip,
                )
            view = _view(workspace, count)
        published = await self._publish(view.slug, actor) if changed and count else None
        return WorkspaceToggle(workspace=view, changed=changed, published=published)

    async def add_instruments(
        self,
        ref: str,
        instrument_refs: Sequence[str],
        provider: Provider,
        *,
        account_id: UUID | None = None,
        mode: SubscriptionMode = SubscriptionMode.QUOTE,
        actor: str,
        client_ip: str | None = None,
    ) -> UniverseChange:
        """Stream these instruments (canonical keys or ids) in the workspace from ``provider``, through
        ``account_id`` when given, else through the provider's enabled account.

        Instruments already in the workspace with another source are switched to this one. Raises
        ``InstrumentsRejectedError``, changing nothing, when any instrument is unknown, inactive, not
        taken by the workspace, not listed by the provider or not streamable by it."""
        refs = _check_refs(instrument_refs)
        async with self.db.session() as session:
            workspace = await _find(session, ref)
            rules = UniverseRules.from_settings(workspace.settings)
            if not rules.takes_instruments:
                raise ValidationFailedError(
                    f"Workspace '{workspace.slug}' takes no instruments: {TAKES_NOTHING}", code=_UNAVAILABLE
                )
            if account_id is not None:
                await _check_account(session, account_id, provider)
            found = await _lookup(session, refs)
        capabilities = await self.capabilities.effective(provider, account_id)
        if mode not in capabilities.subscription_modes:
            supported = _listed(capabilities.subscription_modes)
            raise ValidationFailedError(
                f"{capabilities.display_name} does not support {mode.value} subscriptions ({supported})",
                code=_MODE_UNSUPPORTED,
            )
        problems: dict[str, str] = {}
        candidates: list[InstrumentRow] = []
        for key, row in found:
            if row is None:
                problems[key] = "no such instrument"
            elif (reason := _eligibility(row, rules)) is not None:
                problems[key] = reason
            else:
                candidates.append(row)
        resolved = await self.instruments.resolve([row.id for row in candidates], provider, mode=mode)
        listed = {item.instrument_id: item for item in resolved.found}
        for row in candidates:
            item = listed.get(row.id)
            if item is None:
                problems[row.canonical_key] = f"{capabilities.display_name} does not list it"
            elif (reason := unsupported_reason(capabilities, item)) is not None:
                problems[row.canonical_key] = reason
        if problems:
            ordered = [(key, problems[key]) for key, _ in found if key in problems]
            raise InstrumentsRejectedError(workspace.slug, "added to", ordered)

        now = self.clock()
        added: list[Instrument] = []
        changed: list[PreviousSource] = []
        unchanged: list[Instrument] = []
        async with self.db.transaction() as session:
            workspace = await _find(session, workspace.id, lock=True)
            if account_id is not None:
                await _check_account(session, account_id, provider, lock=True)
            ids = [candidate.id for candidate in candidates]
            existing = {row.entry.instrument_id: row for row in await _rows(session, workspace.id, ids)}
            for candidate in candidates:
                instrument = _instrument(candidate)
                current = existing.get(candidate.id)
                if current is None:
                    session.add(
                        WorkspaceInstrumentRow(
                            workspace_id=workspace.id,
                            instrument_id=candidate.id,
                            provider=provider,
                            account_id=account_id,
                            subscription_mode=mode,
                            added_at=now,
                            added_by=actor[:64],
                        )
                    )
                    added.append(instrument)
                    continue
                entry = current.entry
                if (entry.provider, entry.account_id, entry.subscription_mode) == (
                    provider,
                    account_id,
                    mode,
                ):
                    unchanged.append(instrument)
                    continue
                changed.append(
                    PreviousSource(
                        instrument=instrument,
                        provider=entry.provider,
                        account=_account(entry.account_id, current.label),
                        mode=entry.subscription_mode,
                    )
                )
                entry.provider, entry.account_id, entry.subscription_mode = provider, account_id, mode
            if added or changed:
                add_audit(
                    session,
                    actor=actor,
                    action="workspace.instruments.add",
                    entity_type=ENTITY,
                    entity_id=workspace.id,
                    details={
                        "slug": workspace.slug,
                        "provider": provider.value,
                        "account_id": _text(account_id),
                        "mode": mode.value,
                        "added": [instrument.canonical_key for instrument in added],
                        "changed": [_source_details(previous) for previous in changed],
                        "unchanged": len(unchanged),
                    },
                    client_ip=client_ip,
                )
                await session.flush()
            view = _view(workspace, await _count(session, workspace.id))
        published = await self._publish(view.slug, actor) if added or changed else None
        return UniverseChange(
            workspace=view,
            added=tuple(added),
            changed=tuple(changed),
            unchanged=tuple(unchanged),
            published=published,
        )

    async def remove_instruments(
        self, ref: str, instrument_refs: Sequence[str], *, actor: str, client_ip: str | None = None
    ) -> UniverseChange:
        """Stop streaming these instruments (canonical keys or ids) in the workspace.

        Raises ``InstrumentsRejectedError``, changing nothing, when any of them is unknown."""
        refs = _check_refs(instrument_refs)
        wi = WorkspaceInstrumentRow
        async with self.db.transaction() as session:
            workspace = await _find(session, ref, lock=True)
            found = await _lookup(session, refs)
            unknown = [(key, "no such instrument") for key, row in found if row is None]
            if unknown:
                raise InstrumentsRejectedError(workspace.slug, "removed from", unknown)
            instruments = [_instrument(row) for _, row in found if row is not None]
            sources = {
                row.entry.instrument_id: row
                for row in await _rows(session, workspace.id, [item.id for item in instruments])
            }
            removed = [item for item in instruments if item.id in sources]
            absent = [item for item in instruments if item.id not in sources]
            if removed:
                await session.execute(
                    delete(wi)
                    .where(wi.workspace_id == workspace.id, wi.instrument_id.in_(list(sources)))
                    .execution_options(synchronize_session=False)
                )
                add_audit(
                    session,
                    actor=actor,
                    action="workspace.instruments.remove",
                    entity_type=ENTITY,
                    entity_id=workspace.id,
                    details={
                        "slug": workspace.slug,
                        "removed": [_source_details(_previous(item, sources[item.id])) for item in removed],
                    },
                    client_ip=client_ip,
                )
            view = _view(workspace, await _count(session, workspace.id))
        published = await self._publish(view.slug, actor) if removed else None
        return UniverseChange(
            workspace=view, removed=tuple(removed), absent=tuple(absent), published=published
        )

    async def _publish(self, slug: str, actor: str) -> bool:
        command = WorkerCommand(
            type=CommandType.REFRESH_SUBSCRIPTIONS, params={"workspace": slug}, issued_by=actor
        )
        return await publish_command(self.bus, command)


def _items(value: object) -> Sequence[object]:
    """A setting that should be a list; a lone string counts as a list of one."""
    if isinstance(value, str):
        return (value,)
    return value if isinstance(value, list | tuple) else ()


def _member[E: StrEnum](enum: type[E], value: object) -> E | None:
    if not isinstance(value, str):
        return None
    try:
        return enum(normalize_symbol(value))
    except ValueError:
        return None


def _members[E: StrEnum](enum: type[E], value: object) -> tuple[E, ...]:
    """The known members a setting names, in order and without repeats."""
    found = (_member(enum, item) for item in _items(value))
    return tuple(dict.fromkeys(member for member in found if member is not None))


def _words(value: object) -> tuple[str, ...]:
    words = (normalize_symbol(item) for item in _items(value) if isinstance(item, str))
    return tuple(dict.fromkeys(word for word in words if word))


def _listed(items: Sequence[str]) -> str:
    return ", ".join(items) or "none"


def _not_taken(what: str, value: str, allowed: Sequence[str]) -> str:
    return f"its {what} {value} is not one this workspace takes ({_listed(allowed)})"


def _check_refs(refs: Sequence[str]) -> list[str]:
    texts = [ref.strip() for ref in refs]
    if not texts:
        raise ValidationFailedError("Name at least one instrument", code=_INVALID)
    if not all(texts):
        raise ValidationFailedError("An instrument key cannot be blank", code=_INVALID)
    if len(texts) > MAX_BATCH:
        raise ValidationFailedError(f"At most {MAX_BATCH} instruments can be changed at once", code=_INVALID)
    return texts


def _parse_ref(text: str) -> UUID | str:
    try:
        return UUID(text)
    except ValueError:
        return normalize_symbol(text)


async def _find(session: AsyncSession, ref: UUID | str, *, lock: bool = False) -> WorkspaceRow:
    """A workspace by id or slug."""
    if isinstance(ref, str):
        text = ref.strip()
        try:
            ref = UUID(text)
        except ValueError:
            stmt = select(WorkspaceRow).where(WorkspaceRow.slug == text.lower())
            missing = f"No workspace has the slug '{text}'"
        else:
            stmt = select(WorkspaceRow).where(WorkspaceRow.id == ref)
            missing = f"No workspace has the id {ref}"
    else:
        stmt = select(WorkspaceRow).where(WorkspaceRow.id == ref)
        missing = f"No workspace has the id {ref}"
    row = await session.scalar(stmt.with_for_update() if lock else stmt)
    if row is None:
        raise NotFoundError(missing, code=_NOT_FOUND)
    return row


async def find_workspace(session: AsyncSession, ref: UUID | str, *, lock: bool = False) -> WorkspaceRow:
    """A workspace by id or slug; ``NotFoundError`` when there is none."""
    return await _find(session, ref, lock=lock)


async def _count(session: AsyncSession, workspace_id: UUID) -> int:
    wi = WorkspaceInstrumentRow
    count = await session.scalar(select(func.count()).select_from(wi).where(wi.workspace_id == workspace_id))
    return count or 0


async def _check_account(
    session: AsyncSession, account_id: UUID, provider: Provider, *, lock: bool = False
) -> None:
    """The account must exist and belong to ``provider``; ``lock`` keeps it until the commit."""
    a = ProviderAccountRow
    stmt = select(a.provider, a.label).where(a.id == account_id)
    found = (await session.execute(stmt.with_for_update(read=True) if lock else stmt)).first()
    if found is None:
        raise NotFoundError(f"No provider account has the id {account_id}", code="provider_account_not_found")
    if found.provider is not provider:
        raise ValidationFailedError(
            f"Account '{found.label}' is a {found.provider.value} account, not {provider.value}",
            code=_ACCOUNT_MISMATCH,
        )


async def _lookup(session: AsyncSession, refs: Sequence[str]) -> list[tuple[str, InstrumentRow | None]]:
    """Each instrument once, in the order first named, keyed by its canonical key; unknown references
    (normalised) with None."""
    i = InstrumentRow
    parsed = [_parse_ref(text) for text in refs]
    ids = [value for value in parsed if isinstance(value, UUID)]
    keys = [value for value in parsed if isinstance(value, str)]
    rows = await session.scalars(select(i).where(or_(i.id.in_(ids), i.canonical_key.in_(keys))))
    by_id = {row.id: row for row in rows}
    by_key = {row.canonical_key: row for row in by_id.values()}
    found: dict[object, tuple[str, InstrumentRow | None]] = {}
    for value in parsed:
        row = by_id.get(value) if isinstance(value, UUID) else by_key.get(value)
        if row is None:
            found.setdefault(value, (str(value), None))
        else:
            found.setdefault(row.id, (row.canonical_key, row))
    return list(found.values())


async def _rows(
    session: AsyncSession, workspace_id: UUID, instrument_ids: Collection[UUID] | None = None
) -> list[_Row]:
    wi, i, a = WorkspaceInstrumentRow, InstrumentRow, ProviderAccountRow
    stmt = (
        select(wi, i, a.label)
        .join(i, i.id == wi.instrument_id)
        .outerjoin(a, a.id == wi.account_id)
        .where(wi.workspace_id == workspace_id)
        .order_by(wi.added_at, i.canonical_key)
    )
    if instrument_ids is not None:
        stmt = stmt.where(wi.instrument_id.in_(instrument_ids))
    result = await session.execute(stmt)
    return [_Row(entry, instrument, label) for entry, instrument, label in result]


def _eligibility(row: InstrumentRow, rules: UniverseRules) -> str | None:
    return INACTIVE if not row.is_active else rules.problem(_instrument(row))


def _instrument(row: InstrumentRow) -> Instrument:
    return Instrument.model_validate(row, from_attributes=True)


def _account(account_id: UUID | None, label: str | None) -> AccountRef | None:
    return None if account_id is None or label is None else AccountRef(id=account_id, label=label)


def _text(value: UUID | None) -> str | None:
    return None if value is None else str(value)


def _previous(instrument: Instrument, row: _Row) -> PreviousSource:
    entry = row.entry
    return PreviousSource(
        instrument=instrument,
        provider=entry.provider,
        account=_account(entry.account_id, row.label),
        mode=entry.subscription_mode,
    )


def _source_details(source: PreviousSource) -> dict[str, Any]:
    return {
        "instrument": source.instrument.canonical_key,
        "provider": source.provider.value,
        "account_id": None if source.account is None else str(source.account.id),
        "mode": source.mode.value,
    }


def _view(row: WorkspaceRow, count: int) -> WorkspaceView:
    settings = row.settings if isinstance(row.settings, dict) else {}
    return WorkspaceView(
        id=row.id,
        slug=row.slug,
        name=row.name,
        market_region=row.market_region,
        kind=row.kind,
        description=row.description,
        is_enabled=row.is_enabled,
        sort_order=row.sort_order,
        settings=settings,
        accepts=UniverseRules.from_settings(settings),
        instrument_count=count,
        updated_at=row.updated_at,
    )


def _entries(rows: Sequence[_Row], plan: SubscriptionPlan | None) -> tuple[UniverseEntry, ...]:
    """Each row with its status in ``plan``; without a plan, the workspace is disabled."""
    streamed: dict[tuple[Provider, UUID], StreamAccount] = {}
    skipped: dict[tuple[Provider, UUID], Skipped] = {}
    if plan is not None:
        for account in plan.accounts:
            for item in account.instruments:
                streamed[(account.account.provider, item.instrument_id)] = account.account
        for missed in plan.skipped:
            skipped.setdefault((missed.provider, missed.instrument_id), missed)
    entries: list[UniverseEntry] = []
    for row in rows:
        entry, instrument = row.entry, _instrument(row.instrument)
        status, streamed_by, reason, detail = EntryStatus.WORKSPACE_DISABLED, None, None, None
        if plan is not None:
            key = (entry.provider, entry.instrument_id)
            if (stream := streamed.get(key)) is not None:
                status, streamed_by = (
                    EntryStatus.PLANNED,
                    AccountRef(id=stream.account_id, label=stream.label),
                )
            elif (skip := skipped.get(key)) is not None:
                status, reason, detail = EntryStatus.SKIPPED, skip.reason, skip.detail
                if reason is SkipReason.NOT_LISTED and not instrument.is_active:
                    detail = INACTIVE
            else:
                status, detail = EntryStatus.SKIPPED, NOT_IN_PLAN
        entries.append(
            UniverseEntry(
                instrument=instrument,
                provider=entry.provider,
                account=_account(entry.account_id, row.label),
                mode=entry.subscription_mode,
                added_at=entry.added_at,
                added_by=entry.added_by,
                status=status,
                streamed_by=streamed_by,
                skip_reason=reason,
                detail=detail,
            )
        )
    return tuple(entries)
