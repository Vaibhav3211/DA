"""Backtest datasets: requesting them, and building them in the backtest worker (M9; see docs/backtesting.md).

A dataset freezes one instrument's candles at one interval over a range of exchange-local dates, taken
from one source:

* PROVIDER_HISTORY: the provider's historical-candle API (Zerodha or Groww). A download uses one of the
  provider's enabled accounts, whose access token must be current, and the provider's plan must include
  the API.
* RECORDED: the closed candles this system built from the provider's live feed (Zerodha or Groww).
* SIMULATED: the closed candles it built from the simulator. Backtests on them are labelled simulated.

A request is checked, queued (PENDING) and audited; asking again while the same request waits or builds
returns that one. The backtest worker (``qt-backtest-worker``) builds the oldest waiting dataset: it
fetches the candles, places them on the exchange calendar (``app.backtest.dataset.build``) and stores
them with their coverage and content SHA (READY), or records why it could not (FAILED). A READY dataset
never changes; a new request for the same dates makes a new dataset.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from collections.abc import Callable, Sequence
from datetime import UTC, date, datetime, time, timedelta
from itertools import batched
from typing import Final, Self
from uuid import UUID

import httpx
from pydantic import Field, ValidationError
from redis.exceptions import RedisError
from sqlalchemy import func, insert, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.backtest.dataset import (
    BuiltDataset,
    DatasetCandle,
    DatasetError,
    SourceCandle,
    build,
    dataset_sha,
    expected_candles,
)
from app.backtest.engine import BacktestError
from app.container import Container
from app.core.clock import utc_now
from app.core.config import Settings
from app.core.errors import AppError, ConflictError, NotFoundError, ValidationFailedError
from app.core.logging import get_logger
from app.domain.enums import (
    CandleInterval,
    DatasetSource,
    DatasetStatus,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
)
from app.domain.models import Instrument
from app.domain.models.backtest import DatasetCoverage
from app.domain.models.base import DomainModel, UtcDatetime
from app.market_data.calendars.service import MarketCalendar
from app.market_data.candles.store import load_range
from app.observability.heartbeat import BACKTEST_WORKER
from app.persistence.database import Database
from app.persistence.models import (
    BacktestDatasetCandleRow,
    BacktestDatasetRow,
    CandleRow,
    InstrumentProviderMappingRow,
    InstrumentRow,
    ProviderAccountRow,
)
from app.persistence.models.common import stamp_updated
from app.providers.base import describe_error
from app.providers.groww.client import GrowwRestClient
from app.providers.history import HISTORY_SUPPORT, History, HistorySupport, download
from app.providers.zerodha.client import KiteRestClient
from app.services.audit import add_audit
from app.services.instruments import find_instrument
from app.services.markets import MarketCalendarCache
from app.services.provider_accounts import ProviderAccountService
from app.streaming.redis_bus import Keys, RedisBus

log = get_logger(__name__)

ENTITY: Final = "backtest_dataset"
MAX_SPAN_DAYS: Final = 7305  # 20 years of dates in one dataset
MAX_ERROR: Final = 500
INSERT_CHUNK: Final = 5000
LIST_LIMIT_MAX: Final = 500
ACTIVE: Final = (DatasetStatus.PENDING, DatasetStatus.BUILDING)
HISTORY_PROVIDERS: Final = (Provider.ZERODHA, Provider.GROWW)
_DERIVATIVES: Final = frozenset({InstrumentType.FUTURE, InstrumentType.OPTION})


class DatasetView(DomainModel):
    """A backtest dataset. ``coverage`` is filled in once it is READY."""

    id: UUID
    instrument_id: UUID
    instrument_key: str
    symbol: str
    exchange: Exchange
    provider: Provider
    account_id: UUID | None  # the account a download used
    source: DatasetSource
    simulated: bool  # simulator candles: backtests on them are labelled simulated
    interval: CandleInterval
    date_from: date  # exchange-local dates, both included
    date_to: date
    status: DatasetStatus
    requested_by: str | None
    worker_id: str | None
    started_at: UtcDatetime | None
    finished_at: UtcDatetime | None
    error: str | None
    candle_count: int
    first_candle_at: UtcDatetime | None
    last_candle_at: UtcDatetime | None
    content_sha: str | None
    coverage: DatasetCoverage | None
    created_at: UtcDatetime
    updated_at: UtcDatetime


class DatasetRequestResult(DomainModel):
    dataset: DatasetView
    created: bool  # False: the same request was already waiting or building


class RecordedSeries(DomainModel):
    """Closed candles recorded from one source at one interval."""

    interval: CandleInterval
    candles: int
    first_candle_at: UtcDatetime
    last_candle_at: UtcDatetime


class AccountChoice(DomainModel):
    account_id: UUID
    label: str
    problem: str | None = None  # why a download cannot use it now


class DatasetSourceOption(DomainModel):
    provider: Provider
    source: DatasetSource
    available: bool
    reason: str | None = None  # why it is unavailable
    intervals: tuple[CandleInterval, ...] = ()  # what it can supply for this instrument
    max_days_per_request: dict[str, int] = Field(default_factory=dict)  # provider history, per interval
    note: str | None = None
    accounts: tuple[AccountChoice, ...] = ()  # provider history: the provider's enabled accounts
    recorded: tuple[RecordedSeries, ...] = ()  # recorded sources: what was recorded


class DatasetSources(DomainModel):
    """Where an instrument's dataset can come from, and the limits on it."""

    instrument_id: UUID
    instrument_key: str
    symbol: str
    exchange: Exchange
    segment: Segment
    today: date  # the exchange-local date: the last date a dataset may cover
    max_candles: int  # BACKTEST_MAX_CANDLES
    max_span_days: int
    options: tuple[DatasetSourceOption, ...]
    worker_problem: str | None  # why queued datasets would wait


class ClaimLostError(Exception):
    """The job is no longer this worker's: it was marked abandoned meanwhile."""


def source_problem(provider: Provider, source: DatasetSource) -> str | None:
    """Why ``source`` cannot come from ``provider``, or None."""
    if source is DatasetSource.SIMULATED:
        return None if provider is Provider.SIMULATOR else "simulated datasets come from the SIMULATOR"
    if provider not in HISTORY_PROVIDERS:
        return f"{source.value} datasets come from ZERODHA or GROWW; use source SIMULATED for the simulator"
    return None


def mapping_problem(
    provider: Provider, instrument: Instrument, mapping: InstrumentProviderMappingRow | None
) -> str | None:
    """Why the provider's history API cannot name the instrument, or None."""
    if mapping is None:
        return (
            f"{instrument.canonical_key} has no active {provider.value} mapping; refresh the "
            f"{provider.value} instrument master"
        )
    if provider is Provider.GROWW and not mapping.provider_metadata.get("groww_symbol"):
        return (
            f"the Groww mapping of {instrument.canonical_key} has no Groww symbol; refresh the Groww "
            "instrument master"
        )
    return None


def local_bounds(
    first_day: date, last_day: date, calendar: MarketCalendar, exchange: Exchange
) -> tuple[datetime, datetime]:
    """The UTC instants of local midnight at the start of ``first_day`` and after ``last_day``."""
    zone = calendar.timezone(exchange)
    start = datetime.combine(first_day, time(), tzinfo=zone).astimezone(UTC)
    end = datetime.combine(last_day + timedelta(days=1), time(), tzinfo=zone).astimezone(UTC)
    return start, end


async def backtest_worker_problem(bus: RedisBus) -> str | None:
    """Why queued datasets and backtests wait; None while the backtest worker's heartbeat is fresh."""
    try:
        beat = await bus.get_json(Keys.worker_heartbeat(BACKTEST_WORKER))
    except (RedisError, OSError) as exc:
        return f"The backtest worker's heartbeat cannot be read from Redis ({type(exc).__name__})"
    if beat is None:
        return "The backtest worker is not running, so queued jobs wait; start qt-backtest-worker"
    return None


def expected_failure(exc: BaseException) -> bool:
    """Whether the exception is one of the failures a job reports as it is (not a crash)."""
    return isinstance(exc, AppError | DatasetError | BacktestError)


def failure_text(exc: BaseException) -> str:
    """What a FAILED job records: the message of an expected failure, else a redacted summary."""
    if isinstance(exc, AppError):
        text = exc.message
    elif expected_failure(exc):
        text = str(exc)
    else:
        text = f"unexpected error ({describe_error(exc)}); see the backtest worker log"
    return text[:MAX_ERROR]


class DatasetService:
    def __init__(
        self,
        db: Database,
        bus: RedisBus,
        settings: Settings,
        accounts: ProviderAccountService,
        calendars: MarketCalendarCache,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self.db = db
        self.bus = bus
        self.settings = settings
        self.accounts = accounts
        self.calendars = calendars
        self._transport = transport
        self.clock = clock

    @classmethod
    def from_container(
        cls,
        container: Container,
        calendars: MarketCalendarCache,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> Self:
        accounts = ProviderAccountService.from_container(container, clock=clock)
        return cls(
            container.db,
            container.bus,
            container.settings,
            accounts,
            calendars,
            transport=transport,
            clock=clock,
        )

    # ---- requests -------------------------------------------------------------------------------

    async def request(
        self,
        instrument: UUID | str,
        *,
        provider: Provider,
        source: DatasetSource,
        interval: CandleInterval,
        date_from: date,
        date_to: date,
        account_id: UUID | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> DatasetRequestResult:
        """Queue a dataset after checking that its source can supply it. Asking again while the same
        request waits or builds returns that one."""
        problem = source_problem(provider, source)
        if problem is not None:
            raise ValidationFailedError(
                f"Cannot build this dataset: {problem}", code="dataset_source_invalid"
            )
        if account_id is not None and source is not DatasetSource.PROVIDER_HISTORY:
            raise ValidationFailedError(
                "Only provider history downloads use an account; recorded candles do not",
                code="dataset_source_invalid",
            )
        calendar, _ = await self.calendars.get()
        now = self.clock()
        async with self.db.session() as session:
            instrument_row = await find_instrument(session, instrument)
            listing = _instrument(instrument_row)
            self._check_dates(calendar, listing, interval, date_from, date_to, now)
            if source is DatasetSource.PROVIDER_HISTORY:
                support = HISTORY_SUPPORT[provider]
                problem = support.problem(listing.segment, interval)
                if problem is None:
                    problem = mapping_problem(
                        provider, listing, await _mapping(session, listing.id, provider)
                    )
                if problem is not None:
                    raise ValidationFailedError(
                        f"Cannot download {listing.canonical_key}: {problem}",
                        code="dataset_source_unavailable",
                    )
                account_id = await _history_account(session, provider, account_id)
            else:
                await self._check_recorded(session, calendar, listing, provider, interval, date_from, date_to)
        if account_id is not None:
            # Refuses a disabled account, or one without a current access token, before queueing.
            await self.accounts.session_credentials(account_id)

        d = BacktestDatasetRow
        key = f"{ENTITY}:{listing.id}:{provider.value}:{source.value}:{interval.value}:{date_from}:{date_to}"
        async with self.db.transaction() as session:
            await session.execute(select(func.pg_advisory_xact_lock(func.hashtext(key))))
            same_account = d.account_id.is_(None) if account_id is None else d.account_id == account_id
            existing = await session.scalar(
                select(d)
                .where(
                    d.instrument_id == listing.id,
                    d.provider == provider,
                    d.source == source,
                    d.interval == interval,
                    d.date_from == date_from,
                    d.date_to == date_to,
                    same_account,
                    d.status.in_(ACTIVE),
                )
                .order_by(d.created_at)
                .limit(1)
            )
            if existing is not None:
                return DatasetRequestResult(dataset=dataset_view(existing, instrument_row), created=False)
            row = BacktestDatasetRow(
                instrument_id=listing.id,
                provider=provider,
                account_id=account_id,
                source=source,
                interval=interval,
                date_from=date_from,
                date_to=date_to,
                status=DatasetStatus.PENDING,
                requested_by=actor[:64],
                candle_count=0,
                coverage={},
                created_at=now,
                updated_at=now,
            )
            session.add(row)
            await session.flush()
            add_audit(
                session,
                actor=actor,
                action="backtest_dataset.request",
                entity_type=ENTITY,
                entity_id=row.id,
                details={
                    "instrument": listing.canonical_key,
                    "provider": provider.value,
                    "source": source.value,
                    "interval": interval.value,
                    "date_from": date_from.isoformat(),
                    "date_to": date_to.isoformat(),
                    "account_id": None if account_id is None else str(account_id),
                },
                client_ip=client_ip,
            )
        return DatasetRequestResult(dataset=dataset_view(row, instrument_row), created=True)

    def _check_dates(
        self,
        calendar: MarketCalendar,
        instrument: Instrument,
        interval: CandleInterval,
        date_from: date,
        date_to: date,
        now: datetime,
    ) -> None:
        today = calendar.local_date(instrument.exchange, now)
        if date_from > date_to:
            raise ValidationFailedError(
                f"The first date ({date_from}) is after the last date ({date_to})",
                code="dataset_dates_invalid",
            )
        if date_to > today:
            raise ValidationFailedError(
                f"The last date ({date_to}) is after today on {instrument.exchange.value} ({today})",
                code="dataset_dates_invalid",
            )
        if (date_to - date_from).days + 1 > MAX_SPAN_DAYS:
            raise ValidationFailedError(
                f"A dataset covers at most {MAX_SPAN_DAYS} dates (20 years)", code="dataset_dates_invalid"
            )
        limit = self.settings.backtest_max_candles
        estimate = expected_candles(
            calendar, instrument.exchange, interval, date_from, date_to, stop_above=limit
        )
        if estimate > limit:
            raise ValidationFailedError(
                f"{date_from} to {date_to} holds more than {limit:,} {interval.value} candles "
                "(BACKTEST_MAX_CANDLES); choose fewer dates or a longer interval",
                code="dataset_too_large",
            )

    async def _check_recorded(
        self,
        session: AsyncSession,
        calendar: MarketCalendar,
        instrument: Instrument,
        provider: Provider,
        interval: CandleInterval,
        date_from: date,
        date_to: date,
    ) -> None:
        start, end = local_bounds(date_from, date_to, calendar, instrument.exchange)
        c = CandleRow
        found = await session.scalar(
            select(c.bucket_start)
            .where(
                c.provider == provider,
                c.instrument_id == instrument.id,
                c.interval == interval,
                c.bucket_start >= start,
                c.bucket_start < end,
                c.bucket_end <= self.clock(),
            )
            .limit(1)
        )
        if found is not None:
            return
        series = (await _recorded(session, instrument.id, self.clock())).get(provider, [])
        shown = "; ".join(
            f"{item.interval.value}: {item.candles} from {item.first_candle_at:%Y-%m-%d} to "
            f"{item.last_candle_at:%Y-%m-%d}"
            for item in series
        )
        raise ValidationFailedError(
            f"No closed {interval.value} candles of {instrument.canonical_key} were recorded from "
            f"{provider.value} between {date_from} and {date_to} (recorded: {shown or 'none'})",
            code="dataset_no_candles",
        )

    # ---- reads ----------------------------------------------------------------------------------

    async def list_datasets(
        self,
        *,
        instrument: UUID | str | None = None,
        interval: CandleInterval | None = None,
        status: DatasetStatus | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[DatasetView]:
        """The newest first."""
        d, i = BacktestDatasetRow, InstrumentRow
        async with self.db.session() as session:
            stmt = select(d, i).join(i, i.id == d.instrument_id)
            if instrument is not None:
                stmt = stmt.where(d.instrument_id == (await find_instrument(session, instrument)).id)
            if interval is not None:
                stmt = stmt.where(d.interval == interval)
            if status is not None:
                stmt = stmt.where(d.status == status)
            stmt = stmt.order_by(d.created_at.desc(), d.id).offset(offset).limit(min(limit, LIST_LIMIT_MAX))
            return [dataset_view(row, instrument_row) for row, instrument_row in await session.execute(stmt)]

    async def get(self, dataset_id: UUID) -> DatasetView:
        async with self.db.session() as session:
            row = await session.get(BacktestDatasetRow, dataset_id)
            if row is None:
                raise dataset_not_found(dataset_id)
            instrument_row = await session.get(InstrumentRow, row.instrument_id)
        if instrument_row is None:  # deleted meanwhile; the dataset went with it
            raise dataset_not_found(dataset_id)
        return dataset_view(row, instrument_row)

    async def sources(self, instrument: UUID | str) -> DatasetSources:
        """Where the instrument's datasets can come from: each provider's history API, and the candles
        recorded from each feed, with the reason when one cannot be used."""
        calendar, _ = await self.calendars.get()
        now = self.clock()
        m, a = InstrumentProviderMappingRow, ProviderAccountRow
        async with self.db.session() as session:
            instrument_row = await find_instrument(session, instrument)
            listing = _instrument(instrument_row)
            mappings = {
                row.provider: row
                for row in await session.scalars(select(m).where(m.instrument_id == listing.id, m.is_active))
            }
            accounts = list(
                await session.scalars(
                    select(a).where(a.is_enabled, a.provider.in_(HISTORY_PROVIDERS)).order_by(a.label)
                )
            )
            recorded = await _recorded(session, listing.id, now)
        options: list[DatasetSourceOption] = []
        for provider in HISTORY_PROVIDERS:
            choices = tuple(
                AccountChoice(account_id=row.id, label=row.label, problem=_token_problem(row, now))
                for row in accounts
                if row.provider is provider
            )
            options.append(
                _history_option(HISTORY_SUPPORT[provider], listing, mappings.get(provider), choices)
            )
            options.append(_recorded_option(provider, DatasetSource.RECORDED, recorded.get(provider, [])))
        options.append(
            _recorded_option(
                Provider.SIMULATOR, DatasetSource.SIMULATED, recorded.get(Provider.SIMULATOR, [])
            )
        )
        return DatasetSources(
            instrument_id=listing.id,
            instrument_key=listing.canonical_key,
            symbol=listing.symbol,
            exchange=listing.exchange,
            segment=listing.segment,
            today=calendar.local_date(listing.exchange, now),
            max_candles=self.settings.backtest_max_candles,
            max_span_days=MAX_SPAN_DAYS,
            options=tuple(options),
            worker_problem=await backtest_worker_problem(self.bus),
        )

    # ---- the backtest worker ----------------------------------------------------------------------

    async def claim_next(self, worker_id: str) -> UUID | None:
        """Claim the oldest waiting dataset for this worker (BUILDING); None when none waits."""
        d = BacktestDatasetRow
        now = self.clock()
        async with self.db.transaction() as session:
            row = await session.scalar(
                select(d)
                .where(d.status == DatasetStatus.PENDING)
                .order_by(d.created_at, d.id)
                .limit(1)
                .with_for_update(skip_locked=True)
            )
            if row is None:
                return None
            row.status = DatasetStatus.BUILDING
            row.worker_id = worker_id[:120]
            row.started_at = now
            stamp_updated(row, now)
            return row.id

    async def keep_alive(self, dataset_id: UUID, worker_id: str) -> bool:
        """Show that this worker still builds the dataset; False when it is no longer its job."""
        d = BacktestDatasetRow
        async with self.db.transaction() as session:
            found = await session.scalar(
                update(d)
                .where(d.id == dataset_id, d.status == DatasetStatus.BUILDING, d.worker_id == worker_id[:120])
                .values(updated_at=self.clock())
                .returning(d.id)
            )
        return found is not None

    async def fail_abandoned(self, *, stale_before: datetime) -> list[UUID]:
        """Fail the datasets left BUILDING by a worker that stopped (no progress since ``stale_before``)."""
        d = BacktestDatasetRow
        now = self.clock()
        error = "The backtest worker stopped while building it; request it again"
        async with self.db.transaction() as session:
            failed = await session.scalars(
                update(d)
                .where(d.status == DatasetStatus.BUILDING, d.updated_at < stale_before)
                .values(status=DatasetStatus.FAILED, finished_at=now, updated_at=now, error=error)
                .returning(d.id)
            )
            return list(failed)

    async def build_claimed(
        self, dataset_id: UUID, worker_id: str, calendar: MarketCalendar
    ) -> DatasetStatus:
        """Build a dataset this worker claimed and store it READY, or FAILED with the reason. Returns the
        status it ended in; the claim may have been lost meanwhile (it stays as the other party left it)."""
        try:
            await self._build(dataset_id, worker_id, calendar)
        except ClaimLostError:
            log.warning("backtest_dataset_claim_lost", dataset_id=str(dataset_id))
            return DatasetStatus.FAILED
        except Exception as exc:
            if not expected_failure(exc):
                log.exception("backtest_dataset_build_crashed", dataset_id=str(dataset_id))
            text = failure_text(exc)
            log.warning("backtest_dataset_failed", dataset_id=str(dataset_id), error=text)
            await self._fail(dataset_id, worker_id, text)
            return DatasetStatus.FAILED
        return DatasetStatus.READY

    async def _build(self, dataset_id: UUID, worker_id: str, calendar: MarketCalendar) -> None:
        async with self.db.session() as session:
            row = await session.get(BacktestDatasetRow, dataset_id)
            if row is None or row.status is not DatasetStatus.BUILDING or row.worker_id != worker_id[:120]:
                raise ClaimLostError
            instrument_row = await session.get(InstrumentRow, row.instrument_id)
            if instrument_row is None:
                raise NotFoundError("The instrument was deleted", code="instrument_not_found")
            instrument = _instrument(instrument_row)
            mapping = await _mapping(session, instrument.id, row.provider)
        provider, source, interval = row.provider, row.source, row.interval
        first_day, last_day = row.date_from, row.date_to
        limit = self.settings.backtest_max_candles
        estimate = expected_candles(
            calendar, instrument.exchange, interval, first_day, last_day, stop_above=limit
        )
        if estimate > limit:
            raise DatasetError(
                f"{first_day} to {last_day} holds more than {limit:,} {interval.value} candles "
                "(BACKTEST_MAX_CANDLES); request fewer dates or a longer interval"
            )
        now = self.clock()
        requests = duplicates = 0
        source_candles: list[SourceCandle]
        if source is DatasetSource.PROVIDER_HISTORY:
            history = await self._download(row, instrument, mapping, calendar)
            if len(history.candles) > limit:
                raise DatasetError(
                    f"{provider.value} returned {len(history.candles):,} candles, more than "
                    f"BACKTEST_MAX_CANDLES ({limit:,})"
                )
            source_candles = [SourceCandle.from_history(candle) for candle in history.candles]
            requests, duplicates = history.requests, history.duplicates
        else:
            start, end = local_bounds(first_day, last_day, calendar, instrument.exchange)
            async with self.db.session() as session:
                recorded = await load_range(
                    session,
                    provider,
                    instrument.id,
                    instrument,
                    interval,
                    start=start,
                    end=end,
                    until=now,
                    limit=limit + 1,
                )
            if len(recorded) > limit:
                raise DatasetError(f"More than BACKTEST_MAX_CANDLES ({limit:,}) candles were recorded")
            source_candles = [SourceCandle.from_candle(candle) for candle in recorded]

        def assemble() -> tuple[BuiltDataset, str]:
            built = build(
                source_candles,
                calendar=calendar,
                instrument=instrument,
                interval=interval,
                first_day=first_day,
                last_day=last_day,
                live_anchor=self.settings.candle_anchor,
                until=now,
                requests=requests,
                duplicates=duplicates,
            )
            return built, dataset_sha(provider, source, instrument.id, interval, built.candles)

        built, sha = await asyncio.to_thread(assemble)
        await self._store(dataset_id, worker_id, built, sha)

    async def _download(
        self,
        row: BacktestDatasetRow,
        instrument: Instrument,
        mapping: InstrumentProviderMappingRow | None,
        calendar: MarketCalendar,
    ) -> History:
        support = HISTORY_SUPPORT.get(row.provider)
        if support is None or row.account_id is None:
            raise DatasetError(f"{row.provider.value} has no historical candles to download")
        problem = support.problem(instrument.segment, row.interval) or mapping_problem(
            row.provider, instrument, mapping
        )
        if problem is not None or mapping is None:
            raise DatasetError(f"Cannot download {instrument.canonical_key}: {problem}")
        credentials = await self.accounts.session_credentials(row.account_id)
        zone = calendar.timezone(instrument.exchange)
        settings = self.settings
        if row.provider is Provider.ZERODHA:
            if not credentials.api_key:
                raise DatasetError("The Zerodha account has no API key")
            token, with_oi = mapping.provider_token, instrument.instrument_type in _DERIVATIVES
            async with KiteRestClient(
                api_key=credentials.api_key,
                base_url=settings.zerodha_api_base_url,
                access_token=credentials.access_token,
                transport=self._transport,
                clock=self.clock,
            ) as kite:

                async def kite_window(name: str, first: date, last: date) -> Sequence[object]:
                    return await kite.historical_candles(token, name, first, last, oi=with_oi)

                return await download(support, row.interval, row.date_from, row.date_to, zone, kite_window)
        exchange, segment = mapping.provider_exchange, mapping.provider_segment
        symbol = str(mapping.provider_metadata["groww_symbol"])
        async with GrowwRestClient(
            base_url=settings.groww_api_base_url,
            access_token=credentials.access_token,
            transport=self._transport,
            clock=self.clock,
        ) as groww:

            async def groww_window(name: str, first: date, last: date) -> Sequence[object]:
                return await groww.historical_candles(exchange, segment, symbol, name, first, last)

            return await download(support, row.interval, row.date_from, row.date_to, zone, groww_window)

    async def _store(self, dataset_id: UUID, worker_id: str, built: BuiltDataset, sha: str) -> None:
        """Store the candles and mark the dataset READY in one transaction, if it is still this worker's."""
        d = BacktestDatasetRow
        candles = built.candles
        async with self.db.transaction() as session:
            for chunk in batched(candles, INSERT_CHUNK):
                await session.execute(
                    insert(BacktestDatasetCandleRow),
                    [
                        {
                            "dataset_id": dataset_id,
                            "bucket_start": candle.start,
                            "bucket_end": candle.end,
                            "open_price": candle.open,
                            "high_price": candle.high,
                            "low_price": candle.low,
                            "close_price": candle.close,
                            "volume": candle.volume,
                            "open_interest": candle.open_interest,
                            "flags": list(candle.flags),
                        }
                        for candle in chunk
                    ],
                )
            now = self.clock()
            stored = await session.scalar(
                update(d)
                .where(d.id == dataset_id, d.status == DatasetStatus.BUILDING, d.worker_id == worker_id[:120])
                .values(
                    status=DatasetStatus.READY,
                    finished_at=now,
                    updated_at=now,
                    error=None,
                    candle_count=len(candles),
                    first_candle_at=candles[0].start,
                    last_candle_at=candles[-1].end,
                    content_sha=sha,
                    coverage=built.coverage.model_dump(mode="json"),
                )
                .returning(d.id)
            )
            if stored is None:
                raise ClaimLostError  # rolls the candles back

    async def _fail(self, dataset_id: UUID, worker_id: str, error: str) -> None:
        d = BacktestDatasetRow
        now = self.clock()
        async with self.db.transaction() as session:
            await session.execute(
                update(d)
                .where(d.id == dataset_id, d.status == DatasetStatus.BUILDING, d.worker_id == worker_id[:120])
                .values(status=DatasetStatus.FAILED, finished_at=now, updated_at=now, error=error[:MAX_ERROR])
            )


# ---- helpers ------------------------------------------------------------------------------------------


def dataset_not_found(dataset_id: UUID) -> NotFoundError:
    return NotFoundError(f"Dataset {dataset_id} was not found", code="dataset_not_found")


def dataset_not_ready(row: BacktestDatasetRow) -> ConflictError:
    if row.status is DatasetStatus.FAILED:
        why = f"it failed: {row.error or 'no reason recorded'}; request it again"
    else:
        why = f"it is {row.status.value}; wait until it is READY"
    return ConflictError(f"Dataset {row.id} cannot be used yet: {why}", code="dataset_not_ready")


async def load_dataset_candles(session: AsyncSession, dataset_id: UUID) -> list[DatasetCandle]:
    """A dataset's candles in time order."""
    c = BacktestDatasetCandleRow
    rows = await session.execute(
        select(
            c.bucket_start,
            c.bucket_end,
            c.open_price,
            c.high_price,
            c.low_price,
            c.close_price,
            c.volume,
            c.open_interest,
            c.flags,
        )
        .where(c.dataset_id == dataset_id)
        .order_by(c.bucket_start)
    )
    return [
        DatasetCandle(
            start=start,
            end=end,
            open=open_price,
            high=high,
            low=low,
            close=close,
            volume=volume,
            open_interest=open_interest,
            flags=tuple(flags),
        )
        for start, end, open_price, high, low, close, volume, open_interest, flags in rows
    ]


def _instrument(row: InstrumentRow) -> Instrument:
    return Instrument.model_validate(row, from_attributes=True)


def dataset_view(row: BacktestDatasetRow, instrument: InstrumentRow) -> DatasetView:
    coverage: DatasetCoverage | None = None
    if row.status is DatasetStatus.READY and row.coverage:
        try:
            coverage = DatasetCoverage.model_validate(row.coverage)
        except ValidationError:  # stored by another engine version; the candles are still usable
            coverage = None
    return DatasetView(
        id=row.id,
        instrument_id=row.instrument_id,
        instrument_key=instrument.canonical_key,
        symbol=instrument.symbol,
        exchange=instrument.exchange,
        provider=row.provider,
        account_id=row.account_id,
        source=row.source,
        simulated=row.source is DatasetSource.SIMULATED,
        interval=row.interval,
        date_from=row.date_from,
        date_to=row.date_to,
        status=row.status,
        requested_by=row.requested_by,
        worker_id=row.worker_id,
        started_at=row.started_at,
        finished_at=row.finished_at,
        error=row.error,
        candle_count=row.candle_count,
        first_candle_at=row.first_candle_at,
        last_candle_at=row.last_candle_at,
        content_sha=row.content_sha,
        coverage=coverage,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


async def _mapping(
    session: AsyncSession, instrument_id: UUID, provider: Provider
) -> InstrumentProviderMappingRow | None:
    m = InstrumentProviderMappingRow
    return await session.scalar(
        select(m)
        .where(m.instrument_id == instrument_id, m.provider == provider, m.is_active)
        .order_by(m.valid_from.desc())
        .limit(1)
    )


async def _history_account(session: AsyncSession, provider: Provider, account_id: UUID | None) -> UUID:
    """The account a download uses: the one given, or the provider's only enabled account."""
    a = ProviderAccountRow
    if account_id is not None:
        row = await session.get(a, account_id)
        if row is None:
            raise NotFoundError(
                f"Provider account {account_id} does not exist", code="provider_account_not_found"
            )
        if row.provider is not provider:
            raise ValidationFailedError(
                f"Account '{row.label}' is a {row.provider.value} account, not a {provider.value} one",
                code="dataset_source_invalid",
            )
        return row.id
    rows = (
        await session.execute(
            select(a.id, a.label).where(a.provider == provider, a.is_enabled).order_by(a.label)
        )
    ).all()
    if not rows:
        raise ValidationFailedError(
            f"Downloading {provider.value} history needs an enabled {provider.value} account with a "
            "current access token; add one and log in",
            code="dataset_account_missing",
        )
    if len(rows) > 1:
        raise ValidationFailedError(
            f"Choose the {provider.value} account to download with: {', '.join(label for _, label in rows)}",
            code="dataset_account_ambiguous",
            details={"accounts": [{"id": str(row_id), "label": label} for row_id, label in rows]},
        )
    return rows[0][0]


def _token_problem(row: ProviderAccountRow, now: datetime) -> str | None:
    if row.token_expires_at is None or row.token_expires_at <= now:
        return f"'{row.label}' has no current access token; log in again"
    return None


def _history_option(
    support: HistorySupport,
    instrument: Instrument,
    mapping: InstrumentProviderMappingRow | None,
    accounts: tuple[AccountChoice, ...],
) -> DatasetSourceOption:
    provider = support.provider
    intervals = tuple(interval for interval in CandleInterval if interval in support.intervals)
    reason = support.problem(instrument.segment, intervals[0]) or mapping_problem(
        provider, instrument, mapping
    )
    if reason is None and not accounts:
        reason = f"there is no enabled {provider.value} account; add one and log in"
    elif reason is None and all(choice.problem for choice in accounts):
        reason = accounts[0].problem if len(accounts) == 1 else "no account has a current access token"
    return DatasetSourceOption(
        provider=provider,
        source=DatasetSource.PROVIDER_HISTORY,
        available=reason is None,
        reason=reason,
        intervals=intervals,
        max_days_per_request={interval.value: support.max_days[interval] for interval in intervals},
        note=support.note,
        accounts=accounts,
    )


def _recorded_option(
    provider: Provider, source: DatasetSource, series: Sequence[RecordedSeries]
) -> DatasetSourceOption:
    reason = None if series else f"no closed candles of this instrument were recorded from {provider.value}"
    return DatasetSourceOption(
        provider=provider,
        source=source,
        available=bool(series),
        reason=reason,
        intervals=tuple(item.interval for item in series),
        recorded=tuple(series),
    )


async def _recorded(
    session: AsyncSession, instrument_id: UUID, now: datetime
) -> dict[Provider, list[RecordedSeries]]:
    """The closed candles recorded for an instrument, per source and interval."""
    c = CandleRow
    rows = await session.execute(
        select(c.provider, c.interval, func.count(), func.min(c.bucket_start), func.max(c.bucket_end))
        .where(c.instrument_id == instrument_id, c.bucket_end <= now)
        .group_by(c.provider, c.interval)
    )
    found: defaultdict[Provider, list[RecordedSeries]] = defaultdict(list)
    for provider, interval, count, first, last in rows:
        found[provider].append(
            RecordedSeries(interval=interval, candles=count, first_candle_at=first, last_candle_at=last)
        )
    order = {interval: index for index, interval in enumerate(CandleInterval)}
    return {
        provider: sorted(items, key=lambda item: order[item.interval]) for provider, items in found.items()
    }
