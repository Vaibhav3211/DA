"""Local user authentication with opaque server-side sessions stored in Redis.

The browser holds a random session token in an HttpOnly, SameSite=Lax cookie; Redis stores only
its SHA-256 hash. Sessions have an absolute lifetime and are revoked on logout, password change
and user deactivation.
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from functools import cache
from uuid import UUID

from pydantic import BaseModel
from sqlalchemy import func, select

from app.core.clock import utc_now
from app.core.config import Settings
from app.core.errors import (
    AuthenticationError,
    ConflictError,
    NotFoundError,
    RateLimitedError,
    ValidationFailedError,
)
from app.core.logging import get_logger
from app.core.security import (
    hash_password,
    hash_token,
    new_opaque_token,
    password_needs_rehash,
    verify_password,
)
from app.persistence.database import Database
from app.persistence.models import UserRow
from app.services.audit import add_audit
from app.streaming.redis_bus import Keys, RedisBus, encode

log = get_logger(__name__)

MAX_FAILED_LOGINS = 5
LOCKOUT_DURATION = timedelta(minutes=15)
# Failed sign-ins per client address, whatever the username: bounds guessing across usernames too.
MAX_FAILED_LOGINS_PER_IP = 5
FAILED_LOGIN_WINDOW = timedelta(minutes=15)
MIN_PASSWORD_LENGTH = 12
MAX_PASSWORD_LENGTH = 256
_USERNAME = re.compile(r"^[a-z0-9][a-z0-9_.-]{2,63}$")


class SessionUser(BaseModel):
    user_id: UUID
    username: str
    created_at: datetime
    expires_at: datetime


@cache
def _dummy_hash() -> str:
    # Verifying against this when the user does not exist keeps response timing uniform.
    return hash_password(new_opaque_token())


def normalize_username(username: str) -> str:
    return username.strip().lower()


def validate_username(username: str) -> None:
    if not _USERNAME.match(username):
        raise ValidationFailedError(
            "Username must be 3-64 characters: lowercase letters, digits, '.', '_' or '-'",
            code="invalid_username",
        )


def validate_new_credentials(username: str, password: str) -> None:
    validate_username(username)
    if not MIN_PASSWORD_LENGTH <= len(password) <= MAX_PASSWORD_LENGTH:
        raise ValidationFailedError(
            f"Password must be {MIN_PASSWORD_LENGTH}-{MAX_PASSWORD_LENGTH} characters",
            code="weak_password",
        )
    if password.strip().lower() == username:
        raise ValidationFailedError("Password must not equal the username", code="weak_password")


class AuthService:
    def __init__(self, db: Database, bus: RedisBus, settings: Settings) -> None:
        self._db = db
        self._bus = bus
        self._settings = settings

    # ---- login / sessions --------------------------------------------------------------------

    async def login(self, username: str, password: str, *, client_ip: str | None) -> tuple[str, SessionUser]:
        await self._enforce_rate_limit(client_ip)
        failures_key = Keys.login_attempts(f"failed:ip:{client_ip or 'unknown'}")
        await self._enforce_failure_limit(failures_key)
        name = normalize_username(username)
        now = utc_now()
        failure: AuthenticationError | None = None
        authenticated: tuple[UUID, str] | None = None
        async with self._db.transaction() as session:
            user = await session.scalar(select(UserRow).where(UserRow.username == name).with_for_update())
            if user is None or not user.is_active:
                verify_password(_dummy_hash(), password)
                failure = AuthenticationError("Invalid username or password", code="invalid_credentials")
                add_audit(
                    session,
                    actor=name or "?",
                    action="auth.login_failed",
                    entity_type="user",
                    details={"reason": "unknown_or_inactive_user"},
                    client_ip=client_ip,
                )
            elif user.locked_until is not None and user.locked_until > now:
                failure = AuthenticationError(
                    "Too many failed attempts; the account is temporarily locked",
                    code="account_locked",
                    details={"locked_until": user.locked_until.isoformat()},
                )
                add_audit(
                    session,
                    actor=name,
                    action="auth.login_rejected_locked",
                    entity_type="user",
                    entity_id=user.id,
                    client_ip=client_ip,
                )
            elif not verify_password(user.password_hash, password):
                user.failed_login_count += 1
                details: dict[str, object] = {"failed_login_count": user.failed_login_count}
                if user.failed_login_count >= MAX_FAILED_LOGINS:
                    user.locked_until = now + LOCKOUT_DURATION
                    user.failed_login_count = 0
                    details["locked_until"] = user.locked_until.isoformat()
                failure = AuthenticationError("Invalid username or password", code="invalid_credentials")
                add_audit(
                    session,
                    actor=name,
                    action="auth.login_failed",
                    entity_type="user",
                    entity_id=user.id,
                    details=details,
                    client_ip=client_ip,
                )
            else:
                user.failed_login_count = 0
                user.locked_until = None
                user.last_login_at = now
                if password_needs_rehash(user.password_hash):
                    user.password_hash = hash_password(password)
                add_audit(
                    session,
                    actor=name,
                    action="auth.login",
                    entity_type="user",
                    entity_id=user.id,
                    client_ip=client_ip,
                )
                authenticated = (user.id, user.username)
        if failure is not None:
            if failure.code == "invalid_credentials":
                await self._record_failure(failures_key)
            raise failure
        assert authenticated is not None
        await self._bus.delete(failures_key)
        return await self._create_session(*authenticated, now)

    async def _create_session(self, user_id: UUID, username: str, now: datetime) -> tuple[str, SessionUser]:
        ttl = self._settings.session_ttl_seconds
        token = new_opaque_token()
        token_hash = hash_token(token)
        session_user = SessionUser(
            user_id=user_id, username=username, created_at=now, expires_at=now + timedelta(seconds=ttl)
        )
        index_key = Keys.user_sessions(user_id)
        async with self._bus.redis.pipeline(transaction=True) as pipe:
            pipe.set(Keys.session(token_hash), encode(session_user), ex=ttl)
            pipe.sadd(index_key, token_hash)
            pipe.expire(index_key, ttl)
            await pipe.execute()
        return token, session_user

    async def resolve(self, token: str) -> SessionUser | None:
        if not token or len(token) > 256:
            return None
        raw = await self._bus.get_json(Keys.session(hash_token(token)))
        if raw is None:
            return None
        session_user = SessionUser.model_validate(raw)
        if session_user.expires_at <= utc_now():
            return None
        return session_user

    async def logout(self, token: str, *, client_ip: str | None) -> None:
        session_user = await self.resolve(token)
        token_hash = hash_token(token)
        await self._bus.delete(Keys.session(token_hash))
        if session_user is None:
            return
        await self._bus.redis.srem(Keys.user_sessions(session_user.user_id), token_hash)
        async with self._db.transaction() as session:
            add_audit(
                session,
                actor=session_user.username,
                action="auth.logout",
                entity_type="user",
                entity_id=session_user.user_id,
                client_ip=client_ip,
            )

    async def revoke_all_sessions(self, user_id: UUID) -> int:
        index_key = Keys.user_sessions(user_id)
        hashes = [str(h) for h in await self._bus.redis.smembers(index_key)]
        await self._bus.delete(*(Keys.session(h) for h in hashes), index_key)
        return len(hashes)

    async def _enforce_rate_limit(self, client_ip: str | None) -> None:
        key = Keys.login_attempts(f"ip:{client_ip or 'unknown'}")
        async with self._bus.redis.pipeline(transaction=True) as pipe:
            pipe.incr(key)
            pipe.expire(key, 60, nx=True)
            attempts, _ = await pipe.execute()
        if int(attempts) > self._settings.login_rate_limit_per_minute:
            ttl = await self._bus.redis.ttl(key)
            raise RateLimitedError(
                "Too many login attempts; wait and try again",
                details={"retry_after_seconds": max(int(ttl), 1)},
            )

    async def _enforce_failure_limit(self, key: str) -> None:
        failures = await self._bus.redis.get(key)
        if failures is not None and int(failures) >= MAX_FAILED_LOGINS_PER_IP:
            ttl = await self._bus.redis.ttl(key)
            log.warning("login_blocked_for_address", failures=int(failures))
            raise RateLimitedError(
                "Too many failed sign-in attempts from this address; try again later",
                code="login_blocked",
                details={"retry_after_seconds": max(int(ttl), 1)},
            )

    async def _record_failure(self, key: str) -> None:
        # The window starts at the first failure; a successful sign-in clears the count.
        async with self._bus.redis.pipeline(transaction=True) as pipe:
            pipe.incr(key)
            pipe.expire(key, int(FAILED_LOGIN_WINDOW.total_seconds()), nx=True)
            await pipe.execute()

    # ---- user management (CLI) -----------------------------------------------------------------

    async def user_count(self) -> int:
        async with self._db.session() as session:
            return int(await session.scalar(select(func.count()).select_from(UserRow)) or 0)

    async def user_exists(self, username: str) -> bool:
        name = normalize_username(username)
        async with self._db.session() as session:
            return await session.scalar(select(UserRow.id).where(UserRow.username == name)) is not None

    async def create_user(self, username: str, password: str, *, actor: str) -> UUID:
        name = normalize_username(username)
        validate_new_credentials(name, password)
        async with self._db.transaction() as session:
            existing = await session.scalar(select(UserRow.id).where(UserRow.username == name))
            if existing is not None:
                raise ConflictError(f"User '{name}' already exists", code="user_exists")
            user = UserRow(username=name, password_hash=hash_password(password))
            session.add(user)
            await session.flush()
            add_audit(session, actor=actor, action="user.create", entity_type="user", entity_id=user.id)
            return user.id

    async def set_password(self, username: str, password: str, *, actor: str) -> int:
        """Set a new password, clear lockout and revoke every existing session of the user."""
        name = normalize_username(username)
        validate_new_credentials(name, password)
        async with self._db.transaction() as session:
            user = await session.scalar(select(UserRow).where(UserRow.username == name).with_for_update())
            if user is None:
                raise NotFoundError(f"User '{name}' does not exist", code="user_not_found")
            user.password_hash = hash_password(password)
            user.failed_login_count = 0
            user.locked_until = None
            user.is_active = True
            user_id = user.id
            add_audit(
                session, actor=actor, action="user.password_reset", entity_type="user", entity_id=user_id
            )
        return await self.revoke_all_sessions(user_id)
