"""Provider login flows: Zerodha redirect login, Groww access tokens, and logout.

These are the only callers of provider authentication endpoints. Each flow stores the new access
token encrypted (``ProviderAccountService.store_access_token``), records token metadata and an
audit entry, and asks the market-data worker to (re)connect the account when it is enabled.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any
from urllib.parse import SplitResult, urlsplit
from uuid import UUID

import httpx
from sqlalchemy import func, select

from app.core.config import Settings
from app.core.errors import (
    AppError,
    ConflictError,
    PermissionDeniedError,
    RateLimitedError,
    ServiceUnavailableError,
    ValidationFailedError,
)
from app.core.logging import get_logger
from app.core.security import hash_token, new_opaque_token
from app.domain.enums import AccountStatus, AuthMethod, CredentialKind, Provider
from app.domain.events import CommandType
from app.domain.models.base import DomainModel, UtcDatetime
from app.persistence.models import ProviderAccountRow, ProviderTokenMetadataRow
from app.providers.base import describe_error
from app.providers.errors import ProviderAuthRequiredError
from app.providers.groww.auth import jwt_expiry
from app.providers.groww.auth import token_expiry as groww_token_expiry
from app.providers.groww.client import GrowwRestClient
from app.providers.groww.totp import totp_code
from app.providers.zerodha.auth import build_login_url, parse_redirect, redirect_state
from app.providers.zerodha.client import KiteRestClient
from app.services.audit import CLI_ACTOR, add_audit
from app.services.provider_accounts import ENTITY, AccountSecrets, ProviderAccountService, ProviderAccountView
from app.streaming.redis_bus import Keys

log = get_logger(__name__)

LOGIN_STATE_TTL = timedelta(minutes=10)
# Groww limits how many access tokens a user may create per day; stay within it locally so a
# misbehaving script cannot lock the account out (counted per account over a rolling 24 hours).
GROWW_DAILY_TOKEN_LIMIT = 150
_CREATED_TOKEN_METHODS = (AuthMethod.GROWW_API_KEY_SECRET, AuthMethod.GROWW_TOTP)
_BEARER_PREFIX = re.compile(r"\Abearer\s+", re.IGNORECASE)
_TOKEN = re.compile(r"[\x21-\x7e]{1,4096}")
_DEFAULT_PORTS: Mapping[str, int] = {"http": 80, "https": 443}


class ZerodhaLoginStart(DomainModel):
    account_id: UUID
    login_url: str  # open in a browser; Kite redirects to redirect_url afterwards
    redirect_url: str
    expires_at: UtcDatetime


class LogoutResult(DomainModel):
    account: ProviderAccountView
    # True/False: whether Zerodha confirmed the session was invalidated. None: the provider has no
    # logout endpoint, so the token stays valid at the provider until it expires.
    remote_revoked: bool | None


def _expect_provider(account: ProviderAccountRow, provider: Provider) -> None:
    if account.provider is not provider:
        raise ValidationFailedError(
            f"Account '{account.label}' is a {account.provider.value} account, not {provider.value}",
            code="wrong_provider",
        )


def _user_mismatch(label: str, bound: str, actual: str) -> ConflictError:
    return ConflictError(
        f"Account '{label}' belongs to provider user {bound}, but this login is for {actual}. "
        "Use the same user, or add a separate account for the other one.",
        code="provider_user_mismatch",
    )


def clean_access_token(token: str) -> str:
    """A pasted token without surrounding whitespace or a ``Bearer`` prefix."""
    value = _BEARER_PREFIX.sub("", token.strip(), count=1).strip()
    if not _TOKEN.fullmatch(value):
        raise ValidationFailedError(
            "The access token must be 1-4096 printable characters without spaces", code="invalid_token"
        )
    return value


def _endpoint(parts: SplitResult) -> tuple[str, str, int | None, str]:
    scheme = parts.scheme.lower()
    try:
        port = parts.port
    except ValueError:
        raise ValidationFailedError("The URL has an invalid port", code="redirect_url_mismatch") from None
    return scheme, (parts.hostname or "").lower(), port or _DEFAULT_PORTS.get(scheme), parts.path.rstrip("/")


def check_redirect_target(callback: str, expected: str | None) -> None:
    """A pasted full URL must point at the configured redirect URL (a bare query string is fine)."""
    text = callback.strip()
    if "://" not in text or not expected:
        return
    if _endpoint(urlsplit(text)) != _endpoint(urlsplit(expected.strip())):
        raise ValidationFailedError(
            "That URL is not the configured Zerodha redirect URL; paste the address the browser "
            "showed after the Kite login",
            code="redirect_url_mismatch",
        )


class ProviderAuthService:
    def __init__(
        self, accounts: ProviderAccountService, *, transport: httpx.AsyncBaseTransport | None = None
    ) -> None:
        self.accounts = accounts
        self._transport = transport  # tests inject an httpx.MockTransport

    @property
    def settings(self) -> Settings:
        return self.accounts.settings

    def _kite(self, api_key: str) -> KiteRestClient:
        return KiteRestClient(
            api_key=api_key,
            base_url=self.settings.zerodha_api_base_url,
            transport=self._transport,
            clock=self.accounts.clock,
        )

    def _groww(self, access_token: str | None = None) -> GrowwRestClient:
        return GrowwRestClient(
            base_url=self.settings.groww_api_base_url,
            access_token=access_token,
            transport=self._transport,
            clock=self.accounts.clock,
        )

    # ---- Zerodha ----------------------------------------------------------------------------------

    def _redirect_url(self) -> str:
        url = (self.settings.zerodha_redirect_url or "").strip()
        if not url:
            raise ServiceUnavailableError(
                "ZERODHA_REDIRECT_URL is not configured; set it to the redirect URL registered for "
                "the Kite Connect app",
                code="zerodha_redirect_not_configured",
            )
        return url

    async def begin_zerodha_login(self, account_id: UUID, *, actor: str) -> ZerodhaLoginStart:
        """Create a one-time login state and the Kite login URL that carries it."""
        redirect_url = self._redirect_url()
        secrets = await self.accounts.resolve_secrets(account_id)
        account = secrets.account
        _expect_provider(account, Provider.ZERODHA)
        api_key = secrets.require(CredentialKind.API_KEY)
        secrets.require(CredentialKind.API_SECRET)  # fail now, not after the user has logged in
        self.accounts.vault.require()  # the access token must be storable
        state = new_opaque_token()
        now = self.accounts.clock()
        await self.accounts.bus.set_json(
            Keys.zerodha_pending_login(hash_token(state)),
            {"account_id": str(account.id), "actor": actor, "created_at": now.isoformat()},
            ttl_seconds=LOGIN_STATE_TTL.total_seconds(),
        )
        log.info("zerodha_login_started", account_id=str(account.id), label=account.label)
        return ZerodhaLoginStart(
            account_id=account.id,
            login_url=build_login_url(self.settings.zerodha_login_url, api_key, state),
            redirect_url=redirect_url,
            expires_at=now + LOGIN_STATE_TTL,
        )

    async def is_cli_zerodha_login(self, callback: str) -> bool:
        """Whether a Kite redirect returns to a login that ``qt zerodha login`` is waiting to finish.

        It only looks: the login state stays unused, so the command line can still complete it.
        """
        state = redirect_state(callback)
        if state is None:
            return False
        payload = await self.accounts.bus.get_json(Keys.zerodha_pending_login(hash_token(state)))
        try:
            return _pending_login(payload).actor == CLI_ACTOR
        except ValidationFailedError:
            return False

    async def complete_zerodha_login(
        self, callback: str, *, actor: str, client_ip: str | None = None
    ) -> ProviderAccountView:
        """Finish a login from the URL Kite redirected the browser to (or just its query string)."""
        check_redirect_target(callback, self.settings.zerodha_redirect_url)
        redirect = parse_redirect(callback)
        if not redirect.state:
            raise ValidationFailedError(
                "The redirect carries no login state; start the login again", code="login_state_missing"
            )
        key = Keys.zerodha_pending_login(hash_token(redirect.state))
        pending = _pending_login(await self.accounts.bus.get_json(key))
        if pending.actor != actor:
            # Not consumed: the session that started the login can still finish it.
            if pending.actor == CLI_ACTOR:
                raise PermissionDeniedError(
                    "This login was started from the command line; paste this page's address into "
                    "the waiting `qt zerodha login` prompt",
                    code="login_state_mismatch",
                )
            raise PermissionDeniedError("This login was started by another user", code="login_state_mismatch")
        _pending_login(await self.accounts.bus.getdel_json(key))  # one use only, even when racing
        secrets = await self.accounts.resolve_secrets(pending.account_id)
        account = secrets.account
        _expect_provider(account, Provider.ZERODHA)
        api_key = secrets.require(CredentialKind.API_KEY)
        api_secret = secrets.require(CredentialKind.API_SECRET)
        self.accounts.vault.require()
        async with self._kite(api_key) as client:
            session = await client.generate_session(redirect.request_token, api_secret)
            bound = account.provider_user_ref
            if bound and session.user_id != bound:
                await self._revoke_kite(client, session.access_token)
                raise _user_mismatch(account.label, bound, session.user_id)
        return await self._store(
            account.id,
            token=session.access_token,
            expires_at=session.expires_at,
            user_ref=session.user_id,
            actor=actor,
            client_ip=client_ip,
            action="provider_account.login",
        )

    @staticmethod
    async def _revoke_kite(client: KiteRestClient, token: str) -> bool:
        """Best-effort Kite logout; False when Zerodha did not confirm it."""
        try:
            await client.invalidate_access_token(token)
        except (AppError, httpx.HTTPError) as exc:
            log.warning("zerodha_logout_not_confirmed", error=describe_error(exc))
            return False
        return True

    # ---- Groww -------------------------------------------------------------------------------------

    async def set_groww_token(
        self,
        account_id: UUID,
        token: str,
        *,
        verify: bool = True,
        actor: str,
        client_ip: str | None = None,
    ) -> ProviderAccountView:
        """Store an access token generated in Groww Cloud, checking it with a profile call first."""
        value = clean_access_token(token)
        claimed = jwt_expiry(value)
        if claimed is not None and claimed <= self.accounts.clock():
            raise ValidationFailedError("This access token has already expired", code="token_expired")
        account = await self.accounts.get(account_id)
        if account.provider is not Provider.GROWW:
            raise ValidationFailedError(
                f"Account '{account.label}' is a {account.provider.value} account, not GROWW",
                code="wrong_provider",
            )
        self.accounts.vault.require()
        user_ref: str | None = None
        if verify:
            async with self._groww(value) as client:
                try:
                    profile = await client.profile()
                except ProviderAuthRequiredError:
                    raise ValidationFailedError(
                        "Groww rejected this access token", code="provider_token_rejected"
                    ) from None
            user_ref = profile.user_ref
        return await self._store(
            account_id,
            token=value,
            expires_at=groww_token_expiry(value, self.accounts.clock()),
            user_ref=user_ref,
            actor=actor,
            client_ip=client_ip,
            action="provider_account.token_set",
            details={"verified": verify},
            auth_method=AuthMethod.GROWW_ACCESS_TOKEN,
        )

    async def create_groww_token(
        self,
        account_id: UUID,
        *,
        code: str | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> ProviderAccountView:
        """Create an access token with the stored API key (approval secret or TOTP flow).

        For the TOTP flow, ``code`` is the authenticator's current code; without one it is computed
        from the stored TOTP secret.
        """
        secrets = await self.accounts.resolve_secrets(account_id)
        account = secrets.account
        _expect_provider(account, Provider.GROWW)
        method = account.auth_method
        if method not in _CREATED_TOKEN_METHODS:
            raise ValidationFailedError(
                f"Account '{account.label}' uses access tokens generated in Groww Cloud; set one "
                "instead, or switch the account to an API key method",
                code="use_set_token",
            )
        api_key = secrets.require(CredentialKind.API_KEY)
        if method is AuthMethod.GROWW_API_KEY_SECRET:
            if code is not None:
                raise ValidationFailedError(
                    "Authenticator codes only apply to the GROWW_TOTP method", code="totp_not_applicable"
                )
            api_secret: str | None = secrets.require(CredentialKind.API_SECRET)
            totp = None
        else:
            api_secret = None
            totp = self._totp(secrets, code)
        self.accounts.vault.require()
        await self._check_token_budget(account.id)
        async with self._groww() as client:
            if api_secret is not None:
                session = await client.create_access_token_with_secret(api_key, api_secret)
            else:
                session = await client.create_access_token_with_totp(api_key, totp or "")
        return await self._store(
            account.id,
            token=session.access_token,
            expires_at=session.expires_at,
            user_ref=None,
            actor=actor,
            client_ip=client_ip,
            action="provider_account.token_created",
            details={"method": method.value},
        )

    def _totp(self, secrets: AccountSecrets, code: str | None) -> str:
        if code is not None and code.strip():
            return code.strip()
        if (
            secrets.get(CredentialKind.TOTP_SECRET) is None
            and CredentialKind.TOTP_SECRET not in secrets.unreadable
        ):
            raise ValidationFailedError(
                "Enter the current code from the authenticator app, or store the TOTP secret so codes "
                "are generated automatically",
                code="totp_code_required",
            )
        return totp_code(secrets.require(CredentialKind.TOTP_SECRET), now=self.accounts.clock())

    async def _check_token_budget(self, account_id: UUID) -> None:
        since = self.accounts.clock() - timedelta(hours=24)
        async with self.accounts.db.session() as session:
            used = await session.scalar(
                select(func.count())
                .select_from(ProviderTokenMetadataRow)
                .where(
                    ProviderTokenMetadataRow.account_id == account_id,
                    ProviderTokenMetadataRow.auth_method.in_(_CREATED_TOKEN_METHODS),
                    ProviderTokenMetadataRow.issued_at > since,
                )
            )
        if (used or 0) >= GROWW_DAILY_TOKEN_LIMIT:
            raise RateLimitedError(
                f"{used} Groww access tokens were created for this account in the last 24 hours; "
                "wait before creating another",
                code="token_budget_exhausted",
            )

    # ---- logout and storage -----------------------------------------------------------------------

    async def disconnect(self, account_id: UUID, *, actor: str, client_ip: str | None = None) -> LogoutResult:
        """Log out: forget the access token, and invalidate a Kite session at Zerodha (best effort)."""
        accounts = self.accounts
        secrets = await accounts.resolve_secrets(account_id, include_token=True)
        account = secrets.account
        if account.provider is Provider.SIMULATOR:
            raise ValidationFailedError("Simulator accounts have no login", code="credentials_not_applicable")
        remote_revoked: bool | None = None
        token = secrets.get(CredentialKind.ACCESS_TOKEN)
        if account.provider is Provider.ZERODHA:
            api_key = secrets.get(CredentialKind.API_KEY)
            remote_revoked = False
            if token and api_key:
                async with self._kite(api_key) as client:
                    remote_revoked = await self._revoke_kite(client, token)
        async with accounts.db.transaction() as session:
            row = await accounts.lock_account(session, account_id)
            kinds = await accounts.credential_kinds(session, row.id)
            if CredentialKind.ACCESS_TOKEN not in kinds and row.status is AccountStatus.DISCONNECTED:
                return LogoutResult(account=accounts.view(row, kinds), remote_revoked=remote_revoked)
            await accounts.drop_access_token(session, row, reason="logged out", actor=actor)
            kinds -= {CredentialKind.ACCESS_TOKEN}
            row.status = AccountStatus.DISCONNECTED
            row.last_error_code = None
            row.last_error_message = None
            accounts.touch(row, actor)
            add_audit(
                session,
                actor=actor,
                action="provider_account.logout",
                entity_type=ENTITY,
                entity_id=row.id,
                details={
                    "provider": row.provider.value,
                    "label": row.label,
                    "remote_revoked": remote_revoked,
                },
                client_ip=client_ip,
            )
        if row.is_enabled:
            await accounts.notify(CommandType.DISCONNECT_ACCOUNT, row, actor)
        return LogoutResult(account=accounts.view(row, kinds), remote_revoked=remote_revoked)

    async def _store(
        self,
        account_id: UUID,
        *,
        token: str,
        expires_at: datetime,
        user_ref: str | None,
        actor: str,
        client_ip: str | None,
        action: str,
        details: Mapping[str, Any] | None = None,
        auth_method: AuthMethod | None = None,
    ) -> ProviderAccountView:
        accounts = self.accounts
        async with accounts.db.transaction() as session:
            row = await accounts.lock_account(session, account_id)
            bound = row.provider_user_ref
            if user_ref is not None and bound and bound != user_ref:
                raise _user_mismatch(row.label, bound, user_ref)
            await accounts.store_access_token(
                session,
                row,
                token=token,
                expires_at=expires_at,
                user_ref=user_ref,
                actor=actor,
                auth_method=auth_method,
            )
            await session.flush()  # autoflush is off: make the new token row visible to the query
            kinds = await accounts.credential_kinds(session, row.id)
            add_audit(
                session,
                actor=actor,
                action=action,
                entity_type=ENTITY,
                entity_id=row.id,
                details={
                    "provider": row.provider.value,
                    "label": row.label,
                    "user_ref": user_ref,
                    "expires_at": expires_at.isoformat(),
                    **(details or {}),
                },
                client_ip=client_ip,
            )
        if row.is_enabled:
            await accounts.notify(CommandType.CONNECT_ACCOUNT, row, actor)
        return accounts.view(row, kinds)


@dataclass(frozen=True, slots=True)
class _PendingLogin:
    account_id: UUID
    actor: str


def _pending_login(payload: object) -> _PendingLogin:
    if isinstance(payload, Mapping):
        account_id, actor = payload.get("account_id"), payload.get("actor")
        if isinstance(account_id, str) and isinstance(actor, str):
            try:
                return _PendingLogin(UUID(account_id), actor)
            except ValueError:
                pass
    raise ValidationFailedError(
        "This login is unknown or has expired; start the login again", code="login_state_invalid"
    )
