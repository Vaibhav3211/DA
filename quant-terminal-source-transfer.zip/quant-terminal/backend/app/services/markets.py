"""Market sessions for API readers, from the same calendar the workers use."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from datetime import date, datetime

from app.core.config import Settings
from app.core.logging import get_logger
from app.domain.enums import Exchange, MarketSessionState
from app.domain.models.base import DomainModel, UtcDatetime
from app.market_data.calendars.loader import load_exchange_specs, load_market_calendar, load_overrides
from app.market_data.calendars.service import DayKind, ExchangeSpec, MarketCalendar
from app.persistence.database import Database

log = get_logger(__name__)


class MarketCalendarCache:
    """The market calendar, loaded on first use. Overrides are re-read every
    ``CALENDAR_RELOAD_INTERVAL_SECONDS``, as the workers do."""

    def __init__(
        self, db: Database, settings: Settings, *, monotonic: Callable[[], float] = time.monotonic
    ) -> None:
        self._db = db
        self._reload_seconds = settings.calendar_reload_interval_seconds
        self._monotonic = monotonic
        self._lock = asyncio.Lock()
        self._loaded: tuple[MarketCalendar, tuple[ExchangeSpec, ...]] | None = None
        self._reload_due = 0.0

    async def get(self) -> tuple[MarketCalendar, tuple[ExchangeSpec, ...]]:
        async with self._lock:
            if self._loaded is None:
                calendar = await load_market_calendar(self._db)
                specs = sorted(await load_exchange_specs(self._db), key=lambda spec: spec.exchange.value)
                self._loaded = (calendar, tuple(specs))
            elif self._monotonic() >= self._reload_due:
                await self._reload_overrides(self._loaded[0])
            else:
                return self._loaded
            self._reload_due = self._monotonic() + self._reload_seconds
            return self._loaded

    async def _reload_overrides(self, calendar: MarketCalendar) -> None:
        try:
            overrides = frozenset(await load_overrides(self._db))
        except Exception as exc:  # the overrides in use stay; the next read tries again
            log.error("calendar_reload_failed", error=type(exc).__name__)
            return
        if overrides != calendar.overrides:
            calendar.set_overrides(overrides)
            log.info("calendar_overrides_reloaded", overrides=len(overrides))


class MarketSession(DomainModel):
    exchange: Exchange
    timezone: str
    state: MarketSessionState
    session_date: date  # the exchange-local trading date the state refers to
    day_kind: DayKind
    open_at: UtcDatetime | None
    close_at: UtcDatetime | None
    special: bool  # a special session, such as Muhurat trading
    verified: bool  # False: computed beyond the published calendar, or the exchange has no calendar
    calendar_covered_until: date | None


class MarketOverview(DomainModel):
    markets: tuple[MarketSession, ...]
    generated_at: UtcDatetime


async def market_overview(cache: MarketCalendarCache, now: datetime) -> MarketOverview:
    calendar, specs = await cache.get()
    coverage = calendar.coverage()
    sessions: list[MarketSession] = []
    for spec in specs:
        status = calendar.status(spec.exchange, now)
        day = status.day
        sessions.append(
            MarketSession(
                exchange=spec.exchange,
                timezone=spec.timezone.key,
                state=status.state,
                session_date=day.session_date,
                day_kind=day.kind,
                open_at=day.open_at,
                close_at=day.close_at,
                special=day.special,
                verified=day.verified,
                calendar_covered_until=coverage.get(spec.exchange),
            )
        )
    return MarketOverview(markets=tuple(sessions), generated_at=now)
