"""Risk rule settings: list, tune, enable/disable, reset, and pause or resume a workspace.

Rows in ``risk_rules`` layer over the code defaults (global row, then workspace row). The signal
engine reads them with ``load_policy`` inside its own transaction, so a change applies to the very
next candidate.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from datetime import datetime
from typing import Any, Self
from uuid import UUID

from pydantic import ValidationError
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.container import Container
from app.core.clock import utc_now
from app.core.errors import NotFoundError, ValidationFailedError
from app.domain.models.base import DomainModel, UtcDatetime
from app.persistence.database import Database
from app.persistence.models import RiskRuleRow
from app.risk.engine import (
    EffectiveRule,
    RiskPolicy,
    RuleOverride,
    describe_error,
    merge_params,
    resolve_policy,
)
from app.risk.rules import BUILTIN_RULES, RULES_BY_KEY, WORKSPACE_PAUSE, RiskRule
from app.services.audit import add_audit
from app.services.workspaces import find_workspace

ENTITY = "risk_rule"


class RiskRuleView(DomainModel):
    rule_key: str
    description: str
    mandatory: bool
    workspace_slug: str | None
    enabled: bool
    source: str
    params: dict[str, Any]
    defaults: dict[str, Any]
    error: str | None = None
    updated_by: str | None = None
    updated_at: UtcDatetime | None = None


def _override(row: RiskRuleRow) -> RuleOverride:
    return RuleOverride(row.rule_key, row.workspace_id, row.is_enabled, row.params)


async def _rows(session: AsyncSession, workspace_id: UUID | None) -> list[RiskRuleRow]:
    query = select(RiskRuleRow).where(
        RiskRuleRow.workspace_id.is_(None) | (RiskRuleRow.workspace_id == workspace_id)
    )
    return list((await session.scalars(query)).all())


async def load_policy(session: AsyncSession, workspace_id: UUID | None) -> RiskPolicy:
    """Effective rules for a workspace (``None``: the global layer only)."""
    return resolve_policy([_override(row) for row in await _rows(session, workspace_id)], workspace_id)


def _rule(rule_key: str) -> RiskRule:
    rule = RULES_BY_KEY.get(rule_key)
    if rule is None:
        known = ", ".join(item.key for item in BUILTIN_RULES)
        raise NotFoundError(f"Unknown risk rule {rule_key!r} (known: {known})", code="risk_rule_not_found")
    return rule


class RiskRuleService:
    def __init__(self, db: Database, *, clock: Callable[[], datetime] = utc_now) -> None:
        self._db = db
        self._clock = clock

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(container.db, clock=clock)

    async def list_rules(self, workspace: str | None = None) -> list[RiskRuleView]:
        async with self._db.session() as session:
            row = await find_workspace(session, workspace) if workspace else None
            workspace_id, slug = (row.id, row.slug) if row is not None else (None, None)
            rows = await _rows(session, workspace_id)
        policy = resolve_policy([_override(item) for item in rows], workspace_id)
        return [_view(item, slug, rows) for item in policy.rules]

    async def get_rule(self, rule_key: str, workspace: str | None = None) -> RiskRuleView:
        _rule(rule_key)
        return next(view for view in await self.list_rules(workspace) if view.rule_key == rule_key)

    async def set_rule(
        self,
        rule_key: str,
        *,
        workspace: str | None = None,
        enabled: bool | None = None,
        params: Mapping[str, Any] | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> RiskRuleView:
        return await self._set(
            rule_key,
            workspace=workspace,
            enabled=enabled,
            params=params,
            actor=actor,
            client_ip=client_ip,
            action="risk.rule_set",
        )

    async def pause(
        self, workspace: str, *, reason: str | None, actor: str, client_ip: str | None = None
    ) -> RiskRuleView:
        return await self._set(
            WORKSPACE_PAUSE,
            workspace=workspace,
            params={"paused": True, "reason": reason},
            actor=actor,
            client_ip=client_ip,
            action="risk.workspace_pause",
        )

    async def resume(self, workspace: str, *, actor: str, client_ip: str | None = None) -> RiskRuleView:
        return await self._set(
            WORKSPACE_PAUSE,
            workspace=workspace,
            params={"paused": False, "reason": None},
            actor=actor,
            client_ip=client_ip,
            action="risk.workspace_resume",
        )

    async def reset_rule(
        self, rule_key: str, *, workspace: str | None = None, actor: str, client_ip: str | None = None
    ) -> RiskRuleView:
        """Delete the stored row so the next layer (global row or code default) applies again."""
        _rule(rule_key)
        async with self._db.transaction() as session:
            await session.execute(select(func.pg_advisory_xact_lock(func.hashtext(ENTITY))))
            ws = await find_workspace(session, workspace, lock=True) if workspace else None
            row = await self._row(session, rule_key, ws.id if ws is not None else None)
            if row is not None:
                add_audit(
                    session,
                    actor=actor,
                    action="risk.rule_reset",
                    entity_type=ENTITY,
                    entity_id=_entity_id(rule_key, ws.slug if ws is not None else None),
                    details={"before": {"enabled": row.is_enabled, "params": row.params}},
                    client_ip=client_ip,
                )
                await session.delete(row)
        return await self.get_rule(rule_key, workspace)

    async def _set(
        self,
        rule_key: str,
        *,
        workspace: str | None,
        enabled: bool | None = None,
        params: Mapping[str, Any] | None,
        actor: str,
        client_ip: str | None,
        action: str,
    ) -> RiskRuleView:
        rule = _rule(rule_key)
        if enabled is False and rule.mandatory:
            raise ValidationFailedError(
                f"{rule_key} is mandatory and cannot be disabled (tune its parameters instead)",
                code="risk_rule_mandatory",
            )
        if enabled is None and not params:
            raise ValidationFailedError(
                "Nothing to change: give enabled and/or params", code="risk_rule_no_change"
            )
        now = self._clock()
        async with self._db.transaction() as session:
            await session.execute(select(func.pg_advisory_xact_lock(func.hashtext(ENTITY))))
            ws = await find_workspace(session, workspace, lock=True) if workspace else None
            workspace_id, slug = (ws.id, ws.slug) if ws is not None else (None, None)
            rows = await _rows(session, workspace_id)
            current = resolve_policy([_override(item) for item in rows], workspace_id).get(rule_key)
            same_rule = [item for item in rows if item.rule_key == rule_key]
            row = next((item for item in same_rule if item.workspace_id == workspace_id), None)
            new_params = {**(row.params if row is not None else {}), **(params or {})}
            # Validate the stack the engine will see: the global row under a workspace row.
            below = [
                item.params for item in same_rule if workspace_id is not None and item.workspace_id is None
            ]
            try:
                merge_params(rule, *below, new_params)
            except ValidationError as exc:
                raise ValidationFailedError(
                    f"Invalid parameters for {rule_key}: {describe_error(exc)}",
                    code="risk_rule_params_invalid",
                    details={"params": new_params},
                ) from exc
            # A new row pins the currently effective enabled state unless one is given.
            new_enabled = (
                enabled if enabled is not None else (row.is_enabled if row is not None else current.enabled)
            )
            before = None if row is None else {"enabled": row.is_enabled, "params": row.params}
            after = {"enabled": new_enabled, "params": new_params}
            if before == after:
                return _view(current, slug, rows)
            if row is None:
                row = RiskRuleRow(rule_key=rule_key, workspace_id=workspace_id)
                session.add(row)
            row.is_enabled = new_enabled
            row.params = new_params
            row.updated_by = actor
            row.updated_at = now
            add_audit(
                session,
                actor=actor,
                action=action,
                entity_type=ENTITY,
                entity_id=_entity_id(rule_key, slug),
                details={"before": before, "after": after},
                client_ip=client_ip,
            )
            await session.flush()
            rows = await _rows(session, workspace_id)
            effective = resolve_policy([_override(item) for item in rows], workspace_id).get(rule_key)
            return _view(effective, slug, rows)

    @staticmethod
    async def _row(session: AsyncSession, rule_key: str, workspace_id: UUID | None) -> RiskRuleRow | None:
        query = select(RiskRuleRow).where(RiskRuleRow.rule_key == rule_key).with_for_update()
        if workspace_id is None:
            query = query.where(RiskRuleRow.workspace_id.is_(None))
        else:
            query = query.where(RiskRuleRow.workspace_id == workspace_id)
        return await session.scalar(query)


def _entity_id(rule_key: str, workspace_slug: str | None) -> str:
    return f"{rule_key}@{workspace_slug or 'global'}"


def _view(item: EffectiveRule, workspace_slug: str | None, rows: list[RiskRuleRow]) -> RiskRuleView:
    rule = item.rule
    matching = [row for row in rows if row.rule_key == rule.key]
    latest = max(matching, key=lambda row: row.workspace_id is not None, default=None)
    if item.params is not None:
        params = item.params.model_dump(mode="json")
    else:
        params = dict(latest.params) if latest is not None else {}
    return RiskRuleView(
        rule_key=rule.key,
        description=rule.description,
        mandatory=rule.mandatory,
        workspace_slug=workspace_slug,
        enabled=item.enabled,
        source=item.source,
        params=params,
        defaults=rule.params_model().model_dump(mode="json"),
        error=item.error,
        updated_by=latest.updated_by if latest is not None else None,
        updated_at=latest.updated_at if latest is not None else None,
    )
