"""Global kill switch. When engaged, the risk gate blocks every new actionable signal.

PostgreSQL (``system_flags``) is the source of truth; Redis holds a mirror the strategy worker
reads on the hot path. A missing mirror (e.g. after a Redis flush) is rebuilt from the database.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.clock import utc_now
from app.persistence.database import Database
from app.persistence.models import SystemFlagRow
from app.services.audit import add_audit
from app.streaming.redis_bus import Keys, RedisBus

FLAG_KEY = "kill_switch"
# The mirror expires so any stale copy (e.g. a failed write after commit) self-heals from the DB.
_MIRROR_TTL_SECONDS = 30.0


class KillSwitchState(BaseModel):
    engaged: bool
    reason: str | None = None
    updated_by: str | None = None
    updated_at: datetime | None = None


async def load_kill_switch(session: AsyncSession) -> KillSwitchState:
    """Read the flag in the caller's session (the signal engine checks it in its own transaction)."""
    row = await session.scalar(select(SystemFlagRow).where(SystemFlagRow.key == FLAG_KEY))
    if row is None:
        # Fail safe: a missing flag row means the schema was not seeded; block signals.
        return KillSwitchState(engaged=True, reason="kill switch flag missing from database")
    return KillSwitchState(
        engaged=bool(row.value.get("engaged", True)),
        reason=row.value.get("reason"),
        updated_by=row.updated_by,
        updated_at=row.updated_at,
    )


class KillSwitchService:
    def __init__(self, db: Database, bus: RedisBus) -> None:
        self._db = db
        self._bus = bus

    async def get(self) -> KillSwitchState:
        cached = await self._bus.get_json(Keys.KILL_SWITCH)
        if cached is not None:
            return KillSwitchState.model_validate(cached)
        state = await self._load()
        await self._bus.set_json(Keys.KILL_SWITCH, state, ttl_seconds=_MIRROR_TTL_SECONDS)
        return state

    async def _load(self) -> KillSwitchState:
        async with self._db.session() as session:
            return await load_kill_switch(session)

    async def set(
        self, *, engaged: bool, reason: str | None, actor: str, client_ip: str | None = None
    ) -> KillSwitchState:
        now = utc_now()
        # Drop the mirror first: if Redis is unavailable we fail before changing anything, and
        # readers fall back to the database until the new state is mirrored.
        await self._bus.delete(Keys.KILL_SWITCH)
        async with self._db.transaction() as session:
            row = await session.scalar(
                select(SystemFlagRow).where(SystemFlagRow.key == FLAG_KEY).with_for_update()
            )
            value = {"engaged": engaged, "reason": reason}
            if row is None:
                session.add(SystemFlagRow(key=FLAG_KEY, value=value, updated_by=actor, updated_at=now))
            else:
                row.value = value
                row.updated_by = actor
                row.updated_at = now
            add_audit(
                session,
                actor=actor,
                action="kill_switch.engage" if engaged else "kill_switch.release",
                entity_type="system_flag",
                entity_id=FLAG_KEY,
                details={"reason": reason},
                client_ip=client_ip,
            )
        state = KillSwitchState(engaged=engaged, reason=reason, updated_by=actor, updated_at=now)
        await self._bus.set_json(Keys.KILL_SWITCH, state, ttl_seconds=_MIRROR_TTL_SECONDS)
        return state
