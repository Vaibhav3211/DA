"""The instrument master: refreshing it from provider dumps, searching it, resolving subscriptions.

A refresh takes one provider's dump (downloaded, supplied by the operator, or the simulator's
built-in list), parses and canonicalises it off the event loop, applies it in one transaction with
an audit entry (``app.market_data.instruments.sync``) and then asks the workers to re-resolve their
subscriptions. Downloads are cached before they are parsed, so a refused or failing import can be
inspected and re-run offline (``qt instruments refresh --file``).
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from collections.abc import Callable, Collection, Sequence
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from itertools import batched
from pathlib import Path
from typing import Final, Self
from uuid import UUID

import httpx
from pydantic import Field
from sqlalchemy import ColumnElement, case, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.container import Container
from app.core.clock import IST, utc_now
from app.core.config import Settings
from app.core.errors import NotFoundError, ValidationFailedError
from app.core.logging import get_logger
from app.domain.enums import (
    AuthMethod,
    CredentialKind,
    Exchange,
    InstrumentType,
    OptionType,
    Provider,
    Segment,
    SubscriptionMode,
)
from app.domain.events import CommandType, WorkerCommand
from app.domain.models import Instrument, InstrumentMapping, ProviderInstrument
from app.domain.models.base import DomainModel
from app.market_data.instruments.cache import cache_dump
from app.market_data.instruments.canonical import PreparedDump, normalize_symbol, prepare
from app.market_data.instruments.sync import SyncStats, apply_dump
from app.persistence.database import Database
from app.persistence.models import InstrumentProviderMappingRow, InstrumentRow, ProviderAccountRow
from app.providers.base import describe_error
from app.providers.groww.client import GrowwRestClient
from app.providers.groww.instruments import parse_instrument_dump as parse_groww_dump
from app.providers.instrument_dump import MAX_DUMP_BYTES
from app.providers.simulator.instruments import synthetic_instrument_dump
from app.providers.zerodha.client import KiteRestClient
from app.providers.zerodha.instruments import parse_instrument_dump as parse_kite_dump
from app.services.audit import add_audit
from app.services.provider_accounts import ProviderAccountService, environment_credential, publish_command
from app.streaming.redis_bus import RedisBus

log = get_logger(__name__)

AUDIT_ACTION: Final = "instruments.refresh"
AUDIT_ENTITY: Final = "instrument_master"
SEARCH_LIMIT_MAX: Final = 500
_IN_CHUNK: Final = 5000
_SOURCE_INVALID: Final = "instrument_source_invalid"


class DumpSource(StrEnum):
    DOWNLOAD = "DOWNLOAD"  # fetched from the provider
    FILE = "FILE"  # supplied by the operator, e.g. a cached or manually downloaded copy
    BUILT_IN = "BUILT_IN"  # the simulator's synthetic instruments


class RefreshReport(DomainModel):
    provider: Provider
    source: DumpSource
    account_id: UUID | None  # the account whose credentials downloaded the dump
    rows: int
    accepted: int
    skipped: dict[str, int]
    stats: SyncStats
    forced: bool
    cache_path: str | None
    cache_error: str | None
    published: bool  # whether the workers were told to re-resolve their subscriptions
    duration_seconds: float


class InstrumentQuery(DomainModel):
    """Search filters. Every ``text`` term must appear in the symbol, the name or an active provider
    symbol. ``active=None`` returns active and inactive instruments."""

    text: str | None = Field(default=None, max_length=100)
    exchange: Exchange | None = None
    segment: Segment | None = None
    instrument_type: InstrumentType | None = None
    underlying: str | None = Field(default=None, max_length=80)
    expiry: date | None = None
    strike: Decimal | None = None
    option_type: OptionType | None = None
    provider: Provider | None = None  # listed (actively mapped) by this provider
    active: bool | None = True
    limit: int = Field(default=50, ge=1, le=SEARCH_LIMIT_MAX)
    offset: int = Field(default=0, ge=0)


class InstrumentHit(DomainModel):
    instrument: Instrument
    providers: tuple[Provider, ...]  # providers with an active mapping


class InstrumentPage(DomainModel):
    items: tuple[InstrumentHit, ...]
    has_more: bool


class InstrumentDetail(DomainModel):
    instrument: Instrument
    mappings: tuple[InstrumentMapping, ...]  # active first, then the newest closed ones


class ResolvedInstruments(DomainModel):
    found: tuple[ProviderInstrument, ...]  # in the order requested
    missing: tuple[UUID, ...]  # unknown, inactive, or not listed by the provider


def read_dump_file(path: Path) -> bytes:
    """An operator-supplied dump. For the CLI only: the API never reads paths on the server."""
    try:
        with path.open("rb") as handle:
            data = handle.read(MAX_DUMP_BYTES + 1)
    except OSError as exc:
        raise ValidationFailedError(
            f"Cannot read the instrument file {path}: {exc.strerror or exc}",
            code="instrument_file_unreadable",
        ) from None
    if len(data) > MAX_DUMP_BYTES:
        raise ValidationFailedError(
            f"The instrument file {path} is larger than {MAX_DUMP_BYTES} bytes",
            code="instrument_file_too_large",
        )
    return data


class InstrumentService:
    def __init__(
        self, accounts: ProviderAccountService, *, transport: httpx.AsyncBaseTransport | None = None
    ) -> None:
        self.accounts = accounts
        self._transport = transport  # tests inject an httpx.MockTransport

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(ProviderAccountService.from_container(container, clock=clock))

    @property
    def db(self) -> Database:
        return self.accounts.db

    @property
    def bus(self) -> RedisBus:
        return self.accounts.bus

    @property
    def settings(self) -> Settings:
        return self.accounts.settings

    @property
    def clock(self) -> Callable[[], datetime]:
        return self.accounts.clock

    # ---- refresh ----------------------------------------------------------------------------------

    async def refresh(
        self,
        provider: Provider,
        *,
        actor: str,
        data: bytes | None = None,
        file_name: str | None = None,
        account_id: UUID | None = None,
        force: bool = False,
        client_ip: str | None = None,
    ) -> RefreshReport:
        """Refresh ``provider``'s instruments from ``data`` (an operator-supplied dump) or a download
        (with ``account_id``'s credentials for Zerodha; by default the enabled account's).

        Raises ``ConflictError`` while another refresh of the provider runs or, unless ``force``,
        when the dump looks truncated. Provider errors propagate unchanged."""
        started = time.monotonic()
        now = self.clock()
        today = now.astimezone(IST).date()
        source = _source(provider, data, account_id)
        cache_path: str | None = None
        cache_error: str | None = None
        if source is DumpSource.BUILT_IN:
            prepared = prepare(synthetic_instrument_dump())
        else:
            if data is None:
                data, account_id = await self._download(provider, account_id)
                cache_path, cache_error = await self._cache(provider, data, now)
            prepared = await asyncio.to_thread(_parse, provider, data, today)
        async with self.db.transaction() as session:
            stats = await apply_dump(session, prepared, now=now, today=today, force=force)
            add_audit(
                session,
                actor=actor,
                action=AUDIT_ACTION,
                entity_type=AUDIT_ENTITY,
                entity_id=provider.value,
                details={
                    "source": source.value,
                    "file_name": file_name,
                    "account_id": None if account_id is None else str(account_id),
                    "rows": prepared.rows,
                    "accepted": len(prepared.entries),
                    "skipped": dict(prepared.skipped),
                    "stats": stats.model_dump(),
                    "forced": force,
                },
                client_ip=client_ip,
            )
        published = await publish_command(
            self.bus,
            WorkerCommand(type=CommandType.REFRESH_SUBSCRIPTIONS, provider=provider, issued_by=actor),
        )
        report = RefreshReport(
            provider=provider,
            source=source,
            account_id=account_id,
            rows=prepared.rows,
            accepted=len(prepared.entries),
            skipped=dict(prepared.skipped),
            stats=stats,
            forced=force,
            cache_path=cache_path,
            cache_error=cache_error,
            published=published,
            duration_seconds=round(time.monotonic() - started, 3),
        )
        log.info(
            "instruments_refreshed",
            provider=provider.value,
            source=source.value,
            rows=report.rows,
            accepted=report.accepted,
            forced=force,
            **stats.model_dump(),
        )
        return report

    async def _download(self, provider: Provider, account_id: UUID | None) -> tuple[bytes, UUID | None]:
        if provider is Provider.GROWW:
            async with GrowwRestClient(
                base_url=self.settings.groww_api_base_url, transport=self._transport, clock=self.clock
            ) as groww:
                return await groww.instruments_csv(self.settings.groww_instruments_url), None
        api_key, access_token, account_id = await self._kite_credentials(account_id)
        async with KiteRestClient(
            api_key=api_key,
            base_url=self.settings.zerodha_api_base_url,
            access_token=access_token,
            transport=self._transport,
            clock=self.clock,
        ) as kite:
            return await kite.instruments_csv(), account_id

    async def _kite_credentials(self, account_id: UUID | None) -> tuple[str, str | None, UUID | None]:
        """API key, a still-valid access token (sent when present), and the account they came from."""
        if account_id is None:
            async with self.db.session() as session:
                account_id = await session.scalar(
                    select(ProviderAccountRow.id).where(
                        ProviderAccountRow.provider == Provider.ZERODHA, ProviderAccountRow.is_enabled
                    )
                )
        if account_id is None:
            api_key = environment_credential(
                self.settings, AuthMethod.ZERODHA_LOGIN_REDIRECT, CredentialKind.API_KEY
            )
            if api_key is None:
                raise ValidationFailedError(
                    "Downloading the Zerodha instrument dump needs a Kite API key: enable a Zerodha "
                    "account, set ZERODHA_API_KEY, or import a downloaded dump from a file",
                    code="zerodha_api_key_missing",
                )
            return api_key, None, None
        secrets = await self.accounts.resolve_secrets(account_id, include_token=True)
        account = secrets.account
        if account.provider is not Provider.ZERODHA:
            raise ValidationFailedError(
                f"Account '{account.label}' is a {account.provider.value.title()} account, not a Zerodha one",
                code=_SOURCE_INVALID,
            )
        expires_at = account.token_expires_at
        valid = expires_at is not None and expires_at > self.clock()
        token = secrets.get(CredentialKind.ACCESS_TOKEN) if valid else None
        return secrets.require(CredentialKind.API_KEY), token, account.id

    async def _cache(self, provider: Provider, data: bytes, at: datetime) -> tuple[str | None, str | None]:
        """(path, error). Caching is best effort: a full disk must not block the refresh itself."""
        directory = self.settings.instrument_cache_dir.strip()
        if not directory:
            return None, None
        try:
            path = await asyncio.to_thread(cache_dump, Path(directory), provider, data, at=at)
        except OSError as exc:
            error = describe_error(exc)
            log.warning("instrument_dump_not_cached", provider=provider.value, error=error)
            return None, error
        return str(path), None

    # ---- reads ------------------------------------------------------------------------------------

    async def search(self, query: InstrumentQuery) -> InstrumentPage:
        """Exact symbol matches first, then prefix matches; cash before derivatives, which come by
        nearest expiry, then strike."""
        i = InstrumentRow
        needle = normalize_symbol(query.text or "")
        rank = [] if not needle else [_rank(needle)]
        statement = (
            select(i)
            .where(*_filters(query))
            .order_by(
                *rank,
                i.expiry.asc().nulls_first(),
                i.underlying.asc().nulls_first(),
                i.strike.asc().nulls_first(),
                i.option_type.asc().nulls_first(),
                i.symbol,
                i.id,
            )
            .offset(query.offset)
            .limit(query.limit + 1)
        )
        async with self.db.session() as session:
            rows = list((await session.scalars(statement)).all())
            page = rows[: query.limit]
            providers = await _active_providers(session, [row.id for row in page])
        return InstrumentPage(
            items=tuple(
                InstrumentHit(instrument=_instrument(row), providers=providers.get(row.id, ()))
                for row in page
            ),
            has_more=len(rows) > query.limit,
        )

    async def get(self, ref: UUID | str) -> InstrumentDetail:
        """An instrument by id or canonical key, with all its mappings."""
        m = InstrumentProviderMappingRow
        async with self.db.session() as session:
            row = await _find(session, ref)
            mappings = await session.scalars(
                select(m)
                .where(m.instrument_id == row.id)
                .order_by(m.is_active.desc(), m.valid_from.desc(), m.provider)
            )
            return InstrumentDetail(instrument=_instrument(row), mappings=tuple(map(_mapping, mappings)))

    async def resolve(
        self,
        instrument_ids: Sequence[UUID],
        provider: Provider,
        *,
        mode: SubscriptionMode = SubscriptionMode.QUOTE,
    ) -> ResolvedInstruments:
        """What ``provider``'s adapter needs to subscribe to each active instrument it lists."""
        i, m = InstrumentRow, InstrumentProviderMappingRow
        wanted = list(dict.fromkeys(instrument_ids))
        found: dict[UUID, ProviderInstrument] = {}
        async with self.db.session() as session:
            for chunk in batched(wanted, _IN_CHUNK):
                result = await session.execute(
                    select(m, i)
                    .join(i, i.id == m.instrument_id)
                    .where(m.instrument_id.in_(chunk), m.provider == provider, m.is_active, i.is_active)
                )
                for mapping, instrument in result:
                    found[instrument.id] = ProviderInstrument(
                        instrument_id=instrument.id,
                        provider=provider,
                        provider_token=mapping.provider_token,
                        exchange_token=mapping.exchange_token,
                        provider_symbol=mapping.provider_symbol,
                        provider_exchange=mapping.provider_exchange,
                        provider_segment=mapping.provider_segment,
                        exchange=instrument.exchange,
                        segment=instrument.segment,
                        instrument_type=instrument.instrument_type,
                        symbol=instrument.symbol,
                        expiry=instrument.expiry,
                        tick_size=instrument.tick_size,
                        mode=mode,
                    )
        return ResolvedInstruments(
            found=tuple(found[key] for key in wanted if key in found),
            missing=tuple(key for key in wanted if key not in found),
        )


def _source(provider: Provider, data: bytes | None, account_id: UUID | None) -> DumpSource:
    if provider is Provider.SIMULATOR:
        if data is not None or account_id is not None:
            raise ValidationFailedError(
                "The simulator's instruments are built in: it takes no file or account", code=_SOURCE_INVALID
            )
        return DumpSource.BUILT_IN
    if data is not None:
        if account_id is not None:
            raise ValidationFailedError(
                "An account is only used to download a dump, not to import a file", code=_SOURCE_INVALID
            )
        return DumpSource.FILE
    if provider is Provider.GROWW and account_id is not None:
        raise ValidationFailedError(
            "The Groww instrument master is public: downloading it needs no account", code=_SOURCE_INVALID
        )
    return DumpSource.DOWNLOAD


def _parse(provider: Provider, data: bytes, today: date) -> PreparedDump:
    """CPU-bound (a full dump has 100k+ rows): run it in a worker thread."""
    dump = parse_kite_dump(data) if provider is Provider.ZERODHA else parse_groww_dump(data, today=today)
    return prepare(dump)


def _filters(query: InstrumentQuery) -> list[ColumnElement[bool]]:
    i, m = InstrumentRow, InstrumentProviderMappingRow
    conditions: list[ColumnElement[bool]] = []
    if query.exchange is not None:
        conditions.append(i.exchange == query.exchange)
    if query.segment is not None:
        conditions.append(i.segment == query.segment)
    if query.instrument_type is not None:
        conditions.append(i.instrument_type == query.instrument_type)
    if query.underlying:
        conditions.append(i.underlying == normalize_symbol(query.underlying))
    if query.expiry is not None:
        conditions.append(i.expiry == query.expiry)
    if query.strike is not None:
        conditions.append(i.strike == query.strike)
    if query.option_type is not None:
        conditions.append(i.option_type == query.option_type)
    if query.active is not None:
        conditions.append(i.is_active == query.active)
    if query.provider is not None:
        conditions.append(
            select(m.id).where(m.instrument_id == i.id, m.provider == query.provider, m.is_active).exists()
        )
    for term in normalize_symbol(query.text or "").split():
        pattern = f"%{_escape_like(term)}%"
        conditions.append(
            or_(
                i.symbol.ilike(pattern, escape="\\"),
                i.name.ilike(pattern, escape="\\"),
                select(m.id)
                .where(m.instrument_id == i.id, m.is_active, m.provider_symbol.ilike(pattern, escape="\\"))
                .exists(),
            )
        )
    return conditions


def _rank(needle: str) -> ColumnElement[int]:
    i = InstrumentRow
    return case((i.symbol == needle, 0), (i.symbol.startswith(needle, autoescape=True), 1), else_=2)


def _escape_like(term: str) -> str:
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


async def _find(session: AsyncSession, ref: UUID | str) -> InstrumentRow:
    i = InstrumentRow
    if isinstance(ref, str):
        text = ref
        try:
            ref = UUID(text.strip())
        except ValueError:
            key = normalize_symbol(text)
            row = await session.scalar(select(i).where(i.canonical_key == key))
            if row is None:
                raise NotFoundError(
                    f"No instrument has the key '{key}'", code="instrument_not_found"
                ) from None
            return row
    found = await session.get(i, ref)
    if found is None:
        raise NotFoundError(f"No instrument has the id {ref}", code="instrument_not_found")
    return found


async def find_instrument(session: AsyncSession, ref: UUID | str) -> InstrumentRow:
    """An instrument by id or canonical key; ``NotFoundError`` when there is none."""
    return await _find(session, ref)


async def _active_providers(
    session: AsyncSession, instrument_ids: Collection[UUID]
) -> dict[UUID, tuple[Provider, ...]]:
    m = InstrumentProviderMappingRow
    if not instrument_ids:
        return {}
    result = await session.execute(
        select(m.instrument_id, m.provider).where(m.instrument_id.in_(instrument_ids), m.is_active)
    )
    providers: defaultdict[UUID, set[Provider]] = defaultdict(set)
    for instrument_id, provider in result:
        providers[instrument_id].add(provider)
    return {key: tuple(sorted(value)) for key, value in providers.items()}


def _instrument(row: InstrumentRow) -> Instrument:
    return Instrument.model_validate(row, from_attributes=True)


def _mapping(row: InstrumentProviderMappingRow) -> InstrumentMapping:
    return InstrumentMapping(
        id=row.id,
        instrument_id=row.instrument_id,
        provider=row.provider,
        provider_token=row.provider_token,
        exchange_token=row.exchange_token,
        provider_symbol=row.provider_symbol,
        provider_exchange=row.provider_exchange,
        provider_segment=row.provider_segment,
        is_active=row.is_active,
        valid_from=row.valid_from,
        valid_to=row.valid_to,
        metadata=row.provider_metadata,
    )
