"""Provider accounts: lifecycle, encrypted credentials, token state and connection history.

Credential values (API keys, API secrets, TOTP secrets and access tokens) are encrypted with the
application ``SecretBox`` and bound to ``provider_account:<id>:<kind>``, so a ciphertext copied to
another account or field fails to decrypt. Views expose only masked API keys and which kinds are
configured. Decrypted values leave this module only through ``session_credentials`` (for the
market-data worker) and ``resolve_secrets`` (for login flows); both stay in memory.

At most one account per provider is enabled, and the market-data worker streams only enabled
accounts. Changes that affect a running stream publish a best-effort worker command; the worker
also reconciles from the database, so a lost command only delays the change.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Collection, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from types import MappingProxyType
from typing import Self
from uuid import UUID

import sqlalchemy as sa
from pydantic import SecretStr
from redis.exceptions import RedisError
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.container import Container
from app.core.clock import utc_now
from app.core.config import AppEnv, Settings
from app.core.errors import ConflictError, NotFoundError, ServiceUnavailableError, ValidationFailedError
from app.core.logging import get_logger
from app.core.security import ENCRYPTION_NOT_CONFIGURED, EncryptionError, SecretBox, hash_token, mask_secret
from app.domain.enums import AccountStatus, AuthMethod, ConnectionState, CredentialKind, Provider
from app.domain.events import CommandType, WorkerCommand
from app.domain.models.base import DomainModel, UtcDatetime
from app.persistence.database import Database
from app.persistence.models import (
    ProviderAccountRow,
    ProviderConnectionEventRow,
    ProviderCredentialRow,
    ProviderTokenMetadataRow,
)
from app.persistence.models.common import stamp_updated
from app.providers import registry
from app.providers.base import CredentialSource, SessionCredentials, StateChange, describe_error
from app.providers.errors import ProviderAuthRequiredError, ProviderNotEnabledError
from app.providers.groww.totp import secret_bytes
from app.services.audit import SYSTEM_ACTOR, add_audit
from app.streaming.redis_bus import RedisBus, Streams

log = get_logger(__name__)

ENTITY = "provider_account"

_API_KEY = CredentialKind.API_KEY
_API_SECRET = CredentialKind.API_SECRET
_ACCESS_TOKEN = CredentialKind.ACCESS_TOKEN
_TOTP_SECRET = CredentialKind.TOTP_SECRET

# The first method of each provider is the default for new accounts.
_METHODS: Mapping[Provider, tuple[AuthMethod, ...]] = MappingProxyType(
    {
        Provider.ZERODHA: (AuthMethod.ZERODHA_LOGIN_REDIRECT,),
        Provider.GROWW: (
            AuthMethod.GROWW_ACCESS_TOKEN,
            AuthMethod.GROWW_API_KEY_SECRET,
            AuthMethod.GROWW_TOTP,
        ),
        Provider.SIMULATOR: (AuthMethod.NONE,),
    }
)
_STORABLE: Mapping[Provider, frozenset[CredentialKind]] = MappingProxyType(
    {
        Provider.ZERODHA: frozenset({_API_KEY, _API_SECRET}),
        Provider.GROWW: frozenset({_API_KEY, _API_SECRET, _TOTP_SECRET}),
        Provider.SIMULATOR: frozenset(),
    }
)
# The TOTP secret is optional: without it every token request needs a code from an authenticator.
_REQUIRED: Mapping[AuthMethod, tuple[CredentialKind, ...]] = MappingProxyType(
    {
        AuthMethod.ZERODHA_LOGIN_REDIRECT: (_API_KEY, _API_SECRET),
        AuthMethod.GROWW_ACCESS_TOKEN: (),
        AuthMethod.GROWW_API_KEY_SECRET: (_API_KEY, _API_SECRET),
        AuthMethod.GROWW_TOTP: (_API_KEY,),
        AuthMethod.NONE: (),
    }
)
_KIND_ORDER = (_API_KEY, _API_SECRET, _TOTP_SECRET)
_KIND_LABELS: Mapping[CredentialKind, str] = MappingProxyType(
    {
        _API_KEY: "API key",
        _API_SECRET: "API secret",
        _ACCESS_TOKEN: "access token",
        _TOTP_SECRET: "TOTP secret",
    }
)
_LABEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9 _.-]{0,79}")
_PRINTABLE = re.compile(r"[\x21-\x7e]{1,4096}")


def auth_methods(provider: Provider) -> tuple[AuthMethod, ...]:
    return _METHODS[provider]


def storable_kinds(provider: Provider) -> frozenset[CredentialKind]:
    return _STORABLE[provider]


def required_kinds(method: AuthMethod) -> tuple[CredentialKind, ...]:
    return _REQUIRED[method]


def credential_label(method: AuthMethod, kind: CredentialKind) -> str:
    if method is AuthMethod.GROWW_TOTP and kind is _API_KEY:
        return "TOTP token (API key)"
    return _KIND_LABELS[kind]


def renew_hint(method: AuthMethod) -> str:
    """What the user does to get a new access token."""
    if method is AuthMethod.ZERODHA_LOGIN_REDIRECT:
        return "log in again"
    if method is AuthMethod.GROWW_ACCESS_TOKEN:
        return "set a new access token"
    if method is AuthMethod.NONE:
        return "no login is needed"
    return "create a new access token"


def normalize_label(label: str) -> str:
    cleaned = " ".join(label.split())
    if not _LABEL.fullmatch(cleaned):
        raise ValidationFailedError(
            "Account labels have 1-80 characters (letters, digits, spaces, '.', '_' or '-') and start "
            "with a letter or digit",
            code="invalid_label",
        )
    return cleaned


def normalize_credential(kind: CredentialKind, value: str) -> str:
    """Canonical form of a credential value. Errors never echo the value."""
    if kind is _TOTP_SECRET:
        cleaned = re.sub(r"[\s-]+", "", value).upper()
        try:
            secret_bytes(cleaned)
        except ValidationFailedError as exc:
            message = exc.message[:1].upper() + exc.message[1:]
            raise ValidationFailedError(message, code="invalid_credential") from None
        return cleaned
    cleaned = value.strip()
    if not _PRINTABLE.fullmatch(cleaned):
        raise ValidationFailedError(
            f"The {_KIND_LABELS[kind]} must be 1-4096 printable characters without spaces",
            code="invalid_credential",
        )
    return cleaned


def environment_credential(settings: Settings, method: AuthMethod, kind: CredentialKind) -> str | None:
    """Deployment-level (.env) fallback for a credential the account does not store."""
    secret: SecretStr | None = None
    if method is AuthMethod.ZERODHA_LOGIN_REDIRECT:
        secret = {_API_KEY: settings.zerodha_api_key, _API_SECRET: settings.zerodha_api_secret}.get(kind)
    elif method is AuthMethod.GROWW_API_KEY_SECRET:
        secret = {_API_KEY: settings.groww_api_key, _API_SECRET: settings.groww_api_secret}.get(kind)
    if secret is None:
        return None
    return secret.get_secret_value().strip() or None


def _check_method(provider: Provider, method: AuthMethod) -> None:
    if method not in _METHODS[provider]:
        allowed = ", ".join(m.value for m in _METHODS[provider])
        raise ValidationFailedError(
            f"{provider.value} accounts support these auth methods: {allowed}",
            code="auth_method_not_supported",
        )


def _token_not_settable() -> ValidationFailedError:
    return ValidationFailedError(
        "Access tokens are managed by login and logout, not as account credentials",
        code="credential_kind_not_allowed",
    )


def _check_storable(provider: Provider, kinds: Collection[CredentialKind]) -> None:
    if _ACCESS_TOKEN in kinds:
        raise _token_not_settable()
    unsupported = [kind for kind in _KIND_ORDER if kind in kinds and kind not in _STORABLE[provider]]
    if unsupported:
        names = ", ".join(_KIND_LABELS[kind] for kind in unsupported)
        raise ValidationFailedError(
            f"{provider.value} accounts do not use: {names}", code="credential_kind_not_allowed"
        )


def _not_found(account_id: UUID) -> NotFoundError:
    return NotFoundError(f"Provider account {account_id} does not exist", code="provider_account_not_found")


def _label_taken(provider: Provider, label: str) -> ConflictError:
    return ConflictError(
        f"A {provider.value} account named '{label}' already exists", code="provider_account_label_taken"
    )


def _already_enabled(provider: Provider, other: str | None) -> ConflictError:
    which = "the enabled one" if other is None else f"'{other}'"
    return ConflictError(
        f"Only one {provider.value} account can be enabled; disable {which} first",
        code="provider_account_already_enabled",
    )


class CredentialVault:
    """Seals and opens credential values bound to their account and kind."""

    def __init__(self, box: SecretBox | None) -> None:
        self._box = box

    def require(self) -> SecretBox:
        if self._box is None:
            raise ServiceUnavailableError(ENCRYPTION_NOT_CONFIGURED, code="encryption_not_configured")
        return self._box

    @staticmethod
    def context(account_id: UUID, kind: CredentialKind) -> str:
        return f"provider_account:{account_id}:{kind.value.lower()}"

    def seal(self, account_id: UUID, kind: CredentialKind, value: str) -> tuple[str, str]:
        """(ciphertext, key id) for a value."""
        box = self.require()
        return box.encrypt(value, context=self.context(account_id, kind)), box.primary_key_id

    def try_open(self, row: ProviderCredentialRow) -> str | None:
        """The decrypted value, or None when no configured key can decrypt it."""
        if self._box is None:
            return None
        try:
            return self._box.decrypt(row.ciphertext, context=self.context(row.account_id, row.kind))
        except EncryptionError:
            return None


class CredentialOrigin(StrEnum):
    ACCOUNT = "ACCOUNT"  # encrypted in the database
    ENVIRONMENT = "ENVIRONMENT"  # deployment settings


@dataclass(frozen=True, slots=True)
class ResolvedCredential:
    value: str = field(repr=False)
    origin: CredentialOrigin


@dataclass(frozen=True, slots=True)
class AccountSecrets:
    """Decrypted credentials for one login flow. Held in memory only; never logged or returned."""

    account: ProviderAccountRow
    values: Mapping[CredentialKind, ResolvedCredential] = field(repr=False)
    unreadable: frozenset[CredentialKind] = frozenset()

    def get(self, kind: CredentialKind) -> str | None:
        resolved = self.values.get(kind)
        return None if resolved is None else resolved.value

    def require(self, kind: CredentialKind) -> str:
        value = self.get(kind)
        if value is not None:
            return value
        name = credential_label(self.account.auth_method, kind)
        if kind in self.unreadable:
            raise ConflictError(
                f"The stored {name} of '{self.account.label}' cannot be decrypted with the configured "
                "encryption keys; set it again",
                code="credential_unreadable",
            )
        raise ValidationFailedError(
            f"Account '{self.account.label}' has no {name}; add it first", code="credentials_missing"
        )


class CredentialInfo(DomainModel):
    kind: CredentialKind
    label: str
    origin: CredentialOrigin
    masked: str | None = None  # API keys only, e.g. "••••ab12"


class ProviderAccountView(DomainModel):
    id: UUID
    provider: Provider
    label: str
    auth_method: AuthMethod
    status: AccountStatus
    is_enabled: bool
    masked_api_key: str | None
    credentials: tuple[CredentialInfo, ...]
    missing_credentials: tuple[CredentialKind, ...]
    has_access_token: bool
    provider_user_ref: str | None
    last_auth_at: UtcDatetime | None
    token_expires_at: UtcDatetime | None
    last_connected_at: UtcDatetime | None
    last_disconnected_at: UtcDatetime | None
    last_error_code: str | None
    last_error_message: str | None
    streaming_disabled_reason: str | None
    created_by: str | None
    updated_by: str | None
    created_at: UtcDatetime
    updated_at: UtcDatetime


class RotationReport(DomainModel):
    primary_key_id: str
    examined: int
    rotated: int
    failed: tuple[str, ...]  # "<provider>/<label>:<kind>" entries no configured key could decrypt


class ProviderAccountService:
    def __init__(
        self,
        db: Database,
        bus: RedisBus,
        settings: Settings,
        secret_box: SecretBox | None,
        *,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self.db = db
        self.bus = bus
        self.settings = settings
        self.vault = CredentialVault(secret_box)
        self.clock = clock

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(container.db, container.bus, container.settings, container.secret_box, clock=clock)

    # ---- reads ----------------------------------------------------------------------------------

    async def list_accounts(self, provider: Provider | None = None) -> list[ProviderAccountView]:
        stmt = select(ProviderAccountRow).order_by(
            ProviderAccountRow.provider, func.lower(ProviderAccountRow.label)
        )
        if provider is not None:
            stmt = stmt.where(ProviderAccountRow.provider == provider)
        async with self.db.session() as session:
            rows = (await session.scalars(stmt)).all()
            kinds = await self._kinds_by_account(session, [row.id for row in rows])
        now = self.clock()
        return [self.view(row, kinds.get(row.id, frozenset()), now=now) for row in rows]

    async def get(self, account_id: UUID) -> ProviderAccountView:
        async with self.db.session() as session:
            row = await self._get_row(session, account_id)
            kinds = await self.credential_kinds(session, row.id)
        return self.view(row, kinds)

    async def resolve_ref(self, ref: str, *, provider: Provider | None = None) -> ProviderAccountView:
        """An account by id or label (exact label first, then case-insensitive)."""
        text = ref.strip()
        async with self.db.session() as session:
            row = await self._find_by_ref(session, text, provider)
            kinds = await self.credential_kinds(session, row.id)
        return self.view(row, kinds)

    async def _find_by_ref(
        self, session: AsyncSession, text: str, provider: Provider | None
    ) -> ProviderAccountRow:
        try:
            account_id: UUID | None = UUID(text)
        except ValueError:
            account_id = None
        if account_id is not None:
            row = await session.get(ProviderAccountRow, account_id)
            if row is not None and (provider is None or row.provider is provider):
                return row
        stmt = select(ProviderAccountRow).where(func.lower(ProviderAccountRow.label) == text.lower())
        if provider is not None:
            stmt = stmt.where(ProviderAccountRow.provider == provider)
        rows = list((await session.scalars(stmt)).all())
        matches = [row for row in rows if row.label == text] or rows
        if len(matches) > 1:
            providers = ", ".join(sorted(row.provider.value for row in matches))
            raise ConflictError(
                f"'{text}' matches accounts of several providers ({providers}); name the provider or "
                "use the account id",
                code="provider_account_ambiguous",
            )
        if not matches:
            raise NotFoundError(f"No provider account matches '{text}'", code="provider_account_not_found")
        return matches[0]

    # ---- lifecycle ------------------------------------------------------------------------------

    async def create(
        self,
        provider: Provider,
        label: str,
        *,
        auth_method: AuthMethod | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> ProviderAccountView:
        name = normalize_label(label)
        method = auth_method or _METHODS[provider][0]
        _check_method(provider, method)
        if provider is Provider.SIMULATOR and self.settings.app_env not in (
            AppEnv.DEVELOPMENT,
            AppEnv.REPLAY,
        ):
            raise ValidationFailedError(
                "Simulator accounts are only allowed when APP_ENV is development or replay",
                code="simulator_not_allowed",
            )
        now = self.clock()
        async with self.db.transaction() as session:
            await self._ensure_label_free(session, provider, name)
            row = ProviderAccountRow(
                provider=provider,
                label=name,
                auth_method=method,
                status=AccountStatus.AUTH_REQUIRED,
                is_enabled=False,
                created_by=actor[:64],
                updated_by=actor[:64],
                created_at=now,
                updated_at=now,
            )
            row.status = self._settled_status(row, frozenset())
            session.add(row)
            await self._flush_label(session, provider, name)
            add_audit(
                session,
                actor=actor,
                action="provider_account.create",
                entity_type=ENTITY,
                entity_id=row.id,
                details={"provider": provider.value, "label": name, "method": method.value},
                client_ip=client_ip,
            )
        return self.view(row, frozenset())

    async def update(
        self,
        account_id: UUID,
        *,
        label: str | None = None,
        auth_method: AuthMethod | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> ProviderAccountView:
        """Rename and/or change the auth method. Stored tokens stay valid either way."""
        name = None if label is None else normalize_label(label)
        async with self.db.transaction() as session:
            row = await self.lock_account(session, account_id)
            kinds = await self.credential_kinds(session, row.id)
            changes: dict[str, dict[str, str]] = {}
            if name is not None and name != row.label:
                if name.lower() != row.label.lower():
                    await self._ensure_label_free(session, row.provider, name, exclude=row.id)
                changes["label"] = {"from": row.label, "to": name}
                row.label = name
            if auth_method is not None and auth_method is not row.auth_method:
                _check_method(row.provider, auth_method)
                changes["method"] = {"from": row.auth_method.value, "to": auth_method.value}
                row.auth_method = auth_method
            if changes:
                row.status = self._settled_status(row, kinds)
                self.touch(row, actor)
                await self._flush_label(session, row.provider, row.label)
                add_audit(
                    session,
                    actor=actor,
                    action="provider_account.update",
                    entity_type=ENTITY,
                    entity_id=row.id,
                    details=changes,
                    client_ip=client_ip,
                )
        return self.view(row, kinds)

    async def set_enabled(
        self, account_id: UUID, enabled: bool, *, actor: str, client_ip: str | None = None
    ) -> ProviderAccountView:
        """Enable (stream) or disable an account. At most one account per provider is enabled."""
        async with self.db.transaction() as session:
            provider = await session.scalar(
                select(ProviderAccountRow.provider).where(ProviderAccountRow.id == account_id)
            )
            if provider is None:
                raise _not_found(account_id)
            # Lock every account of the provider in a fixed order so concurrent enables serialize.
            rows = (
                await session.scalars(
                    select(ProviderAccountRow)
                    .where(ProviderAccountRow.provider == provider)
                    .order_by(ProviderAccountRow.id)
                    .with_for_update()
                )
            ).all()
            row = next((r for r in rows if r.id == account_id), None)
            if row is None:
                raise _not_found(account_id)
            kinds = await self.credential_kinds(session, row.id)
            changed = row.is_enabled != enabled
            if changed:
                other = next((r for r in rows if r.is_enabled and r.id != row.id), None)
                if enabled and other is not None:
                    raise _already_enabled(provider, other.label)
                row.is_enabled = enabled
                self.touch(row, actor)
                try:
                    await session.flush()
                except IntegrityError:
                    raise _already_enabled(provider, None) from None
                add_audit(
                    session,
                    actor=actor,
                    action="provider_account.enable" if enabled else "provider_account.disable",
                    entity_type=ENTITY,
                    entity_id=row.id,
                    details={"provider": provider.value, "label": row.label},
                    client_ip=client_ip,
                )
        if changed:
            await self.notify(
                CommandType.CONNECT_ACCOUNT if enabled else CommandType.DISCONNECT_ACCOUNT, row, actor
            )
        return self.view(row, kinds)

    async def delete(self, account_id: UUID, *, actor: str, client_ip: str | None = None) -> None:
        """Remove the account and its stored credentials.

        Local only: log out first to also revoke a Zerodha session at the provider.
        """
        async with self.db.transaction() as session:
            row = await self.lock_account(session, account_id)
            was_enabled = row.is_enabled
            provider = row.provider
            add_audit(
                session,
                actor=actor,
                action="provider_account.delete",
                entity_type=ENTITY,
                entity_id=row.id,
                details={"provider": provider.value, "label": row.label, "was_enabled": was_enabled},
                client_ip=client_ip,
            )
            await session.execute(sa.delete(ProviderAccountRow).where(ProviderAccountRow.id == account_id))
        if was_enabled:
            await publish_command(
                self.bus,
                WorkerCommand(
                    type=CommandType.DISCONNECT_ACCOUNT,
                    provider=provider,
                    account_id=account_id,
                    issued_by=actor,
                ),
            )

    # ---- credentials ----------------------------------------------------------------------------

    async def set_credentials(
        self,
        account_id: UUID,
        values: Mapping[CredentialKind, str],
        *,
        actor: str,
        client_ip: str | None = None,
    ) -> ProviderAccountView:
        """Store (encrypt) credential values, replacing existing ones of the same kind."""
        if not values:
            raise ValidationFailedError("No credentials were given", code="credentials_missing")
        if _ACCESS_TOKEN in values:
            raise _token_not_settable()
        self.vault.require()
        logged_out = False
        async with self.db.transaction() as session:
            row = await self.lock_account(session, account_id)
            _check_storable(row.provider, values.keys())
            normalized = {kind: normalize_credential(kind, value) for kind, value in values.items()}
            stored = await self.credential_rows(session, row.id)
            key_changed = (
                row.provider is Provider.ZERODHA
                and _API_KEY in normalized
                and self._effective_value(row, stored, _API_KEY) != normalized[_API_KEY]
            )
            now = self.clock()
            for kind, value in normalized.items():
                ciphertext, key_id = self.vault.seal(row.id, kind, value)
                existing = stored.get(kind)
                if existing is None:
                    session.add(
                        ProviderCredentialRow(
                            account_id=row.id,
                            kind=kind,
                            ciphertext=ciphertext,
                            key_id=key_id,
                            created_at=now,
                            updated_at=now,
                        )
                    )
                else:
                    existing.ciphertext = ciphertext
                    existing.key_id = key_id
                    stamp_updated(existing, now)
            if _API_KEY in normalized:
                row.masked_api_key = mask_secret(normalized[_API_KEY])
            kinds = frozenset(stored) | frozenset(normalized)
            if key_changed and _ACCESS_TOKEN in kinds:
                # A Kite access token belongs to the API key that created it.
                await self.drop_access_token(session, row, reason="API key changed", actor=actor)
                kinds -= {_ACCESS_TOKEN}
                logged_out = True
            row.status = self._settled_status(row, kinds)
            self.touch(row, actor, now)
            add_audit(
                session,
                actor=actor,
                action="provider_account.credentials_set",
                entity_type=ENTITY,
                entity_id=row.id,
                details={
                    "kinds": [k.value for k in _KIND_ORDER if k in normalized],
                    "logged_out": logged_out,
                },
                client_ip=client_ip,
            )
        if logged_out and row.is_enabled:
            await self.notify(CommandType.DISCONNECT_ACCOUNT, row, actor)
        return self.view(row, kinds)

    async def clear_credentials(
        self,
        account_id: UUID,
        kinds: Collection[CredentialKind] | None = None,
        *,
        actor: str,
        client_ip: str | None = None,
    ) -> ProviderAccountView:
        """Remove stored credentials (all storable kinds when ``kinds`` is None)."""
        if kinds is not None and _ACCESS_TOKEN in kinds:
            raise _token_not_settable()
        logged_out = False
        async with self.db.transaction() as session:
            row = await self.lock_account(session, account_id)
            targets = _STORABLE[row.provider] if kinds is None else frozenset(kinds)
            _check_storable(row.provider, targets)
            stored = await self.credential_rows(session, row.id)
            removed = [kind for kind in _KIND_ORDER if kind in targets and kind in stored]
            if not removed:
                return self.view(row, frozenset(stored))
            zerodha = row.provider is Provider.ZERODHA
            old_key = self._effective_value(row, stored, _API_KEY) if zerodha else None
            await session.execute(
                sa.delete(ProviderCredentialRow).where(
                    ProviderCredentialRow.account_id == row.id, ProviderCredentialRow.kind.in_(removed)
                )
            )
            remaining = {kind: cred for kind, cred in stored.items() if kind not in removed}
            remaining_kinds = frozenset(remaining)
            if _API_KEY in removed:
                row.masked_api_key = None
            if (
                zerodha
                and _ACCESS_TOKEN in remaining_kinds
                and self._effective_value(row, remaining, _API_KEY) != old_key
            ):
                # A Kite access token belongs to the API key that created it.
                await self.drop_access_token(session, row, reason="API key removed", actor=actor)
                remaining_kinds -= {_ACCESS_TOKEN}
                logged_out = True
            row.status = self._settled_status(row, remaining_kinds)
            self.touch(row, actor)
            add_audit(
                session,
                actor=actor,
                action="provider_account.credentials_cleared",
                entity_type=ENTITY,
                entity_id=row.id,
                details={"kinds": [kind.value for kind in removed], "logged_out": logged_out},
                client_ip=client_ip,
            )
        if logged_out and row.is_enabled:
            await self.notify(CommandType.DISCONNECT_ACCOUNT, row, actor)
        return self.view(row, remaining_kinds)

    # ---- encryption keys and token expiry --------------------------------------------------------

    async def rotate_encryption(self, *, actor: str, client_ip: str | None = None) -> RotationReport:
        """Re-encrypt every stored credential with the primary key.

        Keep the previous key configured until a run reports no failures.
        """
        box = self.vault.require()
        examined = rotated = 0
        failed: list[str] = []
        async with self.db.transaction() as session:
            result = await session.execute(
                select(ProviderCredentialRow, ProviderAccountRow.provider, ProviderAccountRow.label)
                .join(ProviderAccountRow, ProviderAccountRow.id == ProviderCredentialRow.account_id)
                .order_by(ProviderAccountRow.provider, ProviderAccountRow.label, ProviderCredentialRow.kind)
                .with_for_update(of=ProviderCredentialRow)
            )
            now = self.clock()
            for cred, provider, label in result:
                examined += 1
                if not box.needs_rotation(cred.ciphertext):
                    continue
                context = self.vault.context(cred.account_id, cred.kind)
                try:
                    plaintext = box.decrypt(cred.ciphertext, context=context)
                except EncryptionError:
                    failed.append(f"{provider.value}/{label}:{cred.kind.value}")
                    continue
                cred.ciphertext = box.encrypt(plaintext, context=context)
                cred.key_id = box.primary_key_id
                stamp_updated(cred, now)
                rotated += 1
            add_audit(
                session,
                actor=actor,
                action="provider_credentials.rotate",
                entity_type="provider_credentials",
                details={
                    "primary_key_id": box.primary_key_id,
                    "examined": examined,
                    "rotated": rotated,
                    "failed": failed,
                },
                client_ip=client_ip,
            )
        return RotationReport(
            primary_key_id=box.primary_key_id, examined=examined, rotated=rotated, failed=tuple(failed)
        )

    async def expire_tokens(self) -> list[UUID]:
        """Move authenticated accounts whose access token has expired to a login-required status.

        Run periodically by the worker so statuses and alerts stay accurate without a live stream.
        """
        now = self.clock()
        async with self.db.transaction() as session:
            rows = (
                await session.scalars(
                    select(ProviderAccountRow)
                    .where(
                        ProviderAccountRow.status == AccountStatus.AUTHENTICATED,
                        ProviderAccountRow.provider != Provider.SIMULATOR,
                        or_(
                            ProviderAccountRow.token_expires_at.is_(None),
                            ProviderAccountRow.token_expires_at <= now,
                        ),
                    )
                    .order_by(ProviderAccountRow.id)
                    .with_for_update(skip_locked=True)
                )
            ).all()
            for row in rows:
                await self._expire(session, row, await self.credential_kinds(session, row.id), now=now)
        return [row.id for row in rows]

    async def _expire(
        self,
        session: AsyncSession,
        row: ProviderAccountRow,
        kinds: frozenset[CredentialKind],
        *,
        now: datetime,
    ) -> None:
        """Forget an expired access token. ``token_expires_at`` stays so alerts can say when."""
        await session.execute(
            sa.delete(ProviderCredentialRow).where(
                ProviderCredentialRow.account_id == row.id, ProviderCredentialRow.kind == _ACCESS_TOKEN
            )
        )
        remaining = kinds - {_ACCESS_TOKEN}
        missing = self.missing_credentials(row, remaining)
        row.status = AccountStatus.NEEDS_CREDENTIALS if missing else AccountStatus.AUTH_REQUIRED
        row.last_error_code = "token_expired"
        row.last_error_message = f"The access token expired; {renew_hint(row.auth_method)}"
        stamp_updated(row, now)
        expires_at = row.token_expires_at
        add_audit(
            session,
            actor=SYSTEM_ACTOR,
            action="provider_account.token_expired",
            entity_type=ENTITY,
            entity_id=row.id,
            details={
                "provider": row.provider.value,
                "label": row.label,
                "expires_at": None if expires_at is None else expires_at.isoformat(),
            },
        )

    # ---- decrypted access -------------------------------------------------------------------------

    async def session_credentials(self, account_id: UUID) -> SessionCredentials:
        """Credentials for one market-data connection attempt (the worker's ``CredentialSource``)."""
        now = self.clock()
        async with self.db.session() as session:
            row = await session.get(ProviderAccountRow, account_id)
            if row is None:
                raise _not_found(account_id)
            if not row.is_enabled:
                raise ProviderNotEnabledError(f"Provider account '{row.label}' is disabled")
            if row.provider is Provider.SIMULATOR:
                raise ValidationFailedError(
                    "Simulator accounts have no credentials", code="credentials_not_applicable"
                )
            stored = await self.credential_rows(session, row.id)
        token_row = stored.get(_ACCESS_TOKEN)
        expires_at = row.token_expires_at
        if token_row is None or expires_at is None or expires_at <= now:
            raise ProviderAuthRequiredError(self._login_hint(row))
        self.vault.require()
        token = self.vault.try_open(token_row)
        if token is None:
            raise ProviderAuthRequiredError(
                f"The stored access token of '{row.label}' cannot be decrypted with the configured "
                f"encryption keys; {renew_hint(row.auth_method)}"
            )
        api_key: str | None = None
        if row.provider is Provider.ZERODHA:
            api_key = self._effective_value(row, stored, _API_KEY)
            if api_key is None:
                raise ProviderAuthRequiredError(
                    f"Account '{row.label}' has no usable API key; set it and {renew_hint(row.auth_method)}"
                )
        return SessionCredentials(
            access_token=token, api_key=api_key, expires_at=expires_at, user_ref=row.provider_user_ref
        )

    def credential_source(self, account_id: UUID) -> CredentialSource:
        async def load() -> SessionCredentials:
            return await self.session_credentials(account_id)

        return load

    async def resolve_secrets(self, account_id: UUID, *, include_token: bool = False) -> AccountSecrets:
        """Decrypted credentials for a login flow. Stored values win over deployment settings."""
        async with self.db.session() as session:
            row = await self._get_row(session, account_id)
            stored = await self.credential_rows(session, row.id)
        if stored:
            self.vault.require()
        values: dict[CredentialKind, ResolvedCredential] = {}
        unreadable: set[CredentialKind] = set()
        for kind in _KIND_ORDER + ((_ACCESS_TOKEN,) if include_token else ()):
            cred = stored.get(kind)
            if cred is not None:
                value = self.vault.try_open(cred)
                if value is None:
                    unreadable.add(kind)
                else:
                    values[kind] = ResolvedCredential(value, CredentialOrigin.ACCOUNT)
                continue
            env = self._env_value(row, kind)
            if env is not None:
                values[kind] = ResolvedCredential(env, CredentialOrigin.ENVIRONMENT)
        return AccountSecrets(row, MappingProxyType(values), frozenset(unreadable))

    # ---- connection history -----------------------------------------------------------------------

    async def record_state_change(self, change: StateChange) -> None:
        """Persist a stream state change and fold it into the account's status."""
        async with self.db.transaction() as session:
            row = None
            if change.account_id is not None:
                row = await session.get(
                    ProviderAccountRow, change.account_id, with_for_update=True, populate_existing=True
                )
            session.add(
                ProviderConnectionEventRow(
                    provider=change.provider,
                    account_id=None if row is None else row.id,
                    stream_id=change.stream_id[:120],
                    previous_state=change.previous,
                    state=change.state,
                    reason=change.reason[:300],
                    actor=SYSTEM_ACTOR,
                    occurred_at=change.occurred_at,
                )
            )
            if row is not None:
                now = self.clock()
                await self._apply_state_change(session, row, change, now=now)
                if session.is_modified(row):
                    stamp_updated(row, now)

    async def _apply_state_change(
        self, session: AsyncSession, row: ProviderAccountRow, change: StateChange, *, now: datetime
    ) -> None:
        if change.state is ConnectionState.CONNECTED:
            row.last_connected_at = change.occurred_at
            row.last_error_code = None
            row.last_error_message = None
            # The stored token works again (the earlier rejection was transient).
            if row.status in (
                AccountStatus.AUTH_REQUIRED,
                AccountStatus.NEEDS_CREDENTIALS,
            ) and self._token_valid(row, await self.credential_kinds(session, row.id), now):
                row.status = AccountStatus.AUTHENTICATED
            return
        if change.previous is ConnectionState.CONNECTED:
            row.last_disconnected_at = change.occurred_at
        if change.state is not ConnectionState.AUTH_REQUIRED or row.provider is Provider.SIMULATOR:
            return
        if row.last_auth_at is not None and row.last_auth_at > change.occurred_at:
            return  # a later login already replaced the rejected token
        if row.status is AccountStatus.AUTHENTICATED:
            kinds = await self.credential_kinds(session, row.id)
            expires_at = row.token_expires_at
            if _ACCESS_TOKEN in kinds and expires_at is not None and expires_at <= now:
                await self._expire(session, row, kinds, now=now)
                return
            # Keep the token: the rejection may be transient, and a later connect self-heals.
            missing = self.missing_credentials(row, kinds)
            row.status = AccountStatus.NEEDS_CREDENTIALS if missing else AccountStatus.AUTH_REQUIRED
            add_audit(
                session,
                actor=SYSTEM_ACTOR,
                action="provider_account.auth_lost",
                entity_type=ENTITY,
                entity_id=row.id,
                details={"provider": row.provider.value, "label": row.label, "reason": change.reason[:300]},
            )
        row.last_error_code = "auth_required"
        row.last_error_message = change.reason[:500]

    # ---- tokens (used by the login flows in provider_auth) ---------------------------------------

    async def store_access_token(
        self,
        session: AsyncSession,
        row: ProviderAccountRow,
        *,
        token: str,
        expires_at: datetime | None,
        user_ref: str | None,
        actor: str,
        auth_method: AuthMethod | None = None,
    ) -> None:
        """Encrypt and store a new access token, revoking the previous one. The caller holds the lock."""
        now = self.clock()
        ciphertext, key_id = self.vault.seal(row.id, _ACCESS_TOKEN, token)
        existing = await session.scalar(
            select(ProviderCredentialRow).where(
                ProviderCredentialRow.account_id == row.id, ProviderCredentialRow.kind == _ACCESS_TOKEN
            )
        )
        if existing is None:
            session.add(
                ProviderCredentialRow(
                    account_id=row.id,
                    kind=_ACCESS_TOKEN,
                    ciphertext=ciphertext,
                    key_id=key_id,
                    created_at=now,
                    updated_at=now,
                )
            )
        else:
            existing.ciphertext = ciphertext
            existing.key_id = key_id
            stamp_updated(existing, now)
        await self._revoke_tokens(session, row.id, reason="replaced by a new token", actor=actor, now=now)
        session.add(
            ProviderTokenMetadataRow(
                account_id=row.id,
                token_kind=_ACCESS_TOKEN,
                auth_method=auth_method or row.auth_method,
                fingerprint=hash_token(token)[:16],
                issued_at=now,
                expires_at=expires_at,
            )
        )
        row.status = AccountStatus.AUTHENTICATED
        row.last_auth_at = now
        row.token_expires_at = expires_at
        if user_ref is not None:
            row.provider_user_ref = user_ref[:64]
        row.last_error_code = None
        row.last_error_message = None
        self.touch(row, actor, now)

    async def drop_access_token(
        self, session: AsyncSession, row: ProviderAccountRow, *, reason: str, actor: str
    ) -> bool:
        """Delete the stored access token and revoke its metadata. True when a token was stored."""
        result = await session.execute(
            sa.delete(ProviderCredentialRow)
            .where(ProviderCredentialRow.account_id == row.id, ProviderCredentialRow.kind == _ACCESS_TOKEN)
            .returning(ProviderCredentialRow.id)
        )
        removed = result.first() is not None
        await self._revoke_tokens(session, row.id, reason=reason, actor=actor, now=self.clock())
        row.token_expires_at = None
        return removed

    @staticmethod
    async def _revoke_tokens(
        session: AsyncSession, account_id: UUID, *, reason: str, actor: str, now: datetime
    ) -> None:
        await session.execute(
            sa.update(ProviderTokenMetadataRow)
            .where(
                ProviderTokenMetadataRow.account_id == account_id,
                ProviderTokenMetadataRow.revoked_at.is_(None),
                or_(ProviderTokenMetadataRow.expires_at.is_(None), ProviderTokenMetadataRow.expires_at > now),
            )
            .values(revoked_at=now, revoked_by=actor[:64], revoke_reason=reason[:200])
        )

    # ---- queries ----------------------------------------------------------------------------------

    @staticmethod
    async def lock_account(session: AsyncSession, account_id: UUID) -> ProviderAccountRow:
        row = await session.get(ProviderAccountRow, account_id, with_for_update=True, populate_existing=True)
        if row is None:
            raise _not_found(account_id)
        return row

    @staticmethod
    async def _get_row(session: AsyncSession, account_id: UUID) -> ProviderAccountRow:
        row = await session.get(ProviderAccountRow, account_id)
        if row is None:
            raise _not_found(account_id)
        return row

    @staticmethod
    async def credential_rows(
        session: AsyncSession, account_id: UUID
    ) -> dict[CredentialKind, ProviderCredentialRow]:
        rows = await session.scalars(
            select(ProviderCredentialRow).where(ProviderCredentialRow.account_id == account_id)
        )
        return {row.kind: row for row in rows}

    @staticmethod
    async def credential_kinds(session: AsyncSession, account_id: UUID) -> frozenset[CredentialKind]:
        kinds = await session.scalars(
            select(ProviderCredentialRow.kind).where(ProviderCredentialRow.account_id == account_id)
        )
        return frozenset(kinds)

    @staticmethod
    async def _kinds_by_account(
        session: AsyncSession, account_ids: Sequence[UUID]
    ) -> dict[UUID, frozenset[CredentialKind]]:
        if not account_ids:
            return {}
        result = await session.execute(
            select(ProviderCredentialRow.account_id, ProviderCredentialRow.kind).where(
                ProviderCredentialRow.account_id.in_(account_ids)
            )
        )
        grouped: dict[UUID, set[CredentialKind]] = {}
        for account_id, kind in result:
            grouped.setdefault(account_id, set()).add(kind)
        return {account_id: frozenset(kinds) for account_id, kinds in grouped.items()}

    async def _ensure_label_free(
        self, session: AsyncSession, provider: Provider, label: str, *, exclude: UUID | None = None
    ) -> None:
        stmt = select(ProviderAccountRow.id).where(
            ProviderAccountRow.provider == provider, func.lower(ProviderAccountRow.label) == label.lower()
        )
        if exclude is not None:
            stmt = stmt.where(ProviderAccountRow.id != exclude)
        if await session.scalar(stmt.limit(1)) is not None:
            raise _label_taken(provider, label)

    @staticmethod
    async def _flush_label(session: AsyncSession, provider: Provider, label: str) -> None:
        try:
            await session.flush()
        except IntegrityError:
            raise _label_taken(provider, label) from None

    # ---- status and views -------------------------------------------------------------------------

    def missing_credentials(
        self, row: ProviderAccountRow, kinds: Collection[CredentialKind]
    ) -> tuple[CredentialKind, ...]:
        """Required kinds the account neither stores nor gets from deployment settings."""
        return tuple(
            kind
            for kind in _REQUIRED[row.auth_method]
            if kind not in kinds and self._env_value(row, kind) is None
        )

    def _env_value(self, row: ProviderAccountRow, kind: CredentialKind) -> str | None:
        return environment_credential(self.settings, row.auth_method, kind)

    def _effective_value(
        self,
        row: ProviderAccountRow,
        stored: Mapping[CredentialKind, ProviderCredentialRow],
        kind: CredentialKind,
    ) -> str | None:
        """The value a login would use: the stored one (None if undecryptable), else the setting."""
        cred = stored.get(kind)
        if cred is not None:
            return self.vault.try_open(cred)
        return self._env_value(row, kind)

    @staticmethod
    def _token_valid(row: ProviderAccountRow, kinds: Collection[CredentialKind], now: datetime) -> bool:
        expires_at = row.token_expires_at
        return _ACCESS_TOKEN in kinds and expires_at is not None and expires_at > now

    def _settled_status(self, row: ProviderAccountRow, kinds: Collection[CredentialKind]) -> AccountStatus:
        """Status after a configuration change, with ``kinds`` the credentials now stored."""
        if row.provider is Provider.SIMULATOR:
            return AccountStatus.AUTHENTICATED
        if row.status is AccountStatus.AUTHENTICATED and _ACCESS_TOKEN in kinds:
            return AccountStatus.AUTHENTICATED
        if self.missing_credentials(row, kinds):
            return AccountStatus.NEEDS_CREDENTIALS
        if row.status is AccountStatus.DISCONNECTED:
            return AccountStatus.DISCONNECTED
        return AccountStatus.AUTH_REQUIRED

    def _effective_status(
        self, row: ProviderAccountRow, kinds: Collection[CredentialKind], now: datetime
    ) -> AccountStatus:
        """The stored status, corrected for a token that expired since the last expiry sweep."""
        if (
            row.status is AccountStatus.AUTHENTICATED
            and row.provider is not Provider.SIMULATOR
            and not self._token_valid(row, kinds, now)
        ):
            if self.missing_credentials(row, kinds):
                return AccountStatus.NEEDS_CREDENTIALS
            return AccountStatus.AUTH_REQUIRED
        return row.status

    def _login_hint(self, row: ProviderAccountRow) -> str:
        renew = renew_hint(row.auth_method)
        if row.status is AccountStatus.DISCONNECTED:
            return f"Account '{row.label}' was logged out; {renew}"
        if row.status is AccountStatus.NEEDS_CREDENTIALS:
            return f"Account '{row.label}' is missing credentials; add them, then {renew}"
        return f"Account '{row.label}' has no valid access token; {renew}"

    def touch(self, row: ProviderAccountRow, actor: str, now: datetime | None = None) -> None:
        row.updated_by = actor[:64]
        stamp_updated(row, now or self.clock())

    def view(
        self, row: ProviderAccountRow, kinds: Collection[CredentialKind], *, now: datetime | None = None
    ) -> ProviderAccountView:
        now = now or self.clock()
        credentials: list[CredentialInfo] = []
        for kind in _KIND_ORDER:
            if kind not in _STORABLE[row.provider]:
                continue
            label = credential_label(row.auth_method, kind)
            if kind in kinds:
                masked = row.masked_api_key if kind is _API_KEY else None
                credentials.append(
                    CredentialInfo(kind=kind, label=label, origin=CredentialOrigin.ACCOUNT, masked=masked)
                )
                continue
            env = self._env_value(row, kind)
            if env is not None:
                masked = mask_secret(env) if kind is _API_KEY else None
                credentials.append(
                    CredentialInfo(kind=kind, label=label, origin=CredentialOrigin.ENVIRONMENT, masked=masked)
                )
        masked_key = next((info.masked for info in credentials if info.kind is _API_KEY), None)
        return ProviderAccountView(
            id=row.id,
            provider=row.provider,
            label=row.label,
            auth_method=row.auth_method,
            status=self._effective_status(row, kinds, now),
            is_enabled=row.is_enabled,
            masked_api_key=masked_key,
            credentials=tuple(credentials),
            missing_credentials=self.missing_credentials(row, kinds),
            has_access_token=_ACCESS_TOKEN in kinds,
            provider_user_ref=row.provider_user_ref,
            last_auth_at=row.last_auth_at,
            token_expires_at=row.token_expires_at,
            last_connected_at=row.last_connected_at,
            last_disconnected_at=row.last_disconnected_at,
            last_error_code=row.last_error_code,
            last_error_message=row.last_error_message,
            streaming_disabled_reason=registry.disabled_reason(row.provider, self.settings),
            created_by=row.created_by,
            updated_by=row.updated_by,
            created_at=row.created_at,
            updated_at=row.updated_at,
        )

    async def notify(self, command: CommandType, row: ProviderAccountRow, actor: str) -> bool:
        return await publish_command(
            self.bus, WorkerCommand(type=command, provider=row.provider, account_id=row.id, issued_by=actor)
        )


class AccountConnectionObserver:
    """``StreamObserver`` that records connection history and keeps account statuses current."""

    def __init__(self, accounts: ProviderAccountService) -> None:
        self._accounts = accounts

    async def on_state_change(self, change: StateChange) -> None:
        await self._accounts.record_state_change(change)


async def publish_command(bus: RedisBus, command: WorkerCommand) -> bool:
    """Best effort: the worker also reconciles from the database, so a lost command only delays."""
    try:
        await bus.publish(Streams.COMMANDS, command)
    except (RedisError, OSError) as exc:
        log.warning(
            "worker_command_not_published",
            command=command.type.value,
            account_id=None if command.account_id is None else str(command.account_id),
            error=describe_error(exc),
        )
        return False
    return True
