"""Append-only audit trail for security-relevant and configuration actions."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import current_correlation_id, get_logger, redact_value
from app.persistence.models import AuditLogRow

log = get_logger(__name__)

SYSTEM_ACTOR = "system"
CLI_ACTOR = "cli"


def add_audit(
    session: AsyncSession,
    *,
    actor: str,
    action: str,
    entity_type: str,
    entity_id: object | None = None,
    details: Mapping[str, Any] | None = None,
    client_ip: str | None = None,
) -> AuditLogRow:
    """Stage an audit record in the caller's transaction (committed or rolled back with it)."""
    sanitized = redact_value(None, dict(details or {}))
    row = AuditLogRow(
        actor=actor[:64],
        action=action,
        entity_type=entity_type,
        entity_id=None if entity_id is None else str(entity_id)[:80],
        details=sanitized,
        correlation_id=current_correlation_id(),
        client_ip=client_ip,
    )
    session.add(row)
    log.info("audit", action=action, entity_type=entity_type, entity_id=row.entity_id, actor=row.actor)
    return row
