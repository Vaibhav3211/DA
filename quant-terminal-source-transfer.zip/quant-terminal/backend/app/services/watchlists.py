"""Watchlists: named, ordered lists of instruments within a workspace.

A watchlist is for viewing only and subscribes nothing. Live data flows for the instruments in the
workspace's universe; each item says whether its instrument is in the universe.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Sequence
from datetime import datetime
from typing import Self
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.container import Container
from app.core.clock import utc_now
from app.core.errors import ConflictError, NotFoundError, ValidationFailedError
from app.domain.models import Instrument
from app.domain.models.base import DomainModel, UtcDatetime
from app.persistence.database import Database
from app.persistence.models import (
    InstrumentRow,
    WatchlistItemRow,
    WatchlistRow,
    WorkspaceInstrumentRow,
    WorkspaceRow,
)
from app.persistence.models.common import stamp_updated
from app.services.audit import add_audit
from app.services.workspaces import find_workspace

MAX_WATCHLISTS_PER_WORKSPACE = 50
MAX_WATCHLIST_ITEMS = 500
MAX_NAME_LENGTH = 80


class WatchlistItemView(DomainModel):
    instrument: Instrument
    sort_order: int
    added_at: UtcDatetime
    in_universe: bool  # whether the workspace streams this instrument


class WatchlistView(DomainModel):
    id: UUID
    workspace_id: UUID
    workspace_slug: str
    name: str
    sort_order: int
    items: tuple[WatchlistItemView, ...]
    created_at: UtcDatetime
    updated_at: UtcDatetime


class WatchlistService:
    def __init__(self, db: Database, *, clock: Callable[[], datetime] = utc_now) -> None:
        self._db = db
        self._clock = clock

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(container.db, clock=clock)

    async def list_watchlists(self, workspace: str) -> list[WatchlistView]:
        async with self._db.session() as session:
            ws = await find_workspace(session, workspace)
            w = WatchlistRow
            rows = (
                await session.scalars(select(w).where(w.workspace_id == ws.id).order_by(w.sort_order, w.name))
            ).all()
            return await _views(session, ws, rows)

    async def get(self, watchlist_id: UUID) -> WatchlistView:
        async with self._db.session() as session:
            row = await _find(session, watchlist_id)
            ws = await find_workspace(session, row.workspace_id)
            return (await _views(session, ws, [row]))[0]

    async def create(
        self, workspace: str, name: str, *, actor: str, client_ip: str | None = None
    ) -> WatchlistView:
        name = _check_name(name)
        now = self._clock()
        async with self._db.transaction() as session:
            # The lock serialises the count and name checks of concurrent changes in the workspace.
            ws = await find_workspace(session, workspace, lock=True)
            w = WatchlistRow
            count = await session.scalar(select(func.count()).select_from(w).where(w.workspace_id == ws.id))
            if (count or 0) >= MAX_WATCHLISTS_PER_WORKSPACE:
                raise ValidationFailedError(
                    f"A workspace can have at most {MAX_WATCHLISTS_PER_WORKSPACE} watchlists",
                    code="watchlist_limit_reached",
                )
            await _check_name_free(session, ws.id, name)
            row = WatchlistRow(
                workspace_id=ws.id, name=name, sort_order=count or 0, created_at=now, updated_at=now
            )
            session.add(row)
            await session.flush()
            add_audit(
                session,
                actor=actor,
                action="watchlist.create",
                entity_type="watchlist",
                entity_id=row.id,
                details={"workspace": ws.slug, "name": name},
                client_ip=client_ip,
            )
            return (await _views(session, ws, [row]))[0]

    async def update(
        self,
        watchlist_id: UUID,
        *,
        name: str | None = None,
        sort_order: int | None = None,
        actor: str,
        client_ip: str | None = None,
    ) -> WatchlistView:
        now = self._clock()
        async with self._db.transaction() as session:
            row = await _find(session, watchlist_id)
            ws = await find_workspace(session, row.workspace_id, lock=True)
            row = await _find(session, watchlist_id, lock=True)
            changes: dict[str, list[object]] = {}
            if name is not None:
                name = _check_name(name)
                if name != row.name:
                    await _check_name_free(session, ws.id, name)
                    changes["name"] = [row.name, name]
                    row.name = name
            if sort_order is not None and sort_order != row.sort_order:
                changes["sort_order"] = [row.sort_order, sort_order]
                row.sort_order = sort_order
            if changes:
                stamp_updated(row, now)
                add_audit(
                    session,
                    actor=actor,
                    action="watchlist.update",
                    entity_type="watchlist",
                    entity_id=row.id,
                    details={"workspace": ws.slug, "changes": changes},
                    client_ip=client_ip,
                )
            return (await _views(session, ws, [row]))[0]

    async def delete(self, watchlist_id: UUID, *, actor: str, client_ip: str | None = None) -> None:
        async with self._db.transaction() as session:
            row = await _find(session, watchlist_id, lock=True)
            ws = await find_workspace(session, row.workspace_id)
            add_audit(
                session,
                actor=actor,
                action="watchlist.delete",
                entity_type="watchlist",
                entity_id=row.id,
                details={"workspace": ws.slug, "name": row.name},
                client_ip=client_ip,
            )
            await session.delete(row)

    async def set_items(
        self, watchlist_id: UUID, instrument_ids: Sequence[UUID], *, actor: str, client_ip: str | None = None
    ) -> WatchlistView:
        """Replace the items with ``instrument_ids``, in that order. Items kept keep their ``added_at``."""
        wanted = list(dict.fromkeys(instrument_ids))
        if len(wanted) > MAX_WATCHLIST_ITEMS:
            raise ValidationFailedError(
                f"A watchlist can hold at most {MAX_WATCHLIST_ITEMS} instruments", code="watchlist_too_large"
            )
        now = self._clock()
        async with self._db.transaction() as session:
            row = await _find(session, watchlist_id, lock=True)
            ws = await find_workspace(session, row.workspace_id)
            known = set(await session.scalars(select(InstrumentRow.id).where(InstrumentRow.id.in_(wanted))))
            unknown = [str(instrument_id) for instrument_id in wanted if instrument_id not in known]
            if unknown:
                raise NotFoundError(
                    f"{len(unknown)} instrument(s) do not exist",
                    code="instrument_not_found",
                    details={"instrument_ids": unknown[:20]},
                )
            existing = {
                item.instrument_id: item
                for item in await session.scalars(
                    select(WatchlistItemRow).where(WatchlistItemRow.watchlist_id == row.id)
                )
            }
            positions = {instrument_id: index for index, instrument_id in enumerate(wanted)}
            removed = [item for instrument_id, item in existing.items() if instrument_id not in positions]
            for item in removed:
                await session.delete(item)
            added = 0
            for instrument_id, index in positions.items():
                current = existing.get(instrument_id)
                if current is None:
                    session.add(
                        WatchlistItemRow(
                            watchlist_id=row.id, instrument_id=instrument_id, sort_order=index, added_at=now
                        )
                    )
                    added += 1
                elif current.sort_order != index:
                    current.sort_order = index
            stamp_updated(row, now)
            add_audit(
                session,
                actor=actor,
                action="watchlist.set_items",
                entity_type="watchlist",
                entity_id=row.id,
                details={"workspace": ws.slug, "items": len(wanted), "added": added, "removed": len(removed)},
                client_ip=client_ip,
            )
            await session.flush()
            return (await _views(session, ws, [row]))[0]


def _check_name(name: str) -> str:
    text = " ".join(name.split())
    if not text or len(text) > MAX_NAME_LENGTH:
        raise ValidationFailedError(
            f"A watchlist name must be 1 to {MAX_NAME_LENGTH} characters", code="invalid_watchlist_name"
        )
    return text


async def _check_name_free(session: AsyncSession, workspace_id: UUID, name: str) -> None:
    w = WatchlistRow
    taken = await session.scalar(
        select(w.id).where(w.workspace_id == workspace_id, func.lower(w.name) == name.lower())
    )
    if taken is not None:
        raise ConflictError(f"The workspace already has a watchlist named '{name}'", code="watchlist_exists")


async def _find(session: AsyncSession, watchlist_id: UUID, *, lock: bool = False) -> WatchlistRow:
    stmt = select(WatchlistRow).where(WatchlistRow.id == watchlist_id)
    row = await session.scalar(stmt.with_for_update() if lock else stmt)
    if row is None:
        raise NotFoundError(f"No watchlist has the id {watchlist_id}", code="watchlist_not_found")
    return row


async def _views(
    session: AsyncSession, ws: WorkspaceRow, rows: Sequence[WatchlistRow]
) -> list[WatchlistView]:
    items: defaultdict[UUID, list[tuple[WatchlistItemRow, InstrumentRow]]] = defaultdict(list)
    if rows:
        wl = WatchlistItemRow
        result = await session.execute(
            select(wl, InstrumentRow)
            .join(InstrumentRow, InstrumentRow.id == wl.instrument_id)
            .where(wl.watchlist_id.in_([row.id for row in rows]))
            .order_by(wl.sort_order, InstrumentRow.symbol)
        )
        for item, instrument in result:
            items[item.watchlist_id].append((item, instrument))
    listed = list({instrument.id for pairs in items.values() for _, instrument in pairs})
    wi = WorkspaceInstrumentRow
    in_universe = (
        set(
            await session.scalars(
                select(wi.instrument_id).where(wi.workspace_id == ws.id, wi.instrument_id.in_(listed))
            )
        )
        if listed
        else set()
    )
    return [
        WatchlistView(
            id=row.id,
            workspace_id=ws.id,
            workspace_slug=ws.slug,
            name=row.name,
            sort_order=row.sort_order,
            items=tuple(
                WatchlistItemView(
                    instrument=Instrument.model_validate(instrument, from_attributes=True),
                    sort_order=item.sort_order,
                    added_at=item.added_at,
                    in_universe=instrument.id in in_universe,
                )
                for item, instrument in items[row.id]
            ),
            created_at=row.created_at,
            updated_at=row.updated_at,
        )
        for row in rows
    ]
