"""Whether each strategy suits an instrument as its workspace streams it (EXT-1.3, EXT-6.1).

``check_compatibility`` gives the checks the strategy panel shows beside a chart, each passed, warning
or failed:

- MARKET: the workspace's market, and the instrument's, are ones the strategy supports.
- INSTRUMENT: the instrument is active, and its exchange, segment, type and key are ones the strategy
  declares.
- TIMEFRAME: the platform builds every candle interval the strategy and its indicators need
  (CANDLE_INTERVALS). A chart on another interval is a warning, shown for comparison.
- DATA: the instrument's provider, in the workspace's subscription mode, sends the data the strategy
  needs (``app.providers.delivery``) and events it runs on. Simulated data is a warning: its signals are
  informational only.
- WARMUP: whether enough closed candles are stored to finish warming up now, or the strategy will warm
  up from live candles. Never a failure.

A failed check means the strategy cannot be applied to the instrument. Saving a configuration enforces
the market check; ``instrument_problem`` (the instrument and data checks) is enforced by saving an
instrument scope, which cannot list the instrument, and by the strategy worker, which leaves it out of a
whole-workspace scope with the reason; the worker fails a run whose candles are not built. Nothing here
reads the database: ``StrategyService.compatibility`` gathers the inputs.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Final
from uuid import UUID

from app.domain.enums import (
    EXCHANGE_MARKETS,
    CandleInterval,
    CheckStatus,
    CompatibilityAspect,
    EventType,
    MarketRegion,
    Provider,
    SubscriptionMode,
)
from app.domain.models.base import DomainModel
from app.domain.models.strategy import StrategyMetadata
from app.persistence.models import InstrumentRow
from app.providers.delivery import MODES, FeedDelivery, labels
from app.strategies.registry import RegisteredStrategy

INACTIVE: Final = "it is inactive (expired or no longer listed)"


class CompatibilityCheck(DomainModel):
    aspect: CompatibilityAspect
    status: CheckStatus
    detail: str


class WarmupCoverage(DomainModel):
    interval: CandleInterval
    needed: int  # closed candles the strategy needs before it can propose signals
    stored: int  # of those, the ones stored now (at most ``needed``)


class StrategyCompatibility(DomainModel):
    strategy_id: str
    version: str
    compatible: bool  # no check failed: it can be applied to the instrument
    checks: tuple[CompatibilityCheck, ...]
    warmup: tuple[WarmupCoverage, ...]  # per candle interval it needs warm-up candles on


class InstrumentCompatibility(DomainModel):
    """How each strategy in the code suits one instrument of a workspace."""

    workspace_slug: str
    market_region: MarketRegion
    instrument_id: UUID
    canonical_key: str
    provider: Provider  # the workspace's source of the instrument
    subscription_mode: SubscriptionMode
    chart_interval: CandleInterval | None
    built_intervals: tuple[CandleInterval, ...]  # CANDLE_INTERVALS
    strategies: tuple[StrategyCompatibility, ...]


@dataclass(frozen=True, slots=True)
class CompatibilityInputs:
    market: MarketRegion  # the workspace's
    instrument: InstrumentRow
    provider: Provider
    mode: SubscriptionMode
    built: frozenset[CandleInterval]  # what CANDLE_INTERVALS builds
    # Closed candles of the instrument stored from the provider, per interval (counted up to the most any
    # strategy needs).
    stored: Mapping[CandleInterval, int]
    feeds: FeedDelivery
    chart_interval: CandleInterval | None = None


def instrument_problem(
    entry: RegisteredStrategy,
    instrument: InstrumentRow,
    provider: Provider,
    mode: SubscriptionMode,
    feeds: FeedDelivery,
) -> str | None:
    """Why the strategy cannot run on the instrument as the workspace streams it; None when it can (the
    INSTRUMENT and DATA checks)."""
    return _listing_problem(entry.metadata, instrument) or feed_problem(
        entry, instrument, provider, mode, feeds
    )


def feed_problem(
    entry: RegisteredStrategy,
    instrument: InstrumentRow,
    provider: Provider,
    mode: SubscriptionMode,
    feeds: FeedDelivery,
) -> str | None:
    """Why the instrument's feed does not give the strategy what it needs; None when it does."""
    metadata = entry.metadata
    shortfall = feeds.shortfall(
        provider,
        mode,
        segment=instrument.segment,
        instrument_type=instrument.instrument_type,
        needs=entry.data_requirements,
        event_types=metadata.event_types,
        candles=bool(entry.intervals),
    )
    if shortfall is not None or metadata.candle_intervals:
        return shortfall

    def sent(in_mode: SubscriptionMode) -> bool:
        delivery = feeds.of(
            provider, in_mode, segment=instrument.segment, instrument_type=instrument.instrument_type
        )
        return not delivery.event_types.isdisjoint(metadata.event_types)

    if sent(mode):
        return None
    delivery = feeds.of(
        provider, mode, segment=instrument.segment, instrument_type=instrument.instrument_type
    )
    sends = _all(_names(delivery.event_types))
    problem = (
        f"it runs only on {_either(_names(metadata.event_types))} events, which the {provider.value} feed "
        f"in {mode.value} mode does not send for this instrument (it sends {sends})"
    )
    fix = next((other for other in MODES if other is not mode and sent(other)), None)
    return problem if fix is None else f"{problem}; subscribe the instrument in {fix.value} mode"


def check_compatibility(entry: RegisteredStrategy, inputs: CompatibilityInputs) -> StrategyCompatibility:
    warmup, coverage = _warmup(entry, inputs)
    checks = (
        _market(entry.metadata, inputs),
        _instrument(entry.metadata, inputs.instrument),
        _timeframe(entry, inputs),
        _data(entry, inputs),
        warmup,
    )
    return StrategyCompatibility(
        strategy_id=entry.strategy_id,
        version=entry.version,
        compatible=all(check.status is not CheckStatus.FAILED for check in checks),
        checks=checks,
        warmup=coverage,
    )


def _market(metadata: StrategyMetadata, inputs: CompatibilityInputs) -> CompatibilityCheck:
    for market in dict.fromkeys((inputs.market, EXCHANGE_MARKETS[inputs.instrument.exchange])):
        problem = metadata.eligibility_problem(market=market)
        if problem is not None:
            return _check(CompatibilityAspect.MARKET, CheckStatus.FAILED, problem)
    return _check(
        CompatibilityAspect.MARKET, CheckStatus.PASSED, f"it supports the {inputs.market.value} market"
    )


def _instrument(metadata: StrategyMetadata, instrument: InstrumentRow) -> CompatibilityCheck:
    problem = _listing_problem(metadata, instrument)
    if problem is not None:
        return _check(CompatibilityAspect.INSTRUMENT, CheckStatus.FAILED, problem)
    if metadata.instrument_keys:
        detail = f"{instrument.canonical_key} is one of the instruments it lists"
    else:
        detail = (
            f"it supports {instrument.segment.value} {instrument.instrument_type.value} instruments on "
            f"{instrument.exchange.value}"
        )
    return _check(CompatibilityAspect.INSTRUMENT, CheckStatus.PASSED, detail)


def _timeframe(entry: RegisteredStrategy, inputs: CompatibilityInputs) -> CompatibilityCheck:
    aspect = CompatibilityAspect.TIMEFRAME
    missing = _ordered(entry.intervals - inputs.built)
    if missing:
        detail = f"it needs {_all(missing)} candles, which CANDLE_INTERVALS does not build"
        return _check(aspect, CheckStatus.FAILED, detail)
    own = entry.metadata.candle_intervals
    if not own:
        detail = f"it runs on {_either(_names(entry.metadata.event_types))} market events"
        if entry.intervals:
            detail += f", with indicators on {_all(_ordered(entry.intervals))} candles"
        return _check(aspect, CheckStatus.PASSED, detail)
    detail = f"it is evaluated on {_all(_ordered(own))} candles"
    chart = inputs.chart_interval
    if chart is None:
        return _check(aspect, CheckStatus.PASSED, detail)
    if chart in own:
        return _check(aspect, CheckStatus.PASSED, f"{detail}, the chart's interval")
    shown = f"its signals appear on the {chart.value} candles containing them"
    return _check(aspect, CheckStatus.WARNING, f"{detail}, not the chart's {chart.value}: {shown}")


def _data(entry: RegisteredStrategy, inputs: CompatibilityInputs) -> CompatibilityCheck:
    aspect = CompatibilityAspect.DATA
    instrument, provider, mode = inputs.instrument, inputs.provider, inputs.mode
    problem = feed_problem(entry, instrument, provider, mode, inputs.feeds)
    if problem is not None:
        return _check(aspect, CheckStatus.FAILED, problem)
    feed = f"the {provider.value} feed in {mode.value} mode"
    needs = entry.data_requirements
    detail = f"{feed} sends the {labels(needs)} it needs" if needs else f"{feed} sends the prices it needs"
    notes: list[str] = []
    delivery = inputs.feeds.of(
        provider, mode, segment=instrument.segment, instrument_type=instrument.instrument_type
    )
    unsent = [event_type for event_type in entry.metadata.event_types if event_type not in delivery.events]
    if unsent:
        notes.append(f"it also takes {_either(_names(unsent))} events, which {feed} does not send")
    if provider is Provider.SIMULATOR:
        notes.append("the data is simulated, so its signals are informational only")
    if notes:
        return _check(aspect, CheckStatus.WARNING, "; ".join((detail, *notes)))
    return _check(aspect, CheckStatus.PASSED, detail)


def _warmup(
    entry: RegisteredStrategy, inputs: CompatibilityInputs
) -> tuple[CompatibilityCheck, tuple[WarmupCoverage, ...]]:
    aspect = CompatibilityAspect.WARMUP
    coverage = tuple(
        WarmupCoverage(interval=interval, needed=needed, stored=min(inputs.stored.get(interval, 0), needed))
        for interval, needed in sorted(entry.warmups.items(), key=lambda item: item[0].seconds)
        if needed > 0
    )
    if not coverage:
        return _check(aspect, CheckStatus.PASSED, "it needs no warm-up candles"), coverage
    unbuilt = [item.interval for item in coverage if item.interval not in inputs.built]
    if unbuilt:
        detail = f"it cannot warm up: {_all(unbuilt)} candles are not built"
        return _check(aspect, CheckStatus.WARNING, detail), coverage
    short = [item for item in coverage if item.stored < item.needed]
    if not short:
        detail = f"enough closed candles are stored to warm up now ({_counts(coverage)})"
        return _check(aspect, CheckStatus.PASSED, detail), coverage
    detail = f"it will warm up from live candles: {_counts(short)} are stored"
    return _check(aspect, CheckStatus.WARNING, detail), coverage


def _listing_problem(metadata: StrategyMetadata, instrument: InstrumentRow) -> str | None:
    if not instrument.is_active:
        return INACTIVE
    return metadata.eligibility_problem(
        exchange=instrument.exchange,
        segment=instrument.segment,
        instrument_type=instrument.instrument_type,
        instrument_key=instrument.canonical_key,
    )


def _check(aspect: CompatibilityAspect, status: CheckStatus, detail: str) -> CompatibilityCheck:
    return CompatibilityCheck(aspect=aspect, status=status, detail=detail)


def _ordered(intervals: Iterable[CandleInterval]) -> list[CandleInterval]:
    return sorted(intervals, key=lambda interval: interval.seconds)


def _names(event_types: Iterable[EventType]) -> list[str]:
    chosen = set(event_types)
    return [event_type.value for event_type in EventType if event_type in chosen]


def _counts(coverage: Iterable[WarmupCoverage]) -> str:
    return ", ".join(f"{item.stored} of {item.needed} {item.interval.value} candles" for item in coverage)


def _all(names: Iterable[str]) -> str:
    listed = list(names)
    if len(listed) < 2:
        return "".join(listed) or "none"
    return f"{', '.join(listed[:-1])} and {listed[-1]}"


def _either(names: Iterable[str]) -> str:
    listed = list(names)
    if len(listed) < 2:
        return "".join(listed) or "none"
    return f"{', '.join(listed[:-1])} or {listed[-1]}"
