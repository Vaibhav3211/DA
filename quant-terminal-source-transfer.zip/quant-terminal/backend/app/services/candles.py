"""Candle series for charts: closed candles from the database, the forming one from Redis."""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime
from typing import Self
from uuid import UUID

from pydantic import ValidationError

from app.container import Container
from app.core.clock import utc_now
from app.core.config import Settings
from app.core.errors import ValidationFailedError
from app.domain.enums import CandleInterval, DataStatus, Provider
from app.domain.models import Candle, Instrument
from app.domain.models.base import DomainModel, UtcDatetime
from app.market_data.candles.store import load_recent
from app.persistence.database import Database
from app.services.instruments import find_instrument
from app.services.quotes import FeedStatuses, effective_status, read_feed_streams
from app.streaming.redis_bus import Keys, RedisBus

MAX_CANDLES = 2000


def forming_view(candle: Candle, feeds: FeedStatuses, now: datetime, *, stale_after_seconds: float) -> Candle:
    """A forming candle with its data status recomputed when read, as a quote's is."""
    feed = feeds.status(candle.provider, candle.account_id)
    age = max(0.0, (now - candle.last_event_at).total_seconds())
    status = effective_status(candle.data_status, feed, age, stale_after_seconds=stale_after_seconds)
    return candle.model_copy(update={"data_status": status})


class CandleSeries(DomainModel):
    instrument: Instrument
    provider: Provider
    interval: CandleInterval
    candles: tuple[Candle, ...]  # closed, oldest first
    # The current bucket, with its data status recomputed when read (as a quote's is).
    forming: Candle | None
    feed_status: DataStatus
    generated_at: UtcDatetime


class CandleService:
    def __init__(
        self, db: Database, bus: RedisBus, settings: Settings, *, clock: Callable[[], datetime] = utc_now
    ) -> None:
        self._db = db
        self._bus = bus
        self._stale_after = settings.data_stale_after_seconds
        self._clock = clock

    @classmethod
    def from_container(cls, container: Container, *, clock: Callable[[], datetime] = utc_now) -> Self:
        return cls(container.db, container.bus, container.settings, clock=clock)

    async def series(
        self,
        instrument: UUID | str,
        provider: Provider,
        interval: CandleInterval,
        *,
        limit: int = 300,
        until: datetime | None = None,
        include_forming: bool = True,
    ) -> CandleSeries:
        """The newest ``limit`` closed candles before ``until`` (default: now). Without ``until`` the
        forming candle is included too, and a just-closed candle not yet in the database is added."""
        if not 1 <= limit <= MAX_CANDLES:
            raise ValidationFailedError(f"limit must be 1 to {MAX_CANDLES}", code="invalid_limit")
        now = self._clock()
        async with self._db.session() as session:
            row = await find_instrument(session, instrument)
            listing = Instrument.model_validate(row, from_attributes=True)
            candles = await load_recent(
                session,
                provider,
                row.id,
                listing,
                interval,
                until=now if until is None else until,
                limit=limit,
            )
        feeds = FeedStatuses(await read_feed_streams(self._bus))
        forming: Candle | None = None
        if until is None:
            latest = await self._shown(provider, row.id, interval)
            newer = latest is not None and (not candles or latest.bucket_start > candles[-1].bucket_start)
            if latest is not None and newer and latest.is_closed:
                candles = [*candles, latest][-limit:]
            elif latest is not None and newer and include_forming:
                forming = forming_view(latest, feeds, now, stale_after_seconds=self._stale_after)
        account = forming.account_id if forming else candles[-1].account_id if candles else None
        feed_status = (
            feeds.status(provider, account) if forming or candles else feeds.provider_status(provider)
        )
        return CandleSeries(
            instrument=listing,
            provider=provider,
            interval=interval,
            candles=tuple(candles),
            forming=forming,
            feed_status=feed_status,
            generated_at=now,
        )

    async def _shown(
        self, provider: Provider, instrument_id: UUID, interval: CandleInterval
    ) -> Candle | None:
        """The candle the pipeline shows for the series: the forming one, or the one just closed."""
        value = await self._bus.get_json(Keys.partial_candle(provider, instrument_id, interval))
        if value is None:
            return None
        try:
            return Candle.model_validate(value)
        except ValidationError:
            return None
