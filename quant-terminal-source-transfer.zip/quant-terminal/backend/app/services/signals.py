"""Signal history (spec §16, §20): signals, their lifecycle events and risk decisions, read-only.

The signal engine is the only writer. Lists come newest first and page by keyset: the opaque cursor
names the last signal of a page, so signals generated while a client pages through do not shift the
pages that follow.
"""

from __future__ import annotations

import base64
import json
from datetime import datetime
from typing import Any, Final, Self
from uuid import UUID

from pydantic import Field, model_validator
from sqlalchemy import select, tuple_

from app.container import Container
from app.core.clock import ensure_utc
from app.core.errors import NotFoundError, ValidationFailedError
from app.domain.enums import OPEN_SIGNAL_STATUSES, RiskOutcome, SignalEventType, SignalStatus, SignalType
from app.domain.models.base import DomainModel, UtcDatetime
from app.domain.models.signal import RiskCheck, Signal
from app.persistence.database import Database
from app.persistence.models import (
    RiskDecisionRow,
    SignalEventRow,
    SignalRow,
    StrategyDeploymentRow,
    StrategyRunRow,
    WorkspaceRow,
)
from app.services.instruments import find_instrument
from app.services.workspaces import find_workspace

DEFAULT_LIMIT: Final = 50
MAX_LIMIT: Final = 500
_MAX_CURSOR: Final = 200
_OPEN: Final = tuple(sorted(OPEN_SIGNAL_STATUSES))


class SignalQuery(DomainModel):
    """``list_signals`` filters; every one given must hold. ``since`` is inclusive and ``until``
    exclusive, both on ``generated_at``. ``cursor`` continues after a previous page."""

    workspace: UUID | str | None = None  # id or slug
    strategy_id: str | None = None
    instrument: UUID | str | None = None  # id or canonical key
    deployment_id: UUID | None = None
    statuses: frozenset[SignalStatus] = frozenset()
    signal_types: frozenset[SignalType] = frozenset()
    open_only: bool = False  # GENERATED, ACTIVE or UPDATED
    actionable: bool | None = None
    since: UtcDatetime | None = None
    until: UtcDatetime | None = None
    limit: int = Field(default=DEFAULT_LIMIT, ge=1, le=MAX_LIMIT)
    cursor: str | None = None

    @model_validator(mode="after")
    def _window(self) -> Self:
        if self.since is not None and self.until is not None and self.since >= self.until:
            raise ValueError("since must be before until")
        return self


class SignalView(Signal):
    """A signal and the slug of its workspace."""

    workspace_slug: str


class SignalPage(DomainModel):
    items: tuple[SignalView, ...]
    next_cursor: str | None  # None: this is the last page


class SignalEventView(DomainModel):
    id: int
    event_type: SignalEventType
    from_status: SignalStatus | None
    to_status: SignalStatus
    details: dict[str, Any]
    occurred_at: UtcDatetime


class RiskDecisionView(DomainModel):
    """One pass through the risk gate; a signal is gated again whenever it is updated."""

    id: UUID
    outcome: RiskOutcome
    checks: tuple[RiskCheck, ...]
    evaluated_at: UtcDatetime


class SignalConfiguration(DomainModel):
    """The saved configuration the signal's run used, as it was when the run started: editing the saved
    configuration later does not change it."""

    deployment_label: str  # the saved configuration's current label
    configuration_id: UUID
    config: dict[str, Any]
    config_hash: str
    code_fingerprint: str | None  # None when the run did not record it
    run_started_at: UtcDatetime
    is_current: bool  # False once the saved configuration has been edited since the run started


class SignalDetail(DomainModel):
    signal: SignalView
    configuration: SignalConfiguration
    events: tuple[SignalEventView, ...]  # oldest first
    decisions: tuple[RiskDecisionView, ...]  # oldest first


class SignalService:
    def __init__(self, db: Database) -> None:
        self.db = db

    @classmethod
    def from_container(cls, container: Container) -> Self:
        return cls(container.db)

    async def list_signals(self, query: SignalQuery | None = None) -> SignalPage:
        """Newest first (by ``generated_at``, then id)."""
        query = SignalQuery() if query is None else query
        s, w = SignalRow, WorkspaceRow
        stmt = select(s, w.slug).join(w, w.id == s.workspace_id)
        if query.cursor is not None:
            stmt = stmt.where(tuple_(s.generated_at, s.id) < _position(query.cursor))
        if query.strategy_id is not None:
            stmt = stmt.where(s.strategy_id == query.strategy_id)
        if query.deployment_id is not None:
            stmt = stmt.where(s.deployment_id == query.deployment_id)
        if query.statuses:
            stmt = stmt.where(s.status.in_(sorted(query.statuses)))
        if query.open_only:
            stmt = stmt.where(s.status.in_(_OPEN))
        if query.signal_types:
            stmt = stmt.where(s.signal_type.in_(sorted(query.signal_types)))
        if query.actionable is not None:
            stmt = stmt.where(s.is_actionable.is_(query.actionable))
        if query.since is not None:
            stmt = stmt.where(s.generated_at >= query.since)
        if query.until is not None:
            stmt = stmt.where(s.generated_at < query.until)
        stmt = stmt.order_by(s.generated_at.desc(), s.id.desc()).limit(query.limit + 1)
        async with self.db.session() as session:
            if query.workspace is not None:
                stmt = stmt.where(s.workspace_id == (await find_workspace(session, query.workspace)).id)
            if query.instrument is not None:
                stmt = stmt.where(s.instrument_id == (await find_instrument(session, query.instrument)).id)
            rows = (await session.execute(stmt)).all()
        items = tuple(_view(row, slug) for row, slug in rows[: query.limit])
        more = len(rows) > query.limit
        return SignalPage(items=items, next_cursor=_cursor(items[-1]) if more else None)

    async def get_signal(self, signal_id: UUID) -> SignalDetail:
        s, e, d, r, c = SignalRow, SignalEventRow, RiskDecisionRow, StrategyRunRow, StrategyDeploymentRow
        async with self.db.session() as session:
            found = (
                await session.execute(
                    select(s, WorkspaceRow.slug, r, c.label, c.configuration_id)
                    .join(WorkspaceRow, WorkspaceRow.id == s.workspace_id)
                    .join(r, r.id == s.strategy_run_id)
                    .join(c, c.id == s.deployment_id)
                    .where(s.id == signal_id)
                )
            ).first()
            if found is None:
                raise NotFoundError(f"Signal {signal_id} was not found", code="signal_not_found")
            signal, slug, run, label, current = found
            events = await session.scalars(
                select(e).where(e.signal_id == signal_id).order_by(e.occurred_at, e.id)
            )
            decisions = await session.scalars(
                select(d).where(d.signal_id == signal_id).order_by(d.evaluated_at, d.id)
            )
            fingerprint = run.input_context.get("code_fingerprint")
            return SignalDetail(
                signal=_view(signal, slug),
                configuration=SignalConfiguration(
                    deployment_label=label,
                    configuration_id=run.configuration_id,
                    config=run.config_snapshot,
                    config_hash=run.config_hash,
                    code_fingerprint=fingerprint if isinstance(fingerprint, str) else None,
                    run_started_at=run.started_at,
                    is_current=current == run.configuration_id,
                ),
                events=tuple(SignalEventView.model_validate(row, from_attributes=True) for row in events),
                decisions=tuple(
                    RiskDecisionView.model_validate(row, from_attributes=True) for row in decisions
                ),
            )


def _view(row: SignalRow, slug: str) -> SignalView:
    return SignalView(**dict(Signal.model_validate(row, from_attributes=True)), workspace_slug=slug)


def _cursor(last: Signal) -> str:
    raw = json.dumps([last.generated_at.isoformat(), str(last.id)], separators=(",", ":"))
    return base64.urlsafe_b64encode(raw.encode()).decode("ascii").rstrip("=")


def _position(cursor: str) -> tuple[datetime, UUID]:
    """The (generated_at, id) a cursor names. Every decoding failure is a ValueError."""
    try:
        if len(cursor) > _MAX_CURSOR:
            raise ValueError("too long")
        raw = base64.urlsafe_b64decode(cursor.encode("ascii") + b"=" * (-len(cursor) % 4))
        value = json.loads(raw)
        if not (isinstance(value, list) and len(value) == 2 and all(isinstance(v, str) for v in value)):
            raise ValueError("unexpected shape")
        return ensure_utc(datetime.fromisoformat(value[0])), UUID(value[1])
    except ValueError:
        raise ValidationFailedError(
            "The cursor is not one a signal list returned", code="invalid_cursor"
        ) from None
