"""Risk and safety rules applied to every strategy candidate (spec §18).

A rule is a pure function of a ``RiskInput`` snapshot, its parameters and the evaluation time, so a
decision can be reproduced, stored and explained. A rule returns ``None`` when it does not apply to
the candidate. A failed check either BLOCKs (the signal is kept for audit as BLOCKED and is never
actionable) or WARNs (shown with the signal; the outcome is unaffected).

Mandatory rules cannot be disabled; their parameters can still be tuned. Duplicate suppression is
applied by the signal lifecycle before the gate: a candidate repeating the open signal is dropped.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal
from types import MappingProxyType
from typing import Any, NamedTuple

from pydantic import BaseModel, ConfigDict, Field

from app.domain.enums import (
    CandleFlag,
    DataStatus,
    MarketRegion,
    MarketSessionState,
    Provider,
    SignalType,
)
from app.domain.models.candle import Candle
from app.domain.models.instrument import Instrument
from app.domain.models.market_event import NormalizedMarketEvent
from app.domain.models.signal import RiskCheck, SignalCandidate
from app.domain.models.strategy import StrategyMetadata

KILL_SWITCH = "kill_switch"
WORKSPACE_PAUSE = "workspace_pause"
LIVE_SIGNALS = "live_signals"
STRATEGY_ENABLED = "strategy_enabled"
DATA_QUALITY = "data_quality"
INSTRUMENT_STATUS = "instrument_status"
ELIGIBILITY = "eligibility"
SESSION_STATUS = "session_status"
FREQUENCY = "frequency"
PRICE_SANITY = "price_sanity"
VOLATILITY_LIMIT = "volatility_limit"
STOP_LOSS_REQUIRED = "stop_loss_required"

# Upper bounds of the frequency parameters; the signal engine loads at most this much history.
MAX_FREQUENCY_SIGNALS = 100
MAX_FREQUENCY_WINDOW_MINUTES = 1440

BLOCKING_STATUSES = frozenset(
    {DataStatus.STALE, DataStatus.RECONNECTING, DataStatus.DISCONNECTED, DataStatus.UNKNOWN}
)
_HUNDRED = Decimal(100)
_CENT = Decimal("0.01")


class RecentSignal(NamedTuple):
    generated_at: datetime
    signal_type: SignalType


@dataclass(frozen=True, slots=True)
class SourceData:
    """The market data a candidate was computed from (normally the candle that just closed)."""

    provider: Provider
    status: DataStatus
    as_of: datetime | None
    last_price: Decimal | None = None
    high: Decimal | None = None
    low: Decimal | None = None
    flags: frozenset[CandleFlag] = frozenset()

    @classmethod
    def from_candle(cls, candle: Candle) -> SourceData:
        return cls(
            provider=candle.provider,
            status=candle.data_status,
            as_of=candle.bucket_end,
            last_price=candle.close_price,
            high=candle.high_price,
            low=candle.low_price,
            flags=frozenset(candle.flags),
        )

    @classmethod
    def from_event(cls, event: NormalizedMarketEvent) -> SourceData:
        # An event's high and low are the day's range, not this update's, so they are left out.
        return cls(
            provider=event.provider,
            status=event.data_status,
            as_of=event.event_time,
            last_price=event.last_price,
        )


@dataclass(frozen=True, slots=True)
class RiskInput:
    """Everything the gate needs about one candidate, captured at evaluation time."""

    candidate: SignalCandidate
    metadata: StrategyMetadata
    instrument: Instrument
    market_region: MarketRegion
    source: SourceData
    session_state: MarketSessionState
    trading_date: date  # exchange-local date at evaluation time
    deployment_enabled: bool
    kill_switch_engaged: bool
    live_signals_enabled: bool
    kill_switch_reason: str | None = None
    deployment_problem: str | None = None
    universe_problem: str | None = None
    # True when the candidate refreshes the open signal of the same type (frequency does not apply).
    is_update: bool = False
    # Recent allowed signals for the same deployment and instrument.
    recent_signals: tuple[RecentSignal, ...] = ()

    @property
    def statuses(self) -> tuple[DataStatus, ...]:
        return (self.source.status, *(value.data_status for value in self.candidate.indicator_values))

    @property
    def uses_simulated_data(self) -> bool:
        return self.source.provider is Provider.SIMULATOR or DataStatus.SIMULATED in self.statuses


class RuleParams(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class NoParams(RuleParams):
    pass


class PauseParams(RuleParams):
    paused: bool = False
    reason: str | None = Field(default=None, max_length=200)


class DataQualityParams(RuleParams):
    max_age_seconds: int = Field(default=120, ge=1, le=86_400)
    block_delayed: bool = False
    block_flags: tuple[CandleFlag, ...] = (CandleFlag.DISCONNECTED_DURING,)
    warn_flags: tuple[CandleFlag, ...] = (
        CandleFlag.GAP_BEFORE,
        CandleFlag.PARTIAL_START,
        CandleFlag.LATE_EVENTS_IGNORED,
    )


class SessionParams(RuleParams):
    allowed_states: tuple[MarketSessionState, ...] = Field(default=(MarketSessionState.OPEN,), min_length=1)


class FrequencyParams(RuleParams):
    max_signals: int = Field(default=3, ge=1, le=MAX_FREQUENCY_SIGNALS)
    window_minutes: int = Field(default=60, ge=1, le=MAX_FREQUENCY_WINDOW_MINUTES)
    # Exits are never rate-limited by default: blocking one could leave a position unmanaged.
    signal_types: tuple[SignalType, ...] = Field(default=(SignalType.BUY, SignalType.SELL), min_length=1)


class PriceSanityParams(RuleParams):
    max_entry_deviation_pct: Decimal = Field(default=Decimal(2), gt=0, le=100)
    min_price: Decimal | None = Field(default=None, gt=0)
    max_price: Decimal | None = Field(default=None, gt=0)


class VolatilityParams(RuleParams):
    max_candle_range_pct: Decimal = Field(default=Decimal(5), gt=0, le=1000)
    max_stop_distance_pct: Decimal = Field(default=Decimal(10), gt=0, le=1000)


class StopLossParams(RuleParams):
    signal_types: tuple[SignalType, ...] = (SignalType.BUY, SignalType.SELL)


Check = Callable[[RiskInput, Any, datetime], RiskCheck | None]


@dataclass(frozen=True, slots=True)
class RiskRule:
    key: str
    description: str
    params_model: type[RuleParams]
    check: Check
    mandatory: bool = False


def _result(
    rule: str,
    ok: str,
    problems: Iterable[str] = (),
    warnings: Iterable[str] = (),
    details: Mapping[str, Any] | None = None,
) -> RiskCheck:
    blocking, warned, info = list(problems), list(warnings), dict(details or {})
    if blocking:
        if warned:
            info["warnings"] = warned
        return RiskCheck(rule=rule, passed=False, message="; ".join(blocking), details=info)
    if warned:
        return RiskCheck(rule=rule, passed=False, severity="WARN", message="; ".join(warned), details=info)
    return RiskCheck(rule=rule, passed=True, message=ok, details=info)


def _pct(value: Decimal) -> str:
    return str(value.quantize(_CENT))


def _kill_switch(data: RiskInput, params: NoParams, now: datetime) -> RiskCheck:
    if data.kill_switch_engaged:
        reason = data.kill_switch_reason or "no reason given"
        return _result(KILL_SWITCH, "", [f"Kill switch is engaged ({reason})"])
    return _result(KILL_SWITCH, "Kill switch is off")


def _workspace_pause(data: RiskInput, params: PauseParams, now: datetime) -> RiskCheck:
    if params.paused:
        reason = params.reason or "no reason given"
        return _result(WORKSPACE_PAUSE, "", [f"Signals are paused for this workspace ({reason})"])
    return _result(WORKSPACE_PAUSE, "Workspace is not paused")


def _live_signals(data: RiskInput, params: NoParams, now: datetime) -> RiskCheck:
    if data.uses_simulated_data:
        return _result(LIVE_SIGNALS, "Simulated data: the signal stays informational")
    if not data.live_signals_enabled:
        message = "Signals on live data are disabled (set LIVE_SIGNALS_ENABLED=true to allow them)"
        return _result(LIVE_SIGNALS, "", [message])
    return _result(LIVE_SIGNALS, "Signals on live data are enabled")


def _strategy_enabled(data: RiskInput, params: NoParams, now: datetime) -> RiskCheck:
    strategy = f"{data.metadata.strategy_id} {data.metadata.version}"
    if data.deployment_problem:
        return _result(
            STRATEGY_ENABLED, "", [f"Deployment of {strategy} is blocked: {data.deployment_problem}"]
        )
    if not data.deployment_enabled:
        return _result(STRATEGY_ENABLED, "", [f"{strategy} is not enabled for this workspace"])
    return _result(STRATEGY_ENABLED, f"{strategy} is enabled")


def _data_quality(data: RiskInput, params: DataQualityParams, now: datetime) -> RiskCheck:
    statuses = data.statuses
    problems = [f"data is {status}" for status in sorted(BLOCKING_STATUSES.intersection(statuses))]
    warnings: list[str] = []
    if DataStatus.DELAYED in statuses:
        (problems if params.block_delayed else warnings).append("data is DELAYED")
    details: dict[str, Any] = {"statuses": sorted(set(statuses))}
    as_of = data.source.as_of
    if as_of is None:
        problems.append("the source data time is unknown")
    else:
        age = (now - as_of).total_seconds()
        details["age_seconds"] = round(age, 1)
        if age > params.max_age_seconds:
            problems.append(f"source data is {age:.0f}s old (limit {params.max_age_seconds}s)")
    flags = data.source.flags
    problems += [f"candle flagged {flag}" for flag in sorted(flags.intersection(params.block_flags))]
    warnings += [
        f"candle flagged {flag}"
        for flag in sorted(flags.intersection(params.warn_flags) - set(params.block_flags))
    ]
    if flags:
        details["flags"] = sorted(flags)
    return _result(DATA_QUALITY, "Data is fresh and complete", problems, warnings, details)


def _instrument_status(data: RiskInput, params: NoParams, now: datetime) -> RiskCheck:
    instrument = data.instrument
    if not instrument.is_active:
        return _result(INSTRUMENT_STATUS, "", [f"{instrument.symbol} is inactive"])
    expiry = instrument.expiry
    if expiry is not None and expiry < data.trading_date:
        return _result(INSTRUMENT_STATUS, "", [f"{instrument.symbol} expired on {expiry}"])
    if expiry is not None and expiry == data.trading_date:
        return _result(INSTRUMENT_STATUS, "", warnings=[f"{instrument.symbol} expires today"])
    return _result(INSTRUMENT_STATUS, f"{instrument.symbol} is active")


def _eligibility(data: RiskInput, params: NoParams, now: datetime) -> RiskCheck:
    instrument = data.instrument
    problems = [
        problem
        for problem in (
            data.metadata.eligibility_problem(
                market=data.market_region,
                exchange=instrument.exchange,
                segment=instrument.segment,
                instrument_type=instrument.instrument_type,
                instrument_key=instrument.canonical_key,
            ),
            data.universe_problem,
        )
        if problem
    ]
    if data.candidate.instrument_id != instrument.id:
        problems.append("the candidate names a different instrument than the one evaluated")
    return _result(ELIGIBILITY, f"{instrument.symbol} is eligible", problems)


def _session_status(data: RiskInput, params: SessionParams, now: datetime) -> RiskCheck:
    exchange, state = data.instrument.exchange, data.session_state
    if state in params.allowed_states:
        return _result(SESSION_STATUS, f"{exchange} session is {state}")
    allowed = ", ".join(params.allowed_states)
    return _result(SESSION_STATUS, "", [f"{exchange} session is {state} (allowed: {allowed})"])


def _frequency(data: RiskInput, params: FrequencyParams, now: datetime) -> RiskCheck | None:
    if data.is_update or data.candidate.signal_type not in params.signal_types:
        return None
    since = now - timedelta(minutes=params.window_minutes)
    count = sum(
        1
        for recent in data.recent_signals
        if recent.signal_type in params.signal_types and recent.generated_at > since
    )
    window = f"{params.window_minutes} min"
    details = {
        "recent_signals": count,
        "max_signals": params.max_signals,
        "window_minutes": params.window_minutes,
    }
    if count >= params.max_signals:
        message = f"{count} signals for this instrument in the last {window} (limit {params.max_signals})"
        return _result(FREQUENCY, "", [message], details=details)
    return _result(
        FREQUENCY, f"{count} of {params.max_signals} signals used in the last {window}", details=details
    )


def _levels(candidate: SignalCandidate) -> list[tuple[str, Decimal]]:
    levels = [("entry", candidate.entry_price), ("stop-loss", candidate.stop_loss)]
    levels += [(f"target {target.label}", target.price) for target in candidate.targets]
    return [(name, value) for name, value in levels if value is not None]


def _side_problems(candidate: SignalCandidate, reference: Decimal) -> list[str]:
    buy = candidate.signal_type is SignalType.BUY
    below, above = ("below", "above") if buy else ("above", "below")
    problems: list[str] = []
    stop = candidate.stop_loss
    if stop is not None and ((stop >= reference) if buy else (stop <= reference)):
        problems.append(f"stop-loss {stop} must be {below} {reference} for {candidate.signal_type}")
    for target in candidate.targets:
        if (target.price <= reference) if buy else (target.price >= reference):
            side = f"must be {above} {reference} for {candidate.signal_type}"
            problems.append(f"target {target.label} {target.price} {side}")
    return problems


def _price_sanity(data: RiskInput, params: PriceSanityParams, now: datetime) -> RiskCheck | None:
    candidate, last = data.candidate, data.source.last_price
    levels = _levels(candidate)
    if not levels and last is None:
        return None
    problems = [f"{name} {value} is not positive" for name, value in levels if value <= 0]
    reference = candidate.entry_price if candidate.entry_price is not None else last
    if reference is not None and reference > 0 and candidate.signal_type in (SignalType.BUY, SignalType.SELL):
        problems += _side_problems(candidate, reference)
    entry = candidate.entry_price
    if entry is not None and last is not None and last > 0:
        deviation = abs(entry - last) / last * _HUNDRED
        if deviation > params.max_entry_deviation_pct:
            problems.append(
                f"entry {entry} is {_pct(deviation)}% from the last price {last} "
                f"(limit {params.max_entry_deviation_pct}%)"
            )
    price = last if last is not None else entry
    if price is not None and params.min_price is not None and price < params.min_price:
        problems.append(f"price {price} is below the minimum {params.min_price}")
    if price is not None and params.max_price is not None and price > params.max_price:
        problems.append(f"price {price} is above the maximum {params.max_price}")
    tick = data.instrument.tick_size
    off_tick = [name for name, value in levels if tick and value > 0 and value % tick != 0]
    warnings = [f"{', '.join(off_tick)} not on the {tick} tick"] if off_tick else []
    details = {"last_price": None if last is None else str(last)}
    return _result(PRICE_SANITY, "Price levels are consistent", problems, warnings, details)


def _volatility(data: RiskInput, params: VolatilityParams, now: datetime) -> RiskCheck | None:
    source, candidate = data.source, data.candidate
    problems: list[str] = []
    details: dict[str, Any] = {}
    if (
        source.high is not None
        and source.low is not None
        and source.last_price is not None
        and source.last_price > 0
    ):
        candle_range = (source.high - source.low) / source.last_price * _HUNDRED
        details["candle_range_pct"] = _pct(candle_range)
        if candle_range > params.max_candle_range_pct:
            problems.append(
                f"source candle range {_pct(candle_range)}% exceeds {params.max_candle_range_pct}%"
            )
    entry, stop = candidate.entry_price, candidate.stop_loss
    if entry is not None and stop is not None and entry > 0:
        distance = abs(entry - stop) / entry * _HUNDRED
        details["stop_distance_pct"] = _pct(distance)
        if distance > params.max_stop_distance_pct:
            problems.append(
                f"stop-loss is {_pct(distance)}% from entry (limit {params.max_stop_distance_pct}%)"
            )
    if not details:
        return None
    return _result(VOLATILITY_LIMIT, "Volatility is within limits", problems, details=details)


def _stop_loss(data: RiskInput, params: StopLossParams, now: datetime) -> RiskCheck | None:
    candidate = data.candidate
    if candidate.signal_type not in params.signal_types:
        return None
    if candidate.stop_loss is None:
        return _result(STOP_LOSS_REQUIRED, "", [f"{candidate.signal_type} signals require a stop-loss"])
    return _result(STOP_LOSS_REQUIRED, f"Stop-loss {candidate.stop_loss} is set")


BUILTIN_RULES: tuple[RiskRule, ...] = (
    RiskRule(
        KILL_SWITCH,
        "Blocks every signal while the global kill switch is engaged.",
        NoParams,
        _kill_switch,
        True,
    ),
    RiskRule(
        WORKSPACE_PAUSE,
        "Manual pause of one workspace (qt risk pause/resume).",
        PauseParams,
        _workspace_pause,
        True,
    ),
    RiskRule(
        LIVE_SIGNALS, "Live-data signals need LIVE_SIGNALS_ENABLED=true.", NoParams, _live_signals, True
    ),
    RiskRule(
        STRATEGY_ENABLED, "The deployment must be enabled and runnable.", NoParams, _strategy_enabled, True
    ),
    RiskRule(DATA_QUALITY, "Feed status, candle flags and data age.", DataQualityParams, _data_quality, True),
    RiskRule(
        INSTRUMENT_STATUS, "The instrument is active and not expired.", NoParams, _instrument_status, True
    ),
    RiskRule(
        ELIGIBILITY,
        "Market, segment and instrument type allowed by strategy and workspace.",
        NoParams,
        _eligibility,
        True,
    ),
    RiskRule(SESSION_STATUS, "The exchange session is in an allowed state.", SessionParams, _session_status),
    RiskRule(FREQUENCY, "Limits new signals per deployment and instrument.", FrequencyParams, _frequency),
    RiskRule(
        PRICE_SANITY,
        "Positive levels on the correct side, entry near the last price, optional price band.",
        PriceSanityParams,
        _price_sanity,
    ),
    RiskRule(
        VOLATILITY_LIMIT, "Source candle range and stop distance limits.", VolatilityParams, _volatility
    ),
    RiskRule(STOP_LOSS_REQUIRED, "Directional signals need a stop-loss.", StopLossParams, _stop_loss),
)
RULES_BY_KEY: Mapping[str, RiskRule] = MappingProxyType({rule.key: rule for rule in BUILTIN_RULES})
