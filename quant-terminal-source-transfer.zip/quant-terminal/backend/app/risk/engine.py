"""Risk gate: resolves the effective rule settings for a workspace and evaluates candidates.

Parameters resolve as code default < global row < workspace row (``risk_rules``); the most specific
row also decides whether an optional rule is enabled. Stored parameters that no longer validate
(e.g. after a code change) make the rule BLOCK until they are fixed, and a rule that raises BLOCKs
too: the gate fails closed.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import ValidationError

from app.core.logging import get_logger
from app.domain.enums import RiskOutcome
from app.domain.models.signal import RiskCheck, RiskDecision
from app.risk.rules import BUILTIN_RULES, RiskInput, RiskRule, RuleParams

log = get_logger(__name__)

RuleSource = Literal["default", "global", "workspace"]


@dataclass(frozen=True, slots=True)
class RuleOverride:
    """A stored ``risk_rules`` row; ``workspace_id`` None is the global layer."""

    rule_key: str
    workspace_id: UUID | None
    is_enabled: bool
    params: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class EffectiveRule:
    rule: RiskRule
    enabled: bool
    source: RuleSource
    params: RuleParams | None  # None when the stored parameters are invalid
    error: str | None = None


@dataclass(frozen=True, slots=True)
class RiskPolicy:
    workspace_id: UUID | None
    rules: tuple[EffectiveRule, ...]

    def get(self, key: str) -> EffectiveRule:
        for item in self.rules:
            if item.rule.key == key:
                return item
        raise KeyError(key)


def merge_params(rule: RiskRule, *layers: Mapping[str, Any]) -> RuleParams:
    """Overlay stored parameter layers on the rule defaults and validate the result."""
    merged: dict[str, Any] = rule.params_model().model_dump(mode="json")
    for layer in layers:
        merged.update(layer)
    return rule.params_model.model_validate(merged)


def describe_error(exc: ValidationError) -> str:
    return "; ".join(
        f"{'.'.join(str(part) for part in error['loc']) or 'params'}: {error['msg']}"
        for error in exc.errors()
    )


def resolve_policy(
    overrides: Iterable[RuleOverride], workspace_id: UUID | None, *, rules: Sequence[RiskRule] = BUILTIN_RULES
) -> RiskPolicy:
    global_rows: dict[str, RuleOverride] = {}
    workspace_rows: dict[str, RuleOverride] = {}
    for override in overrides:
        if override.workspace_id is None:
            global_rows[override.rule_key] = override
        elif override.workspace_id == workspace_id:
            workspace_rows[override.rule_key] = override
    effective: list[EffectiveRule] = []
    for rule in rules:
        layers = [row for row in (global_rows.get(rule.key), workspace_rows.get(rule.key)) if row is not None]
        source: RuleSource = (
            "workspace" if rule.key in workspace_rows else "global" if rule.key in global_rows else "default"
        )
        enabled = rule.mandatory or (layers[-1].is_enabled if layers else True)
        try:
            params: RuleParams | None = merge_params(rule, *(row.params for row in layers))
            error = None
        except ValidationError as exc:
            params, error = None, describe_error(exc)
        effective.append(EffectiveRule(rule, enabled, source, params, error))
    return RiskPolicy(workspace_id, tuple(effective))


def evaluate(data: RiskInput, policy: RiskPolicy, now: datetime) -> RiskDecision:
    checks = [check for item in policy.rules if (check := _run(item, data, now)) is not None]
    blocked = any(not check.passed and check.severity == "BLOCK" for check in checks)
    return RiskDecision(
        outcome=RiskOutcome.BLOCK if blocked else RiskOutcome.ALLOW, checks=tuple(checks), evaluated_at=now
    )


def _run(item: EffectiveRule, data: RiskInput, now: datetime) -> RiskCheck | None:
    key = item.rule.key
    if not item.enabled:
        return RiskCheck(
            rule=key,
            passed=True,
            message=f"Skipped: disabled by the {item.source} setting",
            details={"skipped": True},
        )
    if item.params is None:
        return RiskCheck(
            rule=key,
            passed=False,
            message=f"Stored parameters are invalid ({item.error}); fix with qt risk set or qt risk reset",
        )
    try:
        return item.rule.check(data, item.params, now)
    except Exception as exc:  # a broken rule must block, never allow
        log.exception("risk_rule_failed", rule=key, strategy_id=data.metadata.strategy_id)
        return RiskCheck(rule=key, passed=False, message=f"Rule failed: {type(exc).__name__}: {exc}")
