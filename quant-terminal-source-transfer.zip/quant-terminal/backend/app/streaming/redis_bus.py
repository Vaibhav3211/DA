"""Redis transport shared by the API and the workers.

Streams carry ordered, bounded (``MAXLEN ~``) event flows between processes; plain keys hold
latest-value state (quotes, feed status, sessions). Every stream entry has a single field ``d``
holding JSON produced by pydantic-core (Decimal -> string, datetime -> ISO 8601, UUID -> string),
so prices never pass through binary floating point on the wire.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any
from uuid import UUID

import pydantic_core
from pydantic import BaseModel
from redis.asyncio import Redis
from redis.exceptions import ResponseError
from redis.typing import KeyT, StreamIdT

from app.domain.enums import CandleInterval, Provider

_FIELD = "d"


class Streams:
    CANDLES = "qt:md:candles"
    FEED = "qt:md:feed"
    SIGNALS = "qt:signals"
    COMMANDS = "qt:commands"

    @staticmethod
    def market_events(provider: Provider) -> str:
        return f"qt:md:events:{provider.value.lower()}"

    @staticmethod
    def all_market_events() -> list[str]:
        return [Streams.market_events(p) for p in Provider]


class Keys:
    KILL_SWITCH = "qt:flags:kill_switch"

    @staticmethod
    def quote(provider: Provider, instrument_id: UUID | str) -> str:
        return f"qt:quote:{provider.value.lower()}:{instrument_id}"

    @staticmethod
    def partial_candle(provider: Provider, instrument_id: UUID | str, interval: CandleInterval) -> str:
        return f"qt:candle:partial:{provider.value.lower()}:{instrument_id}:{interval.value}"

    @staticmethod
    def feed_state(stream_id: str) -> str:
        """Latest ``StreamHealth`` of one provider connection (``<provider>:<account>:<shard>``)."""
        return f"qt:feed:{stream_id}"

    FEED_STATE_PATTERN = "qt:feed:*"

    @staticmethod
    def session(token_hash: str) -> str:
        return f"qt:session:{token_hash}"

    @staticmethod
    def user_sessions(user_id: UUID | str) -> str:
        """Set of session-token hashes per user, so every session can be revoked at once."""
        return f"qt:user_sessions:{user_id}"

    @staticmethod
    def zerodha_pending_login(state_hash: str) -> str:
        return f"qt:zerodha:pending:{state_hash}"

    @staticmethod
    def worker_heartbeat(worker: str) -> str:
        return f"qt:worker:{worker}"

    WORKER_HEARTBEAT_PATTERN = "qt:worker:*"

    @staticmethod
    def login_attempts(scope: str) -> str:
        return f"qt:login:attempts:{scope}"


def encode(payload: BaseModel | Mapping[str, Any]) -> str:
    if isinstance(payload, BaseModel):
        return payload.model_dump_json()
    return pydantic_core.to_json(payload).decode("utf-8")


def decode(raw: str | bytes) -> Any:
    return pydantic_core.from_json(raw)


@dataclass(frozen=True, slots=True)
class StreamMessage:
    stream: str
    message_id: str
    payload: Any


type Payload = BaseModel | Mapping[str, Any]


@dataclass(slots=True)
class Batch:
    """Stream entries and latest-value keys written together in one round trip (not atomically)."""

    entries: list[tuple[str, Payload]] = field(default_factory=list)
    values: list[tuple[str, Payload, float | None]] = field(default_factory=list)
    deletes: list[str] = field(default_factory=list)

    def add(self, stream: str, payload: Payload) -> None:
        self.entries.append((stream, payload))

    def set(self, key: str, value: Payload, *, ttl_seconds: float | None = None) -> None:
        self.values.append((key, value, ttl_seconds))

    def delete(self, key: str) -> None:
        self.deletes.append(key)

    def __len__(self) -> int:
        return len(self.entries) + len(self.values) + len(self.deletes)


class RedisBus:
    def __init__(self, redis: Redis, *, default_maxlen: int) -> None:
        self.redis = redis
        self._default_maxlen = default_maxlen

    @classmethod
    def from_url(cls, url: str, *, default_maxlen: int) -> RedisBus:
        client = Redis.from_url(
            url,
            decode_responses=True,
            health_check_interval=30,
            socket_keepalive=True,
            socket_connect_timeout=5,
        )
        return cls(client, default_maxlen=default_maxlen)

    async def close(self) -> None:
        await self.redis.aclose()

    async def ping(self) -> bool:
        return bool(await self.redis.ping())

    # ---- streams -------------------------------------------------------------------------

    async def publish(
        self, stream: str, payload: BaseModel | Mapping[str, Any], *, maxlen: int | None = None
    ) -> str:
        message_id = await self.redis.xadd(
            stream, {_FIELD: encode(payload)}, maxlen=maxlen or self._default_maxlen, approximate=True
        )
        return str(message_id)

    async def publish_many(
        self, items: Sequence[tuple[str, BaseModel | Mapping[str, Any]]], *, maxlen: int | None = None
    ) -> None:
        if not items:
            return
        async with self.redis.pipeline(transaction=False) as pipe:
            for stream, payload in items:
                pipe.xadd(
                    stream, {_FIELD: encode(payload)}, maxlen=maxlen or self._default_maxlen, approximate=True
                )
            await pipe.execute()

    async def write(self, batch: Batch, *, maxlen: int | None = None) -> None:
        """Send a :class:`Batch` in one pipeline. Payloads are encoded before anything is sent."""
        if not batch:
            return
        limit = maxlen or self._default_maxlen
        entries = [(stream, encode(payload)) for stream, payload in batch.entries]
        values = [(key, encode(value), ttl) for key, value, ttl in batch.values]
        async with self.redis.pipeline(transaction=False) as pipe:
            for stream, data in entries:
                pipe.xadd(stream, {_FIELD: data}, maxlen=limit, approximate=True)
            for key, data, ttl in values:
                if ttl is None:
                    pipe.set(key, data)
                else:
                    pipe.set(key, data, px=max(1, int(ttl * 1000)))
            if batch.deletes:
                pipe.delete(*batch.deletes)
            await pipe.execute()

    async def last_id(self, stream: str) -> str:
        """ID of the newest entry (``0-0`` if the stream is empty), for tailing from "now"."""
        entries = await self.redis.xrevrange(stream, count=1)
        return str(entries[0][0]) if entries else "0-0"

    async def read(
        self, offsets: Mapping[str, str], *, count: int = 500, block_ms: int | None = 1000
    ) -> list[StreamMessage]:
        streams: dict[KeyT, StreamIdT] = dict(offsets.items())
        response = await self.redis.xread(streams, count=count, block=block_ms)
        return _flatten(response)

    async def range(
        self, stream: str, start: str = "-", end: str = "+", *, count: int | None = None
    ) -> list[StreamMessage]:
        """Entries from ``start`` to ``end``, oldest first. IDs are inclusive; ``(<id>`` excludes one."""
        entries = await self.redis.xrange(stream, min=start, max=end, count=count)
        return _flatten([(stream, entries)])

    async def ensure_group(self, stream: str, group: str, *, start_id: str = "$") -> None:
        try:
            await self.redis.xgroup_create(stream, group, id=start_id, mkstream=True)
        except ResponseError as exc:
            if "BUSYGROUP" not in str(exc):
                raise

    async def read_group(
        self,
        group: str,
        consumer: str,
        streams: Sequence[str],
        *,
        pending: bool = False,
        count: int = 500,
        block_ms: int | None = 1000,
    ) -> list[StreamMessage]:
        """Read new entries (``>``) or, with ``pending=True``, this consumer's unacknowledged ones."""
        start = "0" if pending else ">"
        response = await self.redis.xreadgroup(
            group, consumer, dict.fromkeys(streams, start), count=count, block=None if pending else block_ms
        )
        return _flatten(response)

    async def ack(self, stream: str, group: str, *message_ids: str) -> None:
        if message_ids:
            await self.redis.xack(stream, group, *message_ids)

    # ---- key/value -------------------------------------------------------------------------

    async def set_json(
        self, key: str, value: BaseModel | Mapping[str, Any], *, ttl_seconds: float | None = None
    ) -> None:
        if ttl_seconds is None:
            await self.redis.set(key, encode(value))
        else:
            await self.redis.set(key, encode(value), px=max(1, int(ttl_seconds * 1000)))

    async def get_json(self, key: str) -> Any | None:
        raw = await self.redis.get(key)
        return None if raw is None else decode(raw)

    async def getdel_json(self, key: str) -> Any | None:
        raw = await self.redis.getdel(key)
        return None if raw is None else decode(raw)

    async def mget_json(self, keys: Sequence[str]) -> list[Any | None]:
        if not keys:
            return []
        values = await self.redis.mget(list(keys))
        return [None if raw is None else decode(raw) for raw in values]

    async def scan_json(self, pattern: str, *, limit: int = 1000) -> dict[str, Any]:
        keys: list[str] = []
        async for key in self.redis.scan_iter(match=pattern, count=200):
            keys.append(str(key))
            if len(keys) >= limit:
                break
        values = await self.mget_json(keys)
        return {k: v for k, v in zip(keys, values, strict=True) if v is not None}

    async def delete(self, *keys: str) -> None:
        if keys:
            await self.redis.delete(*keys)


def _flatten(response: Any) -> list[StreamMessage]:
    messages: list[StreamMessage] = []
    if not response:
        return messages
    for stream, entries in response:
        for message_id, fields in entries:
            # Entries deleted while pending come back with an empty field map.
            if not fields or _FIELD not in fields:
                messages.append(StreamMessage(str(stream), str(message_id), None))
                continue
            messages.append(StreamMessage(str(stream), str(message_id), decode(fields[_FIELD])))
    return messages
