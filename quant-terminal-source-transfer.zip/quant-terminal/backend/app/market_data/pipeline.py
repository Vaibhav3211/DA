"""Market-data pipeline of one provider account.

The pipeline takes the adapter's normalized events in batches. Each batch is published to the
provider's market-event stream, merged into the latest-quote cache and fed to the candle builder.
Between batches it closes due candles (handed to the shared ``CandleWriter`` and published to the
candle stream), publishes changed forming candles every ``candle_partial_publish_interval_seconds``,
publishes the account's stream health every ``feed_status_publish_interval_seconds`` and hands every
forming candle to the writer every ``candle_checkpoint_interval_seconds``.

Buckets close against a processing horizon: the local clock while the queue is empty, otherwise the
receive time of the newest processed event, so a backlog never closes buckets whose events are still
queued.

Redis writes are retried briefly, then dropped and counted; Redis trouble never stops the feed or the
candles. A retried write may repeat entries that reached Redis before the failure, so stream readers
must tolerate duplicates (events carry ``event_id``; candles are keyed by series, bucket and revision).
"""

from __future__ import annotations

import asyncio
import math
import time
from collections import Counter
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Final, Protocol
from uuid import UUID

from redis.exceptions import RedisError

from app.core.clock import utc_now
from app.core.config import Settings
from app.core.logging import RateLimitedLogger, get_logger
from app.domain.enums import CandleInterval, ConnectionState, EventType, Provider
from app.domain.events import FeedStateChange
from app.domain.models import Candle, NormalizedMarketEvent, ProviderHealth, QuoteSnapshot
from app.market_data.candles.builder import CandleBuilder
from app.market_data.candles.writer import CandleWriter
from app.observability.metrics import (
    CANDLES_DROPPED,
    MARKET_EVENTS_DROPPED,
    MARKET_EVENTS_PUBLISHED,
    PROCESSING_LATENCY,
    REDIS_ERRORS,
)
from app.providers.base import EventQueue, StateChange, StreamObserver, describe_error
from app.streaming.redis_bus import Batch, Keys, RedisBus, Streams

log = get_logger(__name__)
_limited = RateLimitedLogger(log, 30.0)

RETRY_DELAYS: Final = (0.05, 0.25, 1.0)
_STOP_GRACE_SECONDS: Final = 5.0
_LATENCY_SMOOTHING: Final = 0.2
# A partial-candle key outlives its bucket by this much, so readers still see the final candle.
_PARTIAL_TTL_MARGIN_SECONDS: Final = 300
_MIN_FEED_STATE_TTL_SECONDS: Final = 5.0

type _Series = tuple[UUID, CandleInterval]


class FeedSource(Protocol):
    """What the pipeline uses of a ``MarketDataAdapter``."""

    @property
    def provider(self) -> Provider: ...

    @property
    def account_id(self) -> UUID | None: ...

    @property
    def queue(self) -> EventQueue: ...

    async def health(self) -> ProviderHealth: ...


@dataclass(frozen=True, slots=True)
class PipelineConfig:
    quote_ttl_seconds: float
    partial_interval_seconds: float
    feed_status_interval_seconds: float
    checkpoint_interval_seconds: float  # 0 = forming candles are only saved when the pipeline stops
    lateness: timedelta
    batch_size: int = 500
    idle_seconds: float = 0.25  # longest wait for events before the periodic work runs anyway

    @classmethod
    def from_settings(cls, settings: Settings) -> PipelineConfig:
        return cls(
            quote_ttl_seconds=settings.quote_cache_ttl_seconds,
            partial_interval_seconds=settings.candle_partial_publish_interval_seconds,
            feed_status_interval_seconds=settings.feed_status_publish_interval_seconds,
            checkpoint_interval_seconds=settings.candle_checkpoint_interval_seconds,
            lateness=timedelta(seconds=settings.candle_lateness_seconds),
        )


class MarketDataPipeline:
    """Publishes one provider account's events, quotes, candles and stream health."""

    def __init__(
        self,
        source: FeedSource,
        bus: RedisBus,
        builder: CandleBuilder,
        writer: CandleWriter,
        config: PipelineConfig,
        *,
        clock: Callable[[], datetime] = utc_now,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self._source = source
        self._provider = source.provider
        self._bus = bus
        self._builder = builder
        self._writer = writer
        self._config = config
        self._clock = clock
        self._monotonic = monotonic
        self._events_stream = Streams.market_events(self._provider)
        self._quotes: dict[UUID, QuoteSnapshot] = {}
        # Start of the newest candle written to each partial-candle key.
        self._shown: dict[_Series, datetime] = {}
        self._feed_streams: set[str] = set()
        self._last_received_at: datetime | None = None
        self._latency_ms: float | None = None
        self._task: asyncio.Task[None] | None = None
        self._stopping = False
        started = monotonic()
        self._next_partials = started
        self._next_feed_state = started
        self._next_checkpoint = started + config.checkpoint_interval_seconds
        label = self._provider.value
        self._publish_failed = MARKET_EVENTS_DROPPED.labels(label, "publish_failed")
        self._latency = PROCESSING_LATENCY.labels(label)

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    def start(self) -> None:
        if self._task is None:
            self._stopping = False
            name = f"market-data-pipeline:{self._provider.value.lower()}:{self._source.account_id or 'none'}"
            self._task = asyncio.create_task(self._run(), name=name)

    async def stop(self) -> None:
        """Publish what is still queued, close the buckets that ended and hand the forming ones to
        the writer (as cut short by a disconnect). Disconnect the adapter first."""
        task, self._task = self._task, None
        if task is not None:
            self._stopping = True
            await asyncio.wait({task}, timeout=_STOP_GRACE_SECONDS)
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        try:
            queue, size = self._source.queue, self._config.batch_size
            for _ in range(math.ceil(queue.qsize() / size)):
                await self.process(queue.drain(size))
            # Nothing else arrives, so every bucket that ended can close without waiting.
            await self._close(self._clock() + self._config.lateness)
        finally:
            self._writer.add(self._builder.flush_open())
            await self._clear_feed_state()

    def retain(self, instrument_ids: Iterable[UUID]) -> None:
        """Forget instruments that are no longer streamed (their open buckets still close)."""
        active = set(instrument_ids)
        self._builder.retain(active)
        for instrument_id in self._quotes.keys() - active:
            del self._quotes[instrument_id]
        for series in [series for series in self._shown if series[0] not in active]:
            del self._shown[series]

    async def process(self, events: Sequence[NormalizedMarketEvent]) -> bool:
        """Publish a batch of events and their quotes, and build candles from them.

        Returns whether Redis took the batch. Candles are built either way.
        """
        if not events:
            return True
        batch = Batch()
        quotes: dict[UUID, QuoteSnapshot] = {}
        types: Counter[EventType] = Counter()
        for event in events:
            batch.add(self._events_stream, event)
            quotes[event.instrument_id] = QuoteSnapshot.from_event(
                event, quotes.get(event.instrument_id) or self._quotes.get(event.instrument_id)
            )
            types[event.event_type] += 1
            self._builder.add(event)
        self._quotes.update(quotes)
        for instrument_id, snapshot in quotes.items():
            batch.set(
                Keys.quote(self._provider, instrument_id),
                snapshot,
                ttl_seconds=self._config.quote_ttl_seconds,
            )
        newest = max(event.received_at for event in events)
        if self._last_received_at is None or newest > self._last_received_at:
            self._last_received_at = newest
        if not await self._write(batch, "publish_events"):
            self._publish_failed.inc(len(events))
            return False
        self._observe_latency(events)
        for event_type, count in types.items():
            MARKET_EVENTS_PUBLISHED.labels(self._provider.value, event_type.value).inc(count)
        return True

    async def maintain(self) -> None:
        """Close due candles and run the periodic publications that are due."""
        # No await between reading the queue size and closing: nothing can be queued in between.
        horizon = self._clock() if self._source.queue.qsize() == 0 else self._last_received_at
        if horizon is not None:
            await self._close(horizon)
        now = self._monotonic()
        if now >= self._next_partials:
            self._next_partials = now + self._config.partial_interval_seconds
            await self._publish_partials()
        if now >= self._next_feed_state:
            self._next_feed_state = now + self._config.feed_status_interval_seconds
            await self._publish_feed_state()
        interval = self._config.checkpoint_interval_seconds
        if interval > 0 and now >= self._next_checkpoint:
            self._next_checkpoint = now + interval
            self._writer.add(self._builder.checkpoint())

    # ---- internals -------------------------------------------------------------------------------

    async def _run(self) -> None:
        queue = self._source.queue
        while not self._stopping:
            try:
                events = await self._next_batch(queue)
                await self.process(events)
                await self.maintain()
            except Exception as exc:  # one bad batch must not stop the account's data
                _limited.error(
                    "cycle",
                    "market_data_pipeline_failed",
                    provider=self._provider.value,
                    error=describe_error(exc),
                )
                await asyncio.sleep(self._config.idle_seconds)

    async def _next_batch(self, queue: EventQueue) -> list[NormalizedMarketEvent]:
        try:
            async with asyncio.timeout(self._config.idle_seconds):
                first = await queue.get()
        except TimeoutError:
            return []
        return [first, *queue.drain(self._config.batch_size - 1)]

    async def _close(self, horizon: datetime) -> None:
        closed = self._builder.close_due(horizon)
        revisions = self._builder.take_revisions()
        if closed or revisions:
            self._writer.add([*closed, *revisions])  # revisions come last: they replace older versions
        if not closed:
            return
        batch = Batch()
        for candle in closed:
            batch.add(Streams.CANDLES, candle)
            shown = self._shown.get((candle.instrument_id, candle.interval))
            if shown is None or shown <= candle.bucket_start:  # keep a newer forming candle on the key
                self._show(batch, candle)
        if not await self._write(batch, "publish_candles"):
            CANDLES_DROPPED.labels(reason="publish_failed").inc(len(closed))

    async def _publish_partials(self) -> None:
        batch = Batch()
        for candle in self._builder.partials():
            self._show(batch, candle)
        await self._write(batch, "publish_partials")

    def _show(self, batch: Batch, candle: Candle) -> None:
        key = Keys.partial_candle(self._provider, candle.instrument_id, candle.interval)
        batch.set(key, candle, ttl_seconds=candle.interval.seconds + _PARTIAL_TTL_MARGIN_SECONDS)
        self._shown[(candle.instrument_id, candle.interval)] = candle.bucket_start

    async def _publish_feed_state(self) -> None:
        health = await self._source.health()
        ttl = max(_MIN_FEED_STATE_TTL_SECONDS, 3 * self._config.feed_status_interval_seconds)
        latency = None if self._latency_ms is None else round(self._latency_ms, 1)
        batch = Batch()
        current = {stream.stream_id for stream in health.streams}
        for stream in health.streams:
            state = stream.model_copy(update={"processing_latency_ms": latency})
            batch.set(Keys.feed_state(stream.stream_id), state, ttl_seconds=ttl)
        for stream_id in sorted(self._feed_streams - current):
            batch.delete(Keys.feed_state(stream_id))
        if await self._write(batch, "publish_feed_state"):
            self._feed_streams = current
        else:
            self._feed_streams |= current  # delete the keys of vanished streams next time

    async def _clear_feed_state(self) -> None:
        batch = Batch()
        for stream_id in sorted(self._feed_streams):
            batch.delete(Keys.feed_state(stream_id))
        if await self._write(batch, "clear_feed_state"):
            self._feed_streams = set()

    def _observe_latency(self, events: Sequence[NormalizedMarketEvent]) -> None:
        now = self._clock()
        total = 0.0
        for event in events:
            seconds = max(0.0, (now - event.received_at).total_seconds())
            self._latency.observe(seconds)
            total += seconds
        mean_ms = total * 1000 / len(events)
        previous = self._latency_ms
        self._latency_ms = (
            mean_ms if previous is None else previous + _LATENCY_SMOOTHING * (mean_ms - previous)
        )

    async def _write(self, batch: Batch, operation: str) -> bool:
        if not batch:
            return True
        attempts = len(RETRY_DELAYS) + 1
        for attempt in range(attempts):
            try:
                await self._bus.write(batch)
            except (RedisError, OSError) as exc:
                REDIS_ERRORS.labels(operation=operation).inc()
                if attempt + 1 == attempts:
                    _limited.warning(
                        operation,
                        "redis_write_failed",
                        provider=self._provider.value,
                        operation=operation,
                        entries=len(batch),
                        error=describe_error(exc),
                    )
                    return False
                await asyncio.sleep(RETRY_DELAYS[attempt])
            else:
                return True
        return False


class FeedChangePublisher:
    """``StreamObserver`` that announces stream state changes on the feed stream, then passes them
    to an optional inner observer (e.g. ``AccountConnectionObserver``, which records them).

    A Redis failure does not keep the change from being recorded; the inner observer's failures
    propagate to the adapter, which logs them.
    """

    def __init__(self, bus: RedisBus, inner: StreamObserver | None = None) -> None:
        self._bus = bus
        self._inner = inner

    async def on_state_change(self, change: StateChange) -> None:
        await self._announce(change)
        if self._inner is not None:
            await self._inner.on_state_change(change)

    async def _announce(self, change: StateChange) -> None:
        message = FeedStateChange(
            provider=change.provider,
            account_id=change.account_id,
            stream_id=change.stream_id,
            previous_state=change.previous or ConnectionState.IDLE,
            state=change.state,
            reason=change.reason,
            at=change.occurred_at,
        )
        try:
            await self._bus.publish(Streams.FEED, message)
        except (RedisError, OSError) as exc:
            REDIS_ERRORS.labels(operation="publish_feed_change").inc()
            _limited.warning(
                "feed_change",
                "feed_state_change_not_published",
                stream_id=change.stream_id,
                state=change.state.value,
                error=describe_error(exc),
            )
