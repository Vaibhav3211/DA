"""Connection manager: runs the market data of every enabled provider account.

Each planned account gets a feed: its adapter (the provider connections), a feed tracker (the
coverage history its candles are judged by) and a pipeline. ``reconcile`` brings the feeds in line
with the subscription plan: feeds of accounts that are no longer planned stop, newly planned
accounts start (resuming the forming candles an earlier run saved) and running feeds take their new
instrument sets. A feed whose capabilities changed restarts, since its adapter checks instruments
against them. The worker reconciles periodically and after every command saying that accounts or
instruments changed, so a lost command only delays a change.

An instrument set the adapter refuses (more than the account's connections hold) leaves the previous
set streaming. The refusal is logged and reported in ``details``, and is not retried until the plan
changes.
"""

from __future__ import annotations

import asyncio
import time
from collections import Counter
from collections.abc import Awaitable, Callable, Collection, Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Final, Protocol
from uuid import UUID

from app.core.clock import utc_now
from app.core.config import Settings
from app.core.logging import get_logger
from app.domain.enums import CandleInterval, Provider
from app.domain.events import CommandType, WorkerCommand
from app.domain.models import Candle, ProviderInstrument
from app.market_data.calendars.service import MarketCalendar
from app.market_data.candles.builder import CandleBuilder
from app.market_data.candles.store import Listing, load_forming
from app.market_data.candles.writer import CandleWriter
from app.market_data.feed import FeedTracker
from app.market_data.pipeline import FeedChangePublisher, FeedSource, MarketDataPipeline, PipelineConfig
from app.market_data.subscriptions import AccountPlan, StreamAccount, SubscriptionPlan
from app.persistence.database import Database
from app.providers.base import StateChange, describe_error
from app.providers.errors import SubscriptionCapacityError, UnsupportedInstrumentError
from app.providers.registry import create_adapter
from app.services.provider_accounts import AccountConnectionObserver, ProviderAccountService
from app.streaming.redis_bus import RedisBus

log = get_logger(__name__)

# Commands after which the plan may differ.
_PLAN_CHANGES: Final = frozenset(
    {CommandType.CONNECT_ACCOUNT, CommandType.DISCONNECT_ACCOUNT, CommandType.REFRESH_SUBSCRIPTIONS}
)
# Commands saying an account's credentials changed (a login, a logout or a dropped token).
_CREDENTIAL_CHANGES: Final = frozenset({CommandType.CONNECT_ACCOUNT, CommandType.DISCONNECT_ACCOUNT})


class Planner(Protocol):
    async def plan(self) -> SubscriptionPlan: ...


class FeedAdapter(FeedSource, Protocol):
    """What the manager uses of a ``MarketDataAdapter``."""

    async def connect(self) -> None: ...

    async def disconnect(self) -> None: ...

    async def set_subscriptions(self, instruments: Sequence[ProviderInstrument]) -> None: ...

    def request_reconnect(self, reason: str) -> None: ...


# A new, unconnected adapter for a planned account that reports its state changes to the listener.
type AdapterFactory = Callable[[AccountPlan, Callable[[StateChange], None]], FeedAdapter]
# The forming candles an earlier run saved, as ``load_forming`` reads them.
type FormingLoader = Callable[
    [Provider, Mapping[UUID, Listing], Collection[CandleInterval], datetime], Awaitable[list[Candle]]
]


@dataclass(slots=True)
class _Feed:
    plan: AccountPlan  # the newest plan of the account
    adapter: FeedAdapter
    tracker: FeedTracker
    pipeline: MarketDataPipeline
    instruments: tuple[ProviderInstrument, ...] = ()  # the set the adapter accepted
    refused: str | None = None  # why the adapter refused the planned set


class ConnectionManager:
    """Starts, updates and stops one feed per planned provider account."""

    def __init__(
        self,
        settings: Settings,
        planner: Planner,
        adapters: AdapterFactory,
        bus: RedisBus,
        writer: CandleWriter,
        calendar: MarketCalendar,
        forming: FormingLoader,
        *,
        clock: Callable[[], datetime] = utc_now,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self._settings = settings
        self._planner = planner
        self._adapters = adapters
        self._bus = bus
        self._writer = writer
        self._calendar = calendar
        self._forming = forming
        self._clock = clock
        self._monotonic = monotonic
        self._config = PipelineConfig.from_settings(settings)
        self._plan = SubscriptionPlan(())
        self._feeds: dict[UUID, _Feed] = {}
        self._failed: dict[UUID, tuple[StreamAccount, str]] = {}  # feeds that could not start
        self._lock = asyncio.Lock()

    async def reconcile(self) -> set[UUID]:
        """Bring the feeds in line with the current plan; returns the accounts whose feed started.

        When no plan can be made (e.g. the database is down), the feeds stream what they streamed.
        """
        async with self._lock:
            try:
                plan = await self._planner.plan()
            except Exception as exc:  # keep streaming; the next reconciliation tries again
                log.error("subscription_plan_failed", error=describe_error(exc))
                return set()
            self._report(plan)
            planned = {item.account.account_id: item for item in plan.accounts}
            stopping: dict[UUID, str] = {}
            for account_id, feed in self._feeds.items():
                target = planned.get(account_id)
                if target is None:
                    stopping[account_id] = "the account no longer streams"
                elif target.capabilities != feed.plan.capabilities:
                    stopping[account_id] = "its capabilities changed"
            await asyncio.gather(*(self._stop(account_id, reason) for account_id, reason in stopping.items()))
            self._failed = {key: value for key, value in self._failed.items() if key in planned}
            started: set[UUID] = set()
            for account_id, item in planned.items():
                running = self._feeds.get(account_id)
                try:
                    if running is None:
                        if await self._start(item):
                            started.add(account_id)
                    else:
                        await self._update(running, item)
                except Exception as exc:  # one account's trouble must not hold up the others
                    log.error("feed_reconcile_failed", **_fields(item.account), error=describe_error(exc))
            return started

    async def handle(self, commands: Iterable[WorkerCommand]) -> None:
        """Apply a batch of commands: one reconciliation, then a reconnect of every running feed whose
        account's credentials changed (a feed the reconciliation started reads them anyway)."""
        relevant = [command for command in commands if command.type in _PLAN_CHANGES]
        if not relevant:
            return
        started = await self.reconcile()
        changed = dict.fromkeys(
            command.account_id
            for command in relevant
            if command.type in _CREDENTIAL_CHANGES and command.account_id is not None
        )
        for account_id in changed:
            feed = self._feeds.get(account_id) if account_id not in started else None
            if feed is not None:
                feed.adapter.request_reconnect("credentials changed")
                log.info("feed_reconnect_requested", **_fields(feed.plan.account))

    async def stop_all(self) -> None:
        async with self._lock:
            await asyncio.gather(
                *(self._stop(account_id, "the worker is stopping") for account_id in list(self._feeds))
            )

    def details(self) -> dict[str, Any]:
        """The feeds' state for the worker heartbeat. ``queue_depth`` and ``queue_capacity`` describe
        the fullest event queue, the one the health check warns about."""
        queues = [feed.adapter.queue for feed in self._feeds.values()]
        fullest = max(queues, key=lambda queue: queue.qsize() / queue.capacity, default=None)
        return {
            "feeds": [
                {
                    **_fields(feed.plan.account),
                    "instruments": len(feed.instruments),
                    "planned": len(feed.plan.instruments),
                    "refused": feed.refused,
                    "queued_events": feed.adapter.queue.qsize(),
                }
                for feed in self._feeds.values()
            ],
            "failed": [{**_fields(account), "error": error} for account, error in self._failed.values()],
            "idle": [{**_fields(idle.account), "reason": idle.reason} for idle in self._plan.idle],
            "skipped": dict(Counter(skip.reason.value for skip in self._plan.skipped)),
            "queue_depth": 0 if fullest is None else fullest.qsize(),
            "queue_capacity": self._settings.provider_queue_size if fullest is None else fullest.capacity,
        }

    # ---- internals -------------------------------------------------------------------------------

    def _report(self, plan: SubscriptionPlan) -> None:
        """Log the accounts that may not stream and the instruments not streamed, when they change."""
        if plan.idle != self._plan.idle:
            (log.warning if plan.idle else log.info)(
                "idle_accounts",
                accounts=[
                    f"{idle.account.provider.value}/{idle.account.label}: {idle.reason}" for idle in plan.idle
                ],
            )
        if plan.skipped != self._plan.skipped:
            (log.warning if plan.skipped else log.info)(
                "skipped_instruments",
                count=len(plan.skipped),
                reasons=dict(Counter(skip.reason.value for skip in plan.skipped)),
            )
        self._plan = plan

    async def _start(self, plan: AccountPlan) -> bool:
        account = plan.account
        tracker = FeedTracker()
        try:
            adapter = self._adapters(plan, tracker.on_state_change)
        except Exception as exc:  # e.g. the provider may no longer stream here
            self._fail(account, exc)
            return False
        builder = CandleBuilder(
            account.provider,
            self._settings.candle_intervals,
            self._calendar,
            tracker,
            anchor=self._settings.candle_anchor,
            lateness=self._config.lateness,
        )
        pipeline = MarketDataPipeline(
            adapter,
            self._bus,
            builder,
            self._writer,
            self._config,
            clock=self._clock,
            monotonic=self._monotonic,
        )
        feed = _Feed(plan, adapter, tracker, pipeline)
        await self._subscribe(feed, plan.instruments)
        await self._resume(feed, builder)
        pipeline.start()
        try:
            await adapter.connect()
        except Exception as exc:
            await self._shutdown(feed)
            self._fail(account, exc)
            return False
        self._feeds[account.account_id] = feed
        self._failed.pop(account.account_id, None)
        log.info("feed_started", **_fields(account), instruments=len(feed.instruments))
        return True

    async def _update(self, feed: _Feed, plan: AccountPlan) -> None:
        previous, feed.plan = feed.plan, plan  # e.g. a new label
        if _by_id(plan.instruments) != _by_id(previous.instruments):
            await self._subscribe(feed, plan.instruments)

    async def _subscribe(self, feed: _Feed, instruments: tuple[ProviderInstrument, ...]) -> None:
        try:
            await feed.adapter.set_subscriptions(instruments)
        except (SubscriptionCapacityError, UnsupportedInstrumentError) as exc:
            feed.refused = describe_error(exc)
            log.error(
                "subscriptions_refused",
                **_fields(feed.plan.account),
                planned=len(instruments),
                streaming=len(feed.instruments),
                error=feed.refused,
            )
            return
        feed.instruments, feed.refused = instruments, None
        ids = [instrument.instrument_id for instrument in instruments]
        feed.tracker.note_subscriptions(ids, self._clock())
        feed.pipeline.retain(ids)
        log.info("subscriptions_set", **_fields(feed.plan.account), instruments=len(ids))

    async def _resume(self, feed: _Feed, builder: CandleBuilder) -> None:
        """Resume the forming candles that an earlier run, or this account's previous feed, saved."""
        if not feed.instruments:
            return
        try:
            await self._writer.flush()  # the candles a stopped feed handed over are stored first
            candles = await self._forming(
                feed.plan.account.provider,
                {instrument.instrument_id: instrument for instrument in feed.instruments},
                builder.intervals,
                self._clock(),
            )
        except Exception as exc:  # the buckets start afresh instead
            log.warning(
                "forming_candles_not_resumed", **_fields(feed.plan.account), error=describe_error(exc)
            )
            return
        resumed = builder.seed(candles)
        if resumed:
            log.info("forming_candles_resumed", **_fields(feed.plan.account), candles=resumed)

    async def _stop(self, account_id: UUID, reason: str) -> None:
        feed = self._feeds.pop(account_id)
        await self._shutdown(feed)
        log.info("feed_stopped", **_fields(feed.plan.account), reason=reason)

    async def _shutdown(self, feed: _Feed) -> None:
        """Disconnect, then stop the pipeline, which hands the forming candles to the writer."""
        try:
            await feed.adapter.disconnect()
        except Exception as exc:  # the pipeline must still stop and save its candles
            log.error("feed_disconnect_failed", **_fields(feed.plan.account), error=describe_error(exc))
        feed.tracker.note_disconnect(self._clock())
        try:
            await feed.pipeline.stop()
        except Exception as exc:
            log.error(
                "market_data_pipeline_stop_failed", **_fields(feed.plan.account), error=describe_error(exc)
            )

    def _fail(self, account: StreamAccount, exc: Exception) -> None:
        error = describe_error(exc)
        previous = self._failed.get(account.account_id)
        self._failed[account.account_id] = (account, error)
        if previous is None or previous[1] != error:  # retried every reconciliation; logged once
            log.error("feed_start_failed", **_fields(account), error=error)


def adapter_factory(
    settings: Settings,
    bus: RedisBus,
    accounts: ProviderAccountService,
    calendar: MarketCalendar,
    *,
    clock: Callable[[], datetime] = utc_now,
) -> AdapterFactory:
    """Adapters that read the account's stored credentials, announce and record their state changes
    and know when their exchanges trade."""
    observer = FeedChangePublisher(bus, AccountConnectionObserver(accounts))

    def create(plan: AccountPlan, listener: Callable[[StateChange], None]) -> FeedAdapter:
        account = plan.account
        return create_adapter(
            account.provider,
            account_id=account.account_id,
            settings=settings,
            capabilities=plan.capabilities,
            credentials=accounts.credential_source(account.account_id),
            observer=observer,
            session_open=lambda exchanges: calendar.session_open(exchanges, clock()),
            state_listener=listener,
        )

    return create


def forming_loader(database: Database) -> FormingLoader:
    async def load(
        provider: Provider,
        instruments: Mapping[UUID, Listing],
        intervals: Collection[CandleInterval],
        after: datetime,
    ) -> list[Candle]:
        async with database.session() as session:
            return await load_forming(session, provider, instruments, intervals, after)

    return load


def _fields(account: StreamAccount) -> dict[str, str]:
    return {"provider": account.provider.value, "account_id": str(account.account_id), "label": account.label}


def _by_id(instruments: Iterable[ProviderInstrument]) -> dict[UUID, ProviderInstrument]:
    return {instrument.instrument_id: instrument for instrument in instruments}
