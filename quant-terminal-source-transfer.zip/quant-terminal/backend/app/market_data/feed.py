"""Feed coverage history of one provider account.

The candle builder asks when an instrument's data can be trusted to be complete: while the
account's feed was up *and* the instrument was subscribed. Events are processed some time after
they were received, so questions are about the past and this keeps a short history of up periods
and subscription periods rather than only the current state.
"""

from __future__ import annotations

from bisect import bisect_left, bisect_right
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from uuid import UUID

from app.domain.enums import ConnectionState
from app.providers.base import StateChange

# A connection that is still starting (e.g. one added for new instruments) is not an outage.
_UP_STATES = frozenset({ConnectionState.IDLE, ConnectionState.CONNECTING, ConnectionState.CONNECTED})
DEFAULT_RETENTION = timedelta(days=2)
_MAX_FEED_PERIODS = 4096
_MAX_SUBSCRIPTION_PERIODS = 64


@dataclass(slots=True)
class Periods:
    """Disjoint ``[start, end)`` periods in time order; only the newest may be open (``end=None``)."""

    starts: list[datetime] = field(default_factory=list)
    ends: list[datetime | None] = field(default_factory=list)

    @property
    def is_open(self) -> bool:
        return bool(self.ends) and self.ends[-1] is None

    def open(self, at: datetime) -> None:
        if self.is_open:
            return
        previous_end = self.ends[-1] if self.ends else None
        self.starts.append(at if previous_end is None else max(at, previous_end))
        self.ends.append(None)

    def close(self, at: datetime) -> None:
        if self.is_open:
            self.ends[-1] = max(at, self.starts[-1])

    def find(self, at: datetime) -> int | None:
        """Index of the period containing ``at``."""
        index = bisect_right(self.starts, at) - 1
        if index < 0:
            return None
        end = self.ends[index]
        return index if end is None or at < end else None

    def spans(self, start: datetime, end: datetime) -> bool:
        """Whether a single period covers ``[start, end)``."""
        index = self.find(start)
        if index is None:
            return False
        period_end = self.ends[index]
        return period_end is None or end <= period_end

    def ended_within(self, start: datetime, end: datetime) -> bool:
        # Closed periods are ordered, so their ends ascend: walk back from the last one starting
        # before ``end`` until the ends fall before ``start``.
        for index in range(bisect_left(self.starts, end) - 1, -1, -1):
            period_end = self.ends[index]
            if period_end is None:
                continue
            if period_end < start:
                return False
            if period_end < end:
                return True
        return False

    def prune(self, before: datetime, keep: int) -> datetime | None:
        """Forget closed periods that ended before ``before`` and the oldest beyond ``keep``.

        Returns the latest end forgotten, if any.
        """
        excess = len(self.starts) - keep
        count = 0
        for end in self.ends:
            if end is None or (end >= before and count >= excess):
                break
            count += 1
        if count == 0:
            return None
        forgotten = self.ends[count - 1]
        del self.starts[:count]
        del self.ends[:count]
        return forgotten


class FeedTracker:
    """Up/down history of one provider account's feed and its instruments' subscriptions.

    The feed is up while at least one stream is connected and every other stream is connected or
    still starting. An instrument is covered at time t when the feed was up and the instrument
    was subscribed at t; its coverage starts at the later of the two period starts.
    """

    def __init__(self, *, retention: timedelta = DEFAULT_RETENTION) -> None:
        self._retention = retention
        self._streams: dict[str, ConnectionState] = {}
        self._feed = Periods()
        self._subscriptions: dict[UUID, Periods] = {}
        # Answers about spans starting before this point are conservative (history was dropped).
        self._forgotten_until: datetime | None = None

    @property
    def is_up(self) -> bool:
        return self._feed.is_open

    def on_state_change(self, change: StateChange) -> None:
        """Synchronous stream state listener (``MarketDataAdapter(state_listener=...)``)."""
        if change.state is ConnectionState.STOPPED:
            self._streams.pop(change.stream_id, None)
        else:
            self._streams[change.stream_id] = change.state
        self._refresh(change.occurred_at)

    def note_subscriptions(self, instrument_ids: Iterable[UUID], at: datetime) -> None:
        """Record the complete subscribed set as of ``at``; call after the adapter accepted it."""
        wanted = set(instrument_ids)
        for instrument_id in wanted:
            self._subscriptions.setdefault(instrument_id, Periods()).open(at)
        for instrument_id, periods in self._subscriptions.items():
            if instrument_id not in wanted:
                periods.close(at)
        self._prune(at)

    def note_disconnect(self, at: datetime) -> None:
        """The adapter was disconnected: the feed is down whatever its streams reported last."""
        self._streams.clear()
        self._refresh(at)

    def coverage_start(self, instrument_id: UUID, at: datetime) -> datetime | None:
        """Since when the instrument has been covered without a break, if it is covered at ``at``."""
        feed = self._feed.find(at)
        periods = self._subscriptions.get(instrument_id)
        subscribed = periods.find(at) if periods is not None else None
        if feed is None or periods is None or subscribed is None:
            return None
        return max(self._feed.starts[feed], periods.starts[subscribed])

    def covered(self, instrument_id: UUID, start: datetime, end: datetime) -> bool:
        """Whether the instrument was covered throughout ``[start, end)``."""
        periods = self._subscriptions.get(instrument_id)
        return periods is not None and self._feed.spans(start, end) and periods.spans(start, end)

    def interrupted(self, instrument_id: UUID, start: datetime, end: datetime) -> bool:
        """Whether the feed went down or the instrument was unsubscribed within ``[start, end)``."""
        if self._forgotten_until is not None and start <= self._forgotten_until:
            return True
        if self._feed.ended_within(start, end):
            return True
        periods = self._subscriptions.get(instrument_id)
        return periods is not None and periods.ended_within(start, end)

    def _refresh(self, at: datetime) -> None:
        states = self._streams.values()
        up = ConnectionState.CONNECTED in states and all(state in _UP_STATES for state in states)
        if up and not self._feed.is_open:
            self._feed.open(at)
            self._prune(at)
        elif not up:
            self._feed.close(at)

    def _prune(self, now: datetime) -> None:
        before = now - self._retention
        forgotten = [self._feed.prune(before, _MAX_FEED_PERIODS)]
        for instrument_id, periods in list(self._subscriptions.items()):
            forgotten.append(periods.prune(before, _MAX_SUBSCRIPTION_PERIODS))
            if not periods.starts:
                del self._subscriptions[instrument_id]
        latest = max((at for at in forgotten if at is not None), default=None)
        if latest is not None and (self._forgotten_until is None or latest > self._forgotten_until):
            self._forgotten_until = latest
