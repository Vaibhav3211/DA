"""Background candle writer.

Pipelines hand closed candles, revisions and forming-candle checkpoints to one writer, which upserts
them every ``candle_flush_interval_seconds``. Rows are keyed by candle, so a newer version of a
candle replaces a pending older one. A failed write keeps its rows for the next attempt; the backlog
is capped and drops its oldest rows first. A chunk the database refuses (e.g. its instrument was
deleted meanwhile) is retried row by row, so only the offending rows are lost.
"""

from __future__ import annotations

import asyncio
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from itertools import islice
from typing import Any, Final

from sqlalchemy.exc import DataError, DBAPIError, IntegrityError

from app.core.logging import RateLimitedLogger, get_logger
from app.domain.models import Candle
from app.market_data.candles.store import UPSERT_CHUNK, CandleKey, candle_key, candle_values, upsert_candles
from app.observability.metrics import CANDLES_DROPPED, DB_WRITE_ERRORS
from app.persistence.database import Database
from app.providers.base import describe_error

log = get_logger(__name__)
_limited = RateLimitedLogger(log, 30.0)

DEFAULT_MAX_PENDING: Final = 50_000


@dataclass(frozen=True, slots=True)
class _Pending:
    row: dict[str, Any]
    closed: bool


type _Item = tuple[CandleKey, _Pending]


class CandleWriter:
    def __init__(
        self, database: Database, *, interval_seconds: float, max_pending: int = DEFAULT_MAX_PENDING
    ) -> None:
        self._database = database
        self._interval = interval_seconds
        self._max_pending = max_pending
        self._pending: dict[CandleKey, _Pending] = {}
        self._lock = asyncio.Lock()
        self._task: asyncio.Task[None] | None = None
        self._write_errors = DB_WRITE_ERRORS.labels(table="candles")

    @property
    def pending(self) -> int:
        return len(self._pending)

    def add(self, candles: Iterable[Candle]) -> None:
        for candle in candles:
            key = candle_key(candle)
            self._pending.pop(key, None)  # newest last: a full backlog drops the oldest rows first
            self._pending[key] = _Pending(candle_values(candle), candle.is_closed)
        self._trim()

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run(), name="candle-writer")

    async def close(self) -> None:
        """Stop the periodic flush and write what is pending; rows that cannot be written are lost."""
        task, self._task = self._task, None
        if task is not None:
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        if await self._flush_logged():
            return
        closed = sum(pending.closed for pending in self._pending.values())
        CANDLES_DROPPED.labels(reason="persist_failed").inc(closed)
        log.error("candles_not_persisted", rows=len(self._pending), closed_candles=closed)
        self._pending.clear()

    async def flush(self) -> int:
        """Write every pending row and return how many were stored.

        A failure that is not about the rows themselves propagates and keeps the unwritten rows.
        """
        async with self._lock:
            items = list(self._pending.items())
            self._pending.clear()
            stored = 0
            for start in range(0, len(items), UPSERT_CHUNK):
                try:
                    stored += await self._write(items[start : start + UPSERT_CHUNK])
                except BaseException:
                    self._pending = dict(items[start:]) | self._pending
                    self._trim()
                    raise
            return stored

    async def _run(self) -> None:
        while True:
            await asyncio.sleep(self._interval)
            await self._flush_logged()

    async def _flush_logged(self) -> bool:
        try:
            await self.flush()
        except Exception as exc:  # the rows stay pending for the next attempt
            self._write_errors.inc()
            _limited.warning("flush", "candle_flush_failed", pending=len(self._pending), error=_describe(exc))
            return False
        return True

    async def _write(self, items: Sequence[_Item]) -> int:
        try:
            async with self._database.transaction() as session:
                await upsert_candles(session, [pending.row for _, pending in items])
        except (IntegrityError, DataError) as exc:
            if len(items) == 1:
                self._reject(items[0], exc)
                return 0
            stored = 0
            for item in items:  # isolate the rows the database refuses
                stored += await self._write([item])
            return stored
        return len(items)

    def _reject(self, item: _Item, exc: DBAPIError) -> None:
        (provider, instrument_id, interval, bucket_start), pending = item
        self._write_errors.inc()
        if pending.closed:
            CANDLES_DROPPED.labels(reason="persist_failed").inc()
        _limited.error(
            "rejected",
            "candle_rejected",
            provider=provider.value,
            instrument_id=str(instrument_id),
            interval=interval.value,
            bucket_start=bucket_start.isoformat(),
            error=_describe(exc),
        )

    def _trim(self) -> None:
        excess = len(self._pending) - self._max_pending
        if excess <= 0:
            return
        closed = sum(self._pending.pop(key).closed for key in list(islice(self._pending, excess)))
        CANDLES_DROPPED.labels(reason="persist_backlog").inc(closed)
        _limited.warning("backlog", "candle_backlog_full", dropped=excess, closed_candles=closed)


def _describe(exc: BaseException) -> str:
    """Leaves out the statement and parameters SQLAlchemy puts in its messages."""
    if isinstance(exc, DBAPIError) and exc.orig is not None:
        return describe_error(exc.orig)
    return describe_error(exc)
