"""Live OHLCV candle builder.

One builder per provider-account pipeline turns that account's normalized events into candles for
every configured interval. Buckets follow the exchange calendar: intraday buckets start at the
session open (or on the exchange-local clock, clipped to the session) and the last one ends at the
close; the daily bucket is the session itself. Events outside the session are skipped. When the
calendar does not know an exchange's hours, buckets follow the exchange-local day and are flagged
OUTSIDE_SESSION.

Events are bucketed by their exchange/provider timestamp (receive time when there is none). A bucket
closes once the processing horizon (local clock) passes its end plus the lateness allowance, so
source latency plus clock skew must stay below ``candle_lateness_seconds``. Later events for a
closed bucket are rejected and counted, and the series' last closed candle is revised once with
LATE_EVENTS_IGNORED. Feed coverage (``FeedTracker``) marks buckets that started before the data did
(PARTIAL_START), follow a stretch without data (GAP_BEFORE) or saw the feed drop
(DISCONNECTED_DURING).

Volume: providers report cumulative day volume, so an intraday bucket's volume is the increase
across it. A delta that cannot be derived reliably (coverage broke since the previous value, the
value decreased, the first value of the day arrived after the open) makes the bucket's volume
unknown (``None`` with VOLUME_INCOMPLETE). The daily candle takes the latest cumulative value.
"""

from __future__ import annotations

import heapq
import itertools
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal
from typing import NamedTuple, Protocol
from uuid import UUID

from app.core.config import CandleAnchor
from app.domain.enums import (
    CandleFlag,
    CandleInterval,
    DataStatus,
    Exchange,
    Provider,
    Segment,
    VolumeSemantics,
    worst_status,
)
from app.domain.models import Candle, NormalizedMarketEvent
from app.market_data.calendars.service import DayKind, MarketCalendar
from app.observability.metrics import CANDLE_EVENTS_SKIPPED, CANDLE_LATE_EVENTS, CANDLES_CLOSED

DEFAULT_LATENESS = timedelta(seconds=2)
# Recomputed from the events when a persisted forming candle is resumed.
_DERIVED_VOLUME_FLAGS = frozenset({CandleFlag.VOLUME_INCOMPLETE, CandleFlag.VOLUME_UNAVAILABLE})


class Coverage(Protocol):
    """Feed coverage history of the account (implemented by ``FeedTracker``)."""

    def coverage_start(self, instrument_id: UUID, at: datetime) -> datetime | None: ...

    def covered(self, instrument_id: UUID, start: datetime, end: datetime) -> bool: ...

    def interrupted(self, instrument_id: UUID, start: datetime, end: datetime) -> bool: ...


@dataclass(frozen=True, slots=True)
class Slot:
    """One bucket: ``[start, end)`` in UTC."""

    start: datetime
    end: datetime
    session_date: date
    # Start of the trading session; None when the exchange's hours are unknown.
    session_open: datetime | None

    @property
    def outside_session(self) -> bool:
        return self.session_open is None


@dataclass(frozen=True, slots=True)
class BucketFrame:
    """Where the buckets of one exchange day lie."""

    session_date: date
    first: datetime  # earliest bucket start: the session open (local midnight when unknown)
    last: datetime  # latest bucket end: the session close (the next local midnight when unknown)
    midnight: datetime  # local midnight starting the day, origin of clock-anchored buckets
    known: bool

    def slot(self, at: datetime, interval: CandleInterval, anchor: CandleAnchor) -> Slot:
        session_open = self.first if self.known else None
        if interval is CandleInterval.D1:
            return Slot(self.first, self.last, self.session_date, session_open)
        step = timedelta(seconds=interval.seconds)
        origin = self.first if anchor is CandleAnchor.SESSION else self.midnight
        start = origin + (at - origin) // step * step
        return Slot(max(start, self.first), min(start + step, self.last), self.session_date, session_open)


def bucket_frame(calendar: MarketCalendar, exchange: Exchange, at: datetime) -> BucketFrame | None:
    """Bucket frame of the exchange day containing ``at``; None when ``at`` is outside the session."""
    day = calendar.trading_day_at(exchange, at)
    if day.kind is not DayKind.SESSION and day.kind is not DayKind.UNKNOWN:
        return None
    zone = calendar.timezone(exchange)
    midnight = datetime.combine(day.session_date, time(), tzinfo=zone).astimezone(UTC)
    if day.kind is DayKind.UNKNOWN:
        next_midnight = datetime.combine(day.session_date + timedelta(days=1), time(), tzinfo=zone)
        return BucketFrame(day.session_date, midnight, next_midnight.astimezone(UTC), midnight, known=False)
    if day.open_at is None or day.close_at is None or not day.open_at <= at < day.close_at:
        return None
    return BucketFrame(day.session_date, day.open_at, day.close_at, midnight, known=True)


def bucket_for(
    calendar: MarketCalendar, exchange: Exchange, at: datetime, interval: CandleInterval, anchor: CandleAnchor
) -> Slot | None:
    frame = bucket_frame(calendar, exchange, at)
    return None if frame is None else frame.slot(at, interval, anchor)


class _VolumeChange(NamedTuple):
    delta: int | None  # None: no reliable delta could be derived
    cumulative: int | None  # the day's cumulative volume, when the provider reports one
    reset: bool = False


@dataclass(slots=True)
class _VolumeState:
    """Last cumulative day volume seen for an instrument."""

    cumulative: int
    received_at: datetime
    event_time: datetime
    session_date: date


@dataclass(slots=True)
class _Bucket:
    symbol: str
    exchange: Exchange
    segment: Segment
    account_id: UUID | None
    start: datetime
    end: datetime
    open_price: Decimal
    high_price: Decimal
    low_price: Decimal
    close_price: Decimal
    # Event times of the open and close prices.
    first_event_at: datetime
    last_event_at: datetime
    status: DataStatus
    flags: set[CandleFlag]
    event_count: int = 0
    volume: int = 0
    volume_seen: bool = False
    volume_unknown: bool = False
    volume_at: datetime | None = None  # daily buckets: event time of the cumulative value used


@dataclass(slots=True)
class _Series:
    """Buckets of one instrument and interval."""

    open: dict[datetime, _Bucket] = field(default_factory=dict)
    # End and session of the newest bucket opened (the reference for GAP_BEFORE).
    last_end: datetime | None = None
    last_session: date | None = None
    last_closed: Candle | None = None


_Key = tuple[UUID, CandleInterval]


class CandleBuilder:
    """Builds candles of one provider account. Not thread-safe; owned by its pipeline task."""

    def __init__(
        self,
        provider: Provider,
        intervals: Sequence[CandleInterval],
        calendar: MarketCalendar,
        coverage: Coverage,
        *,
        anchor: CandleAnchor = CandleAnchor.SESSION,
        lateness: timedelta = DEFAULT_LATENESS,
    ) -> None:
        self._provider = provider
        self._intervals = tuple(dict.fromkeys(intervals))
        self._calendar = calendar
        self._coverage = coverage
        self._anchor = anchor
        self._lateness = lateness
        self._series: dict[_Key, _Series] = {}
        self._volumes: dict[UUID, _VolumeState] = {}
        self._deadlines: list[tuple[datetime, int, _Key, datetime]] = []
        self._order = itertools.count()
        self._dirty: set[_Key] = set()
        self._revisions: list[Candle] = []
        self._horizon: datetime | None = None
        self._no_price = CANDLE_EVENTS_SKIPPED.labels(provider=provider.value, reason="no_price")
        self._outside_session = CANDLE_EVENTS_SKIPPED.labels(
            provider=provider.value, reason="outside_session"
        )
        self._late = CANDLE_LATE_EVENTS.labels(provider=provider.value)
        self._closed = {
            interval: CANDLES_CLOSED.labels(provider=provider.value, interval=interval.value)
            for interval in self._intervals
        }

    @property
    def intervals(self) -> tuple[CandleInterval, ...]:
        return self._intervals

    @property
    def open_buckets(self) -> int:
        return sum(len(series.open) for series in self._series.values())

    def add(self, event: NormalizedMarketEvent) -> None:
        price = event.last_price
        if price is None:
            self._no_price.inc()
            return
        at = event.event_time
        frame = bucket_frame(self._calendar, event.exchange, at)
        if frame is None:
            self._outside_session.inc()
            return
        volume = self._volume_change(event, frame)
        late = False
        for interval in self._intervals:
            slot = frame.slot(at, interval, self._anchor)
            late |= not self._apply(event, interval, slot, price, volume)
        if late:
            self._late.inc()

    def close_due(self, horizon: datetime) -> list[Candle]:
        """Close every bucket whose end plus the lateness allowance is at or before ``horizon``.

        The horizon never moves back: events for buckets due before the furthest horizon seen are
        late from then on.
        """
        if self._horizon is None or horizon > self._horizon:
            self._horizon = horizon
        limit = self._horizon
        closed: list[Candle] = []
        while self._deadlines and self._deadlines[0][0] <= limit:
            _, _, key, start = heapq.heappop(self._deadlines)
            series = self._series.get(key)
            bucket = series.open.pop(start, None) if series is not None else None
            if series is None or bucket is None:
                continue  # already flushed
            candle = self._candle(key, bucket, closed=True)
            series.last_closed = candle
            closed.append(candle)
            self._closed[key[1]].inc()
        return closed

    def partials(self) -> list[Candle]:
        """The newest forming candle of every series that changed since the previous call."""
        candles: list[Candle] = []
        for key in self._dirty:
            series = self._series.get(key)
            if series is not None and series.open:
                candles.append(self._candle(key, series.open[max(series.open)], closed=False))
        self._dirty.clear()
        return candles

    def take_revisions(self) -> list[Candle]:
        """Closed candles revised since the previous call (to persist; they are not re-published)."""
        revisions, self._revisions = self._revisions, []
        return revisions

    def checkpoint(self) -> list[Candle]:
        """Every forming candle as it would be if the feed stopped now; the buckets stay open.

        Persisted periodically, it lets the next run resume the buckets after a crash.
        """
        return [
            self._candle(key, bucket, closed=False, forced=True)
            for key, series in self._series.items()
            for bucket in series.open.values()
        ]

    def flush_open(self) -> list[Candle]:
        """Every forming candle, marked as cut short by a disconnect, and forget all buckets.

        Call when the feed stops; persisting the result lets the next run resume the buckets.
        """
        candles = self.checkpoint()
        self._series.clear()
        self._volumes.clear()
        self._deadlines.clear()
        self._dirty.clear()
        return candles

    def seed(self, candles: Iterable[Candle]) -> int:
        """Resume forming candles persisted by a previous run; returns how many were resumed.

        Candles whose bucket no longer matches the calendar and anchor are ignored.
        """
        resumed = 0
        for candle in candles:
            if candle.interval not in self._intervals or candle.provider is not self._provider:
                continue
            slot = bucket_for(
                self._calendar, candle.exchange, candle.bucket_start, candle.interval, self._anchor
            )
            if slot is None or (slot.start, slot.end) != (candle.bucket_start, candle.bucket_end):
                continue
            key = (candle.instrument_id, candle.interval)
            series = self._series.setdefault(key, _Series())
            if slot.start in series.open:
                continue
            unknown = CandleFlag.VOLUME_INCOMPLETE in candle.flags
            bucket = _Bucket(
                symbol=candle.symbol,
                exchange=candle.exchange,
                segment=candle.segment,
                account_id=candle.account_id,
                start=slot.start,
                end=slot.end,
                open_price=candle.open_price,
                high_price=candle.high_price,
                low_price=candle.low_price,
                close_price=candle.close_price,
                first_event_at=candle.first_event_at,
                last_event_at=candle.last_event_at,
                status=candle.data_status,
                flags=set(candle.flags) - _DERIVED_VOLUME_FLAGS,
                event_count=candle.event_count,
                volume=candle.volume or 0,
                volume_seen=candle.volume is not None or unknown,
                volume_unknown=unknown,
                volume_at=candle.last_event_at if candle.interval is CandleInterval.D1 else None,
            )
            self._track(key, series, slot, bucket)
            resumed += 1
        return resumed

    def retain(self, instrument_ids: Iterable[UUID]) -> None:
        """Forget the state of instruments no longer streamed (their open buckets still close)."""
        active = set(instrument_ids)
        idle = [key for key, series in self._series.items() if key[0] not in active and not series.open]
        for key in idle:
            del self._series[key]
        for instrument_id in self._volumes.keys() - active:
            del self._volumes[instrument_id]

    # ---- internals ---------------------------------------------------------------------------

    def _apply(
        self,
        event: NormalizedMarketEvent,
        interval: CandleInterval,
        slot: Slot,
        price: Decimal,
        volume: _VolumeChange | None,
    ) -> bool:
        """Add the event to its bucket of ``interval``; False when the bucket already closed."""
        key = (event.instrument_id, interval)
        series = self._series.get(key)
        if series is None:
            series = self._series[key] = _Series()
        bucket = series.open.get(slot.start)
        if bucket is None:
            if self._horizon is not None and slot.end + self._lateness <= self._horizon:
                self._note_late(series, slot)
                return False
            bucket = self._open(event, key, series, slot, price)
        at = event.event_time
        if at < bucket.first_event_at:
            bucket.open_price, bucket.first_event_at = price, at
        if at >= bucket.last_event_at:
            bucket.close_price, bucket.last_event_at = price, at
        if price > bucket.high_price:
            bucket.high_price = price
        if price < bucket.low_price:
            bucket.low_price = price
        bucket.event_count += 1
        if event.data_status is not bucket.status:
            bucket.status = worst_status(bucket.status, event.data_status)
        if event.uses_receive_time:
            bucket.flags.add(CandleFlag.RECEIVE_TIME_BASIS)
        if volume is not None:
            _add_volume(bucket, interval, at, volume)
        self._dirty.add(key)
        return True

    def _open(
        self, event: NormalizedMarketEvent, key: _Key, series: _Series, slot: Slot, price: Decimal
    ) -> _Bucket:
        instrument_id = event.instrument_id
        flags: set[CandleFlag] = set()
        if slot.outside_session:
            flags.add(CandleFlag.OUTSIDE_SESSION)
        since = self._coverage.coverage_start(instrument_id, event.received_at)
        if since is None or since > slot.start:
            flags.add(CandleFlag.PARTIAL_START)
        reference = slot.session_open
        if series.last_session == slot.session_date and series.last_end is not None:
            # An earlier bucket opened after a later one falls back to the session open (conservative).
            reference = series.last_end if series.last_end <= slot.start else slot.session_open
        if (
            reference is not None
            and reference < slot.start
            and not self._coverage.covered(instrument_id, reference, slot.start)
        ):
            flags.add(CandleFlag.GAP_BEFORE)
        at = event.event_time
        bucket = _Bucket(
            symbol=event.symbol,
            exchange=event.exchange,
            segment=event.segment,
            account_id=event.account_id,
            start=slot.start,
            end=slot.end,
            open_price=price,
            high_price=price,
            low_price=price,
            close_price=price,
            first_event_at=at,
            last_event_at=at,
            status=event.data_status,
            flags=flags,
        )
        self._track(key, series, slot, bucket)
        return bucket

    def _track(self, key: _Key, series: _Series, slot: Slot, bucket: _Bucket) -> None:
        series.open[slot.start] = bucket
        if series.last_end is None or slot.start >= series.last_end:
            series.last_end, series.last_session = slot.end, slot.session_date
        heapq.heappush(self._deadlines, (slot.end + self._lateness, next(self._order), key, slot.start))
        self._dirty.add(key)

    def _note_late(self, series: _Series, slot: Slot) -> None:
        last = series.last_closed
        if last is None or last.bucket_start != slot.start or CandleFlag.LATE_EVENTS_IGNORED in last.flags:
            return
        revised = last.model_copy(
            update={
                "flags": _ordered({*last.flags, CandleFlag.LATE_EVENTS_IGNORED}),
                "revision": last.revision + 1,
            }
        )
        series.last_closed = revised
        self._revisions.append(revised)

    def _volume_change(self, event: NormalizedMarketEvent, frame: BucketFrame) -> _VolumeChange | None:
        volume = event.volume
        if volume is None or event.volume_semantics is VolumeSemantics.UNAVAILABLE:
            return None
        if event.volume_semantics is VolumeSemantics.INCREMENTAL:
            return _VolumeChange(volume, None)
        instrument_id = event.instrument_id
        at, received = event.event_time, event.received_at
        state = self._volumes.get(instrument_id)
        if state is not None and frame.session_date < state.session_date:
            return None  # a previous session's value: its buckets are long closed
        since = self._coverage.coverage_start(instrument_id, received)
        if state is not None and state.session_date == frame.session_date:
            if at < state.event_time:
                return _VolumeChange(0, volume)  # older than the value already counted
            previous, previous_received = state.cumulative, state.received_at
            state.cumulative, state.received_at, state.event_time = volume, received, at
            if since is None or since > previous_received:
                return _VolumeChange(None, volume)  # coverage broke since the previous value
            if volume < previous:
                return _VolumeChange(None, volume, reset=True)
            return _VolumeChange(volume - previous, volume)
        self._volumes[instrument_id] = _VolumeState(volume, received, at, frame.session_date)
        # The day's first value is all bucket volume only if nothing could have been missed before it.
        return _VolumeChange(volume if since is not None and since <= frame.first else None, volume)

    def _candle(self, key: _Key, bucket: _Bucket, *, closed: bool, forced: bool = False) -> Candle:
        instrument_id, interval = key
        flags = set(bucket.flags)
        status = bucket.status
        if forced or self._coverage.interrupted(instrument_id, bucket.start, bucket.end):
            flags.add(CandleFlag.DISCONNECTED_DURING)
            status = worst_status(status, DataStatus.DISCONNECTED if forced else DataStatus.RECONNECTING)
        volume: int | None = bucket.volume
        if bucket.volume_unknown:
            flags.add(CandleFlag.VOLUME_INCOMPLETE)
            volume = None
        elif not bucket.volume_seen:
            flags.add(CandleFlag.VOLUME_UNAVAILABLE)
            volume = None
        return Candle(
            provider=self._provider,
            account_id=bucket.account_id,
            instrument_id=instrument_id,
            symbol=bucket.symbol,
            exchange=bucket.exchange,
            segment=bucket.segment,
            interval=interval,
            bucket_start=bucket.start,
            bucket_end=bucket.end,
            open_price=bucket.open_price,
            high_price=bucket.high_price,
            low_price=bucket.low_price,
            close_price=bucket.close_price,
            volume=volume,
            event_count=bucket.event_count,
            is_closed=closed,
            data_status=status,
            flags=_ordered(flags),
            first_event_at=bucket.first_event_at,
            last_event_at=bucket.last_event_at,
        )


def _add_volume(bucket: _Bucket, interval: CandleInterval, at: datetime, change: _VolumeChange) -> None:
    bucket.volume_seen = True
    if change.reset:
        bucket.flags.add(CandleFlag.VOLUME_RESET)
    if interval is CandleInterval.D1 and change.cumulative is not None:
        if bucket.volume_at is None or at >= bucket.volume_at:
            bucket.volume, bucket.volume_at, bucket.volume_unknown = change.cumulative, at, False
    elif change.delta is None:
        bucket.volume_unknown = True
    else:
        bucket.volume += change.delta


def _ordered(flags: Iterable[CandleFlag]) -> tuple[CandleFlag, ...]:
    present = set(flags)
    return tuple(flag for flag in CandleFlag if flag in present)
