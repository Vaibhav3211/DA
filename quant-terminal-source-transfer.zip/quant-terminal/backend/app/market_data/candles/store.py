"""Candle persistence.

A candle row is keyed by (provider, instrument, interval, bucket start), so writing a newer version
of a candle (the closed candle after a forming one, or a revision) overwrites the stored one. Rows
whose bucket has not ended are forming candles a pipeline saved when it stopped or checkpointed;
they carry DISCONNECTED_DURING (they are what survives if the feed stops there) and let the next
run resume the buckets (``load_forming``).
"""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from datetime import datetime, timedelta
from itertools import batched
from typing import Any, Final, Protocol
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.enums import CandleFlag, CandleInterval, Exchange, Provider, Segment
from app.domain.models import Candle
from app.domain.models.candle import CANDLE_BUILDER_VERSION
from app.persistence.models import CandleRow

UPSERT_CHUNK: Final = 500
_IN_CHUNK: Final = 5000
# Bounds the bucket-start scan when loading forming candles: a daily bucket spans at most a local day.
_LONGEST_BUCKET: Final = timedelta(days=2)
_LONGEST_SESSION: Final = timedelta(days=1)
_PRIMARY_KEY: Final = (
    CandleRow.provider,
    CandleRow.instrument_id,
    CandleRow.interval,
    CandleRow.bucket_start,
)
_REPLACED: Final = tuple(
    column.name
    for column in CandleRow.__table__.columns
    if not column.primary_key and column.name not in {"created_at", "updated_at"}
)
_FLAGS: Final = {flag.value: flag for flag in CandleFlag}

type CandleKey = tuple[Provider, UUID, CandleInterval, datetime]


class Listing(Protocol):
    """What a candle states about its instrument besides the id."""

    @property
    def symbol(self) -> str: ...

    @property
    def exchange(self) -> Exchange: ...

    @property
    def segment(self) -> Segment: ...


def candle_key(candle: Candle) -> CandleKey:
    return candle.provider, candle.instrument_id, candle.interval, candle.bucket_start


def candle_values(candle: Candle) -> dict[str, Any]:
    """The column values of a candle's row."""
    return {
        "provider": candle.provider,
        "instrument_id": candle.instrument_id,
        "interval": candle.interval,
        "bucket_start": candle.bucket_start,
        "bucket_end": candle.bucket_end,
        "account_id": candle.account_id,
        "open_price": candle.open_price,
        "high_price": candle.high_price,
        "low_price": candle.low_price,
        "close_price": candle.close_price,
        "volume": candle.volume,
        "event_count": candle.event_count,
        "data_status": candle.data_status,
        "flags": [flag.value for flag in candle.flags],
        "is_complete": candle.is_complete,
        "first_event_at": candle.first_event_at,
        "last_event_at": candle.last_event_at,
        "builder_version": candle.builder_version,
    }


async def upsert_candles(session: AsyncSession, rows: Sequence[Mapping[str, Any]]) -> None:
    """Insert or overwrite rows of ``candle_values``; the last row of a key wins. The caller commits."""
    unique = {
        (row["provider"], row["instrument_id"], row["interval"], row["bucket_start"]): row for row in rows
    }
    ordered = [unique[key] for key in sorted(unique)]  # a stable lock order
    for chunk in batched(ordered, UPSERT_CHUNK):
        statement = pg_insert(CandleRow).values(list(chunk))
        await session.execute(
            statement.on_conflict_do_update(
                index_elements=list(_PRIMARY_KEY),
                set_={name: statement.excluded[name] for name in _REPLACED} | {"updated_at": func.now()},
            )
        )


async def load_forming(
    session: AsyncSession,
    provider: Provider,
    instruments: Mapping[UUID, Listing],
    intervals: Collection[CandleInterval],
    after: datetime,
) -> list[Candle]:
    """Forming candles of ``instruments`` saved by an earlier run: buckets ending after ``after``,
    built by the current builder version."""
    if not intervals:
        return []
    candles: list[Candle] = []
    for chunk in batched(sorted(instruments), _IN_CHUNK):
        rows = await session.scalars(
            select(CandleRow).where(
                CandleRow.provider == provider,
                CandleRow.instrument_id.in_(chunk),
                CandleRow.interval.in_(list(intervals)),
                CandleRow.bucket_start > after - _LONGEST_BUCKET,
                CandleRow.bucket_end > after,
                CandleRow.builder_version == CANDLE_BUILDER_VERSION,
            )
        )
        candles.extend(_candle(row, instruments[row.instrument_id], closed=False) for row in rows)
    return candles


async def load_recent(
    session: AsyncSession,
    provider: Provider,
    instrument_id: UUID,
    listing: Listing,
    interval: CandleInterval,
    *,
    until: datetime,
    limit: int,
    since: datetime | None = None,
) -> list[Candle]:
    """Closed candles of one series ending by ``until``, oldest first: the last ``limit`` of them, plus
    every earlier one starting at or after ``since`` (a session so far, for session-anchored indicators).

    A bucket whose feed stopped before it ended keeps its last saved version (flagged
    DISCONNECTED_DURING), which is the closed candle for that bucket.
    """
    series = (
        CandleRow.provider == provider,
        CandleRow.instrument_id == instrument_id,
        CandleRow.interval == interval,
        CandleRow.bucket_end <= until,
    )
    rows: list[CandleRow] = []
    if limit > 0:
        latest = await session.scalars(
            select(CandleRow).where(*series).order_by(CandleRow.bucket_start.desc()).limit(limit)
        )
        rows = list(latest)[::-1]
    if since is not None and len(rows) >= limit:  # fewer rows than the limit means there are no others
        earlier = [CandleRow.bucket_start >= max(since, until - _LONGEST_SESSION)]
        if rows:
            earlier.append(CandleRow.bucket_start < rows[0].bucket_start)
        older = await session.scalars(
            select(CandleRow).where(*series, *earlier).order_by(CandleRow.bucket_start)
        )
        rows = [*older, *rows]
    return [_candle(row, listing, closed=True) for row in rows]


async def load_range(
    session: AsyncSession,
    provider: Provider,
    instrument_id: UUID,
    listing: Listing,
    interval: CandleInterval,
    *,
    start: datetime,
    end: datetime,
    until: datetime,
    limit: int,
) -> list[Candle]:
    """Closed candles of one series starting in ``start``..``end`` (end excluded) and ending by ``until``,
    oldest first: the first ``limit`` of them. A recorded snapshot for a backtest dataset."""
    rows = await session.scalars(
        select(CandleRow)
        .where(
            CandleRow.provider == provider,
            CandleRow.instrument_id == instrument_id,
            CandleRow.interval == interval,
            CandleRow.bucket_start >= start,
            CandleRow.bucket_start < end,
            CandleRow.bucket_end <= until,
        )
        .order_by(CandleRow.bucket_start)
        .limit(limit)
    )
    return [_candle(row, listing, closed=True) for row in rows]


async def count_recent(
    session: AsyncSession,
    provider: Provider,
    instrument_id: UUID,
    interval: CandleInterval,
    *,
    until: datetime,
    limit: int,
) -> int:
    """How many of the last ``limit`` closed candles of one series ending by ``until`` are stored: what
    ``load_recent`` would load, counted."""
    if limit <= 0:
        return 0
    latest = (
        select(CandleRow.bucket_start)
        .where(
            CandleRow.provider == provider,
            CandleRow.instrument_id == instrument_id,
            CandleRow.interval == interval,
            CandleRow.bucket_end <= until,
        )
        .order_by(CandleRow.bucket_start.desc())
        .limit(limit)
        .subquery()
    )
    return await session.scalar(select(func.count()).select_from(latest)) or 0


def _candle(row: CandleRow, listing: Listing, *, closed: bool) -> Candle:
    return Candle(
        provider=row.provider,
        account_id=row.account_id,
        instrument_id=row.instrument_id,
        symbol=listing.symbol,
        exchange=listing.exchange,
        segment=listing.segment,
        interval=row.interval,
        bucket_start=row.bucket_start,
        bucket_end=row.bucket_end,
        open_price=row.open_price,
        high_price=row.high_price,
        low_price=row.low_price,
        close_price=row.close_price,
        volume=row.volume,
        event_count=row.event_count,
        is_closed=closed,
        data_status=row.data_status,
        flags=tuple(_FLAGS[name] for name in row.flags if name in _FLAGS),
        first_event_at=row.first_event_at,
        last_event_at=row.last_event_at,
        builder_version=row.builder_version,
    )
