"""What each enabled provider account streams.

The universe is the instruments of the enabled workspaces. Each workspace row names its source
provider and may pin one of the provider's accounts; unpinned rows follow the provider's enabled
account (there is at most one). There is no fallback between providers: a row is skipped, with the
reason, when its provider may not stream here, its account is not enabled, the provider does not list
the instrument or the account cannot stream it. Market data is shared per provider and instrument,
so a row is only reported as skipped when no workspace gets the instrument from that provider.

An instrument wanted by several workspaces is subscribed once, in the richest mode asked for.
Enabled accounts are planned even without instruments, so their connection and login state show.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from types import MappingProxyType
from typing import Final
from uuid import UUID

from sqlalchemy import select

from app.core.config import Settings
from app.domain.enums import Provider, SubscriptionMode
from app.domain.models import ProviderCapabilities, ProviderInstrument
from app.persistence.database import Database
from app.persistence.models import ProviderAccountRow, WorkspaceInstrumentRow, WorkspaceRow
from app.providers.base import unsupported_reason
from app.providers.registry import disabled_reason
from app.services.capabilities import CapabilityService
from app.services.instruments import InstrumentService

MODE_RANK: Final = {SubscriptionMode.LTP: 0, SubscriptionMode.QUOTE: 1, SubscriptionMode.FULL: 2}
STREAMING_OFF: Final = "streaming is turned off in its capability configuration"


class SkipReason(StrEnum):
    STREAMING_DISABLED = "streaming_disabled"  # by this deployment's settings or the capabilities
    NO_ENABLED_ACCOUNT = "no_enabled_account"
    ACCOUNT_NOT_ENABLED = "account_not_enabled"  # pinned to an account other than the enabled one
    NOT_LISTED = "not_listed"  # inactive, or not listed by the provider
    UNSUPPORTED = "unsupported"  # outside the account's exchanges, segments or modes


@dataclass(frozen=True, slots=True)
class StreamAccount:
    account_id: UUID
    provider: Provider
    label: str


@dataclass(frozen=True, slots=True)
class WantedInstrument:
    """One workspace row: stream this instrument from this provider (and account, when pinned)."""

    instrument_id: UUID
    provider: Provider
    account_id: UUID | None
    mode: SubscriptionMode


@dataclass(frozen=True, slots=True)
class Skipped:
    instrument_id: UUID
    provider: Provider
    account_id: UUID | None  # the pinned account, or the enabled account that cannot serve it
    reason: SkipReason
    detail: str


@dataclass(frozen=True, slots=True)
class AccountRequest:
    account: StreamAccount
    modes: Mapping[UUID, SubscriptionMode]  # instrument -> richest mode wanted, first wanted first


@dataclass(frozen=True, slots=True)
class Assignment:
    requests: tuple[AccountRequest, ...]  # one per enabled account, in the order given
    skipped: tuple[Skipped, ...]


@dataclass(frozen=True, slots=True)
class AccountPlan:
    account: StreamAccount
    capabilities: ProviderCapabilities
    instruments: tuple[ProviderInstrument, ...]


@dataclass(frozen=True, slots=True)
class IdleAccount:
    """An enabled account that may not stream here."""

    account: StreamAccount
    reason: str


@dataclass(frozen=True, slots=True)
class SubscriptionPlan:
    accounts: tuple[AccountPlan, ...]
    idle: tuple[IdleAccount, ...] = ()
    skipped: tuple[Skipped, ...] = ()


def assign(accounts: Iterable[StreamAccount], wanted: Iterable[WantedInstrument]) -> Assignment:
    """Group workspace rows by the enabled account that serves them."""
    by_provider: dict[Provider, StreamAccount] = {}
    for account in accounts:
        if by_provider.setdefault(account.provider, account) != account:
            raise ValueError(f"more than one enabled {account.provider.value} account")
    served: dict[UUID, dict[UUID, SubscriptionMode]] = {
        account.account_id: {} for account in by_provider.values()
    }
    skipped: dict[tuple[Provider, UUID], Skipped] = {}
    for row in wanted:
        target = by_provider.get(row.provider)
        if target is None:
            reason, detail = SkipReason.NO_ENABLED_ACCOUNT, f"{row.provider.value} has no enabled account"
        elif row.account_id is not None and row.account_id != target.account_id:
            reason, detail = (
                SkipReason.ACCOUNT_NOT_ENABLED,
                f"its workspace pins a {row.provider.value} account that is not enabled",
            )
        else:
            modes = served[target.account_id]
            current = modes.get(row.instrument_id)
            if current is None or MODE_RANK[row.mode] > MODE_RANK[current]:
                modes[row.instrument_id] = row.mode
            continue
        skip = Skipped(row.instrument_id, row.provider, row.account_id, reason, detail)
        skipped.setdefault((row.provider, row.instrument_id), skip)
    return Assignment(
        requests=tuple(
            AccountRequest(account, MappingProxyType(served[account.account_id]))
            for account in by_provider.values()
        ),
        skipped=tuple(
            skip
            for (provider, instrument_id), skip in skipped.items()
            if provider not in by_provider or instrument_id not in served[by_provider[provider].account_id]
        ),
    )


async def load_enabled_accounts(db: Database) -> list[StreamAccount]:
    a = ProviderAccountRow
    async with db.session() as session:
        result = await session.execute(
            select(a.id, a.provider, a.label).where(a.is_enabled).order_by(a.provider, a.id)
        )
        return [StreamAccount(account_id, provider, label) for account_id, provider, label in result]


async def load_wanted(db: Database) -> list[WantedInstrument]:
    """The instrument rows of the enabled workspaces, oldest first."""
    w, wi = WorkspaceRow, WorkspaceInstrumentRow
    async with db.session() as session:
        result = await session.execute(
            select(wi.instrument_id, wi.provider, wi.account_id, wi.subscription_mode)
            .join(w, w.id == wi.workspace_id)
            .where(w.is_enabled)
            .order_by(wi.added_at, wi.instrument_id, wi.workspace_id)
        )
        return [
            WantedInstrument(instrument_id, provider, account_id, mode)
            for instrument_id, provider, account_id, mode in result
        ]


class SubscriptionPlanner:
    """Plans the subscriptions of every enabled account from the database."""

    def __init__(
        self, settings: Settings, instruments: InstrumentService, capabilities: CapabilityService
    ) -> None:
        self._settings = settings
        self._instruments = instruments
        self._capabilities = capabilities

    async def plan(self) -> SubscriptionPlan:
        db = self._instruments.db
        assignment = assign(await load_enabled_accounts(db), await load_wanted(db))
        accounts: list[AccountPlan] = []
        idle: list[IdleAccount] = []
        skipped = list(assignment.skipped)
        for request in assignment.requests:
            account = request.account
            capabilities = await self._capabilities.effective(account.provider, account.account_id)
            reason = disabled_reason(account.provider, self._settings)
            if reason is None and not capabilities.streaming:
                reason = STREAMING_OFF
            if reason is not None:
                idle.append(IdleAccount(account, reason))
                skipped.extend(
                    _skip(instrument_id, account, SkipReason.STREAMING_DISABLED, reason)
                    for instrument_id in request.modes
                )
                continue
            instruments, rejected = await self._resolve(request, capabilities)
            accounts.append(AccountPlan(account, capabilities, instruments))
            skipped.extend(rejected)
        return SubscriptionPlan(tuple(accounts), tuple(idle), tuple(skipped))

    async def _resolve(
        self, request: AccountRequest, capabilities: ProviderCapabilities
    ) -> tuple[tuple[ProviderInstrument, ...], list[Skipped]]:
        if not request.modes:
            return (), []
        account = request.account
        resolved = await self._instruments.resolve(list(request.modes), account.provider)
        skipped = [
            _skip(instrument_id, account, SkipReason.NOT_LISTED, f"not listed by {account.provider.value}")
            for instrument_id in resolved.missing
        ]
        instruments: list[ProviderInstrument] = []
        for found in resolved.found:
            instrument = found.model_copy(update={"mode": request.modes[found.instrument_id]})
            reason = unsupported_reason(capabilities, instrument)
            if reason is None:
                instruments.append(instrument)
            else:
                skipped.append(_skip(found.instrument_id, account, SkipReason.UNSUPPORTED, reason))
        return tuple(instruments), skipped


def _skip(instrument_id: UUID, account: StreamAccount, reason: SkipReason, detail: str) -> Skipped:
    return Skipped(instrument_id, account.provider, account.account_id, reason, detail)
