"""Apply one provider's instrument dump to the canonical instrument master.

Runs inside the caller's transaction:

1. Serialise. A second refresh of the same provider fails fast (``instrument_refresh_running``);
   refreshes of different providers queue behind each other because they update shared instruments.
2. Match every entry to the provider's active mappings by provider token:
   * same token, same canonical key: refresh the mapping's attributes in place;
   * same token, different key (Kite reuses the tokens of expired contracts; symbols get renamed):
     close the mapping and open a new version. A cash instrument whose symbol changed is renamed
     in place when nothing else refers to it, so its history stays attached;
   * new token: link it to the instrument with the same key, creating it when needed.
3. Close active mappings whose tokens are missing, but only within the (exchange, segment) scopes
   the dump covers, so a partial (e.g. single-exchange) dump never touches other scopes. Tokens the
   dump lists in rows it could not use are held: their mappings stay as they are. A dump that
   would close more than half of a sizeable scope is refused unless forced: a truncated download
   is far likelier than a mass delisting.
4. Recompute ``is_active``: an instrument is active while it has an active mapping and has not
   expired.

Attribute ownership keeps two providers from flipping values back and forth: names and underlyings
are only filled in when missing (a renamed instrument takes the new ones); Zerodha (and the
simulator) own lot sizes, tick sizes and ISINs, which other providers only fill in when missing.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Collection, Iterable, Sequence
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from itertools import batched
from typing import Any, Final, cast
from uuid import UUID, uuid4

from pydantic_core import to_jsonable_python
from sqlalchemy import CursorResult, Update, func, insert, select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import InstrumentedAttribute

from app.core.errors import ConflictError
from app.domain.enums import Exchange, InstrumentType, Provider, Segment
from app.domain.models import ProviderInstrumentRecord
from app.domain.models.base import DomainModel
from app.market_data.instruments.canonical import DERIVATIVES, CanonicalInstrument, Entry, PreparedDump
from app.persistence.models import InstrumentProviderMappingRow, InstrumentRow

LOCK_NAME: Final = "instrument_refresh"
GUARD_SHARE: Final = 0.5
GUARD_MIN_ACTIVE: Final = 10
_IN_CHUNK: Final = 5000
_INSERT_CHUNK: Final = 1000
_OWNED: Final = ("lot_size", "tick_size", "isin")
_DESCRIPTIVE: Final = ("name", "underlying")
_OWNERS: Final = frozenset({Provider.ZERODHA, Provider.SIMULATOR})
_NO_SYNC: Final = {"synchronize_session": False}

type Scope = tuple[Exchange, Segment]


class SyncStats(DomainModel):
    instruments_created: int = 0
    instruments_updated: int = 0
    instruments_renamed: int = 0
    instruments_activated: int = 0
    instruments_deactivated: int = 0
    mappings_created: int = 0
    mappings_updated: int = 0
    mappings_unchanged: int = 0
    mappings_moved: int = 0
    mappings_closed: int = 0
    mappings_held: int = 0


@dataclass(frozen=True, slots=True)
class _Mapped:
    """An active mapping with the identity of its instrument."""

    id: UUID
    instrument_id: UUID
    values: dict[str, Any]
    key: str
    scope: Scope
    instrument_type: InstrumentType


@dataclass(frozen=True, slots=True)
class _Stored:
    """The attributes of an existing instrument a refresh may change."""

    id: UUID
    key: str
    symbol: str
    name: str | None
    underlying: str | None
    lot_size: int | None
    tick_size: Decimal | None
    isin: str | None


async def apply_dump(
    session: AsyncSession, dump: PreparedDump, *, now: datetime, today: date, force: bool = False
) -> SyncStats:
    """``today`` is the exchange (IST) date that decides which contracts have expired."""
    provider = dump.provider
    await _lock(session, provider)
    active = await _active_mappings(session, provider)
    by_token = {entry.record.provider_token: entry for entry in dump.entries}
    dump_keys = {entry.instrument.key for entry in dump.entries}
    scopes = {_scope(entry.instrument) for entry in dump.entries}
    unseen = [
        m
        for token, m in active.items()
        if token not in by_token and token not in dump.held and m.scope in scopes
    ]
    if not force:
        _check_complete(provider, active.values(), unseen, scopes)
    kept: list[tuple[Entry, _Mapped]] = []
    moved: list[tuple[Entry, _Mapped]] = []
    fresh: list[Entry] = []
    for token, entry in by_token.items():
        mapped = active.get(token)
        if mapped is None:
            fresh.append(entry)
        elif mapped.key == entry.instrument.key:
            kept.append((entry, mapped))
        else:
            moved.append((entry, mapped))
    stored = {item.key: item for item in await _instruments(session, InstrumentRow.canonical_key, dump_keys)}
    renames = await _renames(session, moved, stored, dump_keys)
    targets = {**stored, **renames}

    await _close(session, [m.id for m in unseen] + [m.id for _, m in moved], now)
    created, created_count = await _create(
        session, [e.instrument for e in dump.entries if e.instrument.key not in targets], now=now, today=today
    )
    updates: list[dict[str, Any]] = []
    touched: list[UUID] = []
    for entry in dump.entries:
        target = targets.get(entry.instrument.key)
        if target is None:
            continue  # created above with the dump's values
        changes = _changes(target, entry.instrument, provider, renamed=entry.instrument.key in renames)
        if changes:
            updates.append({"id": target.id, **changes, "last_seen_at": now, "updated_at": now})
        else:
            touched.append(target.id)
    await _update_by_pk(session, InstrumentRow, updates)
    await _touch(session, InstrumentRow, touched, now)

    mapping_updates: list[dict[str, Any]] = []
    mapping_touched: list[UUID] = []
    for entry, mapped in kept:
        values = _mapping_values(entry.record)
        changed = {name: value for name, value in values.items() if mapped.values.get(name) != value}
        if changed:
            mapping_updates.append({"id": mapped.id, **changed, "last_seen_at": now, "updated_at": now})
        else:
            mapping_touched.append(mapped.id)
    await _update_by_pk(session, InstrumentProviderMappingRow, mapping_updates)
    await _touch(session, InstrumentProviderMappingRow, mapping_touched, now)
    instrument_ids = {key: target.id for key, target in targets.items()} | created
    linked = [*fresh, *(entry for entry, _ in moved)]
    if linked:
        await session.execute(
            insert(InstrumentProviderMappingRow),
            [_new_mapping(entry, instrument_ids[entry.instrument.key], now) for entry in linked],
        )

    affected = set(instrument_ids.values()) | {m.instrument_id for m in unseen}
    affected |= {m.instrument_id for _, m in moved}
    activated, deactivated = await _recompute(session, affected, now=now, today=today)
    renamed = sum(1 for update_ in updates if "canonical_key" in update_)
    return SyncStats(
        instruments_created=created_count,
        instruments_updated=len(updates) - renamed,
        instruments_renamed=renamed,
        instruments_activated=activated,
        instruments_deactivated=deactivated,
        mappings_created=len(fresh),
        mappings_updated=len(mapping_updates),
        mappings_unchanged=len(mapping_touched),
        mappings_moved=len(moved),
        mappings_closed=len(unseen),
        mappings_held=sum(1 for token in active if token in dump.held),
    )


async def _lock(session: AsyncSession, provider: Provider) -> None:
    acquired = await session.scalar(
        select(func.pg_try_advisory_xact_lock(func.hashtext(f"{LOCK_NAME}:{provider.value}")))
    )
    if not acquired:
        raise ConflictError(
            f"An instrument refresh for {provider.value.title()} is already running",
            code="instrument_refresh_running",
        )
    await session.execute(select(func.pg_advisory_xact_lock(func.hashtext(LOCK_NAME))))


def _scope(instrument: CanonicalInstrument) -> Scope:
    return (instrument.exchange, instrument.segment)


def _check_complete(
    provider: Provider, active: Iterable[_Mapped], unseen: Sequence[_Mapped], scopes: Collection[Scope]
) -> None:
    totals = Counter(m.scope for m in active if m.scope in scopes)
    missing = Counter(m.scope for m in unseen)
    suspect = sorted(
        scope
        for scope, count in missing.items()
        if totals[scope] >= GUARD_MIN_ACTIVE and count > totals[scope] * GUARD_SHARE
    )
    if not suspect:
        return
    described = ", ".join(f"{e.value} {s.value} ({missing[(e, s)]} of {totals[(e, s)]})" for e, s in suspect)
    raise ConflictError(
        f"The {provider.value.title()} instrument dump lacks most active instruments of {described}, so it "
        "looks incomplete. Check the source, or force the refresh to close them",
        code="instrument_dump_incomplete",
        details={
            "scopes": [
                {
                    "exchange": e.value,
                    "segment": s.value,
                    "missing": missing[(e, s)],
                    "active": totals[(e, s)],
                }
                for e, s in suspect
            ]
        },
    )


async def _active_mappings(session: AsyncSession, provider: Provider) -> dict[str, _Mapped]:
    m, i = InstrumentProviderMappingRow, InstrumentRow
    result = await session.execute(
        select(
            m.id,
            m.instrument_id,
            m.provider_token,
            m.exchange_token,
            m.provider_symbol,
            m.provider_exchange,
            m.provider_segment,
            m.provider_metadata,
            i.canonical_key,
            i.exchange,
            i.segment,
            i.instrument_type,
        )
        .join(i, i.id == m.instrument_id)
        .where(m.provider == provider, m.is_active)
    )
    return {
        row.provider_token: _Mapped(
            id=row.id,
            instrument_id=row.instrument_id,
            values={
                "exchange_token": row.exchange_token,
                "provider_symbol": row.provider_symbol,
                "provider_exchange": row.provider_exchange,
                "provider_segment": row.provider_segment,
                "provider_metadata": row.provider_metadata,
            },
            key=row.canonical_key,
            scope=(row.exchange, row.segment),
            instrument_type=row.instrument_type,
        )
        for row in result
    }


async def _instruments(
    session: AsyncSession, column: InstrumentedAttribute[Any], values: Collection[Any]
) -> list[_Stored]:
    i = InstrumentRow
    found: list[_Stored] = []
    for chunk in batched(sorted(values), _IN_CHUNK):
        result = await session.execute(
            select(
                i.id, i.canonical_key, i.symbol, i.name, i.underlying, i.lot_size, i.tick_size, i.isin
            ).where(column.in_(chunk))
        )
        found.extend(_Stored(*row) for row in result)
    return found


async def _renames(
    session: AsyncSession,
    moved: Sequence[tuple[Entry, _Mapped]],
    stored: Collection[str],
    dump_keys: Collection[str],
) -> dict[str, _Stored]:
    """New key → existing instrument to rename. Only a cash-like instrument whose old key left the
    dump, whose new key is unused, and which nothing but the moving mapping refers to qualifies."""
    candidates = {
        entry.instrument.key: mapped
        for entry, mapped in moved
        if not entry.instrument.is_derivative
        and mapped.instrument_type not in DERIVATIVES
        and (mapped.scope, mapped.instrument_type)
        == (_scope(entry.instrument), entry.instrument.instrument_type)
        and entry.instrument.key not in stored
        and mapped.key not in dump_keys
    }
    if not candidates:
        return {}
    links = await _link_counts(session, {mapped.instrument_id for mapped in candidates.values()})
    sole = [mapped.instrument_id for mapped in candidates.values() if links.get(mapped.instrument_id) == 1]
    by_id = {item.id: item for item in await _instruments(session, InstrumentRow.id, sole)}
    return {key: by_id[m.instrument_id] for key, m in candidates.items() if m.instrument_id in by_id}


async def _link_counts(session: AsyncSession, instrument_ids: Collection[UUID]) -> dict[UUID, int]:
    m = InstrumentProviderMappingRow
    counts: dict[UUID, int] = {}
    for chunk in batched(sorted(instrument_ids), _IN_CHUNK):
        result = await session.execute(
            select(m.instrument_id, func.count())
            .where(m.is_active, m.instrument_id.in_(chunk))
            .group_by(m.instrument_id)
        )
        # a Result has .keys(), so dict()/dict.update() would mistake it for a mapping
        for instrument_id, count in result:
            counts[instrument_id] = count
    return counts


def _changes(
    target: _Stored, new: CanonicalInstrument, provider: Provider, *, renamed: bool
) -> dict[str, Any]:
    changes: dict[str, Any] = {"canonical_key": new.key} if renamed else {}
    if target.symbol != new.symbol:
        changes["symbol"] = new.symbol
    # Providers describe instruments differently, so only a rename replaces these (the renamed
    # instrument has no other provider to disagree); otherwise they are only filled in.
    for field in _DESCRIPTIVE:
        value, current = getattr(new, field), getattr(target, field)
        if value is not None and value != current and (renamed or current is None):
            changes[field] = value
    owner = provider in _OWNERS
    for field in _OWNED:
        value, current = getattr(new, field), getattr(target, field)
        if value is not None and value != current and (owner or current is None):
            changes[field] = value
    return changes


def _mapping_values(record: ProviderInstrumentRecord) -> dict[str, Any]:
    return {
        "exchange_token": record.exchange_token,
        "provider_symbol": record.provider_symbol,
        "provider_exchange": record.provider_exchange,
        "provider_segment": record.provider_segment,
        # Compared with the stored JSONB, so normalised the way it is stored.
        "provider_metadata": to_jsonable_python({**record.metadata, "tradable": record.tradable}),
    }


def _new_mapping(entry: Entry, instrument_id: UUID, now: datetime) -> dict[str, Any]:
    return {
        "id": uuid4(),
        "instrument_id": instrument_id,
        "provider": entry.record.provider,
        "provider_token": entry.record.provider_token,
        **_mapping_values(entry.record),
        "is_active": True,
        "valid_from": now,
        "valid_to": None,
        "last_seen_at": now,
        "created_at": now,
        "updated_at": now,
    }


def _new_instrument(item: CanonicalInstrument, *, now: datetime, today: date) -> dict[str, Any]:
    return {
        "id": uuid4(),
        "canonical_key": item.key,
        "exchange": item.exchange,
        "segment": item.segment,
        "instrument_type": item.instrument_type,
        "symbol": item.symbol,
        "name": item.name,
        "underlying": item.underlying,
        "expiry": item.expiry,
        "strike": item.strike,
        "option_type": item.option_type,
        "lot_size": item.lot_size,
        "tick_size": item.tick_size,
        "currency": "INR",
        "isin": item.isin,
        "is_active": item.expiry is None or item.expiry >= today,
        "last_seen_at": now,
        "created_at": now,
        "updated_at": now,
    }


async def _create(
    session: AsyncSession, instruments: Sequence[CanonicalInstrument], *, now: datetime, today: date
) -> tuple[dict[str, UUID], int]:
    """Key → id of each instrument, and how many were inserted (keys sorted: a stable lock order)."""
    ids: dict[str, UUID] = {}
    ordered = sorted(instruments, key=lambda item: item.key)
    for chunk in batched(ordered, _INSERT_CHUNK):
        statement = (
            pg_insert(InstrumentRow)
            .values([_new_instrument(item, now=now, today=today) for item in chunk])
            .on_conflict_do_nothing(index_elements=[InstrumentRow.canonical_key])
            .returning(InstrumentRow.canonical_key, InstrumentRow.id)
        )
        for key, instrument_id in await session.execute(statement):
            ids[key] = instrument_id
    inserted = len(ids)
    conflicted = [item.key for item in ordered if item.key not in ids]
    if conflicted:  # inserted meanwhile by another writer: link to those rows instead
        ids.update(
            {
                item.key: item.id
                for item in await _instruments(session, InstrumentRow.canonical_key, conflicted)
            }
        )
    return ids, inserted


async def _close(session: AsyncSession, mapping_ids: Collection[UUID], now: datetime) -> None:
    m = InstrumentProviderMappingRow
    for chunk in batched(sorted(mapping_ids), _IN_CHUNK):
        await session.execute(
            update(m).where(m.id.in_(chunk)).values(is_active=False, valid_to=now, updated_at=now),
            execution_options=_NO_SYNC,
        )


async def _update_by_pk(
    session: AsyncSession,
    model: type[InstrumentRow] | type[InstrumentProviderMappingRow],
    rows: Sequence[dict[str, Any]],
) -> None:
    if rows:
        await session.execute(update(model), sorted(rows, key=lambda row: row["id"]))


async def _touch(
    session: AsyncSession,
    model: type[InstrumentRow] | type[InstrumentProviderMappingRow],
    ids: Collection[UUID],
    now: datetime,
) -> None:
    """Record that rows were seen without counting it as a change (``updated_at`` is kept)."""
    for chunk in batched(sorted(ids), _IN_CHUNK):
        await session.execute(
            update(model).where(model.id.in_(chunk)).values(last_seen_at=now, updated_at=model.updated_at),
            execution_options=_NO_SYNC,
        )


async def _recompute(
    session: AsyncSession, instrument_ids: Collection[UUID], *, now: datetime, today: date
) -> tuple[int, int]:
    """(activated, deactivated): the affected instruments, plus every instrument that has expired."""
    i, m = InstrumentRow, InstrumentProviderMappingRow
    linked = select(m.id).where(m.instrument_id == i.id, m.is_active).exists()
    live = linked & (i.expiry.is_(None) | (i.expiry >= today))
    activated = deactivated = 0
    for chunk in batched(sorted(instrument_ids), _IN_CHUNK):
        scope = i.id.in_(chunk)
        deactivated += await _rowcount(
            session, update(i).where(scope, i.is_active, ~live).values(is_active=False, updated_at=now)
        )
        activated += await _rowcount(
            session, update(i).where(scope, ~i.is_active, live).values(is_active=True, updated_at=now)
        )
    deactivated += await _rowcount(
        session, update(i).where(i.is_active, i.expiry < today).values(is_active=False, updated_at=now)
    )
    return activated, deactivated


async def _rowcount(session: AsyncSession, statement: Update) -> int:
    result = await session.execute(statement, execution_options=_NO_SYNC)
    return cast(CursorResult[Any], result).rowcount
