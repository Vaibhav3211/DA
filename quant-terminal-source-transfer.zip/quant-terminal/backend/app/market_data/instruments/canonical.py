"""Canonical instrument identity: keys, display symbols and dump validation.

A canonical key identifies one instrument independently of any provider:

* non-derivatives: ``EXCHANGE:SEGMENT:TYPE:SYMBOL``, e.g. ``NSE:CASH:EQUITY:INFY``;
* futures: ``EXCHANGE:SEGMENT:FUTURE:UNDERLYING:YYYY-MM-DD``;
* options: ``EXCHANGE:SEGMENT:OPTION:UNDERLYING:YYYY-MM-DD:STRIKE:CE|PE``.

Symbols and underlyings are whitespace-collapsed and upper-cased. Providers are linked to the same
instrument only when their keys match exactly, so instruments the providers spell differently
(Kite's "NIFTY 50" index and Groww's "NIFTY") stay separate instead of being merged by guesswork.

``prepare`` also rejects records that would not fit the database columns, so one odd row is skipped
and counted rather than failing a whole refresh.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Final

from app.domain.enums import Exchange, InstrumentType, OptionType, Provider, Segment
from app.domain.models import ProviderInstrumentRecord
from app.providers.errors import ProviderProtocolError
from app.providers.instrument_dump import InstrumentDump

# Column sizes of ``instruments`` and ``instrument_provider_mappings`` (a unit test keeps them equal).
KEY_MAX_LENGTH: Final = 160
SYMBOL_MAX_LENGTH: Final = 80  # the instrument's symbol and underlying
FIELD_MAX_LENGTHS: Final = {
    "provider_token": 80,
    "exchange_token": 40,
    "provider_symbol": 120,
    "provider_exchange": 16,
    "provider_segment": 24,
    "name": 200,
    "isin": 12,
}
_DECIMAL_STEP: Final = Decimal("1e-8")  # NUMERIC(24, 8)
_DECIMAL_LIMIT: Final = Decimal(10) ** 16
_INT_MAX: Final = 2**31 - 1
DERIVATIVES: Final = frozenset({InstrumentType.FUTURE, InstrumentType.OPTION})
_MONTHS: Final = ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")


class RecordRejected(ValueError):
    """A record that cannot be stored; ``reason`` is counted in the refresh report."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True, slots=True)
class CanonicalInstrument:
    key: str
    exchange: Exchange
    segment: Segment
    instrument_type: InstrumentType
    symbol: str
    name: str | None
    underlying: str | None
    expiry: date | None
    strike: Decimal | None
    option_type: OptionType | None
    lot_size: int | None
    tick_size: Decimal | None
    isin: str | None

    @property
    def is_derivative(self) -> bool:
        return self.instrument_type in DERIVATIVES


@dataclass(frozen=True, slots=True)
class Entry:
    record: ProviderInstrumentRecord
    instrument: CanonicalInstrument


@dataclass(slots=True)
class PreparedDump:
    provider: Provider
    entries: tuple[Entry, ...]
    skipped: Counter[str]
    rows: int
    # Tokens of skipped records: the provider still lists them, so their mappings are left alone.
    held: frozenset[str]


def normalize_symbol(value: str) -> str:
    return " ".join(value.split()).upper()


def format_strike(strike: Decimal) -> str:
    """``24000`` rather than ``2.4E+4`` or ``24000.00``."""
    return format(strike.normalize(), "f")


def contract_date(day: date) -> str:
    """``27JAN26``. A fixed month table keeps symbols independent of the process locale."""
    return f"{day.day:02d}{_MONTHS[day.month - 1]}{day.year % 100:02d}"


def canonicalize(record: ProviderInstrumentRecord) -> CanonicalInstrument:
    """The canonical form of one record. Raises ``RecordRejected`` when it cannot be stored."""
    head = f"{record.exchange.value}:{record.segment.value}:{record.instrument_type.value}"
    underlying = normalize_symbol(record.underlying or "") or None
    expiry: date | None = None
    strike: Decimal | None = None
    option_type: OptionType | None = None
    if record.instrument_type in DERIVATIVES:
        if underlying is None or record.expiry is None:
            raise RecordRejected("invalid_row")
        expiry = record.expiry
        key = f"{head}:{underlying}:{expiry.isoformat()}"
        symbol = f"{underlying} {contract_date(expiry)}"
        if record.instrument_type is InstrumentType.OPTION:
            if record.strike is None or record.strike <= 0 or record.option_type is None:
                raise RecordRejected("invalid_row")
            strike, option_type = record.strike, record.option_type
            key += f":{format_strike(strike)}:{option_type.value}"
            symbol += f" {format_strike(strike)} {option_type.value}"
        else:
            symbol += " FUT"
    else:
        symbol = normalize_symbol(record.provider_symbol)
        if not symbol:
            raise RecordRejected("invalid_row")
        key = f"{head}:{symbol}"
    if len(key) > KEY_MAX_LENGTH:
        raise RecordRejected("key_too_long")
    if _too_long(record, symbol, underlying):
        raise RecordRejected("field_too_long")
    if not _in_range(record, strike):
        raise RecordRejected("value_out_of_range")
    return CanonicalInstrument(
        key=key,
        exchange=record.exchange,
        segment=record.segment,
        instrument_type=record.instrument_type,
        symbol=symbol,
        name=record.name,
        underlying=underlying,
        expiry=expiry,
        strike=strike,
        option_type=option_type,
        lot_size=record.lot_size,
        tick_size=record.tick_size,
        isin=record.isin,
    )


def prepare(dump: InstrumentDump) -> PreparedDump:
    """Canonical entries of one dump. Records sharing a provider token or a canonical key are all
    skipped (``duplicate_token``/``ambiguous``): nothing says which of them is right."""
    skipped = Counter(dump.skipped)
    accepted: list[Entry] = []
    held: set[str] = set()
    for record in dump.records:
        if record.provider is not dump.provider:
            raise ValueError(f"a {record.provider.value} record in a {dump.provider.value} dump")
        try:
            accepted.append(Entry(record, canonicalize(record)))
        except RecordRejected as rejected:
            skipped[rejected.reason] += 1
            held.add(record.provider_token)
    tokens = Counter(entry.record.provider_token for entry in accepted)
    unique = [entry for entry in accepted if tokens[entry.record.provider_token] == 1]
    keys = Counter(entry.instrument.key for entry in unique)
    entries = tuple(entry for entry in unique if keys[entry.instrument.key] == 1)
    for reason, count in (
        ("duplicate_token", len(accepted) - len(unique)),
        ("ambiguous", len(unique) - len(entries)),
    ):
        if count:
            skipped[reason] += count
    if not entries:
        raise ProviderProtocolError(
            f"the {dump.provider.value.title()} instrument dump has no usable instruments ({dump.rows} rows)"
        )
    held.update(entry.record.provider_token for entry in accepted)
    held.difference_update(entry.record.provider_token for entry in entries)
    return PreparedDump(dump.provider, entries, skipped, dump.rows, frozenset(held))


def _too_long(record: ProviderInstrumentRecord, symbol: str, underlying: str | None) -> bool:
    if len(symbol) > SYMBOL_MAX_LENGTH or len(underlying or "") > SYMBOL_MAX_LENGTH:
        return True
    return any(len(getattr(record, field) or "") > limit for field, limit in FIELD_MAX_LENGTHS.items())


def _in_range(record: ProviderInstrumentRecord, strike: Decimal | None) -> bool:
    if record.lot_size is not None and not 0 < record.lot_size <= _INT_MAX:
        return False
    if record.tick_size is not None and record.tick_size <= 0:
        return False
    return all(_fits_numeric(value) for value in (strike, record.tick_size) if value is not None)


def _fits_numeric(value: Decimal) -> bool:
    """Fits NUMERIC(24, 8) exactly (PostgreSQL would silently round a ninth decimal place)."""
    return abs(value) < _DECIMAL_LIMIT and value == value.quantize(_DECIMAL_STEP)
