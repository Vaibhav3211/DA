"""Local copies of downloaded instrument dumps, for diagnosis and offline re-imports (``--file``).

Each download is written atomically to ``<cache dir>/<provider>/<UTC timestamp>.csv`` and only the
newest few are kept. Pruning only deletes files named by this module, so a mistyped cache directory
never costs the operator unrelated files.
"""

from __future__ import annotations

import os
import re
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Final

from app.domain.enums import Provider

KEEP: Final = 3
_STAMP: Final = "%Y%m%dT%H%M%S%fZ"
_NAME: Final = re.compile(r"\d{8}T\d{12}Z\.csv")


def cache_dump(directory: Path, provider: Provider, data: bytes, *, at: datetime, keep: int = KEEP) -> Path:
    """Store ``data`` and prune older copies; returns the new file. Raises ``OSError``."""
    if keep < 1:
        raise ValueError("keep at least the new copy")
    folder = directory / provider.value.lower()
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{at.astimezone(UTC).strftime(_STAMP)}.csv"
    descriptor, temporary = tempfile.mkstemp(dir=folder, prefix=".download-", suffix=".tmp")
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise
    _prune(folder, keep=keep - 1, spare=target)
    return target


def _prune(folder: Path, *, keep: int, spare: Path) -> None:
    """Delete all but the ``keep`` newest copies other than ``spare`` (kept even if the clock went
    back)."""
    copies = sorted(
        path for path in folder.iterdir() if path != spare and _NAME.fullmatch(path.name) and path.is_file()
    )
    for path in copies[: max(len(copies) - keep, 0)]:
        path.unlink(missing_ok=True)
