"""Builds the :class:`MarketCalendar` from the exchange table, the overrides table and the library."""

from __future__ import annotations

import asyncio
from collections.abc import Iterable
from datetime import UTC
from zoneinfo import ZoneInfo

import sqlalchemy as sa

from app.core.logging import get_logger
from app.market_data.calendars.service import (
    CalendarOverride,
    ExchangeSpec,
    LibrarySchedule,
    MarketCalendar,
)
from app.persistence.database import Database
from app.persistence.models.instruments import ExchangeRow
from app.persistence.models.market_data import MarketCalendarOverrideRow

log = get_logger(__name__)


def load_library_schedules(codes: Iterable[str]) -> dict[str, LibrarySchedule]:
    """Blocking (the library import alone takes seconds): call it from a worker thread.

    A calendar that fails to load is logged and left out, so its exchanges report UNKNOWN.
    """
    import exchange_calendars  # slow import, only needed here

    schedules: dict[str, LibrarySchedule] = {}
    for code in sorted(set(codes)):
        try:
            calendar = exchange_calendars.get_calendar(code)
            frame = calendar.schedule
            sessions = {
                label.date(): (opened.to_pydatetime().astimezone(UTC), closed.to_pydatetime().astimezone(UTC))
                for label, opened, closed in zip(frame.index, frame["open"], frame["close"], strict=True)
            }
            schedules[code] = LibrarySchedule(
                sessions=sessions,
                first_session=calendar.first_session.date(),
                last_session=calendar.last_session.date(),
                weekmask=str(calendar.weekmask),
                regular_open=calendar.open_times[-1][1],
                regular_close=calendar.close_times[-1][1],
            )
        except Exception as exc:  # an unknown/broken calendar degrades to UNKNOWN, loudly
            log.error("calendar_load_failed", calendar=code, error=f"{type(exc).__name__}: {exc}")
    return schedules


async def load_exchange_specs(database: Database) -> list[ExchangeSpec]:
    async with database.session() as session:
        rows = (await session.scalars(sa.select(ExchangeRow))).all()
    return [ExchangeSpec(row.code, ZoneInfo(row.timezone), row.calendar_code) for row in rows]


async def load_overrides(database: Database) -> list[CalendarOverride]:
    async with database.session() as session:
        rows = (await session.scalars(sa.select(MarketCalendarOverrideRow))).all()
    return [
        CalendarOverride(row.exchange, row.session_date, row.kind, row.open_time, row.close_time)
        for row in rows
    ]


async def load_market_calendar(database: Database, *, extend_beyond_coverage: bool = True) -> MarketCalendar:
    specs = await load_exchange_specs(database)
    overrides = await load_overrides(database)
    codes = [spec.calendar_code for spec in specs if spec.calendar_code is not None]
    schedules = await asyncio.to_thread(load_library_schedules, codes) if codes else {}
    calendar = MarketCalendar(specs, schedules, overrides, extend_beyond_coverage=extend_beyond_coverage)
    log.info(
        "calendar_loaded",
        exchanges=sorted(spec.exchange.value for spec in specs),
        overrides=len(overrides),
        coverage={exchange.value: day.isoformat() for exchange, day in calendar.coverage().items()},
    )
    return calendar
