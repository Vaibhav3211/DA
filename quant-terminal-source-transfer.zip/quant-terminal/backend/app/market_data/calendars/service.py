"""Exchange trading calendars.

Session hours come from ``exchange_calendars`` (NSE and BSE share its ``XBOM`` calendar) and are
corrected by manual overrides (holidays, special sessions such as Muhurat trading). Every answer
says whether it is verified: past the library's published holiday list the regular weekday hours
are assumed (``verified=False``, optional) so the platform keeps working while health reports the
coverage gap. Exchanges without a calendar (MCX) are UNKNOWN. The synthetic SIM venue trades
around the clock in UTC days.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import UTC, date, datetime, time, timedelta
from enum import StrEnum
from zoneinfo import ZoneInfo

from app.domain.enums import CalendarOverrideKind, Exchange, MarketSessionState

PRE_OPEN_WINDOW = timedelta(minutes=15)
POST_CLOSE_WINDOW = timedelta(minutes=30)
_UTC_ZONE = ZoneInfo("UTC")
_DAY_CACHE_LIMIT = 4096


class DayKind(StrEnum):
    SESSION = "SESSION"
    HOLIDAY = "HOLIDAY"
    WEEKEND = "WEEKEND"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True, slots=True)
class TradingDay:
    exchange: Exchange
    session_date: date
    kind: DayKind
    open_at: datetime | None = None  # UTC
    close_at: datetime | None = None  # UTC
    # Set by a manual override (holiday or special session).
    special: bool = False
    # False when the answer is an assumption (no published calendar covers this date).
    verified: bool = True

    def contains(self, at: datetime) -> bool:
        return self.open_at is not None and self.close_at is not None and self.open_at <= at < self.close_at


@dataclass(frozen=True, slots=True)
class LibrarySchedule:
    """Published sessions of one ``exchange_calendars`` calendar (UTC open/close per session date)."""

    sessions: Mapping[date, tuple[datetime, datetime]]
    first_session: date
    last_session: date
    weekmask: str  # Monday first; "1" marks a normal trading weekday
    regular_open: time
    regular_close: time


@dataclass(frozen=True, slots=True)
class ExchangeSpec:
    exchange: Exchange
    timezone: ZoneInfo
    calendar_code: str | None = None


@dataclass(frozen=True, slots=True)
class CalendarOverride:
    """Manual correction; times are exchange-local and default to the regular session hours."""

    exchange: Exchange
    session_date: date
    kind: CalendarOverrideKind
    open_time: time | None = None
    close_time: time | None = None


@dataclass(frozen=True, slots=True)
class SessionStatus:
    state: MarketSessionState
    day: TradingDay


class MarketCalendar:
    """Answers "is this exchange trading at time t" cheaply (results are cached per exchange day)."""

    def __init__(
        self,
        exchanges: Iterable[ExchangeSpec],
        schedules: Mapping[str, LibrarySchedule],
        overrides: Iterable[CalendarOverride] = (),
        *,
        extend_beyond_coverage: bool = True,
    ) -> None:
        self._specs = {spec.exchange: spec for spec in exchanges}
        self._schedules = dict(schedules)
        self._extend = extend_beyond_coverage
        self._overrides: dict[tuple[Exchange, date], CalendarOverride] = {}
        self._days: dict[tuple[Exchange, date], TradingDay] = {}
        self.set_overrides(overrides)

    @property
    def overrides(self) -> frozenset[CalendarOverride]:
        return frozenset(self._overrides.values())

    def set_overrides(self, overrides: Iterable[CalendarOverride]) -> None:
        self._overrides = {(item.exchange, item.session_date): item for item in overrides}
        self._days.clear()

    def timezone(self, exchange: Exchange) -> ZoneInfo:
        spec = self._specs.get(exchange)
        return spec.timezone if spec is not None else _UTC_ZONE

    def local_date(self, exchange: Exchange, at: datetime) -> date:
        return at.astimezone(self.timezone(exchange)).date()

    def trading_day(self, exchange: Exchange, session_date: date) -> TradingDay:
        key = (exchange, session_date)
        day = self._days.get(key)
        if day is None:
            if len(self._days) >= _DAY_CACHE_LIMIT:
                self._days.clear()
            day = self._days[key] = self._compute(exchange, session_date)
        return day

    def trading_day_at(self, exchange: Exchange, at: datetime) -> TradingDay:
        return self.trading_day(exchange, self.local_date(exchange, at))

    def status(self, exchange: Exchange, at: datetime) -> SessionStatus:
        day = self.trading_day_at(exchange, at)
        return SessionStatus(_state(day, at), day)

    def session_open(self, exchanges: Iterable[Exchange], at: datetime) -> bool | None:
        """True if any exchange is in session, None if any is unknown (and none open), else False."""
        unknown = False
        for exchange in exchanges:
            day = self.trading_day_at(exchange, at)
            if day.kind is DayKind.UNKNOWN:
                unknown = True
            elif day.contains(at):
                return True
        return None if unknown else False

    def coverage(self) -> dict[Exchange, date]:
        """Last date each library-backed exchange's sessions are published for."""
        return {
            spec.exchange: self._schedules[spec.calendar_code].last_session
            for spec in self._specs.values()
            if spec.calendar_code is not None and spec.calendar_code in self._schedules
        }

    def _compute(self, exchange: Exchange, session_date: date) -> TradingDay:
        spec = self._specs.get(exchange)
        if spec is None:
            return TradingDay(exchange, session_date, DayKind.UNKNOWN, verified=False)
        schedule = self._schedules.get(spec.calendar_code) if spec.calendar_code is not None else None
        override = self._overrides.get((exchange, session_date))
        if override is not None:
            return _apply_override(spec, session_date, override, schedule)
        if exchange is Exchange.SIM:
            open_at, close_at = _local_span(session_date, time(), None, spec.timezone)
            return TradingDay(exchange, session_date, DayKind.SESSION, open_at, close_at)
        if schedule is None or session_date < schedule.first_session:
            return TradingDay(exchange, session_date, DayKind.UNKNOWN, verified=False)
        trades_today = schedule.weekmask[session_date.weekday()] == "1"
        if session_date <= schedule.last_session:
            hours = schedule.sessions.get(session_date)
            if hours is not None:
                return TradingDay(exchange, session_date, DayKind.SESSION, hours[0], hours[1])
            kind = DayKind.HOLIDAY if trades_today else DayKind.WEEKEND
            return TradingDay(exchange, session_date, kind)
        if not self._extend:
            return TradingDay(exchange, session_date, DayKind.UNKNOWN, verified=False)
        if not trades_today:
            return TradingDay(exchange, session_date, DayKind.WEEKEND, verified=False)
        open_at, close_at = _local_span(
            session_date, schedule.regular_open, schedule.regular_close, spec.timezone
        )
        return TradingDay(exchange, session_date, DayKind.SESSION, open_at, close_at, verified=False)


def _apply_override(
    spec: ExchangeSpec, session_date: date, override: CalendarOverride, schedule: LibrarySchedule | None
) -> TradingDay:
    if override.kind is CalendarOverrideKind.HOLIDAY:
        return TradingDay(spec.exchange, session_date, DayKind.HOLIDAY, special=True)
    open_time = override.open_time or (schedule.regular_open if schedule is not None else None)
    close_time = override.close_time or (schedule.regular_close if schedule is not None else None)
    if open_time is None or close_time is None or close_time <= open_time:
        return TradingDay(spec.exchange, session_date, DayKind.UNKNOWN, special=True, verified=False)
    open_at, close_at = _local_span(session_date, open_time, close_time, spec.timezone)
    return TradingDay(spec.exchange, session_date, DayKind.SESSION, open_at, close_at, special=True)


def _local_span(
    session_date: date, open_time: time, close_time: time | None, zone: ZoneInfo
) -> tuple[datetime, datetime]:
    """UTC bounds of local ``open_time``..``close_time`` (``None``: the next local midnight)."""
    open_at = datetime.combine(session_date, open_time, tzinfo=zone).astimezone(UTC)
    if close_time is None:
        close_local = datetime.combine(session_date + timedelta(days=1), time(), tzinfo=zone)
    else:
        close_local = datetime.combine(session_date, close_time, tzinfo=zone)
    return open_at, close_local.astimezone(UTC)


def _state(day: TradingDay, at: datetime) -> MarketSessionState:
    if day.kind is DayKind.UNKNOWN:
        return MarketSessionState.UNKNOWN
    if day.kind is DayKind.HOLIDAY:
        return MarketSessionState.HOLIDAY
    if day.open_at is None or day.close_at is None:
        return MarketSessionState.CLOSED
    if at < day.open_at:
        return (
            MarketSessionState.PRE_OPEN if at >= day.open_at - PRE_OPEN_WINDOW else MarketSessionState.CLOSED
        )
    if at < day.close_at:
        return MarketSessionState.OPEN
    if at < day.close_at + POST_CLOSE_WINDOW:
        return MarketSessionState.POST_CLOSE
    return MarketSessionState.CLOSED
