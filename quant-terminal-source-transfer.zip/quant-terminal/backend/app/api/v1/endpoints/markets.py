"""Exchange sessions (pre-open, open, closed, holiday) from the exchange calendars, and which markets the
providers stream."""

from __future__ import annotations

from fastapi import APIRouter

from app.api.deps import Capabilities, Clock, CurrentUser, MarketCalendarDep
from app.domain.enums import Provider
from app.services.market_availability import MarketAvailability, market_availability
from app.services.markets import MarketOverview, market_overview

router = APIRouter(prefix="/markets", tags=["markets"])


@router.get("")
async def markets(_user: CurrentUser, calendar: MarketCalendarDep, clock: Clock) -> MarketOverview:
    return await market_overview(calendar, clock())


@router.get("/availability")
async def availability(
    _user: CurrentUser, calendar: MarketCalendarDep, capabilities: Capabilities
) -> list[MarketAvailability]:
    """Each market with the providers whose capabilities stream it, and why the others are unavailable."""
    loaded, _specs = await calendar.get()
    effective = [await capabilities.effective(provider) for provider in Provider]
    return list(market_availability(effective, calendars=loaded.coverage().keys()))
