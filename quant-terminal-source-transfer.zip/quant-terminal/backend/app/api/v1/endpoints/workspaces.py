"""Workspaces: their instrument universes and watchlists. Saved strategy configurations live under
/deployments."""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Path
from pydantic import Field

from app.api.deps import ClientIp, CurrentUser, Watchlists, Workspaces
from app.api.v1.schemas.common import InstrumentRef, RequestModel
from app.domain.enums import Provider, SubscriptionMode
from app.services.watchlists import MAX_NAME_LENGTH, WatchlistView
from app.services.workspaces import MAX_BATCH, Universe, UniverseChange, WorkspaceToggle, WorkspaceView

router = APIRouter(prefix="/workspaces", tags=["workspaces"])

WorkspacePath = Annotated[str, Path(min_length=1, max_length=80, description="Workspace id or slug")]


class UniverseAdd(RequestModel):
    instruments: list[InstrumentRef] = Field(min_length=1, max_length=MAX_BATCH)
    provider: Provider
    account_id: UUID | None = None  # omitted: the provider's enabled account
    mode: SubscriptionMode = SubscriptionMode.QUOTE


class UniverseRemove(RequestModel):
    instruments: list[InstrumentRef] = Field(min_length=1, max_length=MAX_BATCH)


class WatchlistCreate(RequestModel):
    name: str = Field(min_length=1, max_length=MAX_NAME_LENGTH)


@router.get("")
async def list_workspaces(_user: CurrentUser, workspaces: Workspaces) -> list[WorkspaceView]:
    return await workspaces.list_workspaces()


@router.get("/{workspace}")
async def get_workspace(workspace: WorkspacePath, _user: CurrentUser, workspaces: Workspaces) -> Universe:
    """The workspace and its universe: each instrument, its provider and whether it streams."""
    return await workspaces.universe(workspace)


@router.post("/{workspace}/enable")
async def enable_workspace(
    workspace: WorkspacePath, user: CurrentUser, workspaces: Workspaces, ip: ClientIp
) -> WorkspaceToggle:
    return await workspaces.set_enabled(workspace, True, actor=user.username, client_ip=ip)


@router.post("/{workspace}/disable")
async def disable_workspace(
    workspace: WorkspacePath, user: CurrentUser, workspaces: Workspaces, ip: ClientIp
) -> WorkspaceToggle:
    return await workspaces.set_enabled(workspace, False, actor=user.username, client_ip=ip)


@router.post("/{workspace}/instruments")
async def add_instruments(
    workspace: WorkspacePath, body: UniverseAdd, user: CurrentUser, workspaces: Workspaces, ip: ClientIp
) -> UniverseChange:
    return await workspaces.add_instruments(
        workspace,
        body.instruments,
        body.provider,
        account_id=body.account_id,
        mode=body.mode,
        actor=user.username,
        client_ip=ip,
    )


@router.post("/{workspace}/instruments/remove")
async def remove_instruments(
    workspace: WorkspacePath, body: UniverseRemove, user: CurrentUser, workspaces: Workspaces, ip: ClientIp
) -> UniverseChange:
    return await workspaces.remove_instruments(workspace, body.instruments, actor=user.username, client_ip=ip)


@router.get("/{workspace}/watchlists")
async def list_watchlists(
    workspace: WorkspacePath, _user: CurrentUser, watchlists: Watchlists
) -> list[WatchlistView]:
    return await watchlists.list_watchlists(workspace)


@router.post("/{workspace}/watchlists", status_code=201)
async def create_watchlist(
    workspace: WorkspacePath, body: WatchlistCreate, user: CurrentUser, watchlists: Watchlists, ip: ClientIp
) -> WatchlistView:
    return await watchlists.create(workspace, body.name, actor=user.username, client_ip=ip)
