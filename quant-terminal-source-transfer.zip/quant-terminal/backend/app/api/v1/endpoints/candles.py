"""Candles: closed history from the database, plus the forming candle from the live cache."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Query

from app.api.deps import Candles, CurrentUser
from app.domain.enums import CandleInterval, Provider
from app.domain.models.base import UtcDatetime
from app.services.candles import MAX_CANDLES, CandleSeries

router = APIRouter(prefix="/candles", tags=["candles"])


@router.get("")
async def get_candles(
    _user: CurrentUser,
    candles: Candles,
    instrument: Annotated[
        str, Query(min_length=1, max_length=120, description="Instrument id or canonical key")
    ],
    provider: Provider,
    interval: CandleInterval = CandleInterval.M1,
    limit: Annotated[int, Query(ge=1, le=MAX_CANDLES)] = 300,
    until: Annotated[
        UtcDatetime | None, Query(description="Only candles that ended by this time; omit for the latest")
    ] = None,
    include_forming: bool = True,
) -> CandleSeries:
    return await candles.series(
        instrument, provider, interval, limit=limit, until=until, include_forming=include_forming
    )
