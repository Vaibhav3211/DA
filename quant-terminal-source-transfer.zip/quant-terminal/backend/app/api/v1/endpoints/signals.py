"""Signals: decision support only. Nothing here places or routes an order."""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query

from app.api.deps import CurrentUser, Signals
from app.api.v1.schemas.common import checked
from app.domain.enums import SignalStatus, SignalType
from app.domain.models.base import UtcDatetime
from app.services.signals import DEFAULT_LIMIT, MAX_LIMIT, SignalDetail, SignalPage, SignalQuery

router = APIRouter(prefix="/signals", tags=["signals"])


@router.get("")
async def list_signals(
    _user: CurrentUser,
    signals: Signals,
    workspace: Annotated[str | None, Query(min_length=1, max_length=80)] = None,
    strategy_id: Annotated[str | None, Query(min_length=1, max_length=100)] = None,
    instrument: Annotated[str | None, Query(min_length=1, max_length=120)] = None,
    deployment_id: UUID | None = None,
    status: Annotated[list[SignalStatus] | None, Query(description="Repeat for several")] = None,
    signal_type: Annotated[list[SignalType] | None, Query(description="Repeat for several")] = None,
    open_only: bool = False,
    actionable: bool | None = None,
    since: UtcDatetime | None = None,
    until: UtcDatetime | None = None,
    limit: Annotated[int, Query(ge=1, le=MAX_LIMIT)] = DEFAULT_LIMIT,
    cursor: Annotated[
        str | None, Query(max_length=200, description="next_cursor of the previous page")
    ] = None,
) -> SignalPage:
    query = checked(
        SignalQuery,
        workspace=workspace,
        strategy_id=strategy_id,
        instrument=instrument,
        deployment_id=deployment_id,
        statuses=frozenset(status or ()),
        signal_types=frozenset(signal_type or ()),
        open_only=open_only,
        actionable=actionable,
        since=since,
        until=until,
        limit=limit,
        cursor=cursor,
    )
    return await signals.list_signals(query)


@router.get("/{signal_id}")
async def get_signal(signal_id: UUID, _user: CurrentUser, signals: Signals) -> SignalDetail:
    """The signal with its lifecycle events and risk decisions."""
    return await signals.get_signal(signal_id)
