"""Provider accounts and their stored credentials. Credentials are write-only: responses carry masks."""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query
from pydantic import Field

from app.api.deps import Accounts, ClientIp, CurrentUser
from app.api.v1.schemas.common import RequestModel, Secret
from app.domain.enums import AuthMethod, CredentialKind, Provider
from app.services.provider_accounts import ProviderAccountView

router = APIRouter(prefix="/accounts", tags=["accounts"])


class AccountCreate(RequestModel):
    provider: Provider
    label: str = Field(min_length=1, max_length=80)
    auth_method: AuthMethod | None = None


class AccountUpdate(RequestModel):
    label: str | None = Field(default=None, min_length=1, max_length=80)
    auth_method: AuthMethod | None = None


class CredentialsUpdate(RequestModel):
    values: dict[CredentialKind, Secret] = Field(min_length=1, max_length=len(CredentialKind))


@router.get("")
async def list_accounts(
    _user: CurrentUser, accounts: Accounts, provider: Provider | None = None
) -> list[ProviderAccountView]:
    return await accounts.list_accounts(provider)


@router.post("", status_code=201)
async def create_account(
    body: AccountCreate, user: CurrentUser, accounts: Accounts, ip: ClientIp
) -> ProviderAccountView:
    return await accounts.create(
        body.provider, body.label, auth_method=body.auth_method, actor=user.username, client_ip=ip
    )


@router.get("/{account_id}")
async def get_account(account_id: UUID, _user: CurrentUser, accounts: Accounts) -> ProviderAccountView:
    return await accounts.get(account_id)


@router.patch("/{account_id}")
async def update_account(
    account_id: UUID, body: AccountUpdate, user: CurrentUser, accounts: Accounts, ip: ClientIp
) -> ProviderAccountView:
    return await accounts.update(
        account_id, label=body.label, auth_method=body.auth_method, actor=user.username, client_ip=ip
    )


@router.delete("/{account_id}", status_code=204)
async def delete_account(account_id: UUID, user: CurrentUser, accounts: Accounts, ip: ClientIp) -> None:
    await accounts.delete(account_id, actor=user.username, client_ip=ip)


@router.post("/{account_id}/enable")
async def enable_account(
    account_id: UUID, user: CurrentUser, accounts: Accounts, ip: ClientIp
) -> ProviderAccountView:
    return await accounts.set_enabled(account_id, True, actor=user.username, client_ip=ip)


@router.post("/{account_id}/disable")
async def disable_account(
    account_id: UUID, user: CurrentUser, accounts: Accounts, ip: ClientIp
) -> ProviderAccountView:
    return await accounts.set_enabled(account_id, False, actor=user.username, client_ip=ip)


@router.put("/{account_id}/credentials")
async def set_credentials(
    account_id: UUID, body: CredentialsUpdate, user: CurrentUser, accounts: Accounts, ip: ClientIp
) -> ProviderAccountView:
    """Store or replace credentials; kinds not sent are kept."""
    values = {kind: secret.get_secret_value() for kind, secret in body.values.items()}
    return await accounts.set_credentials(account_id, values, actor=user.username, client_ip=ip)


@router.delete("/{account_id}/credentials")
async def clear_credentials(
    account_id: UUID,
    user: CurrentUser,
    accounts: Accounts,
    ip: ClientIp,
    kind: Annotated[
        list[CredentialKind] | None, Query(description="Kinds to clear; all when omitted")
    ] = None,
) -> ProviderAccountView:
    return await accounts.clear_credentials(account_id, kind or None, actor=user.username, client_ip=ip)
