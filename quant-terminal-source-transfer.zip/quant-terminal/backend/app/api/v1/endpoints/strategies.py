"""Strategy catalogue, saved configurations (deployments) and their runs.

A saved configuration names a strategy, its settings and its instrument scope in a workspace. Its live
signals start off; once they are on, the strategy worker monitors it on the server until they are turned
off, whether or not a chart is open.
"""

from __future__ import annotations

from typing import Annotated, Any
from uuid import UUID

from fastapi import APIRouter, Path, Query
from pydantic import Field

from app.api.deps import ClientIp, CurrentUser, Strategies
from app.api.v1.schemas.common import RequestModel
from app.domain.enums import CandleInterval, ScopeKind
from app.services.strategies import (
    MAX_LABEL,
    MAX_RUNS,
    MAX_SCOPE,
    CatalogueSync,
    DeploymentView,
    RunView,
    Scope,
    StrategyView,
)
from app.services.strategy_compatibility import InstrumentCompatibility

router = APIRouter(tags=["strategies"])

WorkspaceFilter = Annotated[
    str | None, Query(min_length=1, max_length=80, description="Workspace id or slug")
]
StrategyFilter = Annotated[str | None, Query(min_length=1, max_length=100)]


class ScopeBody(RequestModel):
    """What a configuration watches. There is no default: list its instruments, or choose the whole
    workspace (including instruments added later) explicitly."""

    kind: ScopeKind
    instrument_ids: list[UUID] = Field(default_factory=list, max_length=MAX_SCOPE)  # empty for WORKSPACE

    def scope(self) -> Scope:
        return Scope(self.kind, tuple(self.instrument_ids))


class ConfigurationCreate(RequestModel):
    workspace: str = Field(min_length=1, max_length=80, description="Workspace id or slug")
    strategy_id: str = Field(min_length=1, max_length=100)
    scope: ScopeBody
    # Unique among the workspace's configurations; omitted: the strategy id, numbered when taken.
    label: str | None = Field(default=None, max_length=MAX_LABEL)
    config: dict[str, Any] | None = None  # the settings that differ from the strategy's defaults


class ConfigurationUpdate(RequestModel):
    label: str | None = Field(default=None, max_length=MAX_LABEL)  # renames it
    scope: ScopeBody | None = None  # replaces its scope; omitted: it keeps it
    config: dict[str, Any] | None = None  # settings to change; the others keep their saved values
    reset_config: bool = False  # start from the strategy's defaults rather than the saved settings


@router.get("/strategies")
async def list_strategies(_user: CurrentUser, strategies: Strategies) -> list[StrategyView]:
    return await strategies.list_strategies()


@router.post("/strategies/sync")
async def sync_strategies(user: CurrentUser, strategies: Strategies) -> CatalogueSync:
    """Re-read the strategy code shipped with the backend into the catalogue."""
    return await strategies.sync_catalogue(actor=user.username)


@router.get("/strategies/{strategy_id}")
async def get_strategy(
    strategy_id: Annotated[str, Path(min_length=1, max_length=100)],
    _user: CurrentUser,
    strategies: Strategies,
) -> StrategyView:
    return await strategies.get_strategy(strategy_id)


@router.get("/strategy-compatibility")
async def get_compatibility(
    _user: CurrentUser,
    strategies: Strategies,
    workspace: Annotated[str, Query(min_length=1, max_length=80, description="Workspace id or slug")],
    instrument_id: UUID,
    chart_interval: Annotated[
        CandleInterval | None, Query(description="The chart's interval, compared with each strategy's")
    ] = None,
) -> InstrumentCompatibility:
    """How each strategy in the code suits an instrument of the workspace, as the workspace streams it:
    market, instrument, timeframe, data and warm-up checks, each passed, warning or failed."""
    return await strategies.compatibility(workspace, instrument_id, chart_interval=chart_interval)


@router.get("/strategy-runs")
async def list_runs(
    _user: CurrentUser,
    strategies: Strategies,
    workspace: WorkspaceFilter = None,
    strategy_id: StrategyFilter = None,
    deployment_id: UUID | None = None,
    limit: Annotated[int, Query(ge=1, le=MAX_RUNS)] = 20,
) -> list[RunView]:
    """The latest runs first."""
    return await strategies.list_runs(workspace, strategy_id, deployment_id=deployment_id, limit=limit)


@router.get("/deployments")
async def list_deployments(
    _user: CurrentUser,
    strategies: Strategies,
    workspace: WorkspaceFilter = None,
    strategy_id: StrategyFilter = None,
    instrument_id: Annotated[
        UUID | None, Query(description="Only configurations whose scope covers this instrument")
    ] = None,
    include_archived: bool = False,
) -> list[DeploymentView]:
    """Saved configurations with their monitoring state."""
    return await strategies.list_deployments(
        workspace, strategy_id=strategy_id, instrument_id=instrument_id, include_archived=include_archived
    )


@router.post("/deployments", status_code=201)
async def create_deployment(
    body: ConfigurationCreate, user: CurrentUser, strategies: Strategies, ip: ClientIp
) -> DeploymentView:
    """Save a configuration of a strategy in a workspace. Its live signals start off."""
    return await strategies.create_configuration(
        body.workspace,
        body.strategy_id,
        scope=body.scope.scope(),
        label=body.label,
        config=body.config,
        actor=user.username,
        client_ip=ip,
    )


@router.get("/deployments/{deployment_id}")
async def get_deployment(deployment_id: UUID, _user: CurrentUser, strategies: Strategies) -> DeploymentView:
    """A saved configuration, archived or not, with its monitoring state."""
    return await strategies.get_deployment(deployment_id)


@router.patch("/deployments/{deployment_id}")
async def update_deployment(
    deployment_id: UUID, body: ConfigurationUpdate, user: CurrentUser, strategies: Strategies, ip: ClientIp
) -> DeploymentView:
    """Save a configuration again: it moves to the code's version of its strategy, and takes the label,
    scope and settings given. When its live signals are on, the strategy worker picks up the change."""
    return await strategies.update_configuration(
        deployment_id,
        label=body.label,
        scope=None if body.scope is None else body.scope.scope(),
        config=body.config,
        reset_config=body.reset_config,
        actor=user.username,
        client_ip=ip,
    )


@router.post("/deployments/{deployment_id}/enable")
async def enable_deployment(
    deployment_id: UUID, user: CurrentUser, strategies: Strategies, ip: ClientIp
) -> DeploymentView:
    """Turn live signals on; asking again changes nothing. The strategy worker then monitors the
    configuration on the server, whether or not a chart is open, until they are turned off."""
    return await strategies.set_enabled(deployment_id, True, actor=user.username, client_ip=ip)


@router.post("/deployments/{deployment_id}/disable")
async def disable_deployment(
    deployment_id: UUID, user: CurrentUser, strategies: Strategies, ip: ClientIp
) -> DeploymentView:
    """Turn live signals off, which stops monitoring. Its runs and signals stay."""
    return await strategies.set_enabled(deployment_id, False, actor=user.username, client_ip=ip)


@router.post("/deployments/{deployment_id}/archive")
async def archive_deployment(
    deployment_id: UUID, user: CurrentUser, strategies: Strategies, ip: ClientIp
) -> DeploymentView:
    """Archive a configuration whose live signals are off: it leaves the lists and frees its label. Its
    runs and signals stay."""
    return await strategies.archive(deployment_id, actor=user.username, client_ip=ip)
