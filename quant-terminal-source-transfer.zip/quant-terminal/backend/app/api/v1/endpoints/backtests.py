"""Backtests: replays of a saved configuration's strategy over a dataset, and the trade rules they use.

Backtests are simulations on past candles. Nothing here places or routes an order, and reading a result
never runs a backtest: ``POST /backtests`` queues one for the backtest worker.
"""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query

from app.api.deps import Backtests, ClientIp, CurrentUser, Paging
from app.api.v1.schemas.common import InstrumentRef, RequestModel
from app.domain.enums import BacktestStatus
from app.domain.models.backtest import TradeRules
from app.services.backtests import (
    TRADES_LIMIT_MAX,
    BacktestDetail,
    BacktestLatest,
    BacktestQueueResult,
    BacktestRunView,
    BacktestTradesPage,
    TradeRulesView,
)

router = APIRouter(tags=["backtests"])

InstrumentQuery = Annotated[
    str, Query(min_length=1, max_length=120, description="Instrument id or canonical key")
]


class BacktestRequest(RequestModel):
    deployment_id: UUID  # the saved configuration
    instrument: InstrumentRef  # id or canonical key; must be in the configuration's scope
    dataset_id: UUID  # a READY dataset of that instrument, at the strategy's interval


class TradeRulesBody(TradeRules):
    """Trade rules to save with a configuration: the request form of ``TradeRules``, whose decimal
    amounts may be sent as numbers or strings."""


@router.get("/deployments/{deployment_id}/backtest-rules")
async def get_trade_rules(deployment_id: UUID, _user: CurrentUser, backtests: Backtests) -> TradeRulesView:
    """The trade rules the configuration's backtests use: its own when saved, else the strategy's."""
    return await backtests.rules(deployment_id)


@router.put("/deployments/{deployment_id}/backtest-rules")
async def set_trade_rules(
    deployment_id: UUID, body: TradeRulesBody, user: CurrentUser, backtests: Backtests, ip: ClientIp
) -> TradeRulesView:
    """Save trade rules with the configuration. Its backtests that used other rules become outdated."""
    return await backtests.set_rules(deployment_id, body, actor=user.username, client_ip=ip)


@router.delete("/deployments/{deployment_id}/backtest-rules")
async def clear_trade_rules(
    deployment_id: UUID, user: CurrentUser, backtests: Backtests, ip: ClientIp
) -> TradeRulesView:
    """Drop the configuration's own trade rules: its backtests use the strategy's, when it declares any."""
    return await backtests.clear_rules(deployment_id, actor=user.username, client_ip=ip)


@router.post("/backtests", status_code=202)
async def queue_backtest(
    body: BacktestRequest, user: CurrentUser, backtests: Backtests, ip: ClientIp
) -> BacktestQueueResult:
    """Queue a backtest for the backtest worker after checking that it can run. Asking again while the same
    backtest waits, runs or has succeeded returns that one (``created`` false)."""
    return await backtests.queue(
        body.deployment_id, body.instrument, body.dataset_id, actor=user.username, client_ip=ip
    )


@router.get("/backtests")
async def list_backtests(
    _user: CurrentUser,
    backtests: Backtests,
    paging: Paging,
    deployment_id: UUID | None = None,
    instrument: Annotated[
        str | None, Query(min_length=1, max_length=120, description="Instrument id or canonical key")
    ] = None,
    status: BacktestStatus | None = None,
) -> list[BacktestRunView]:
    """The newest first; each says whether it is outdated against its configuration's current settings."""
    return await backtests.list_runs(
        deployment_id=deployment_id,
        instrument=instrument,
        status=status,
        limit=paging.limit,
        offset=paging.offset,
    )


@router.get("/backtests/latest")
async def latest_backtest(
    deployment_id: UUID, instrument: InstrumentQuery, _user: CurrentUser, backtests: Backtests
) -> BacktestLatest:
    """The configuration's latest backtest on the instrument with its current settings (CURRENT), else its
    latest one with other settings (OUTDATED), else NOT_BACKTESTED; and why it cannot be backtested now."""
    return await backtests.latest(deployment_id, instrument)


@router.get("/backtests/{run_id}")
async def get_backtest(run_id: UUID, _user: CurrentUser, backtests: Backtests) -> BacktestDetail:
    """A backtest with its summary, dataset and equity curve, and the settings changed since it ran."""
    return await backtests.get(run_id)


@router.get("/backtests/{run_id}/trades")
async def list_backtest_trades(
    run_id: UUID,
    _user: CurrentUser,
    backtests: Backtests,
    offset: Annotated[int, Query(ge=0, le=1_000_000)] = 0,
    limit: Annotated[int, Query(ge=1, le=TRADES_LIMIT_MAX)] = 100,
) -> BacktestTradesPage:
    """A page of the backtest's closed trades, in order. An open position at the end is in its summary."""
    return await backtests.trades(run_id, offset=offset, limit=limit)
