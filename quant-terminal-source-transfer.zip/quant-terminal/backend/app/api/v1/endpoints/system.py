"""System health, metrics summary, and kill switch."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field

from app.api.deps import ClientIp, ContainerDep, CurrentUser
from app.observability.health import SystemHealth, SystemHealthService
from app.services.kill_switch import KillSwitchService, KillSwitchState

router = APIRouter(prefix="/system", tags=["system"])


@router.get("/health")
async def system_health(container: ContainerDep, _user: CurrentUser) -> SystemHealth:
    return await SystemHealthService(container).report()


class MetricsSummary(BaseModel):
    workers: list[dict[str, Any]]
    feeds: list[dict[str, Any]]
    websocket_clients: int
    prometheus_endpoint: str = "/metrics"


@router.get("/metrics")
async def system_metrics(request: Request, container: ContainerDep, _user: CurrentUser) -> MetricsSummary:
    """Operator summary. Full time series are exposed in Prometheus format at ``/metrics``."""
    report = await SystemHealthService(container).report()
    hub = getattr(request.app.state, "ws_hub", None)
    return MetricsSummary(
        workers=[w.model_dump(mode="json") for w in report.workers],
        feeds=[f.model_dump(mode="json") for f in report.feeds],
        websocket_clients=hub.client_count if hub is not None else 0,
    )


class KillSwitchUpdate(BaseModel):
    engaged: bool
    reason: str | None = Field(default=None, max_length=300)


@router.get("/kill-switch")
async def get_kill_switch(container: ContainerDep, _user: CurrentUser) -> KillSwitchState:
    return await KillSwitchService(container.db, container.bus).get()


@router.put("/kill-switch")
async def set_kill_switch(
    body: KillSwitchUpdate, container: ContainerDep, user: CurrentUser, ip: ClientIp
) -> KillSwitchState:
    return await KillSwitchService(container.db, container.bus).set(
        engaged=body.engaged, reason=body.reason, actor=user.username, client_ip=ip
    )
