"""Watchlists: named, ordered instrument lists for viewing. They subscribe nothing."""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter
from pydantic import Field

from app.api.deps import ClientIp, CurrentUser, Watchlists
from app.api.v1.schemas.common import RequestModel
from app.services.watchlists import MAX_NAME_LENGTH, MAX_WATCHLIST_ITEMS, WatchlistView

router = APIRouter(prefix="/watchlists", tags=["watchlists"])


class WatchlistUpdate(RequestModel):
    name: str | None = Field(default=None, min_length=1, max_length=MAX_NAME_LENGTH)
    sort_order: int | None = Field(default=None, ge=0, le=10_000)


class WatchlistItems(RequestModel):
    instrument_ids: list[UUID] = Field(max_length=MAX_WATCHLIST_ITEMS)  # the new contents, in order


@router.get("/{watchlist_id}")
async def get_watchlist(watchlist_id: UUID, _user: CurrentUser, watchlists: Watchlists) -> WatchlistView:
    return await watchlists.get(watchlist_id)


@router.patch("/{watchlist_id}")
async def update_watchlist(
    watchlist_id: UUID, body: WatchlistUpdate, user: CurrentUser, watchlists: Watchlists, ip: ClientIp
) -> WatchlistView:
    return await watchlists.update(
        watchlist_id, name=body.name, sort_order=body.sort_order, actor=user.username, client_ip=ip
    )


@router.delete("/{watchlist_id}", status_code=204)
async def delete_watchlist(
    watchlist_id: UUID, user: CurrentUser, watchlists: Watchlists, ip: ClientIp
) -> None:
    await watchlists.delete(watchlist_id, actor=user.username, client_ip=ip)


@router.put("/{watchlist_id}/items")
async def set_watchlist_items(
    watchlist_id: UUID, body: WatchlistItems, user: CurrentUser, watchlists: Watchlists, ip: ClientIp
) -> WatchlistView:
    return await watchlists.set_items(watchlist_id, body.instrument_ids, actor=user.username, client_ip=ip)
