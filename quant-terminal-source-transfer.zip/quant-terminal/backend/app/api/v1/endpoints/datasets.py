"""Backtest datasets: the closed candles of one instrument at one interval over a date range, stored for
replay.

The backtest worker builds a dataset from a provider's history API (with one of its accounts) or from the
candles the feeds recorded. Simulator candles make a simulated dataset; backtests on it say so.
"""

from __future__ import annotations

from datetime import date
from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query

from app.api.deps import ClientIp, CurrentUser, Datasets, Paging
from app.api.v1.schemas.common import InstrumentRef, RequestModel
from app.domain.enums import CandleInterval, DatasetSource, DatasetStatus, Provider
from app.services.datasets import DatasetRequestResult, DatasetSources, DatasetView

router = APIRouter(prefix="/datasets", tags=["backtests"])

InstrumentQuery = Annotated[
    str, Query(min_length=1, max_length=120, description="Instrument id or canonical key")
]


class DatasetRequest(RequestModel):
    instrument: InstrumentRef  # id or canonical key
    provider: Provider
    source: DatasetSource
    interval: CandleInterval
    date_from: date  # exchange-local dates, both included
    date_to: date
    # PROVIDER_HISTORY only: the account to download with; omitted: the provider's only enabled account.
    account_id: UUID | None = None


@router.get("/sources")
async def dataset_sources(
    instrument: InstrumentQuery, _user: CurrentUser, datasets: Datasets
) -> DatasetSources:
    """Where the instrument's datasets can come from, what each source can supply and why one cannot."""
    return await datasets.sources(instrument)


@router.post("", status_code=202)
async def request_dataset(
    body: DatasetRequest, user: CurrentUser, datasets: Datasets, ip: ClientIp
) -> DatasetRequestResult:
    """Queue a dataset for the backtest worker after checking that its source can supply it. Asking again
    while the same request waits or builds returns that one (``created`` false)."""
    return await datasets.request(
        body.instrument,
        provider=body.provider,
        source=body.source,
        interval=body.interval,
        date_from=body.date_from,
        date_to=body.date_to,
        account_id=body.account_id,
        actor=user.username,
        client_ip=ip,
    )


@router.get("")
async def list_datasets(
    _user: CurrentUser,
    datasets: Datasets,
    paging: Paging,
    instrument: Annotated[
        str | None, Query(min_length=1, max_length=120, description="Instrument id or canonical key")
    ] = None,
    interval: CandleInterval | None = None,
    status: DatasetStatus | None = None,
) -> list[DatasetView]:
    """The newest first."""
    return await datasets.list_datasets(
        instrument=instrument, interval=interval, status=status, limit=paging.limit, offset=paging.offset
    )


@router.get("/{dataset_id}")
async def get_dataset(dataset_id: UUID, _user: CurrentUser, datasets: Datasets) -> DatasetView:
    """A dataset with its coverage (once READY): expected, present and missing candles, and the gaps."""
    return await datasets.get(dataset_id)
