"""Sign-in, sign-out and current-session endpoints."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, Request, Response
from pydantic import BaseModel, Field, SecretStr

from app.api.deps import AuthServiceDep, ClientIp, ContainerDep, CurrentUser
from app.api.v1.schemas.common import OkResponse
from app.services.auth_service import SessionUser

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: SecretStr = Field(min_length=1, max_length=256)


class SessionResponse(BaseModel):
    user_id: UUID
    username: str
    expires_at: datetime

    @classmethod
    def of(cls, user: SessionUser) -> SessionResponse:
        return cls(user_id=user.user_id, username=user.username, expires_at=user.expires_at)


@router.post("/login")
async def login(
    body: LoginRequest, response: Response, auth: AuthServiceDep, container: ContainerDep, ip: ClientIp
) -> SessionResponse:
    token, user = await auth.login(body.username, body.password.get_secret_value(), client_ip=ip)
    settings = container.settings
    response.set_cookie(
        settings.session_cookie_name,
        token,
        max_age=settings.session_ttl_seconds,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        path="/",
    )
    return SessionResponse.of(user)


@router.post("/logout")
async def logout(
    request: Request, response: Response, auth: AuthServiceDep, container: ContainerDep, ip: ClientIp
) -> OkResponse:
    name = container.settings.session_cookie_name
    token = request.cookies.get(name)
    if token:
        await auth.logout(token, client_ip=ip)
    response.delete_cookie(
        name, path="/", secure=container.settings.cookie_secure, httponly=True, samesite="lax"
    )
    return OkResponse()


@router.get("/me")
async def me(user: CurrentUser) -> SessionResponse:
    return SessionResponse.of(user)
