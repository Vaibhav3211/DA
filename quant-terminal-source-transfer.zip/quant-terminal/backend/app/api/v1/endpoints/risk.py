"""Risk rules (global, or per workspace) and pausing a workspace's signals."""

from __future__ import annotations

from typing import Annotated, Any, Self

from fastapi import APIRouter, Path, Query
from pydantic import Field, model_validator

from app.api.deps import ClientIp, CurrentUser, Risk
from app.api.v1.schemas.common import RequestModel
from app.services.risk import RiskRuleView

router = APIRouter(prefix="/risk", tags=["risk"])

RuleKey = Annotated[str, Path(min_length=1, max_length=64)]
WorkspacePath = Annotated[str, Path(min_length=1, max_length=80, description="Workspace id or slug")]
Scope = Annotated[
    str | None,
    Query(min_length=1, max_length=80, description="Workspace id or slug; omit for the global rule"),
]


class RuleUpdate(RequestModel):
    enabled: bool | None = None
    params: dict[str, Any] | None = None  # merged over the current parameters, then validated

    @model_validator(mode="after")
    def _has_change(self) -> Self:
        if self.enabled is None and self.params is None:
            raise ValueError("Send enabled, params or both")
        return self


class PauseRequest(RequestModel):
    reason: str | None = Field(default=None, max_length=300)


@router.get("/rules")
async def list_rules(_user: CurrentUser, risk: Risk, workspace: Scope = None) -> list[RiskRuleView]:
    return await risk.list_rules(workspace)


@router.get("/rules/{rule_key}")
async def get_rule(
    rule_key: RuleKey, _user: CurrentUser, risk: Risk, workspace: Scope = None
) -> RiskRuleView:
    return await risk.get_rule(rule_key, workspace)


@router.put("/rules/{rule_key}")
async def set_rule(
    rule_key: RuleKey, body: RuleUpdate, user: CurrentUser, risk: Risk, ip: ClientIp, workspace: Scope = None
) -> RiskRuleView:
    return await risk.set_rule(
        rule_key,
        workspace=workspace,
        enabled=body.enabled,
        params=body.params,
        actor=user.username,
        client_ip=ip,
    )


@router.post("/rules/{rule_key}/reset")
async def reset_rule(
    rule_key: RuleKey, user: CurrentUser, risk: Risk, ip: ClientIp, workspace: Scope = None
) -> RiskRuleView:
    """Drop the stored setting: a workspace rule falls back to the global one, a global rule to defaults."""
    return await risk.reset_rule(rule_key, workspace=workspace, actor=user.username, client_ip=ip)


@router.post("/workspaces/{workspace}/pause")
async def pause_workspace(
    workspace: WorkspacePath, user: CurrentUser, risk: Risk, ip: ClientIp, body: PauseRequest | None = None
) -> RiskRuleView:
    """Block the workspace's new signals until resumed. Market data keeps streaming."""
    reason = body.reason if body is not None else None
    return await risk.pause(workspace, reason=reason, actor=user.username, client_ip=ip)


@router.post("/workspaces/{workspace}/resume")
async def resume_workspace(
    workspace: WorkspacePath, user: CurrentUser, risk: Risk, ip: ClientIp
) -> RiskRuleView:
    return await risk.resume(workspace, actor=user.username, client_ip=ip)
