"""Provider connections: status, capabilities, and the Zerodha and Groww sign-in flows.

No response carries a provider token or secret; account views show masked values only.
"""

from __future__ import annotations

import html
from string import Template
from typing import Annotated, Self
from urllib.parse import urlencode, urlsplit, urlunsplit
from uuid import UUID

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from pydantic import model_validator

from app.api.deps import (
    Accounts,
    Capabilities,
    ClientIp,
    ContainerDep,
    CurrentUser,
    ProviderAuth,
    ProviderStatuses,
    resolve_session,
)
from app.api.v1.schemas.common import RequestModel, Secret
from app.core.errors import AppError, ValidationFailedError
from app.core.logging import get_logger
from app.domain.enums import Provider
from app.domain.models import ProviderCapabilities
from app.services.provider_accounts import ProviderAccountView
from app.services.provider_auth import LogoutResult, ZerodhaLoginStart
from app.services.provider_status import ProviderHealth, ProviderSummary, parse_provider

log = get_logger(__name__)
router = APIRouter(prefix="/providers", tags=["providers"])


async def path_provider(provider: str, container: ContainerDep) -> Provider:
    return parse_provider(provider, container.settings)


PathProvider = Annotated[Provider, Depends(path_provider)]


class AccountRequest(RequestModel):
    account_id: UUID


class GrowwConnectRequest(RequestModel):
    """Sign a Groww account in.

    ``access_token`` stores a token generated on Groww's site. Otherwise a token is created from the
    stored API key and secret, or from the stored TOTP secret; ``totp_code`` supplies a one-time code
    instead of the stored TOTP secret.
    """

    account_id: UUID
    access_token: Secret | None = None
    totp_code: Secret | None = None

    @model_validator(mode="after")
    def _one_source(self) -> Self:
        if self.access_token is not None and self.totp_code is not None:
            raise ValueError("Send access_token or totp_code, not both")
        return self


@router.get("")
async def list_providers(_user: CurrentUser, statuses: ProviderStatuses) -> list[ProviderSummary]:
    return await statuses.summaries()


@router.post("/zerodha/connect")
async def zerodha_connect(body: AccountRequest, user: CurrentUser, auth: ProviderAuth) -> ZerodhaLoginStart:
    """Start a Kite login: open ``login_url`` in this browser; Kite then redirects to the callback."""
    return await auth.begin_zerodha_login(body.account_id, actor=user.username)


@router.get("/zerodha/callback")
async def zerodha_callback(
    request: Request, container: ContainerDep, auth: ProviderAuth, ip: ClientIp
) -> Response:
    """Kite redirects the browser here; the outcome is passed on to the frontend's providers page.

    A login started by ``qt zerodha login`` is left for the command line: this page shows the address
    to paste at its prompt, since redirecting would take the request token out of the address bar.
    """
    settings = container.settings
    query = request.url.query
    if await auth.is_cli_zerodha_login(query):
        return _cli_login_page(settings.zerodha_redirect_url, query)
    frontend = settings.frontend_base_url
    user = await resolve_session(request, container)
    if user is None:
        return _to_frontend(frontend, zerodha="error", code="unauthenticated")
    try:
        account = await auth.complete_zerodha_login(query, actor=user.username, client_ip=ip)
    except AppError as exc:
        log.warning("zerodha_callback_failed", code=exc.code)
        return _to_frontend(frontend, zerodha="error", code=exc.code)
    return _to_frontend(frontend, zerodha="connected", account_id=str(account.id))


@router.post("/groww/connect")
async def groww_connect(
    body: GrowwConnectRequest, user: CurrentUser, auth: ProviderAuth, ip: ClientIp
) -> ProviderAccountView:
    if body.access_token is not None:
        return await auth.set_groww_token(
            body.account_id, body.access_token.get_secret_value(), actor=user.username, client_ip=ip
        )
    code = body.totp_code.get_secret_value() if body.totp_code is not None else None
    return await auth.create_groww_token(body.account_id, code=code, actor=user.username, client_ip=ip)


@router.get("/{provider}")
async def get_provider(
    provider: PathProvider, _user: CurrentUser, statuses: ProviderStatuses
) -> ProviderSummary:
    return await statuses.summary(provider)


@router.get("/{provider}/health")
async def provider_health(
    provider: PathProvider, _user: CurrentUser, statuses: ProviderStatuses
) -> ProviderHealth:
    return await statuses.health(provider)


@router.get("/{provider}/capabilities")
async def provider_capabilities(
    provider: PathProvider, _user: CurrentUser, capabilities: Capabilities, account_id: UUID | None = None
) -> ProviderCapabilities:
    """Documented capabilities with overrides applied (the account's own, when ``account_id`` is given)."""
    return await capabilities.effective(provider, account_id)


@router.post("/{provider}/disconnect")
async def disconnect(
    provider: PathProvider,
    body: AccountRequest,
    user: CurrentUser,
    accounts: Accounts,
    auth: ProviderAuth,
    ip: ClientIp,
) -> LogoutResult:
    account = await accounts.get(body.account_id)
    if account.provider is not provider:
        raise ValidationFailedError(
            f"The account belongs to {account.provider.value}, not {provider.value}", code="provider_mismatch"
        )
    return await auth.disconnect(body.account_id, actor=user.username, client_ip=ip)


def _to_frontend(base: str, **params: str) -> RedirectResponse:
    return RedirectResponse(f"{base.rstrip('/')}/providers?{urlencode(params)}", status_code=303)


_CLI_LOGIN_PAGE = Template("""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Finish the Zerodha login - Quant Terminal</title>
<style>
body { max-width: 44rem; margin: 3rem auto; padding: 0 1rem; font: 16px/1.5 system-ui, sans-serif;
  color: #e6edf3; background: #0b0f14; }
textarea { box-sizing: border-box; width: 100%; padding: 0.5rem; font: 14px ui-monospace, monospace;
  color: inherit; background: #11161d; border: 1px solid #30363d; border-radius: 6px; }
</style>
</head>
<body>
<h1>Finish the login at the command line</h1>
<p><code>qt zerodha login</code> started this Kite login and is waiting for this address. Copy it and
paste it at the prompt:</p>
<textarea readonly rows="5" aria-label="Address to paste">$address</textarea>
<p>It holds a one-time request token, so paste it nowhere else. Close this page once the command
reports the login.</p>
</body>
</html>
""")
_CLI_LOGIN_PAGE_POLICY = "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'"


def _cli_login_page(redirect_url: str | None, query: str) -> HTMLResponse:
    """The address Kite sent the browser to, for the user to paste at the ``qt zerodha login`` prompt."""
    address = f"?{query}"  # the command also accepts a bare query string
    if redirect_url and redirect_url.strip():
        parts = urlsplit(redirect_url.strip())
        address = urlunsplit((parts.scheme, parts.netloc, parts.path, query, ""))
    return HTMLResponse(
        _CLI_LOGIN_PAGE.substitute(address=html.escape(address)),
        headers={"Content-Security-Policy": _CLI_LOGIN_PAGE_POLICY, "Referrer-Policy": "no-referrer"},
    )
