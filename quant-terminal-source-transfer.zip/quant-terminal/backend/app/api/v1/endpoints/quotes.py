"""Latest quotes from the live cache, with their data status recomputed at read time."""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query

from app.api.deps import CurrentUser, Quotes
from app.domain.enums import Provider
from app.services.quotes import QuoteList

router = APIRouter(prefix="/quotes", tags=["quotes"])


@router.get("/latest")
async def latest_quotes(
    _user: CurrentUser,
    quotes: Quotes,
    workspace: Annotated[
        str | None, Query(min_length=1, max_length=80, description="Quotes for this workspace's universe")
    ] = None,
    instrument_id: Annotated[list[UUID] | None, Query(description="Repeat for several instruments")] = None,
    provider: Provider | None = None,
) -> QuoteList:
    return await quotes.latest(workspace=workspace, instrument_ids=instrument_id or (), provider=provider)
