"""Instrument master: search, details and provider refreshes."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Path, Query

from app.api.deps import ClientIp, CurrentUser, Instruments
from app.api.v1.schemas.common import RequestModel, checked
from app.domain.enums import Exchange, InstrumentType, OptionType, Provider, Segment
from app.services.instruments import (
    SEARCH_LIMIT_MAX,
    InstrumentDetail,
    InstrumentPage,
    InstrumentQuery,
    RefreshReport,
)

router = APIRouter(prefix="/instruments", tags=["instruments"])


class RefreshRequest(RequestModel):
    provider: Provider
    account_id: UUID | None = None
    force: bool = False


@router.get("/search")
async def search_instruments(
    _user: CurrentUser,
    instruments: Instruments,
    q: Annotated[
        str | None,
        Query(max_length=100, description="Every term must appear in the symbol, name or a provider symbol"),
    ] = None,
    exchange: Exchange | None = None,
    segment: Segment | None = None,
    instrument_type: InstrumentType | None = None,
    underlying: Annotated[str | None, Query(max_length=80)] = None,
    expiry: date | None = None,
    strike: Decimal | None = None,
    option_type: OptionType | None = None,
    provider: Annotated[Provider | None, Query(description="Only instruments this provider lists")] = None,
    include_inactive: bool = False,
    limit: Annotated[int, Query(ge=1, le=SEARCH_LIMIT_MAX)] = 50,
    offset: Annotated[int, Query(ge=0, le=100_000)] = 0,
) -> InstrumentPage:
    query = checked(
        InstrumentQuery,
        text=q,
        exchange=exchange,
        segment=segment,
        instrument_type=instrument_type,
        underlying=underlying,
        expiry=expiry,
        strike=strike,
        option_type=option_type,
        provider=provider,
        active=None if include_inactive else True,
        limit=limit,
        offset=offset,
    )
    return await instruments.search(query)


@router.post("/refresh")
async def refresh_instruments(
    body: RefreshRequest, user: CurrentUser, instruments: Instruments, ip: ClientIp
) -> RefreshReport:
    """Download the provider's instrument list and update the master. This calls the provider."""
    return await instruments.refresh(
        body.provider, account_id=body.account_id, force=body.force, actor=user.username, client_ip=ip
    )


# Declared last: the path converter would otherwise also match /search.
@router.get("/{ref:path}")
async def get_instrument(
    ref: Annotated[str, Path(min_length=1, max_length=120, description="Instrument id or canonical key")],
    _user: CurrentUser,
    instruments: Instruments,
) -> InstrumentDetail:
    return await instruments.get(ref)
