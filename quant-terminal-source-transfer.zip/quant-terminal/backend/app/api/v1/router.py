"""Aggregates every /api/v1 endpoint module."""

from __future__ import annotations

from fastapi import APIRouter

from app.api.v1.endpoints import (
    accounts,
    auth,
    backtests,
    candles,
    datasets,
    instruments,
    markets,
    providers,
    quotes,
    risk,
    signals,
    strategies,
    system,
    watchlists,
    workspaces,
)

api_router = APIRouter()
for module in (
    auth,
    providers,
    accounts,
    instruments,
    markets,
    workspaces,
    watchlists,
    quotes,
    candles,
    strategies,
    signals,
    risk,
    datasets,
    backtests,
    system,
):
    api_router.include_router(module.router)
