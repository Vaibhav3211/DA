"""Shared API request and response shapes."""

from __future__ import annotations

from typing import Annotated, Any

from pydantic import BaseModel, ConfigDict, Field, SecretStr, StringConstraints, ValidationError

from app.core.errors import ValidationFailedError, sanitize_validation_errors

# A credential or token in a request body; never logged and never echoed in errors.
Secret = Annotated[SecretStr, Field(min_length=1, max_length=4096)]
# An instrument id or canonical key (for example NSE:EQ:RELIANCE).
InstrumentRef = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=120)]
# A workspace id or slug.
WorkspaceRef = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=80)]


class ApiModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class RequestModel(BaseModel):
    """A request body: unknown fields are rejected rather than silently ignored."""

    model_config = ConfigDict(extra="forbid")


def checked[M: BaseModel](model: type[M], /, **values: Any) -> M:
    """Build ``model`` from request values; invalid values are a 422, not a server error."""
    try:
        return model(**values)
    except ValidationError as exc:
        raise ValidationFailedError(
            "Request validation failed", details=sanitize_validation_errors(list(exc.errors()))
        ) from None


class Page[T](BaseModel):
    items: list[T]
    total: int
    limit: int
    offset: int


class OkResponse(BaseModel):
    ok: bool = True
