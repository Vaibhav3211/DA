"""WebSocket endpoints: ``/ws/v1/market``, ``/ws/v1/signals`` and ``/ws/v1/system``.

A handshake from an origin not allowed is refused before it is accepted. Others are accepted so that
an unauthenticated client can be told so with close code 4401 (a refused handshake reaches browsers as
1006). The session cookie is checked again every heartbeat interval, so signing out ends connections.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from typing import Any, Final, cast

import structlog
from fastapi import APIRouter
from redis.exceptions import RedisError
from sqlalchemy.exc import SQLAlchemyError
from starlette.websockets import WebSocket, WebSocketDisconnect

from app.api.deps import get_container, resolve_session
from app.api.middleware import websocket_origin_allowed
from app.api.ws.hub import WsClient, WsHub
from app.api.ws.protocol import (
    CLOSE_INTERNAL_ERROR,
    CLOSE_NORMAL,
    CLOSE_POLICY_VIOLATION,
    CLOSE_UNAUTHENTICATED,
    CLOSE_UNSUPPORTED_DATA,
    MARKET_CHANNELS,
    SIGNAL_CHANNELS,
    SYSTEM_CHANNELS,
    Channel,
    ClientMessage,
    Heartbeat,
    ProtocolError,
    Unsubscribe,
    error_event,
    parse_client_message,
    request_id_of,
    welcome_event,
)
from app.core.errors import AppError
from app.core.logging import RateLimitedLogger, get_logger
from app.providers.base import describe_error

log = get_logger(__name__)
_limited = RateLimitedLogger(log, 30.0)

MAX_CONNECTIONS_PER_USER: Final = 10
RATE_WINDOW_SECONDS: Final = 10.0
MAX_MESSAGES_PER_WINDOW: Final = 100
MAX_INVALID_MESSAGES: Final = 20
CLOSE_TIMEOUT_SECONDS: Final = 5.0

router = APIRouter()


@router.websocket("/ws/v1/market")
async def market_socket(websocket: WebSocket) -> None:
    """Quotes, forming and closed candles, and feed status."""
    await _serve(websocket, MARKET_CHANNELS)


@router.websocket("/ws/v1/signals")
async def signals_socket(websocket: WebSocket) -> None:
    """Signal lifecycle updates."""
    await _serve(websocket, SIGNAL_CHANNELS)


@router.websocket("/ws/v1/system")
async def system_socket(websocket: WebSocket) -> None:
    """System health."""
    await _serve(websocket, SYSTEM_CHANNELS)


async def _serve(websocket: WebSocket, channels: frozenset[Channel]) -> None:
    container = get_container(websocket)
    hub = cast(WsHub, websocket.app.state.ws_hub)
    settings = container.settings
    if not websocket_origin_allowed(websocket.scope, settings.allowed_origins):
        log.warning("ws_origin_rejected", origin=(websocket.headers.get("origin") or "")[:200])
        await _close(websocket, CLOSE_POLICY_VIOLATION, "origin_not_allowed")
        return
    await websocket.accept()
    try:
        user = await resolve_session(websocket, container)
    except (RedisError, OSError) as exc:
        _limited.warning("ws_session", "ws_session_unavailable", error=describe_error(exc))
        await _close(websocket, CLOSE_INTERNAL_ERROR, "unavailable")
        return
    if user is None:
        await _close(websocket, CLOSE_UNAUTHENTICATED, "unauthenticated")
        return
    if hub.connections(user.user_id) >= MAX_CONNECTIONS_PER_USER:
        await _close(websocket, CLOSE_POLICY_VIOLATION, "too_many_connections")
        return
    client = hub.client(websocket, user, channels)
    structlog.contextvars.bind_contextvars(user=user.username, connection_id=client.id)
    log.info("ws_connected", path=websocket.url.path)
    try:
        await hub.add(client)
        client.reply(welcome_event(client.id, channels, settings, hub.now()))
        await _run(websocket, hub, client)
    except (RedisError, OSError) as exc:
        _limited.warning("ws_hub", "ws_unavailable", error=describe_error(exc))
        client.close(CLOSE_INTERNAL_ERROR, "unavailable")
    finally:
        hub.remove(client)
    if not client.disconnected:
        await _close(websocket, client.close_code or CLOSE_NORMAL, client.close_reason)
    log.info("ws_disconnected", code=client.close_code, reason=client.close_reason or None)


async def _run(websocket: WebSocket, hub: WsHub, client: WsClient) -> None:
    """Serve the connection until it is closed by either side."""
    tasks: list[asyncio.Task[Any]] = [
        asyncio.create_task(client.send_loop()),
        asyncio.create_task(_receive(websocket, hub, client)),
        asyncio.create_task(_keep_alive(websocket, hub, client)),
        asyncio.create_task(client.closing.wait()),
    ]
    done: set[asyncio.Task[Any]] = set()
    try:
        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    for task in done:
        error = None if task.cancelled() else task.exception()
        if isinstance(error, WebSocketDisconnect):
            client.disconnected = True
        elif error is not None:
            log.error("ws_connection_failed", error=describe_error(error), exc_info=error)
            client.close(CLOSE_INTERNAL_ERROR, "internal_error")


async def _receive(websocket: WebSocket, hub: WsHub, client: WsClient) -> None:
    window_started = time.monotonic()
    received = 0
    invalid = 0
    while True:
        message = await websocket.receive()
        if message["type"] == "websocket.disconnect":
            client.disconnected = True
            return
        now = time.monotonic()
        if now - window_started >= RATE_WINDOW_SECONDS:
            window_started, received = now, 0
        received += 1
        if received > MAX_MESSAGES_PER_WINDOW:
            client.close(CLOSE_POLICY_VIOLATION, "rate_limited")
            return
        text = message.get("text")
        if not isinstance(text, str):
            client.close(CLOSE_UNSUPPORTED_DATA, "text_frames_only")
            return
        try:
            parsed = parse_client_message(text)
        except ProtocolError as exc:
            invalid += 1
            if invalid >= MAX_INVALID_MESSAGES:
                client.close(CLOSE_POLICY_VIOLATION, "too_many_invalid_messages")
                return
            client.reply(error_event(exc.code, exc.message, request_id_of(text), exc.details))
            continue
        await _handle(hub, client, parsed)


async def _handle(hub: WsHub, client: WsClient, message: ClientMessage) -> None:
    """Answer one valid message. A request that fails is answered with an error; the connection stays."""
    try:
        if isinstance(message, Heartbeat):
            client.reply({"type": "heartbeat", "server_time": hub.now(), "request_id": message.request_id})
            return
        if message.channel not in client.channels:
            raise ProtocolError("channel_not_available", f"{message.channel} is not served on this endpoint")
        if isinstance(message, Unsubscribe):
            client.unsubscribe(message.channel)
            reply = {"type": "unsubscribed", "channel": message.channel, "request_id": message.request_id}
            client.reply(reply, message.channel)
            return
        await hub.subscribe(client, message)
    except (ProtocolError, AppError) as exc:
        client.reply(error_event(exc.code, exc.message, message.request_id, exc.details))
    except (RedisError, OSError, SQLAlchemyError) as exc:
        _limited.warning("ws_request", "ws_request_failed", error=describe_error(exc))
        message_text = "Live data is unavailable right now; try again shortly"
        client.reply(error_event("unavailable", message_text, message.request_id))


async def _keep_alive(websocket: WebSocket, hub: WsHub, client: WsClient) -> None:
    """Heartbeat the client, and close the connection once its session has ended."""
    container = get_container(websocket)
    interval = container.settings.ws_heartbeat_interval_seconds
    while True:
        await asyncio.sleep(interval)
        try:
            user = await resolve_session(websocket, container)
        except (RedisError, OSError) as exc:
            _limited.warning("ws_session", "ws_session_check_failed", error=describe_error(exc))
            continue
        if user is None or user.user_id != client.user.user_id:
            client.close(CLOSE_UNAUTHENTICATED, "session_expired")
            return
        client.reply({"type": "heartbeat", "server_time": hub.now(), "request_id": None})


async def _close(websocket: WebSocket, code: int, reason: str = "") -> None:
    with contextlib.suppress(WebSocketDisconnect, RuntimeError, OSError, TimeoutError):
        async with asyncio.timeout(CLOSE_TIMEOUT_SECONDS):
            await websocket.close(code, reason)
