"""Server-side fan-out of live data to this API process's WebSocket clients.

The hub tails the closed-candle, feed and signal streams, and polls latest-value keys (quotes, forming
candles, feed state) at most ``WS_MAX_UPDATES_PER_SECOND`` times a second. Each client is handed only
what its subscriptions ask for; nothing is broadcast per tick:

* latest values (quotes, forming candles, feed and system status) are conflated per client: an item
  is queued only when it changed, and one replaced before it was sent is dropped;
* events (closed candles, feed state changes, signal updates) and replies are queued in order, at
  most ``WS_CLIENT_QUEUE_SIZE`` of them.

A client whose queue overflows, or that lets more than ``WS_SLOW_CLIENT_DROP_LIMIT`` updates be
replaced before taking them, is closed with 1013. Nothing missed is replayed: clients reconnect,
resubscribe and reload REST snapshots.
"""

from __future__ import annotations

import asyncio
import contextlib
import functools
from collections import deque
from collections.abc import Awaitable, Callable, Hashable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Final
from uuid import UUID, uuid4

from pydantic import BaseModel, ValidationError
from redis.exceptions import RedisError
from starlette.websockets import WebSocket

from app.api.ws.protocol import (
    CLOSE_GOING_AWAY,
    CLOSE_TRY_AGAIN_LATER,
    Channel,
    ProtocolError,
    Subscribe,
    check_subscription,
    encode_event,
    items_frame,
)
from app.container import Container
from app.core.clock import utc_now
from app.core.logging import RateLimitedLogger, get_logger
from app.domain.enums import CandleInterval, DataStatus, Provider
from app.domain.events import FeedStateChange, SignalUpdate
from app.domain.models import Candle, QuoteSnapshot, StreamHealth
from app.domain.models.signal import Signal
from app.observability.health import SystemHealthService
from app.observability.metrics import (
    REDIS_ERRORS,
    WS_CLIENTS,
    WS_MESSAGES_DROPPED,
    WS_MESSAGES_SENT,
    WS_SLOW_CLIENT_DISCONNECTS,
)
from app.providers.base import describe_error
from app.services.auth_service import SessionUser
from app.services.candles import forming_view
from app.services.quotes import (
    MAX_QUOTE_INSTRUMENTS,
    FeedStatuses,
    QuoteSelection,
    QuoteService,
    QuoteView,
    quote_status,
    read_feed_streams,
)
from app.services.workspaces import find_workspace
from app.streaming.redis_bus import Keys, Streams

log = get_logger(__name__)
_limited = RateLimitedLogger(log, 30.0)

type Pair = tuple[Provider, UUID]

MAX_PAIRS: Final = MAX_QUOTE_INSTRUMENTS * len(Provider)  # (provider, instrument) pairs per subscription
SYSTEM_STATUS_INTERVAL_SECONDS: Final = 5.0
STREAM_READ_COUNT: Final = 100
STREAM_BLOCK_MS: Final = 1000
SHUTDOWN_WAIT_SECONDS: Final = 2.0
_RETRY_SECONDS: Final = 1.0
_STATUS: Final = "status"  # the one item of the feed and system channels
_CONTROL: Final = "control"  # metric label of replies that belong to no channel


class Item:
    """A payload for any number of clients: built when first needed, then encoded once per variant."""

    __slots__ = ("_build", "_json", "_model")

    def __init__(self, build: Callable[[], BaseModel]) -> None:
        self._build = build
        self._model: BaseModel | None = None
        self._json: dict[bool, str] = {}

    @classmethod
    def of(cls, model: BaseModel) -> Item:
        item = cls(lambda: model)
        item._model = model
        return item

    def json(self, *, depth: bool = True) -> str:
        """The payload's JSON; ``depth=False`` leaves a quote's ``market_depth`` out."""
        text = self._json.get(depth)
        if text is None:
            if self._model is None:
                self._model = self._build()
            text = self._model.model_dump_json(exclude=None if depth else {"market_depth"})
            self._json[depth] = text
        return text


@dataclass(frozen=True, slots=True)
class Update:
    """An item's latest value; ``mark`` changes whenever what a client would be shown changes."""

    mark: object
    item: Item
    bucket_start: datetime | None = None  # forming candles: never sent once their bucket has closed


@dataclass(frozen=True, slots=True)
class Subscription:
    channel: Channel
    generation: int  # data read before the subscription was made is never offered to it
    pairs: tuple[Pair, ...] = ()  # quotes and candles, in the order they are sent
    members: frozenset[Pair] = frozenset()
    interval: CandleInterval | None = None
    provider: Provider | None = None
    depth: bool = False
    workspace_id: UUID | None = None
    workspace_slug: str | None = None
    instrument_ids: tuple[UUID, ...] = ()  # as asked for
    instruments: frozenset[UUID] = frozenset()  # signals: only these instruments' (all when empty)

    def wants_candle(self, candle: Candle) -> bool:
        return candle.interval is self.interval and (candle.provider, candle.instrument_id) in self.members

    def wants_provider(self, provider: Provider) -> bool:
        return self.provider is None or provider is self.provider

    def wants_signal(self, signal: Signal) -> bool:
        if self.workspace_id is not None and signal.workspace_id != self.workspace_id:
            return False
        return not self.instruments or signal.instrument_id in self.instruments


def subscribed_event(subscription: Subscription, request_id: str | None) -> dict[str, Any]:
    workspace = None
    if subscription.workspace_id is not None:
        workspace = {"id": subscription.workspace_id, "slug": subscription.workspace_slug}
    return {
        "type": "subscribed",
        "channel": subscription.channel,
        "request_id": request_id,
        "workspace": workspace,
        "instrument_ids": subscription.instrument_ids,
        "provider": subscription.provider,
        "interval": subscription.interval,
        "depth": subscription.depth,
    }


def _quote_mark(quote: QuoteSnapshot, stored: DataStatus, status: DataStatus, feed: DataStatus) -> object:
    return (
        quote.received_at,
        quote.processed_at,
        quote.sequence_number,
        quote.depth_received_at,
        stored,
        status,
        feed,
    )


def quote_update(
    quote: QuoteSnapshot, feeds: FeedStatuses, now: datetime, *, stale_after_seconds: float
) -> Update:
    status, feed, _ = quote_status(quote, feeds, now, stale_after_seconds=stale_after_seconds)
    build = functools.partial(QuoteView.build, quote, feeds, now, stale_after_seconds=stale_after_seconds)
    return Update(_quote_mark(quote, quote.data_status, status, feed), Item(build))


def view_mark(view: QuoteView) -> object:
    """The mark of a quote shown in a snapshot, equal to :func:`quote_update`'s for the same state."""
    return _quote_mark(view, view.stored_status, view.data_status, view.feed_status)


def forming_update(
    candle: Candle, feeds: FeedStatuses, now: datetime, *, stale_after_seconds: float
) -> Update:
    view = forming_view(candle, feeds, now, stale_after_seconds=stale_after_seconds)
    mark = (
        candle.bucket_start,
        candle.revision,
        candle.event_count,
        candle.last_event_at,
        candle.data_status,
        view.data_status,
    )
    return Update(mark, Item.of(view), bucket_start=candle.bucket_start)


def feed_status(
    streams: Sequence[StreamHealth], provider: Provider | None, now: datetime
) -> tuple[object, str]:
    """The ``feed.status`` frame for one provider (or all), and the mark that decides resending it."""
    shown = [stream for stream in streams if provider is None or stream.provider is provider]
    feeds = FeedStatuses(shown)
    providers = [provider] if provider is not None else list(Provider)
    mark = tuple((s.stream_id, s.updated_at, s.state, s.data_status) for s in shown)
    frame = encode_event(
        {
            "type": "feed.status",
            "streams": shown,
            "providers": {each.value: feeds.provider_status(each) for each in providers},
            "generated_at": now,
        }
    )
    return mark, frame


def _valid[M: BaseModel](model: type[M], raw: Any) -> M | None:
    if raw is None:
        return None
    try:
        return model.model_validate(raw)
    except ValidationError:
        _limited.warning("ws_value_invalid", "ws_value_invalid", model=model.__name__)
        return None


class _ModelCache[M: BaseModel]:
    """Models of latest-value keys, validated again only when the fields that version them change."""

    def __init__(self, model: type[M], version: tuple[str, ...]) -> None:
        self._model = model
        self._version = version
        self._entries: dict[str, tuple[tuple[object, ...], M]] = {}

    def load(self, keys: Sequence[str], values: Sequence[Any]) -> dict[str, M]:
        """The valid models among ``values`` (read from ``keys``); keys not read are forgotten."""
        entries: dict[str, tuple[tuple[object, ...], M]] = {}
        for key, raw in zip(keys, values, strict=True):
            if not isinstance(raw, dict):
                continue
            version = tuple(raw.get(name) for name in self._version)
            entry = self._entries.get(key)
            if entry is None or entry[0] != version:
                model = _valid(self._model, raw)
                if model is None:
                    continue
                entry = (version, model)
            entries[key] = entry
        self._entries = entries
        return {key: model for key, (_, model) in entries.items()}

    def clear(self) -> None:
        self._entries = {}


# ---- clients -----------------------------------------------------------------------------------


class WsClient:
    """One connection: its subscriptions, and what waits to be sent to it."""

    def __init__(
        self,
        websocket: WebSocket,
        user: SessionUser,
        channels: frozenset[Channel],
        *,
        queue_size: int,
        drop_limit: int,
    ) -> None:
        self.id = uuid4().hex
        self.websocket = websocket
        self.user = user
        self.channels = channels
        self.subscriptions: dict[Channel, Subscription] = {}
        self.close_code: int | None = None
        self.close_reason = ""
        self.closing = asyncio.Event()
        self.disconnected = False
        self._queue_size = queue_size
        self._drop_limit = drop_limit
        self._frames: deque[tuple[str, str]] = deque()  # (metric label, frame): in order, never dropped
        self._updates: dict[Channel, dict[Pair, Update]] = {}  # quotes and forming candles not yet sent
        self._statuses: dict[Channel, str] = {}  # feed and system status frames not yet sent
        self._marks: dict[Channel, dict[Hashable, object]] = {}  # the version last queued, per item
        self._closed_through: dict[Pair, datetime] = {}  # newest closed candle bucket queued, per pair
        self._replaced = 0  # updates replaced before this client took them, since it last took some
        self._ready = asyncio.Event()

    def close(self, code: int, reason: str) -> None:
        """Ask for the connection to be closed; the first code given is the one sent."""
        if self.close_code is None:
            self.close_code, self.close_reason = code, reason
        self.closing.set()

    def send(self, frame: str, label: str = _CONTROL) -> None:
        """Queue a frame that must not be lost. A client that lets the queue fill up is too slow."""
        if self.closing.is_set():
            return
        if len(self._frames) >= self._queue_size:
            WS_MESSAGES_DROPPED.labels(reason="queue_full").inc()
            self._too_slow()
            return
        self._frames.append((label, frame))
        self._ready.set()

    def reply(self, event: Mapping[str, Any], label: str = _CONTROL) -> None:
        self.send(encode_event(event), label)

    def subscribe(self, subscription: Subscription, marks: Mapping[Hashable, object]) -> None:
        """Make ``subscription`` the channel's; ``marks`` are the versions its snapshot showed."""
        self.unsubscribe(subscription.channel)
        self.subscriptions[subscription.channel] = subscription
        self._marks[subscription.channel] = dict(marks)

    def unsubscribe(self, channel: Channel) -> None:
        self.subscriptions.pop(channel, None)
        self._updates.pop(channel, None)
        self._statuses.pop(channel, None)
        self._marks.pop(channel, None)
        if channel is Channel.CANDLES:
            self._closed_through.clear()

    def offer_updates(self, channel: Channel, latest: Mapping[Pair, Update], generation: int) -> None:
        """Queue the subscribed items whose version changed since they were last queued."""
        subscription = self._accepting(channel, generation)
        if subscription is None:
            return
        marks = self._marks.setdefault(channel, {})
        pending = self._updates.setdefault(channel, {})
        replaced = 0
        for pair in subscription.pairs:
            update = latest.get(pair)
            if update is None or marks.get(pair) == update.mark:
                continue
            if update.bucket_start is not None:
                closed = self._closed_through.get(pair)
                if closed is not None and update.bucket_start <= closed:
                    continue
            marks[pair] = update.mark
            replaced += pair in pending
            pending[pair] = update
        if pending:
            self._ready.set()
        if replaced:
            self._count_replaced(replaced)

    def offer_status(self, channel: Channel, mark: object, frame: str, generation: int) -> None:
        """Queue the channel's status if it changed, replacing one not yet sent."""
        if self._accepting(channel, generation) is None:
            return
        marks = self._marks.setdefault(channel, {})
        if marks.get(_STATUS) == mark:
            return
        marks[_STATUS] = mark
        if channel in self._statuses:
            self._count_replaced(1)
        self._statuses[channel] = frame
        self._ready.set()

    def send_closed_candle(self, candle: Candle, frame: str) -> None:
        """Queue a closed candle. Its bucket's forming candle is never sent after it."""
        pair = (candle.provider, candle.instrument_id)
        closed = self._closed_through.get(pair)
        if closed is None or candle.bucket_start > closed:
            self._closed_through[pair] = candle.bucket_start
        pending = self._updates.get(Channel.CANDLES, {})
        waiting = pending.get(pair)
        if (
            waiting is not None
            and waiting.bucket_start is not None
            and waiting.bucket_start <= candle.bucket_start
        ):
            del pending[pair]
        self.send(frame, Channel.CANDLES)

    async def send_loop(self) -> None:
        """Send queued frames, then the latest updates, until cancelled."""
        while True:
            await self._ready.wait()
            self._ready.clear()
            while self._frames:
                label, frame = self._frames.popleft()
                await self.websocket.send_text(frame)
                WS_MESSAGES_SENT.labels(channel=label).inc()
            for label, frame in self._take_updates():
                await self.websocket.send_text(frame)
                WS_MESSAGES_SENT.labels(channel=label).inc()

    def _take_updates(self) -> list[tuple[str, str]]:
        frames: list[tuple[str, str]] = []
        quotes = self._updates.pop(Channel.QUOTES, None)
        if quotes:
            subscription = self.subscriptions.get(Channel.QUOTES)
            depth = subscription is not None and subscription.depth
            items = [update.item.json(depth=depth) for update in quotes.values()]
            frames.append((Channel.QUOTES, items_frame("quote.update", items)))
        candles = self._updates.pop(Channel.CANDLES, None)
        if candles:
            items = [update.item.json() for update in candles.values()]
            frames.append((Channel.CANDLES, items_frame("candle.update", items)))
        for channel in (Channel.FEED, Channel.SYSTEM):
            frame = self._statuses.pop(channel, None)
            if frame is not None:
                frames.append((channel, frame))
        self._replaced = 0
        return frames

    def _accepting(self, channel: Channel, generation: int) -> Subscription | None:
        subscription = self.subscriptions.get(channel)
        if subscription is None or subscription.generation > generation or self.closing.is_set():
            return None
        return subscription

    def _count_replaced(self, count: int) -> None:
        WS_MESSAGES_DROPPED.labels(reason="coalesced").inc(count)
        self._replaced += count
        if self._replaced > self._drop_limit:
            self._too_slow()

    def _too_slow(self) -> None:
        if self.closing.is_set():
            return
        WS_SLOW_CLIENT_DISCONNECTS.inc()
        log.warning(
            "ws_slow_client", connection_id=self.id, queued=len(self._frames), replaced=self._replaced
        )
        self.close(CLOSE_TRY_AGAIN_LATER, "slow_client")


# ---- hub ---------------------------------------------------------------------------------------


class WsHub:
    """Hands live data to this API process's WebSocket clients, as their subscriptions ask."""

    def __init__(self, container: Container, *, clock: Callable[[], datetime] = utc_now) -> None:
        self._container = container
        self._settings = container.settings
        self._bus = container.bus
        self._clock = clock
        self._clients: dict[str, WsClient] = {}
        self._empty = asyncio.Event()  # set while no client is registered
        self._empty.set()
        self._tasks: list[asyncio.Task[None]] = []
        self._start_lock = asyncio.Lock()
        self._stopped = False
        self._offsets: dict[str, str] = {}
        self._generation = 0
        self._feeds = FeedStatuses(())
        self._feeds_due = 0.0
        self._quotes = _ModelCache(
            QuoteSnapshot,
            ("received_at", "processed_at", "sequence_number", "data_status", "depth_received_at"),
        )
        self._candles = _ModelCache(
            Candle, ("bucket_start", "revision", "event_count", "last_event_at", "data_status", "is_closed")
        )

    @property
    def client_count(self) -> int:
        return len(self._clients)

    def now(self) -> datetime:
        return self._clock()

    def connections(self, user_id: UUID) -> int:
        return sum(1 for client in self._clients.values() if client.user.user_id == user_id)

    def client(self, websocket: WebSocket, user: SessionUser, channels: frozenset[Channel]) -> WsClient:
        return WsClient(
            websocket,
            user,
            channels,
            queue_size=self._settings.ws_client_queue_size,
            drop_limit=self._settings.ws_slow_client_drop_limit,
        )

    async def add(self, client: WsClient) -> None:
        """Register a connected client; the first one starts the hub's tasks."""
        if self._stopped:
            client.close(CLOSE_GOING_AWAY, "server_shutdown")
            return
        self._clients[client.id] = client
        self._empty.clear()
        WS_CLIENTS.set(len(self._clients))
        async with self._start_lock:
            if not self._tasks:
                await self._start()

    def remove(self, client: WsClient) -> None:
        if self._clients.pop(client.id, None) is not None:
            WS_CLIENTS.set(len(self._clients))
        if not self._clients:
            self._empty.set()

    async def stop(self) -> None:
        """Close every client with 1001, give them a moment to go, and stop the hub's tasks."""
        self._stopped = True
        for client in list(self._clients.values()):
            client.close(CLOSE_GOING_AWAY, "server_shutdown")
        with contextlib.suppress(TimeoutError):
            async with asyncio.timeout(SHUTDOWN_WAIT_SECONDS):
                await self._empty.wait()
        tasks, self._tasks = self._tasks, []
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    async def _start(self) -> None:
        # Events are tailed from now on: those published before the first client came are not sent.
        streams = (Streams.CANDLES, Streams.FEED, Streams.SIGNALS)
        self._offsets = {stream: await self._bus.last_id(stream) for stream in streams}
        poll_every = 1.0 / self._settings.ws_max_updates_per_second
        self._tasks = [
            asyncio.create_task(self._repeat("ws_streams", self._read_streams, 0.0), name="ws-hub-streams"),
            asyncio.create_task(self._repeat("ws_poll", self._poll, poll_every), name="ws-hub-poll"),
            asyncio.create_task(
                self._repeat("ws_system", self._report_system, SYSTEM_STATUS_INTERVAL_SECONDS),
                name="ws-hub-system",
            ),
        ]

    async def _repeat(self, name: str, step: Callable[[], Awaitable[None]], pause: float) -> None:
        """Run ``step`` until cancelled; a failure is logged and retried, never fatal."""
        while True:
            try:
                await step()
            except (RedisError, OSError) as exc:
                REDIS_ERRORS.labels(operation=name).inc()
                _limited.warning(name, "ws_hub_redis_error", task=name, error=describe_error(exc))
                await asyncio.sleep(_RETRY_SECONDS)
            except Exception as exc:
                _limited.error(name, "ws_hub_task_failed", task=name, error=describe_error(exc), exc_info=exc)
                await asyncio.sleep(_RETRY_SECONDS)
            if pause:
                await asyncio.sleep(pause)

    def _subscribed(self, channel: Channel) -> list[tuple[WsClient, Subscription]]:
        found: list[tuple[WsClient, Subscription]] = []
        for client in self._clients.values():
            subscription = client.subscriptions.get(channel)
            if subscription is not None and not client.closing.is_set():
                found.append((client, subscription))
        return found

    # ---- events ----------------------------------------------------------------------------------

    async def _read_streams(self) -> None:
        messages = await self._bus.read(self._offsets, count=STREAM_READ_COUNT, block_ms=STREAM_BLOCK_MS)
        for message in messages:
            self._offsets[message.stream] = message.message_id
            if message.payload is None:
                continue
            try:
                if message.stream == Streams.CANDLES:
                    self._dispatch_candle(message.payload)
                elif message.stream == Streams.FEED:
                    self._dispatch_feed(message.payload)
                elif message.stream == Streams.SIGNALS:
                    self._dispatch_signal(message.payload)
            except ValidationError:
                _limited.warning(f"invalid:{message.stream}", "ws_event_invalid", stream=message.stream)

    def _dispatch_candle(self, payload: Any) -> None:
        subscribed = self._subscribed(Channel.CANDLES)
        if not subscribed:
            return
        candle = Candle.model_validate(payload)
        frame: str | None = None
        for client, subscription in subscribed:
            if subscription.wants_candle(candle):
                frame = frame or encode_event({"type": "candle.closed", "candle": candle})
                client.send_closed_candle(candle, frame)

    def _dispatch_feed(self, payload: Any) -> None:
        change = FeedStateChange.model_validate(payload)
        self._feeds_due = 0.0  # refresh feed and quote statuses on the next poll
        frame: str | None = None
        for client, subscription in self._subscribed(Channel.FEED):
            if subscription.wants_provider(change.provider):
                frame = frame or encode_event({"type": "feed.state_change", **dict(change)})
                client.send(frame, Channel.FEED)

    def _dispatch_signal(self, payload: Any) -> None:
        subscribed = self._subscribed(Channel.SIGNALS)
        if not subscribed:
            return
        update = SignalUpdate.model_validate(payload)
        frame: str | None = None
        for client, subscription in subscribed:
            if subscription.wants_signal(update.signal):
                frame = frame or encode_event(
                    {
                        "type": "signal.update",
                        "event_type": update.event_type,
                        "at": update.at,
                        "signal": update.signal,
                    }
                )
                client.send(frame, Channel.SIGNALS)

    # ---- latest values ---------------------------------------------------------------------------

    async def _poll(self) -> None:
        if not self._clients:
            return
        # Data read from here on is at least as new as any snapshot of a subscription made so far.
        generation = self._generation
        clock = asyncio.get_running_loop().time()
        if clock >= self._feeds_due:
            self._feeds_due = clock + self._settings.feed_status_publish_interval_seconds
            await self._refresh_feeds(generation)
        now = self._clock()
        await self._poll_quotes(now, generation)
        await self._poll_candles(now, generation)

    async def _refresh_feeds(self, generation: int) -> None:
        streams = await read_feed_streams(self._bus)
        self._feeds = FeedStatuses(streams)
        now = self._clock()
        statuses: dict[Provider | None, tuple[object, str]] = {}
        for client, subscription in self._subscribed(Channel.FEED):
            status = statuses.get(subscription.provider)
            if status is None:
                status = statuses[subscription.provider] = feed_status(streams, subscription.provider, now)
            mark, frame = status
            client.offer_status(Channel.FEED, mark, frame, generation)

    async def _poll_quotes(self, now: datetime, generation: int) -> None:
        subscribed = self._subscribed(Channel.QUOTES)
        if not subscribed:
            self._quotes.clear()
            return
        pairs = list(dict.fromkeys(pair for _, subscription in subscribed for pair in subscription.pairs))
        keys = [Keys.quote(provider, instrument_id) for provider, instrument_id in pairs]
        quotes = self._quotes.load(keys, await self._bus.mget_json(keys))
        feeds, stale = self._feeds, self._settings.data_stale_after_seconds
        latest: dict[Pair, Update] = {}
        for pair, key in zip(pairs, keys, strict=True):
            quote = quotes.get(key)
            if quote is not None:
                latest[pair] = quote_update(quote, feeds, now, stale_after_seconds=stale)
        for client in list(self._clients.values()):
            client.offer_updates(Channel.QUOTES, latest, generation)

    async def _poll_candles(self, now: datetime, generation: int) -> None:
        subscribed = self._subscribed(Channel.CANDLES)
        if not subscribed:
            self._candles.clear()
            return
        wanted: dict[tuple[Pair, CandleInterval], str] = {}
        for _, subscription in subscribed:
            if subscription.interval is not None:
                for provider, instrument_id in subscription.pairs:
                    key = Keys.partial_candle(provider, instrument_id, subscription.interval)
                    wanted[((provider, instrument_id), subscription.interval)] = key
        keys = list(wanted.values())
        candles = self._candles.load(keys, await self._bus.mget_json(keys))
        feeds, stale = self._feeds, self._settings.data_stale_after_seconds
        latest: dict[CandleInterval, dict[Pair, Update]] = {}
        for (pair, interval), key in wanted.items():
            candle = candles.get(key)
            if candle is not None and not candle.is_closed:
                update = forming_update(candle, feeds, now, stale_after_seconds=stale)
                latest.setdefault(interval, {})[pair] = update
        for client in list(self._clients.values()):
            current = client.subscriptions.get(Channel.CANDLES)
            if current is not None and current.interval is not None:
                client.offer_updates(Channel.CANDLES, latest.get(current.interval, {}), generation)

    async def _report_system(self) -> None:
        if not self._subscribed(Channel.SYSTEM):
            return
        generation = self._generation
        report = await SystemHealthService(self._container).report()
        frame = encode_event({"type": "system.status", "health": report})
        for client in list(self._clients.values()):
            client.offer_status(Channel.SYSTEM, report.generated_at, frame, generation)

    # ---- subscriptions ---------------------------------------------------------------------------

    async def subscribe(self, client: WsClient, message: Subscribe) -> None:
        """Replace the client's subscription to the channel, then queue an ack and a snapshot.

        Signals have no snapshot here: ``GET /signals`` is the snapshot, and updates follow the ack.
        """
        check_subscription(message)
        match message.channel:
            case Channel.QUOTES:
                await self._subscribe_quotes(client, message)
            case Channel.CANDLES:
                await self._subscribe_candles(client, message)
            case Channel.FEED:
                streams = await read_feed_streams(self._bus)
                mark, frame = feed_status(streams, message.provider, self._clock())
                self._register(client, message, {_STATUS: mark})
                client.send(frame, Channel.FEED)
            case Channel.SIGNALS:
                await self._subscribe_signals(client, message)
            case Channel.SYSTEM:
                report = await SystemHealthService(self._container).report()
                self._register(client, message, {_STATUS: report.generated_at})
                client.send(encode_event({"type": "system.status", "health": report}), Channel.SYSTEM)

    async def _subscribe_quotes(self, client: WsClient, message: Subscribe) -> None:
        service = QuoteService.from_container(self._container, clock=self._clock)
        selection = await self._select(service, message)
        quotes = await service.read(selection)
        marks: dict[Hashable, object] = {
            (view.provider, view.instrument_id): view_mark(view) for view in quotes.items
        }
        self._register(client, message, marks, selection=selection)
        items = [Item.of(view).json(depth=message.depth) for view in quotes.items]
        frame = items_frame(
            "quote.snapshot",
            items,
            request_id=message.request_id,
            missing=quotes.missing,
            generated_at=quotes.generated_at,
        )
        client.send(frame, Channel.QUOTES)

    async def _subscribe_candles(self, client: WsClient, message: Subscribe) -> None:
        interval = message.interval
        if interval is None:  # check_subscription has made sure there is one
            raise ProtocolError("interval_required", "Candle subscriptions need an interval")
        selection = await self._select(QuoteService.from_container(self._container), message)
        keys = [Keys.partial_candle(provider, iid, interval) for provider, iid in selection.pairs]
        values = await self._bus.mget_json(keys)
        feeds = FeedStatuses(await read_feed_streams(self._bus))
        now = self._clock()
        forming: dict[Pair, Update] = {}
        for pair, raw in zip(selection.pairs, values, strict=True):
            candle = _valid(Candle, raw)
            if candle is not None and not candle.is_closed:
                stale = self._settings.data_stale_after_seconds
                forming[pair] = forming_update(candle, feeds, now, stale_after_seconds=stale)
        self._register(client, message, {pair: u.mark for pair, u in forming.items()}, selection=selection)
        items = [update.item.json() for update in forming.values()]
        frame = items_frame(
            "candle.snapshot", items, request_id=message.request_id, interval=interval, generated_at=now
        )
        client.send(frame, Channel.CANDLES)

    async def _subscribe_signals(self, client: WsClient, message: Subscribe) -> None:
        workspace_id: UUID | None = None
        workspace_slug: str | None = None
        if message.workspace_id is not None:
            async with self._container.db.session() as session:
                row = await find_workspace(session, message.workspace_id)
            workspace_id, workspace_slug = row.id, row.slug
        self._register(client, message, {}, workspace_id=workspace_id, workspace_slug=workspace_slug)

    async def _select(self, service: QuoteService, message: Subscribe) -> QuoteSelection:
        selection = await service.select(
            workspace=message.workspace_id, instrument_ids=message.instrument_ids, provider=message.provider
        )
        if len(selection.pairs) > MAX_PAIRS:
            raise ProtocolError(
                "selection_too_large",
                f"At most {MAX_PAIRS} (provider, instrument) pairs at once; name fewer instruments",
            )
        return selection

    def _register(
        self,
        client: WsClient,
        message: Subscribe,
        marks: Mapping[Hashable, object],
        *,
        selection: QuoteSelection | None = None,
        workspace_id: UUID | None = None,
        workspace_slug: str | None = None,
    ) -> Subscription:
        """Make the subscription (after its snapshot was read, with no await since) and queue the ack."""
        self._generation += 1
        instrument_ids = tuple(dict.fromkeys(message.instrument_ids))
        if selection is not None:
            workspace_id, workspace_slug = selection.workspace_id, selection.workspace_slug
            instrument_ids = selection.instrument_ids
        pairs = selection.pairs if selection is not None else ()
        subscription = Subscription(
            channel=message.channel,
            generation=self._generation,
            pairs=pairs,
            members=frozenset(pairs),
            interval=message.interval,
            provider=message.provider,
            depth=message.depth,
            workspace_id=workspace_id,
            workspace_slug=workspace_slug,
            instrument_ids=instrument_ids,
            instruments=frozenset(instrument_ids),
        )
        client.subscribe(subscription, marks)
        client.reply(subscribed_event(subscription, message.request_id), message.channel)
        return subscription
