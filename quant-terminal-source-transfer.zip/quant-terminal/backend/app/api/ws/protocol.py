"""WebSocket protocol: what clients send, what the server sends, and how connections close.

Clients send JSON text frames with an ``action`` (subscribe, unsubscribe, heartbeat); every server
frame is a JSON object with a ``type``. Prices are exact decimal strings and times ISO 8601 UTC, as in
the REST API. The full protocol is described in ``docs/websocket-protocol.md``.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from datetime import datetime
from enum import StrEnum
from typing import Annotated, Any, Literal
from uuid import UUID

import pydantic_core
from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError

from app.core.config import Settings
from app.core.errors import sanitize_validation_errors
from app.domain.enums import CandleInterval, Provider
from app.services.quotes import MAX_QUOTE_INSTRUMENTS

MAX_MESSAGE_CHARS = 32 * 1024

# Close codes. 4401 is application-defined: the client must sign in again before reconnecting.
CLOSE_NORMAL = 1000
CLOSE_GOING_AWAY = 1001
CLOSE_UNSUPPORTED_DATA = 1003
CLOSE_POLICY_VIOLATION = 1008
CLOSE_INTERNAL_ERROR = 1011
CLOSE_TRY_AGAIN_LATER = 1013
CLOSE_UNAUTHENTICATED = 4401

RECONNECT_GUIDANCE: dict[str, Any] = {
    "retry_close_codes": [CLOSE_GOING_AWAY, 1006, CLOSE_INTERNAL_ERROR, 1012, CLOSE_TRY_AGAIN_LATER],
    "final_close_codes": [CLOSE_UNSUPPORTED_DATA, CLOSE_POLICY_VIOLATION, CLOSE_UNAUTHENTICATED],
    "initial_delay_seconds": 1,
    "max_delay_seconds": 30,
    "advice": (
        "After an unexpected close, reconnect with exponential backoff and jitter, resubscribe, and "
        "reload REST snapshots: nothing sent while disconnected is replayed. After 4401 sign in again "
        "first; after 1003 or 1008 fix the client instead of retrying. Resubscribe after editing a "
        "workspace's universe."
    ),
}


class Channel(StrEnum):
    QUOTES = "quotes"
    CANDLES = "candles"
    FEED = "feed"
    SIGNALS = "signals"
    SYSTEM = "system"


MARKET_CHANNELS = frozenset({Channel.QUOTES, Channel.CANDLES, Channel.FEED})
SIGNAL_CHANNELS = frozenset({Channel.SIGNALS})
SYSTEM_CHANNELS = frozenset({Channel.SYSTEM})

_REQUEST_ID = re.compile(r"^[A-Za-z0-9._:-]{1,64}$")
RequestId = Annotated[str, Field(pattern=_REQUEST_ID.pattern)]


class _ClientMessage(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    request_id: RequestId | None = None  # echoed on the reply


class Subscribe(_ClientMessage):
    """Subscribe to a channel, replacing this connection's earlier subscription to it.

    quotes and candles: a workspace's universe (optionally only ``instrument_ids``), or
    ``instrument_ids`` from every provider (or only ``provider``); candles also need ``interval``.
    feed: optionally only ``provider``. signals: optionally only a workspace and/or instruments.
    """

    action: Literal["subscribe"]
    channel: Channel
    workspace_id: Annotated[str, Field(min_length=1, max_length=64)] | None = None  # slug or id
    instrument_ids: tuple[UUID, ...] = Field(default=(), max_length=MAX_QUOTE_INSTRUMENTS)
    provider: Provider | None = None
    interval: CandleInterval | None = None
    depth: bool = False  # quotes: include market depth


class Unsubscribe(_ClientMessage):
    action: Literal["unsubscribe"]
    channel: Channel


class Heartbeat(_ClientMessage):
    action: Literal["heartbeat"]


type ClientMessage = Subscribe | Unsubscribe | Heartbeat

_MESSAGES: TypeAdapter[ClientMessage] = TypeAdapter(
    Annotated[Subscribe | Unsubscribe | Heartbeat, Field(discriminator="action")]
)

# The options each channel takes; any other option set to a non-default value is rejected.
_ALL_OPTIONS = ("workspace_id", "instrument_ids", "provider", "interval", "depth")
_OPTIONS: dict[Channel, frozenset[str]] = {
    Channel.QUOTES: frozenset({"workspace_id", "instrument_ids", "provider", "depth"}),
    Channel.CANDLES: frozenset({"workspace_id", "instrument_ids", "provider", "interval"}),
    Channel.FEED: frozenset({"provider"}),
    Channel.SIGNALS: frozenset({"workspace_id", "instrument_ids"}),
    Channel.SYSTEM: frozenset(),
}


class ProtocolError(Exception):
    """A client message that is malformed or not allowed. Never echoes the message back."""

    def __init__(self, code: str, message: str, *, details: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def parse_client_message(text: str) -> ClientMessage:
    if len(text) > MAX_MESSAGE_CHARS:
        raise ProtocolError("message_too_large", f"Messages are limited to {MAX_MESSAGE_CHARS} characters")
    try:
        return _MESSAGES.validate_json(text)
    except ValidationError as exc:
        details = sanitize_validation_errors(exc.errors(include_input=False, include_url=False))
        raise ProtocolError("invalid_message", "Message is not valid", details=details) from None


def check_subscription(message: Subscribe) -> None:
    """Reject options the channel does not take, and selections the channel needs but lacks."""
    allowed = _OPTIONS[message.channel]
    fields = Subscribe.model_fields
    extra = [
        name
        for name in _ALL_OPTIONS
        if name not in allowed and getattr(message, name) != fields[name].default
    ]
    if extra:
        raise ProtocolError(
            "option_not_allowed", f"{message.channel} subscriptions do not take: {', '.join(extra)}"
        )
    if (
        message.channel in (Channel.QUOTES, Channel.CANDLES)
        and message.workspace_id is None
        and not message.instrument_ids
    ):
        raise ProtocolError("selection_required", "Name a workspace or at least one instrument")
    if message.channel is Channel.CANDLES and message.interval is None:
        raise ProtocolError("interval_required", "Candle subscriptions need an interval")


def request_id_of(text: str) -> str | None:
    """The valid ``request_id`` of a message that could not be parsed, so the error can carry it."""
    if len(text) > MAX_MESSAGE_CHARS:
        return None
    try:
        raw = pydantic_core.from_json(text)
    except ValueError:
        return None
    value = raw.get("request_id") if isinstance(raw, dict) else None
    return value if isinstance(value, str) and _REQUEST_ID.fullmatch(value) else None


def encode_event(event: Mapping[str, Any]) -> str:
    """JSON for a server event; pydantic models, decimals, UUIDs and datetimes serialize as in REST."""
    return pydantic_core.to_json(event).decode("utf-8")


def items_frame(event_type: str, items: Iterable[str], **fields: Any) -> str:
    """An event whose ``items`` are JSON objects encoded already (once, for every client sent them)."""
    head = encode_event({"type": event_type, **fields})
    return f'{head[:-1]},"items":[{",".join(items)}]}}'


def error_event(code: str, message: str, request_id: str | None, details: Any = None) -> dict[str, Any]:
    return {"type": "error", "code": code, "message": message, "details": details, "request_id": request_id}


def welcome_event(
    connection_id: str, channels: frozenset[Channel], settings: Settings, now: datetime
) -> dict[str, Any]:
    return {
        "type": "welcome",
        "connection_id": connection_id,
        "channels": sorted(channels),
        "server_time": now,
        "heartbeat_interval_seconds": settings.ws_heartbeat_interval_seconds,
        "max_updates_per_second": settings.ws_max_updates_per_second,
        "stale_after_seconds": settings.data_stale_after_seconds,
        "max_instruments": MAX_QUOTE_INSTRUMENTS,
        "reconnect": RECONNECT_GUIDANCE,
    }
