"""FastAPI dependencies shared by REST and WebSocket endpoints."""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from datetime import datetime
from typing import Annotated, cast

import structlog
from fastapi import Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.requests import HTTPConnection

from app.container import Container
from app.core.clock import utc_now
from app.core.errors import AuthenticationError
from app.services.auth_service import AuthService, SessionUser
from app.services.backtests import BacktestService
from app.services.candles import CandleService
from app.services.capabilities import CapabilityService
from app.services.datasets import DatasetService
from app.services.instruments import InstrumentService
from app.services.markets import MarketCalendarCache
from app.services.provider_accounts import ProviderAccountService
from app.services.provider_auth import ProviderAuthService
from app.services.provider_status import ProviderStatusService
from app.services.quotes import QuoteService
from app.services.risk import RiskRuleService
from app.services.signals import SignalService
from app.services.strategies import StrategyService
from app.services.watchlists import WatchlistService
from app.services.workspaces import WorkspaceService


def get_container(conn: HTTPConnection) -> Container:
    return cast(Container, conn.app.state.container)


ContainerDep = Annotated[Container, Depends(get_container)]


def client_ip(conn: HTTPConnection) -> str | None:
    # Direct peer address only; X-Forwarded-For is not trusted (no proxy is configured).
    return conn.client.host if conn.client else None


ClientIp = Annotated[str | None, Depends(client_ip)]


def get_auth_service(container: ContainerDep) -> AuthService:
    return AuthService(container.db, container.bus, container.settings)


AuthServiceDep = Annotated[AuthService, Depends(get_auth_service)]


async def resolve_session(conn: HTTPConnection, container: Container) -> SessionUser | None:
    token = conn.cookies.get(container.settings.session_cookie_name)
    if not token:
        return None
    return await AuthService(container.db, container.bus, container.settings).resolve(token)


async def get_current_user(conn: HTTPConnection, container: ContainerDep) -> SessionUser:
    user = await resolve_session(conn, container)
    if user is None:
        raise AuthenticationError("Sign in required", code="unauthenticated")
    structlog.contextvars.bind_contextvars(user=user.username)
    return user


CurrentUser = Annotated[SessionUser, Depends(get_current_user)]


async def get_db_session(container: ContainerDep) -> AsyncIterator[AsyncSession]:
    async with container.db.session() as session:
        yield session


DbSession = Annotated[AsyncSession, Depends(get_db_session)]


class PageParams:
    def __init__(
        self,
        limit: Annotated[int, Query(ge=1, le=500)] = 50,
        offset: Annotated[int, Query(ge=0, le=1_000_000)] = 0,
    ) -> None:
        self.limit = limit
        self.offset = offset


Paging = Annotated[PageParams, Depends()]


async def get_clock() -> Callable[[], datetime]:
    """The clock services read; tests override this dependency."""
    return utc_now


Clock = Annotated[Callable[[], datetime], Depends(get_clock)]


async def get_accounts(container: ContainerDep, clock: Clock) -> ProviderAccountService:
    return ProviderAccountService.from_container(container, clock=clock)


Accounts = Annotated[ProviderAccountService, Depends(get_accounts)]


async def get_provider_auth(accounts: Accounts) -> ProviderAuthService:
    return ProviderAuthService(accounts)


ProviderAuth = Annotated[ProviderAuthService, Depends(get_provider_auth)]


async def get_instruments(accounts: Accounts) -> InstrumentService:
    return InstrumentService(accounts)


Instruments = Annotated[InstrumentService, Depends(get_instruments)]


async def get_capabilities(container: ContainerDep, clock: Clock) -> CapabilityService:
    return CapabilityService.from_container(container, clock=clock)


Capabilities = Annotated[CapabilityService, Depends(get_capabilities)]


async def get_provider_statuses(
    accounts: Accounts, capabilities: Capabilities, clock: Clock
) -> ProviderStatusService:
    return ProviderStatusService(accounts, capabilities, clock=clock)


ProviderStatuses = Annotated[ProviderStatusService, Depends(get_provider_statuses)]


async def get_workspaces(instruments: Instruments, capabilities: Capabilities) -> WorkspaceService:
    return WorkspaceService(instruments, capabilities)


Workspaces = Annotated[WorkspaceService, Depends(get_workspaces)]


async def get_strategies(container: ContainerDep, clock: Clock) -> StrategyService:
    return StrategyService.from_container(container, clock=clock)


Strategies = Annotated[StrategyService, Depends(get_strategies)]


async def get_signals(container: ContainerDep) -> SignalService:
    return SignalService.from_container(container)


Signals = Annotated[SignalService, Depends(get_signals)]


async def get_risk(container: ContainerDep, clock: Clock) -> RiskRuleService:
    return RiskRuleService.from_container(container, clock=clock)


Risk = Annotated[RiskRuleService, Depends(get_risk)]


async def get_watchlists(container: ContainerDep, clock: Clock) -> WatchlistService:
    return WatchlistService.from_container(container, clock=clock)


Watchlists = Annotated[WatchlistService, Depends(get_watchlists)]


async def get_quotes(container: ContainerDep, clock: Clock) -> QuoteService:
    return QuoteService.from_container(container, clock=clock)


Quotes = Annotated[QuoteService, Depends(get_quotes)]


async def get_candles(container: ContainerDep, clock: Clock) -> CandleService:
    return CandleService.from_container(container, clock=clock)


Candles = Annotated[CandleService, Depends(get_candles)]


def get_market_calendar(conn: HTTPConnection) -> MarketCalendarCache:
    return cast(MarketCalendarCache, conn.app.state.market_calendar)


MarketCalendarDep = Annotated[MarketCalendarCache, Depends(get_market_calendar)]


async def get_datasets(container: ContainerDep, calendars: MarketCalendarDep, clock: Clock) -> DatasetService:
    return DatasetService.from_container(container, calendars, clock=clock)


Datasets = Annotated[DatasetService, Depends(get_datasets)]


async def get_backtests(container: ContainerDep, clock: Clock) -> BacktestService:
    return BacktestService.from_container(container, clock=clock)


Backtests = Annotated[BacktestService, Depends(get_backtests)]
