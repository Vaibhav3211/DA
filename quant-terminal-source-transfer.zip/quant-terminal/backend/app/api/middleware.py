"""Pure-ASGI middleware: request context/metrics, security headers, and Origin (CSRF) checks."""

from __future__ import annotations

import re
import time
import uuid
from collections.abc import Iterable
from typing import Any
from urllib.parse import urlsplit

import structlog
from starlette.datastructures import Headers, MutableHeaders
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.core.errors import error_envelope
from app.core.logging import get_logger
from app.observability.metrics import HTTP_REQUEST_SECONDS, HTTP_REQUESTS

log = get_logger("app.access")

_REQUEST_ID = re.compile(r"^[A-Za-z0-9._-]{8,64}$")
# W3C Trace Context: version-traceid-parentid-flags
_TRACEPARENT = re.compile(r"^[0-9a-f]{2}-([0-9a-f]{32})-[0-9a-f]{16}-[0-9a-f]{2}$")
_UNSAFE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})
_QUIET_PATHS = ("/health/live", "/health/ready", "/metrics")


def route_template(scope: Scope) -> str:
    """The matched route's path template, e.g. ``/api/v1/instruments/{instrument_id}``.

    FastAPI 0.16x keeps included routers nested, so ``scope["route"].path`` is relative to the
    include prefix; the full template is on FastAPI's effective route context. Read it defensively and
    fall back to the relative template (still bounded cardinality) if that internal changes.
    """
    context = (scope.get("fastapi") or {}).get("effective_route_context")
    full = getattr(context, "path_format", None)
    if isinstance(full, str):
        return full
    return getattr(scope.get("route"), "path", None) or "unmatched"


def origin_of(url: str) -> str:
    parts = urlsplit(url)
    return f"{parts.scheme}://{parts.netloc}".lower()


class RequestContextMiddleware:
    """Correlation ID (``X-Request-ID``), W3C trace ID, structured access log, and HTTP metrics."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return
        headers = Headers(scope=scope)
        incoming = headers.get("x-request-id", "")
        request_id = incoming if _REQUEST_ID.match(incoming) else uuid.uuid4().hex
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(correlation_id=request_id)
        trace = _TRACEPARENT.match(headers.get("traceparent", ""))
        if trace:
            structlog.contextvars.bind_contextvars(trace_id=trace.group(1))
        if scope["type"] == "websocket":
            await self.app(scope, receive, send)
            return

        started = time.perf_counter()
        status_holder = {"status": 500}

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                status_holder["status"] = message["status"]
                MutableHeaders(scope=message)["X-Request-ID"] = request_id
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            elapsed = time.perf_counter() - started
            # Route templates (not raw paths) keep metric label cardinality bounded.
            route = route_template(scope)
            method = scope["method"]
            status = status_holder["status"]
            HTTP_REQUESTS.labels(method, route, str(status)).inc()
            HTTP_REQUEST_SECONDS.labels(method, route).observe(elapsed)
            if not scope["path"].startswith(_QUIET_PATHS):
                # Never log the query string: OAuth-style callbacks carry one-time tokens in it.
                log.info(
                    "http_request",
                    method=method,
                    route=route,
                    status=status,
                    duration_ms=round(elapsed * 1000, 2),
                )


class SecurityHeadersMiddleware:
    def __init__(self, app: ASGIApp, *, hsts: bool) -> None:
        self.app = app
        self.hsts = hsts

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        path: str = scope["path"]
        is_docs = path.startswith(("/docs", "/redoc", "/openapi.json"))

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = MutableHeaders(scope=message)
                headers.setdefault("X-Content-Type-Options", "nosniff")
                headers.setdefault("X-Frame-Options", "DENY")
                headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
                headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
                if not is_docs:
                    headers.setdefault(
                        "Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'"
                    )
                    headers.setdefault("Cache-Control", "no-store")
                if self.hsts:
                    headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
            await send(message)

        await self.app(scope, receive, send_wrapper)


class OriginCheckMiddleware:
    """Rejects state-changing browser requests from origins that are not explicitly allowed.

    Together with the SameSite=Lax session cookie this prevents cross-site request forgery.
    Requests without an Origin header (CLI tools, server-to-server) are not browser-initiated
    cross-site requests and are allowed through to normal authentication.
    """

    def __init__(self, app: ASGIApp, *, allowed_origins: Iterable[str]) -> None:
        self.app = app
        self.allowed = {origin.rstrip("/").lower() for origin in allowed_origins}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http" and scope["method"] in _UNSAFE_METHODS:
            origin = Headers(scope=scope).get("origin")
            if origin is not None and origin.rstrip("/").lower() not in self.allowed:
                response = JSONResponse(
                    error_envelope("origin_not_allowed", "Request origin is not allowed"), status_code=403
                )
                await response(scope, receive, send)
                return
        await self.app(scope, receive, send)


def websocket_origin_allowed(scope: Scope | dict[str, Any], allowed_origins: Iterable[str]) -> bool:
    """Browsers always send Origin on WebSocket handshakes; reject any origin not allowed.

    Cookies are attached to cross-site WebSocket handshakes, so this check is mandatory.
    """
    origin = Headers(scope=scope).get("origin")
    if origin is None:
        return True
    return origin.rstrip("/").lower() in {o.rstrip("/").lower() for o in allowed_origins}
