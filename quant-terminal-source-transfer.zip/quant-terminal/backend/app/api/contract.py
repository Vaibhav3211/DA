"""The API contract as TypeScript, for the frontend: ``frontend/src/lib/api/types.gen.ts``.

It holds every model of the OpenAPI schema, plus the models WebSocket frames carry that no REST route
returns. Models the server only ever sends have every field required, since responses include them all.
After changing an API model run ``python -m app.api.contract`` in ``backend/``; a unit test fails while
the committed file is out of date.
"""

from __future__ import annotations

import json
import re
import sys
from collections.abc import Iterable, Iterator, Mapping
from pathlib import Path
from typing import Any

from pydantic import BaseModel
from pydantic.json_schema import models_json_schema

from app.core.config import Settings
from app.domain.events import FeedStateChange
from app.domain.models.signal import Signal

TYPES_PATH = Path(__file__).resolve().parents[3] / "frontend" / "src" / "lib" / "api" / "types.gen.ts"
FRAME_MODELS: tuple[type[BaseModel], ...] = (FeedStateChange, Signal)  # sent only on WebSocket frames
HEADER = "// Generated from the backend's API models by `python -m app.api.contract`. Do not edit.\n"
_REF = "#/components/schemas/"
_IDENTIFIER = re.compile(r"^[A-Za-z_$][A-Za-z0-9_$]*$")

type Schema = Mapping[str, Any]


def generate(settings: Settings | None = None) -> str:
    """The TypeScript declarations of the API's models."""
    schemas, sent_only = contract_schemas(settings)
    return render(schemas, sent_only)


def contract_schemas(settings: Settings | None = None) -> tuple[dict[str, Schema], set[str]]:
    """Every named schema of the API, and the names of those that are only ever sent by the server."""
    from app.main import create_app  # imports the whole API, so only when generating

    openapi = create_app(settings).openapi()
    schemas: dict[str, Schema] = dict(openapi["components"]["schemas"])
    _, frames = models_json_schema(
        [(model, "serialization") for model in FRAME_MODELS], ref_template=_REF + "{model}"
    )
    for name, schema in frames.get("$defs", {}).items():
        schemas.setdefault(name, schema)
    sent: list[Any] = [{"$ref": _REF + model.__name__} for model in FRAME_MODELS]
    received: list[Any] = []
    for path_item in openapi["paths"].values():
        for operation in path_item.values():
            for response in operation.get("responses", {}).values():
                sent.extend(content.get("schema") for content in response.get("content", {}).values())
            body = operation.get("requestBody", {})
            received.extend(content.get("schema") for content in body.get("content", {}).values())
            received.extend(parameter.get("schema") for parameter in operation.get("parameters", []))
    return schemas, _reachable(sent, schemas) - _reachable(received, schemas)


def render(schemas: Mapping[str, Schema], sent_only: set[str]) -> str:
    invalid = sorted(name for name in schemas if not _IDENTIFIER.match(name))
    if invalid:
        # e.g. Model-Input and Model-Output: one model is a request body and is in a response, with
        # different JSON shapes. Give the request its own model.
        raise ValueError(f"Schema names that are not TypeScript identifiers: {', '.join(invalid)}")
    declarations = [_declaration(name, schemas[name], name in sent_only) for name in sorted(schemas)]
    return HEADER + "".join("\n" + declaration for declaration in declarations)


def ts_type(schema: Any) -> str:
    """The TypeScript type of a JSON schema."""
    if not isinstance(schema, Mapping) or not schema:
        return "unknown"
    if "$ref" in schema:
        return str(schema["$ref"]).removeprefix(_REF)
    if "const" in schema:
        return json.dumps(schema["const"])
    if "enum" in schema:
        return _union(json.dumps(value) for value in schema["enum"])
    for key in ("anyOf", "oneOf"):
        if key in schema:
            return _union(ts_type(option) for option in schema[key])
    if "allOf" in schema:
        return " & ".join(_grouped(ts_type(part)) for part in schema["allOf"])
    kind = schema.get("type")
    if isinstance(kind, list):
        return _union(ts_type({**schema, "type": each}) for each in kind)
    match kind:
        case "string":
            return "string"
        case "integer" | "number":
            return "number"
        case "boolean":
            return "boolean"
        case "null":
            return "null"
        case "array" if "prefixItems" in schema:
            return "[" + ", ".join(ts_type(item) for item in schema["prefixItems"]) + "]"
        case "array":
            return _grouped(ts_type(schema.get("items"))) + "[]"
        case "object" if "properties" in schema:
            return "{ " + " ".join(_members(schema, all_required=False)) + " }"
        case "object":
            values = schema.get("additionalProperties")
            value = "unknown" if values is None or values is True else ts_type(values)
            if "propertyNames" in schema:
                return f"Partial<Record<{ts_type(schema['propertyNames'])}, {value}>>"
            return f"Record<string, {value}>"
    return "unknown"


def main(argv: list[str] | None = None) -> None:
    args = sys.argv[1:] if argv is None else argv
    path = Path(args[0]) if args else TYPES_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(generate(), encoding="utf-8", newline="\n")
    sys.stdout.write(f"wrote {path}\n")


def _declaration(name: str, schema: Schema, sent_only: bool) -> str:
    comment = _comment(schema.get("description"))
    if schema.get("type") == "object" and "properties" in schema:
        members = "".join(f"  {member}\n" for member in _members(schema, all_required=sent_only))
        return f"{comment}export interface {name} {{\n{members}}}\n"
    return f"{comment}export type {name} = {ts_type(schema)};\n"


def _members(schema: Schema, *, all_required: bool) -> Iterator[str]:
    required = set(schema.get("required", ()))
    for name, field in schema["properties"].items():
        key = name if _IDENTIFIER.match(name) else json.dumps(name)
        optional = "" if all_required or name in required else "?"
        yield f"{key}{optional}: {ts_type(field)};"


def _comment(description: Any) -> str:
    if not isinstance(description, str) or not description.strip():
        return ""
    first = description.strip().split("\n\n", 1)[0]
    text = " ".join(first.split()).replace("*/", "* /")
    return f"/** {text} */\n"


def _union(types: Iterable[str]) -> str:
    return " | ".join(dict.fromkeys(types))


def _grouped(type_: str) -> str:
    return f"({type_})" if " | " in type_ or " & " in type_ else type_


def _refs(node: Any) -> Iterator[str]:
    if isinstance(node, Mapping):
        ref = node.get("$ref")
        if isinstance(ref, str) and ref.startswith(_REF):
            yield ref.removeprefix(_REF)
        for value in node.values():
            yield from _refs(value)
    elif isinstance(node, list):
        for value in node:
            yield from _refs(value)


def _reachable(roots: Iterable[Any], schemas: Mapping[str, Schema]) -> set[str]:
    seen: set[str] = set()
    pending = [name for root in roots for name in _refs(root)]
    while pending:
        name = pending.pop()
        if name not in seen:
            seen.add(name)
            pending.extend(_refs(schemas.get(name, {})))
    return seen


if __name__ == "__main__":
    main()
