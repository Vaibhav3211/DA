"""Backtest datasets: source candles placed on the exchange calendar.

A dataset freezes one instrument's candles at one interval over a range of exchange-local dates.
``build`` places each source candle on the grid the live candle builder uses:

* An intraday candle must start on a bucket of the session. Providers start them at the session open or
  on the clock; both grids are tried and the one more candles fit is kept (the live CANDLE_ANCHOR when
  they fit equally, as they do whenever the open falls on the clock grid). A candle ends where its
  bucket ends, so the last one of a session ends at the close.
* A daily candle belongs to its exchange-local date and spans that day's session.
* On days the calendar does not know (exchanges without a published calendar) candles are kept
  unchecked, end at the next step or local midnight, and are flagged OUTSIDE_SESSION.

Candles on closed days, outside the session hours, off the grid or outside the requested dates are left
out and counted. Coverage compares the candles kept with those the calendar expects, so gaps are
visible. Prices are kept as received (to 8 decimal places, the storage precision): a candle whose high
and low do not contain its open and close is kept and flagged INCONSISTENT_OHLC.
"""

from __future__ import annotations

import hashlib
import math
from collections import Counter
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from datetime import UTC, date, datetime, time, timedelta
from decimal import ROUND_DOWN, Decimal
from typing import Final
from uuid import UUID

from app.core.config import CandleAnchor
from app.domain.enums import (
    CandleFlag,
    CandleInterval,
    DatasetSource,
    DataStatus,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
)
from app.domain.models import Candle, Instrument
from app.domain.models.backtest import DatasetCoverage, GapRange
from app.market_data.calendars.service import DayKind, MarketCalendar, TradingDay
from app.market_data.candles.builder import BucketFrame
from app.providers.history import HistoricalCandle

INCONSISTENT_OHLC: Final = "INCONSISTENT_OHLC"
INCOMPLETE_FLAGS: Final = frozenset(
    {CandleFlag.PARTIAL_START.value, CandleFlag.GAP_BEFORE.value, CandleFlag.DISCONNECTED_DURING.value}
)
MAX_LISTED: Final = 50  # gaps, assumed days and unknown days listed in the coverage
MAX_EXAMPLES: Final = 10  # left-out candles described in the coverage

# Why a candle was left out.
CLOSED_DAY: Final = "CLOSED_DAY"
OUTSIDE_HOURS: Final = "OUTSIDE_HOURS"
OFF_GRID: Final = "OFF_GRID"
OUTSIDE_DATES: Final = "OUTSIDE_DATES"

_FLAG_ORDER: Final = {flag: index for index, flag in enumerate((*CandleFlag, INCONSISTENT_OHLC))}
_CANDLE_FLAGS: Final = frozenset(flag.value for flag in CandleFlag)
_PRICE_STEP: Final = Decimal("1e-8")
_PCT_STEP: Final = Decimal("0.01")
_HUNDRED: Final = Decimal(100)


class DatasetError(ValueError):
    """The source candles cannot form a dataset."""


@dataclass(frozen=True, slots=True)
class SourceCandle:
    """A candle as its source gave it, before it is placed on the calendar."""

    start: datetime  # UTC
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: int | None
    open_interest: int | None = None
    flags: tuple[str, ...] = ()  # recorded candles: the live builder's flags

    @classmethod
    def from_history(cls, candle: HistoricalCandle) -> SourceCandle:
        return cls(
            candle.start,
            candle.open,
            candle.high,
            candle.low,
            candle.close,
            candle.volume,
            candle.open_interest,
        )

    @classmethod
    def from_candle(cls, candle: Candle) -> SourceCandle:
        return cls(
            candle.bucket_start,
            candle.open_price,
            candle.high_price,
            candle.low_price,
            candle.close_price,
            candle.volume,
            flags=tuple(flag.value for flag in candle.flags),
        )


@dataclass(frozen=True, slots=True)
class DatasetCandle:
    start: datetime  # UTC
    end: datetime
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: int | None
    open_interest: int | None = None
    flags: tuple[str, ...] = ()  # CandleFlag values, and INCONSISTENT_OHLC


@dataclass(frozen=True, slots=True)
class BuiltDataset:
    candles: tuple[DatasetCandle, ...]  # in time order
    coverage: DatasetCoverage


@dataclass(frozen=True, slots=True)
class _Placed:
    start: datetime
    end: datetime
    session_date: date
    known: bool  # False on days the calendar does not know


@dataclass(frozen=True, slots=True)
class _LeftOut:
    reason: str
    text: str


class _Grid:
    """Places candle starts on one exchange's calendar, caching each day's bucket frame."""

    def __init__(self, calendar: MarketCalendar, exchange: Exchange, interval: CandleInterval) -> None:
        self.calendar = calendar
        self.exchange = exchange
        self.interval = interval
        self.zone = calendar.timezone(exchange)
        self._frames: dict[date, BucketFrame | None] = {}

    def frame(self, day: TradingDay) -> BucketFrame | None:
        """The bucket frame of a session day or an unknown day; None for closed days."""
        if day.session_date not in self._frames:
            self._frames[day.session_date] = self._frame(day)
        return self._frames[day.session_date]

    def _frame(self, day: TradingDay) -> BucketFrame | None:
        midnight = datetime.combine(day.session_date, time(), tzinfo=self.zone).astimezone(UTC)
        if day.kind is DayKind.UNKNOWN:
            next_day = datetime.combine(day.session_date + timedelta(days=1), time(), tzinfo=self.zone)
            return BucketFrame(day.session_date, midnight, next_day.astimezone(UTC), midnight, known=False)
        if day.kind is DayKind.SESSION and day.open_at is not None and day.close_at is not None:
            return BucketFrame(day.session_date, day.open_at, day.close_at, midnight, known=True)
        return None

    def place(self, start: datetime, anchor: CandleAnchor) -> _Placed | _LeftOut:
        day = self.calendar.trading_day_at(self.exchange, start)
        frame = self.frame(day)
        if frame is None:
            return _LeftOut(CLOSED_DAY, f"the exchange is closed ({day.kind.value.lower()})")
        if self.interval is CandleInterval.D1:
            return _Placed(frame.first, frame.last, frame.session_date, frame.known)
        if frame.known and not frame.first <= start < frame.last:
            return _LeftOut(OUTSIDE_HOURS, "outside the session hours")
        slot = frame.slot(start, self.interval, anchor)
        if slot.start != start:
            return _LeftOut(OFF_GRID, f"not on the {anchor.value} grid of {self.interval.value} candles")
        return _Placed(slot.start, slot.end, frame.session_date, frame.known)

    def slots(self, day: TradingDay, anchor: CandleAnchor | None) -> Iterator[tuple[datetime, datetime]]:
        """The buckets the calendar expects on a session day."""
        frame = self.frame(day)
        if frame is None or not frame.known:
            return
        if self.interval is CandleInterval.D1 or anchor is None:
            yield frame.first, frame.last
            return
        at = frame.first
        while at < frame.last:
            slot = frame.slot(at, self.interval, anchor)
            yield slot.start, slot.end
            at = slot.end

    def local(self, at: datetime) -> str:
        return at.astimezone(self.zone).strftime("%Y-%m-%d %H:%M")


def build(
    source: Iterable[SourceCandle],
    *,
    calendar: MarketCalendar,
    instrument: Instrument,
    interval: CandleInterval,
    first_day: date,
    last_day: date,
    live_anchor: CandleAnchor,
    until: datetime | None = None,
    requests: int = 0,
    duplicates: int = 0,
) -> BuiltDataset:
    """Place the source candles on the calendar and measure the coverage of ``first_day``..``last_day``.
    Candles the calendar expects to end after ``until`` (normally now) are not counted as missing.
    Raises DatasetError when no candle can be kept."""
    raw = sorted(source, key=lambda candle: candle.start)
    grid = _Grid(calendar, instrument.exchange, interval)
    period = f"{instrument.symbol} {interval.value} candles from {first_day} to {last_day}"
    if not raw:
        raise DatasetError(f"the source has no {period}")
    anchor = None if interval is CandleInterval.D1 else _choose_anchor(raw, grid, live_anchor)
    no_volume = instrument.instrument_type is InstrumentType.INDEX or instrument.segment is Segment.INDEX

    kept: dict[datetime, DatasetCandle] = {}
    left_out: Counter[str] = Counter()
    examples: list[str] = []
    repeats = duplicates
    inconsistent = without_volume = incomplete = 0
    for candle in raw:
        placed = grid.place(candle.start, anchor or live_anchor)
        if isinstance(placed, _Placed) and not first_day <= placed.session_date <= last_day:
            placed = _LeftOut(OUTSIDE_DATES, f"outside the requested dates ({placed.session_date})")
        if isinstance(placed, _LeftOut):
            left_out[placed.reason] += 1
            if len(examples) < MAX_EXAMPLES:
                examples.append(f"{grid.local(candle.start)}: {placed.text}")
            continue
        if placed.start in kept:
            repeats += 1
            continue
        flags = set(candle.flags)
        volume = candle.volume
        if no_volume:
            volume = None
            flags.add(CandleFlag.VOLUME_UNAVAILABLE.value)
        if not placed.known:
            flags.add(CandleFlag.OUTSIDE_SESSION.value)
        low_ok = candle.low <= min(candle.open, candle.close)
        if not (low_ok and candle.high >= max(candle.open, candle.close)):
            flags.add(INCONSISTENT_OHLC)
            inconsistent += 1
        if volume is None:
            without_volume += 1
        if flags & INCOMPLETE_FLAGS:
            incomplete += 1
        kept[placed.start] = DatasetCandle(
            start=placed.start,
            end=placed.end,
            open=_stored(candle.open),
            high=_stored(candle.high),
            low=_stored(candle.low),
            close=_stored(candle.close),
            volume=volume,
            open_interest=candle.open_interest,
            flags=tuple(sorted(flags, key=lambda flag: _FLAG_ORDER.get(flag, len(_FLAG_ORDER)))),
        )
    if not kept:
        reasons = ", ".join(f"{count} {reason}" for reason, count in sorted(left_out.items()))
        raise DatasetError(
            f"none of the {len(raw)} source candles fits the {instrument.exchange.value} calendar for the "
            f"{period} ({reasons}); e.g. {'; '.join(examples[:3])}"
        )

    coverage = _coverage(kept, grid, anchor, first_day, last_day, until)
    notes = list(coverage.notes)
    if anchor is not None and anchor is not live_anchor:
        notes.append(
            f"These candles start on the {anchor.value} grid while live candles use {live_anchor.value} "
            "(CANDLE_ANCHOR), so their boundaries differ from live candles."
        )
    if no_volume:
        notes.append("Index candles carry no volume, so they are flagged VOLUME_UNAVAILABLE.")
    total_left_out = sum(left_out.values())
    if total_left_out:
        notes.append(f"{total_left_out} source candles were left out; see left_out_by_reason.")
    coverage = coverage.model_copy(
        update={
            "left_out": total_left_out,
            "left_out_by_reason": dict(sorted(left_out.items())),
            "left_out_examples": tuple(examples),
            "duplicates": repeats,
            "requests": requests,
            "inconsistent": inconsistent,
            "without_volume": without_volume,
            "incomplete": incomplete,
            "notes": tuple(notes),
        }
    )
    return BuiltDataset(tuple(kept[start] for start in sorted(kept)), coverage)


def _choose_anchor(raw: list[SourceCandle], grid: _Grid, live_anchor: CandleAnchor) -> CandleAnchor:
    fits = {
        anchor: sum(isinstance(grid.place(candle.start, anchor), _Placed) for candle in raw)
        for anchor in CandleAnchor
    }
    best = max(fits.values())
    if fits[live_anchor] == best:
        return live_anchor
    return next(anchor for anchor in CandleAnchor if fits[anchor] == best)


def _coverage(
    kept: dict[datetime, DatasetCandle],
    grid: _Grid,
    anchor: CandleAnchor | None,
    first_day: date,
    last_day: date,
    until: datetime | None,
) -> DatasetCoverage:
    session_days = expected = present = 0
    gaps: list[GapRange] = []
    gap_total = 0
    run: list[datetime] = []  # [start of the first missing candle, end of the last]
    run_count = 0
    assumed: list[date] = []
    unknown: list[date] = []

    def close_run() -> None:
        nonlocal gap_total, run_count
        if run_count:
            gap_total += 1
            if len(gaps) < MAX_LISTED:
                gaps.append(GapRange(start=run[0], end=run[1], candles=run_count))
        run.clear()
        run_count = 0

    day = first_day
    while day <= last_day:
        trading_day = grid.calendar.trading_day(grid.exchange, day)
        if trading_day.kind is DayKind.UNKNOWN:
            unknown.append(day)
        elif trading_day.kind is DayKind.SESSION:
            counted = False
            for start, end in grid.slots(trading_day, anchor):
                if until is not None and end > until:
                    break
                counted = True
                expected += 1
                if start in kept:
                    present += 1
                    close_run()
                    continue
                if not run:
                    run.extend((start, end))
                run[1] = end
                run_count += 1
            if counted:
                session_days += 1
                if not trading_day.verified:
                    assumed.append(day)
        day += timedelta(days=1)
    close_run()

    notes: list[str] = []
    if assumed:
        notes.append(
            f"{len(assumed)} session days are past the published {grid.exchange.value} calendar, so their "
            "regular hours are assumed."
        )
    if unknown:
        notes.append(
            f"The {grid.exchange.value} calendar is unknown on {len(unknown)} days: their candles were kept "
            "unchecked and flagged OUTSIDE_SESSION, and nothing is counted as missing on them."
        )
    coverage_pct = None
    if expected:
        coverage_pct = (Decimal(present) * _HUNDRED / expected).quantize(_PCT_STEP, ROUND_DOWN)
    return DatasetCoverage(
        anchor=None if anchor is None else anchor.value,
        session_days=session_days,
        expected=expected,
        present=present,
        missing=expected - present,
        coverage_pct=coverage_pct,
        gaps=tuple(gaps),
        gap_total=gap_total,
        assumed_days=tuple(assumed[:MAX_LISTED]),
        assumed_days_total=len(assumed),
        unknown_days=tuple(unknown[:MAX_LISTED]),
        unknown_days_total=len(unknown),
        notes=tuple(notes),
    )


def _stored(price: Decimal) -> Decimal:
    exponent = price.as_tuple().exponent
    return price.quantize(_PRICE_STEP) if isinstance(exponent, int) and exponent < -8 else price


def expected_candles(
    calendar: MarketCalendar,
    exchange: Exchange,
    interval: CandleInterval,
    first_day: date,
    last_day: date,
    *,
    stop_above: int | None = None,
) -> int:
    """About how many candles ``first_day``..``last_day`` holds, to refuse an oversized dataset before
    fetching it: the buckets of each session, or of the whole local day when the calendar does not know
    the day. Counting stops once it passes ``stop_above``."""
    whole_day = 1 if interval is CandleInterval.D1 else math.ceil(86_400 / interval.seconds)
    total = 0
    day = first_day
    while day <= last_day and (stop_above is None or total <= stop_above):
        trading_day = calendar.trading_day(exchange, day)
        if trading_day.kind is DayKind.UNKNOWN:
            total += whole_day
        elif trading_day.open_at is not None and trading_day.close_at is not None:
            if interval is CandleInterval.D1:
                total += 1
            else:
                span = (trading_day.close_at - trading_day.open_at).total_seconds()
                total += math.ceil(span / interval.seconds)
        day += timedelta(days=1)
    return total


# ---- identity and replay ---------------------------------------------------------------------------


def dataset_sha(
    provider: Provider,
    source: DatasetSource,
    instrument_id: UUID,
    interval: CandleInterval,
    candles: Iterable[DatasetCandle],
) -> str:
    """SHA-256 of the dataset's content: equal values give the same SHA however they were stored."""
    digest = hashlib.sha256(f"{provider.value}|{source.value}|{instrument_id}|{interval.value}\n".encode())
    for candle in candles:
        fields = (
            candle.start.astimezone(UTC).isoformat(),
            candle.end.astimezone(UTC).isoformat(),
            _number(candle.open),
            _number(candle.high),
            _number(candle.low),
            _number(candle.close),
            "" if candle.volume is None else str(candle.volume),
            "" if candle.open_interest is None else str(candle.open_interest),
            ",".join(candle.flags),
        )
        digest.update(("|".join(fields) + "\n").encode())
    return digest.hexdigest()


def _number(value: Decimal) -> str:
    return format(value.normalize(), "f")


def to_candles(
    candles: Iterable[DatasetCandle],
    *,
    instrument: Instrument,
    provider: Provider,
    interval: CandleInterval,
    simulated: bool,
) -> list[Candle]:
    """The dataset as closed candles for the strategy runtime. They carry the data status of the feed
    they stand for (LIVE, or SIMULATED for simulator recordings) and no event counts."""
    status = DataStatus.SIMULATED if simulated else DataStatus.LIVE
    return [
        Candle(
            provider=provider,
            account_id=None,
            instrument_id=instrument.id,
            symbol=instrument.symbol,
            exchange=instrument.exchange,
            segment=instrument.segment,
            interval=interval,
            bucket_start=candle.start,
            bucket_end=candle.end,
            open_price=candle.open,
            high_price=candle.high,
            low_price=candle.low,
            close_price=candle.close,
            volume=candle.volume,
            event_count=0,
            is_closed=True,
            data_status=status,
            flags=tuple(CandleFlag(flag) for flag in candle.flags if flag in _CANDLE_FLAGS),
            first_event_at=candle.start,
            last_event_at=candle.end,
        )
        for candle in candles
    ]
