"""Backtest metrics: what the closed trades and the equity curve add up to.

Definitions (also in docs/backtesting.md):

* A trade's result is net of fees and slippage. It is a win above 0.00, a loss below and breakeven at
  0.00 (results are kept to the cent).
* Win rate = winning closed trades / all closed trades x 100. Breakeven trades count in the denominator.
  The position still open at the end is not a trade, and signals are not trades.
* Average win and average loss are the mean net result of winning and losing trades (the loss negative).
* Gross results use reference prices (no fees or slippage); returns are over the initial capital.
* Profit factor = total net result of winning trades / the absolute total of losing trades.
* Maximum drawdown is the largest fall of the equity from a previous peak, with equity marked at every
  candle's close (open position included); falls inside a candle are not seen.

A value that cannot be computed (no trades, no losses, ...) is reported with the reason instead.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal
from typing import Final

from app.domain.enums import TradeOutcome
from app.domain.models.backtest import BacktestMetrics, BacktestTrade, Measure

_CENT: Final = Decimal("0.01")
_HUNDRED: Final = Decimal(100)

NO_CLOSED_TRADES: Final = "No closed trades"


def money(value: Decimal) -> Decimal:
    return value.quantize(_CENT, ROUND_HALF_UP)


def percent(part: Decimal, whole: Decimal) -> Decimal:
    return (part * _HUNDRED / whole).quantize(_CENT, ROUND_HALF_UP)


def measure(
    trades: Sequence[BacktestTrade],
    *,
    initial_capital: Decimal,
    equity: Sequence[tuple[datetime, Decimal]],
) -> BacktestMetrics:
    """Metrics of the closed trades, and the drawdown of the close-marked equity curve."""
    wins = [trade.net_pnl for trade in trades if trade.outcome is TradeOutcome.WIN]
    losses = [trade.net_pnl for trade in trades if trade.outcome is TradeOutcome.LOSS]
    closed = len(trades)
    gross = sum((trade.gross_pnl for trade in trades), Decimal(0))
    net = sum((trade.net_pnl for trade in trades), Decimal(0))
    drawdown, drawdown_pct, peak_at, trough_at = _drawdown(equity)
    return BacktestMetrics(
        closed_trades=closed,
        wins=len(wins),
        losses=len(losses),
        breakevens=closed - len(wins) - len(losses),
        win_rate_pct=(
            Measure(value=percent(Decimal(len(wins)), Decimal(closed)))
            if closed
            else Measure(reason=NO_CLOSED_TRADES)
        ),
        average_win=_average(wins, "No winning trades"),
        average_loss=_average(losses, "No losing trades"),
        gross_pnl=money(gross),
        net_pnl=money(net),
        gross_return_pct=percent(gross, initial_capital),
        net_return_pct=percent(net, initial_capital),
        fees=money(sum((trade.fees for trade in trades), Decimal(0))),
        slippage=money(sum((trade.slippage for trade in trades), Decimal(0))),
        profit_factor=_profit_factor(closed, wins, losses),
        max_drawdown=drawdown,
        max_drawdown_pct=drawdown_pct,
        drawdown_peak_at=peak_at,
        drawdown_trough_at=trough_at,
        final_equity=money(equity[-1][1]) if equity else money(initial_capital),
        both_touched_trades=sum(trade.both_touched for trade in trades),
        gap_exits=sum(trade.gap_exit for trade in trades),
    )


def _average(values: Sequence[Decimal], empty: str) -> Measure:
    if not values:
        return Measure(reason=empty)
    return Measure(value=money(sum(values, Decimal(0)) / len(values)))


def _profit_factor(closed: int, wins: Sequence[Decimal], losses: Sequence[Decimal]) -> Measure:
    if not closed:
        return Measure(reason=NO_CLOSED_TRADES)
    lost = -sum(losses, Decimal(0))
    if not lost:
        return Measure(reason="No losing trades, so there is no loss to divide by")
    return Measure(value=(sum(wins, Decimal(0)) / lost).quantize(_CENT, ROUND_HALF_UP))


def _drawdown(
    equity: Sequence[tuple[datetime, Decimal]],
) -> tuple[Decimal, Measure, datetime | None, datetime | None]:
    """The largest fall from a peak: its amount, its share of the peak, the peak's and the trough's time."""
    if not equity:
        return Decimal("0.00"), Measure(reason="No equity points"), None, None
    peak_at, peak = equity[0]
    worst = Decimal(0)
    worst_peak: tuple[datetime, Decimal] | None = None
    trough_at: datetime | None = None
    for at, value in equity:
        if value > peak:
            peak_at, peak = at, value
        fall = peak - value
        if fall > worst:
            worst, worst_peak, trough_at = fall, (peak_at, peak), at
    if worst_peak is None:
        return Decimal("0.00"), Measure(value=Decimal("0.00")), None, None
    if worst_peak[1] <= 0:
        share = Measure(reason="The equity peak before the fall was not positive")
    else:
        share = Measure(value=percent(worst, worst_peak[1]))
    return money(worst), share, worst_peak[0], trough_at
