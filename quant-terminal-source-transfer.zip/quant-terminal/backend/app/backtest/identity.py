"""Backtest identity: the settings that decide a backtest's results, and their hash.

A run records the settings it used and their SHA-256 (``settings_hash``); its data is identified
separately, by the dataset's content SHA. A run matches a configuration while the hash of the
configuration's current settings equals the run's. Changing the strategy's code or version, the
parameters, the instrument or its lot or tick size, the interval, the trade rules, the history risk rules,
the default signal validity or the engine makes earlier runs outdated, and ``changed_paths`` says what
changed. Values that cannot change results are recorded but not hashed: where the trade rules came from,
and the risk rules that do not apply to history.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Any, Final
from uuid import UUID

from app.backtest.engine import ENGINE_VERSION, HISTORY_RULES
from app.core.hashing import json_sha256
from app.domain.enums import CandleInterval, TradeRulesSource
from app.domain.models import Instrument
from app.domain.models.backtest import TradeRules
from app.risk.engine import EffectiveRule, RiskPolicy, RuleOverride, resolve_policy
from app.risk.rules import BUILTIN_RULES, ELIGIBILITY
from app.strategies.registry import RegisteredStrategy

UNHASHED: Final = frozenset({"trade_rules_source", "risk_not_applied"})


def backtest_settings(
    entry: RegisteredStrategy,
    *,
    config: Mapping[str, Any],
    config_hash: str,
    instrument: Instrument,
    interval: CandleInterval,
    rules: TradeRules,
    rules_source: TradeRulesSource,
    policy: RiskPolicy,
    signal_validity_seconds: int,
) -> dict[str, Any]:
    """The settings snapshot of a backtest, in JSON values. Eligibility is not listed: it is checked
    before the replay, and an ineligible instrument cannot be backtested at all."""
    return {
        "engine_version": ENGINE_VERSION,
        "strategy": {"id": entry.strategy_id, "version": entry.version, "fingerprint": entry.fingerprint},
        "configuration": {"config_hash": config_hash, "config": _plain(config)},
        "instrument": {
            "id": str(instrument.id),
            "interval": interval.value,
            "lot_size": instrument.lot_size,  # entries are rounded down to it
            "tick_size": _plain(instrument.tick_size),  # slippage moves fills by whole ticks
        },
        "trade_rules": _plain(rules.model_dump()),
        "trade_rules_source": rules_source.value,
        "signal_validity_seconds": signal_validity_seconds,
        "risk": {
            item.rule.key: _rule(item)
            for item in sorted(policy.rules, key=lambda item: item.rule.key)
            if item.rule.key in HISTORY_RULES
        },
        "risk_not_applied": sorted(
            item.rule.key
            for item in policy.rules
            if item.rule.key not in HISTORY_RULES and item.rule.key != ELIGIBILITY
        ),
    }


def settings_hash(settings: Mapping[str, Any]) -> str:
    return json_sha256({key: value for key, value in settings.items() if key not in UNHASHED})


def snapshot_policy(settings: Mapping[str, Any], workspace_id: UUID | None) -> RiskPolicy:
    """The history risk rules a settings snapshot recorded, as the policy a replay applies. Raises
    ValueError when the snapshot lacks a rule, recorded invalid parameters, or holds parameters the code
    no longer accepts."""
    recorded = settings.get("risk")
    if not isinstance(recorded, Mapping):
        raise ValueError("the settings snapshot has no risk rules")
    overrides: list[RuleOverride] = []
    for key in HISTORY_RULES:
        state = recorded.get(key)
        if not isinstance(state, Mapping) or not isinstance(state.get("enabled"), bool):
            raise ValueError(f"the settings snapshot has no state for risk rule {key}")
        if "error" in state:
            raise ValueError(f"risk rule {key} had invalid parameters: {state['error']}")
        params = state.get("params", {})
        if not isinstance(params, Mapping):
            raise ValueError(f"the settings snapshot has unreadable parameters for risk rule {key}")
        overrides.append(RuleOverride(key, None, state["enabled"], dict(params)))
    rules = tuple(rule for rule in BUILTIN_RULES if rule.key in HISTORY_RULES)
    policy = resolve_policy(overrides, workspace_id, rules=rules)
    broken = [
        f"{item.rule.key}: {item.error}" for item in policy.rules if item.enabled and item.params is None
    ]
    if broken:
        raise ValueError("recorded risk rule parameters no longer validate: " + "; ".join(broken))
    return policy


def changed_paths(old: Mapping[str, Any], new: Mapping[str, Any]) -> list[str]:
    """The dotted paths of the hashed settings that differ, e.g. ``trade_rules.fill`` or
    ``configuration.config.fast_period``."""
    paths: list[str] = []
    _diff(
        {key: value for key, value in old.items() if key not in UNHASHED},
        {key: value for key, value in new.items() if key not in UNHASHED},
        "",
        paths,
    )
    config_changed = any(path.startswith("configuration.config.") for path in paths)
    if config_changed and "configuration.config_hash" in paths:
        paths.remove("configuration.config_hash")  # the parameters that changed say more
    return paths


def _diff(old: object, new: object, prefix: str, out: list[str]) -> None:
    if isinstance(old, Mapping) and isinstance(new, Mapping):
        for key in sorted({*old, *new}, key=str):
            path = f"{prefix}.{key}" if prefix else str(key)
            if key not in old or key not in new:
                out.append(path)
            else:
                _diff(old[key], new[key], path, out)
    elif old != new or type(old) is not type(new):
        out.append(prefix)


def _rule(item: EffectiveRule) -> dict[str, Any]:
    """A disabled rule's parameters cannot change results, so only its state is recorded."""
    if not item.enabled:
        return {"enabled": False}
    if item.params is None:
        return {"enabled": True, "error": item.error}
    return {"enabled": True, "params": _plain(item.params.model_dump())}


def _plain(value: object) -> Any:
    """JSON values that compare equal when the values are equal: decimals in plain normalized form."""
    match value:
        case Enum():
            return _plain(value.value)
        case bool() | int() | float() | str() | None:
            return value
        case Decimal():
            return format(value.normalize(), "f")
        case UUID():
            return str(value)
        case datetime() | date():
            return value.isoformat()
        case Mapping():
            return {str(key): _plain(item) for key, item in value.items()}
        case list() | tuple():
            return [_plain(item) for item in value]
    raise TypeError(f"{type(value).__name__} is not a backtest setting value")
