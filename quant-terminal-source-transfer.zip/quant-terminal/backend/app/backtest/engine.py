"""Backtest replay: a dataset through the strategy, the signal lifecycle, the risk gate and the trade rules.

The replay mirrors live signals as far as history allows:

* The strategy runs in the live runtime (``MarketState``, ``StrategyRunner``) with its saved
  configuration. It receives each candle after the candle closes, in order, so it cannot see later
  prices. Warm-up candles are folded into its indicators before it is first called, as the live worker
  does with stored candles, and its ``initialize`` hook runs after them.
* Each proposal goes through the live lifecycle (new signal, update, duplicate, invalidation, expiry)
  and the history risk rules (session status, frequency, price sanity, volatility, stop-loss) with the
  workspace's current settings, evaluated at the candle's close. Rules about the live system (kill
  switch, workspace pause, LIVE_SIGNALS_ENABLED, deployment state, feed quality, instrument status) do
  not apply to history; eligibility is checked once before the replay.
* Allowed BUY, SELL and EXIT signals become trades under the trade rules.

Fills: NEXT_OPEN fills a decision taken at a close at the next candle's open, the first price after the
decision; SAME_CLOSE fills it at that close, which is optimistic. INTRABAR exits a position when a
candle's low or high reaches its stop-loss or target, at the level, or at the open when the candle opens
beyond it (a gap). The order of prices inside a candle is unknown, so when one candle reaches both
levels the stop-loss is assumed (``both_touched``). CLOSE checks the levels against closes only and exits
like a decision. A position is checked from the candle it entered in when it entered at an open, and
from the next candle when it entered at a close. SIGNAL levels are the entry signal's stop-loss and first
target, and follow the signal's allowed updates. Validity (``valid_until``) governs the open signal
(duplicates, updates, frequency), not fills.

Money: each fill pays a fee (a percentage of its value plus a fixed amount per order) and slippage
(whole ticks against the trade). Units are rounded down to the lot. There is no margin model: an entry
worth more than the equity is taken in full and counted in the notes.
"""

from __future__ import annotations

import asyncio
import math
import time
from collections import Counter, deque
from collections.abc import Callable, Sequence
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal
from typing import Final
from uuid import UUID

from app.backtest.metrics import measure, money
from app.domain.enums import (
    CandleInterval,
    DataRequirement,
    ExitCheck,
    ExitReason,
    FillTiming,
    MarketRegion,
    MarketSessionState,
    OppositeSignal,
    PositionSide,
    Provider,
    RiskOutcome,
    SignalStatus,
    SignalType,
    SizingMethod,
    StopTargetSource,
    TradeOutcome,
    TradeSides,
)
from app.domain.models import Candle, Instrument, SignalCandidate
from app.domain.models.backtest import (
    BacktestMetrics,
    BacktestPeriod,
    BacktestSummary,
    BacktestTrade,
    EquityPoint,
    OpenPosition,
    SignalRef,
    SignalStats,
    SkippedEntry,
    TradeRules,
)
from app.market_data.calendars.service import MarketCalendar
from app.providers.base import describe_error
from app.risk.engine import RiskPolicy, evaluate
from app.risk.rules import (
    FREQUENCY,
    MAX_FREQUENCY_WINDOW_MINUTES,
    PRICE_SANITY,
    SESSION_STATUS,
    STOP_LOSS_REQUIRED,
    VOLATILITY_LIMIT,
    RecentSignal,
    RiskInput,
)
from app.signals.engine import Proposal, RunContext
from app.signals.lifecycle import Action, OpenSignal, plan, valid_until
from app.strategies.base import StrategyConfig
from app.strategies.registry import EVENT_ONLY_DATA, RegisteredStrategy
from app.strategies.runtime import CircuitBreaker, MarketState, StrategyRunner, calendar_sessions

ENGINE_VERSION: Final = "1.0"
HISTORY_RULES: Final = (SESSION_STATUS, FREQUENCY, PRICE_SANITY, VOLATILITY_LIMIT, STOP_LOSS_REQUIRED)
MAX_CURVE_POINTS: Final = 2000
MAX_SKIPPED: Final = 50

_YIELD_EVERY: Final = 256
_PRICE_STEP: Final = Decimal("1e-8")
_RETURN_STEP: Final = Decimal("0.0001")
_HUNDRED: Final = Decimal(100)
_RECENT_WINDOW: Final = timedelta(minutes=MAX_FREQUENCY_WINDOW_MINUTES)
_TRADED: Final = frozenset({SignalType.BUY, SignalType.SELL, SignalType.EXIT})
_SESSION_STATE_NOTES: Final = {
    MarketSessionState.POST_CLOSE: " (at the close, where daily candles and each session's last candle end)",
    MarketSessionState.UNKNOWN: " (the exchange has no calendar for those days)",
}


class BacktestError(Exception):
    """The backtest cannot run, or had to stop; the message says why."""


def history_policy(policy: RiskPolicy) -> RiskPolicy:
    """The risk rules that apply to history, with the workspace's effective settings."""
    return RiskPolicy(
        policy.workspace_id, tuple(item for item in policy.rules if item.rule.key in HISTORY_RULES)
    )


@dataclass(frozen=True, slots=True)
class Replay:
    """What one backtest replays: a saved configuration on one instrument's dataset."""

    entry: RegisteredStrategy
    config: StrategyConfig
    instrument: Instrument
    provider: Provider
    interval: CandleInterval
    rules: TradeRules
    policy: RiskPolicy  # the workspace's policy; only HISTORY_RULES are applied
    calendar: MarketCalendar
    market_region: MarketRegion
    workspace_id: UUID
    deployment_id: UUID
    run_id: UUID
    configuration_id: UUID | None = None
    simulated: bool = False  # the dataset was recorded from the simulator


@dataclass(frozen=True, slots=True)
class Limits:
    strategy_timeout_seconds: float  # per strategy call, as live
    max_seconds: float  # the whole replay
    signal_validity_seconds: int  # for signals that do not say how long they are valid


@dataclass(frozen=True, slots=True)
class BacktestResult:
    summary: BacktestSummary
    trades: tuple[BacktestTrade, ...]
    equity_curve: tuple[EquityPoint, ...]  # sampled down to MAX_CURVE_POINTS


def setup_problem(
    entry: RegisteredStrategy,
    instrument: Instrument,
    interval: CandleInterval,
    market_region: MarketRegion,
    rules: TradeRules,
) -> str | None:
    """Why the strategy cannot be replayed on this instrument's candles of ``interval``, whatever the
    candles hold; None when it can."""
    metadata, name = entry.metadata, entry.strategy_id
    if metadata.event_types:
        kinds = ", ".join(sorted(kind.value for kind in metadata.event_types))
        return f"{name} reacts to market events ({kinds}), which candles cannot replay"
    event_only = sorted(requirement.value for requirement in entry.data_requirements & EVENT_ONLY_DATA)
    if event_only:
        return f"{name} needs {', '.join(event_only)}, which only market events carry"
    if entry.intervals != {interval}:
        used = ", ".join(sorted(item.value for item in entry.intervals))
        return f"{name} uses {used} candles; the dataset has {interval.value} candles only"
    eligibility = metadata.eligibility_problem(
        market=market_region,
        exchange=instrument.exchange,
        segment=instrument.segment,
        instrument_type=instrument.instrument_type,
        instrument_key=instrument.canonical_key,
    )
    if eligibility is not None:
        return eligibility
    if rules.slippage_ticks and not instrument.tick_size:
        return f"slippage is set in ticks, and {instrument.symbol} has no tick size"
    return None


def replay_problem(replay: Replay, candles: Sequence[Candle]) -> str | None:
    """Why this replay cannot run, or None."""
    entry = replay.entry
    problem = setup_problem(entry, replay.instrument, replay.interval, replay.market_region, replay.rules)
    if problem is not None:
        return problem
    if not candles:
        return "the dataset has no candles"
    if DataRequirement.VOLUME in entry.data_requirements and all(c.volume is None for c in candles):
        return f"{entry.strategy_id} needs volume, and none of the dataset's candles has it"
    return None


async def run_backtest(
    replay: Replay,
    candles: Sequence[Candle],
    limits: Limits,
    *,
    monotonic: Callable[[], float] = time.monotonic,
) -> BacktestResult:
    """Replay ``candles`` (one instrument, one interval, in time order). Raises BacktestError when the
    replay cannot run, the strategy fails or the time limit is reached."""
    problem = replay_problem(replay, candles)
    if problem is not None:
        raise BacktestError(problem)
    started = monotonic()
    entry = replay.entry
    market = MarketState(
        entry, [(replay.instrument, replay.provider)], sessions=calendar_sessions(replay.calendar)
    )
    clock = _Clock(candles[0].bucket_end)
    run = RunContext(
        run_id=replay.run_id,
        deployment_id=replay.deployment_id,
        workspace_id=replay.workspace_id,
        market_region=replay.market_region,
        metadata=entry.metadata,
        configuration_id=replay.configuration_id,
    )
    try:
        runner = StrategyRunner(
            entry,
            run,
            replay.config,
            market,
            timeout_seconds=limits.strategy_timeout_seconds,
            breaker=CircuitBreaker(1, math.inf),
            clock=clock.now,
            record_metrics=False,
        )
    except Exception as exc:  # plugin code
        raise BacktestError(f"{entry.strategy_id} could not be created: {describe_error(exc)}") from None
    try:
        warmup = 0
        while warmup < len(candles) and market.warming():
            market.fold(candles[warmup])
            warmup += 1
        if market.warming():
            needed = entry.warmups[replay.interval]
            raise BacktestError(
                f"{entry.strategy_id} needs {needed} {replay.interval.value} candles to warm up before it is "
                f"first called, and the dataset has {len(candles)}"
            )
        if warmup >= len(candles):
            raise BacktestError(f"no candles are left to evaluate after the {warmup} warm-up candles")
        problem = await runner.initialize()
        if problem is not None:
            raise BacktestError(f"{entry.strategy_id} failed to start: {problem}")

        simulation = _Simulation(replay, limits.signal_validity_seconds)
        simulation.start(candles[warmup])
        for index in range(warmup, len(candles)):
            if monotonic() - started > limits.max_seconds:
                raise BacktestError(
                    f"stopped after {limits.max_seconds:g}s at candle {index + 1} of {len(candles)}; use a "
                    "shorter dataset or raise BACKTEST_MAX_SECONDS"
                )
            candle = candles[index]
            simulation.open(index, candle)
            clock.at = candle.bucket_end
            proposals: list[Proposal] = []
            if runner.fold(candle):
                proposals = await runner.on_candle(candle)
                if runner.stats.failures or runner.stats.timeouts:
                    raise BacktestError(
                        f"{entry.strategy_id} failed on the candle starting "
                        f"{candle.bucket_start.isoformat()}: {runner.stats.last_error}"
                    )
            simulation.close(index, candle, proposals)
            if (index - warmup) % _YIELD_EVERY == _YIELD_EVERY - 1:
                await asyncio.sleep(0)  # let the worker's other tasks (heartbeat) run
        return simulation.result(candles, warmup)
    finally:
        await runner.shutdown()


class _Clock:
    """The strategy's clock: the close of the candle being evaluated."""

    def __init__(self, at: datetime) -> None:
        self.at = at

    def now(self) -> datetime:
        return self.at


@dataclass(slots=True)
class _Position:
    side: PositionSide
    quantity: int
    entry_at: datetime  # start of the candle the entry filled in
    entry_reference: Decimal
    entry_price: Decimal
    entry_fee: Decimal
    stop: Decimal | None
    target: Decimal | None
    active_from: int  # index of the first candle that counts as held and can trigger its exits
    signal_id: UUID
    signal: SignalRef
    held: int = 0


@dataclass(slots=True)
class _Entry:
    side: PositionSide
    signal_id: UUID
    signal: SignalRef
    stop: Decimal | None  # SIGNAL levels
    target: Decimal | None


@dataclass(frozen=True, slots=True)
class _Exit:
    reason: ExitReason
    decided_at: datetime
    signal: SignalRef | None = None


class _Simulation:
    """Positions, the open signal and the equity of one replay."""

    def __init__(self, replay: Replay, validity_seconds: int) -> None:
        self.replay = replay
        self.rules = replay.rules
        self.instrument = replay.instrument
        self.metadata = replay.entry.metadata
        self.policy = history_policy(replay.policy)
        self.validity = validity_seconds
        self.lot = max(replay.instrument.lot_size or 1, 1)
        self.slip = replay.rules.slippage_ticks * (replay.instrument.tick_size or Decimal(0))
        self.cash = replay.rules.initial_capital  # realized equity
        self.position: _Position | None = None
        self.entry: _Entry | None = None  # pending until the next fill
        self.exit: _Exit | None = None
        self.open_signal: OpenSignal | None = None
        self.open_until: datetime | None = None
        self.signals = 0
        self.recent: deque[RecentSignal] = deque()
        self.trades: list[BacktestTrade] = []
        self.skipped: list[SkippedEntry] = []
        self.skipped_total = 0
        self.equity: list[tuple[datetime, Decimal]] = []
        self.counts: Counter[str] = Counter()
        self.blocked_by_rule: Counter[str] = Counter()
        self.session_blocks: Counter[MarketSessionState] = Counter()

    def start(self, first: Candle) -> None:
        self.equity.append((first.bucket_start, money(self.cash)))

    # ---- one candle ------------------------------------------------------------------------------------

    def open(self, index: int, candle: Candle) -> None:
        """From the candle's open until just before its close: fills at the open (NEXT_OPEN), then the
        stop-loss and target inside the candle (INTRABAR)."""
        if self.rules.fill is FillTiming.NEXT_OPEN:
            self._fill(index, candle, candle.open_price, at_close=False)
        position = self.position
        if position is None or index < position.active_from:
            return
        position.held += 1
        if self.rules.exit_check is ExitCheck.INTRABAR:
            self._touch(candle, position)

    def close(self, index: int, candle: Candle, proposals: Sequence[Proposal]) -> None:
        """At the candle's close: exits decided on closes, the strategy's proposals, fills at the close
        (SAME_CLOSE) and the equity mark."""
        now = candle.bucket_end
        self._close_exits(index, candle)
        if self.open_until is not None and self.open_until <= now:
            self.counts["expired"] += 1
            self.open_signal = self.open_until = None
        for proposal in proposals:
            self._propose(candle, proposal)
        if self.rules.fill is FillTiming.SAME_CLOSE:
            self._fill(index, candle, candle.close_price, at_close=True)
        equity = self.cash
        if self.position is not None:
            equity += self._unrealized(self.position, candle.close_price)
        self.equity.append((now, money(equity)))

    # ---- exits -----------------------------------------------------------------------------------------

    def _touch(self, candle: Candle, position: _Position) -> None:
        long = position.side is PositionSide.LONG
        stop, target = position.stop, position.target
        opening = candle.open_price
        if stop is not None and _at_stop(opening, stop, long):
            self._close(candle, opening, ExitReason.STOP_LOSS, gap=True)
        elif target is not None and _at_target(opening, target, long):
            self._close(candle, opening, ExitReason.TARGET, gap=True)
        else:
            high, low = candle.high_price, candle.low_price
            stop_hit = stop is not None and _at_stop(low if long else high, stop, long)
            target_hit = target is not None and _at_target(high if long else low, target, long)
            if stop is not None and stop_hit:
                self._close(candle, stop, ExitReason.STOP_LOSS, both=target_hit)
            elif target is not None and target_hit:
                self._close(candle, target, ExitReason.TARGET)

    def _close_exits(self, index: int, candle: Candle) -> None:
        position = self.position
        if position is None or index < position.active_from or self.exit is not None:
            return
        long, now = position.side is PositionSide.LONG, candle.bucket_end
        if self.rules.exit_check is ExitCheck.CLOSE:
            close = candle.close_price
            if position.stop is not None and _at_stop(close, position.stop, long):
                self.exit = _Exit(ExitReason.STOP_LOSS, now)
                return
            if position.target is not None and _at_target(close, position.target, long):
                self.exit = _Exit(ExitReason.TARGET, now)
                return
        limit = self.rules.max_holding_candles
        if limit is not None and position.held >= limit:
            self.exit = _Exit(ExitReason.MAX_HOLDING, now)

    def _close(
        self,
        candle: Candle,
        reference: Decimal,
        reason: ExitReason,
        *,
        gap: bool = False,
        both: bool = False,
        signal: SignalRef | None = None,
    ) -> None:
        position = self.position
        assert position is not None
        long = position.side is PositionSide.LONG
        units = position.quantity
        exit_price = self._price(reference, buying=not long)
        direction = 1 if long else -1
        fees = position.entry_fee + self._fee(exit_price, units)
        gross = money((reference - position.entry_reference) * direction * units)
        net = money((exit_price - position.entry_price) * direction * units - fees)
        outcome = TradeOutcome.WIN if net > 0 else TradeOutcome.LOSS if net < 0 else TradeOutcome.BREAKEVEN
        self.cash += net
        self.trades.append(
            BacktestTrade(
                number=len(self.trades) + 1,
                side=position.side,
                quantity=units,
                entry_at=position.entry_at,
                entry_reference=position.entry_reference,
                entry_price=position.entry_price,
                exit_at=candle.bucket_start,
                exit_reference=reference,
                exit_price=exit_price,
                exit_reason=reason,
                stop_loss=position.stop,
                target=position.target,
                both_touched=both,
                gap_exit=gap,
                candles_held=position.held,
                gross_pnl=gross,
                fees=fees,
                slippage=money(gross - net - fees),
                net_pnl=net,
                return_pct=(net * _HUNDRED / (position.entry_reference * units)).quantize(
                    _RETURN_STEP, ROUND_HALF_UP
                ),
                outcome=outcome,
                entry_signal=position.signal,
                exit_signal=signal,
            )
        )
        self.position = None

    # ---- signals ---------------------------------------------------------------------------------------

    def _propose(self, candle: Candle, proposal: Proposal) -> None:
        now, candidate = candle.bucket_end, proposal.candidate
        self.counts["proposed"] += 1
        action = plan(candidate, self.open_signal)
        if action is Action.IGNORE:
            return
        if action is Action.DUPLICATE:
            self.counts["duplicates"] += 1
            return
        if action is Action.INVALIDATE:
            self.counts["invalidations"] += 1
            opened = self.open_signal
            if self.entry is not None and opened is not None and self.entry.signal_id == opened.id:
                self._cancel(now, "its signal was invalidated before the entry filled")
            self.open_signal = self.open_until = None
            return
        is_update = action is Action.UPDATE
        calendar, exchange = self.replay.calendar, self.instrument.exchange
        state = calendar.status(exchange, now).state
        data = RiskInput(
            candidate=candidate,
            metadata=self.metadata,
            instrument=self.instrument,
            market_region=self.replay.market_region,
            source=proposal.source,
            session_state=state,
            trading_date=calendar.local_date(exchange, now),
            deployment_enabled=True,
            kill_switch_engaged=False,
            live_signals_enabled=True,
            is_update=is_update,
            recent_signals=() if is_update else self._recent(now),
        )
        decision = evaluate(data, self.policy, now)
        if decision.outcome is RiskOutcome.BLOCK:
            self.counts["blocked"] += 1
            failed = {
                check.rule for check in decision.checks if not check.passed and check.severity == "BLOCK"
            }
            self.blocked_by_rule.update(failed)
            if SESSION_STATUS in failed:
                self.session_blocks[state] += 1
            return
        self.counts["allowed"] += 1
        until = valid_until(candidate, now, self.validity)
        if is_update:
            assert self.open_signal is not None
            self.counts["updates"] += 1
            self.open_signal = replace(
                self.open_signal,
                status=SignalStatus.UPDATED,
                entry_price=candidate.entry_price,
                stop_loss=candidate.stop_loss,
                targets=candidate.targets,
            )
            self.open_until = until
            self._follow(self.open_signal.id, candidate)
            return
        self.signals += 1
        signal_id = UUID(int=self.signals)
        self.open_signal = OpenSignal(
            signal_id,
            candidate.signal_type,
            SignalStatus.ACTIVE,
            candidate.entry_price,
            candidate.stop_loss,
            candidate.targets,
        )
        self.open_until = until
        self.recent.append(RecentSignal(now, candidate.signal_type))
        if candidate.signal_type in _TRADED:
            self.counts["acted"] += 1
            self._act(candle, signal_id, candidate)

    def _recent(self, now: datetime) -> tuple[RecentSignal, ...]:
        horizon = now - _RECENT_WINDOW
        while self.recent and self.recent[0].generated_at <= horizon:
            self.recent.popleft()
        return tuple(self.recent)

    def _follow(self, signal_id: UUID, candidate: SignalCandidate) -> None:
        """An allowed update moves the levels of the position or pending entry its signal opened."""
        if self.rules.stop_target is not StopTargetSource.SIGNAL:
            return
        stop, target = candidate.stop_loss, _first_target(candidate)
        if self.position is not None and self.position.signal_id == signal_id:
            self.position.stop, self.position.target = stop, target
        if self.entry is not None and self.entry.signal_id == signal_id:
            self.entry.stop, self.entry.target = stop, target

    def _act(self, candle: Candle, signal_id: UUID, candidate: SignalCandidate) -> None:
        """Turn an allowed BUY, SELL or EXIT into pending fills, against the position as it will be once
        the pending fills are done."""
        now, kind = candle.bucket_end, candidate.signal_type
        ref = _signal_ref(candidate, candle)
        if kind is SignalType.EXIT:
            if self.entry is not None:
                self._cancel(now, "an EXIT signal arrived before the entry filled")
            elif self.position is not None and self.exit is None:
                self.exit = _Exit(ExitReason.EXIT_SIGNAL, now, ref)
            return
        wanted = PositionSide.LONG if kind is SignalType.BUY else PositionSide.SHORT
        current = self._projected()
        if current is wanted:
            return
        if current is not None:
            if self.entry is not None:
                self._cancel(now, f"an opposite {kind.value} signal arrived before the entry filled")
            elif self.position is not None and self.exit is None:
                self.exit = _Exit(ExitReason.OPPOSITE_SIGNAL, now, ref)
            if self.rules.opposite_signal is OppositeSignal.CLOSE:
                return
        if not _side_allowed(self.rules.sides, wanted):
            self._skip(now, kind, f"{wanted.value} trades are not allowed (sides {self.rules.sides.value})")
            return
        self.entry = _Entry(wanted, signal_id, ref, candidate.stop_loss, _first_target(candidate))

    def _projected(self) -> PositionSide | None:
        if self.entry is not None:
            return self.entry.side
        if self.position is not None and self.exit is None:
            return self.position.side
        return None

    # ---- fills -----------------------------------------------------------------------------------------

    def _fill(self, index: int, candle: Candle, reference: Decimal, *, at_close: bool) -> None:
        """Fill the pending exit, then the pending entry, at ``reference``."""
        if self.exit is not None:
            pending, self.exit = self.exit, None
            if self.position is not None:
                self._close(candle, reference, pending.reason, signal=pending.signal)
        if self.entry is not None:
            entry, self.entry = self.entry, None
            self._enter(index, candle, entry, reference, at_close=at_close)

    def _enter(
        self, index: int, candle: Candle, entry: _Entry, reference: Decimal, *, at_close: bool
    ) -> None:
        rules, long = self.rules, entry.side is PositionSide.LONG
        at, kind = candle.bucket_start, entry.signal.signal_type
        stop: Decimal | None = None
        target: Decimal | None = None
        if rules.stop_target is StopTargetSource.SIGNAL:
            stop, target = entry.stop, entry.target
            if stop is not None and _at_stop(reference, stop, long):
                self._skip(
                    at, kind, f"the fill price {reference} was already at or past the stop-loss {stop}"
                )
                return
            if target is not None and _at_target(reference, target, long):
                self._skip(at, kind, f"the fill price {reference} was already at or past the target {target}")
                return
        if self.cash <= 0:
            self._skip(at, kind, f"the equity ({money(self.cash)}) is not positive")
            return
        fill = self._price(reference, buying=long)
        if rules.stop_target is StopTargetSource.PERCENT:
            stop = _offset(fill, rules.stop_pct, up=not long)
            target = _offset(fill, rules.target_pct, up=long)
        units, problem = self._units(fill, stop)
        if problem is not None:
            self._skip(at, kind, problem)
            return
        if fill * units > self.cash:
            self.counts["oversize"] += 1
        self.position = _Position(
            side=entry.side,
            quantity=units,
            entry_at=at,
            entry_reference=reference,
            entry_price=fill,
            entry_fee=self._fee(fill, units),
            stop=stop,
            target=target,
            active_from=index + 1 if at_close else index,
            signal_id=entry.signal_id,
            signal=entry.signal,
        )

    def _units(self, fill: Decimal, stop: Decimal | None) -> tuple[int, str | None]:
        rules = self.rules
        if rules.sizing is SizingMethod.FIXED_QUANTITY:
            assert rules.quantity is not None
            units = rules.quantity
        elif rules.sizing is SizingMethod.FIXED_AMOUNT:
            assert rules.amount is not None
            units = int(rules.amount / fill)
        else:
            assert rules.risk_pct is not None
            if stop is None:
                return 0, "there is no stop-loss to size the risk from"
            risk = abs(fill - stop)
            if not risk:
                return 0, "the stop-loss equals the entry fill, so the risk per unit is zero"
            units = int(self.cash * rules.risk_pct / _HUNDRED / risk)
        lots = units // self.lot * self.lot
        if lots <= 0:
            return 0, f"{rules.sizing.value} sizing gives {units} units, less than one lot of {self.lot}"
        return lots, None

    def _price(self, reference: Decimal, *, buying: bool) -> Decimal:
        """The fill price: the reference moved against the trade by the slippage."""
        price = reference + self.slip if buying else reference - self.slip
        if price <= 0:
            raise BacktestError(
                f"slippage of {self.rules.slippage_ticks} ticks takes a fill at {reference} to {price}"
            )
        return price

    def _fee(self, price: Decimal, units: int) -> Decimal:
        return money(self.rules.fee_pct_per_side * price * units / _HUNDRED + self.rules.fee_per_order)

    @staticmethod
    def _unrealized(position: _Position, price: Decimal) -> Decimal:
        direction = 1 if position.side is PositionSide.LONG else -1
        return (price - position.entry_price) * direction * position.quantity - position.entry_fee

    def _cancel(self, at: datetime, reason: str) -> None:
        assert self.entry is not None
        self._skip(at, self.entry.signal.signal_type, f"cancelled: {reason}")
        self.entry = None

    def _skip(self, at: datetime, kind: SignalType, reason: str) -> None:
        self.skipped_total += 1
        if len(self.skipped) < MAX_SKIPPED:
            self.skipped.append(SkippedEntry(at=at, signal_type=kind, reason=reason))

    # ---- result ----------------------------------------------------------------------------------------

    def result(self, candles: Sequence[Candle], warmup: int) -> BacktestResult:
        last = candles[-1]
        open_position = None
        if self.position is not None:
            position = self.position
            open_position = OpenPosition(
                side=position.side,
                quantity=position.quantity,
                entry_at=position.entry_at,
                entry_price=position.entry_price,
                stop_loss=position.stop,
                target=position.target,
                candles_held=position.held,
                marked_at=last.bucket_end,
                mark_price=last.close_price,
                unrealized_pnl=money(self._unrealized(position, last.close_price)),
                entry_signal=position.signal,
            )
        pending: list[str] = []
        if self.exit is not None:
            pending.append(
                f"{self.exit.reason.value} exit decided at {self.exit.decided_at.isoformat()} had no later "
                "candle to fill on"
            )
        if self.entry is not None:
            pending.append(
                f"{self.entry.side.value} entry from the {self.entry.signal.signal_type.value} signal "
                f"decided at {self.entry.signal.decided_at.isoformat()} had no later candle to fill on"
            )
        metrics = measure(self.trades, initial_capital=self.rules.initial_capital, equity=self.equity)
        counts = self.counts
        summary = BacktestSummary(
            engine_version=ENGINE_VERSION,
            period=BacktestPeriod(
                dataset_from=candles[0].bucket_start,
                dataset_to=last.bucket_end,
                warmup_candles=warmup,
                evaluated_from=candles[warmup].bucket_start,
                evaluated_to=last.bucket_end,
                evaluated_candles=len(candles) - warmup,
            ),
            metrics=metrics,
            signals=SignalStats(
                proposed=counts["proposed"],
                allowed=counts["allowed"],
                blocked=counts["blocked"],
                blocked_by_rule=dict(sorted(self.blocked_by_rule.items())),
                duplicates=counts["duplicates"],
                updates=counts["updates"],
                invalidations=counts["invalidations"],
                expired=counts["expired"],
            ),
            open_position=open_position,
            pending_at_end=tuple(pending),
            skipped_entries=tuple(self.skipped),
            skipped_entries_total=self.skipped_total,
            equity_points=len(self.equity),
            notes=tuple(self._notes(candles, metrics)),
        )
        curve = tuple(EquityPoint(at=at, equity=value) for at, value in sample(self.equity, MAX_CURVE_POINTS))
        return BacktestResult(summary, tuple(self.trades), curve)

    def _notes(self, candles: Sequence[Candle], metrics: BacktestMetrics) -> list[str]:
        rules, counts = self.rules, self.counts
        notes: list[str] = []
        if self.replay.simulated:
            notes.append(
                "The dataset was recorded from the development simulator: these are not market prices."
            )
        if counts["acted"] and not self.metadata.can_emit_actionable:
            notes.append(
                f"{self.metadata.strategy_id} does not emit actionable signals live; its signals were traded "
                "here only to measure them."
            )
        if self.session_blocks:
            states = ", ".join(
                f"{count} {state.value}{_SESSION_STATE_NOTES.get(state, '')}"
                for state, count in sorted(self.session_blocks.items())
            )
            notes.append(
                f"session_status blocked signals decided while the session was not in an allowed state: "
                f"{states}. Live signals are blocked the same way; add the state to the rule's "
                "allowed_states to let them through."
            )
        if rules.fill is FillTiming.SAME_CLOSE:
            notes.append(
                "Decisions filled at the close they were taken at (SAME_CLOSE), a price only known once the "
                "candle had closed, so the results are optimistic."
            )
        if rules.exit_check is ExitCheck.CLOSE and rules.stop_target is not StopTargetSource.NONE:
            notes.append("Stop-loss and target were checked against closes only, not inside candles.")
        if metrics.both_touched_trades:
            notes.append(
                f"In {metrics.both_touched_trades} trades one candle reached both the stop-loss and the "
                "target; the order inside a candle is unknown, so the stop-loss was assumed."
            )
        if counts["oversize"]:
            notes.append(
                f"{counts['oversize']} entries were worth more than the equity at the time. There is no "
                "margin model, so they were taken in full."
            )
        if DataRequirement.VOLUME in self.replay.entry.data_requirements:
            missing = sum(candle.volume is None for candle in candles)
            if missing:
                notes.append(f"{missing} candles have no volume, which the strategy needs.")
        if not self.trades:
            ending = " The strategy proposed no signals." if not counts["proposed"] else ""
            notes.append(f"No trade closed in the evaluated period.{ending}")
        return notes


# ---- helpers ---------------------------------------------------------------------------------------------


def _at_stop(price: Decimal, stop: Decimal, long: bool) -> bool:
    return price <= stop if long else price >= stop


def _at_target(price: Decimal, target: Decimal, long: bool) -> bool:
    return price >= target if long else price <= target


def _first_target(candidate: SignalCandidate) -> Decimal | None:
    return candidate.targets[0].price if candidate.targets else None


def _side_allowed(sides: TradeSides, side: PositionSide) -> bool:
    if sides is TradeSides.BOTH:
        return True
    return (sides is TradeSides.LONG_ONLY) == (side is PositionSide.LONG)


def _offset(fill: Decimal, pct: Decimal | None, *, up: bool) -> Decimal | None:
    """A PERCENT level: ``pct`` % above or below the entry fill; None when unset or not positive."""
    if pct is None:
        return None
    factor = 1 + pct / _HUNDRED if up else 1 - pct / _HUNDRED
    level = fill * factor
    exponent = level.as_tuple().exponent
    if isinstance(exponent, int) and exponent < -8:
        level = level.quantize(_PRICE_STEP, ROUND_HALF_UP)
    return level if level > 0 else None


def _signal_ref(candidate: SignalCandidate, candle: Candle) -> SignalRef:
    return SignalRef(
        signal_type=candidate.signal_type,
        decided_at=candle.bucket_end,
        candle_start=candle.bucket_start,
        entry_price=candidate.entry_price,
        stop_loss=candidate.stop_loss,
        targets=candidate.targets,
        reasons=candidate.reasons,
        indicators={
            value.name: None if value.value is None else str(value.value)
            for value in candidate.indicator_values
        },
    )


def sample(points: Sequence[tuple[datetime, Decimal]], limit: int) -> list[tuple[datetime, Decimal]]:
    """At most ``limit`` points that keep the curve's shape: the first and last points and, in each of
    equal stretches between them, the lowest and highest."""
    if len(points) <= limit:
        return list(points)
    inner = len(points) - 2
    stretches = max((limit - 2) // 2, 1)
    kept = [points[0]]
    for stretch in range(stretches):
        chunk = points[1 + stretch * inner // stretches : 1 + (stretch + 1) * inner // stretches]
        if not chunk:
            continue
        low = min(range(len(chunk)), key=lambda i: chunk[i][1])
        high = max(range(len(chunk)), key=lambda i: chunk[i][1])
        kept.extend(chunk[i] for i in sorted({low, high}))
    kept.append(points[-1])
    return kept
