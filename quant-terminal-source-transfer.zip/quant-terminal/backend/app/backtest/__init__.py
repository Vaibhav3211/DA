"""Backtests (M9; see docs/backtesting.md): historical datasets, the replay engine and its metrics.

Nothing here does I/O. The dataset and backtest services load and store; this package places candles on
the exchange calendar, replays them through a strategy and the risk gate, and measures the trades.
"""
