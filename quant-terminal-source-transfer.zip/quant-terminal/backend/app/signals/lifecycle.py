"""Signal lifecycle rules (spec §17): what a new candidate does to the open signal.

Per deployment and instrument at most one signal is open (GENERATED, ACTIVE or UPDATED):

- An INVALIDATED candidate closes the open signal as INVALIDATED (nothing happens if none is open).
- A candidate of the open signal's type with identical levels is a duplicate and is dropped before
  the risk gate; with changed levels it UPDATEs the open signal once the gate allows it.
- Any other candidate is a new signal. If the gate allows it, it becomes ACTIVE and replaces the open
  signal: SUPERSEDED, or CLOSED when the new signal is an EXIT.
- A candidate the gate blocks is kept as a BLOCKED record for audit; the open signal is left alone.

Open signals EXPIRE at ``valid_until``.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from enum import StrEnum
from uuid import UUID

from app.domain.enums import ACTIONABLE_SIGNAL_TYPES, RiskOutcome, SignalStatus, SignalType
from app.domain.models.signal import RiskDecision, SignalCandidate, TargetLevel
from app.domain.models.strategy import StrategyMetadata

_RATIO_STEP = Decimal("0.01")


class Action(StrEnum):
    NEW = "NEW"
    UPDATE = "UPDATE"
    DUPLICATE = "DUPLICATE"
    INVALIDATE = "INVALIDATE"
    IGNORE = "IGNORE"  # an invalidation with no open signal


@dataclass(frozen=True, slots=True)
class OpenSignal:
    id: UUID
    signal_type: SignalType
    status: SignalStatus
    entry_price: Decimal | None
    stop_loss: Decimal | None
    targets: tuple[TargetLevel, ...]


type Levels = tuple[Decimal | None, Decimal | None, tuple[tuple[str, Decimal], ...]]


def levels(entry: Decimal | None, stop: Decimal | None, targets: tuple[TargetLevel, ...]) -> Levels:
    # Decimal equality ignores trailing zeros, so 100.1 and 100.10 are the same level.
    return entry, stop, tuple((target.label, target.price) for target in targets)


def plan(candidate: SignalCandidate, open_signal: OpenSignal | None) -> Action:
    if candidate.signal_type is SignalType.INVALIDATED:
        return Action.INVALIDATE if open_signal is not None else Action.IGNORE
    if open_signal is None or open_signal.signal_type is not candidate.signal_type:
        return Action.NEW
    current = levels(open_signal.entry_price, open_signal.stop_loss, open_signal.targets)
    proposed = levels(candidate.entry_price, candidate.stop_loss, candidate.targets)
    return Action.DUPLICATE if current == proposed else Action.UPDATE


def replaced_status(new_type: SignalType) -> SignalStatus:
    """What happens to the open signal when a new signal of ``new_type`` replaces it."""
    return SignalStatus.CLOSED if new_type is SignalType.EXIT else SignalStatus.SUPERSEDED


def is_actionable(
    signal_type: SignalType, decision: RiskDecision, metadata: StrategyMetadata, *, simulated: bool
) -> bool:
    """Only an allowed BUY/SELL/EXIT from a strategy that may emit actionable signals, on real data."""
    return (
        signal_type in ACTIONABLE_SIGNAL_TYPES
        and decision.outcome is RiskOutcome.ALLOW
        and metadata.can_emit_actionable
        and not simulated
    )


def risk_reward(candidate: SignalCandidate) -> Decimal | None:
    """Reward to the first target over the risk to the stop-loss, for BUY and SELL."""
    entry, stop = candidate.entry_price, candidate.stop_loss
    if candidate.signal_type not in (SignalType.BUY, SignalType.SELL) or entry is None or stop is None:
        return None
    if not candidate.targets or entry == stop:
        return None
    return (abs(candidate.targets[0].price - entry) / abs(entry - stop)).quantize(_RATIO_STEP)


def valid_until(candidate: SignalCandidate, now: datetime, default_seconds: int) -> datetime:
    return now + timedelta(seconds=candidate.valid_for_seconds or default_seconds)
