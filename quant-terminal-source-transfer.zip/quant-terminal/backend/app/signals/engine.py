"""Signal engine (spec §16-18): turns strategy candidates into risk-gated, persisted signals.

``submit`` takes one batch of proposals from one deployment run and handles it in one transaction. The
kill switch, the risk policy and the deployment's current state are read inside that transaction, so a
pause, a disable or a redeploy applies to the very next candidate. An advisory lock per deployment and
instrument keeps at most one signal open for the pair.

Every gated candidate leaves a risk decision row, and blocked candidates are kept as BLOCKED signals. A
candidate blocked again for the same rules with the same levels is not stored twice. Lifecycle changes
are published on ``qt:signals`` after commit; publishing is best effort because the database is the
source of truth.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

from redis.exceptions import RedisError
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.clock import utc_now
from app.core.config import Settings
from app.core.logging import get_logger
from app.domain.enums import (
    OPEN_SIGNAL_STATUSES,
    MarketRegion,
    RiskOutcome,
    SignalEventType,
    SignalStatus,
    worst_status,
)
from app.domain.events import SignalUpdate
from app.domain.models.instrument import Instrument
from app.domain.models.signal import RiskDecision, Signal, SignalCandidate, TargetLevel
from app.domain.models.strategy import StrategyMetadata
from app.market_data.calendars.service import MarketCalendar
from app.persistence.database import Database
from app.persistence.models.signals import RiskDecisionRow, SignalEventRow, SignalRow
from app.persistence.models.strategies import StrategyDeploymentRow
from app.persistence.models.workspaces import WorkspaceRow
from app.providers.base import describe_error
from app.risk.engine import RiskPolicy, evaluate
from app.risk.rules import (
    MAX_FREQUENCY_SIGNALS,
    MAX_FREQUENCY_WINDOW_MINUTES,
    RecentSignal,
    RiskInput,
    SourceData,
)
from app.services.kill_switch import KillSwitchState, load_kill_switch
from app.services.risk import load_policy
from app.signals.lifecycle import (
    Action,
    OpenSignal,
    is_actionable,
    levels,
    plan,
    replaced_status,
    risk_reward,
    valid_until,
)
from app.streaming.redis_bus import RedisBus, Streams

log = get_logger(__name__)

_OPEN = tuple(sorted(OPEN_SIGNAL_STATUSES))
EXPIRE_BATCH = 500


def _no_universe_problem(_instrument: Instrument) -> str | None:
    return None


@dataclass(frozen=True, slots=True)
class RunContext:
    """The deployment run a batch of candidates comes from."""

    run_id: UUID
    deployment_id: UUID
    workspace_id: UUID
    market_region: MarketRegion
    metadata: StrategyMetadata
    # The configuration the run uses; a batch is blocked once the deployment moves to another one.
    configuration_id: UUID | None = None
    deployment_enabled: bool = True
    deployment_problem: str | None = None
    # Why the workspace universe currently excludes an instrument (None when it takes it).
    universe_problem: Callable[[Instrument], str | None] = _no_universe_problem


class DeploymentGoneError(LookupError):
    """The deployment of a run no longer exists."""


@dataclass(frozen=True, slots=True)
class Proposal:
    """One candidate, the instrument it names and the market data it was computed from."""

    candidate: SignalCandidate
    instrument: Instrument
    source: SourceData
    account_id: UUID | None = None


@dataclass(frozen=True, slots=True)
class Outcome:
    action: Action
    signal_id: UUID | None = None  # the signal created, changed or repeated
    decision: RiskDecision | None = None  # None when the gate was not consulted
    stored: bool = True  # False for duplicates, repeated blocks and ignored invalidations

    @property
    def emitted(self) -> bool:
        """The gate allowed a new signal or an update."""
        return self.stored and self.decision is not None and self.decision.outcome is RiskOutcome.ALLOW

    @property
    def blocked(self) -> bool:
        return self.decision is not None and self.decision.outcome is RiskOutcome.BLOCK


@dataclass(slots=True)
class _Changes:
    """Writes lifecycle events in one transaction and collects the updates to publish after commit."""

    session: AsyncSession
    now: datetime
    updates: list[SignalUpdate] = field(default_factory=list)

    def event(
        self,
        row: SignalRow,
        event_type: SignalEventType,
        from_status: SignalStatus | None,
        details: dict[str, Any] | None = None,
        *,
        to_status: SignalStatus | None = None,
        publish: bool = True,
    ) -> None:
        self.session.add(
            SignalEventRow(
                signal_id=row.id,
                event_type=event_type,
                from_status=from_status,
                to_status=to_status or row.status,
                details=details or {},
                occurred_at=self.now,
            )
        )
        if publish:
            signal = Signal.model_validate(row, from_attributes=True)
            self.updates.append(SignalUpdate(event_type=event_type, signal=signal, at=self.now))

    def transition(
        self, row: SignalRow, status: SignalStatus, event_type: SignalEventType, details: dict[str, Any]
    ) -> None:
        previous = row.status
        row.status = status
        row.updated_at = self.now
        if status not in OPEN_SIGNAL_STATUSES:
            row.closed_at = self.now
        self.event(row, event_type, previous, details)


@dataclass(frozen=True, slots=True)
class _Gate:
    run: RunContext
    kill_switch: KillSwitchState
    policy: RiskPolicy


class SignalEngine:
    def __init__(
        self,
        db: Database,
        bus: RedisBus,
        settings: Settings,
        calendar: MarketCalendar,
        *,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self._db = db
        self._bus = bus
        self._settings = settings
        self._calendar = calendar
        self._clock = clock

    async def submit(self, run: RunContext, proposals: Sequence[Proposal]) -> list[Outcome]:
        if not proposals:
            return []
        async with self._db.transaction() as session:
            changes = _Changes(session, self._clock())
            # A fixed lock order keeps two batches over the same instruments from deadlocking.
            for instrument_id in sorted({proposal.instrument.id for proposal in proposals}):
                await _lock(session, run.deployment_id, instrument_id)
            run = await _current(session, run)
            gate = _Gate(run, await load_kill_switch(session), await load_policy(session, run.workspace_id))
            outcomes = [await self._apply(changes, gate, proposal) for proposal in proposals]
        await self._publish(changes.updates)
        return outcomes

    async def expire(self, *, limit: int = EXPIRE_BATCH) -> int:
        """Expire open signals past ``valid_until``; rows locked by ``submit`` wait for the next sweep."""
        async with self._db.transaction() as session:
            changes = _Changes(session, self._clock())
            result = await session.scalars(
                select(SignalRow)
                .where(
                    SignalRow.closed_at.is_(None),
                    SignalRow.status.in_(_OPEN),
                    SignalRow.valid_until <= changes.now,
                )
                .order_by(SignalRow.valid_until)
                .limit(limit)
                .with_for_update(skip_locked=True)
            )
            expired = result.all()
            for row in expired:
                details = {"valid_until": None if row.valid_until is None else row.valid_until.isoformat()}
                changes.transition(row, SignalStatus.EXPIRED, SignalEventType.EXPIRED, details)
        await self._publish(changes.updates)
        return len(expired)

    async def _apply(self, changes: _Changes, gate: _Gate, proposal: Proposal) -> Outcome:
        session, run, candidate = changes.session, gate.run, proposal.candidate
        instrument_id = proposal.instrument.id
        current = await _open_row(session, run.deployment_id, instrument_id)
        action = plan(candidate, None if current is None else _open_signal(current))
        if action is Action.IGNORE:
            return Outcome(action, stored=False)
        if action is Action.DUPLICATE:
            assert current is not None
            return Outcome(action, current.id, stored=False)
        if action is Action.INVALIDATE:
            assert current is not None
            details = {"reasons": list(candidate.reasons), "explanation": candidate.explanation}
            changes.transition(current, SignalStatus.INVALIDATED, SignalEventType.INVALIDATED, details)
            await session.flush()
            return Outcome(action, current.id)

        is_update = action is Action.UPDATE
        recent = () if is_update else await _recent(session, run.deployment_id, instrument_id, changes.now)
        data = self._risk_input(gate, proposal, changes.now, is_update=is_update, recent=recent)
        decision = evaluate(data, gate.policy, changes.now)
        if decision.outcome is RiskOutcome.BLOCK:
            repeated = await _repeated_block(session, run.deployment_id, instrument_id, candidate, decision)
            if repeated is not None:
                return Outcome(action, repeated, decision, stored=False)
            row = await self._insert(changes, run, proposal, data, decision, SignalStatus.BLOCKED)
            changes.event(
                row, SignalEventType.BLOCKED, SignalStatus.GENERATED, {"reasons": decision.blocking_reasons}
            )
        elif current is not None and is_update:
            row = current
            previous = _levels_json(row)
            self._fill(row, proposal, data, decision, changes.now)
            row.update_count += 1
            changes.transition(row, SignalStatus.UPDATED, SignalEventType.UPDATED, {"previous": previous})
        else:
            row = await self._insert(changes, run, proposal, data, decision, SignalStatus.ACTIVE)
            changes.event(row, SignalEventType.ACTIVATED, SignalStatus.GENERATED)
            if current is not None:
                replaced = replaced_status(candidate.signal_type)
                current.superseded_by = row.id
                changes.transition(
                    current, replaced, SignalEventType(replaced.value), {"replaced_by": str(row.id)}
                )
        session.add(
            RiskDecisionRow(
                signal_id=row.id,
                deployment_id=run.deployment_id,
                instrument_id=instrument_id,
                outcome=decision.outcome,
                checks=[check.model_dump(mode="json") for check in decision.checks],
                evaluated_at=decision.evaluated_at,
            )
        )
        await session.flush()
        return Outcome(action, row.id, decision)

    def _risk_input(
        self,
        gate: _Gate,
        proposal: Proposal,
        now: datetime,
        *,
        is_update: bool,
        recent: tuple[RecentSignal, ...],
    ) -> RiskInput:
        instrument = proposal.instrument
        return RiskInput(
            candidate=proposal.candidate,
            metadata=gate.run.metadata,
            instrument=instrument,
            market_region=gate.run.market_region,
            source=proposal.source,
            session_state=self._calendar.status(instrument.exchange, now).state,
            trading_date=self._calendar.local_date(instrument.exchange, now),
            deployment_enabled=gate.run.deployment_enabled,
            kill_switch_engaged=gate.kill_switch.engaged,
            live_signals_enabled=self._settings.live_signals_enabled,
            kill_switch_reason=gate.kill_switch.reason,
            deployment_problem=gate.run.deployment_problem,
            universe_problem=gate.run.universe_problem(instrument),
            is_update=is_update,
            recent_signals=recent,
        )

    async def _insert(
        self,
        changes: _Changes,
        run: RunContext,
        proposal: Proposal,
        data: RiskInput,
        decision: RiskDecision,
        status: SignalStatus,
    ) -> SignalRow:
        instrument, now = proposal.instrument, changes.now
        row = SignalRow(
            id=uuid4(),
            workspace_id=run.workspace_id,
            market_region=run.market_region,
            instrument_id=instrument.id,
            symbol=instrument.symbol,
            exchange=instrument.exchange,
            segment=instrument.segment,
            strategy_id=run.metadata.strategy_id,
            strategy_version=run.metadata.version,
            deployment_id=run.deployment_id,
            strategy_run_id=run.run_id,
            signal_type=proposal.candidate.signal_type,
            status=status,
            generated_at=now,
            closed_at=None if status in OPEN_SIGNAL_STATUSES else now,
            superseded_by=None,
            update_count=0,
        )
        self._fill(row, proposal, data, decision, now)
        changes.session.add(row)
        await changes.session.flush()  # events and the decision reference the row
        changes.event(row, SignalEventType.GENERATED, None, to_status=SignalStatus.GENERATED, publish=False)
        return row

    def _fill(
        self, row: SignalRow, proposal: Proposal, data: RiskInput, decision: RiskDecision, now: datetime
    ) -> None:
        """Set everything the candidate determines (shared by new signals and updates)."""
        candidate, allowed = proposal.candidate, decision.outcome is RiskOutcome.ALLOW
        simulated = data.uses_simulated_data
        row.provider = proposal.source.provider
        row.account_id = proposal.account_id
        row.is_actionable = is_actionable(candidate.signal_type, decision, data.metadata, simulated=simulated)
        row.entry_price = candidate.entry_price
        row.stop_loss = candidate.stop_loss
        row.targets = [target.model_dump(mode="json") for target in candidate.targets]
        row.risk_reward = risk_reward(candidate)
        row.score = candidate.score
        row.score_definition = candidate.score_definition
        row.updated_at = now
        validity = self._settings.signal_default_validity_seconds
        row.valid_until = valid_until(candidate, now, validity) if allowed else None
        row.source_event_time = candidate.source_event_time or proposal.source.as_of
        row.source_candle_interval = candidate.source_candle_interval
        row.source_candle_start = candidate.source_candle_start
        row.data_status = worst_status(*data.statuses)
        row.reasons = list(candidate.reasons)
        row.indicator_values = [value.model_dump(mode="json") for value in candidate.indicator_values]
        row.invalidation_conditions = list(candidate.invalidation_conditions)
        row.explanation = candidate.explanation
        row.risk_outcome = decision.outcome
        row.risk_decision = decision.model_dump(mode="json")

    async def _publish(self, updates: Sequence[SignalUpdate]) -> None:
        for index, update in enumerate(updates):
            try:
                await self._bus.publish(Streams.SIGNALS, update)
            except (RedisError, OSError) as exc:
                log.warning(
                    "signal_updates_not_published",
                    signal_id=str(update.signal.id),
                    dropped=len(updates) - index,
                    error=describe_error(exc),
                )
                return


async def _lock(session: AsyncSession, deployment_id: UUID, instrument_id: UUID) -> None:
    key = f"signal:{deployment_id}:{instrument_id}"
    await session.execute(select(func.pg_advisory_xact_lock(func.hashtext(key))))


async def _current(session: AsyncSession, run: RunContext) -> RunContext:
    """The run as its deployment stands now. The share lock holds off enabling, disabling and redeploying
    (which lock the row for update) until the batch commits."""
    deployment, workspace = StrategyDeploymentRow, WorkspaceRow
    row = (
        await session.execute(
            select(
                deployment.is_enabled,
                deployment.strategy_version,
                deployment.configuration_id,
                workspace.is_enabled,
                workspace.slug,
            )
            .join(workspace, workspace.id == deployment.workspace_id)
            .where(deployment.id == run.deployment_id)
            .with_for_update(read=True, of=deployment)
        )
    ).first()
    if row is None:
        raise DeploymentGoneError(f"deployment {run.deployment_id} no longer exists")
    enabled, version, configuration_id, workspace_enabled, slug = row
    changed = version != run.metadata.version or (
        run.configuration_id is not None and configuration_id != run.configuration_id
    )
    problem = run.deployment_problem
    if problem is None and changed:
        problem = "the deployment changed after this run started"
    if problem is None and not workspace_enabled:
        problem = f"workspace {slug} is disabled"
    return replace(run, deployment_enabled=run.deployment_enabled and enabled, deployment_problem=problem)


async def _open_row(session: AsyncSession, deployment_id: UUID, instrument_id: UUID) -> SignalRow | None:
    result = await session.scalars(
        select(SignalRow)
        .where(
            SignalRow.deployment_id == deployment_id,
            SignalRow.instrument_id == instrument_id,
            SignalRow.status.in_(_OPEN),
        )
        .order_by(SignalRow.generated_at.desc())
        .limit(1)
        .with_for_update()
    )
    return result.first()


async def _recent(
    session: AsyncSession, deployment_id: UUID, instrument_id: UUID, now: datetime
) -> tuple[RecentSignal, ...]:
    """Allowed signals in the longest frequency window, at most the largest limit per signal type.

    The cap keeps the count exact for any rule settings: the rule only asks whether the matching
    signals reach ``max_signals``, which never exceeds ``MAX_FREQUENCY_SIGNALS``.
    """
    rank = func.row_number().over(partition_by=SignalRow.signal_type, order_by=SignalRow.generated_at.desc())
    ranked = (
        select(SignalRow.generated_at, SignalRow.signal_type, rank.label("rank"))
        .where(
            SignalRow.deployment_id == deployment_id,
            SignalRow.instrument_id == instrument_id,
            SignalRow.risk_outcome == RiskOutcome.ALLOW,
            SignalRow.generated_at > now - timedelta(minutes=MAX_FREQUENCY_WINDOW_MINUTES),
        )
        .subquery()
    )
    result = await session.execute(
        select(ranked.c.generated_at, ranked.c.signal_type).where(ranked.c.rank <= MAX_FREQUENCY_SIGNALS)
    )
    return tuple(RecentSignal(generated_at, signal_type) for generated_at, signal_type in result)


async def _repeated_block(
    session: AsyncSession,
    deployment_id: UUID,
    instrument_id: UUID,
    candidate: SignalCandidate,
    decision: RiskDecision,
) -> UUID | None:
    """The latest signal for the pair when it is the same candidate blocked by the same rules."""
    latest = await session.scalar(
        select(SignalRow)
        .where(SignalRow.deployment_id == deployment_id, SignalRow.instrument_id == instrument_id)
        .order_by(SignalRow.generated_at.desc())
        .limit(1)
    )
    if latest is None or latest.status is not SignalStatus.BLOCKED:
        return None
    if latest.signal_type is not candidate.signal_type:
        return None
    if levels(latest.entry_price, latest.stop_loss, _targets(latest)) != levels(
        candidate.entry_price, candidate.stop_loss, candidate.targets
    ):
        return None
    previous = RiskDecision.model_validate(latest.risk_decision)
    return latest.id if _blocking_rules(previous) == _blocking_rules(decision) else None


def _blocking_rules(decision: RiskDecision) -> frozenset[str]:
    return frozenset(
        check.rule for check in decision.checks if not check.passed and check.severity == "BLOCK"
    )


def _targets(row: SignalRow) -> tuple[TargetLevel, ...]:
    return tuple(TargetLevel.model_validate(target) for target in row.targets)


def _open_signal(row: SignalRow) -> OpenSignal:
    return OpenSignal(
        id=row.id,
        signal_type=row.signal_type,
        status=row.status,
        entry_price=row.entry_price,
        stop_loss=row.stop_loss,
        targets=_targets(row),
    )


def _levels_json(row: SignalRow) -> dict[str, Any]:
    return {
        "entry_price": _text(row.entry_price),
        "stop_loss": _text(row.stop_loss),
        "targets": list(row.targets),
    }


def _text(value: Decimal | None) -> str | None:
    # Stored prices carry the column scale (100.10000000); event details show them as 100.1.
    return None if value is None else format(value.normalize(), "f")
