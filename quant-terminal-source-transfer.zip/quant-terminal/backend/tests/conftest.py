"""Shared test helpers. Unit tests never read the developer's .env file."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

from app.core.config import Settings

TEST_DATABASE_URL = "postgresql://qt:qt@localhost:5432/qt_unit_tests"


def build_settings(**overrides: Any) -> Settings:
    values: dict[str, Any] = {"database_url": TEST_DATABASE_URL, "log_json": False}
    values.update(overrides)
    return Settings(_env_file=None, **values)


@pytest.fixture
def make_settings() -> Callable[..., Settings]:
    return build_settings
