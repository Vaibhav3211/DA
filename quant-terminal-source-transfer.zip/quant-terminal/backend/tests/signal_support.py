"""Shared fixtures for strategy, risk and signal tests."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from app.domain.enums import (
    CandleInterval,
    DataStatus,
    Exchange,
    InstrumentType,
    MarketRegion,
    Segment,
    SignalType,
)
from app.domain.models.instrument import Instrument
from app.domain.models.signal import IndicatorValue, SignalCandidate, TargetLevel
from app.domain.models.strategy import StrategyMetadata
from tests.candle_support import INSTRUMENT

ALPHA = Instrument(
    id=INSTRUMENT,
    canonical_key="NSE:CASH:ALPHA",
    exchange=Exchange.NSE,
    segment=Segment.CASH,
    instrument_type=InstrumentType.EQUITY,
    symbol="ALPHA",
    tick_size=Decimal("0.05"),
)
METADATA = StrategyMetadata(
    strategy_id="test.gate",
    name="Gate fixture",
    description="Risk gate fixture",
    version="1.0.0",
    author="tests",
    markets=(MarketRegion.INDIA,),
    segments=(Segment.CASH,),
    instrument_types=(InstrumentType.EQUITY,),
    candle_intervals=(CandleInterval.M1,),
    can_emit_actionable=True,
)


def make_indicator(status: DataStatus = DataStatus.LIVE) -> IndicatorValue:
    return IndicatorValue(
        name="ema_fast", indicator="ema", version="1", value=Decimal(100), data_status=status
    )


def make_candidate(**overrides: Any) -> SignalCandidate:
    """A clean BUY on ALPHA: entry 100.10, stop 98.05, T1 104.20 (risk-reward 2.00)."""
    fields: dict[str, Any] = {
        "instrument_id": INSTRUMENT,
        "signal_type": SignalType.BUY,
        "reasons": ("fast EMA crossed above slow EMA",),
        "explanation": "Bullish EMA crossover",
        "entry_price": Decimal("100.10"),
        "stop_loss": Decimal("98.05"),
        "targets": (TargetLevel(label="T1", price=Decimal("104.20")),),
        "indicator_values": (make_indicator(),),
    }
    fields.update(overrides)
    return SignalCandidate(**fields)
