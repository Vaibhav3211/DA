"""Provider login flows against PostgreSQL and Redis. Zerodha and Groww are ``httpx`` fakes."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import parse_qs, urlencode, urlsplit
from uuid import UUID, uuid4

import httpx
import pytest
from pydantic import SecretStr

from app.container import Container
from app.core.errors import (
    AppError,
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitedError,
    ServiceUnavailableError,
    ValidationFailedError,
)
from app.core.security import hash_token
from app.domain.enums import AccountStatus, AuthMethod, CredentialKind, Provider
from app.domain.events import CommandType
from app.persistence.models import ProviderTokenMetadataRow
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderProtocolError,
    ProviderRequestRejectedError,
)
from app.providers.groww.totp import totp_code
from app.services.audit import CLI_ACTOR
from app.services.provider_accounts import ProviderAccountService, ProviderAccountView
from app.services.provider_auth import (
    GROWW_DAILY_TOKEN_LIMIT,
    LOGIN_STATE_TTL,
    ProviderAuthService,
    ZerodhaLoginStart,
)
from app.streaming.redis_bus import Keys
from tests.integration.provider_support import (
    ACTOR,
    KITE_LOGIN_URL,
    NOW,
    REDIRECT_URL,
    FakeClock,
    FakeProvider,
    Reply,
    account_service,
    audit_entries,
    failure,
    groww_failure,
    groww_jwt,
    groww_ok,
    kite_error,
    kite_ok,
    provider_settings,
    store_token,
    token_metadata,
    worker_commands,
)

pytestmark = pytest.mark.integration

API_KEY = CredentialKind.API_KEY
API_SECRET = CredentialKind.API_SECRET
ACCESS_TOKEN = CredentialKind.ACCESS_TOKEN
TOTP_SECRET = CredentialKind.TOTP_SECRET
CONNECT = CommandType.CONNECT_ACCOUNT
DISCONNECT = CommandType.DISCONNECT_ACCOUNT
CLIENT_IP = "203.0.113.7"
# Both providers' tokens lapse at 06:00 IST; NOW is 09:30 IST, so the next reset is tomorrow's.
NEXT_RESET = datetime(2026, 1, 6, 0, 30, tzinfo=UTC)

KITE_KEY = "kiteapikey1234"
KITE_SECRET = "kitesecret5678"
KITE_USER = "AB1234"
KITE_TOKEN = "kiteaccesstoken01"
REQUEST_TOKEN = "reqtoken1234abcd"
SESSION = ("POST", "/session/token")
LOGOUT = ("DELETE", "/session/token")

GROWW_KEYS = {API_KEY: "growwapikey123", API_SECRET: "growwsecret456"}
GROWW_USER = "GW1234"
TOTP_SEED = "JBSWY3DPEHPK3PXP"
PROFILE = ("GET", "/v1/user/detail")
CREATE_TOKEN = ("POST", "/v1/token/api/access")


@pytest.fixture
def remote() -> FakeProvider:
    return FakeProvider()


@pytest.fixture
def auth(accounts: ProviderAccountService, remote: FakeProvider) -> ProviderAuthService:
    return ProviderAuthService(accounts, transport=remote.transport)


async def kite_account(
    accounts: ProviderAccountService, label: str = "Main", *, enabled: bool = False
) -> ProviderAccountView:
    view = await accounts.create(Provider.ZERODHA, label, actor=ACTOR)
    view = await accounts.set_credentials(view.id, {API_KEY: KITE_KEY, API_SECRET: KITE_SECRET}, actor=ACTOR)
    return await accounts.set_enabled(view.id, True, actor=ACTOR) if enabled else view


async def groww_account(
    accounts: ProviderAccountService,
    method: AuthMethod,
    credentials: dict[CredentialKind, str] | None = None,
    *,
    label: str = "Main",
    enabled: bool = False,
) -> ProviderAccountView:
    view = await accounts.create(Provider.GROWW, label, auth_method=method, actor=ACTOR)
    if credentials:
        view = await accounts.set_credentials(view.id, credentials, actor=ACTOR)
    return await accounts.set_enabled(view.id, True, actor=ACTOR) if enabled else view


def keyless_auth(container: Container, clock: FakeClock, remote: FakeProvider) -> ProviderAuthService:
    """Deployment-level Zerodha keys, but no encryption key to store an access token with."""
    settings = provider_settings(
        container.settings, zerodha_api_key=SecretStr(KITE_KEY), zerodha_api_secret=SecretStr(KITE_SECRET)
    )
    accounts = ProviderAccountService(container.db, container.bus, settings, None, clock=clock)
    return ProviderAuthService(accounts, transport=remote.transport)


def login_state(start: ZerodhaLoginStart) -> str:
    query = parse_qs(urlsplit(start.login_url).query)
    return parse_qs(query["redirect_params"][0])["state"][0]


def pending_key(state: str) -> str:
    return Keys.zerodha_pending_login(hash_token(state))


def callback(state: str) -> str:
    """The address Kite sends the browser to after a successful login."""
    query = {"action": "login", "type": "login", "status": "success", "request_token": REQUEST_TOKEN}
    return f"{REDIRECT_URL}?{urlencode({**query, 'state': state})}"


def kite_session(user_id: str = KITE_USER, access_token: str = KITE_TOKEN) -> Reply:
    # login_time is IST without an offset (03:55 UTC)
    session = {"user_id": user_id, "access_token": access_token, "login_time": "2026-01-05 09:25:00"}
    return kite_ok({**session, "exchanges": ["NSE", "BSE"], "products": ["CNC", "MIS"]})


def created(token: str) -> Reply:
    """Groww's access-token response, which is not wrapped in the usual envelope."""
    return lambda _request: httpx.Response(200, json={"token": token})


def refuse(request: httpx.Request) -> httpx.Response:
    raise httpx.ConnectError("connection refused", request=request)


def form(request: httpx.Request) -> dict[str, str]:
    return {name: values[0] for name, values in parse_qs(request.content.decode()).items()}


async def stored_token(accounts: ProviderAccountService, account_id: UUID) -> str | None:
    return (await accounts.resolve_secrets(account_id, include_token=True)).get(ACCESS_TOKEN)


async def command_types(container: Container) -> list[CommandType]:
    return [command.type for command in await worker_commands(container.bus)]


async def last_audit(container: Container, account_id: UUID) -> tuple[str, str, str | None, dict[str, Any]]:
    entry = (await audit_entries(container.db, account_id))[-1]
    return entry.action, entry.actor, entry.client_ip, entry.details


# ---- Zerodha login ----------------------------------------------------------------------------------


async def test_begin_zerodha_login_returns_the_kite_url_with_a_one_time_state(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    account = await kite_account(accounts)

    start = await auth.begin_zerodha_login(account.id, actor=ACTOR)

    assert (start.account_id, start.redirect_url) == (account.id, REDIRECT_URL)
    assert start.expires_at == NOW + LOGIN_STATE_TTL
    url = urlsplit(start.login_url)
    assert f"{url.scheme}://{url.netloc}{url.path}" == KITE_LOGIN_URL
    query = parse_qs(url.query)
    assert (query["v"], query["api_key"]) == (["3"], [KITE_KEY])
    state = login_state(start)
    pending = {"account_id": str(account.id), "actor": ACTOR, "created_at": NOW.isoformat()}
    assert await container.bus.get_json(pending_key(state)) == pending
    assert 0 < await container.bus.redis.ttl(pending_key(state)) <= LOGIN_STATE_TTL.total_seconds()
    assert not any(state in str(key) for key in await container.bus.redis.keys("*"))  # only its hash
    assert login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR)) != state
    assert remote.requests == []


async def test_begin_zerodha_login_checks_what_completing_it_will_need(
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    clock: FakeClock,
    remote: FakeProvider,
) -> None:
    bare = await accounts.create(Provider.ZERODHA, "Bare", actor=ACTOR)
    error = await failure(
        auth.begin_zerodha_login(bare.id, actor=ACTOR), ValidationFailedError, "credentials_missing"
    )
    assert "API key" in error.message
    await accounts.set_credentials(bare.id, {API_KEY: KITE_KEY}, actor=ACTOR)
    error = await failure(
        auth.begin_zerodha_login(bare.id, actor=ACTOR), ValidationFailedError, "credentials_missing"
    )
    assert "API secret" in error.message
    groww = await accounts.create(Provider.GROWW, "Main", actor=ACTOR)
    await failure(auth.begin_zerodha_login(groww.id, actor=ACTOR), ValidationFailedError, "wrong_provider")
    await failure(auth.begin_zerodha_login(uuid4(), actor=ACTOR), NotFoundError, "provider_account_not_found")

    env_keys = await accounts.create(Provider.ZERODHA, "Env", actor=ACTOR)
    keyless = keyless_auth(container, clock, remote)
    await failure(
        keyless.begin_zerodha_login(env_keys.id, actor=ACTOR),
        ServiceUnavailableError,
        "encryption_not_configured",
    )
    ready = await kite_account(accounts)
    unconfigured = ProviderAuthService(account_service(container, clock, zerodha_redirect_url=" "))
    await failure(
        unconfigured.begin_zerodha_login(ready.id, actor=ACTOR),
        ServiceUnavailableError,
        "zerodha_redirect_not_configured",
    )
    assert await container.bus.redis.keys("qt:zerodha:pending:*") == []


@pytest.mark.parametrize(
    "template",
    [
        "{redirect}?action=login&type=login&status=success&request_token={token}&state={state}",
        "action=login&type=login&status=success&request_token={token}&state={state}",
        "?request_token={token}&state={state}",
        "  {shouted}/?state={state}&request_token={token}\n",
    ],
    ids=["redirect-url", "query-string", "bare-query", "case-slash-and-whitespace"],
)
async def test_complete_zerodha_login_accepts_the_redirect_url_or_its_query_string(
    template: str, auth: ProviderAuthService, accounts: ProviderAccountService, remote: FakeProvider
) -> None:
    account = await kite_account(accounts)
    state = login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR))
    remote.routes[SESSION] = kite_session()
    shouted = REDIRECT_URL.replace("http://", "HTTP://", 1)
    pasted = template.format(redirect=REDIRECT_URL, shouted=shouted, token=REQUEST_TOKEN, state=state)

    view = await auth.complete_zerodha_login(pasted, actor=ACTOR)

    assert (view.status, view.provider_user_ref) == (AccountStatus.AUTHENTICATED, KITE_USER)
    assert await stored_token(accounts, account.id) == KITE_TOKEN


async def test_completed_zerodha_login_stores_the_session_and_reconnects_the_worker(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    account = await kite_account(accounts, enabled=True)
    state = login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR))
    remote.routes[SESSION] = kite_session()

    view = await auth.complete_zerodha_login(callback(state), actor=ACTOR, client_ip=CLIENT_IP)

    assert (view.status, view.has_access_token, view.provider_user_ref) == (
        AccountStatus.AUTHENTICATED,
        True,
        KITE_USER,
    )
    assert (view.last_auth_at, view.token_expires_at, view.updated_by) == (NOW, NEXT_RESET, ACTOR)
    assert view == await accounts.get(account.id)
    assert await stored_token(accounts, account.id) == KITE_TOKEN
    (request,) = remote.requests
    assert (request.method, request.url.path, request.headers["X-Kite-Version"]) == (*SESSION, "3")
    assert "Authorization" not in request.headers
    checksum = hashlib.sha256(f"{KITE_KEY}{REQUEST_TOKEN}{KITE_SECRET}".encode()).hexdigest()
    assert form(request) == {"api_key": KITE_KEY, "request_token": REQUEST_TOKEN, "checksum": checksum}
    (token,) = await token_metadata(container.db, account.id)
    assert (token.auth_method, token.issued_at, token.expires_at, token.revoked_at) == (
        AuthMethod.ZERODHA_LOGIN_REDIRECT,
        NOW,
        NEXT_RESET,
        None,
    )
    assert token.fingerprint == hash_token(KITE_TOKEN)[:16]
    details = {
        "provider": "ZERODHA",
        "label": "Main",
        "user_ref": KITE_USER,
        "expires_at": NEXT_RESET.isoformat(),
    }
    assert await last_audit(container, account.id) == ("provider_account.login", ACTOR, CLIENT_IP, details)
    assert await command_types(container) == [CONNECT, CONNECT]  # enabling, then the new session
    assert await container.bus.get_json(pending_key(state)) is None


@pytest.mark.parametrize(
    "target",
    [
        "https://127.0.0.1:8000/api/v1/providers/zerodha/callback",
        "http://localhost:8000/api/v1/providers/zerodha/callback",
        "http://127.0.0.1:8001/api/v1/providers/zerodha/callback",
        "http://127.0.0.1:8000/api/v1/providers/zerodha/callback/other",
        "http://127.0.0.1:99999/api/v1/providers/zerodha/callback",
    ],
    ids=["scheme", "host", "port", "path", "invalid-port"],
)
async def test_complete_zerodha_login_only_accepts_the_configured_redirect_url(
    target: str,
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    remote: FakeProvider,
) -> None:
    account = await kite_account(accounts)
    state = login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR))
    pasted = f"{target}?status=success&request_token={REQUEST_TOKEN}&state={state}"

    await failure(
        auth.complete_zerodha_login(pasted, actor=ACTOR), ValidationFailedError, "redirect_url_mismatch"
    )

    assert remote.requests == []
    assert await container.bus.get_json(pending_key(state)) is not None  # the login can still finish


@pytest.mark.parametrize(
    ("query", "error", "code"),
    [
        (
            "status=cancelled&request_token={token}&state={state}",
            ProviderRequestRejectedError,
            "provider_rejected",
        ),
        ("status=success&state={state}", ValidationFailedError, "validation_failed"),
        ("request_token=not-a-token&state={state}", ValidationFailedError, "validation_failed"),
        (
            "request_token={token}&request_token={token}&state={state}",
            ValidationFailedError,
            "validation_failed",
        ),
        ("request_token={token}", ValidationFailedError, "login_state_missing"),
    ],
    ids=["login-cancelled", "no-request-token", "malformed-request-token", "repeated-parameter", "no-state"],
)
async def test_unusable_redirects_are_rejected_without_using_up_the_login(
    query: str,
    error: type[AppError],
    code: str,
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    remote: FakeProvider,
) -> None:
    account = await kite_account(accounts)
    state = login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR))

    await failure(
        auth.complete_zerodha_login(query.format(token=REQUEST_TOKEN, state=state), actor=ACTOR), error, code
    )

    assert remote.requests == []
    assert await container.bus.get_json(pending_key(state)) is not None


async def test_login_states_are_single_use_and_must_be_intact(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    account = await kite_account(accounts)
    remote.routes[SESSION] = kite_session()
    url = callback(login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR)))
    await auth.complete_zerodha_login(url, actor=ACTOR)

    await failure(auth.complete_zerodha_login(url, actor=ACTOR), ValidationFailedError, "login_state_invalid")
    await failure(
        auth.complete_zerodha_login(callback("neverissued"), actor=ACTOR),
        ValidationFailedError,
        "login_state_invalid",
    )
    tampered: list[dict[str, Any]] = [
        {"account_id": "not-a-uuid", "actor": ACTOR},
        {"account_id": str(account.id)},
        {"account_id": str(account.id), "actor": 7},
    ]
    for payload in tampered:
        await container.bus.set_json(pending_key("tampered"), payload)
        await failure(
            auth.complete_zerodha_login(callback("tampered"), actor=ACTOR),
            ValidationFailedError,
            "login_state_invalid",
        )
    deleted = await kite_account(accounts, "Deleted")
    url = callback(login_state(await auth.begin_zerodha_login(deleted.id, actor=ACTOR)))
    await accounts.delete(deleted.id, actor=ACTOR)
    await failure(auth.complete_zerodha_login(url, actor=ACTOR), NotFoundError, "provider_account_not_found")
    assert len(remote.requests) == 1


async def test_only_whoever_started_a_login_can_finish_it(
    auth: ProviderAuthService, accounts: ProviderAccountService, remote: FakeProvider
) -> None:
    account = await kite_account(accounts)
    remote.routes[SESSION] = kite_session()
    url = callback(login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR)))

    error = await failure(
        auth.complete_zerodha_login(url, actor="user:mallory"), PermissionDeniedError, "login_state_mismatch"
    )
    assert error.message == "This login was started by another user"
    assert (await auth.complete_zerodha_login(url, actor=ACTOR)).status is AccountStatus.AUTHENTICATED

    url = callback(login_state(await auth.begin_zerodha_login(account.id, actor=CLI_ACTOR)))
    error = await failure(
        auth.complete_zerodha_login(url, actor=ACTOR), PermissionDeniedError, "login_state_mismatch"
    )
    assert "qt zerodha login" in error.message
    assert (await auth.complete_zerodha_login(url, actor=CLI_ACTOR)).updated_by == CLI_ACTOR
    assert len(remote.requests) == 2


@pytest.mark.parametrize(
    "logout",
    [kite_ok(True), kite_error(500, "GeneralException", "Service unavailable")],
    ids=["logged-out", "logout-failed"],
)
async def test_a_login_as_another_zerodha_user_is_logged_out_and_rejected(
    logout: Reply,
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    remote: FakeProvider,
) -> None:
    account = await kite_account(accounts)
    await store_token(accounts, account.id, "previouskitetoken", expires_at=NEXT_RESET, user_ref=KITE_USER)
    remote.routes[SESSION] = kite_session(user_id="XY9876", access_token="otherusertoken")
    remote.routes[LOGOUT] = logout
    url = callback(login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR)))

    error = await failure(
        auth.complete_zerodha_login(url, actor=ACTOR), ConflictError, "provider_user_mismatch"
    )

    assert KITE_USER in error.message
    assert "XY9876" in error.message
    assert remote.paths() == [SESSION, LOGOUT]
    assert dict(remote.requests[1].url.params) == {"api_key": KITE_KEY, "access_token": "otherusertoken"}
    view = await accounts.get(account.id)
    assert (view.status, view.provider_user_ref) == (AccountStatus.AUTHENTICATED, KITE_USER)
    assert await stored_token(accounts, account.id) == "previouskitetoken"
    assert "provider_account.login" not in [
        entry.action for entry in await audit_entries(container.db, account.id)
    ]


@pytest.mark.parametrize(
    ("reply", "error", "code"),
    [
        (
            kite_error(403, "TokenException", "Token is invalid or has expired."),
            ProviderAuthRequiredError,
            "provider_auth_required",
        ),
        (
            kite_error(400, "InputException", "Invalid checksum"),
            ProviderRequestRejectedError,
            "provider_rejected",
        ),
        (kite_ok({"user_id": KITE_USER}), ProviderProtocolError, "provider_protocol_error"),
    ],
    ids=["request-token-expired", "bad-checksum", "no-access-token"],
)
async def test_a_failed_token_exchange_stores_nothing(
    reply: Reply,
    error: type[AppError],
    code: str,
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    remote: FakeProvider,
) -> None:
    account = await kite_account(accounts)
    remote.routes[SESSION] = reply
    url = callback(login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR)))

    await failure(auth.complete_zerodha_login(url, actor=ACTOR), error, code)

    view = await accounts.get(account.id)
    assert (view.status, view.has_access_token) == (AccountStatus.AUTH_REQUIRED, False)
    assert await token_metadata(container.db, account.id) == []
    # Kite request tokens are single use as well, so trying again needs a new login.
    await failure(auth.complete_zerodha_login(url, actor=ACTOR), ValidationFailedError, "login_state_invalid")


# ---- Groww access tokens ----------------------------------------------------------------------------


async def test_set_groww_token_verifies_the_token_and_binds_the_groww_user(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    account = await groww_account(accounts, AuthMethod.GROWW_ACCESS_TOKEN, enabled=True)
    expiry = NOW + timedelta(hours=10)
    token = groww_jwt(expiry)
    remote.routes[PROFILE] = groww_ok({"ucc": GROWW_USER, "nse_enabled": True, "active_segments": ["CASH"]})

    view = await auth.set_groww_token(account.id, f"  Bearer {token}\n", actor=ACTOR, client_ip=CLIENT_IP)

    assert (view.status, view.provider_user_ref, view.token_expires_at) == (
        AccountStatus.AUTHENTICATED,
        GROWW_USER,
        expiry,
    )
    assert await stored_token(accounts, account.id) == token
    (request,) = remote.requests
    assert request.headers["Authorization"] == f"Bearer {token}"
    (metadata,) = await token_metadata(container.db, account.id)
    assert (metadata.auth_method, metadata.expires_at) == (AuthMethod.GROWW_ACCESS_TOKEN, expiry)
    details = {"provider": "GROWW", "label": "Main", "user_ref": GROWW_USER, "expires_at": expiry.isoformat()}
    expected = ("provider_account.token_set", ACTOR, CLIENT_IP, {**details, "verified": True})
    assert await last_audit(container, account.id) == expected
    assert await command_types(container) == [CONNECT, CONNECT]


async def test_set_groww_token_without_verification_assumes_the_daily_reset(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    account = await groww_account(accounts, AuthMethod.GROWW_TOTP)

    view = await auth.set_groww_token(account.id, "opaquegrowwtoken", verify=False, actor=ACTOR)

    assert remote.requests == []
    assert (view.status, view.token_expires_at, view.provider_user_ref) == (
        AccountStatus.AUTHENTICATED,
        NEXT_RESET,
        None,
    )
    assert view.auth_method is AuthMethod.GROWW_TOTP
    # Recorded as a pasted token, so it does not use up the daily budget for created tokens.
    (metadata,) = await token_metadata(container.db, account.id)
    assert metadata.auth_method is AuthMethod.GROWW_ACCESS_TOKEN
    action, _, _, details = await last_audit(container, account.id)
    assert (action, details["verified"], details["user_ref"]) == ("provider_account.token_set", False, None)
    assert await command_types(container) == []


async def test_set_groww_token_rejects_unusable_tokens(
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    clock: FakeClock,
    remote: FakeProvider,
) -> None:
    account = await groww_account(accounts, AuthMethod.GROWW_ACCESS_TOKEN)
    kite = await accounts.create(Provider.ZERODHA, "Main", actor=ACTOR)

    for pasted in ("  \n", "two words", "x" * 4097):
        await failure(
            auth.set_groww_token(account.id, pasted, actor=ACTOR), ValidationFailedError, "invalid_token"
        )
    await failure(
        auth.set_groww_token(account.id, groww_jwt(NOW), actor=ACTOR), ValidationFailedError, "token_expired"
    )
    await failure(
        auth.set_groww_token(kite.id, "growwtoken", actor=ACTOR), ValidationFailedError, "wrong_provider"
    )
    await failure(
        auth.set_groww_token(uuid4(), "growwtoken", actor=ACTOR), NotFoundError, "provider_account_not_found"
    )
    keyless = keyless_auth(container, clock, remote)
    await failure(
        keyless.set_groww_token(account.id, "growwtoken", actor=ACTOR),
        ServiceUnavailableError,
        "encryption_not_configured",
    )
    assert remote.requests == []
    remote.routes[PROFILE] = groww_failure(401, "GA005", "Invalid access token")
    await failure(
        auth.set_groww_token(account.id, "growwtoken", actor=ACTOR),
        ValidationFailedError,
        "provider_token_rejected",
    )
    remote.routes[PROFILE] = groww_failure(403, "GA003", "No active Trading API subscription")
    await failure(
        auth.set_groww_token(account.id, "growwtoken", actor=ACTOR),
        ProviderRequestRejectedError,
        "provider_rejected",
    )

    view = await accounts.get(account.id)
    assert (view.status, view.has_access_token) == (AccountStatus.AUTH_REQUIRED, False)
    assert await token_metadata(container.db, account.id) == []


async def test_a_groww_token_for_another_user_is_rejected(
    auth: ProviderAuthService, accounts: ProviderAccountService, remote: FakeProvider
) -> None:
    account = await groww_account(accounts, AuthMethod.GROWW_ACCESS_TOKEN)
    remote.routes[PROFILE] = groww_ok({"ucc": GROWW_USER})
    await auth.set_groww_token(account.id, "firstgrowwtoken", actor=ACTOR)
    remote.routes[PROFILE] = groww_ok({"vendor_user_id": "GW9876"})

    error = await failure(
        auth.set_groww_token(account.id, "othergrowwtoken", actor=ACTOR),
        ConflictError,
        "provider_user_mismatch",
    )

    assert "GW9876" in error.message
    assert await stored_token(accounts, account.id) == "firstgrowwtoken"
    # An unverified token cannot be matched to a user; the account stays bound to the first one.
    view = await auth.set_groww_token(account.id, "thirdgrowwtoken", verify=False, actor=ACTOR)
    assert (view.provider_user_ref, len(remote.requests)) == (GROWW_USER, 2)


async def test_create_groww_token_with_an_approved_api_key(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    account = await groww_account(accounts, AuthMethod.GROWW_API_KEY_SECRET, GROWW_KEYS, enabled=True)
    expiry = NOW + timedelta(hours=20)
    token = groww_jwt(expiry)
    remote.routes[CREATE_TOKEN] = created(token)

    view = await auth.create_groww_token(account.id, actor=ACTOR, client_ip=CLIENT_IP)

    (request,) = remote.requests
    assert request.headers["Authorization"] == f"Bearer {GROWW_KEYS[API_KEY]}"
    timestamp = int(NOW.timestamp())
    checksum = hashlib.sha256(f"{GROWW_KEYS[API_SECRET]}{timestamp}".encode()).hexdigest()
    assert json.loads(request.content) == {
        "key_type": "approval",
        "checksum": checksum,
        "timestamp": timestamp,
    }
    assert (view.status, view.token_expires_at, view.provider_user_ref) == (
        AccountStatus.AUTHENTICATED,
        expiry,
        None,
    )
    assert await stored_token(accounts, account.id) == token
    (metadata,) = await token_metadata(container.db, account.id)
    assert metadata.auth_method is AuthMethod.GROWW_API_KEY_SECRET
    details = {"provider": "GROWW", "label": "Main", "user_ref": None, "expires_at": expiry.isoformat()}
    expected = (
        "provider_account.token_created",
        ACTOR,
        CLIENT_IP,
        {**details, "method": "GROWW_API_KEY_SECRET"},
    )
    assert await last_audit(container, account.id) == expected
    assert await command_types(container) == [CONNECT, CONNECT]
    await failure(
        auth.create_groww_token(account.id, code="123456", actor=ACTOR),
        ValidationFailedError,
        "totp_not_applicable",
    )


async def test_create_groww_token_with_an_authenticator_code(
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    clock: FakeClock,
    remote: FakeProvider,
) -> None:
    account = await groww_account(accounts, AuthMethod.GROWW_TOTP, {API_KEY: "growwtotptoken"})
    remote.routes[CREATE_TOKEN] = created("totpgrowwtoken")

    await failure(
        auth.create_groww_token(account.id, actor=ACTOR), ValidationFailedError, "totp_code_required"
    )
    await failure(
        auth.create_groww_token(account.id, code="12ab56", actor=ACTOR),
        ValidationFailedError,
        "validation_failed",
    )
    assert remote.requests == []
    await auth.create_groww_token(account.id, code=" 123456 ", actor=ACTOR)
    await accounts.set_credentials(account.id, {TOTP_SECRET: TOTP_SEED}, actor=ACTOR)
    clock.advance(timedelta(minutes=1))
    view = await auth.create_groww_token(account.id, actor=ACTOR)  # the code comes from the stored secret

    generated = totp_code(TOTP_SEED, now=clock())
    bodies = [json.loads(request.content) for request in remote.requests]
    assert bodies == [{"key_type": "totp", "totp": "123456"}, {"key_type": "totp", "totp": generated}]
    assert {request.headers["Authorization"] for request in remote.requests} == {"Bearer growwtotptoken"}
    assert (view.status, view.token_expires_at) == (AccountStatus.AUTHENTICATED, NEXT_RESET)
    tokens = await token_metadata(container.db, account.id)
    assert [(token.auth_method, token.revoked_at) for token in tokens] == [
        (AuthMethod.GROWW_TOTP, clock()),
        (AuthMethod.GROWW_TOTP, None),
    ]


async def test_create_groww_token_needs_an_api_key_method_and_its_credentials(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    pasted = await groww_account(accounts, AuthMethod.GROWW_ACCESS_TOKEN)
    await failure(auth.create_groww_token(pasted.id, actor=ACTOR), ValidationFailedError, "use_set_token")
    approval = await groww_account(
        accounts, AuthMethod.GROWW_API_KEY_SECRET, {API_KEY: GROWW_KEYS[API_KEY]}, label="Approval"
    )
    error = await failure(
        auth.create_groww_token(approval.id, actor=ACTOR), ValidationFailedError, "credentials_missing"
    )
    assert "API secret" in error.message
    totp = await groww_account(accounts, AuthMethod.GROWW_TOTP, label="Totp")
    error = await failure(
        auth.create_groww_token(totp.id, code="123456", actor=ACTOR),
        ValidationFailedError,
        "credentials_missing",
    )
    assert "TOTP token (API key)" in error.message
    kite = await kite_account(accounts)
    await failure(auth.create_groww_token(kite.id, actor=ACTOR), ValidationFailedError, "wrong_provider")
    assert remote.requests == []

    await accounts.set_credentials(approval.id, {API_SECRET: GROWW_KEYS[API_SECRET]}, actor=ACTOR)
    body = {"error": {"displayMessage": "Approve the API key in Groww Cloud first"}}
    remote.routes[CREATE_TOKEN] = lambda _request: httpx.Response(400, json=body)
    await failure(
        auth.create_groww_token(approval.id, actor=ACTOR), ProviderRequestRejectedError, "provider_rejected"
    )

    view = await accounts.get(approval.id)
    assert (view.status, view.has_access_token) == (AccountStatus.AUTH_REQUIRED, False)
    assert await token_metadata(container.db, approval.id) == []


async def seed_tokens(
    container: Container, account_id: UUID, method: AuthMethod, issued_at: datetime, count: int = 1
) -> None:
    """Token metadata as left by earlier token requests (revoked since, which does not matter)."""
    async with container.db.transaction() as session:
        session.add_all(
            ProviderTokenMetadataRow(
                account_id=account_id,
                token_kind=ACCESS_TOKEN,
                auth_method=method,
                fingerprint=uuid4().hex[:16],
                issued_at=issued_at,
                expires_at=issued_at + timedelta(hours=8),
                revoked_at=issued_at + timedelta(minutes=5),
                revoked_by=ACTOR,
                revoke_reason="replaced by a new token",
            )
            for _ in range(count)
        )


async def test_created_groww_tokens_are_limited_per_account_over_a_rolling_day(
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    clock: FakeClock,
    remote: FakeProvider,
) -> None:
    account = await groww_account(
        accounts, AuthMethod.GROWW_TOTP, {API_KEY: "growwtotptoken", TOTP_SECRET: TOTP_SEED}
    )
    other = await groww_account(accounts, AuthMethod.GROWW_TOTP, label="Other")
    await seed_tokens(container, account.id, AuthMethod.GROWW_TOTP, NOW - timedelta(hours=23), 148)
    await seed_tokens(container, account.id, AuthMethod.GROWW_API_KEY_SECRET, NOW - timedelta(hours=2))
    # Not counted: older than 24 hours, pasted rather than created, or another account's.
    await seed_tokens(container, account.id, AuthMethod.GROWW_TOTP, NOW - timedelta(hours=24))
    await seed_tokens(container, account.id, AuthMethod.GROWW_ACCESS_TOKEN, NOW - timedelta(hours=1))
    await seed_tokens(
        container, other.id, AuthMethod.GROWW_TOTP, NOW - timedelta(hours=1), GROWW_DAILY_TOKEN_LIMIT
    )
    remote.routes[CREATE_TOKEN] = created("budgetgrowwtoken")

    await auth.create_groww_token(account.id, actor=ACTOR)  # the 150th
    error = await failure(
        auth.create_groww_token(account.id, actor=ACTOR), RateLimitedError, "token_budget_exhausted"
    )

    assert error.message.startswith(f"{GROWW_DAILY_TOKEN_LIMIT} Groww access tokens were created")
    assert len(remote.requests) == 1
    clock.advance(timedelta(hours=1, seconds=1))  # the 148 tokens from 23 hours ago drop out
    view = await auth.create_groww_token(account.id, actor=ACTOR)
    assert (view.status, len(remote.requests)) == (AccountStatus.AUTHENTICATED, 2)


# ---- logout -----------------------------------------------------------------------------------------


async def test_zerodha_logout_invalidates_the_kite_session_and_forgets_the_token(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    account = await kite_account(accounts, enabled=True)
    await store_token(accounts, account.id, KITE_TOKEN, expires_at=NEXT_RESET, user_ref=KITE_USER)
    remote.routes[LOGOUT] = kite_ok(True)

    result = await auth.disconnect(account.id, actor=ACTOR, client_ip=CLIENT_IP)

    assert result.remote_revoked is True
    (request,) = remote.requests
    assert ((request.method, request.url.path), dict(request.url.params)) == (
        LOGOUT,
        {"api_key": KITE_KEY, "access_token": KITE_TOKEN},
    )
    assert "Authorization" not in request.headers
    view = result.account
    assert (view.status, view.has_access_token, view.token_expires_at) == (
        AccountStatus.DISCONNECTED,
        False,
        None,
    )
    assert view.provider_user_ref == KITE_USER  # the next login must be the same Zerodha user
    assert view == await accounts.get(account.id)
    assert await stored_token(accounts, account.id) is None
    (token,) = await token_metadata(container.db, account.id)
    assert (token.revoked_at, token.revoked_by, token.revoke_reason) == (NOW, ACTOR, "logged out")
    details = {"provider": "ZERODHA", "label": "Main", "remote_revoked": True}
    assert await last_audit(container, account.id) == ("provider_account.logout", ACTOR, CLIENT_IP, details)
    assert await command_types(container) == [CONNECT, DISCONNECT]
    audited = len(await audit_entries(container.db, account.id))

    again = await auth.disconnect(account.id, actor="user:bob")  # nothing left to do

    assert (again.remote_revoked, again.account) == (False, view)
    assert len(remote.requests) == 1
    assert len(await audit_entries(container.db, account.id)) == audited
    assert await command_types(container) == [CONNECT, DISCONNECT]
    remote.routes[SESSION] = kite_session()
    state = login_state(await auth.begin_zerodha_login(account.id, actor=ACTOR))
    assert (
        await auth.complete_zerodha_login(callback(state), actor=ACTOR)
    ).status is AccountStatus.AUTHENTICATED


@pytest.mark.parametrize(
    "reply",
    [kite_error(403, "TokenException", "Token is invalid or has expired."), refuse],
    ids=["session-already-invalid", "kite-unreachable"],
)
async def test_zerodha_logout_forgets_the_token_even_when_kite_does_not_confirm(
    reply: Reply,
    auth: ProviderAuthService,
    accounts: ProviderAccountService,
    container: Container,
    remote: FakeProvider,
) -> None:
    account = await kite_account(accounts)
    await store_token(accounts, account.id, KITE_TOKEN, expires_at=NEXT_RESET, user_ref=KITE_USER)
    remote.routes[LOGOUT] = reply

    result = await auth.disconnect(account.id, actor=ACTOR)

    assert result.remote_revoked is False
    assert remote.paths() == [LOGOUT]
    assert (result.account.status, result.account.has_access_token) == (AccountStatus.DISCONNECTED, False)
    action, _, _, details = await last_audit(container, account.id)
    assert (action, details["remote_revoked"]) == ("provider_account.logout", False)
    assert await command_types(container) == []  # not enabled, so the worker has nothing to stop


async def test_logout_of_groww_and_never_logged_in_accounts(
    auth: ProviderAuthService, accounts: ProviderAccountService, container: Container, remote: FakeProvider
) -> None:
    groww = await groww_account(accounts, AuthMethod.GROWW_ACCESS_TOKEN, enabled=True)
    await store_token(accounts, groww.id, "growwaccesstoken", expires_at=NEXT_RESET, user_ref=GROWW_USER)

    result = await auth.disconnect(groww.id, actor=ACTOR)

    # Groww has no logout endpoint: the token stays valid at Groww until it expires.
    assert result.remote_revoked is None
    assert (result.account.status, result.account.has_access_token) == (AccountStatus.DISCONNECTED, False)
    assert await stored_token(accounts, groww.id) is None
    assert await command_types(container) == [CONNECT, DISCONNECT]

    fresh = await kite_account(accounts)
    result = await auth.disconnect(fresh.id, actor=ACTOR)
    assert (result.remote_revoked, result.account.status) == (False, AccountStatus.DISCONNECTED)
    assert remote.requests == []

    simulator = await accounts.create(Provider.SIMULATOR, "Sim", actor=ACTOR)
    await failure(
        auth.disconnect(simulator.id, actor=ACTOR), ValidationFailedError, "credentials_not_applicable"
    )
    await failure(auth.disconnect(uuid4(), actor=ACTOR), NotFoundError, "provider_account_not_found")
