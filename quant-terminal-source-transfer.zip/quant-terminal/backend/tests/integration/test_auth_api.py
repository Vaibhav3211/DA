from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from uuid import uuid4

import httpx
import pytest
from fastapi import FastAPI
from sqlalchemy import select

from app.core.config import Settings
from app.persistence.models import AuditLogRow
from app.services.auth_service import MAX_FAILED_LOGINS, MAX_FAILED_LOGINS_PER_IP, AuthService
from tests.integration.conftest import api_client

pytestmark = pytest.mark.integration

PASSWORD = "integration-test-password"
LOGIN = "/api/v1/auth/login"


def _auth(app: FastAPI) -> AuthService:
    container = app.state.container
    return AuthService(container.db, container.bus, container.settings)


async def _new_user(app: FastAPI) -> str:
    username = f"user{uuid4().hex[:10]}"
    await _auth(app).create_user(username, PASSWORD, actor="test")
    return username


@asynccontextmanager
async def _client_from(app: FastAPI, address: str) -> AsyncIterator[httpx.AsyncClient]:
    transport = httpx.ASGITransport(app=app, client=(address, 123))
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        yield client


async def test_probes_and_prometheus(app_and_client: tuple[FastAPI, httpx.AsyncClient]) -> None:
    _app, client = app_and_client
    assert (await client.get("/health/live")).json() == {"status": "alive"}
    ready = await client.get("/health/ready")
    assert ready.status_code == 200, ready.text
    assert {c["name"] for c in ready.json()["components"]} == {"postgres", "redis"}
    metrics = await client.get("/metrics/")
    assert metrics.status_code == 200
    assert "qt_http_requests_total" in metrics.text


async def test_login_session_and_logout(app_and_client: tuple[FastAPI, httpx.AsyncClient]) -> None:
    app, client = app_and_client
    username = await _new_user(app)

    unauthenticated = await client.get("/api/v1/system/health")
    assert unauthenticated.status_code == 401
    assert unauthenticated.json()["error"]["code"] == "unauthenticated"
    assert unauthenticated.json()["error"]["correlation_id"]

    bad = await client.post("/api/v1/auth/login", json={"username": username, "password": "wrong-password!!"})
    assert bad.status_code == 401
    assert bad.json()["error"]["code"] == "invalid_credentials"

    ok = await client.post("/api/v1/auth/login", json={"username": username.upper(), "password": PASSWORD})
    assert ok.status_code == 200, ok.text
    cookie = ok.headers["set-cookie"].lower()
    assert "httponly" in cookie
    assert "samesite=lax" in cookie
    assert PASSWORD not in ok.text

    me = await client.get("/api/v1/auth/me")
    assert me.status_code == 200
    assert me.json()["username"] == username

    health = await client.get("/api/v1/system/health")
    assert health.status_code == 200
    body = health.json()
    assert body["flags"]["order_execution_enabled"] is False
    assert body["kill_switch"]["engaged"] is False
    # No workers run in this test, so their absence must surface as alerts.
    assert {a["code"] for a in body["alerts"]} >= {"worker_down"}
    assert body["status"] == "degraded"

    assert (await client.post("/api/v1/auth/logout")).status_code == 200
    assert (await client.get("/api/v1/auth/me")).status_code == 401


async def test_lockout_after_repeated_failures(app_and_client: tuple[FastAPI, httpx.AsyncClient]) -> None:
    app, client = app_and_client
    username = await _new_user(app)
    for _ in range(MAX_FAILED_LOGINS):
        response = await client.post(LOGIN, json={"username": username, "password": "nope-nope-nope"})
        assert response.status_code == 401
    # The failing address is blocked too, so the account lockout shows from another address.
    async with _client_from(app, "10.0.0.2") as other:
        locked = await other.post(LOGIN, json={"username": username, "password": PASSWORD})
        assert locked.status_code == 401
        assert locked.json()["error"]["code"] == "account_locked"

        # An administrator password reset (CLI) clears the lockout.
        await _auth(app).set_password(username, PASSWORD + "-new", actor="test")
        unlocked = await other.post(LOGIN, json={"username": username, "password": PASSWORD + "-new"})
        assert unlocked.status_code == 200

    async with app.state.container.db.session() as session:
        actions = (
            await session.scalars(select(AuditLogRow.action).where(AuditLogRow.actor == username))
        ).all()
    assert "auth.login_failed" in actions
    assert "auth.login_rejected_locked" in actions
    assert "auth.login" in actions


async def test_failed_logins_block_the_address(app_and_client: tuple[FastAPI, httpx.AsyncClient]) -> None:
    app, client = app_and_client
    username = await _new_user(app)

    async def fail(on: httpx.AsyncClient, times: int) -> list[int]:
        return [
            (await on.post(LOGIN, json={"username": f"guess{n}", "password": "wrong"})).status_code
            for n in range(times)
        ]

    almost = MAX_FAILED_LOGINS_PER_IP - 1
    # A successful sign-in clears the address's failures (each address stays under the per-minute limit).
    async with _client_from(app, "10.0.0.4") as resetting:
        assert await fail(resetting, almost) == [401] * almost
        ok = await resetting.post(LOGIN, json={"username": username, "password": PASSWORD})
        assert ok.status_code == 200
        assert await fail(resetting, almost) == [401] * almost

    assert await fail(client, MAX_FAILED_LOGINS_PER_IP) == [401] * MAX_FAILED_LOGINS_PER_IP
    blocked = await client.post(LOGIN, json={"username": username, "password": PASSWORD})
    assert blocked.status_code == 429
    assert blocked.json()["error"]["code"] == "login_blocked"
    assert 0 < blocked.json()["error"]["details"]["retry_after_seconds"] <= 15 * 60
    # Other addresses, and the user's account, are unaffected.
    async with _client_from(app, "10.0.0.3") as other:
        assert (await other.post(LOGIN, json={"username": username, "password": PASSWORD})).status_code == 200


async def test_password_reset_revokes_existing_sessions(
    app_and_client: tuple[FastAPI, httpx.AsyncClient],
) -> None:
    app, client = app_and_client
    username = await _new_user(app)
    assert (
        await client.post("/api/v1/auth/login", json={"username": username, "password": PASSWORD})
    ).is_success
    assert (await client.get("/api/v1/auth/me")).status_code == 200
    revoked = await _auth(app).set_password(username, PASSWORD + "-rotated", actor="test")
    assert revoked == 1
    assert (await client.get("/api/v1/auth/me")).status_code == 401


async def test_login_rate_limit(migrated_database: Settings) -> None:
    settings = migrated_database.model_copy(update={"login_rate_limit_per_minute": 3})
    async with api_client(settings) as (_app, client):
        statuses = [
            (
                await client.post("/api/v1/auth/login", json={"username": "nobody", "password": "x"})
            ).status_code
            for _ in range(4)
        ]
    assert statuses == [401, 401, 401, 429]


async def test_kill_switch_round_trip(app_and_client: tuple[FastAPI, httpx.AsyncClient]) -> None:
    app, client = app_and_client
    username = await _new_user(app)
    await client.post("/api/v1/auth/login", json={"username": username, "password": PASSWORD})

    engaged = await client.put("/api/v1/system/kill-switch", json={"engaged": True, "reason": "test"})
    assert engaged.status_code == 200
    assert engaged.json()["engaged"] is True

    # With the Redis mirror gone, the state is rebuilt from PostgreSQL (the source of truth).
    await app.state.container.bus.redis.flushdb()
    await client.post("/api/v1/auth/login", json={"username": username, "password": PASSWORD})
    state = await client.get("/api/v1/system/kill-switch")
    assert state.json()["engaged"] is True
    assert state.json()["updated_by"] == username

    released = await client.put("/api/v1/system/kill-switch", json={"engaged": False})
    assert released.json()["engaged"] is False


async def test_cross_site_requests_are_rejected(app_and_client: tuple[FastAPI, httpx.AsyncClient]) -> None:
    _app, client = app_and_client
    response = await client.post(
        "/api/v1/auth/login",
        json={"username": "x", "password": "y"},
        headers={"Origin": "https://evil.example"},
    )
    assert response.status_code == 403
