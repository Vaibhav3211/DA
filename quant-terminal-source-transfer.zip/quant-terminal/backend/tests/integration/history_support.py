"""Shared setup for backtest integration tests: three NSE instruments, one recorded session of 1-minute
candles and the fixture strategies.

The session's candles start at 09:15 IST on Monday 5 January 2026 and skip 09:22 and 09:23; the test clock
stands at 09:30 IST. TRADER proposes one BUY (entry 100.10, stop 98.05, target 104.20) at the close of the
09:18 candle: it fills at the next open, 100.50, and the 09:20 candle reaches the target. SILENT never
proposes anything. DAILY proposes TRADER's BUY at the close of every session's 09:18 candle, so it trades
the recorded session as TRADER does and signals again the next morning.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from uuid import UUID

from app.container import Container
from app.domain.enums import Exchange, InstrumentType, Provider, Segment, SubscriptionMode
from app.domain.models import Candle, SignalCandidate
from app.market_data.candles.store import candle_values, upsert_candles
from app.persistence.database import Database
from app.persistence.models import InstrumentProviderMappingRow, InstrumentRow
from app.strategies.registry import StrategyRegistry
from tests.backtest_support import IST, Context, scripted
from tests.candle_support import T0, bar
from tests.integration.provider_support import NOW, add_rows, wipe_instruments
from tests.integration.strategy_support import wipe_backtests, wipe_strategies
from tests.signal_support import make_candidate

INDIA = "india-equity"
ONE = "NSE:CASH:EQUITY:BTONE"  # in the workspace, with a Zerodha mapping
TWO = "NSE:CASH:EQUITY:BTTWO"  # in the workspace, without a mapping
THREE = "NSE:CASH:EQUITY:BTTHREE"  # in no workspace
DAY = date(2026, 1, 5)
ONE_TOKEN = "738561"  # BTONE's Zerodha instrument token
NO_WORKER = "The backtest worker is not running, so queued jobs wait; start qt-backtest-worker"
NO_RULES = "no trade rules are set: set them for this configuration, or declare trade_rules in the strategy"
TARGET_ONLY = "No losing trades, so there is no loss to divide by"


def minute(n: int) -> datetime:
    return T0 + timedelta(minutes=n)


def buy_at_minute_3(candle: Candle, context: Context) -> Sequence[SignalCandidate]:
    if candle.bucket_start == minute(3):
        return (make_candidate(instrument_id=candle.instrument_id),)
    return ()


def buy_at_0918(candle: Candle, context: Context) -> Sequence[SignalCandidate]:
    if candle.bucket_start.astimezone(IST).time() == time(9, 18):
        return (make_candidate(instrument_id=candle.instrument_id),)
    return ()


TRADER = scripted(buy_at_minute_3, warmup_candles=3)
SILENT = scripted(strategy_id="test.silent", name="Silent fixture")
DAILY = scripted(buy_at_0918, strategy_id="test.daily", name="Daily fixture", warmup_candles=3)


def fixture_registry() -> StrategyRegistry:
    """The fixture strategies, in one registry that every service of a test shares, as in the app."""
    return StrategyRegistry([TRADER.cls, SILENT.cls])


def session_candles(instrument_id: UUID, symbol: str) -> list[Candle]:
    """Thirteen closed candles from 09:15: flat at 100, up to 104 by 09:20, flat after, none at 09:22 or
    09:23."""

    def at(
        index: int, close: str, *, open_: str | None = None, high: str | None = None, low: str | None = None
    ) -> Candle:
        return bar(index, close, open_=open_, high=high, low=low, instrument_id=instrument_id, symbol=symbol)

    return [
        *(at(n, "100") for n in range(4)),
        at(4, "100.80", open_="100.50", high="101", low="100.20"),
        at(5, "104", open_="101", high="104.50", low="100.90"),
        at(6, "104"),
        *(at(n, "104") for n in range(9, 15)),
    ]


async def record_session(db: Database, instrument_id: UUID, key: str) -> None:
    """Store the session's candles of ``key`` as recorded from Zerodha's feed."""
    candles = session_candles(instrument_id, key.rsplit(":", 1)[1])
    async with db.transaction() as session:
        await upsert_candles(session, [candle_values(candle) for candle in candles])


async def wipe_lab(db: Database) -> None:
    """Remove backtests, strategies and instruments, with everything that hangs off them."""
    await wipe_backtests(db)
    await wipe_strategies(db)
    await wipe_instruments(db)


async def add_instruments(container: Container) -> dict[str, UUID]:
    """BTONE and BTTWO in the India workspace, BTTHREE in none; only BTONE has a Zerodha mapping. Their
    ids by canonical key."""
    symbols = ("BTONE", "BTTWO", "BTTHREE")
    async with container.db.transaction() as session:
        rows = [
            InstrumentRow(
                canonical_key=f"NSE:CASH:EQUITY:{symbol}",
                exchange=Exchange.NSE,
                segment=Segment.CASH,
                instrument_type=InstrumentType.EQUITY,
                symbol=symbol,
                tick_size=Decimal("0.05"),
                lot_size=1,
            )
            for symbol in symbols
        ]
        session.add_all(rows)
        await session.flush()
        session.add(
            InstrumentProviderMappingRow(
                instrument_id=rows[0].id,
                provider=Provider.ZERODHA,
                provider_token=ONE_TOKEN,
                provider_symbol="BTONE",
                provider_exchange="NSE",
                provider_segment="NSE",
                valid_from=NOW,
            )
        )
        ids = {row.symbol: row.id for row in rows}
    full = SubscriptionMode.FULL
    await add_rows(
        container,
        ids,
        [(INDIA, "BTONE", Provider.ZERODHA, full, None), (INDIA, "BTTWO", Provider.ZERODHA, full, None)],
    )
    return {f"NSE:CASH:EQUITY:{symbol}": instrument_id for symbol, instrument_id in ids.items()}
