"""The subscription plan built from workspaces, enabled accounts, instruments and capabilities."""

from __future__ import annotations

from uuid import UUID

import pytest
import sqlalchemy as sa

from app.container import Container
from app.domain.enums import Provider, SubscriptionMode
from app.market_data.subscriptions import STREAMING_OFF, SkipReason, SubscriptionPlan, SubscriptionPlanner
from app.persistence.models import InstrumentProviderMappingRow
from app.services.capabilities import CapabilityService
from app.services.instruments import InstrumentService
from app.services.provider_accounts import ProviderAccountService
from tests.integration.provider_support import (
    ACTOR,
    LAB,
    FakeClock,
    account_service,
    add_rows,
    enabled_account,
    provider_settings,
)

pytestmark = pytest.mark.integration

SIMULATOR, ZERODHA = Provider.SIMULATOR, Provider.ZERODHA
LTP, QUOTE, FULL = SubscriptionMode.LTP, SubscriptionMode.QUOTE, SubscriptionMode.FULL
DISABLED_WORKSPACE = "forex-major"


async def plan(container: Container, clock: FakeClock) -> SubscriptionPlan:
    settings = provider_settings(container.settings, simulator_enabled=True)  # live market data stays off
    planner = SubscriptionPlanner(
        settings,
        InstrumentService(account_service(container, clock, simulator_enabled=True)),
        CapabilityService(container.db, clock=clock),
    )
    return await planner.plan()


async def override(container: Container, account_id: UUID, **values: object) -> None:
    await CapabilityService(container.db).set_override(
        SIMULATOR, values, verification_source="test", verified_on=None, account_id=account_id, actor=ACTOR
    )


async def test_enabled_accounts_stream_the_rows_of_enabled_workspaces(
    accounts: ProviderAccountService, container: Container, clock: FakeClock, symbols: dict[str, UUID]
) -> None:
    lab = await enabled_account(accounts, SIMULATOR)
    kite = await enabled_account(accounts, ZERODHA)
    await override(container, lab, subscription_modes=["LTP", "QUOTE"])
    async with container.db.transaction() as session:
        m = InstrumentProviderMappingRow
        await session.execute(sa.update(m).where(m.instrument_id == symbols["BRAVO"]).values(is_active=False))
    await add_rows(
        container,
        symbols,
        [
            (LAB, "ALPHA", SIMULATOR, QUOTE, None),
            (LAB, "SIM50", SIMULATOR, FULL, None),
            (LAB, "BRAVO", SIMULATOR, QUOTE, None),
            (LAB, "CHARLIE", ZERODHA, QUOTE, None),
            (DISABLED_WORKSPACE, "DELTA", SIMULATOR, QUOTE, None),
            (LAB, "ECHO", SIMULATOR, LTP, lab),
        ],
    )

    result = await plan(container, clock)

    [streamed] = result.accounts
    assert streamed.account.account_id == lab
    assert streamed.capabilities.subscription_modes == (LTP, QUOTE)
    assert [(i.symbol, i.mode) for i in streamed.instruments] == [("ALPHA", QUOTE), ("ECHO", LTP)]
    assert [(idle.account.account_id, idle.reason) for idle in result.idle] == [
        (kite, "live market data is off (set MARKET_DATA_ENABLED=true)")
    ]
    names = {instrument_id: symbol for symbol, instrument_id in symbols.items()}
    assert sorted((names[s.instrument_id], s.provider, s.account_id, s.reason) for s in result.skipped) == [
        ("BRAVO", SIMULATOR, lab, SkipReason.NOT_LISTED),
        ("CHARLIE", ZERODHA, kite, SkipReason.STREAMING_DISABLED),
        ("SIM50", SIMULATOR, lab, SkipReason.UNSUPPORTED),
    ]


async def test_an_account_with_streaming_turned_off_streams_nothing(
    accounts: ProviderAccountService, container: Container, clock: FakeClock, symbols: dict[str, UUID]
) -> None:
    lab = await enabled_account(accounts, SIMULATOR)
    await override(container, lab, streaming=False)
    await add_rows(container, symbols, [(LAB, "ALPHA", SIMULATOR, QUOTE, None)])

    result = await plan(container, clock)

    assert result.accounts == ()
    assert [(idle.account.account_id, idle.reason) for idle in result.idle] == [(lab, STREAMING_OFF)]
    assert [(s.instrument_id, s.reason) for s in result.skipped] == [
        (symbols["ALPHA"], SkipReason.STREAMING_DISABLED)
    ]
