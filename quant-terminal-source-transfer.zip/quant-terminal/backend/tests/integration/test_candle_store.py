"""Candle upserts, resuming forming candles and the candle writer against PostgreSQL."""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

import pytest
import sqlalchemy as sa
from prometheus_client import REGISTRY

from app.container import Container
from app.domain.enums import (
    CandleFlag,
    CandleInterval,
    DataStatus,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
)
from app.domain.models import Candle
from app.market_data.candles.store import candle_values, load_forming, upsert_candles
from app.market_data.candles.writer import CandleWriter
from app.persistence.models import CandleRow, InstrumentRow
from tests.integration.provider_support import wipe_instruments

pytestmark = pytest.mark.integration

OPEN = datetime(2026, 1, 5, 3, 45, tzinfo=UTC)  # 09:15 IST
CLOSE = datetime(2026, 1, 5, 10, 0, tzinfo=UTC)  # 15:30 IST
MINUTE = timedelta(minutes=1)


@dataclass(frozen=True)
class Listing:
    symbol: str = "INFY"
    exchange: Exchange = Exchange.NSE
    segment: Segment = Segment.CASH


@pytest.fixture
async def instrument_id(container: Container) -> AsyncIterator[UUID]:
    await wipe_instruments(container.db)  # their candles cascade
    row = InstrumentRow(
        canonical_key="NSE:INFY",
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        instrument_type=InstrumentType.EQUITY,
        symbol="INFY",
    )
    async with container.db.transaction() as session:
        session.add(row)
    try:
        yield row.id
    finally:
        await wipe_instruments(container.db)


def candle(instrument_id: UUID, **changes: Any) -> Candle:
    values: dict[str, Any] = {
        "provider": Provider.ZERODHA,
        "account_id": None,
        "instrument_id": instrument_id,
        "symbol": "INFY",
        "exchange": Exchange.NSE,
        "segment": Segment.CASH,
        "interval": CandleInterval.M1,
        "bucket_start": OPEN,
        "bucket_end": OPEN + MINUTE,
        "open_price": Decimal("100"),
        "high_price": Decimal("101.5"),
        "low_price": Decimal("99.25"),
        "close_price": Decimal("101"),
        "volume": 1200,
        "event_count": 7,
        "is_closed": True,
        "data_status": DataStatus.LIVE,
        "first_event_at": OPEN + timedelta(seconds=1),
        "last_event_at": OPEN + timedelta(seconds=59),
    }
    return Candle(**(values | changes))


def forming(instrument_id: UUID, **changes: Any) -> Candle:
    """As a stopping pipeline saves it."""
    values = {
        "is_closed": False,
        "flags": (CandleFlag.DISCONNECTED_DURING,),
        "data_status": DataStatus.DISCONNECTED,
    }
    return candle(instrument_id, **(values | changes))


async def upsert(container: Container, *candles: Candle) -> None:
    async with container.db.transaction() as session:
        await upsert_candles(session, [candle_values(item) for item in candles])


async def stored(container: Container) -> list[CandleRow]:
    async with container.db.session() as session:
        rows = await session.scalars(
            sa.select(CandleRow).order_by(CandleRow.interval, CandleRow.bucket_start)
        )
        return list(rows)


def metric(name: str, labels: dict[str, str]) -> float:
    return REGISTRY.get_sample_value(name, labels) or 0.0


async def test_a_newer_version_of_a_candle_overwrites_the_stored_one(
    container: Container, instrument_id: UUID
) -> None:
    await upsert(container, forming(instrument_id, close_price=Decimal("100.5")))
    revised = candle(instrument_id, volume=None, flags=(CandleFlag.VOLUME_UNAVAILABLE,))
    await upsert(container, candle(instrument_id), revised)  # the last version of a key wins

    rows = await stored(container)
    assert [
        (row.close_price, row.volume, row.flags, row.is_complete, row.data_status, row.event_count)
        for row in rows
    ] == [(Decimal("101"), None, ["VOLUME_UNAVAILABLE"], True, DataStatus.LIVE, 7)]
    assert rows[0].updated_at >= rows[0].created_at


async def test_forming_candles_are_resumed_until_their_bucket_ends(
    container: Container, instrument_id: UUID
) -> None:
    minute = forming(instrument_id)
    daily = forming(instrument_id, interval=CandleInterval.D1, bucket_end=CLOSE, volume=None)
    await upsert(
        container,
        minute,
        daily,
        forming(
            instrument_id, interval=CandleInterval.M5, bucket_end=OPEN + 5 * MINUTE, builder_version="0.1"
        ),
        forming(instrument_id, provider=Provider.GROWW),
        candle(instrument_id, bucket_start=OPEN - MINUTE, bucket_end=OPEN),  # closed earlier
    )
    listings = {instrument_id: Listing()}
    intervals = [CandleInterval.M1, CandleInterval.M5, CandleInterval.D1]

    async with container.db.session() as session:
        mid_minute = await load_forming(
            session, Provider.ZERODHA, listings, intervals, OPEN + timedelta(seconds=30)
        )
        next_minute = await load_forming(session, Provider.ZERODHA, listings, intervals, OPEN + MINUTE)
        unlisted = await load_forming(session, Provider.ZERODHA, {uuid4(): Listing()}, intervals, OPEN)

    assert sorted(mid_minute, key=lambda item: item.bucket_end) == [minute, daily]
    assert next_minute == [daily]
    assert unlisted == []


async def test_the_writer_drops_only_the_rows_the_database_refuses(
    container: Container, instrument_id: UUID
) -> None:
    writer = CandleWriter(container.db, interval_seconds=60)
    dropped = metric("qt_candles_dropped_total", {"reason": "persist_failed"})
    errors = metric("qt_db_write_errors_total", {"table": "candles"})

    writer.add([candle(uuid4()), candle(instrument_id), forming(uuid4(), interval=CandleInterval.M3)])
    assert await writer.flush() == 1

    assert [row.instrument_id for row in await stored(container)] == [instrument_id]
    assert writer.pending == 0
    assert metric("qt_candles_dropped_total", {"reason": "persist_failed"}) == dropped + 1  # closed only
    assert metric("qt_db_write_errors_total", {"table": "candles"}) == errors + 2
