"""The REST API over HTTP: every route needs a session, and each endpoint group works end to end on the
real app, database and Redis. Provider hosts are unreachable, and nothing here calls them."""

from __future__ import annotations

import html
import re
from collections.abc import AsyncIterator
from datetime import datetime, timedelta
from decimal import Decimal
from functools import partial
from typing import Any
from urllib.parse import parse_qs, urlencode, urlsplit
from uuid import UUID, uuid4

import httpx
import pytest
from fastapi import FastAPI

from app.api.deps import get_backtests, get_clock, get_strategies
from app.container import Container
from app.core.config import Settings
from app.core.security import hash_token
from app.domain.enums import (
    CandleInterval,
    ConnectionState,
    DataStatus,
    EventType,
    Exchange,
    Provider,
    Segment,
    SubscriptionMode,
)
from app.domain.models import Candle, QuoteSnapshot, StreamHealth
from app.market_data.calendars.loader import load_market_calendar, load_overrides
from app.market_data.candles.store import candle_values, upsert_candles
from app.observability.heartbeat import STRATEGY_WORKER
from app.services.audit import CLI_ACTOR
from app.services.auth_service import AuthService
from app.services.backtests import BacktestService
from app.services.capabilities import CapabilityService
from app.services.datasets import DatasetService
from app.services.provider_accounts import ProviderAccountService
from app.services.provider_auth import ProviderAuthService
from app.services.strategies import StrategyService
from app.services.strategy_runs import RunStore
from app.signals.engine import SignalEngine
from app.strategies.registry import StrategyRegistry
from app.streaming.redis_bus import Keys, RedisBus, Streams
from app.workers.backtest_worker import BacktestWorker
from app.workers.strategy_worker import StrategyWorker
from tests.backtest_support import trade_rules
from tests.candle_support import T0, bar
from tests.integration.conftest import api_client
from tests.integration.history_support import (
    DAILY,
    INDIA,
    NO_RULES,
    NO_WORKER,
    ONE,
    TARGET_ONLY,
    TRADER,
    TWO,
    add_instruments,
    fixture_registry,
    record_session,
    wipe_lab,
)
from tests.integration.provider_support import (
    KITE_LOGIN_URL,
    LAB,
    NOW,
    REDIRECT_URL,
    FakeClock,
    FakeProvider,
    add_rows,
    provider_settings,
)
from tests.integration.strategy_support import EXAMPLE, wipe_strategies

pytestmark = pytest.mark.integration

API = "/api/v1"
PASSWORD = "rest-api-test-password"
PUBLIC = {
    ("POST", f"{API}/auth/login"),
    ("POST", f"{API}/auth/logout"),
    ("GET", f"{API}/providers/zerodha/callback"),
}
KITE_KEY = "kite-key-7f3a9c21"
KITE_SECRET = "kite-secret-5d8e4b60"
SIMULATED = "Its instruments use simulated data: its signals are informational only"
GROWW_TOKEN = "groww-token-0c4f1e93"

type App = tuple[FastAPI, httpx.AsyncClient]


@pytest.fixture
async def api(
    migrated_database: Settings,
    accounts: ProviderAccountService,  # no provider accounts before or after the test
    clock: FakeClock,
) -> AsyncIterator[App]:
    """A logged-in client of the app, whose services read the test clock."""
    async with api_client(provider_settings(migrated_database)) as (app, client):
        app.dependency_overrides[get_clock] = lambda: clock
        await _login(app, client)
        yield app, client


@pytest.fixture
async def no_strategies(container: Container) -> AsyncIterator[None]:
    """No strategies, deployments, signals or risk rule overrides before or after the test."""
    await wipe_strategies(container.db)
    try:
        yield
    finally:
        await wipe_strategies(container.db)


@pytest.fixture
async def history_lab(container: Container) -> AsyncIterator[dict[str, UUID]]:
    """The backtest instruments by canonical key, with BTONE's session recorded; no other instruments,
    strategies or backtests before or after the test."""
    await wipe_lab(container.db)
    try:
        ids = await add_instruments(container)
        await record_session(container.db, ids[ONE], ONE)
        yield ids
    finally:
        await wipe_lab(container.db)


async def _login(app: FastAPI, client: httpx.AsyncClient) -> None:
    container = app.state.container
    username = f"rest{uuid4().hex[:10]}"
    auth = AuthService(container.db, container.bus, container.settings)
    await auth.create_user(username, PASSWORD, actor="test")
    response = await client.post(f"{API}/auth/login", json={"username": username, "password": PASSWORD})
    assert response.status_code == 200, response.text


def _ok(response: httpx.Response, status: int = 200) -> Any:
    assert response.status_code == status, response.text
    return response.json()


def _error(response: httpx.Response, status: int) -> str:
    """The error code of a response that must have ``status``."""
    assert response.status_code == status, response.text
    code: str = response.json()["error"]["code"]
    return code


def _redirect_query(response: httpx.Response, frontend: str) -> dict[str, list[str]]:
    """The query of a 303 redirect to the frontend's providers page."""
    assert response.status_code == 303, response.text
    target = urlsplit(response.headers["location"])
    assert f"{target.scheme}://{target.netloc}{target.path}" == f"{frontend.rstrip('/')}/providers"
    return parse_qs(target.query)


def _closes(candles: list[dict[str, Any]]) -> list[Decimal]:
    return [Decimal(candle["close_price"]) for candle in candles]


def _prices(*values: str) -> list[Decimal]:
    return [Decimal(value) for value in values]


async def _feed(bus: RedisBus, provider: Provider, account_id: UUID | None) -> str:
    """Report a connected, live feed stream of the account, as a market-data worker does."""
    stream_id = f"{provider.value.lower()}:{account_id}:0"
    health = StreamHealth(
        provider=provider,
        account_id=account_id,
        stream_id=stream_id,
        state=ConnectionState.CONNECTED,
        data_status=DataStatus.LIVE,
        state_since=NOW,
        updated_at=NOW,
    )
    await bus.set_json(Keys.feed_state(stream_id), health)
    return stream_id


def _quote(instrument_id: UUID, symbol: str) -> QuoteSnapshot:
    return QuoteSnapshot(
        provider=Provider.SIMULATOR,
        account_id=None,
        instrument_id=instrument_id,
        symbol=symbol,
        exchange=Exchange.SIM,
        segment=Segment.CASH,
        last_event_type=EventType.QUOTE,
        received_at=NOW,
        processed_at=NOW,
        data_status=DataStatus.LIVE,
        last_price=Decimal("101.5"),
    )


def _candle(instrument_id: UUID, index: int, close: int | str, *, closed: bool = True) -> Candle:
    return bar(
        index,
        close,
        closed=closed,
        instrument_id=instrument_id,
        provider=Provider.SIMULATOR,
        exchange=Exchange.SIM,
        symbol="ALPHA",
    )


async def _kite_account(client: httpx.AsyncClient) -> str:
    """The id of a new Zerodha account with an API key and secret, set up over the API."""
    account = _ok(await client.post(f"{API}/accounts", json={"provider": "ZERODHA", "label": "Main"}), 201)
    values = {"API_KEY": KITE_KEY, "API_SECRET": KITE_SECRET}
    _ok(await client.put(f"{API}/accounts/{account['id']}/credentials", json={"values": values}))
    account_id: str = account["id"]
    return account_id


def _protected_calls(app: FastAPI) -> list[tuple[str, str]]:
    """Every API operation but the public ones, with dummy path parameters."""

    def fill(match: re.Match[str]) -> str:
        return "zerodha" if match.group() == "{provider}" else str(uuid4())

    calls: list[tuple[str, str]] = []
    for path, operations in app.openapi()["paths"].items():
        for method in operations:
            if path.startswith(API) and (method.upper(), path) not in PUBLIC:
                calls.append((method.upper(), re.sub(r"\{[^}]+\}", fill, path)))
    return calls


# ---- authentication ---------------------------------------------------------------------------------


async def test_every_route_but_login_logout_and_the_kite_callback_needs_a_session(
    migrated_database: Settings,
) -> None:
    async with api_client(provider_settings(migrated_database)) as (app, client):
        calls = _protected_calls(app)
        assert len(calls) >= 55
        wrong = []
        for method, url in calls:
            response = await client.request(method, url)
            if response.status_code != 401 or response.json()["error"]["code"] != "unauthenticated":
                wrong.append((method, url, response.status_code))
        assert wrong == []


# ---- provider accounts and logins --------------------------------------------------------------------


async def test_accounts_are_managed_without_echoing_secrets(api: App) -> None:
    _app, client = api
    account = _ok(await client.post(f"{API}/accounts", json={"provider": "ZERODHA", "label": "Main"}), 201)
    assert (account["status"], account["is_enabled"], account["masked_api_key"]) == (
        "NEEDS_CREDENTIALS",
        False,
        None,
    )
    url = f"{API}/accounts/{account['id']}"
    extra = {"provider": "ZERODHA", "label": "Other", "is_admin": True}
    assert _error(await client.post(f"{API}/accounts", json=extra), 422) == "validation_failed"

    stored = await client.put(
        f"{url}/credentials", json={"values": {"API_KEY": KITE_KEY, "API_SECRET": KITE_SECRET}}
    )
    view = _ok(stored)
    assert KITE_KEY not in stored.text
    assert KITE_SECRET not in stored.text
    assert view["masked_api_key"] not in (None, KITE_KEY)
    assert {"API_KEY", "API_SECRET"} <= {c["kind"] for c in view["credentials"]}

    oversized = "s" * 5000
    rejected = await client.put(f"{url}/credentials", json={"values": {"API_SECRET": oversized}})
    assert _error(rejected, 422) == "validation_failed"
    assert oversized not in rejected.text
    unknown_kind = await client.put(f"{url}/credentials", json={"values": {"PASSWORD": "hunter2"}})
    assert _error(unknown_kind, 422) == "validation_failed"

    kept = _ok(await client.delete(f"{url}/credentials", params={"kind": "API_SECRET"}))
    assert {c["kind"] for c in kept["credentials"]} & {"API_KEY", "API_SECRET"} == {"API_KEY"}

    assert _ok(await client.patch(url, json={"label": "Renamed"}))["label"] == "Renamed"
    assert _ok(await client.post(f"{url}/enable"))["is_enabled"] is True
    listed = _ok(await client.get(f"{API}/accounts", params={"provider": "ZERODHA"}))
    assert [a["id"] for a in listed] == [account["id"]]
    assert _ok(await client.get(f"{API}/accounts", params={"provider": "GROWW"})) == []
    assert _ok(await client.post(f"{url}/disable"))["is_enabled"] is False
    assert (await client.delete(url)).status_code == 204
    assert _error(await client.get(url), 404) == "provider_account_not_found"


async def test_a_kite_login_starts_here_and_the_callback_reports_to_the_frontend(api: App) -> None:
    app, client = api
    account_id = await _kite_account(client)
    start = _ok(await client.post(f"{API}/providers/zerodha/connect", json={"account_id": account_id}))
    assert start["login_url"].startswith(f"{KITE_LOGIN_URL}?")
    assert (start["account_id"], start["redirect_url"]) == (account_id, REDIRECT_URL)

    frontend = str(app.state.container.settings.frontend_base_url)
    stateless = f"{API}/providers/zerodha/callback?status=success&request_token=reqtoken1234abcd"
    missing = _redirect_query(await client.get(stateless), frontend)
    assert missing == {"zerodha": ["error"], "code": ["login_state_missing"]}
    callback = f"{stateless}&state=forged"
    forged = _redirect_query(await client.get(callback), frontend)
    assert forged == {"zerodha": ["error"], "code": ["login_state_invalid"]}
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as anonymous:
        unauthenticated = _redirect_query(await anonymous.get(callback), frontend)
    assert unauthenticated == {"zerodha": ["error"], "code": ["unauthenticated"]}


def _login_state(login_url: str) -> str:
    """The one-time state a Kite login URL carries back to the callback."""
    return parse_qs(parse_qs(urlsplit(login_url).query)["redirect_params"][0])["state"][0]


async def test_the_callback_leaves_a_command_line_login_for_the_command_line(
    api: App, accounts: ProviderAccountService
) -> None:
    """It shows the address to paste: a redirect would take the request token out of the address bar."""
    app, client = api
    account_id = await _kite_account(client)
    auth = ProviderAuthService(accounts)
    state = _login_state((await auth.begin_zerodha_login(UUID(account_id), actor=CLI_ACTOR)).login_url)
    query = urlencode(
        {"action": "login", "status": "success", "request_token": "reqtoken1234abcd", "state": state}
    )

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as anonymous:
        for browser in (client, anonymous):  # signed in to the terminal or not
            page = await browser.get(f"{API}/providers/zerodha/callback?{query}")
            assert page.status_code == 200, page.text
            assert page.headers["content-type"].startswith("text/html")
            assert html.escape(f"{REDIRECT_URL}?{query}") in page.text
            assert page.headers["content-security-policy"].startswith("default-src 'none';")
            assert page.headers["cache-control"] == "no-store"
    assert await accounts.bus.get_json(Keys.zerodha_pending_login(hash_token(state))) is not None

    assert await auth.is_cli_zerodha_login(f"{REDIRECT_URL}?status=cancelled&state={state}")
    web = _ok(await client.post(f"{API}/providers/zerodha/connect", json={"account_id": account_id}))
    assert not await auth.is_cli_zerodha_login(f"state={_login_state(web['login_url'])}")
    assert not await auth.is_cli_zerodha_login(f"state={state}&state={state}")


async def test_groww_connect_takes_one_secret_and_disconnect_checks_the_provider(api: App) -> None:
    _app, client = api
    groww = _ok(await client.post(f"{API}/accounts", json={"provider": "GROWW", "label": "Groww"}), 201)
    both = {"account_id": groww["id"], "access_token": GROWW_TOKEN, "totp_code": "123456"}
    rejected = await client.post(f"{API}/providers/groww/connect", json=both)
    assert _error(rejected, 422) == "validation_failed"
    assert GROWW_TOKEN not in rejected.text

    kite = await _kite_account(client)
    mismatch = await client.post(f"{API}/providers/groww/disconnect", json={"account_id": kite})
    assert 400 <= mismatch.status_code < 500
    assert mismatch.json()["error"]["code"] == "provider_mismatch"


async def test_providers_report_accounts_feeds_and_capabilities(api: App) -> None:
    app, client = api
    settings = app.state.container.settings
    expected = {"ZERODHA", "GROWW"} | ({"SIMULATOR"} if settings.is_simulated_mode else set())
    assert {p["provider"] for p in _ok(await client.get(f"{API}/providers"))} == expected
    assert _ok(await client.get(f"{API}/providers/Groww"))["provider"] == "GROWW"
    assert _error(await client.get(f"{API}/providers/nyse"), 404) == "provider_not_found"
    assert _ok(await client.get(f"{API}/providers/zerodha/capabilities"))["provider"] == "ZERODHA"

    account_id = await _kite_account(client)
    quiet = _ok(await client.get(f"{API}/providers/zerodha/health"))
    assert (quiet["data_status"], quiet["feeds"]) == ("DISCONNECTED", [])
    assert [(a["account_id"], a["data_status"]) for a in quiet["accounts"]] == [(account_id, "DISCONNECTED")]

    stream_id = await _feed(app.state.container.bus, Provider.ZERODHA, UUID(account_id))
    live = _ok(await client.get(f"{API}/providers/ZERODHA/health"))
    assert (live["data_status"], [f["stream_id"] for f in live["feeds"]]) == ("LIVE", [stream_id])
    assert [a["data_status"] for a in live["accounts"]] == ["LIVE"]
    summary = _ok(await client.get(f"{API}/providers/zerodha"))
    assert (summary["data_status"], [a["id"] for a in summary["accounts"]]) == ("LIVE", [account_id])


# ---- markets, instruments and workspaces -------------------------------------------------------------


async def test_markets_show_each_exchange_session_at_the_current_time(api: App) -> None:
    _app, client = api
    overview = _ok(await client.get(f"{API}/markets"))
    assert datetime.fromisoformat(overview["generated_at"]) == NOW
    nse = next(m for m in overview["markets"] if m["exchange"] == "NSE")
    assert (nse["state"], nse["session_date"]) == ("OPEN", "2026-01-05")


async def test_market_availability_follows_the_effective_provider_capabilities(api: App) -> None:
    app, client = api
    markets = {m["key"]: m for m in _ok(await client.get(f"{API}/markets/availability"))}
    assert [key for key, market in markets.items() if market["available"]] == [
        "india-equity",
        "mcx-commodities",
        "nse-currency",
    ]
    commodities = markets["mcx-commodities"]
    assert (commodities["providers"], commodities["reason"]) == (
        ["ZERODHA"],
        "Streamed by Zerodha Kite Connect",
    )
    assert "MCX has no trading calendar yet, so its sessions show as UNKNOWN" in commodities["notes"]
    metals = markets["spot-metals"]
    assert (metals["region"], metals["planned_milestone"]) == (None, "M13")

    container: Container = app.state.container
    await CapabilityService(container.db).set_override(
        Provider.ZERODHA,
        {"exchanges": ["NSE", "BSE"]},
        verification_source="test",
        verified_on=None,
        actor=CLI_ACTOR,
    )
    commodities = next(
        m for m in _ok(await client.get(f"{API}/markets/availability")) if m["key"] == "mcx-commodities"
    )
    assert (commodities["available"], commodities["reason"]) == (
        False,
        "No provider's capabilities include streaming MCX COMMODITY",
    )


async def test_instruments_are_found_by_search_and_by_reference(api: App, symbols: dict[str, UUID]) -> None:
    _app, client = api
    alpha = symbols["ALPHA"]
    assert _ok(await client.get(f"{API}/instruments/{alpha}"))["instrument"]["symbol"] == "ALPHA"
    assert _error(await client.get(f"{API}/instruments/{uuid4()}"), 404) == "instrument_not_found"
    found = await client.get(f"{API}/instruments/search", params={"q": "alpha", "provider": "SIMULATOR"})
    _ok(found)
    assert str(alpha) in found.text
    assert (
        _error(await client.get(f"{API}/instruments/search", params={"limit": 0}), 422) == "validation_failed"
    )


async def test_a_workspace_universe_is_edited_over_the_api(api: App, symbols: dict[str, UUID]) -> None:
    _app, client = api
    assert LAB in {w["slug"] for w in _ok(await client.get(f"{API}/workspaces"))}
    assert _error(await client.get(f"{API}/workspaces/no-such-space"), 404) == "workspace_not_found"
    url = f"{API}/workspaces/{LAB}"
    alpha, bravo = str(symbols["ALPHA"]), str(symbols["BRAVO"])
    body = {"instruments": [alpha, bravo], "provider": "SIMULATOR"}

    added = _ok(await client.post(f"{url}/instruments", json=body))
    assert sorted(i["symbol"] for i in added["added"]) == ["ALPHA", "BRAVO"]
    again = _ok(await client.post(f"{url}/instruments", json=body))
    assert (again["added"], len(again["unchanged"])) == ([], 2)
    universe = _ok(await client.get(url))
    assert sorted(e["instrument"]["symbol"] for e in universe["entries"]) == ["ALPHA", "BRAVO"]

    removed = _ok(await client.post(f"{url}/instruments/remove", json={"instruments": [bravo]}))
    assert [i["symbol"] for i in removed["removed"]] == ["BRAVO"]
    too_many = {"instruments": [alpha] * 1001, "provider": "SIMULATOR"}
    assert _error(await client.post(f"{url}/instruments", json=too_many), 422) == "validation_failed"


async def test_watchlists_keep_their_items_in_order(api: App, symbols: dict[str, UUID]) -> None:
    app, client = api
    await add_rows(
        app.state.container, symbols, [(LAB, "BRAVO", Provider.SIMULATOR, SubscriptionMode.QUOTE, None)]
    )
    suffix = uuid4().hex[:6]
    lists = f"{API}/workspaces/{LAB}/watchlists"
    created = _ok(await client.post(lists, json={"name": f"Momentum {suffix}"}), 201)
    url = f"{API}/watchlists/{created['id']}"
    duplicate = await client.post(lists, json={"name": f"MOMENTUM {suffix}"})
    assert _error(duplicate, 409) == "watchlist_exists"

    ids = [str(symbols["BRAVO"]), str(symbols["ALPHA"]), str(symbols["BRAVO"])]
    filled = _ok(await client.put(f"{url}/items", json={"instrument_ids": ids}))
    assert [(i["instrument"]["symbol"], i["in_universe"]) for i in filled["items"]] == [
        ("BRAVO", True),
        ("ALPHA", False),
    ]
    unknown = await client.put(f"{url}/items", json={"instrument_ids": [str(uuid4())]})
    assert _error(unknown, 404) == "instrument_not_found"

    renamed = _ok(await client.patch(url, json={"name": f"Swing {suffix}"}))
    assert (renamed["name"], len(renamed["items"])) == (f"Swing {suffix}", 2)
    assert renamed["id"] in {w["id"] for w in _ok(await client.get(lists))}
    assert (await client.delete(url)).status_code == 204
    assert _error(await client.get(url), 404) == "watchlist_not_found"


# ---- market data --------------------------------------------------------------------------------------


async def test_quotes_carry_a_status_recomputed_when_read(
    api: App, symbols: dict[str, UUID], clock: FakeClock
) -> None:
    app, client = api
    container = app.state.container
    alpha, bravo = symbols["ALPHA"], symbols["BRAVO"]
    await add_rows(
        container,
        symbols,
        [(LAB, symbol, Provider.SIMULATOR, SubscriptionMode.QUOTE, None) for symbol in ("ALPHA", "BRAVO")],
    )
    await container.bus.set_json(Keys.quote(Provider.SIMULATOR, alpha), _quote(alpha, "ALPHA"))
    stream_id = await _feed(container.bus, Provider.SIMULATOR, None)

    assert _error(await client.get(f"{API}/quotes/latest"), 422) == "quote_selection_required"
    latest = _ok(await client.get(f"{API}/quotes/latest", params={"workspace": LAB}))
    assert [(q["instrument_id"], q["data_status"], q["feed_status"]) for q in latest["items"]] == [
        (str(alpha), "LIVE", "LIVE")
    ]
    assert latest["missing"] == [str(bravo)]

    clock.advance(timedelta(seconds=container.settings.data_stale_after_seconds + 1))
    both = {"instrument_id": [str(alpha), str(bravo)]}
    aged = _ok(await client.get(f"{API}/quotes/latest", params=both))
    assert [(q["data_status"], q["stored_status"]) for q in aged["items"]] == [("STALE", "LIVE")]
    assert aged["missing"] == [str(bravo)]

    await container.bus.redis.delete(Keys.feed_state(stream_id))
    one = {"instrument_id": str(alpha), "provider": "SIMULATOR"}
    orphaned = _ok(await client.get(f"{API}/quotes/latest", params=one))
    assert [(q["data_status"], q["feed_status"]) for q in orphaned["items"]] == [
        ("DISCONNECTED", "DISCONNECTED")
    ]


async def test_candles_come_oldest_first_with_the_forming_one(api: App, symbols: dict[str, UUID]) -> None:
    app, client = api
    container = app.state.container
    alpha = symbols["ALPHA"]
    async with container.db.transaction() as session:
        await upsert_candles(session, [candle_values(_candle(alpha, n, 100 + n)) for n in range(3)])
    forming = _candle(alpha, 15, "103.5", closed=False)  # 09:30 IST, the clock's minute
    await container.bus.set_json(Keys.partial_candle(Provider.SIMULATOR, alpha, CandleInterval.M1), forming)
    await _feed(container.bus, Provider.SIMULATOR, None)
    query: dict[str, Any] = {"instrument": str(alpha), "provider": "SIMULATOR", "interval": "1m"}

    series = _ok(await client.get(f"{API}/candles", params=query))
    assert _closes(series["candles"]) == _prices("100", "101", "102")
    assert (Decimal(series["forming"]["close_price"]), series["forming"]["data_status"]) == (
        Decimal("103.5"),
        "LIVE",
    )
    assert series["feed_status"] == "LIVE"

    newest = _ok(await client.get(f"{API}/candles", params=query | {"limit": 2, "include_forming": False}))
    assert (_closes(newest["candles"]), newest["forming"]) == (_prices("101", "102"), None)
    earlier = _ok(await client.get(f"{API}/candles", params=query | {"until": "2026-01-05T03:47:00Z"}))
    assert (_closes(earlier["candles"]), earlier["forming"]) == (_prices("100", "101"), None)

    unknown = await client.get(f"{API}/candles", params=query | {"instrument": str(uuid4())})
    assert _error(unknown, 404) == "instrument_not_found"
    assert (
        _error(await client.get(f"{API}/candles", params=query | {"interval": "7m"}), 422)
        == "validation_failed"
    )


# ---- strategies, signals and risk ---------------------------------------------------------------------


@pytest.mark.usefixtures("no_strategies")
async def test_a_strategy_configuration_is_saved_enabled_and_archived_over_the_api(
    api: App, symbols: dict[str, UUID]
) -> None:
    app, client = api
    container: Container = app.state.container
    await add_rows(container, symbols, [(LAB, "ALPHA", Provider.SIMULATOR, SubscriptionMode.QUOTE, None)])
    _ok(await client.post(f"{API}/strategies/sync"))
    assert EXAMPLE in {s["strategy_id"] for s in _ok(await client.get(f"{API}/strategies"))}
    assert _ok(await client.get(f"{API}/strategies/{EXAMPLE}"))["strategy_id"] == EXAMPLE
    assert _error(await client.get(f"{API}/strategies/example.missing"), 404) == "strategy_not_found"

    url = f"{API}/deployments"
    alpha, bravo = str(symbols["ALPHA"]), str(symbols["BRAVO"])  # BRAVO is not in the workspace
    new = {"workspace": LAB, "strategy_id": EXAMPLE}
    # The scope is always chosen explicitly, and must make sense.
    assert _error(await client.post(url, json=new), 422) == "validation_failed"
    for scope in ({"kind": "INSTRUMENTS"}, {"kind": "WORKSPACE", "instrument_ids": [alpha]}):
        assert _error(await client.post(url, json=new | {"scope": scope}), 422) == "deployment_scope_invalid"
    only_alpha = {"kind": "INSTRUMENTS", "instrument_ids": [alpha]}
    saved = _ok(await client.post(url, json=new | {"scope": only_alpha, "label": " Alpha trend "}), 201)
    assert (saved["label"], saved["is_enabled"], saved["scope_kind"], saved["instrument_ids"]) == (
        "Alpha trend",
        False,
        "INSTRUMENTS",
        [alpha],
    )
    assert saved["monitoring"] == {"state": "STOPPED", "reasons": [], "warnings": [SIMULATED], "warmup": None}
    item = f"{url}/{saved['id']}"

    heartbeat = Keys.worker_heartbeat(STRATEGY_WORKER)
    await container.bus.delete(heartbeat)
    enabled = _ok(await client.post(f"{item}/enable"))
    assert (enabled["is_enabled"], enabled["monitoring"]["state"], enabled["monitoring"]["reasons"]) == (
        True,
        "FAILED",
        ["The strategy worker is not running (no recent heartbeat); start qt-strategy-worker"],
    )
    await container.bus.set_json(heartbeat, {"worker": STRATEGY_WORKER}, ttl_seconds=60)
    try:
        again = _ok(await client.post(f"{item}/enable"))  # asking again changes nothing
        assert (again["enabled_at"], again["updated_at"]) == (enabled["enabled_at"], enabled["updated_at"])
        assert (again["monitoring"]["state"], again["monitoring"]["reasons"]) == (
            "STARTING",
            ["Waiting for the strategy worker to start a run with the current settings"],
        )
    finally:
        await container.bus.delete(heartbeat)

    # Another configuration with the same settings on an overlapping scope cannot run alongside it.
    whole = _ok(await client.post(url, json=new | {"scope": {"kind": "WORKSPACE"}}), 201)
    assert (whole["label"], whole["scope_kind"], whole["instrument_ids"]) == (EXAMPLE, "WORKSPACE", [])
    assert _error(await client.post(f"{url}/{whole['id']}/enable"), 409) == "deployment_duplicate"
    changed = _ok(await client.patch(f"{url}/{whole['id']}", json={"config": {"valid_for_minutes": 30}}))
    assert (
        changed["config"]["valid_for_minutes"],
        changed["configuration_id"] != whole["configuration_id"],
    ) == (
        30,
        True,
    )
    assert _ok(await client.post(f"{url}/{whole['id']}/enable"))["is_enabled"] is True
    covering = _ok(await client.get(url, params={"workspace": LAB, "instrument_id": alpha}))
    assert sorted(d["label"] for d in covering) == sorted(["Alpha trend", EXAMPLE])
    assert _ok(await client.get(url, params={"instrument_id": bravo})) == []

    assert _error(await client.post(f"{item}/archive"), 409) == "deployment_enabled"
    assert _ok(await client.post(f"{item}/disable"))["monitoring"]["state"] == "STOPPED"
    assert _ok(await client.post(f"{item}/archive"))["archived_at"] is not None
    assert _error(await client.patch(item, json={"label": "Again"}), 409) == "deployment_archived"
    assert _error(await client.patch(item, json={"surprise": 1}), 422) == "validation_failed"
    assert [d["id"] for d in _ok(await client.get(url, params={"workspace": LAB}))] == [whole["id"]]
    every = _ok(await client.get(url, params={"workspace": LAB, "include_archived": True}))
    assert sorted(d["id"] for d in every) == sorted([saved["id"], whole["id"]])
    assert _ok(await client.get(item))["monitoring"]["state"] == "STOPPED"
    runs = await client.get(f"{API}/strategy-runs", params={"workspace": LAB, "deployment_id": whole["id"]})
    assert _ok(runs) == []
    assert _error(await client.get(f"{url}/{uuid4()}"), 404) == "deployment_not_found"


@pytest.mark.usefixtures("no_strategies")
async def test_the_strategies_suiting_an_instrument_are_checked_over_the_api(
    api: App, symbols: dict[str, UUID]
) -> None:
    app, client = api
    container: Container = app.state.container
    await add_rows(container, symbols, [(LAB, "ALPHA", Provider.SIMULATOR, SubscriptionMode.QUOTE, None)])
    url = f"{API}/strategy-compatibility"
    alpha = {"workspace": LAB, "instrument_id": str(symbols["ALPHA"])}

    shown = _ok(await client.get(url, params=alpha | {"chart_interval": "1m"}))
    assert (shown["provider"], shown["subscription_mode"], shown["chart_interval"]) == (
        "SIMULATOR",
        "QUOTE",
        "1m",
    )
    example = next(item for item in shown["strategies"] if item["strategy_id"] == EXAMPLE)
    assert [(check["aspect"], check["status"]) for check in example["checks"]] == [
        ("MARKET", "PASSED"),
        ("INSTRUMENT", "PASSED"),
        ("TIMEFRAME", "PASSED"),
        ("DATA", "WARNING"),  # simulated
        ("WARMUP", "WARNING"),  # no candles stored yet
    ]
    assert (example["compatible"], example["warmup"]) == (
        True,
        [{"interval": "1m", "needed": 63, "stored": 0}],
    )

    bravo = alpha | {"instrument_id": str(symbols["BRAVO"])}  # not in the workspace
    assert _error(await client.get(url, params=bravo), 404) == "instrument_not_in_workspace"
    assert _error(await client.get(url, params=alpha | {"chart_interval": "7m"}), 422) == "validation_failed"
    assert _error(await client.get(url, params={"workspace": LAB}), 422) == "validation_failed"


@pytest.mark.usefixtures("no_strategies")
async def test_signal_queries_are_validated(api: App) -> None:
    _app, client = api
    assert _ok(await client.get(f"{API}/signals")) == {"items": [], "next_cursor": None}
    backwards = {"since": "2026-01-05T05:00:00Z", "until": "2026-01-05T04:00:00Z"}
    assert _error(await client.get(f"{API}/signals", params=backwards), 422) == "validation_failed"
    assert _error(await client.get(f"{API}/signals", params={"status": "MAYBE"}), 422) == "validation_failed"
    assert _error(await client.get(f"{API}/signals/{uuid4()}"), 404) == "signal_not_found"


@pytest.mark.usefixtures("no_strategies")
async def test_risk_rules_are_tuned_per_workspace_and_workspaces_paused(api: App) -> None:
    _app, client = api
    rules = _ok(await client.get(f"{API}/risk/rules"))
    rule = next(r for r in rules if not r["mandatory"] and r["rule_key"] != "workspace_pause")
    url = f"{API}/risk/rules/{rule['rule_key']}"
    assert _error(await client.put(url, json={}), 422) == "validation_failed"
    assert _error(await client.get(f"{API}/risk/rules/no_such_rule"), 404) == "risk_rule_not_found"

    scoped = _ok(await client.put(url, params={"workspace": LAB}, json={"enabled": not rule["enabled"]}))
    assert (scoped["enabled"], scoped["workspace_slug"]) == (not rule["enabled"], LAB)
    assert _ok(await client.get(url))["enabled"] == rule["enabled"]
    reset = _ok(await client.post(f"{url}/reset", params={"workspace": LAB}))
    assert reset["enabled"] == rule["enabled"]

    paused = _ok(await client.post(f"{API}/risk/workspaces/{LAB}/pause", json={"reason": "maintenance"}))
    assert (paused["rule_key"], paused["params"]["paused"], paused["params"]["reason"]) == (
        "workspace_pause",
        True,
        "maintenance",
    )
    resumed = _ok(await client.post(f"{API}/risk/workspaces/{LAB}/resume"))
    assert resumed["params"]["paused"] is False
    assert _ok(await client.post(f"{API}/risk/workspaces/{LAB}/pause"))["params"]["reason"] is None


# ---- backtests -------------------------------------------------------------------------------------


async def _drain(worker: BacktestWorker) -> None:
    """Let the backtest worker take every waiting job."""
    for _ in range(20):
        if not await worker.run_once():
            return
    raise AssertionError("the backtest worker kept finding jobs")


async def test_a_configuration_is_backtested_on_a_recorded_dataset_over_the_api(
    api: App, clock: FakeClock, history_lab: dict[str, UUID]
) -> None:
    app, client = api
    container: Container = app.state.container
    registry = fixture_registry()  # the app's services and the worker share it, as in the app
    app.dependency_overrides[get_strategies] = lambda: StrategyService(
        container.db, container.bus, registry=registry, clock=clock
    )
    app.dependency_overrides[get_backtests] = lambda: BacktestService.from_container(
        container, registry=registry, clock=clock
    )
    calendars = app.state.market_calendar
    worker = BacktestWorker(
        DatasetService.from_container(container, calendars, transport=FakeProvider().transport, clock=clock),
        BacktestService.from_container(container, registry=registry, clock=clock),
        calendars,
        worker_id="api-test-worker",
        poll_seconds=0,
        clock=clock,
    )

    # Where BTONE's datasets can come from: here, the candles recorded from Zerodha's feed.
    sources = _ok(await client.get(f"{API}/datasets/sources", params={"instrument": ONE}))
    recorded = next(o for o in sources["options"] if (o["provider"], o["source"]) == ("ZERODHA", "RECORDED"))
    assert (recorded["available"], recorded["recorded"]) == (
        True,
        [
            {
                "interval": "1m",
                "candles": 13,
                "first_candle_at": "2026-01-05T03:45:00Z",
                "last_candle_at": "2026-01-05T04:00:00Z",
            }
        ],
    )
    assert (sources["today"], sources["worker_problem"]) == ("2026-01-05", NO_WORKER)

    url = f"{API}/datasets"
    body = {
        "instrument": ONE,
        "provider": "ZERODHA",
        "source": "RECORDED",
        "interval": "1m",
        "date_from": "2026-01-05",
        "date_to": "2026-01-05",
    }
    first = _ok(await client.post(url, json=body), 202)
    again = _ok(await client.post(url, json=body), 202)
    assert (first["created"], first["dataset"]["status"], again["created"], again["dataset"]["id"]) == (
        True,
        "PENDING",
        False,
        first["dataset"]["id"],
    )
    tomorrow = body | {"date_from": "2026-01-06", "date_to": "2026-01-06"}
    assert _error(await client.post(url, json=tomorrow), 422) == "dataset_dates_invalid"
    assert _error(await client.post(url, json=body | {"source": "ELSEWHERE"}), 422) == "validation_failed"
    assert _error(await client.post(url, json=body | {"surprise": 1}), 422) == "validation_failed"
    unknown = body | {"instrument": "NSE:CASH:EQUITY:NOSUCH"}
    assert _error(await client.post(url, json=unknown), 404) == "instrument_not_found"

    await _drain(worker)
    dataset = _ok(await client.get(f"{url}/{first['dataset']['id']}"))
    coverage = dataset["coverage"]
    assert (dataset["status"], dataset["candle_count"], coverage["expected"], coverage["missing"]) == (
        "READY",
        13,
        15,
        2,
    )
    assert coverage["gaps"] == [
        {"start": "2026-01-05T03:52:00Z", "end": "2026-01-05T03:54:00Z", "candles": 2}
    ]
    listed = _ok(await client.get(url, params={"instrument": ONE, "status": "READY"}))
    assert [item["id"] for item in listed] == [dataset["id"]]
    assert _error(await client.get(f"{url}/{uuid4()}"), 404) == "dataset_not_found"

    # A registered strategy, saved for BTONE alone, has no trade rules until they are set.
    _ok(await client.post(f"{API}/strategies/sync"))
    assert TRADER.strategy_id in {s["strategy_id"] for s in _ok(await client.get(f"{API}/strategies"))}
    only_one = {"kind": "INSTRUMENTS", "instrument_ids": [str(history_lab[ONE])]}
    new = {"workspace": INDIA, "strategy_id": TRADER.strategy_id, "scope": only_one, "label": "Trader"}
    saved = _ok(await client.post(f"{API}/deployments", json=new), 201)
    rules_url = f"{API}/deployments/{saved['id']}/backtest-rules"
    unset = _ok(await client.get(rules_url))
    assert (unset["effective"], unset["source"], unset["problem"]) == (None, None, NO_RULES)
    run_body = {"deployment_id": saved["id"], "instrument": ONE, "dataset_id": dataset["id"]}
    assert _error(await client.post(f"{API}/backtests", json=run_body), 409) == "backtest_rules_missing"
    latest_query = {"deployment_id": saved["id"], "instrument": ONE}
    latest = _ok(await client.get(f"{API}/backtests/latest", params=latest_query))
    assert (latest["state"], latest["problem"], latest["current"]) == ("NOT_BACKTESTED", NO_RULES, None)

    rules = trade_rules().model_dump(mode="json")
    assert _error(await client.put(rules_url, json=rules | {"quantity": 0}), 422) == "validation_failed"
    stored = _ok(await client.put(rules_url, json=rules))
    assert (stored["effective"], stored["source"], stored["problem"]) == (rules, "CONFIGURATION", None)

    # Asking again while it waits returns the same backtest; a dataset backtests only its own instrument.
    queued = _ok(await client.post(f"{API}/backtests", json=run_body), 202)
    repeated = _ok(await client.post(f"{API}/backtests", json=run_body), 202)
    run_id = queued["run"]["id"]
    assert (queued["created"], queued["run"]["status"], queued["worker_problem"]) == (
        True,
        "QUEUED",
        NO_WORKER,
    )
    assert (repeated["created"], repeated["run"]["id"]) == (False, run_id)
    other = run_body | {"instrument": TWO}
    assert _error(await client.post(f"{API}/backtests", json=other), 422) == "backtest_dataset_mismatch"

    await _drain(worker)
    latest = _ok(await client.get(f"{API}/backtests/latest", params=latest_query))
    assert (latest["state"], latest["current"]["id"], latest["current"]["outdated"]) == (
        "CURRENT",
        run_id,
        False,
    )
    detail = _ok(await client.get(f"{API}/backtests/{run_id}"))
    assert (detail["run"]["status"], detail["dataset"]["id"], detail["changed"]) == (
        "SUCCEEDED",
        dataset["id"],
        [],
    )
    metrics = detail["run"]["summary"]["metrics"]
    assert (metrics["closed_trades"], metrics["wins"], metrics["losses"], metrics["breakevens"]) == (
        1,
        1,
        0,
        0,
    )
    assert (Decimal(metrics["net_pnl"]), Decimal(metrics["win_rate_pct"]["value"])) == (
        Decimal(37),
        Decimal(100),
    )
    assert metrics["profit_factor"] == {"value": None, "reason": TARGET_ONLY}
    assert [Decimal(point["equity"]) for point in detail["equity_curve"]] == [
        Decimal(100_000),
        Decimal(100_000),
        Decimal(100_003),
        *[Decimal(100_037)] * 8,
    ]

    trades_url = f"{API}/backtests/{run_id}/trades"
    page = _ok(await client.get(trades_url, params={"limit": 10}))
    [trade] = page["trades"]
    assert (page["total"], trade["number"], trade["side"], trade["exit_reason"], trade["outcome"]) == (
        1,
        1,
        "LONG",
        "TARGET",
        "WIN",
    )
    assert [Decimal(trade[name]) for name in ("entry_price", "exit_price", "net_pnl")] == _prices(
        "100.50", "104.20", "37.00"
    )
    assert _error(await client.get(trades_url, params={"limit": 501}), 422) == "validation_failed"
    assert _error(await client.get(f"{API}/backtests/{uuid4()}"), 404) == "backtest_not_found"

    # Other trade rules outdate the result, which stays listed for comparison.
    _ok(await client.put(rules_url, json=rules | {"quantity": 20}))
    latest = _ok(await client.get(f"{API}/backtests/latest", params=latest_query))
    assert (latest["state"], latest["current"], latest["outdated"]["id"], latest["changed"]) == (
        "OUTDATED",
        None,
        run_id,
        ["trade_rules.quantity"],
    )
    listed = _ok(await client.get(f"{API}/backtests", params={"deployment_id": saved["id"]}))
    assert [(item["id"], item["outdated"]) for item in listed] == [(run_id, True)]
    cleared = _ok(await client.delete(rules_url))
    assert (cleared["effective"], cleared["problem"]) == (None, NO_RULES)
    assert (
        _error(await client.get(f"{API}/deployments/{uuid4()}/backtest-rules"), 404) == "deployment_not_found"
    )


# ---- the whole journey (EXT-7.1) -------------------------------------------------------------------


async def test_a_strategy_goes_from_the_chart_through_a_backtest_to_live_signals_and_back_over_the_api(
    api: App, clock: FakeClock, history_lab: dict[str, UUID]
) -> None:
    """EXT-7.1 in one pass on BTONE: open its chart, choose and save a strategy configuration, backtest it
    on the recorded session, inspect the result, turn live signals on, inspect the signal of the next
    morning, then turn live signals off."""
    app, client = api
    container: Container = app.state.container
    db, bus = container.db, container.bus
    registry = StrategyRegistry([DAILY.cls])  # the app's services and both workers share it
    settings = container.settings.model_copy(update={"live_signals_enabled": True})
    strategies = StrategyService(db, bus, registry=registry, clock=clock, live_signals_enabled=True)
    app.dependency_overrides[get_strategies] = lambda: strategies
    app.dependency_overrides[get_backtests] = lambda: BacktestService.from_container(
        container, registry=registry, clock=clock
    )
    calendars = app.state.market_calendar
    backtester = BacktestWorker(
        DatasetService.from_container(container, calendars, transport=FakeProvider().transport, clock=clock),
        BacktestService.from_container(container, registry=registry, clock=clock),
        calendars,
        worker_id="journey-backtest-worker",
        poll_seconds=0,
        clock=clock,
    )
    one = str(history_lab[ONE])

    # Open BTONE's chart: its recorded candles, and the strategy that suits it once the catalogue is synced.
    chart = {"instrument": one, "provider": "ZERODHA", "interval": "1m"}
    assert len(_ok(await client.get(f"{API}/candles", params=chart))["candles"]) == 13
    _ok(await client.post(f"{API}/strategies/sync"))
    suits = {"workspace": INDIA, "instrument_id": one, "chart_interval": "1m"}
    [offered] = _ok(await client.get(f"{API}/strategy-compatibility", params=suits))["strategies"]
    assert (offered["strategy_id"], offered["compatible"]) == (DAILY.strategy_id, True)

    # Choose it for BTONE alone, with trade rules: a saved configuration that nothing monitors yet.
    scope = {"kind": "INSTRUMENTS", "instrument_ids": [one]}
    new = {"workspace": INDIA, "strategy_id": DAILY.strategy_id, "scope": scope, "label": "BTONE mornings"}
    saved = _ok(await client.post(f"{API}/deployments", json=new), 201)
    assert (saved["is_enabled"], saved["monitoring"]["state"]) == (False, "STOPPED")
    item = f"{API}/deployments/{saved['id']}"
    _ok(await client.put(f"{item}/backtest-rules", json=trade_rules().model_dump(mode="json")))
    latest_query = {"deployment_id": saved["id"], "instrument": ONE}
    latest = _ok(await client.get(f"{API}/backtests/latest", params=latest_query))
    assert (latest["state"], latest["current"]) == ("NOT_BACKTESTED", None)

    # Backtest it on the recorded session, whose dataset shows the two missing candles.
    wanted = {"instrument": ONE, "provider": "ZERODHA", "source": "RECORDED", "interval": "1m"}
    day = {"date_from": "2026-01-05", "date_to": "2026-01-05"}
    dataset_id = _ok(await client.post(f"{API}/datasets", json=wanted | day), 202)["dataset"]["id"]
    await _drain(backtester)
    dataset = _ok(await client.get(f"{API}/datasets/{dataset_id}"))
    assert (dataset["status"], dataset["candle_count"], dataset["coverage"]["missing"]) == ("READY", 13, 2)
    run_body = {"deployment_id": saved["id"], "instrument": ONE, "dataset_id": dataset_id}
    run_id = _ok(await client.post(f"{API}/backtests", json=run_body), 202)["run"]["id"]
    await _drain(backtester)

    # Inspect the result: the configuration's current backtest, with its one winning trade.
    latest = _ok(await client.get(f"{API}/backtests/latest", params=latest_query))
    assert (latest["state"], latest["current"]["id"]) == ("CURRENT", run_id)
    result = _ok(await client.get(f"{API}/backtests/{run_id}"))
    metrics = result["run"]["summary"]["metrics"]
    assert (result["run"]["status"], metrics["closed_trades"], metrics["wins"], metrics["losses"]) == (
        "SUCCEEDED",
        1,
        1,
        0,
    )
    [trade] = _ok(await client.get(f"{API}/backtests/{run_id}/trades"))["trades"]
    assert (trade["side"], trade["exit_reason"], Decimal(trade["net_pnl"])) == ("LONG", "TARGET", Decimal(37))

    # The next morning, turn live signals on (asking twice changes nothing); the worker starts one run,
    # warmed up from the stored candles.
    clock.advance(T0 + timedelta(days=1, minutes=2) - clock())  # 09:17 IST on Tuesday 6 January
    heartbeat = Keys.worker_heartbeat(STRATEGY_WORKER)
    await bus.set_json(heartbeat, {"worker": STRATEGY_WORKER}, ttl_seconds=60)
    calendar = await load_market_calendar(db)
    worker = StrategyWorker(
        settings,
        bus,
        db,
        strategies,
        RunStore(db, clock=clock),
        SignalEngine(db, bus, settings, calendar, clock=clock),
        calendar,
        load_overrides=partial(load_overrides, db),
        worker_id="journey-strategy-worker",
        block_ms=10,
        clock=clock,
        monotonic=lambda: 1000.0,  # no periodic refresh: only the test's commands reach it
    )
    try:
        enabled = _ok(await client.post(f"{item}/enable"))
        again = _ok(await client.post(f"{item}/enable"))
        assert (enabled["monitoring"]["state"], again["enabled_at"]) == ("STARTING", enabled["enabled_at"])
        await worker.start()
        assert _ok(await client.get(item))["monitoring"]["state"] == "RUNNING"

        # The 09:18 candle closes and the strategy proposes its BUY; inspect the signal.
        clock.advance(timedelta(minutes=2, seconds=5))
        start = T0 + timedelta(days=1, minutes=3)
        candle = bar(
            0,
            "100.10",
            open_="100",
            high="100.20",
            low="99.90",
            start=start,
            instrument_id=history_lab[ONE],
            symbol="BTONE",
        )
        await bus.publish(Streams.CANDLES, candle)
        await worker.step()
        [listed] = _ok(await client.get(f"{API}/signals", params={"deployment_id": saved["id"]}))["items"]
        detail = _ok(await client.get(f"{API}/signals/{listed['id']}"))
        signal = detail["signal"]
        assert (signal["signal_type"], signal["status"], signal["is_actionable"]) == ("BUY", "ACTIVE", True)
        assert (signal["symbol"], signal["provider"], signal["source_candle_start"]) == (
            "BTONE",
            "ZERODHA",
            "2026-01-06T03:48:00Z",
        )
        assert [Decimal(signal[name]) for name in ("entry_price", "stop_loss")] == _prices("100.10", "98.05")
        assert [(target["label"], Decimal(target["price"])) for target in signal["targets"]] == [
            ("T1", Decimal("104.20"))
        ]
        assert (signal["explanation"], [value["name"] for value in signal["indicator_values"]]) == (
            "Bullish EMA crossover",
            ["ema_fast"],
        )
        used = detail["configuration"]
        assert (
            used["deployment_label"],
            used["config_hash"],
            used["code_fingerprint"],
            used["is_current"],
        ) == (
            "BTONE mornings",
            saved["config_hash"],
            registry.get(DAILY.strategy_id).fingerprint,
            True,
        )
        [decision] = detail["decisions"]
        failed = [check["rule"] for check in decision["checks"] if not check["passed"]]
        assert (decision["outcome"], failed) == ("ALLOW", [])

        # Turn live signals off: monitoring stops at once, and the run once the worker hears of it.
        stopped = _ok(await client.post(f"{item}/disable"))
        assert (stopped["is_enabled"], stopped["monitoring"]["state"]) == (False, "STOPPED")
        await worker.step()  # reads the reload command
        await worker.step()  # refreshes the runs
    finally:
        await worker.stop()
        await bus.delete(heartbeat)

    runs = _ok(
        await client.get(f"{API}/strategy-runs", params={"workspace": INDIA, "deployment_id": saved["id"]})
    )
    assert [(run["status"], run["candles_processed"], run["signals_emitted"]) for run in runs] == [
        ("STOPPED", 1, 1)
    ]
    # Monitoring does not touch the backtest, which stays current; the signal stays in the history.
    latest = _ok(await client.get(f"{API}/backtests/latest", params=latest_query))
    assert (latest["state"], latest["current"]["id"]) == ("CURRENT", run_id)
    history = _ok(await client.get(f"{API}/signals", params={"instrument": ONE}))["items"]
    assert [entry["id"] for entry in history] == [listed["id"]]
