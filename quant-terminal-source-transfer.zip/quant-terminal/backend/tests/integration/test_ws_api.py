"""The WebSocket API: handshake rules, the protocol, and each channel's snapshot and updates.

The hub reads the real clock, so quotes, candles and feed states written here are stamped now.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import AsyncExitStack, asynccontextmanager
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

import httpx
import pytest
from fastapi import FastAPI

from app.api.ws.routes import MAX_CONNECTIONS_PER_USER
from app.core.clock import utc_now
from app.core.config import Settings
from app.domain.enums import (
    CandleInterval,
    ConnectionState,
    DataStatus,
    EventType,
    Exchange,
    MarketRegion,
    Provider,
    RiskOutcome,
    Segment,
    SignalEventType,
    SignalStatus,
    SignalType,
    SubscriptionMode,
)
from app.domain.events import FeedStateChange, SignalUpdate
from app.domain.models import Candle, QuoteSnapshot, StreamHealth
from app.domain.models.signal import RiskDecision, Signal
from app.services.auth_service import AuthService
from app.streaming.redis_bus import Keys, RedisBus, Streams
from tests.candle_support import bar
from tests.integration.conftest import api_client
from tests.integration.provider_support import LAB, add_rows, provider_settings
from tests.integration.ws_support import WsClosed, WsConnection

pytestmark = pytest.mark.integration

API = "/api/v1"
MARKET = "/ws/v1/market"
SIGNALS = "/ws/v1/signals"
SYSTEM = "/ws/v1/system"
PASSWORD = "ws-api-test-password"


@dataclass
class Live:
    """The running app, a signed-in HTTP client of it, and its session cookie."""

    app: FastAPI
    client: httpx.AsyncClient
    symbols: dict[str, UUID]
    cookie: str

    @property
    def bus(self) -> RedisBus:
        bus: RedisBus = self.app.state.container.bus
        return bus

    def connect(self, path: str = MARKET, *, outbox_size: int = 0, **headers: str | None) -> WsConnection:
        """A connection from the frontend's origin with the session cookie, unless ``headers`` differ."""
        values = {"cookie": self.cookie, "origin": self.app.state.container.settings.allowed_origins[0]}
        values |= headers
        return WsConnection(
            self.app, path, cookie=values["cookie"], origin=values["origin"], outbox_size=outbox_size
        )


@asynccontextmanager
async def _live(settings: Settings, symbols: dict[str, UUID], **overrides: Any) -> AsyncIterator[Live]:
    async with api_client(provider_settings(settings, **overrides)) as (app, client):
        yield Live(app, client, symbols, await _login(app, client))


@pytest.fixture
async def live(migrated_database: Settings, symbols: dict[str, UUID]) -> AsyncIterator[Live]:
    async with _live(migrated_database, symbols) as instance:
        yield instance


async def _login(app: FastAPI, client: httpx.AsyncClient) -> str:
    """Sign a new user in; the session cookie as a browser sends it."""
    container = app.state.container
    username = f"ws{uuid4().hex[:10]}"
    auth = AuthService(container.db, container.bus, container.settings)
    await auth.create_user(username, PASSWORD, actor="test")
    response = await client.post(f"{API}/auth/login", json={"username": username, "password": PASSWORD})
    assert response.status_code == 200, response.text
    name = container.settings.session_cookie_name
    return f"{name}={client.cookies[name]}"


async def _subscribe(ws: WsConnection, **fields: Any) -> dict[str, Any]:
    """Subscribe; the ack."""
    await ws.send_json({"action": "subscribe", **fields})
    return await ws.expect("subscribed")


async def _error(ws: WsConnection, message: dict[str, Any] | str) -> tuple[str, str | None]:
    """The code and request ID of the error a message is answered with."""
    if isinstance(message, str):
        await ws.send_text(message)
    else:
        await ws.send_json(message)
    error = await ws.expect("error")
    return error["code"], error["request_id"]


async def _feed(bus: RedisBus, provider: Provider = Provider.SIMULATOR) -> str:
    """Report a connected, live feed stream, as a market-data worker does."""
    now = utc_now()
    stream_id = f"{provider.value.lower()}:None:0"
    health = StreamHealth(
        provider=provider,
        account_id=None,
        stream_id=stream_id,
        state=ConnectionState.CONNECTED,
        data_status=DataStatus.LIVE,
        state_since=now,
        updated_at=now,
    )
    await bus.set_json(Keys.feed_state(stream_id), health)
    return stream_id


def _state_change(provider: Provider) -> FeedStateChange:
    return FeedStateChange(
        provider=provider,
        account_id=None,
        stream_id=f"{provider.value.lower()}:None:0",
        previous_state=ConnectionState.CONNECTED,
        state=ConnectionState.RECONNECTING,
        reason="socket closed",
        at=utc_now(),
    )


def _quote(instrument_id: UUID, symbol: str, price: str) -> QuoteSnapshot:
    now = utc_now()
    return QuoteSnapshot(
        provider=Provider.SIMULATOR,
        account_id=None,
        instrument_id=instrument_id,
        symbol=symbol,
        exchange=Exchange.SIM,
        segment=Segment.CASH,
        last_event_type=EventType.QUOTE,
        received_at=now,
        processed_at=now,
        data_status=DataStatus.LIVE,
        last_price=Decimal(price),
    )


def _candle(instrument_id: UUID, symbol: str, start: datetime, close: str, *, closed: bool) -> Candle:
    return bar(
        0,
        close,
        closed=closed,
        start=start,
        instrument_id=instrument_id,
        provider=Provider.SIMULATOR,
        exchange=Exchange.SIM,
        symbol=symbol,
    )


def _signal(workspace_id: UUID, instrument_id: UUID) -> SignalUpdate:
    now = utc_now()
    signal = Signal(
        id=uuid4(),
        workspace_id=workspace_id,
        market_region=MarketRegion.INDIA,
        instrument_id=instrument_id,
        symbol="ALPHA",
        exchange=Exchange.SIM,
        segment=Segment.CASH,
        provider=Provider.SIMULATOR,
        account_id=None,
        strategy_id="example.ema_crossover",
        strategy_version="1.0.0",
        deployment_id=uuid4(),
        strategy_run_id=uuid4(),
        signal_type=SignalType.BUY,
        status=SignalStatus.ACTIVE,
        is_actionable=False,
        generated_at=now,
        updated_at=now,
        data_status=DataStatus.LIVE,
        reasons=("EMA 9 crossed above EMA 21",),
        explanation="Simulated data: informational only",
        risk_decision=RiskDecision(outcome=RiskOutcome.ALLOW, checks=(), evaluated_at=now),
    )
    return SignalUpdate(event_type=SignalEventType.ACTIVATED, signal=signal, at=now)


# ---- connections --------------------------------------------------------------------------------------


async def test_a_handshake_needs_an_allowed_origin_and_a_live_session(live: Live) -> None:
    with pytest.raises(WsClosed) as refused:
        async with live.connect(origin="https://evil.example"):
            pass
    assert (refused.value.code, refused.value.reason) == (1008, "origin_not_allowed")

    name = live.cookie.split("=", 1)[0]
    for cookie in (None, f"{name}=not-a-session"):
        async with live.connect(cookie=cookie) as ws:
            closed = await ws.closed()
        assert (closed.code, closed.reason) == (4401, "unauthenticated")

    async with live.connect(origin=None) as ws:  # not a browser, so no Origin header
        assert (await ws.receive())["type"] == "welcome"


async def test_the_protocol_answers_each_request_and_refuses_bad_ones(live: Live) -> None:
    alpha = str(live.symbols["ALPHA"])
    async with live.connect() as ws:
        welcome = await ws.expect("welcome")
        assert welcome["channels"] == ["candles", "feed", "quotes"]
        assert (welcome["max_instruments"], welcome["heartbeat_interval_seconds"]) == (500, 15.0)
        assert 4401 in welcome["reconnect"]["final_close_codes"]

        await ws.send_json({"action": "heartbeat", "request_id": "hb-1"})
        assert (await ws.expect("heartbeat"))["request_id"] == "hb-1"
        assert await _error(ws, "not json") == ("invalid_message", None)
        too_many = [str(uuid4()) for _ in range(501)]
        refusals: list[tuple[dict[str, Any], str]] = [
            ({"channel": "quotes", "extra": 1}, "invalid_message"),
            ({"channel": "quotes", "instrument_ids": too_many}, "invalid_message"),
            ({"channel": "signals"}, "channel_not_available"),
            ({"channel": "quotes"}, "selection_required"),
            ({"channel": "candles", "instrument_ids": [alpha]}, "interval_required"),
            ({"channel": "feed", "interval": "1m"}, "option_not_allowed"),
            ({"channel": "quotes", "workspace_id": "no-such-space"}, "workspace_not_found"),
        ]
        for n, (fields, code) in enumerate(refusals):
            message = {"action": "subscribe", "request_id": f"r-{n}", **fields}
            assert await _error(ws, message) == (code, f"r-{n}")

        await ws.send_json({"action": "unsubscribe", "channel": "quotes", "request_id": "u"})
        assert (await ws.expect("unsubscribed"))["request_id"] == "u"
        await ws.send_bytes(b"\x00")
        closed = await ws.closed()
    assert (closed.code, closed.reason) == (1003, "text_frames_only")


async def test_connections_are_counted_capped_per_user_and_closed_on_shutdown(live: Live) -> None:
    async with AsyncExitStack() as stack:
        sockets = [
            await stack.enter_async_context(live.connect(SYSTEM)) for _ in range(MAX_CONNECTIONS_PER_USER)
        ]
        for ws in sockets:
            await ws.expect("welcome")
        metrics = await live.client.get(f"{API}/system/metrics")
        assert metrics.json()["websocket_clients"] == MAX_CONNECTIONS_PER_USER
        async with live.connect(SYSTEM) as extra:
            closed = await extra.closed()
        assert (closed.code, closed.reason) == (1008, "too_many_connections")

        await live.app.state.ws_hub.stop()
        for ws in sockets:
            closed = await ws.closed()
            assert (closed.code, closed.reason) == (1001, "server_shutdown")


async def test_signing_out_ends_the_connections_of_the_session(
    migrated_database: Settings, symbols: dict[str, UUID]
) -> None:
    settings = {"ws_heartbeat_interval_seconds": 0.2}
    async with _live(migrated_database, symbols, **settings) as live, live.connect(SYSTEM) as ws:
        await ws.expect("welcome")
        beat = await ws.receive()
        assert (beat["type"], beat["request_id"]) == ("heartbeat", None)
        assert (await live.client.post(f"{API}/auth/logout")).is_success
        closed = await ws.closed()
    assert (closed.code, closed.reason) == (4401, "session_expired")


async def test_a_client_too_slow_to_take_its_events_is_disconnected(
    migrated_database: Settings, symbols: dict[str, UUID]
) -> None:
    settings = {"ws_client_queue_size": 3}
    async with (
        _live(migrated_database, symbols, **settings) as live,
        live.connect(SIGNALS, outbox_size=1) as ws,
    ):
        await ws.expect("welcome")
        ack = await _subscribe(ws, channel="signals")
        assert ack["workspace"] is None
        for _ in range(20):
            await live.bus.publish(Streams.SIGNALS, _signal(uuid4(), live.symbols["ALPHA"]))
        closed = await ws.closed()
    assert (closed.code, closed.reason) == (1013, "slow_client")


# ---- channels -----------------------------------------------------------------------------------------


async def test_quotes_come_as_a_snapshot_then_as_they_change(live: Live) -> None:
    container = live.app.state.container
    alpha, bravo = live.symbols["ALPHA"], live.symbols["BRAVO"]
    await add_rows(
        container,
        live.symbols,
        [(LAB, symbol, Provider.SIMULATOR, SubscriptionMode.QUOTE, None) for symbol in ("ALPHA", "BRAVO")],
    )
    stream_id = await _feed(live.bus)
    await live.bus.set_json(Keys.quote(Provider.SIMULATOR, alpha), _quote(alpha, "ALPHA", "101.5"))

    async with live.connect() as ws:
        await ws.expect("welcome")
        ack = await _subscribe(ws, channel="quotes", workspace_id=LAB, request_id="q")
        assert (ack["workspace"]["slug"], sorted(ack["instrument_ids"])) == (
            LAB,
            sorted([str(alpha), str(bravo)]),
        )
        snapshot = await ws.expect("quote.snapshot")
        assert [(q["symbol"], q["last_price"], q["data_status"]) for q in snapshot["items"]] == [
            ("ALPHA", "101.5", "LIVE")
        ]
        assert (snapshot["missing"], snapshot["request_id"]) == ([str(bravo)], "q")
        assert "market_depth" not in snapshot["items"][0]

        await live.bus.set_json(Keys.quote(Provider.SIMULATOR, bravo), _quote(bravo, "BRAVO", "55"))
        update = await ws.expect("quote.update")
        assert [(q["symbol"], q["last_price"]) for q in update["items"]] == [("BRAVO", "55")]

        await live.bus.redis.delete(Keys.feed_state(stream_id))
        orphaned = await ws.expect("quote.update")
        assert sorted((q["symbol"], q["data_status"], q["feed_status"]) for q in orphaned["items"]) == [
            ("ALPHA", "DISCONNECTED", "DISCONNECTED"),
            ("BRAVO", "DISCONNECTED", "DISCONNECTED"),
        ]


async def test_candles_come_as_a_snapshot_then_forming_and_closed(live: Live) -> None:
    alpha, bravo = live.symbols["ALPHA"], live.symbols["BRAVO"]
    await _feed(live.bus)
    minute = utc_now().replace(second=0, microsecond=0)
    forming = _candle(alpha, "ALPHA", minute, "100", closed=False)
    key = Keys.partial_candle(Provider.SIMULATOR, alpha, CandleInterval.M1)
    await live.bus.set_json(key, forming)

    async with live.connect() as ws:
        await ws.expect("welcome")
        fields = {"instrument_ids": [str(alpha)], "provider": "SIMULATOR", "interval": "1m"}
        ack = await _subscribe(ws, channel="candles", request_id="c", **fields)
        assert (ack["interval"], ack["provider"], ack["instrument_ids"]) == ("1m", "SIMULATOR", [str(alpha)])
        snapshot = await ws.expect("candle.snapshot")
        assert [(c["close_price"], c["is_closed"]) for c in snapshot["items"]] == [("100", False)]
        assert (snapshot["interval"], snapshot["request_id"]) == ("1m", "c")

        later = {"close_price": Decimal(101), "high_price": Decimal(101), "event_count": 2, "revision": 1}
        await live.bus.set_json(key, forming.model_copy(update=later))
        update = await ws.expect("candle.update")
        assert [c["close_price"] for c in update["items"]] == ["101"]

        await live.bus.publish(Streams.CANDLES, _candle(bravo, "BRAVO", minute, "50", closed=True))
        await live.bus.publish(Streams.CANDLES, _candle(alpha, "ALPHA", minute, "102", closed=True))
        closed = (await ws.expect("candle.closed"))["candle"]
        assert (closed["symbol"], closed["close_price"], closed["is_closed"]) == ("ALPHA", "102", True)


async def test_signal_updates_are_sent_for_the_subscribed_workspace(live: Live) -> None:
    alpha = live.symbols["ALPHA"]
    async with live.connect(SIGNALS) as ws:
        assert (await ws.expect("welcome"))["channels"] == ["signals"]
        assert await _error(ws, {"action": "subscribe", "channel": "feed"}) == ("channel_not_available", None)
        ack = await _subscribe(ws, channel="signals", workspace_id=LAB)
        assert ack["workspace"]["slug"] == LAB

        mine = _signal(UUID(ack["workspace"]["id"]), alpha)
        await live.bus.publish(Streams.SIGNALS, _signal(uuid4(), alpha))
        await live.bus.publish(Streams.SIGNALS, mine)
        update = await ws.expect("signal.update")
        assert (update["event_type"], update["signal"]["id"]) == ("ACTIVATED", str(mine.signal.id))


async def test_feed_and_system_status_come_on_subscribing_and_as_they_change(live: Live) -> None:
    stream_id = await _feed(live.bus)
    async with live.connect() as ws:
        await ws.expect("welcome")
        await _subscribe(ws, channel="feed", provider="SIMULATOR")
        status = await ws.expect("feed.status")
        assert [s["stream_id"] for s in status["streams"]] == [stream_id]
        assert status["providers"] == {"SIMULATOR": "LIVE"}
        for provider in (Provider.ZERODHA, Provider.SIMULATOR):
            await live.bus.publish(Streams.FEED, _state_change(provider))
        change = await ws.expect("feed.state_change")
        assert (change["provider"], change["state"]) == ("SIMULATOR", "RECONNECTING")

    async with live.connect(SYSTEM) as ws:
        await ws.expect("welcome")
        await _subscribe(ws, channel="system")
        health = (await ws.expect("system.status"))["health"]
        assert {"status", "components", "feeds", "kill_switch"} <= health.keys()
