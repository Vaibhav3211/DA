"""The market-data worker end to end on PostgreSQL and Redis: a simulator account streams workspace
instruments into Redis (events, quotes, candles, feed state, heartbeat) and PostgreSQL (candles),
follows a worker command and stores its forming candles when it is stopped."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any
from uuid import UUID

import pytest
from sqlalchemy import select

from app.container import Container
from app.core.config import Settings
from app.domain.enums import CandleFlag, CandleInterval, Provider, SubscriptionMode
from app.domain.events import CommandType, WorkerCommand
from app.market_data.calendars.loader import load_market_calendar
from app.observability.heartbeat import MARKET_DATA_WORKER
from app.persistence.database import Database
from app.persistence.models import CandleRow
from app.services.provider_accounts import ProviderAccountService, publish_command
from app.streaming.redis_bus import Keys, RedisBus, Streams
from app.workers.market_data_worker import serve
from tests.integration.provider_support import ACTOR, LAB, add_rows, enabled_account, provider_settings

pytestmark = pytest.mark.integration

SIMULATOR, QUOTE = Provider.SIMULATOR, SubscriptionMode.QUOTE
S1, D1 = CandleInterval.S1, CandleInterval.D1
_TIMEOUT_SECONDS = 20.0


def worker_settings(settings: Settings) -> Settings:
    """Fast ticks and one-second candles, so that a few seconds show the whole flow; daily candles are
    still forming when the worker stops. Reconciling only every 30 s, the worker can only react
    sooner to a command."""
    return provider_settings(
        settings,
        simulator_enabled=True,
        simulator_seed=7,
        simulator_tick_interval_seconds=0.05,
        candle_intervals=[S1, D1],
        candle_lateness_seconds=0.1,
        candle_partial_publish_interval_seconds=0.1,
        candle_flush_interval_seconds=0.1,
        feed_status_publish_interval_seconds=0.1,
        subscription_reconcile_interval_seconds=30.0,
        market_data_worker_metrics_port=0,
    )


async def eventually[T](worker: asyncio.Task[None], probe: Callable[[], Awaitable[T]]) -> T:
    """Poll ``probe`` until it returns a truthy value; fail at once if the worker ends."""
    async with asyncio.timeout(_TIMEOUT_SECONDS):
        while True:
            if worker.done():
                worker.result()  # raises the worker's error
                pytest.fail("the worker stopped")
            if value := await probe():
                return value
            await asyncio.sleep(0.05)


async def value(bus: RedisBus, key: str) -> Any:
    found = await bus.get_json(key)
    assert found is not None, key
    return found


async def payloads(bus: RedisBus, stream: str) -> list[Any]:
    return [message.payload for message in await bus.read({stream: "0-0"}, count=10_000, block_ms=None)]


async def candles(db: Database, interval: CandleInterval) -> list[CandleRow]:
    async with db.session() as session:
        rows = await session.scalars(
            select(CandleRow)
            .where(CandleRow.interval == interval)
            .order_by(CandleRow.instrument_id, CandleRow.bucket_start)
        )
        return list(rows)


async def complete_seconds(db: Database) -> list[CandleRow]:
    return [row for row in await candles(db, S1) if row.is_complete]


async def test_the_worker_streams_follows_commands_and_stores_forming_candles_on_stop(
    accounts: ProviderAccountService, container: Container, symbols: dict[str, UUID]
) -> None:
    bus, alpha, bravo = container.bus, symbols["ALPHA"], symbols["BRAVO"]
    lab = await enabled_account(accounts, SIMULATOR)
    await add_rows(container, symbols, [(LAB, "ALPHA", SIMULATOR, QUOTE, None)])
    worker = asyncio.create_task(serve(worker_settings(container.settings)))
    try:
        # The start-up reconciliation streams ALPHA: one-second candles close and are stored.
        stored = await eventually(worker, lambda: complete_seconds(container.db))
        assert {(row.instrument_id, row.account_id) for row in stored} == {(alpha, lab)}
        events = await payloads(bus, Streams.market_events(SIMULATOR))
        assert {(e["instrument_id"], e["account_id"], e["data_status"]) for e in events} == {
            (str(alpha), str(lab), "SIMULATED")
        }
        quote = await value(bus, Keys.quote(SIMULATOR, alpha))
        assert (quote["instrument_id"], quote["data_status"]) == (str(alpha), "SIMULATED")
        forming = await value(bus, Keys.partial_candle(SIMULATOR, alpha, D1))
        assert (forming["instrument_id"], forming["interval"]) == (str(alpha), D1.value)
        closed = await payloads(bus, Streams.CANDLES)
        assert {(candle["instrument_id"], candle["interval"]) for candle in closed} == {
            (str(alpha), S1.value)
        }
        [state] = (await bus.scan_json(Keys.FEED_STATE_PATTERN)).values()
        assert (state["account_id"], state["state"]) == (str(lab), "CONNECTED")
        assert (await accounts.get(lab)).last_connected_at is not None
        details = (await value(bus, Keys.worker_heartbeat(MARKET_DATA_WORKER)))["details"]
        calendar = await load_market_calendar(container.db)
        assert details["calendar_verified_until"] == {
            exchange.value: day.isoformat() for exchange, day in calendar.coverage().items()
        }
        assert details["queue_capacity"] == container.settings.provider_queue_size

        # A workspace change and its command: BRAVO streams within seconds instead of 30.
        await add_rows(container, symbols, [(LAB, "BRAVO", SIMULATOR, QUOTE, None)])
        await publish_command(bus, WorkerCommand(type=CommandType.REFRESH_SUBSCRIPTIONS, issued_by=ACTOR))
        await eventually(worker, lambda: bus.get_json(Keys.quote(SIMULATOR, bravo)))

        worker.cancel()
        with pytest.raises(asyncio.CancelledError):
            await worker
    finally:
        worker.cancel()
        await asyncio.gather(worker, return_exceptions=True)

    # A clean stop: the forming daily candles are stored, cut short, and the feed state is removed.
    days = {row.instrument_id: row for row in await candles(container.db, D1)}
    assert days.keys() == {alpha, bravo}
    assert all(CandleFlag.DISCONNECTED_DURING.value in row.flags for row in days.values())
    assert await bus.scan_json(Keys.FEED_STATE_PATTERN) == {}
    assert (await accounts.get(lab)).last_disconnected_at is not None
