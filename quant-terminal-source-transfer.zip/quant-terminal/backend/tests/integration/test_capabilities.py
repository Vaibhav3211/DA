"""Capability overrides: merge order, normalization, validation and fail-closed reads."""

from __future__ import annotations

from datetime import date
from typing import Any
from uuid import UUID, uuid4

import pytest

from app.core.errors import NotFoundError, ValidationFailedError
from app.domain.enums import Exchange, Provider
from app.persistence.models import ProviderCapabilityRow
from app.providers.capabilities import default_capabilities
from app.services.capabilities import INVALID, CapabilityOverride, CapabilityService
from app.services.provider_accounts import ProviderAccountService
from tests.integration.provider_support import ACTOR, NOW, FakeClock, audit_entries, failure

pytestmark = pytest.mark.integration

ZERODHA = Provider.ZERODHA
DEFAULTS = default_capabilities(ZERODHA)
VERIFIED = date(2026, 11, 2)
SOURCE = "Kite Connect forum answer"


@pytest.fixture
def capabilities(accounts: ProviderAccountService, clock: FakeClock) -> CapabilityService:
    # The ``accounts`` fixture wipes provider accounts and overrides before and after each test.
    return CapabilityService(accounts.db, clock=clock)


async def override(
    capabilities: CapabilityService,
    values: dict[str, Any],
    *,
    account_id: UUID | None = None,
    source: str = SOURCE,
    verified_on: date | None = VERIFIED,
) -> CapabilityOverride:
    return await capabilities.set_override(
        ZERODHA,
        values,
        verification_source=source,
        verified_on=verified_on,
        account_id=account_id,
        actor=ACTOR,
    )


async def store_raw(capabilities: CapabilityService, values: dict[str, Any]) -> None:
    """An override row written behind the service's back (a hand edit or an older release)."""
    async with capabilities.db.transaction() as session:
        session.add(
            ProviderCapabilityRow(
                provider=ZERODHA, capabilities=values, verified_on=VERIFIED, verification_source="Hand edit"
            )
        )


async def test_without_overrides_the_documented_defaults_apply(
    capabilities: CapabilityService, accounts: ProviderAccountService
) -> None:
    account = await accounts.create(ZERODHA, "Main", actor=ACTOR)

    assert await capabilities.effective(ZERODHA) == DEFAULTS
    assert await capabilities.effective(ZERODHA, account.id) == DEFAULTS
    assert await capabilities.list_overrides() == []


async def test_account_overrides_win_over_provider_overrides_which_win_over_defaults(
    capabilities: CapabilityService, accounts: ProviderAccountService
) -> None:
    main = await accounts.create(ZERODHA, "Main", actor=ACTOR)
    spare = await accounts.create(ZERODHA, "Spare", actor=ACTOR)
    await override(capabilities, {"max_instruments_per_connection": 2000, "depth_levels": 20})
    await override(
        capabilities,
        {"max_instruments_per_connection": "4000"},
        account_id=main.id,
        source="Plan email",
        verified_on=None,
    )

    provider_wide = await capabilities.effective(ZERODHA)
    assert (provider_wide.max_instruments_per_connection, provider_wide.depth_levels) == (2000, 20)
    assert (provider_wide.verified_on, provider_wide.verification_source) == (VERIFIED, SOURCE)
    changed = {"max_instruments_per_connection", "depth_levels", "verified_on", "verification_source"}
    assert provider_wide.model_dump(exclude=changed) == DEFAULTS.model_dump(exclude=changed)
    for_main = await capabilities.effective(ZERODHA, main.id)
    assert (for_main.max_instruments_per_connection, for_main.depth_levels) == (4000, 20)
    assert (for_main.verified_on, for_main.verification_source) == (None, "Plan email")
    assert await capabilities.effective(ZERODHA, spare.id) == provider_wide
    assert await capabilities.effective(Provider.GROWW) == default_capabilities(Provider.GROWW)

    listed = await capabilities.list_overrides()
    assert [(item.account_id, item.account_label, item.values) for item in listed] == [
        (None, None, {"max_instruments_per_connection": 2000, "depth_levels": 20}),
        (main.id, "Main", {"max_instruments_per_connection": 4000}),  # stored as the field's type
    ]
    assert {item.updated_at for item in listed} == {NOW}
    assert await capabilities.list_overrides(Provider.GROWW) == []


async def test_changes_merge_into_the_existing_override_with_fresh_provenance(
    capabilities: CapabilityService,
) -> None:
    first = await override(capabilities, {"depth_levels": 20, "exchanges": ["NSE"]})
    second = await override(
        capabilities,
        {"rest_rate_limits": {"quote": "2 requests/second"}, "depth_levels": None},
        source="  Support   ticket 42 ",
        verified_on=date(2026, 11, 9),
    )

    assert second.id == first.id
    assert second.values == {
        "depth_levels": None,
        "exchanges": ["NSE"],
        "rest_rate_limits": {"quote": "2 requests/second"},
    }
    effective = await capabilities.effective(ZERODHA)
    assert (effective.exchanges, effective.depth_levels) == ((Exchange.NSE,), None)
    assert effective.rest_rate_limits == {"quote": "2 requests/second"}  # a mapping is replaced whole
    assert (effective.verified_on, effective.verification_source) == (date(2026, 11, 9), "Support ticket 42")
    audits = await audit_entries(capabilities.db, first.id)
    assert [(entry.action, entry.details["values"]) for entry in audits] == [
        ("provider_capability.set", {"depth_levels": 20, "exchanges": ["NSE"]}),
        (
            "provider_capability.set",
            {"depth_levels": None, "rest_rate_limits": {"quote": "2 requests/second"}},
        ),
    ]


@pytest.mark.parametrize(
    ("values", "source"),
    [
        ({}, SOURCE),
        ({"provider": "groww"}, SOURCE),
        ({"verified_on": "2026-01-01"}, SOURCE),
        ({"retired_field": 1}, SOURCE),
        ({"depth_levels": "deep"}, SOURCE),
        ({"exchanges": ["NYSE"]}, SOURCE),
        ({"streaming": False}, " \t "),
        ({"streaming": False}, "x" * 201),
    ],
    ids=["empty", "provider", "provenance", "unknown", "type", "enum", "no-source", "long-source"],
)
async def test_rejected_changes_leave_the_existing_override_alone(
    capabilities: CapabilityService, values: dict[str, Any], source: str
) -> None:
    await override(capabilities, {"depth_levels": 20})

    await failure(override(capabilities, values, source=source), ValidationFailedError, INVALID)

    [stored] = await capabilities.list_overrides()
    assert (stored.values, stored.verification_source) == ({"depth_levels": 20}, SOURCE)


async def test_account_overrides_need_an_existing_account_of_that_provider(
    capabilities: CapabilityService, accounts: ProviderAccountService
) -> None:
    groww = await accounts.create(Provider.GROWW, "Family", actor=ACTOR)

    missing = override(capabilities, {"depth_levels": 20}, account_id=uuid4())
    await failure(missing, NotFoundError, "provider_account_not_found")
    await failure(
        override(capabilities, {"depth_levels": 20}, account_id=groww.id),
        ValidationFailedError,
        "wrong_provider",
    )
    assert await capabilities.list_overrides() == []


async def test_clearing_fields_keeps_the_rest_and_clearing_everything_removes_the_override(
    capabilities: CapabilityService,
) -> None:
    created = await override(capabilities, {"depth_levels": 20, "rest_quotes": False})

    remaining = await capabilities.clear_override(ZERODHA, fields=["depth_levels", "streaming"], actor=ACTOR)
    assert remaining is not None
    assert remaining.values == {"rest_quotes": False}
    assert (await capabilities.effective(ZERODHA)).depth_levels == DEFAULTS.depth_levels
    assert await capabilities.clear_override(ZERODHA, fields=["streaming"], actor=ACTOR) == remaining
    await failure(
        capabilities.clear_override(ZERODHA, fields=["provider"], actor=ACTOR), ValidationFailedError, INVALID
    )
    assert await capabilities.clear_override(ZERODHA, actor=ACTOR) is None
    assert await capabilities.clear_override(ZERODHA, actor=ACTOR) is None  # nothing left to clear

    assert await capabilities.effective(ZERODHA) == DEFAULTS
    assert await capabilities.list_overrides() == []
    audits = await audit_entries(capabilities.db, created.id)
    assert [(entry.action, entry.details.get("fields")) for entry in audits] == [
        ("provider_capability.set", None),
        ("provider_capability.clear", ["depth_levels"]),
        ("provider_capability.clear", ["rest_quotes"]),
    ]


async def test_stored_overrides_that_no_longer_validate_fail_closed(capabilities: CapabilityService) -> None:
    await store_raw(capabilities, {"depth_levels": "deep"})

    error = await failure(capabilities.effective(ZERODHA), ValidationFailedError, INVALID)
    assert "depth_levels" in error.message


async def test_stored_keys_that_are_not_overridable_are_ignored(capabilities: CapabilityService) -> None:
    await store_raw(
        capabilities,
        {"provider": "groww", "verification_source": "x", "retired_field": 1, "depth_levels": 7},
    )

    effective = await capabilities.effective(ZERODHA)
    assert (effective.provider, effective.depth_levels) == (ZERODHA, 7)
    assert (effective.verified_on, effective.verification_source) == (VERIFIED, "Hand edit")
