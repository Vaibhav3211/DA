"""Backtests on PostgreSQL: datasets from recorded candles and from Zerodha's history API (a fake on a
``.test`` host), their coverage and gaps, the trade rules a backtest needs, instrument scope, results
that go out of date and stay for comparison, zero trades, and jobs a stopped worker left behind.

The instruments, the recorded session and the fixture strategies are described in ``history_support``.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from uuid import UUID, uuid4

import pytest

from app.container import Container
from app.core.errors import ConflictError, NotFoundError, ValidationFailedError
from app.domain.enums import (
    BacktestState,
    BacktestStatus,
    CandleInterval,
    CredentialKind,
    DatasetSource,
    DatasetStatus,
    ExitReason,
    PositionSide,
    Provider,
    TradeOutcome,
    TradeRulesSource,
)
from app.domain.models import Candle
from app.domain.models.backtest import BacktestSummary, GapRange, Measure
from app.observability.heartbeat import BACKTEST_WORKER, HeartbeatPublisher
from app.providers.errors import ProviderAuthRequiredError
from app.services.backtests import BacktestRunView, BacktestService
from app.services.datasets import DatasetRequestResult, DatasetService, DatasetView
from app.services.markets import MarketCalendarCache
from app.services.provider_accounts import ProviderAccountService
from app.services.risk import RiskRuleService
from app.services.strategies import DeploymentView, Scope, StrategyService
from app.strategies.registry import RegisteredStrategy
from app.workers.backtest_worker import BacktestWorker
from tests.backtest_support import IST, trade_rules
from tests.candle_support import T0
from tests.integration.history_support import (
    DAY,
    INDIA,
    NO_RULES,
    NO_WORKER,
    ONE,
    ONE_TOKEN,
    SILENT,
    TARGET_ONLY,
    THREE,
    TRADER,
    TWO,
    add_instruments,
    fixture_registry,
    minute,
    record_session,
    session_candles,
    wipe_lab,
)
from tests.integration.provider_support import (
    ACTOR,
    FakeClock,
    FakeProvider,
    audit_entries,
    failure,
    kite_ok,
    provider_settings,
    store_token,
)

pytestmark = pytest.mark.integration

WORKER = "test-worker"
KITE_KEY, KITE_SECRET, KITE_TOKEN = "kite-api-key", "kite-api-secret", "kite-token"
HISTORY_PATH = f"/instruments/historical/{ONE_TOKEN}/minute"


def kite_candles(candles: Sequence[Candle]) -> list[list[object]]:
    """The candles as Kite's historical API returns them: IST timestamps and float prices."""
    return [
        [
            candle.bucket_start.astimezone(IST).strftime("%Y-%m-%dT%H:%M:%S%z"),
            float(candle.open_price),
            float(candle.high_price),
            float(candle.low_price),
            float(candle.close_price),
            candle.volume,
        ]
        for candle in candles
    ]


def summary_of(run: BacktestRunView | None) -> BacktestSummary:
    assert run is not None
    assert run.summary is not None, run.error
    return run.summary


@dataclass
class Lab:
    container: Container
    clock: FakeClock
    accounts: ProviderAccountService
    ids: dict[str, UUID]  # by canonical key
    strategies: StrategyService
    datasets: DatasetService
    backtests: BacktestService
    worker: BacktestWorker
    kite: FakeProvider

    async def record(self, key: str) -> None:
        """Store the session's candles of ``key`` as recorded from Zerodha's feed."""
        await record_session(self.container.db, self.ids[key], key)

    async def request(
        self,
        key: str,
        *,
        source: DatasetSource = DatasetSource.RECORDED,
        date_from: date = DAY,
        date_to: date = DAY,
    ) -> DatasetRequestResult:
        return await self.datasets.request(
            key,
            provider=Provider.ZERODHA,
            source=source,
            interval=CandleInterval.M1,
            date_from=date_from,
            date_to=date_to,
            actor=ACTOR,
        )

    async def drain(self) -> None:
        """Let the worker take every waiting job."""
        for _ in range(20):
            if not await self.worker.run_once():
                return
        raise AssertionError("the backtest worker kept finding jobs")

    async def recorded(self, key: str) -> DatasetView:
        """A READY dataset of the session's candles of ``key``, recorded from Zerodha."""
        await self.record(key)
        requested = await self.request(key)
        await self.drain()
        dataset = await self.datasets.get(requested.dataset.id)
        assert dataset.status is DatasetStatus.READY, dataset.error
        return dataset

    async def configuration(self, entry: RegisteredStrategy, scope: Scope, label: str) -> DeploymentView:
        return await self.strategies.create_configuration(
            INDIA, entry.strategy_id, scope=scope, label=label, actor=ACTOR
        )

    async def trader(self) -> DeploymentView:
        """TRADER saved for BTONE alone, with the default trade rules."""
        view = await self.configuration(TRADER, Scope.instruments([self.ids[ONE]]), "Trader")
        await self.backtests.set_rules(view.id, trade_rules(), actor=ACTOR)
        return view

    async def backtest(
        self, configuration: DeploymentView, key: str, dataset: DatasetView
    ) -> BacktestRunView:
        """Queue a new backtest and let the worker run it."""
        queued = await self.backtests.queue(configuration.id, key, dataset.id, actor=ACTOR)
        assert queued.created
        await self.drain()
        return (await self.backtests.get(queued.run.id)).run

    async def zerodha(self) -> UUID:
        """An enabled Zerodha account with an API key, not logged in."""
        view = await self.accounts.create(Provider.ZERODHA, "Main", actor=ACTOR)
        credentials = {CredentialKind.API_KEY: KITE_KEY, CredentialKind.API_SECRET: KITE_SECRET}
        await self.accounts.set_credentials(view.id, credentials, actor=ACTOR)
        await self.accounts.set_enabled(view.id, True, actor=ACTOR)
        return view.id

    async def log_in(self, account_id: UUID) -> None:
        await store_token(
            self.accounts, account_id, KITE_TOKEN, expires_at=self.clock.now + timedelta(hours=2)
        )


@pytest.fixture
async def lab(container: Container, accounts: ProviderAccountService, clock: FakeClock) -> AsyncIterator[Lab]:
    db = container.db
    await wipe_lab(db)
    try:
        ids = await add_instruments(container)
        settings = provider_settings(container.settings)
        calendars = MarketCalendarCache(db, settings)
        registry = fixture_registry()
        kite = FakeProvider()
        datasets = DatasetService(
            db, container.bus, settings, accounts, calendars, transport=kite.transport, clock=clock
        )
        backtests = BacktestService(db, container.bus, settings, registry=registry, clock=clock)
        yield Lab(
            container=container,
            clock=clock,
            accounts=accounts,
            ids=ids,
            strategies=StrategyService(db, container.bus, registry=registry, clock=clock),
            datasets=datasets,
            backtests=backtests,
            worker=BacktestWorker(
                datasets, backtests, calendars, worker_id=WORKER, poll_seconds=0, clock=clock
            ),
            kite=kite,
        )
    finally:
        await wipe_lab(db)


# ---- the journey -------------------------------------------------------------------------------------


async def test_a_recorded_session_is_backtested_once_trade_rules_are_set(lab: Lab) -> None:
    await lab.record(ONE)
    first = await lab.request(ONE)
    again = await lab.request(ONE)
    assert (first.created, again.created, again.dataset.id) == (True, False, first.dataset.id)
    assert (first.dataset.status, first.dataset.source, first.dataset.simulated) == (
        DatasetStatus.PENDING,
        DatasetSource.RECORDED,
        False,
    )

    await lab.drain()
    dataset = await lab.datasets.get(first.dataset.id)
    assert (dataset.status, dataset.worker_id, dataset.error, dataset.candle_count) == (
        DatasetStatus.READY,
        WORKER,
        None,
        13,
    )
    assert (dataset.first_candle_at, dataset.last_candle_at) == (T0, minute(15))
    assert dataset.content_sha
    # The calendar expects 15 candles up to the clock; the two missing ones are one visible gap.
    coverage = dataset.coverage
    assert coverage is not None
    assert (coverage.session_days, coverage.expected, coverage.present, coverage.missing) == (1, 15, 13, 2)
    assert (coverage.coverage_pct, coverage.gap_total) == (Decimal("86.66"), 1)
    assert coverage.gaps == (GapRange(start=minute(7), end=minute(9), candles=2),)
    assert (coverage.left_out, coverage.requests, coverage.assumed_days, coverage.notes) == (0, 0, (), ())
    assert [row.action for row in await audit_entries(lab.container.db, dataset.id)] == [
        "backtest_dataset.request"
    ]

    # A configuration has no trade rules until they are set: nothing to calculate performance from.
    trader = await lab.configuration(TRADER, Scope.instruments([lab.ids[ONE]]), "Trader")
    latest = await lab.backtests.latest(trader.id, ONE)
    assert (latest.state, latest.problem, latest.interval, latest.settings_hash) == (
        BacktestState.NOT_BACKTESTED,
        NO_RULES,
        CandleInterval.M1,
        None,
    )
    assert (latest.current, latest.outdated, latest.in_progress, latest.last_failed) == (
        None,
        None,
        None,
        None,
    )
    error = await failure(
        lab.backtests.queue(trader.id, ONE, dataset.id, actor=ACTOR), ConflictError, "backtest_rules_missing"
    )
    assert error.message == f"Cannot backtest 'Trader' on {ONE}: {NO_RULES}"

    rules = await lab.backtests.set_rules(trader.id, trade_rules(), actor=ACTOR)
    assert (rules.effective, rules.source, rules.problem) == (
        trade_rules(),
        TradeRulesSource.CONFIGURATION,
        None,
    )

    queued = await lab.backtests.queue(trader.id, ONE, dataset.id, actor=ACTOR)
    repeated = await lab.backtests.queue(trader.id, ONE, dataset.id, actor=ACTOR)
    assert (queued.created, queued.run.status, queued.worker_problem) == (
        True,
        BacktestStatus.QUEUED,
        NO_WORKER,
    )
    assert (repeated.created, repeated.run.id) == (False, queued.run.id)
    waiting = await lab.backtests.latest(trader.id, ONE)
    assert (waiting.state, waiting.problem, waiting.worker_problem) == (
        BacktestState.NOT_BACKTESTED,
        None,
        NO_WORKER,
    )
    assert waiting.in_progress is not None
    assert waiting.in_progress.id == queued.run.id

    await lab.drain()
    latest = await lab.backtests.latest(trader.id, ONE)
    assert (latest.state, latest.problem, latest.changed, latest.outdated_runs) == (
        BacktestState.CURRENT,
        None,
        (),
        0,
    )
    assert (latest.in_progress, latest.last_failed, latest.outdated) == (None, None, None)
    run = latest.current
    assert run is not None
    assert (run.id, run.status, run.worker_id, run.error, run.trade_count, run.outdated) == (
        queued.run.id,
        BacktestStatus.SUCCEEDED,
        WORKER,
        None,
        1,
        False,
    )
    assert (run.provider, run.source, run.simulated, run.date_from, run.date_to) == (
        Provider.ZERODHA,
        DatasetSource.RECORDED,
        False,
        DAY,
        DAY,
    )
    assert (run.dataset_id, run.dataset_sha, run.requested_by) == (dataset.id, dataset.content_sha, ACTOR)
    assert (run.strategy_id, run.strategy_version, run.interval) == (
        "test.backtest",
        "1.0.0",
        CandleInterval.M1,
    )
    assert run.settings["strategy"] == {
        "id": "test.backtest",
        "version": "1.0.0",
        "fingerprint": run.code_fingerprint,
    }
    assert run.settings["trade_rules"]["quantity"] == 10
    assert run.settings_hash == latest.settings_hash

    summary = summary_of(run)
    period = summary.period
    assert (period.dataset_from, period.dataset_to, period.warmup_candles) == (T0, minute(15), 3)
    assert (period.evaluated_from, period.evaluated_to, period.evaluated_candles) == (
        minute(3),
        minute(15),
        10,
    )
    metrics = summary.metrics
    assert (metrics.closed_trades, metrics.wins, metrics.losses, metrics.breakevens) == (1, 1, 0, 0)
    assert metrics.win_rate_pct == Measure(value=Decimal(100))
    assert (metrics.gross_pnl, metrics.net_pnl, metrics.net_return_pct, metrics.final_equity) == (
        Decimal("37.00"),
        Decimal("37.00"),
        Decimal("0.04"),
        Decimal("100037.00"),
    )
    assert (metrics.profit_factor, metrics.average_loss) == (
        Measure(reason=TARGET_ONLY),
        Measure(reason="No losing trades"),
    )
    assert (summary.signals.proposed, summary.signals.allowed, summary.open_position) == (1, 1, None)
    assert (summary.equity_points, summary.notes) == (11, ())

    detail = await lab.backtests.get(run.id)
    assert (detail.dataset.id, detail.changed, detail.current_problem, detail.curve_problem) == (
        dataset.id,
        (),
        None,
        None,
    )
    assert [point.equity for point in detail.equity_curve] == [
        Decimal(100_000),
        Decimal(100_000),
        Decimal(100_003),
        *[Decimal(100_037)] * 8,
    ]

    page = await lab.backtests.trades(run.id, limit=10)
    assert (page.total, page.offset, page.limit) == (1, 0, 10)
    [trade] = page.trades
    assert (trade.number, trade.side, trade.quantity, trade.entry_at, trade.entry_price) == (
        1,
        PositionSide.LONG,
        10,
        minute(4),
        Decimal("100.50"),
    )
    assert (trade.exit_reason, trade.exit_at, trade.exit_price, trade.both_touched) == (
        ExitReason.TARGET,
        minute(5),
        Decimal("104.20"),
        False,
    )
    assert (trade.candles_held, trade.net_pnl, trade.return_pct, trade.outcome) == (
        2,
        Decimal("37.00"),
        Decimal("3.6816"),
        TradeOutcome.WIN,
    )
    assert trade.entry_signal.decided_at == minute(4)
    assert (await lab.backtests.trades(run.id, limit=1000)).limit == 500

    assert [view.id for view in await lab.backtests.list_runs(deployment_id=trader.id)] == [run.id]
    assert [row.action for row in await audit_entries(lab.container.db, run.id)] == ["backtest.queue"]
    assert "backtest_rules.set" in [row.action for row in await audit_entries(lab.container.db, trader.id)]
    await failure(lab.backtests.get(uuid4()), NotFoundError, "backtest_not_found")
    await failure(lab.backtests.trades(uuid4()), NotFoundError, "backtest_not_found")

    await HeartbeatPublisher(lab.container.bus, BACKTEST_WORKER, "test").publish_once()
    assert (await lab.backtests.latest(trader.id, ONE)).worker_problem is None


async def test_changed_settings_outdate_a_result_that_stays_for_comparison(lab: Lab) -> None:
    dataset = await lab.recorded(ONE)
    trader = await lab.trader()
    first = await lab.backtest(trader, ONE, dataset)

    await lab.backtests.set_rules(trader.id, trade_rules(quantity=20), actor=ACTOR)
    latest = await lab.backtests.latest(trader.id, ONE)
    assert (latest.state, latest.current, latest.changed, latest.outdated_runs) == (
        BacktestState.OUTDATED,
        None,
        ("trade_rules.quantity",),
        1,
    )
    assert latest.outdated is not None
    assert (latest.outdated.id, latest.outdated.outdated) == (first.id, True)
    assert (await lab.backtests.get(first.id)).changed == ("trade_rules.quantity",)

    lab.clock.advance(timedelta(minutes=1))
    second = await lab.backtest(trader, ONE, dataset)
    latest = await lab.backtests.latest(trader.id, ONE)
    assert (latest.state, latest.changed, latest.outdated_runs) == (BacktestState.CURRENT, (), 1)
    assert latest.current is not None
    assert latest.current.id == second.id
    assert summary_of(latest.current).metrics.net_pnl == Decimal("74.00")
    runs = await lab.backtests.list_runs(deployment_id=trader.id)
    assert [(view.id, view.outdated) for view in runs] == [(second.id, False), (first.id, True)]

    # A risk rule that applies to history is part of the settings too.
    risk = RiskRuleService(lab.container.db, clock=lab.clock)
    await risk.set_rule("price_sanity", params={"max_entry_deviation_pct": "5"}, actor=ACTOR)
    latest = await lab.backtests.latest(trader.id, ONE)
    assert (latest.state, latest.changed, latest.outdated_runs) == (
        BacktestState.OUTDATED,
        ("risk.price_sanity.params.max_entry_deviation_pct",),
        2,
    )
    assert latest.outdated is not None
    assert latest.outdated.id == second.id


async def test_a_backtest_stays_inside_the_configuration_scope_and_the_dataset_instrument(lab: Lab) -> None:
    one = await lab.recorded(ONE)
    two = await lab.recorded(TWO)
    trader = await lab.trader()

    outside_scope = f"{TWO} is not in its instrument scope; choose one of its instruments or change its scope"
    assert (await lab.backtests.latest(trader.id, TWO)).problem == outside_scope
    error = await failure(
        lab.backtests.queue(trader.id, TWO, two.id, actor=ACTOR),
        ValidationFailedError,
        "backtest_scope_rejected",
    )
    assert error.message == f"Cannot backtest 'Trader' on {TWO}: {outside_scope}"
    error = await failure(
        lab.backtests.queue(trader.id, ONE, two.id, actor=ACTOR),
        ValidationFailedError,
        "backtest_dataset_mismatch",
    )
    assert error.message == f"Dataset {two.id} holds another instrument's candles, not {ONE}'s"
    await failure(
        lab.backtests.queue(trader.id, ONE, uuid4(), actor=ACTOR), NotFoundError, "dataset_not_found"
    )

    # The whole workspace is an explicit choice, and still ends at the workspace's instruments.
    everything = await lab.configuration(TRADER, Scope.workspace(), "Whole workspace")
    await lab.backtests.set_rules(everything.id, trade_rules(), actor=ACTOR)
    assert (await lab.backtests.latest(everything.id, TWO)).problem is None
    outside_workspace = await lab.backtests.latest(everything.id, THREE)
    assert (
        outside_workspace.problem
        == f"its scope is the whole workspace, and {THREE} is not in workspace {INDIA}"
    )
    run = await lab.backtest(everything, TWO, two)
    assert (run.status, run.instrument_key, run.label, run.trade_count) == (
        BacktestStatus.SUCCEEDED,
        TWO,
        "Whole workspace",
        1,
    )
    assert await lab.backtests.list_runs(deployment_id=trader.id) == []
    assert (await lab.backtests.latest(trader.id, ONE)).state is BacktestState.NOT_BACKTESTED
    assert one.status is DatasetStatus.READY


async def test_missing_history_and_unusable_datasets_are_refused_with_the_reason(lab: Lab) -> None:
    error = await failure(lab.request(ONE), ValidationFailedError, "dataset_no_candles")
    assert error.message == (
        f"No closed 1m candles of {ONE} were recorded from ZERODHA between 2026-01-05 and 2026-01-05 "
        "(recorded: none)"
    )
    error = await failure(
        lab.request(ONE, source=DatasetSource.SIMULATED), ValidationFailedError, "dataset_source_invalid"
    )
    assert error.message == "Cannot build this dataset: simulated datasets come from the SIMULATOR"
    error = await failure(
        lab.request(ONE, date_from=DAY + timedelta(days=1)), ValidationFailedError, "dataset_dates_invalid"
    )
    assert error.message == "The first date (2026-01-06) is after the last date (2026-01-05)"
    error = await failure(
        lab.request(ONE, date_to=DAY + timedelta(days=1)), ValidationFailedError, "dataset_dates_invalid"
    )
    assert error.message == "The last date (2026-01-06) is after today on NSE (2026-01-05)"

    history = DatasetSource.PROVIDER_HISTORY
    error = await failure(
        lab.request(TWO, source=history), ValidationFailedError, "dataset_source_unavailable"
    )
    assert error.message == (
        f"Cannot download {TWO}: {TWO} has no active ZERODHA mapping; refresh the ZERODHA instrument master"
    )
    error = await failure(lab.request(ONE, source=history), ValidationFailedError, "dataset_account_missing")
    assert error.message == (
        "Downloading ZERODHA history needs an enabled ZERODHA account with a current access token; add one "
        "and log in"
    )
    account = await lab.zerodha()
    await failure(lab.request(ONE, source=history), ProviderAuthRequiredError, "provider_auth_required")

    # A dataset is usable only once READY; a source without candles fails it with the reason.
    trader = await lab.trader()
    await lab.record(ONE)
    pending = (await lab.request(ONE)).dataset
    conflict = await failure(
        lab.backtests.queue(trader.id, ONE, pending.id, actor=ACTOR), ConflictError, "dataset_not_ready"
    )
    assert (
        conflict.message == f"Dataset {pending.id} cannot be used yet: it is PENDING; wait until it is READY"
    )

    await lab.log_in(account)
    lab.kite.routes[("GET", HISTORY_PATH)] = kite_ok({"candles": []})
    empty = (await lab.request(ONE, source=history)).dataset
    await lab.drain()
    failed = await lab.datasets.get(empty.id)
    assert (failed.status, failed.error, failed.candle_count, failed.coverage) == (
        DatasetStatus.FAILED,
        "the source has no BTONE 1m candles from 2026-01-05 to 2026-01-05",
        0,
        None,
    )
    conflict = await failure(
        lab.backtests.queue(trader.id, ONE, empty.id, actor=ACTOR), ConflictError, "dataset_not_ready"
    )
    assert (
        conflict.message
        == f"Dataset {empty.id} cannot be used yet: it failed: {failed.error}; request it again"
    )
    assert (await lab.datasets.get(pending.id)).status is DatasetStatus.READY


async def test_a_strategy_without_trades_reports_undefined_metrics_instead_of_numbers(lab: Lab) -> None:
    dataset = await lab.recorded(ONE)
    silent = await lab.configuration(SILENT, Scope.instruments([lab.ids[ONE]]), "Silent")
    await lab.backtests.set_rules(silent.id, trade_rules(), actor=ACTOR)
    run = await lab.backtest(silent, ONE, dataset)

    summary = summary_of(run)
    metrics = summary.metrics
    assert (run.status, run.trade_count, metrics.closed_trades, metrics.wins, metrics.losses) == (
        BacktestStatus.SUCCEEDED,
        0,
        0,
        0,
        0,
    )
    assert (metrics.win_rate_pct, metrics.profit_factor) == (
        Measure(reason="No closed trades"),
        Measure(reason="No closed trades"),
    )
    assert (metrics.average_win, metrics.average_loss) == (
        Measure(reason="No winning trades"),
        Measure(reason="No losing trades"),
    )
    assert (metrics.net_pnl, metrics.final_equity) == (Decimal("0.00"), Decimal("100000.00"))
    assert (summary.signals.proposed, summary.open_position) == (0, None)
    assert summary.notes == ("No trade closed in the evaluated period. The strategy proposed no signals.",)
    page = await lab.backtests.trades(run.id)
    assert (page.total, page.trades) == (0, ())


async def test_jobs_a_stopped_worker_left_fail_and_can_be_queued_again(lab: Lab) -> None:
    dataset = await lab.recorded(ONE)
    await lab.record(TWO)
    stuck = (await lab.request(TWO)).dataset
    assert await lab.datasets.claim_next("gone-worker") == stuck.id
    trader = await lab.trader()
    queued = (await lab.backtests.queue(trader.id, ONE, dataset.id, actor=ACTOR)).run
    assert await lab.backtests.claim_next("gone-worker") == queued.id
    assert not await lab.backtests.keep_alive(queued.id, WORKER)  # another worker's job
    assert await lab.backtests.keep_alive(queued.id, "gone-worker")

    lab.clock.advance(timedelta(minutes=6))
    assert not await lab.worker.run_once()  # fails both, then finds nothing waiting
    abandoned = await lab.datasets.get(stuck.id)
    assert (abandoned.status, abandoned.error) == (
        DatasetStatus.FAILED,
        "The backtest worker stopped while building it; request it again",
    )
    latest = await lab.backtests.latest(trader.id, ONE)
    assert (latest.state, latest.in_progress) == (BacktestState.NOT_BACKTESTED, None)
    assert latest.last_failed is not None
    assert (latest.last_failed.id, latest.last_failed.error) == (
        queued.id,
        "The backtest worker stopped while running it; queue it again",
    )

    lab.clock.advance(timedelta(seconds=1))
    again = await lab.backtests.queue(trader.id, ONE, dataset.id, actor=ACTOR)
    assert again.created
    assert again.run.id != queued.id
    await lab.drain()
    latest = await lab.backtests.latest(trader.id, ONE)
    assert (latest.state, latest.last_failed) == (BacktestState.CURRENT, None)
    assert latest.current is not None
    assert latest.current.id == again.run.id


async def test_zerodha_history_downloads_into_a_dataset_that_backtests_like_recorded_candles(
    lab: Lab,
) -> None:
    account = await lab.zerodha()
    await lab.log_in(account)
    candles = kite_candles(session_candles(lab.ids[ONE], "BTONE"))
    lab.kite.routes[("GET", HISTORY_PATH)] = kite_ok({"candles": candles})

    requested = await lab.request(ONE, source=DatasetSource.PROVIDER_HISTORY)
    assert (requested.created, requested.dataset.account_id) == (True, account)
    await lab.drain()
    dataset = await lab.datasets.get(requested.dataset.id)
    assert (dataset.status, dataset.error, dataset.candle_count, dataset.source) == (
        DatasetStatus.READY,
        None,
        13,
        DatasetSource.PROVIDER_HISTORY,
    )
    coverage = dataset.coverage
    assert coverage is not None
    assert (coverage.expected, coverage.present, coverage.coverage_pct, coverage.requests) == (
        15,
        13,
        Decimal("86.66"),
        1,
    )
    [request] = lab.kite.requests
    assert request.url.path == HISTORY_PATH
    params = request.url.params
    assert (params["from"], params["to"], params["oi"]) == ("2026-01-05 00:00:00", "2026-01-05 23:59:59", "0")
    assert request.headers["authorization"] == f"token {KITE_KEY}:{KITE_TOKEN}"

    run = await lab.backtest(await lab.trader(), ONE, dataset)
    assert (run.status, run.source, run.provider, run.trade_count) == (
        BacktestStatus.SUCCEEDED,
        DatasetSource.PROVIDER_HISTORY,
        Provider.ZERODHA,
        1,
    )
    assert summary_of(run).metrics.net_pnl == Decimal("37.00")
