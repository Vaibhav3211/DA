"""The strategy worker on PostgreSQL and Redis: warm starts, live candles turned into signals, and runs that
follow the deployments."""

from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from functools import partial
from typing import Any
from uuid import UUID

import pytest
import sqlalchemy as sa

from app import __version__
from app.container import Container
from app.domain.enums import (
    CandleInterval,
    DataStatus,
    Exchange,
    Provider,
    RiskOutcome,
    SignalStatus,
    SignalType,
    StrategyRunStatus,
    SubscriptionMode,
)
from app.domain.models import Candle
from app.market_data.calendars.loader import load_market_calendar, load_overrides
from app.market_data.candles.store import candle_values, upsert_candles
from app.persistence.models import InstrumentRow, SignalRow, StrategyRunRow
from app.risk.rules import DATA_QUALITY
from app.services.signals import SignalService
from app.services.strategies import DeploymentView, StrategyService
from app.services.strategy_runs import RunStore
from app.signals.engine import SignalEngine
from app.strategies.registry import builtin_registry
from app.streaming.redis_bus import Streams
from app.workers.strategy_worker import StrategyWorker
from tests.candle_support import bar
from tests.integration.provider_support import ACTOR, LAB, NOW, FakeClock, WorkspaceEntry, add_rows
from tests.integration.strategy_support import EXAMPLE, save_example, start_run, wipe_strategies

pytestmark = pytest.mark.integration

SIM = Provider.SIMULATOR
RUNNING, STOPPED, FAILED = StrategyRunStatus.RUNNING, StrategyRunStatus.STOPPED, StrategyRunStatus.FAILED
MINUTE = timedelta(minutes=1)
WORKER = "worker-under-test"
COUNTS = ("runs", "circuits_open", "warming_instruments", "failed_starts")


@dataclass
class Ticker:
    """The worker's monotonic clock, moved by the test."""

    now: float = 1000.0

    def __call__(self) -> float:
        return self.now


@dataclass
class Lab:
    """The example strategy deployed and enabled in the simulation lab, whose universe starts as ALPHA."""

    container: Container
    clock: FakeClock
    ticker: Ticker
    symbols: dict[str, UUID]
    keys: dict[str, str]  # canonical keys by symbol
    strategies: StrategyService
    deployment: DeploymentView

    @property
    def refresh(self) -> timedelta:
        return timedelta(seconds=self.container.settings.deployment_refresh_seconds)

    async def worker(self, **settings: Any) -> StrategyWorker:
        db, bus = self.container.db, self.container.bus
        configured = self.container.settings.model_copy(update=settings)
        calendar = await load_market_calendar(db)
        return StrategyWorker(
            configured,
            bus,
            db,
            self.strategies,
            RunStore(db, clock=self.clock),
            SignalEngine(db, bus, configured, calendar, clock=self.clock),
            calendar,
            load_overrides=partial(load_overrides, db),
            worker_id=WORKER,
            block_ms=10,
            clock=self.clock,
            monotonic=self.ticker,
        )

    def advance(self, delta: timedelta) -> None:
        self.clock.advance(delta)
        self.ticker.now += delta.total_seconds()

    async def join(self, *names: str) -> None:
        rows: list[WorkspaceEntry] = [(LAB, name, SIM, SubscriptionMode.FULL, None) for name in names]
        await add_rows(self.container, self.symbols, rows)

    def candle(
        self,
        end: datetime,
        close: int = 100,
        *,
        symbol: str = "ALPHA",
        provider: Provider = SIM,
        high: str = "100.5",
        low: str = "99.5",
    ) -> Candle:
        """A closed one-minute candle ending at ``end``."""
        return bar(
            0,
            close,
            high=high,
            low=low,
            start=end - MINUTE,
            status=DataStatus.SIMULATED if provider is SIM else DataStatus.LIVE,
            instrument_id=self.symbols[symbol],
            provider=provider,
            exchange=Exchange.SIM,
            symbol=symbol,
        )

    async def store(self, candles: Sequence[Candle]) -> None:
        async with self.container.db.transaction() as session:
            await upsert_candles(session, [candle_values(candle) for candle in candles])

    async def publish(self, *candles: Candle) -> None:
        for candle in candles:
            await self.container.bus.publish(Streams.CANDLES, candle)

    async def runs(self) -> list[StrategyRunRow]:
        async with self.container.db.session() as session:
            return list(await session.scalars(sa.select(StrategyRunRow).order_by(StrategyRunRow.started_at)))

    async def signals(self) -> list[SignalRow]:
        async with self.container.db.session() as session:
            return list(await session.scalars(sa.select(SignalRow)))


@pytest.fixture
async def lab(container: Container, clock: FakeClock, symbols: dict[str, UUID]) -> AsyncIterator[Lab]:
    await wipe_strategies(container.db)
    try:
        async with container.db.session() as session:
            keys = await session.execute(sa.select(InstrumentRow.symbol, InstrumentRow.canonical_key))
        strategies = StrategyService(container.db, container.bus, clock=clock)
        await add_rows(container, symbols, [(LAB, "ALPHA", SIM, SubscriptionMode.FULL, None)])
        deployment = await save_example(strategies, enable=True)
        yield Lab(container, clock, Ticker(), symbols, dict(keys.all()), strategies, deployment)
    finally:
        await wipe_strategies(container.db)


async def test_a_run_starts_warm_signals_a_crossover_and_stops_once_disabled(lab: Lab) -> None:
    history = [lab.candle(NOW - k * MINUTE) for k in range(64, 0, -1)]  # flat, closing 02:56 to 03:59
    await lab.store(history)
    cutoff = NOW - 5 * MINUTE  # the warm-up reads stored candles up to here, then the candle stream
    await lab.publish(
        *[candle for candle in history if candle.bucket_end >= cutoff],  # the first came from the database
        lab.candle(NOW - MINUTE, symbol="BRAVO"),  # not in the universe
        lab.candle(NOW - MINUTE, provider=Provider.ZERODHA),  # not the provider the run uses for ALPHA
    )
    worker = await lab.worker()
    try:
        await worker.start()
        await lab.publish(lab.candle(NOW, 101, high="101.2", low="100"))  # EMA(9) crosses above EMA(21)
        await worker.step()
        [run] = await lab.runs()
        [signal] = await lab.signals()
        running = worker.details()

        await lab.strategies.set_enabled(lab.deployment.id, False, actor=ACTOR)
        await worker.step()  # reads the reload command
        await worker.step()  # refreshes the runs
        [stopped] = await lab.runs()
        disabled = worker.details()
    finally:
        await worker.stop()

    assert (run.status, run.worker_id) == (RUNNING, WORKER)
    assert run.input_context == {
        "code_fingerprint": builtin_registry().get(EXAMPLE).fingerprint,
        "worker_version": __version__,
        "instruments": {lab.keys["ALPHA"]: SIM.value},
        "excluded": {},
        "warmup": {
            "cutoff": cutoff.isoformat(),
            "stored_candles": 60,
            "stream_candles": 4,
            "instruments_warming": 0,
        },
    }
    assert (run.instruments_warming, run.warmup_remaining) == (0, {})
    assert (signal.signal_type, signal.status, signal.strategy_run_id, signal.deployment_id) == (
        SignalType.BUY,
        SignalStatus.ACTIVE,
        run.id,
        lab.deployment.id,
    )
    assert (signal.symbol, signal.entry_price, signal.source_candle_start) == (
        "ALPHA",
        Decimal(101),
        NOW - MINUTE,
    )
    assert [running[key] for key in COUNTS] == [1, 0, 0, 0]
    assert (
        stopped.id,
        stopped.status,
        stopped.stopped_at,
        stopped.candles_processed,
        stopped.events_processed,
        stopped.signals_emitted,
    ) == (run.id, STOPPED, NOW, 1, 0, 1)
    assert disabled["runs"] == 0


@pytest.mark.parametrize("delay", [timedelta(0), 10 * MINUTE], ids=["fresh", "late"])
async def test_a_crossover_becomes_an_explained_signal_unless_its_data_is_stale(
    lab: Lab, delay: timedelta
) -> None:
    history = [lab.candle(NOW - k * MINUTE) for k in range(64, 0, -1)]
    await lab.store(history)
    await lab.publish(*[candle for candle in history if candle.bucket_end >= NOW - 5 * MINUTE])
    worker = await lab.worker()
    try:
        await worker.start()
        lab.advance(delay)  # the crossover candle reaches the worker this late
        await lab.publish(lab.candle(NOW, 101, high="101.2", low="100"))
        await worker.step()
    finally:
        await worker.stop()
    [row] = await lab.signals()
    detail = await SignalService(lab.container.db).get_signal(row.id)

    used = detail.configuration
    assert (used.deployment_label, used.config_hash, used.code_fingerprint, used.is_current) == (
        lab.deployment.label,
        lab.deployment.config_hash,
        builtin_registry().get(EXAMPLE).fingerprint,
        True,
    )
    signal = detail.signal
    assert signal.reasons[0].startswith("EMA(9) ")
    assert signal.explanation.startswith("EMA(9) crossed above EMA(21) on the 1m candle")
    assert {(value.name, value.data_status) for value in signal.indicator_values} == {
        ("fast", DataStatus.SIMULATED),
        ("slow", DataStatus.SIMULATED),
        ("atr", DataStatus.SIMULATED),
    }
    [target] = signal.targets
    assert signal.stop_loss is not None
    assert signal.entry_price is not None
    assert signal.stop_loss < signal.entry_price < target.price
    assert signal.invalidation_conditions == (
        "price trades below the stop-loss 99.50",
        "EMA(9) crosses back below EMA(21)",
        "no update within 15 minutes",
    )
    assert signal.is_actionable is False  # simulated data
    [decision] = detail.decisions
    blocking = [check for check in decision.checks if not check.passed and check.severity == "BLOCK"]
    if delay:
        assert (signal.status, decision.outcome, [check.rule for check in blocking]) == (
            SignalStatus.BLOCKED,
            RiskOutcome.BLOCK,
            [DATA_QUALITY],
        )
        assert "source data is 600s old (limit 120s)" in blocking[0].message
    else:
        assert (signal.status, decision.outcome, blocking) == (SignalStatus.ACTIVE, RiskOutcome.ALLOW, [])


async def test_a_run_that_cannot_start_as_deployed_waits_for_the_deployment_to_change(lab: Lab) -> None:
    worker = await lab.worker(candle_intervals=[CandleInterval.M5])
    try:
        await worker.start()
        failed = worker.details()
        lab.advance(timedelta(hours=2))  # past any retry delay
        await worker.step()
        waiting = await lab.runs()
        await lab.join("CHARLIE")
        lab.advance(lab.refresh)
        await worker.step()
        retried = await lab.runs()
    finally:
        await worker.stop()

    problem = "it needs 1m candles, which CANDLE_INTERVALS does not build"
    assert [failed[key] for key in COUNTS] == [0, 0, 0, 1]
    assert [(run.status, run.last_error) for run in waiting] == [(FAILED, problem)]
    assert [(run.status, run.last_error) for run in retried] == [(FAILED, problem), (FAILED, problem)]
    assert retried[1].input_context["instruments"] == {
        lab.keys["ALPHA"]: SIM.value,
        lab.keys["CHARLIE"]: SIM.value,
    }


async def test_a_run_restarts_when_its_instruments_change_and_a_dead_workers_runs_are_closed(
    lab: Lab,
) -> None:
    abandoned = await start_run(lab.container.db, lab.deployment, NOW - timedelta(minutes=10))
    worker = await lab.worker()
    try:
        await worker.start()
        started = await lab.runs()
        await lab.join("CHARLIE")
        lab.advance(lab.refresh)  # the periodic refresh notices the new instrument
        await worker.step()
        restarted = await lab.runs()
        details = worker.details()
    finally:
        await worker.stop()

    assert [(run.id, run.status, run.stopped_at, run.last_error) for run in started] == [
        (abandoned, FAILED, NOW, "abandoned: its worker stopped reporting"),
        (started[1].id, RUNNING, None, None),
    ]
    first, second = restarted[1], restarted[2]
    assert (first.id, first.status, first.stopped_at) == (started[1].id, STOPPED, NOW + lab.refresh)
    assert (second.status, second.started_at) == (RUNNING, NOW + lab.refresh)
    assert second.input_context["instruments"] == {
        lab.keys["ALPHA"]: SIM.value,
        lab.keys["CHARLIE"]: SIM.value,
    }
    assert second.input_context["warmup"] == {
        "cutoff": (NOW + lab.refresh).isoformat(),  # an empty candle stream: nothing to replay
        "stored_candles": 0,
        "stream_candles": 0,
        "instruments_warming": 2,
    }
    warmups = builtin_registry().get(EXAMPLE).warmups  # nothing stored: each needs its whole warm-up
    assert (second.instruments_warming, second.warmup_remaining) == (
        2,
        {interval.value: count for interval, count in warmups.items()},
    )
    assert [details[key] for key in COUNTS] == [1, 0, 2, 0]
