"""Integration harness: real PostgreSQL and Redis from ``infra/docker-compose.yml``.

Development data is never touched: tests use a dedicated database (``<DATABASE_NAME>_test``),
recreated and migrated once per session, and Redis logical DB 15, flushed before each test.
Run with ``pytest -m integration`` after ``scripts/setup-dev.ps1`` has created ``backend/.env``.
"""

from __future__ import annotations

import asyncio
import re
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit
from uuid import UUID

import asyncpg
import httpx
import pytest
from alembic import command
from alembic.config import Config
from fastapi import FastAPI
from pydantic import SecretStr
from sqlalchemy import select
from sqlalchemy.engine import make_url

from app.container import Container
from app.core.config import Settings
from app.core.security import generate_encryption_key
from app.domain.enums import Exchange, Provider
from app.main import create_app
from app.persistence.models import InstrumentRow
from app.services.instruments import InstrumentService
from app.services.provider_accounts import ProviderAccountService
from tests.integration.provider_support import (
    ACTOR,
    FakeClock,
    account_service,
    wipe_instruments,
    wipe_providers,
)

BACKEND_DIR = Path(__file__).resolve().parents[2]
_SAFE_DB_NAME = re.compile(r"^[a-z0-9_]{1,60}$")
_TEST_REDIS_DB = 15


def _test_redis_url(url: str) -> str:
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc, f"/{_TEST_REDIS_DB}", parts.query, parts.fragment))


@pytest.fixture(scope="session")
def integration_settings() -> Settings:
    base = Settings(_env_file=str(BACKEND_DIR / ".env"))  # environment variables still take precedence
    url = make_url(base.database_url.get_secret_value())
    test_db = f"{url.database}_test"
    if not _SAFE_DB_NAME.match(test_db):
        raise RuntimeError(f"unexpected test database name: {test_db!r}")
    return base.model_copy(
        update={
            "database_url": SecretStr(url.set(database=test_db).render_as_string(hide_password=False)),
            "redis_url": SecretStr(_test_redis_url(base.redis_url.get_secret_value())),
            "encryption_key": SecretStr(generate_encryption_key()),
            "encryption_previous_keys": None,
            "log_json": False,
            "cookie_secure": False,  # the test client talks plain http
            "market_data_enabled": False,
            "live_signals_enabled": False,
        }
    )


def alembic_config(settings: Settings) -> Config:
    config = Config()  # no ini file: keeps the test process's logging configuration intact
    config.set_main_option("script_location", str(BACKEND_DIR / "alembic"))
    config.attributes["database_url"] = settings.database_url.get_secret_value()
    return config


def with_database(settings: Settings, name: str) -> Settings:
    """The same settings, pointed at another database on the same server."""
    url = make_url(settings.database_url.get_secret_value()).set(database=name)
    return settings.model_copy(update={"database_url": SecretStr(url.render_as_string(hide_password=False))})


async def recreate_database(settings: Settings, *, create: bool = True) -> None:
    """Drop the settings' database and, unless ``create`` is False, create it again, empty."""
    url = make_url(settings.database_url.get_secret_value())
    name = url.database
    assert name is not None
    assert _SAFE_DB_NAME.match(name)
    conn = await asyncpg.connect(
        host=url.host, port=url.port or 5432, user=url.username, password=url.password, database="postgres"
    )
    try:
        await conn.execute(f'DROP DATABASE IF EXISTS "{name}" WITH (FORCE)')
        if create:
            await conn.execute(f'CREATE DATABASE "{name}"')
    finally:
        await conn.close()


@pytest.fixture(scope="session")
def migrated_database(integration_settings: Settings) -> Settings:
    asyncio.run(recreate_database(integration_settings))
    command.upgrade(alembic_config(integration_settings), "head")
    return integration_settings


@pytest.fixture
async def container(migrated_database: Settings) -> AsyncIterator[Container]:
    instance = Container.create(migrated_database)
    await instance.bus.redis.flushdb()
    try:
        yield instance
    finally:
        await instance.close()


@pytest.fixture
def clock() -> FakeClock:
    return FakeClock()


@pytest.fixture
async def accounts(container: Container, clock: FakeClock) -> AsyncIterator[ProviderAccountService]:
    """Account service with no provider accounts before or after the test."""
    await wipe_providers(container.db)
    try:
        yield account_service(container, clock)
    finally:
        await wipe_providers(container.db)


@pytest.fixture
async def symbols(
    accounts: ProviderAccountService,  # no provider accounts or capability overrides
    container: Container,
    clock: FakeClock,
) -> AsyncIterator[dict[str, UUID]]:
    """The simulator's instruments by symbol. Removing them afterwards removes the test's workspace
    rows and candles."""
    await wipe_instruments(container.db)
    await InstrumentService(account_service(container, clock)).refresh(Provider.SIMULATOR, actor=ACTOR)
    async with container.db.session() as session:
        result = await session.execute(
            select(InstrumentRow.symbol, InstrumentRow.id).where(InstrumentRow.exchange == Exchange.SIM)
        )
        ids = dict(result.all())
    try:
        yield ids
    finally:
        await wipe_instruments(container.db)


@pytest.fixture
async def app_and_client(migrated_database: Settings) -> AsyncIterator[tuple[FastAPI, httpx.AsyncClient]]:
    async with api_client(migrated_database) as pair:
        yield pair


@asynccontextmanager
async def api_client(settings: Settings) -> AsyncIterator[tuple[FastAPI, httpx.AsyncClient]]:
    """Runs the real app (lifespan included) in the test's event loop."""
    app = create_app(settings)
    async with app.router.lifespan_context(app):
        await app.state.container.bus.redis.flushdb()
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
            yield app, client
