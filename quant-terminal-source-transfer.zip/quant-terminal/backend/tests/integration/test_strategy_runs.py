"""What the strategy worker reads and writes in PostgreSQL: the runnable deployments with their instruments,
and the run records."""

from __future__ import annotations

from collections.abc import AsyncIterator
from datetime import timedelta
from uuid import UUID

import pytest
import sqlalchemy as sa

from app.container import Container
from app.domain.enums import CandleInterval, Provider, StrategyRunStatus, SubscriptionMode
from app.persistence.models import InstrumentRow, StrategyRunRow, WorkspaceInstrumentRow, WorkspaceRow
from app.services.strategies import DeploymentView, RunView, Scope, StrategyService
from app.services.strategy_runs import RunStore
from app.strategies.runtime import RunStats, WarmupProgress
from tests.integration.provider_support import ACTOR, LAB, NOW, FakeClock, add_rows
from tests.integration.strategy_support import EXAMPLE, save_example, start_run, wipe_strategies

pytestmark = pytest.mark.integration

SIM = Provider.SIMULATOR
STARTING, RUNNING = StrategyRunStatus.STARTING, StrategyRunStatus.RUNNING
CIRCUIT_OPEN, STOPPED, FAILED = (
    StrategyRunStatus.CIRCUIT_OPEN,
    StrategyRunStatus.STOPPED,
    StrategyRunStatus.FAILED,
)


@pytest.fixture
async def strategies(container: Container, clock: FakeClock) -> AsyncIterator[StrategyService]:
    await wipe_strategies(container.db)
    try:
        yield StrategyService(container.db, container.bus, clock=clock)
    finally:
        await wipe_strategies(container.db)


@pytest.fixture
async def deployment(strategies: StrategyService) -> DeploymentView:
    """The example strategy saved in the simulation lab, its live signals off."""
    return await save_example(strategies)


@pytest.fixture
def store(container: Container, clock: FakeClock) -> RunStore:
    return RunStore(container.db, clock=clock)


async def runs(container: Container) -> dict[UUID, StrategyRunRow]:
    async with container.db.session() as session:
        return {row.id: row for row in await session.scalars(sa.select(StrategyRunRow))}


async def lab_universe(container: Container, symbols: dict[str, UUID], *names: str) -> dict[str, str]:
    """Add the instruments to the simulation lab; returns their canonical keys by symbol."""
    await add_rows(container, symbols, [(LAB, name, SIM, SubscriptionMode.FULL, None) for name in names])
    async with container.db.session() as session:
        rows = await session.execute(sa.select(InstrumentRow.symbol, InstrumentRow.canonical_key))
        return dict(rows.all())


# ---- runnable deployments ----------------------------------------------------------------------------


async def test_an_enabled_deployment_runs_on_the_suitable_active_instruments_of_its_workspace(
    container: Container, symbols: dict[str, UUID], strategies: StrategyService
) -> None:
    keys = await lab_universe(container, symbols, "SIM50", "BRAVO", "CHARLIE", "ALPHA")
    async with container.db.transaction() as session:
        await session.execute(
            sa.update(InstrumentRow).where(InstrumentRow.id == symbols["BRAVO"]).values(is_active=False)
        )
    saved = await save_example(strategies)  # the whole workspace

    disabled = await strategies.runnable_deployments()
    enabled = await strategies.set_enabled(saved.id, True, actor=ACTOR)
    [runnable] = await strategies.runnable_deployments()

    assert disabled == []
    assert runnable.deployment == enabled.model_copy(update={"monitoring": None})
    assert [(instrument.symbol, provider) for instrument, provider in runnable.instruments] == [
        ("ALPHA", SIM),
        ("CHARLIE", SIM),
    ]
    assert dict(runnable.excluded) == {
        keys["BRAVO"]: "it is inactive (expired or no longer listed)",
        keys["SIM50"]: f"{EXAMPLE} does not support the INDEX segment",
    }


async def test_an_instrument_that_left_the_workspace_drops_out_of_an_explicit_scope(
    container: Container, symbols: dict[str, UUID], strategies: StrategyService
) -> None:
    keys = await lab_universe(container, symbols, "ALPHA", "BRAVO", "CHARLIE")
    scope = [symbols["CHARLIE"], symbols["BRAVO"]]
    await save_example(strategies, scope=Scope.instruments(scope), enable=True)
    async with container.db.transaction() as session:
        lab = await session.scalar(sa.select(WorkspaceRow.id).where(WorkspaceRow.slug == LAB))
        await session.execute(
            sa.delete(WorkspaceInstrumentRow).where(
                WorkspaceInstrumentRow.workspace_id == lab,
                WorkspaceInstrumentRow.instrument_id == symbols["BRAVO"],
            )
        )

    [runnable] = await strategies.runnable_deployments()

    assert [instrument.symbol for instrument, _ in runnable.instruments] == ["CHARLIE"]
    assert dict(runnable.excluded) == {keys["BRAVO"]: f"it left workspace {LAB}"}


# ---- run records -------------------------------------------------------------------------------------


async def test_a_run_opens_as_starting_and_is_marked_running_once(
    container: Container, clock: FakeClock, deployment: DeploymentView, store: RunStore
) -> None:
    context = {"code_fingerprint": "f00d", "instruments": {"SIM:CASH:ALPHA": "SIMULATOR"}}

    run_id = await store.open(deployment, worker_id="w" * 130, input_context=context)
    opened = (await runs(container))[run_id]
    clock.advance(timedelta(seconds=5))
    marked = await store.mark_running(run_id, context={"warmup": {"stored_candles": 63}})
    again = await store.mark_running(run_id, context={"warmup": {"stored_candles": 0}})
    running = (await runs(container))[run_id]

    assert (opened.status, opened.started_at, opened.heartbeat_at, opened.worker_id) == (
        STARTING,
        NOW,
        NOW,
        "w" * 120,
    )
    assert (
        opened.strategy_version,
        opened.configuration_id,
        opened.config_snapshot,
        opened.config_hash,
    ) == (deployment.strategy_version, deployment.configuration_id, deployment.config, deployment.config_hash)
    assert (marked, again) == (True, False)
    assert (running.status, running.heartbeat_at) == (RUNNING, NOW + timedelta(seconds=5))
    assert running.input_context == {**context, "warmup": {"stored_candles": 63}}


async def test_a_run_records_its_warm_up_progress_and_how_many_instruments_it_covers(
    clock: FakeClock, strategies: StrategyService, deployment: DeploymentView, store: RunStore
) -> None:
    context = {"instruments": {"SIM:CASH:ALPHA": "SIMULATOR", "SIM:CASH:BRAVO": "SIMULATOR"}}
    run_id = await store.open(
        deployment, worker_id="w", input_context={**context, "excluded": {"SIM:INDEX:SIM50": "index"}}
    )
    warming = WarmupProgress(2, {CandleInterval.M5: 3, CandleInterval.M1: 14})

    async def latest() -> RunView:
        [run] = await strategies.list_runs(deployment_id=deployment.id)
        return run

    await store.mark_running(run_id, context={}, warmup=warming)
    started = await latest()
    clock.advance(timedelta(seconds=10))
    await store.record(run_id, RunStats(candles=20), circuit_open=False)  # no progress given: kept
    kept = await latest()
    await store.record(run_id, RunStats(candles=40), circuit_open=False, warmup=WarmupProgress(0, {}))
    warm = await latest()

    assert (started.instruments, started.excluded) == (2, 1)
    assert (started.instruments_warming, started.warmup_remaining) == (2, {"1m": 14, "5m": 3})
    assert list(started.warmup_remaining) == ["1m", "5m"]  # shortest interval first
    assert (kept.instruments_warming, kept.candles_processed) == (2, 20)
    assert (warm.instruments_warming, warm.warmup_remaining) == (0, {})


async def test_recording_stores_the_counters_and_follows_the_circuit(
    container: Container, clock: FakeClock, deployment: DeploymentView, store: RunStore
) -> None:
    run_id = await store.open(deployment, worker_id="w", input_context={})
    stats = RunStats(
        candles=12, events=3, signals=2, failures=5, timeouts=1, last_error="x" * 600, circuit_opened_at=NOW
    )

    clock.advance(timedelta(seconds=10))
    tripped = await store.record(run_id, stats, circuit_open=True)
    tripped_row = (await runs(container))[run_id]
    stats.candles, stats.circuit_opened_at = 13, None
    clock.advance(timedelta(seconds=10))
    recovered = await store.record(run_id, stats, circuit_open=False)
    recovered_row = (await runs(container))[run_id]

    assert (tripped, recovered) == (True, True)
    assert (
        tripped_row.status,
        tripped_row.heartbeat_at,
        tripped_row.candles_processed,
        tripped_row.events_processed,
        tripped_row.signals_emitted,
        tripped_row.failures,
        tripped_row.timeouts,
        tripped_row.circuit_opened_at,
        tripped_row.last_error,
    ) == (CIRCUIT_OPEN, NOW + timedelta(seconds=10), 12, 3, 2, 5, 1, NOW, "x" * 500)
    assert (recovered_row.status, recovered_row.heartbeat_at, recovered_row.candles_processed) == (
        RUNNING,
        NOW + timedelta(seconds=20),
        13,
    )
    assert recovered_row.circuit_opened_at is None


async def test_a_run_closes_once_and_stays_closed(
    container: Container, clock: FakeClock, deployment: DeploymentView, store: RunStore
) -> None:
    run_id = await store.open(deployment, worker_id="w", input_context={})

    with pytest.raises(ValueError, match="does not close a run"):
        await store.close(run_id, RUNNING)
    clock.advance(timedelta(minutes=1))
    closed = await store.close(run_id, FAILED, RunStats(candles=4, last_error="old"), error="warm-up failed")
    reopened = (
        await store.mark_running(run_id, context={}),
        await store.record(run_id, RunStats(), circuit_open=False),
        await store.close(run_id, STOPPED),
    )
    row = (await runs(container))[run_id]

    assert closed is True
    assert reopened == (False, False, False)
    assert (row.status, row.stopped_at, row.candles_processed, row.last_error) == (
        FAILED,
        NOW + timedelta(minutes=1),
        4,
        "warm-up failed",
    )


async def test_open_runs_whose_heartbeat_stopped_are_closed_as_abandoned(
    container: Container, clock: FakeClock, deployment: DeploymentView, store: RunStore
) -> None:
    earlier = NOW - timedelta(minutes=10)
    stale = await start_run(container.db, deployment, earlier)  # no heartbeat: its start counts
    kept = await start_run(container.db, deployment, earlier)
    done = await start_run(container.db, deployment, earlier)
    await store.close(done, STOPPED)
    fresh = await store.open(deployment, worker_id="w", input_context={})
    clock.advance(timedelta(seconds=30))

    closed = await store.close_abandoned(stale_after=timedelta(minutes=1), keep=[kept])
    rows = await runs(container)

    assert closed == [stale]
    assert (rows[stale].status, rows[stale].stopped_at, rows[stale].last_error) == (
        FAILED,
        NOW + timedelta(seconds=30),
        "abandoned: its worker stopped reporting",
    )
    assert (rows[kept].status, rows[done].status, rows[done].stopped_at, rows[fresh].status) == (
        RUNNING,
        STOPPED,
        NOW,
        STARTING,
    )
