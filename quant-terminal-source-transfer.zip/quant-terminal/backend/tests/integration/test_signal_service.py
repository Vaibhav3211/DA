"""Signal history on PostgreSQL: newest-first keyset pages, the filters and a signal's detail."""

from __future__ import annotations

import base64
import json
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

import pytest
from pydantic import ValidationError

from app.container import Container
from app.core.errors import AppError, NotFoundError, ValidationFailedError
from app.domain.enums import Provider, RiskOutcome, SignalEventType, SignalStatus, SignalType
from app.domain.models.instrument import Instrument
from app.domain.models.signal import TargetLevel
from app.market_data.calendars.loader import load_market_calendar
from app.risk.rules import DATA_QUALITY
from app.services.signals import SignalConfiguration, SignalPage, SignalQuery, SignalService
from app.services.strategies import StrategyService
from app.signals.engine import Proposal, RunContext, SignalEngine
from tests.integration.provider_support import ACTOR, LAB, FakeClock, failure
from tests.integration.strategy_support import (
    EXAMPLE,
    example_run,
    load_instrument,
    proposal,
    wipe_strategies,
)

pytestmark = pytest.mark.integration

MINUTE = timedelta(minutes=1)
SELL: dict[str, Any] = {
    "signal_type": SignalType.SELL,
    "stop_loss": Decimal("102.15"),
    "targets": (TargetLevel(label="T1", price=Decimal("96.00")),),
}
ALL = frozenset({"alpha_buy", "bravo_live", "delta_buy", "charlie_stale", "alpha_sell"})
OPEN = frozenset({"bravo_live", "delta_buy", "alpha_sell"})


@dataclass
class History:
    """Signals of the example deployment in the simulation lab, a minute apart from ``start``:

    - ``start``: alpha_buy, a BUY on ALPHA that alpha_sell supersedes;
    - +1m: bravo_live (live data, so actionable) and delta_buy, generated at the same instant;
    - +2m: charlie_stale, a SELL on stale data, blocked;
    - +3m: alpha_sell, active.
    """

    service: SignalService
    engine: SignalEngine
    run: RunContext
    clock: FakeClock
    instruments: dict[str, Instrument]
    start: datetime
    ids: dict[str, UUID] = field(default_factory=dict)

    @property
    def newest_first(self) -> list[str]:
        tie = sorted(("bravo_live", "delta_buy"), key=self.ids.__getitem__, reverse=True)
        return ["alpha_sell", "charlie_stale", *tie, "alpha_buy"]

    def names(self, page: SignalPage) -> list[str]:
        by_id = {signal_id: name for name, signal_id in self.ids.items()}
        return [by_id.get(item.id, str(item.id)) for item in page.items]

    def propose(self, symbol: str, **fields: Any) -> Proposal:
        return proposal(self.instruments[symbol], self.clock.now, **fields)

    async def submit(self, *proposals: Proposal) -> list[UUID]:
        outcomes = await self.engine.submit(self.run, proposals)
        return [outcome.signal_id for outcome in outcomes if outcome.signal_id is not None]

    async def list(self, **filters: Any) -> SignalPage:
        return await self.service.list_signals(SignalQuery(**filters))


@pytest.fixture
async def history(container: Container, clock: FakeClock, symbols: dict[str, UUID]) -> AsyncIterator[History]:
    await wipe_strategies(container.db)
    try:
        settings = container.settings.model_copy(update={"live_signals_enabled": True})
        calendar = await load_market_calendar(container.db)
        h = History(
            service=SignalService(container.db),
            engine=SignalEngine(container.db, container.bus, settings, calendar, clock=clock),
            run=await example_run(container, clock.now),
            clock=clock,
            instruments={
                symbol: await load_instrument(container.db, symbols[symbol])
                for symbol in ("ALPHA", "BRAVO", "CHARLIE", "DELTA", "ECHO")
            },
            start=clock.now,
        )
        [h.ids["alpha_buy"]] = await h.submit(h.propose("ALPHA"))
        clock.advance(MINUTE)
        h.ids["bravo_live"], h.ids["delta_buy"] = await h.submit(
            h.propose("BRAVO", provider=Provider.ZERODHA), h.propose("DELTA")
        )
        clock.advance(MINUTE)
        [h.ids["charlie_stale"]] = await h.submit(h.propose("CHARLIE", age_seconds=600, **SELL))
        clock.advance(MINUTE)
        [h.ids["alpha_sell"]] = await h.submit(h.propose("ALPHA", **SELL))
        yield h
    finally:
        await wipe_strategies(container.db)


def _encoded(value: object) -> str:
    return base64.urlsafe_b64encode(json.dumps(value).encode()).decode("ascii").rstrip("=")


async def test_signals_come_newest_first_with_ties_broken_by_id(history: History) -> None:
    page = await history.list()

    assert history.names(page) == history.newest_first
    assert page.next_cursor is None
    assert {item.workspace_slug for item in page.items} == {LAB}


type Filters = Callable[[History], dict[str, Any]]


@pytest.mark.parametrize(
    ("filters", "expected"),
    [
        pytest.param(lambda h: {"workspace": LAB}, ALL, id="workspace-slug"),
        pytest.param(lambda h: {"workspace": h.run.workspace_id}, ALL, id="workspace-id"),
        pytest.param(lambda h: {"workspace": "india-equity"}, set(), id="another-workspace"),
        pytest.param(lambda h: {"strategy_id": EXAMPLE}, ALL, id="strategy"),
        pytest.param(lambda h: {"strategy_id": "other.strategy"}, set(), id="another-strategy"),
        pytest.param(lambda h: {"deployment_id": h.run.deployment_id}, ALL, id="deployment"),
        pytest.param(lambda h: {"deployment_id": uuid4()}, set(), id="another-deployment"),
        pytest.param(
            lambda h: {"instrument": h.instruments["ALPHA"].id},
            {"alpha_buy", "alpha_sell"},
            id="instrument-id",
        ),
        pytest.param(
            lambda h: {"instrument": h.instruments["BRAVO"].canonical_key},
            {"bravo_live"},
            id="instrument-key",
        ),
        pytest.param(lambda h: {"statuses": frozenset({SignalStatus.ACTIVE})}, OPEN, id="active"),
        pytest.param(
            lambda h: {"statuses": frozenset({SignalStatus.BLOCKED, SignalStatus.SUPERSEDED})},
            {"charlie_stale", "alpha_buy"},
            id="blocked-or-superseded",
        ),
        pytest.param(lambda h: {"open_only": True}, OPEN, id="open"),
        pytest.param(
            lambda h: {"signal_types": frozenset({SignalType.SELL})},
            {"alpha_sell", "charlie_stale"},
            id="sell",
        ),
        pytest.param(lambda h: {"actionable": True}, {"bravo_live"}, id="actionable"),
        pytest.param(lambda h: {"actionable": False}, ALL - {"bravo_live"}, id="informational"),
        pytest.param(lambda h: {"since": h.start + MINUTE}, ALL - {"alpha_buy"}, id="since-is-inclusive"),
        pytest.param(lambda h: {"until": h.start + MINUTE}, {"alpha_buy"}, id="until-is-exclusive"),
        pytest.param(
            lambda h: {"since": h.start + MINUTE, "until": h.start + 3 * MINUTE},
            {"bravo_live", "delta_buy", "charlie_stale"},
            id="window",
        ),
        pytest.param(
            lambda h: {"workspace": LAB, "open_only": True, "actionable": False},
            {"alpha_sell", "delta_buy"},
            id="combined",
        ),
    ],
)
async def test_every_filter_given_must_hold(history: History, filters: Filters, expected: set[str]) -> None:
    page = await history.list(**filters(history))

    assert history.names(page) == [name for name in history.newest_first if name in expected]


async def test_pages_continue_after_their_cursor_whatever_is_generated_meanwhile(history: History) -> None:
    order = history.newest_first
    exact = await history.list(limit=5)
    first = await history.list(limit=3)
    assert first.next_cursor is not None
    history.clock.advance(MINUTE)
    [newer] = await history.submit(history.propose("ECHO"))
    second = await history.list(limit=3, cursor=first.next_cursor)

    assert (len(exact.items), exact.next_cursor) == (5, None)
    assert (history.names(first), history.names(second)) == (order[:3], order[3:])  # across the tie
    assert second.next_cursor is None
    assert (await history.list(limit=1)).items[0].id == newer


async def test_a_cursor_pages_through_the_filtered_list(history: History) -> None:
    sells = frozenset({SignalType.SELL})
    first = await history.list(signal_types=sells, limit=1)
    second = await history.list(signal_types=sells, limit=1, cursor=first.next_cursor)

    assert (history.names(first), history.names(second)) == (["alpha_sell"], ["charlie_stale"])
    assert second.next_cursor is None


@pytest.mark.parametrize(
    ("filters", "error", "code"),
    [
        ({"workspace": "no-such-workspace"}, NotFoundError, "workspace_not_found"),
        ({"workspace": UUID(int=1)}, NotFoundError, "workspace_not_found"),
        ({"instrument": "SIM:CASH:EQUITY:NOPE"}, NotFoundError, "instrument_not_found"),
        ({"instrument": UUID(int=1)}, NotFoundError, "instrument_not_found"),
        ({"cursor": "not a cursor"}, ValidationFailedError, "invalid_cursor"),
        ({"cursor": _encoded({"at": "2026-01-05T04:00:00+00:00"})}, ValidationFailedError, "invalid_cursor"),
        ({"cursor": _encoded(["yesterday", str(UUID(int=1))])}, ValidationFailedError, "invalid_cursor"),
        ({"cursor": "A" * 201}, ValidationFailedError, "invalid_cursor"),
        ({"cursor": "é"}, ValidationFailedError, "invalid_cursor"),
    ],
)
async def test_unknown_references_and_foreign_cursors_are_refused(
    container: Container, filters: dict[str, Any], error: type[AppError], code: str
) -> None:
    await failure(SignalService(container.db).list_signals(SignalQuery(**filters)), error, code)


@pytest.mark.parametrize("gap", [timedelta(0), -MINUTE])
def test_since_must_come_before_until(gap: timedelta) -> None:
    since = datetime(2026, 1, 5, 4, tzinfo=UTC)

    with pytest.raises(ValidationError, match="since must be before until"):
        SignalQuery(since=since, until=since + gap)


async def test_a_signal_comes_with_its_lifecycle_and_every_risk_decision(history: History) -> None:
    superseded = await history.service.get_signal(history.ids["alpha_buy"])
    blocked = await history.service.get_signal(history.ids["charlie_stale"])

    signal = superseded.signal
    assert (signal.workspace_slug, signal.status, signal.superseded_by) == (
        LAB,
        SignalStatus.SUPERSEDED,
        history.ids["alpha_sell"],
    )
    assert [(event.event_type, event.from_status, event.to_status) for event in superseded.events] == [
        (SignalEventType.GENERATED, None, SignalStatus.GENERATED),
        (SignalEventType.ACTIVATED, SignalStatus.GENERATED, SignalStatus.ACTIVE),
        (SignalEventType.SUPERSEDED, SignalStatus.ACTIVE, SignalStatus.SUPERSEDED),
    ]
    assert [decision.outcome for decision in superseded.decisions] == [RiskOutcome.ALLOW]
    assert [event.event_type for event in blocked.events] == [
        SignalEventType.GENERATED,
        SignalEventType.BLOCKED,
    ]
    [decision] = blocked.decisions
    failed = {check.rule for check in decision.checks if not check.passed and check.severity == "BLOCK"}
    assert (decision.outcome, failed) == (RiskOutcome.BLOCK, {DATA_QUALITY})
    assert decision.evaluated_at == history.start + 2 * MINUTE


async def test_an_unknown_signal_is_not_found(container: Container) -> None:
    await failure(SignalService(container.db).get_signal(uuid4()), NotFoundError, "signal_not_found")


async def test_a_signal_keeps_the_configuration_its_run_used(history: History, container: Container) -> None:
    strategies = StrategyService(container.db, container.bus, clock=history.clock)
    saved = await strategies.get_deployment(history.run.deployment_id)

    used = (await history.service.get_signal(history.ids["alpha_buy"])).configuration
    assert used == SignalConfiguration(
        deployment_label=saved.label,
        configuration_id=saved.configuration_id,
        config=saved.config,
        config_hash=saved.config_hash,
        code_fingerprint=None,  # the test run records no input context
        run_started_at=history.start,
        is_current=True,
    )

    edited = await strategies.update_configuration(
        saved.id, label="Wider stops", config={"stop_atr_multiple": "2.5"}, actor=ACTOR
    )
    after = (await history.service.get_signal(history.ids["alpha_buy"])).configuration
    assert edited.config_hash != used.config_hash
    assert after == used.model_copy(update={"deployment_label": "Wider stops", "is_current": False})
