"""Saved strategy configurations on PostgreSQL and Redis: what a scope may hold, the guard against two
configurations proposing the same signals, and the monitoring state derived from the strategy worker's
heartbeat, the kill switch, the risk rules and the source each instrument is bound to."""

from __future__ import annotations

from collections.abc import AsyncIterator, Awaitable
from contextlib import asynccontextmanager
from uuid import UUID, uuid4

import pytest
import sqlalchemy as sa

from app.container import Container
from app.core.errors import ConflictError, ValidationFailedError
from app.domain.enums import MonitoringState, Provider, ScopeKind, SubscriptionMode
from app.observability.heartbeat import STRATEGY_WORKER
from app.persistence.models import InstrumentRow, RiskRuleRow
from app.risk.rules import FREQUENCY
from app.services.kill_switch import KillSwitchService
from app.services.risk import RiskRuleService
from app.services.strategies import MAX_SCOPE, Scope, StrategyService
from app.services.strategy_monitoring import LIVE_SIGNALS_OFF, Monitoring
from app.streaming.redis_bus import Keys
from tests.integration.provider_support import ACTOR, LAB, NOW, FakeClock, WorkspaceEntry, add_rows
from tests.integration.strategy_support import EXAMPLE, save_example, start_run, wipe_strategies

pytestmark = pytest.mark.integration

SIM, ZERODHA = Provider.SIMULATOR, Provider.ZERODHA
STOPPED, STARTING, RUNNING, BLOCKED, FAILED = (
    MonitoringState.STOPPED,
    MonitoringState.STARTING,
    MonitoringState.RUNNING,
    MonitoringState.BLOCKED,
    MonitoringState.FAILED,
)
NO_WORKER = "The strategy worker is not running (no recent heartbeat); start qt-strategy-worker"
WAITING = "Waiting for the strategy worker to start a run with the current settings"
SIMULATED = "Its instruments use simulated data: its signals are informational only"
NO_INDEX = f"{EXAMPLE} does not support the INDEX segment"
KILL_SWITCH = "Kill switch is engaged (drill)"
PAUSED = "Signals are paused for this workspace (results day)"


@pytest.fixture
async def strategies(container: Container, clock: FakeClock) -> AsyncIterator[StrategyService]:
    """The service as configured by default: LIVE_SIGNALS_ENABLED=false."""
    await wipe_strategies(container.db)
    try:
        yield StrategyService(container.db, container.bus, clock=clock)
    finally:
        await wipe_strategies(container.db)


@asynccontextmanager
async def worker_running(container: Container) -> AsyncIterator[None]:
    """The heartbeat a running strategy worker keeps fresh."""
    heartbeat = Keys.worker_heartbeat(STRATEGY_WORKER)
    await container.bus.set_json(heartbeat, {"worker": STRATEGY_WORKER}, ttl_seconds=60)
    try:
        yield
    finally:
        await container.bus.delete(heartbeat)


async def in_lab(container: Container, symbols: dict[str, UUID], **sources: Provider) -> dict[str, str]:
    """Add the instruments (by symbol) to the simulation lab, each bound to the given source provider;
    returns the canonical keys of the simulator's instruments by symbol."""
    entries: list[WorkspaceEntry] = [
        (LAB, symbol, provider, SubscriptionMode.FULL, None) for symbol, provider in sources.items()
    ]
    await add_rows(container, symbols, entries)
    async with container.db.session() as session:
        rows = await session.execute(sa.select(InstrumentRow.symbol, InstrumentRow.canonical_key))
        return dict(rows.all())


async def refusal[E: Exception](kind: type[E], action: Awaitable[object]) -> E:
    with pytest.raises(kind) as caught:
        await action
    return caught.value


async def test_a_scope_is_chosen_explicitly_bounded_and_suited_to_the_strategy(
    container: Container, symbols: dict[str, UUID], strategies: StrategyService
) -> None:
    key = await in_lab(container, symbols, SIM50=SIM, ALPHA=SIM)

    async def refused(scope: Scope) -> ValidationFailedError:
        return await refusal(ValidationFailedError, save_example(strategies, scope=scope))

    empty = await refused(Scope.instruments([]))
    listed = await refused(Scope(ScopeKind.WORKSPACE, (symbols["ALPHA"],)))
    too_many = await refused(Scope.instruments(uuid4() for _ in range(MAX_SCOPE + 1)))
    unsuitable = await refused(Scope.instruments([symbols["SIM50"], symbols["ALPHA"], symbols["BRAVO"]]))
    chosen = await save_example(strategies, scope=Scope.instruments([symbols["ALPHA"]]))

    assert [(error.code, error.message) for error in (empty, listed, too_many)] == [
        (
            "deployment_scope_invalid",
            "Choose at least one instrument, or choose the whole workspace explicitly",
        ),
        ("deployment_scope_invalid", "A whole-workspace scope lists no instruments"),
        ("deployment_scope_too_large", f"A configuration watches at most {MAX_SCOPE} instruments"),
    ]
    assert unsuitable.code == "deployment_scope_rejected"
    assert unsuitable.details["problems"] == [
        {"instrument": key["SIM50"], "reason": NO_INDEX},
        {"instrument": str(symbols["BRAVO"]), "reason": f"it is not in workspace {LAB}"},
    ]
    # Nothing refused was saved.
    assert [view.id for view in await strategies.list_deployments(LAB)] == [chosen.id]


async def test_live_signals_are_refused_where_another_configuration_runs_the_same_settings(
    container: Container, symbols: dict[str, UUID], strategies: StrategyService
) -> None:
    key = await in_lab(container, symbols, ALPHA=SIM, BRAVO=SIM, CHARLIE=SIM)
    alpha, bravo, charlie = symbols["ALPHA"], symbols["BRAVO"], symbols["CHARLIE"]
    pair = await save_example(strategies, scope=Scope.instruments([alpha, bravo]), label="pair", enable=True)
    other = await save_example(strategies, scope=Scope.instruments([charlie, bravo]), label="other")
    whole = await save_example(strategies, label="whole")
    longer = await save_example(
        strategies, scope=Scope.instruments([alpha]), label="longer", config={"valid_for_minutes": 30}
    )

    overlap = await refusal(ConflictError, strategies.set_enabled(other.id, True, actor=ACTOR))
    everything = await refusal(ConflictError, strategies.set_enabled(whole.id, True, actor=ACTOR))
    other_settings = await strategies.set_enabled(longer.id, True, actor=ACTOR)
    await strategies.update_configuration(other.id, scope=Scope.instruments([charlie]), actor=ACTOR)
    apart = await strategies.set_enabled(other.id, True, actor=ACTOR)
    widened = await refusal(
        ConflictError,
        strategies.update_configuration(other.id, scope=Scope.instruments([charlie, alpha]), actor=ACTOR),
    )

    assert overlap.code == "deployment_duplicate"
    assert overlap.message == (
        f"Configuration 'pair' already runs {EXAMPLE} {pair.strategy_version} with the same settings on "
        f"{key['BRAVO']}; stop its live signals first, or change this configuration's settings or scope"
    )
    assert overlap.details == {"deployment_id": str(pair.id), "label": "pair", "instruments": [key["BRAVO"]]}
    # A whole-workspace scope overlaps every instrument scope of its workspace.
    assert (everything.details["label"], everything.details["instruments"]) == (
        "pair",
        [key["ALPHA"], key["BRAVO"]],
    )
    assert other_settings.is_enabled  # other settings propose other signals
    assert (apart.is_enabled, apart.instrument_ids) == (True, (charlie,))
    assert (widened.code, widened.details["instruments"]) == ("deployment_duplicate", [key["ALPHA"]])
    assert await strategies.get_deployment(other.id) == apart  # the refused update changed nothing


async def test_monitoring_reads_the_worker_heartbeat_and_the_source_of_each_instrument(
    container: Container, clock: FakeClock, symbols: dict[str, UUID], strategies: StrategyService
) -> None:
    # ALPHA is bound to a live provider: monitoring only looks at the source each instrument is bound to.
    key = await in_lab(container, symbols, ALPHA=ZERODHA, BRAVO=SIM, SIM50=SIM)
    allowing = StrategyService(container.db, container.bus, clock=clock, live_signals_enabled=True)
    saved = await save_example(strategies, label="whole", enable=True)
    warnings = (
        f"{LIVE_SIGNALS_OFF}: the signals of 1 of its 2 instruments are blocked",
        f"1 instrument left out: {key['SIM50']}: {NO_INDEX}",
    )

    async with worker_running(container):
        waiting = (await strategies.get_deployment(saved.id)).monitoring
        await start_run(container.db, saved, NOW)
        running = (await strategies.get_deployment(saved.id)).monitoring
        allowed = (await allowing.get_deployment(saved.id)).monitoring
    gone = (await strategies.get_deployment(saved.id)).monitoring

    assert saved.monitoring == Monitoring(state=FAILED, reasons=(NO_WORKER,), warnings=warnings)
    assert waiting == Monitoring(state=STARTING, reasons=(WAITING,), warnings=warnings)
    assert running == Monitoring(state=RUNNING, warnings=warnings)
    assert allowed == Monitoring(state=RUNNING, warnings=warnings[1:])
    assert gone == saved.monitoring


async def test_rules_that_block_every_signal_block_monitoring_until_they_are_lifted(
    container: Container, clock: FakeClock, symbols: dict[str, UUID], strategies: StrategyService
) -> None:
    await in_lab(container, symbols, ALPHA=ZERODHA, BRAVO=SIM)
    kill_switch = KillSwitchService(container.db, container.bus)
    risk = RiskRuleService(container.db, clock=clock)
    allowing = StrategyService(container.db, container.bus, clock=clock, live_signals_enabled=True)
    await save_example(strategies, scope=Scope.instruments([symbols["ALPHA"]]), label="live", enable=True)
    await save_example(strategies, scope=Scope.instruments([symbols["BRAVO"]]), label="idle")

    async def states(service: StrategyService = strategies) -> dict[str, Monitoring | None]:
        return {view.label: view.monitoring for view in await service.list_deployments(LAB)}

    async with worker_running(container):
        live_data_off = await states()
        await kill_switch.set(engaged=True, reason="drill", actor=ACTOR)
        await risk.pause(LAB, reason="results day", actor=ACTOR)
        halted = await states()
        await kill_switch.set(engaged=False, reason=None, actor=ACTOR)
        await risk.resume(LAB, actor=ACTOR)
        async with container.db.transaction() as session:
            session.add(RiskRuleRow(rule_key=FREQUENCY, workspace_id=None, params={"max_signals": "many"}))
        unreadable = await states(allowing)
        async with container.db.transaction() as session:
            await session.execute(sa.delete(RiskRuleRow).where(RiskRuleRow.rule_key == FREQUENCY))
        lifted = await states(allowing)

    assert live_data_off == {
        "idle": Monitoring(state=STOPPED, warnings=(SIMULATED,)),
        "live": Monitoring(state=BLOCKED, reasons=(LIVE_SIGNALS_OFF,)),
    }
    assert halted == {
        "idle": Monitoring(
            state=STOPPED,
            warnings=(
                f"If enabled, it would be blocked: {KILL_SWITCH}",
                f"If enabled, it would be blocked: {PAUSED}",
                SIMULATED,
            ),
        ),
        "live": Monitoring(state=BLOCKED, reasons=(KILL_SWITCH, PAUSED, LIVE_SIGNALS_OFF)),
    }
    live = unreadable["live"]
    assert live is not None
    [problem] = live.reasons
    assert live.state is BLOCKED
    assert problem.startswith("Risk rule frequency has invalid stored parameters (max_signals: ")
    assert problem.endswith("); fix with qt risk set or qt risk reset")
    assert unreadable["idle"] == Monitoring(
        state=STOPPED, warnings=(f"If enabled, it would be blocked: {problem}", SIMULATED)
    )
    assert lifted == {
        "idle": Monitoring(state=STOPPED, warnings=(SIMULATED,)),
        "live": Monitoring(state=STARTING, reasons=(WAITING,)),
    }
