"""``qt`` provider commands against PostgreSQL and Redis. Zerodha and Groww are ``httpx`` fakes."""

from __future__ import annotations

import asyncio
import io
import json
import re
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from urllib.parse import urlencode

import httpx
import pytest
from pydantic import SecretStr
from sqlalchemy import func, select, update
from structlog.testing import capture_logs
from structlog.typing import EventDict

from app.cli import _services, entry
from app.container import Container
from app.core.clock import utc_now
from app.core.config import Settings
from app.core.security import generate_encryption_key
from app.domain.events import CommandType
from app.persistence.models import AuditLogRow, WorkspaceRow
from app.services.audit import CLI_ACTOR
from tests.integration.provider_support import (
    KITE_LOGIN_URL,
    REDIRECT_URL,
    FakeProvider,
    Reply,
    csv_reply,
    groww_jwt,
    groww_ok,
    kite_dump,
    kite_equity,
    kite_ok,
    provider_settings,
    wipe_instruments,
    wipe_providers,
    worker_commands,
)

pytestmark = pytest.mark.integration

KITE_KEY = "kiteapikey1234"
KITE_SECRET = "kitesecret5678"
KITE_USER = "AB1234"
KITE_TOKEN = "kiteaccesstoken01"
LOGIN_STATE = "cli-login-state-1234567890"
REQUEST_TOKEN = "reqtoken1234abcd"
SESSION = ("POST", "/session/token")
LOGOUT = ("DELETE", "/session/token")
KITE_DUMP = ("GET", "/instruments")
GROWW_KEY = "growwapikey123"
GROWW_SECRET = "growwsecret456"
PROFILE = ("GET", "/v1/user/detail")
CREATE_TOKEN = ("POST", "/v1/token/api/access")
SYMBOLS = ("INFY", "TCS", "RELIANCE", "SBIN", "ITC", "LT", "WIPRO", "TITAN", "MARUTI", "ONGC", "NTPC", "BEL")
EQUITIES = tuple(
    kite_equity(500_000 + n, symbol, f"{symbol} LTD", exchange_token=n + 1)
    for n, symbol in enumerate(SYMBOLS)
)


@dataclass(frozen=True)
class Harness:
    settings: Settings
    remote: FakeProvider  # answers the provider calls of every command
    audit_watermark: int  # audit rows written by the test have larger ids
    # The commands' structlog events, kept off stdout; a real `qt` prints only warnings, to stderr.
    logs: list[EventDict]

    @property
    def cache(self) -> Path:
        return Path(self.settings.instrument_cache_dir)

    def assert_not_logged(self, *secrets: str) -> None:
        assert self.logs, "no log events were captured"
        logged = repr(self.logs)
        assert [secret for secret in secrets if secret in logged] == []


class Console(io.StringIO):
    """Standard input that is an interactive console, with the user's answers already typed."""

    def isatty(self) -> bool:
        return True


async def _reset_state(settings: Settings) -> int:
    container = Container.create(settings)
    try:
        await wipe_providers(container.db)
        await wipe_instruments(container.db)
        await container.bus.redis.flushdb()
        async with container.db.session() as session:
            return int(await session.scalar(select(func.coalesce(func.max(AuditLogRow.id), 0))) or 0)
    finally:
        await container.close()


@pytest.fixture
def cli(migrated_database: Settings, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Harness]:
    settings = provider_settings(
        migrated_database, market_data_enabled=True, instrument_cache_dir=str(tmp_path / "cache")
    )
    remote = FakeProvider()
    monkeypatch.setattr("app.cli._console.get_settings", lambda: settings)
    monkeypatch.setattr(entry, "configure_logging", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(_services, "http_transport", lambda: remote.transport)
    with capture_logs() as logs:
        yield Harness(settings, remote, asyncio.run(_reset_state(settings)), logs)
        asyncio.run(_reset_state(settings))  # leave the shared test database as seeded


def _run(monkeypatch: pytest.MonkeyPatch, args: list[str], stdin: str = "", *, console: bool = False) -> int:
    monkeypatch.setattr("sys.stdin", Console(stdin) if console else io.StringIO(stdin))
    return entry.main(args)


def _field(output: str, label: str) -> str:
    """The value of the ``label  value`` row in ``output``."""
    for line in output.splitlines():
        if line.startswith(f"{label}  "):
            return line[len(label) :].strip()
    pytest.fail(f"no {label!r} row in:\n{output}")


def _table(output: str) -> list[list[str]]:
    return [re.split(r"\s{2,}", line.strip()) for line in output.splitlines() if line.strip()]


def _created(token: str) -> Reply:
    """Groww's access-token response, which is not wrapped in the usual envelope."""
    return lambda _request: httpx.Response(200, json={"token": token})


def _add_zerodha_account(monkeypatch: pytest.MonkeyPatch, *, enabled: bool = False) -> None:
    assert _run(monkeypatch, ["accounts", "add", "zerodha", "Main"]) == 0
    credentials = f"{KITE_KEY}\n{KITE_SECRET}\n"
    assert _run(monkeypatch, ["accounts", "set-credentials", "Main", "--stdin"], credentials) == 0
    if enabled:
        assert _run(monkeypatch, ["accounts", "enable", "Main"]) == 0


async def _cli_audit_actions(harness: Harness) -> list[str]:
    container = Container.create(harness.settings)
    try:
        async with container.db.session() as session:
            rows = await session.scalars(
                select(AuditLogRow.action)
                .where(AuditLogRow.actor == CLI_ACTOR, AuditLogRow.id > harness.audit_watermark)
                .order_by(AuditLogRow.id)
            )
            return list(rows)
    finally:
        await container.close()


def test_account_lifecycle(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(monkeypatch, ["accounts", "list"]) == 0
    assert "No provider accounts." in capsys.readouterr().err

    assert _run(monkeypatch, ["accounts", "add", "zerodha", "  Main  "]) == 0
    assert capsys.readouterr() == (
        "Added Zerodha account 'Main' (method login-redirect, disabled).\n",
        "Next: qt accounts set-credentials Main -p zerodha\n",
    )

    credentials = f"  {KITE_KEY}  \n{KITE_SECRET}\n"
    assert _run(monkeypatch, ["accounts", "set-credentials", "Main", "--stdin"], credentials) == 0
    assert capsys.readouterr() == (
        "Stored the API key and API secret of Zerodha account 'Main', encrypted.\n",
        "Next: qt zerodha login Main\n",
    )

    assert _run(monkeypatch, ["accounts", "show", "Main"]) == 0
    shown = capsys.readouterr().out
    assert _field(shown, "Status") == "login required"
    assert _field(shown, "Enabled") == "no"
    assert _field(shown, "Credentials") == "API key ••••1234, API secret"
    assert KITE_SECRET not in shown

    assert _run(monkeypatch, ["accounts", "enable", "Main"]) == 0
    assert capsys.readouterr() == ("Enabled Zerodha account 'Main'.\n", "Next: qt zerodha login Main\n")

    assert _run(monkeypatch, ["accounts", "update", "Main", "--label", "Primary"]) == 0
    assert (
        capsys.readouterr().out
        == "Updated Zerodha account 'Primary': method login-redirect, login required.\n"
    )

    assert _run(monkeypatch, ["accounts", "list", "-p", "zerodha"]) == 0
    assert _table(capsys.readouterr().out) == [
        ["PROVIDER", "LABEL", "STATUS", "ENABLED", "METHOD", "TOKEN VALID UNTIL"],
        ["zerodha", "Primary", "login required", "yes", "login-redirect", "-"],
    ]

    assert _run(monkeypatch, ["accounts", "clear-credentials", "Primary", "--api-secret", "--yes"]) == 0
    assert capsys.readouterr() == (
        "Deleted the stored API secret of Zerodha account 'Primary'.\n",
        "Next: qt accounts set-credentials Primary -p zerodha\n",
    )

    # Removal asks first: anything but yes keeps the account, and without a console it needs --yes.
    assert _run(monkeypatch, ["accounts", "remove", "Primary"], "n\n", console=True) == 1
    out, err = capsys.readouterr()
    assert out == "Remove Zerodha account 'Primary' and its stored credentials? [y/N]: "
    assert err == "Nothing was removed.\n"
    assert _run(monkeypatch, ["accounts", "remove", "Primary"]) == 1
    assert "pass --yes" in capsys.readouterr().err

    assert _run(monkeypatch, ["accounts", "remove", "Primary", "--yes"]) == 0
    assert capsys.readouterr().out == "Removed Zerodha account 'Primary'.\n"
    assert asyncio.run(_cli_audit_actions(cli)) == [
        "provider_account.create",
        "provider_account.credentials_set",
        "provider_account.enable",
        "provider_account.update",
        "provider_account.credentials_cleared",
        "provider_account.delete",
    ]
    cli.assert_not_logged(KITE_KEY, KITE_SECRET)


def test_zerodha_login_and_logout(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    # Without login_time the session counts as issued now, so its token is still valid.
    cli.remote.routes[SESSION] = kite_ok({"user_id": KITE_USER, "access_token": KITE_TOKEN})
    cli.remote.routes[LOGOUT] = kite_ok(True)
    monkeypatch.setattr("app.services.provider_auth.new_opaque_token", lambda: LOGIN_STATE)
    _add_zerodha_account(monkeypatch, enabled=True)
    capsys.readouterr()

    assert _run(monkeypatch, ["zerodha", "login"]) == 1
    assert "run `qt zerodha login` in a terminal" in capsys.readouterr().err
    assert _run(monkeypatch, ["zerodha", "login"], "\n", console=True) == 1
    assert "no address was entered" in capsys.readouterr().err

    query = {
        "action": "login",
        "status": "success",
        "request_token": REQUEST_TOKEN,
        "state": LOGIN_STATE,
    }
    pasted = f"{REDIRECT_URL}?{urlencode(query)}\n"
    assert _run(monkeypatch, ["zerodha", "login"], pasted, console=True) == 0
    out, err = capsys.readouterr()
    assert f"\n   {KITE_LOGIN_URL}?" in out
    assert f"api_key={KITE_KEY}" in out
    assert f"2. Kite then sends the browser to {REDIRECT_URL}\n" in out
    assert f"Logged in Zerodha account 'Main' as Zerodha user {KITE_USER}; the access token is valid" in out
    assert err == "The market-data worker will reconnect it.\n"
    assert KITE_TOKEN not in out + err

    assert _run(monkeypatch, ["zerodha", "logout", "Main"]) == 0
    assert capsys.readouterr().out == (
        "Logged out Zerodha account 'Main': Zerodha ended the Kite session "
        "and the access token was deleted.\n"
    )
    assert _run(monkeypatch, ["zerodha", "logout"]) == 0
    assert capsys.readouterr().out == "Zerodha account 'Main' had no access token to log out.\n"
    assert cli.remote.paths() == [SESSION, LOGOUT]
    assert asyncio.run(_cli_audit_actions(cli))[-2:] == ["provider_account.login", "provider_account.logout"]
    cli.assert_not_logged(KITE_SECRET, KITE_TOKEN, REQUEST_TOKEN)


def test_groww_tokens(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    first, second, by_secret, by_totp = (groww_jwt(utc_now() + timedelta(hours=h)) for h in (5, 6, 7, 8))
    assert _run(monkeypatch, ["groww", "set-token", "--token-stdin"], f"{first}\n") == 1
    assert "there is no Groww account; add one with `qt accounts add groww LABEL`" in capsys.readouterr().err

    assert _run(monkeypatch, ["accounts", "add", "groww", "Main"]) == 0
    assert _run(monkeypatch, ["accounts", "add", "groww", "Spare"]) == 0
    capsys.readouterr()
    assert _run(monkeypatch, ["groww", "logout"]) == 1
    error = capsys.readouterr().err
    assert "there are several Groww accounts and none is enabled; name one of: Main, Spare" in error
    assert _run(monkeypatch, ["accounts", "remove", "Spare", "--yes"]) == 0
    capsys.readouterr()

    assert _run(monkeypatch, ["groww", "set-token", "--token-stdin", "--no-verify"], f"{first}\n") == 0
    out, err = capsys.readouterr()
    assert out.startswith("Stored the access token of Groww account 'Main'; it is valid until ")
    assert err == (
        "It was not checked with Groww: a rejected token shows when the account connects.\n"
        "Next: qt accounts enable Main -p groww\n"
    )
    assert cli.remote.requests == []

    cli.remote.routes[PROFILE] = groww_ok({"ucc": "GW1234", "nse_enabled": True, "active_segments": ["CASH"]})
    assert _run(monkeypatch, ["groww", "set-token", "Main", "--token-stdin"], f"{second}\n") == 0
    assert capsys.readouterr().err == "Next: qt accounts enable Main -p groww\n"
    assert cli.remote.paths() == [PROFILE]

    assert _run(monkeypatch, ["groww", "logout"]) == 0
    out, err = capsys.readouterr()
    assert out == "Deleted the access token of Groww account 'Main'.\n"
    assert err.startswith("Groww has no logout API: the token stays valid at Groww until ")
    assert second not in out + err

    # Creating tokens needs an API key method.
    assert _run(monkeypatch, ["groww", "create-token"]) == 1
    assert "store one with `qt groww set-token Main`" in capsys.readouterr().err
    assert _run(monkeypatch, ["accounts", "update", "Main", "--method", "api-key-secret"]) == 0
    credentials = f"{GROWW_KEY}\n{GROWW_SECRET}\n"
    assert _run(monkeypatch, ["accounts", "set-credentials", "Main", "--stdin"], credentials) == 0
    capsys.readouterr()
    cli.remote.routes[CREATE_TOKEN] = _created(by_secret)
    assert _run(monkeypatch, ["groww", "create-token"]) == 0
    assert capsys.readouterr().out.startswith("Created an access token for Groww account 'Main'; it is valid")

    # TOTP without a stored TOTP secret: the code is asked for at the console.
    assert _run(monkeypatch, ["accounts", "update", "Main", "--method", "totp"]) == 0
    cli.remote.routes[CREATE_TOKEN] = _created(by_totp)
    capsys.readouterr()
    assert _run(monkeypatch, ["groww", "create-token"]) == 1
    assert "pass the authenticator's current code with --code" in capsys.readouterr().err
    assert _run(monkeypatch, ["groww", "create-token"], "123456\n", console=True) == 0
    assert capsys.readouterr().out.startswith("Authenticator code: Created an access token for Groww")
    assert json.loads(cli.remote.requests[-1].content) == {"key_type": "totp", "totp": "123456"}
    assert asyncio.run(_cli_audit_actions(cli)) == [
        "provider_account.create",
        "provider_account.create",
        "provider_account.delete",
        "provider_account.token_set",
        "provider_account.token_set",
        "provider_account.logout",
        "provider_account.update",
        "provider_account.credentials_set",
        "provider_account.token_created",
        "provider_account.update",
        "provider_account.token_created",
    ]
    cli.assert_not_logged(first, second, by_secret, by_totp, GROWW_KEY, GROWW_SECRET)


def test_instrument_commands(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    _add_zerodha_account(monkeypatch)
    capsys.readouterr()
    cli.remote.routes[KITE_DUMP] = csv_reply(kite_dump(*EQUITIES))
    assert _run(monkeypatch, ["instruments", "refresh", "zerodha", "--account", "Main"]) == 0
    out, err = capsys.readouterr()
    assert err == "Downloading the Zerodha instrument list...\n"
    assert _field(out, "Source") == "download (API key of account 'Main')"
    assert _field(out, "Rows") == "12 read, 12 accepted"
    assert _field(out, "Skipped") == "none"
    assert _field(out, "Instruments") == "12 new"
    assert _field(out, "Mappings") == "12 new"
    saved = Path(_field(out, "Saved copy"))
    assert saved.parent == cli.cache / "zerodha"
    assert saved.read_bytes() == kite_dump(*EQUITIES)
    assert _field(out, "Workers") == "asked to re-resolve their subscriptions"

    assert _run(monkeypatch, ["instruments", "search", "infy"]) == 0
    assert _table(capsys.readouterr().out) == [
        ["KEY", "NAME", "LOT", "TICK", "PROVIDERS"],
        ["NSE:CASH:EQUITY:INFY", "INFY LTD", "1", "0.05", "zerodha"],
    ]
    assert _run(monkeypatch, ["instruments", "search", "ltd", "--limit", "5"]) == 0
    out, err = capsys.readouterr()
    assert len(_table(out)) == 6
    assert err == "More results: add --offset 5\n"
    assert _run(monkeypatch, ["instruments", "search", "nifty"]) == 0
    assert capsys.readouterr() == ("", "No instruments match.\n")

    assert _run(monkeypatch, ["instruments", "show", "NSE:CASH:EQUITY:INFY"]) == 0
    details, mappings = capsys.readouterr().out.split("\n\n")
    assert _field(details, "Key") == "NSE:CASH:EQUITY:INFY"
    assert _field(details, "Lot size") == "1"
    mapping = _table(mappings)[1]
    assert mapping[:7] == ["zerodha", "500000", "1", "INFY", "NSE", "NSE", "yes"]
    assert mapping[-1] == "-"

    # A download needs an API key: an enabled account's, the named account's or ZERODHA_API_KEY.
    assert _run(monkeypatch, ["instruments", "refresh", "zerodha"]) == 1
    assert "needs a Kite API key" in capsys.readouterr().err

    # A dump missing most of a segment is refused; the downloaded copy stays for inspection.
    truncated = kite_dump(*EQUITIES[:5])
    cli.remote.routes[KITE_DUMP] = csv_reply(truncated)
    assert _run(monkeypatch, ["instruments", "refresh", "zerodha", "--account", "Main"]) == 1
    kept_in = cli.cache / "zerodha"
    assert capsys.readouterr().err.endswith(
        f"with --force. The downloaded copy is kept in {kept_in} for inspection.\n"
    )
    kept = max(kept_in.glob("*.csv"))
    assert kept.read_bytes() == truncated

    assert _run(monkeypatch, ["instruments", "refresh", "zerodha", "--file", str(kept), "--force"]) == 0
    out, err = capsys.readouterr()
    assert err == ""
    assert _field(out, "Source") == f"file {kept}"
    assert _field(out, "Instruments") == "7 deactivated"
    assert _field(out, "Mappings") == "5 unchanged, 7 closed"
    assert _field(out, "Forced") == "yes"
    assert "Saved copy" not in out

    assert _run(monkeypatch, ["instruments", "search", "--inactive", "--limit", "100"]) == 0
    rows = _table(capsys.readouterr().out)
    assert rows[0] == ["KEY", "NAME", "LOT", "TICK", "PROVIDERS", "ACTIVE"]
    assert sorted(row[0] for row in rows[1:]) == sorted(f"NSE:CASH:EQUITY:{symbol}" for symbol in SYMBOLS[5:])
    assert {(row[4], row[5]) for row in rows[1:]} == {("-", "no")}

    missing = tmp_path / "missing.csv"
    assert _run(monkeypatch, ["instruments", "refresh", "zerodha", "--file", str(missing)]) == 1
    assert f"Cannot read the instrument file {missing}" in capsys.readouterr().err

    assert _run(monkeypatch, ["instruments", "refresh", "simulator"]) == 0
    out, err = capsys.readouterr()
    assert _field(out, "Source") == "built in"
    assert err == ""


def test_rotate_encryption_key(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    _add_zerodha_account(monkeypatch)
    previous = cli.settings.encryption_key
    assert previous is not None
    rotated = cli.settings.model_copy(
        update={"encryption_key": SecretStr(generate_encryption_key()), "encryption_previous_keys": previous}
    )
    monkeypatch.setattr("app.cli._console.get_settings", lambda: rotated)
    capsys.readouterr()

    assert _run(monkeypatch, ["rotate-encryption-key"]) == 0
    out, err = capsys.readouterr()
    assert (_field(out, "Re-encrypted"), _field(out, "Already current"), _field(out, "Unreadable")) == (
        "2",
        "0",
        "0",
    )
    assert "ENCRYPTION_PREVIOUS_KEYS can be removed" in err
    assert _run(monkeypatch, ["rotate-encryption-key"]) == 0
    out = capsys.readouterr().out
    assert (_field(out, "Re-encrypted"), _field(out, "Already current")) == ("0", "2")

    # A key that never encrypted the credentials cannot read them: the run fails and names them.
    stranger = rotated.model_copy(
        update={"encryption_key": SecretStr(generate_encryption_key()), "encryption_previous_keys": None}
    )
    monkeypatch.setattr("app.cli._console.get_settings", lambda: stranger)
    assert _run(monkeypatch, ["rotate-encryption-key"]) == 1
    out, err = capsys.readouterr()
    assert _field(out, "Unreadable") == "2"
    assert "No configured key can decrypt these stored credentials:\n" in err
    assert "  ZERODHA/Main:API_KEY\n" in err
    assert "  ZERODHA/Main:API_SECRET\n" in err


def test_capability_overrides(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(monkeypatch, ["accounts", "add", "zerodha", "Main"]) == 0
    capsys.readouterr()

    provider_wide = [
        "depth_levels=20",
        "exchanges=NSE, BSE",
        "--source",
        "  Kite   docs ",
        "--verified-on",
        "2026-01-02",
    ]
    assert _run(monkeypatch, ["capabilities", "set", "zerodha", *provider_wide]) == 0
    assert capsys.readouterr().out == (
        "Updated the provider-wide Zerodha override. It now sets:\ndepth_levels  20\nexchanges     NSE, BSE\n"
    )
    per_account = ["max_instruments_per_connection=1000", "--source", "plan letter", "--account", "Main"]
    assert _run(monkeypatch, ["capabilities", "set", "zerodha", *per_account]) == 0
    assert capsys.readouterr().out.startswith("Updated the Zerodha account 'Main' override. It now sets:\n")
    assert _run(monkeypatch, ["capabilities", "set", "zerodha", "depth_levels=many", "--source", "docs"]) == 1
    assert "depth_levels" in capsys.readouterr().err

    assert _run(monkeypatch, ["capabilities", "show", "zerodha", "--account", "Main"]) == 0
    out = capsys.readouterr().out
    assert _field(out, "depth_levels") == "20  *"
    assert _field(out, "max_instruments_per_connection") == "1000  *"
    assert (
        "  provider-wide Zerodha: depth_levels, exchanges (verified 2026-01-02; source: Kite docs)\n" in out
    )
    assert "  Zerodha account 'Main': max_instruments_per_connection (verified " in out

    assert _run(monkeypatch, ["capabilities", "show", "zerodha", "--json"]) == 0
    shown = json.loads(capsys.readouterr().out)
    assert (shown["depth_levels"], shown["exchanges"]) == (20, ["NSE", "BSE"])
    assert shown["max_instruments_per_connection"] != 1000  # that override is the account's only

    assert _run(monkeypatch, ["capabilities", "clear", "zerodha", "exchanges", "exchanges"]) == 0
    assert capsys.readouterr().out == (
        "Removed exchanges from the provider-wide Zerodha override; it still sets depth_levels.\n"
    )
    assert _run(monkeypatch, ["capabilities", "clear", "zerodha", "exchanges"]) == 0
    assert capsys.readouterr() == ("", "The provider-wide Zerodha override does not set exchanges.\n")
    assert _run(monkeypatch, ["capabilities", "clear", "zerodha"]) == 0
    assert capsys.readouterr().out == (
        "Deleted the provider-wide Zerodha override (depth_levels); the documented values apply.\n"
    )
    assert _run(monkeypatch, ["capabilities", "clear", "zerodha"]) == 0
    assert capsys.readouterr() == ("", "There is no provider-wide Zerodha override.\n")
    assert _run(monkeypatch, ["capabilities", "clear", "zerodha", "--account", "Main"]) == 0
    assert capsys.readouterr().out == (
        "Deleted the Zerodha account 'Main' override (max_instruments_per_connection); "
        "the documented values apply.\n"
    )
    assert asyncio.run(_cli_audit_actions(cli)) == [
        "provider_account.create",
        "provider_capability.set",
        "provider_capability.set",
        "provider_capability.clear",
        "provider_capability.clear",
        "provider_capability.clear",
    ]


async def _enabled_workspaces(settings: Settings, restore: list[str] | None = None) -> list[str]:
    """The enabled workspaces, after enabling exactly ``restore`` when given."""
    container = Container.create(settings)
    try:
        async with container.db.transaction() as session:
            if restore is not None:
                await session.execute(update(WorkspaceRow).values(is_enabled=WorkspaceRow.slug.in_(restore)))
            return sorted(await session.scalars(select(WorkspaceRow.slug).where(WorkspaceRow.is_enabled)))
    finally:
        await container.close()


@pytest.fixture
def seeded_workspaces(cli: Harness) -> Iterator[None]:
    """Leave the workspaces enabled as seeded; their instruments go with the instruments."""
    enabled = asyncio.run(_enabled_workspaces(cli.settings))
    yield
    asyncio.run(_enabled_workspaces(cli.settings, enabled))


async def _refresh_targets(settings: Settings) -> list[str | None]:
    """The workspace named by each subscription refresh asked of the workers (None: every one)."""
    container = Container.create(settings)
    try:
        return [
            command.params.get("workspace")
            for command in await worker_commands(container.bus)
            if command.type is CommandType.REFRESH_SUBSCRIPTIONS
        ]
    finally:
        await container.close()


@pytest.mark.usefixtures("seeded_workspaces")
def test_workspace_commands(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    lab = cli.settings.model_copy(update={"simulator_enabled": True})
    monkeypatch.setattr("app.cli._console.get_settings", lambda: lab)
    dump = tmp_path / "kite.csv"
    dump.write_bytes(kite_dump(*EQUITIES))
    assert _run(monkeypatch, ["instruments", "refresh", "simulator"]) == 0
    assert _run(monkeypatch, ["instruments", "refresh", "zerodha", "--file", str(dump)]) == 0
    assert _run(monkeypatch, ["accounts", "add", "simulator", "Lab"]) == 0
    capsys.readouterr()

    assert _run(monkeypatch, ["workspaces", "list"]) == 0
    listed = {row[0]: row[1:] for row in _table(capsys.readouterr().out)[1:]}
    assert listed["simulation-lab"] == ["Simulation Lab", "lab", "yes", "0"]
    assert listed["forex-major"] == ["Major Pairs", "forex", "no", "0"]

    alpha, bravo = "SIM:CASH:EQUITY:ALPHA", "SIM:CASH:EQUITY:BRAVO"
    add = ["workspaces", "add", "simulation-lab", "simulator"]
    assert _run(monkeypatch, [*add, "sim:cash:equity:alpha", bravo, alpha, "--mode", "ltp"]) == 0
    out, err = capsys.readouterr()
    assert _table(out) == [
        ["KEY", "CHANGE", "STATUS"],
        [alpha, "added", "skipped: SIMULATOR has no enabled account"],
        [bravo, "added", "skipped: SIMULATOR has no enabled account"],
    ]
    assert err == "Asked the market-data workers to update their subscriptions.\n"

    assert _run(monkeypatch, ["accounts", "enable", "Lab"]) == 0
    capsys.readouterr()
    assert _run(monkeypatch, ["workspaces", "show", "simulation-lab"]) == 0
    details, entries = capsys.readouterr().out.split("\n\n")
    assert [_field(details, label) for label in ("Exchanges", "Segments", "Types", "Instruments")] == [
        "SIM",
        "CASH, INDEX",
        "any",
        "2",
    ]
    assert _table(entries) == [
        ["KEY", "PROVIDER", "ACCOUNT", "MODE", "STATUS"],
        [alpha, "simulator", "-", "ltp", "planned (Lab)"],
        [bravo, "simulator", "-", "ltp", "planned (Lab)"],
    ]

    # Adding again with another source changes it; the same source changes nothing.
    assert _run(monkeypatch, [*add, alpha, bravo, "--account", "lab", "--mode", "full"]) == 0
    assert _table(capsys.readouterr().out)[1:] == [
        [alpha, "changed (was simulator, ltp)", "planned (Lab)"],
        [bravo, "changed (was simulator, ltp)", "planned (Lab)"],
    ]
    assert _run(monkeypatch, [*add, bravo, "--account", "Lab", "--mode", "full"]) == 0
    out, err = capsys.readouterr()
    assert (_table(out)[1:], err) == ([[bravo, "unchanged", "planned (Lab)"]], "")

    # All or nothing, with every problem listed. There is no fallback to another provider.
    infy = "NSE:CASH:EQUITY:INFY"
    assert _run(monkeypatch, ["workspaces", "add", "india-equity", "groww", alpha, infy, "nse:x"]) == 1
    assert capsys.readouterr().err.splitlines() == [
        "error: nothing was added to workspace 'india-equity':",
        f"  {alpha}: its exchange SIM is not one this workspace takes (NSE, BSE)",
        f"  {infy}: Groww Trading API does not list it",
        "  NSE:X: no such instrument",
    ]
    assert _run(monkeypatch, ["workspaces", "add", "forex-major", "zerodha", infy]) == 1
    assert capsys.readouterr().err == (
        "error: Workspace 'forex-major' takes no instruments: no market-data provider serves it yet\n"
    )
    assert _run(monkeypatch, ["workspaces", "enable", "forex-major"]) == 1
    assert capsys.readouterr().err == (
        "error: Workspace 'forex-major' cannot be enabled: no market-data provider serves it yet\n"
    )

    assert _run(monkeypatch, ["workspaces", "disable", "simulation-lab"]) == 0
    assert capsys.readouterr().out.startswith("Disabled workspace 'simulation-lab'; ")
    assert _run(monkeypatch, ["workspaces", "show", "simulation-lab"]) == 0
    details, entries = capsys.readouterr().out.split("\n\n")
    assert _field(details, "Enabled") == "no"
    assert [row[-1] for row in _table(entries)[1:]] == ["workspace disabled", "workspace disabled"]
    assert _run(monkeypatch, ["workspaces", "enable", "simulation-lab"]) == 0
    assert _run(monkeypatch, ["workspaces", "enable", "simulation-lab"]) == 0
    out, err = capsys.readouterr()
    assert out == "Enabled workspace 'simulation-lab'.\nWorkspace 'simulation-lab' is already enabled.\n"
    assert err == "Asked the market-data workers to update their subscriptions.\n"

    assert (
        _run(monkeypatch, ["workspaces", "remove", "simulation-lab", alpha, "SIM:CASH:EQUITY:CHARLIE"]) == 0
    )
    assert _table(capsys.readouterr().out) == [
        ["KEY", "CHANGE"],
        [alpha, "removed"],
        ["SIM:CASH:EQUITY:CHARLIE", "not in the workspace"],
    ]
    assert _run(monkeypatch, ["workspaces", "show", "simulation-lab"]) == 0
    assert _table(capsys.readouterr().out.split("\n\n")[1])[1:] == [
        [bravo, "simulator", "Lab", "full", "planned (Lab)"]
    ]

    assert asyncio.run(_cli_audit_actions(cli)) == [
        "instruments.refresh",
        "instruments.refresh",
        "provider_account.create",
        "workspace.instruments.add",
        "provider_account.enable",
        "workspace.instruments.add",
        "workspace.disable",
        "workspace.enable",
        "workspace.instruments.remove",
    ]
    # Two instrument refreshes (every workspace), then the five changes to simulation-lab.
    assert asyncio.run(_refresh_targets(cli.settings)) == [None, None] + ["simulation-lab"] * 5
