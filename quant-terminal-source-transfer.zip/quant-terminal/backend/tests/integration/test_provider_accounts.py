"""Provider account service against PostgreSQL and Redis. No provider endpoint is contacted."""

from __future__ import annotations

import os
from datetime import timedelta
from typing import Any
from uuid import UUID, uuid4

import pytest
import sqlalchemy as sa
from pydantic import SecretStr
from redis.exceptions import RedisError
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.container import Container
from app.core.config import AppEnv
from app.core.errors import ConflictError, NotFoundError, ServiceUnavailableError, ValidationFailedError
from app.core.security import EncryptionError, SecretBox
from app.domain.enums import AccountStatus, AuthMethod, ConnectionState, CredentialKind, Provider
from app.domain.events import CommandType
from app.persistence.models import (
    AuditLogRow,
    ProviderAccountRow,
    ProviderConnectionEventRow,
    ProviderCredentialRow,
)
from app.providers.base import SessionCredentials, StateChange
from app.providers.errors import ProviderAuthRequiredError, ProviderNotEnabledError
from app.services.audit import SYSTEM_ACTOR
from app.services.provider_accounts import (
    AccountConnectionObserver,
    CredentialInfo,
    CredentialOrigin,
    CredentialVault,
    ProviderAccountService,
    ProviderAccountView,
)
from tests.integration.provider_support import (
    ACTOR,
    NOW,
    FakeClock,
    account_service,
    audit_entries,
    failure,
    provider_settings,
    store_token,
    token_metadata,
    worker_commands,
)

pytestmark = pytest.mark.integration

API_KEY = CredentialKind.API_KEY
API_SECRET = CredentialKind.API_SECRET
ACCESS_TOKEN = CredentialKind.ACCESS_TOKEN
TOTP_SECRET = CredentialKind.TOTP_SECRET
ACCOUNT = CredentialOrigin.ACCOUNT
ENVIRONMENT = CredentialOrigin.ENVIRONMENT
KITE_KEYS = {API_KEY: "kiteapikey1234", API_SECRET: "kitesecret5678"}
TOTP_SEED = "JBSWY3DPEHPK3PXP"
LATER = NOW + timedelta(hours=20)


async def zerodha(
    accounts: ProviderAccountService, label: str = "Main", *, keys: bool = True
) -> ProviderAccountView:
    view = await accounts.create(Provider.ZERODHA, label, actor=ACTOR)
    if keys:
        view = await accounts.set_credentials(view.id, KITE_KEYS, actor=ACTOR)
    return view


async def groww(
    accounts: ProviderAccountService, label: str = "Main", method: AuthMethod | None = None
) -> ProviderAccountView:
    return await accounts.create(Provider.GROWW, label, auth_method=method, actor=ACTOR)


def keyless(container: Container, clock: FakeClock, **overrides: Any) -> ProviderAccountService:
    """An account service without an encryption key."""
    return ProviderAccountService(
        container.db, container.bus, provider_settings(container.settings, **overrides), None, clock=clock
    )


async def stored(container: Container, account_id: UUID) -> dict[CredentialKind, ProviderCredentialRow]:
    async with container.db.session() as session:
        return await ProviderAccountService.credential_rows(session, account_id)


async def connection_events(container: Container) -> list[ProviderConnectionEventRow]:
    async with container.db.session() as session:
        rows = await session.scalars(
            select(ProviderConnectionEventRow).order_by(ProviderConnectionEventRow.occurred_at)
        )
        return list(rows)


async def actions(container: Container, account_id: UUID) -> list[str]:
    return [entry.action for entry in await audit_entries(container.db, account_id)]


def change(
    account_id: UUID | None,
    state: ConnectionState,
    *,
    previous: ConnectionState | None = None,
    reason: str = "",
    at: timedelta = timedelta(),
    provider: Provider = Provider.ZERODHA,
) -> StateChange:
    return StateChange(
        provider=provider,
        account_id=account_id,
        stream_id=f"{provider.value.lower()}:main",
        previous=previous,
        state=state,
        reason=reason,
        occurred_at=NOW + at,
    )


# ---- create and look up ---------------------------------------------------------------------------


async def test_create_uses_the_default_method_and_settles_the_status(
    accounts: ProviderAccountService, container: Container
) -> None:
    kite = await accounts.create(Provider.ZERODHA, "  Main   account ", actor=ACTOR)
    assert kite.label == "Main account"
    assert kite.auth_method is AuthMethod.ZERODHA_LOGIN_REDIRECT
    assert kite.status is AccountStatus.NEEDS_CREDENTIALS
    assert kite.missing_credentials == (API_KEY, API_SECRET)
    assert (kite.credentials, kite.is_enabled, kite.has_access_token) == ((), False, False)
    assert (kite.created_by, kite.created_at) == (ACTOR, NOW)
    assert await accounts.get(kite.id) == kite

    pasted = await groww(accounts)
    assert pasted.auth_method is AuthMethod.GROWW_ACCESS_TOKEN
    assert (pasted.status, pasted.missing_credentials) == (AccountStatus.AUTH_REQUIRED, ())

    simulator = await accounts.create(Provider.SIMULATOR, "Sim", actor=ACTOR)
    assert (simulator.auth_method, simulator.status) == (AuthMethod.NONE, AccountStatus.AUTHENTICATED)

    [entry] = await audit_entries(container.db, kite.id)
    assert (entry.action, entry.actor, entry.details) == (
        "provider_account.create",
        ACTOR,
        {"provider": "ZERODHA", "label": "Main account", "method": "ZERODHA_LOGIN_REDIRECT"},
    )


@pytest.mark.parametrize(
    ("env", "allowed"),
    [
        (AppEnv.DEVELOPMENT, True),
        (AppEnv.REPLAY, True),
        (AppEnv.LIVE_DATA, False),
        (AppEnv.PRODUCTION, False),
    ],
)
@pytest.mark.usefixtures("accounts")
async def test_simulator_accounts_need_a_development_or_replay_environment(
    container: Container, clock: FakeClock, env: AppEnv, allowed: bool
) -> None:
    service = account_service(container, clock, app_env=env)
    if allowed:
        assert (await service.create(Provider.SIMULATOR, "Sim", actor=ACTOR)).provider is Provider.SIMULATOR
    else:
        call = service.create(Provider.SIMULATOR, "Sim", actor=ACTOR)
        await failure(call, ValidationFailedError, "simulator_not_allowed")
        assert await service.list_accounts() == []


@pytest.mark.parametrize("label", ["", "   ", "-main", "main/alt", "x" * 81, "émile"])
async def test_create_rejects_invalid_labels(accounts: ProviderAccountService, label: str) -> None:
    await failure(accounts.create(Provider.GROWW, label, actor=ACTOR), ValidationFailedError, "invalid_label")


async def test_create_rejects_a_method_of_another_provider(accounts: ProviderAccountService) -> None:
    call = accounts.create(Provider.ZERODHA, "Main", auth_method=AuthMethod.GROWW_TOTP, actor=ACTOR)
    await failure(call, ValidationFailedError, "auth_method_not_supported")


async def test_labels_are_unique_per_provider_ignoring_case(accounts: ProviderAccountService) -> None:
    await zerodha(accounts, keys=False)
    call = accounts.create(Provider.ZERODHA, "MAIN", actor=ACTOR)
    await failure(call, ConflictError, "provider_account_label_taken")
    assert (await groww(accounts, "main")).label == "main"


async def test_resolve_ref_by_id_or_label(accounts: ProviderAccountService) -> None:
    kite = await zerodha(accounts, keys=False)  # "Main"
    pasted = await groww(accounts, "main")

    assert (await accounts.resolve_ref(str(kite.id))).id == kite.id
    assert (await accounts.resolve_ref("  Main ")).id == kite.id  # an exact label wins
    assert (await accounts.resolve_ref("main")).id == pasted.id
    assert (await accounts.resolve_ref("MAIN", provider=Provider.GROWW)).id == pasted.id
    await failure(accounts.resolve_ref("MAIN"), ConflictError, "provider_account_ambiguous")
    not_found = "provider_account_not_found"
    await failure(accounts.resolve_ref(str(kite.id), provider=Provider.GROWW), NotFoundError, not_found)
    await failure(accounts.resolve_ref("Other"), NotFoundError, not_found)
    await failure(accounts.get(uuid4()), NotFoundError, not_found)


async def test_list_accounts_orders_by_provider_then_label(accounts: ProviderAccountService) -> None:
    await zerodha(accounts, "beta")
    await zerodha(accounts, "Alpha", keys=False)
    await groww(accounts, "Gamma")

    listed = await accounts.list_accounts()
    assert [(view.provider, view.label) for view in listed] == [
        (Provider.GROWW, "Gamma"),
        (Provider.ZERODHA, "Alpha"),
        (Provider.ZERODHA, "beta"),
    ]
    assert [view.missing_credentials for view in listed] == [(), (API_KEY, API_SECRET), ()]
    assert [view.label for view in await accounts.list_accounts(Provider.ZERODHA)] == ["Alpha", "beta"]


# ---- update, enable, delete ---------------------------------------------------------------------------


async def test_update_renames_and_switches_the_auth_method(
    accounts: ProviderAccountService, container: Container, clock: FakeClock
) -> None:
    account = await groww(accounts)
    other = await groww(accounts, "Other")
    clock.advance(timedelta(minutes=5))

    switched = await accounts.update(
        account.id, auth_method=AuthMethod.GROWW_API_KEY_SECRET, actor="user:bob"
    )
    assert (switched.status, switched.missing_credentials) == (
        AccountStatus.NEEDS_CREDENTIALS,
        (API_KEY, API_SECRET),
    )
    assert (switched.updated_by, switched.updated_at) == ("user:bob", clock.now)
    assert (await accounts.update(account.id, label="MAIN", actor=ACTOR)).label == "MAIN"  # case only

    await failure(
        accounts.update(other.id, label="main", actor=ACTOR), ConflictError, "provider_account_label_taken"
    )
    call = accounts.update(account.id, auth_method=AuthMethod.ZERODHA_LOGIN_REDIRECT, actor=ACTOR)
    await failure(call, ValidationFailedError, "auth_method_not_supported")
    await failure(
        accounts.update(account.id, label="a/b", actor=ACTOR), ValidationFailedError, "invalid_label"
    )
    await failure(
        accounts.update(uuid4(), label="New", actor=ACTOR), NotFoundError, "provider_account_not_found"
    )
    await accounts.update(account.id, label="MAIN", auth_method=AuthMethod.GROWW_API_KEY_SECRET, actor=ACTOR)

    entries = await audit_entries(container.db, account.id)
    assert [(entry.action, entry.details) for entry in entries[1:]] == [
        ("provider_account.update", {"method": {"from": "GROWW_ACCESS_TOKEN", "to": "GROWW_API_KEY_SECRET"}}),
        ("provider_account.update", {"label": {"from": "Main", "to": "MAIN"}}),
    ]


async def test_update_keeps_a_stored_token(accounts: ProviderAccountService) -> None:
    account = await groww(accounts)
    await store_token(accounts, account.id, "groww-token", expires_at=LATER)

    updated = await accounts.update(account.id, auth_method=AuthMethod.GROWW_TOTP, actor=ACTOR)

    assert (updated.status, updated.has_access_token) == (AccountStatus.AUTHENTICATED, True)
    assert updated.missing_credentials == (API_KEY,)


async def test_one_enabled_account_per_provider(
    accounts: ProviderAccountService, container: Container
) -> None:
    one = await zerodha(accounts, "One")
    two = await zerodha(accounts, "Two")
    pasted = await groww(accounts)

    assert (await accounts.set_enabled(one.id, True, actor=ACTOR)).is_enabled
    error = await failure(
        accounts.set_enabled(two.id, True, actor=ACTOR), ConflictError, "provider_account_already_enabled"
    )
    assert "disable 'One' first" in error.message
    await accounts.set_enabled(pasted.id, True, actor=ACTOR)
    await accounts.set_enabled(one.id, True, actor=ACTOR)  # unchanged: no command, no audit entry
    assert not (await accounts.set_enabled(one.id, False, actor=ACTOR)).is_enabled
    assert (await accounts.set_enabled(two.id, True, actor=ACTOR)).is_enabled
    await failure(
        accounts.set_enabled(uuid4(), True, actor=ACTOR), NotFoundError, "provider_account_not_found"
    )

    commands = await worker_commands(container.bus)
    assert [(command.type, command.provider, command.account_id) for command in commands] == [
        (CommandType.CONNECT_ACCOUNT, Provider.ZERODHA, one.id),
        (CommandType.CONNECT_ACCOUNT, Provider.GROWW, pasted.id),
        (CommandType.DISCONNECT_ACCOUNT, Provider.ZERODHA, one.id),
        (CommandType.CONNECT_ACCOUNT, Provider.ZERODHA, two.id),
    ]
    assert {command.issued_by for command in commands} == {ACTOR}
    assert (await actions(container, one.id))[-2:] == ["provider_account.enable", "provider_account.disable"]


async def test_the_database_also_allows_one_enabled_account_per_provider(
    accounts: ProviderAccountService, container: Container
) -> None:
    one = await zerodha(accounts, "One", keys=False)
    two = await zerodha(accounts, "Two", keys=False)
    await accounts.set_enabled(one.id, True, actor=ACTOR)

    with pytest.raises(IntegrityError):
        async with container.db.transaction() as session:
            await session.execute(
                sa.update(ProviderAccountRow).where(ProviderAccountRow.id == two.id).values(is_enabled=True)
            )


async def test_changes_succeed_when_the_worker_command_cannot_be_published(
    accounts: ProviderAccountService, container: Container, monkeypatch: pytest.MonkeyPatch
) -> None:
    account = await zerodha(accounts)

    async def unreachable(*_args: object, **_kwargs: object) -> str:
        raise RedisError("connection refused")

    monkeypatch.setattr(container.bus, "publish", unreachable)
    assert (await accounts.set_enabled(account.id, True, actor=ACTOR)).is_enabled
    assert (await accounts.get(account.id)).is_enabled


async def test_delete_removes_credentials_and_tokens_and_unlinks_history(
    accounts: ProviderAccountService, container: Container
) -> None:
    account = await zerodha(accounts)
    await accounts.set_enabled(account.id, True, actor=ACTOR)
    await store_token(accounts, account.id, "kite-token", expires_at=LATER)
    await accounts.record_state_change(
        change(account.id, ConnectionState.CONNECTED, previous=ConnectionState.CONNECTING)
    )

    await accounts.delete(account.id, actor=ACTOR, client_ip="127.0.0.1")

    await failure(accounts.get(account.id), NotFoundError, "provider_account_not_found")
    assert await stored(container, account.id) == {}
    assert await token_metadata(container.db, account.id) == []
    assert [event.account_id for event in await connection_events(container)] == [None]
    commands = await worker_commands(container.bus)
    assert [(command.type, command.account_id) for command in commands] == [
        (CommandType.CONNECT_ACCOUNT, account.id),
        (CommandType.DISCONNECT_ACCOUNT, account.id),
    ]
    entry = (await audit_entries(container.db, account.id))[-1]
    assert (entry.action, entry.client_ip, entry.details["was_enabled"]) == (
        "provider_account.delete",
        "127.0.0.1",
        True,
    )
    await failure(accounts.delete(account.id, actor=ACTOR), NotFoundError, "provider_account_not_found")


# ---- credentials ----------------------------------------------------------------------------------


async def test_credentials_are_encrypted_and_bound_to_their_account_and_kind(
    accounts: ProviderAccountService, container: Container
) -> None:
    account = await zerodha(accounts, keys=False)
    other = await zerodha(accounts, "Other", keys=False)

    view = await accounts.set_credentials(
        account.id, {API_KEY: "  kiteapikey1234 ", API_SECRET: KITE_KEYS[API_SECRET]}, actor=ACTOR
    )

    assert (view.status, view.missing_credentials) == (AccountStatus.AUTH_REQUIRED, ())
    assert view.masked_api_key == "••••1234"
    assert view.credentials == (
        CredentialInfo(kind=API_KEY, label="API key", origin=ACCOUNT, masked="••••1234"),
        CredentialInfo(kind=API_SECRET, label="API secret", origin=ACCOUNT),
    )
    box = container.secret_box
    assert box is not None
    rows = await stored(container, account.id)
    for kind, plaintext in KITE_KEYS.items():
        assert plaintext not in rows[kind].ciphertext
        assert rows[kind].key_id == box.primary_key_id
        assert (
            box.decrypt(rows[kind].ciphertext, context=CredentialVault.context(account.id, kind)) == plaintext
        )
    with pytest.raises(EncryptionError):
        box.decrypt(rows[API_KEY].ciphertext, context=CredentialVault.context(other.id, API_KEY))
    with pytest.raises(EncryptionError):
        box.decrypt(rows[API_KEY].ciphertext, context=CredentialVault.context(account.id, API_SECRET))

    entry = (await audit_entries(container.db, account.id))[-1]
    assert (entry.action, entry.details) == (
        "provider_account.credentials_set",
        {"kinds": ["API_KEY", "API_SECRET"], "logged_out": False},
    )


async def test_set_credentials_rejects_bad_input_without_echoing_it(
    accounts: ProviderAccountService, container: Container
) -> None:
    kite = await zerodha(accounts, keys=False)
    totp = await groww(accounts, method=AuthMethod.GROWW_TOTP)
    simulator = await accounts.create(Provider.SIMULATOR, "Sim", actor=ACTOR)

    await failure(
        accounts.set_credentials(kite.id, {}, actor=ACTOR), ValidationFailedError, "credentials_missing"
    )
    for account_id, kind in [(kite.id, ACCESS_TOKEN), (kite.id, TOTP_SECRET), (simulator.id, API_KEY)]:
        call = accounts.set_credentials(account_id, {kind: TOTP_SEED}, actor=ACTOR)
        await failure(call, ValidationFailedError, "credential_kind_not_allowed")
    for kind, value, message in [
        (API_KEY, "totp api key", "The API key must be 1-4096 printable characters without spaces"),
        (API_SECRET, " \t ", "The API secret must be 1-4096 printable characters without spaces"),
        (TOTP_SECRET, "JBSW!Y3DP-EHPK", "The TOTP secret is not valid base32"),
        (TOTP_SECRET, "jbsw y3dp", "The TOTP secret is too short"),
    ]:
        call = accounts.set_credentials(totp.id, {kind: value}, actor=ACTOR)
        assert (await failure(call, ValidationFailedError, "invalid_credential")).message == message
    call = accounts.set_credentials(uuid4(), {API_KEY: KITE_KEYS[API_KEY]}, actor=ACTOR)
    await failure(call, NotFoundError, "provider_account_not_found")

    assert await stored(container, kite.id) == {}
    assert await stored(container, totp.id) == {}
    assert await actions(container, totp.id) == ["provider_account.create"]


async def test_groww_totp_credentials_are_labelled_and_normalized(
    accounts: ProviderAccountService, container: Container
) -> None:
    account = await groww(accounts, method=AuthMethod.GROWW_TOTP)
    assert (account.status, account.missing_credentials) == (AccountStatus.NEEDS_CREDENTIALS, (API_KEY,))

    view = await accounts.set_credentials(
        account.id, {TOTP_SECRET: " jbsw-y3dp ehpk-3pxp ", API_KEY: "totp-token-abcd"}, actor=ACTOR
    )

    assert (view.status, view.missing_credentials) == (AccountStatus.AUTH_REQUIRED, ())
    assert view.credentials == (
        CredentialInfo(kind=API_KEY, label="TOTP token (API key)", origin=ACCOUNT, masked="••••abcd"),
        CredentialInfo(kind=TOTP_SECRET, label="TOTP secret", origin=ACCOUNT),
    )
    secrets = await accounts.resolve_secrets(account.id)
    assert (secrets.get(API_KEY), secrets.get(TOTP_SECRET)) == ("totp-token-abcd", TOTP_SEED)
    entry = (await audit_entries(container.db, account.id))[-1]
    assert entry.details == {"kinds": ["API_KEY", "TOTP_SECRET"], "logged_out": False}


@pytest.mark.usefixtures("accounts")
async def test_deployment_settings_fill_in_credentials_the_account_does_not_store(
    container: Container, clock: FakeClock
) -> None:
    service = account_service(
        container,
        clock,
        zerodha_api_key=SecretStr("envapikey9876"),
        zerodha_api_secret=SecretStr("envsecret5432"),
        groww_api_key=SecretStr("growwenvkey1111"),
    )
    kite = await service.create(Provider.ZERODHA, "Main", actor=ACTOR)
    assert (kite.status, kite.missing_credentials, kite.masked_api_key) == (
        AccountStatus.AUTH_REQUIRED,
        (),
        "••••9876",
    )
    assert kite.credentials == (
        CredentialInfo(kind=API_KEY, label="API key", origin=ENVIRONMENT, masked="••••9876"),
        CredentialInfo(kind=API_SECRET, label="API secret", origin=ENVIRONMENT),
    )
    secrets = await service.resolve_secrets(kite.id)
    assert {kind: (item.value, item.origin) for kind, item in secrets.values.items()} == {
        API_KEY: ("envapikey9876", ENVIRONMENT),
        API_SECRET: ("envsecret5432", ENVIRONMENT),
    }

    view = await service.set_credentials(kite.id, {API_KEY: KITE_KEYS[API_KEY]}, actor=ACTOR)
    assert [(info.kind, info.origin, info.masked) for info in view.credentials] == [
        (API_KEY, ACCOUNT, "••••1234"),
        (API_SECRET, ENVIRONMENT, None),
    ]
    secrets = await service.resolve_secrets(kite.id)
    assert (secrets.get(API_KEY), secrets.get(API_SECRET)) == (KITE_KEYS[API_KEY], "envsecret5432")

    # Deployment keys apply only to the auth method that uses them.
    approval = await groww(service, "Approval", AuthMethod.GROWW_API_KEY_SECRET)
    assert approval.missing_credentials == (API_SECRET,)
    assert (await groww(service, "Totp", AuthMethod.GROWW_TOTP)).missing_credentials == (API_KEY,)


async def test_a_new_zerodha_api_key_logs_the_account_out(
    accounts: ProviderAccountService, container: Container
) -> None:
    account = await zerodha(accounts)
    await accounts.set_enabled(account.id, True, actor=ACTOR)
    await store_token(accounts, account.id, "kite-access-token", expires_at=LATER, user_ref="AB1234")

    await accounts.set_credentials(account.id, {API_SECRET: "newsecret9999"}, actor=ACTOR)
    kept = await accounts.set_credentials(account.id, {API_KEY: f" {KITE_KEYS[API_KEY]}"}, actor=ACTOR)
    assert (kept.status, kept.has_access_token) == (AccountStatus.AUTHENTICATED, True)

    view = await accounts.set_credentials(account.id, {API_KEY: "otherapikey777"}, actor=ACTOR)

    assert (view.status, view.has_access_token, view.token_expires_at) == (
        AccountStatus.AUTH_REQUIRED,
        False,
        None,
    )
    assert view.masked_api_key == "••••y777"
    [metadata] = await token_metadata(container.db, account.id)
    assert (metadata.revoked_at, metadata.revoked_by, metadata.revoke_reason) == (
        NOW,
        ACTOR,
        "API key changed",
    )
    entries = (await audit_entries(container.db, account.id))[-3:]
    assert [entry.details["logged_out"] for entry in entries] == [False, False, True]
    commands = await worker_commands(container.bus)
    assert [command.type for command in commands] == [
        CommandType.CONNECT_ACCOUNT,
        CommandType.DISCONNECT_ACCOUNT,
    ]
    error = await failure(
        accounts.session_credentials(account.id), ProviderAuthRequiredError, "provider_auth_required"
    )
    assert error.message == "Account 'Main' has no valid access token; log in again"


async def test_clear_credentials_keeps_the_token_until_the_api_key_goes(
    accounts: ProviderAccountService, container: Container
) -> None:
    account = await zerodha(accounts)
    await accounts.set_enabled(account.id, True, actor=ACTOR)
    await store_token(accounts, account.id, "kite-access-token", expires_at=LATER)

    view = await accounts.clear_credentials(account.id, [API_SECRET], actor=ACTOR)
    assert (view.status, view.has_access_token, view.missing_credentials) == (
        AccountStatus.AUTHENTICATED,
        True,
        (API_SECRET,),
    )
    before = await actions(container, account.id)
    assert (
        await accounts.clear_credentials(account.id, [API_SECRET], actor=ACTOR) == view
    )  # nothing to remove
    assert await actions(container, account.id) == before

    cleared = await accounts.clear_credentials(account.id, actor=ACTOR)

    assert (cleared.status, cleared.has_access_token, cleared.masked_api_key, cleared.credentials) == (
        AccountStatus.NEEDS_CREDENTIALS,
        False,
        None,
        (),
    )
    assert [row.revoke_reason for row in await token_metadata(container.db, account.id)] == [
        "API key removed"
    ]
    entries = (await audit_entries(container.db, account.id))[-2:]
    assert [(entry.action, entry.details) for entry in entries] == [
        ("provider_account.credentials_cleared", {"kinds": ["API_SECRET"], "logged_out": False}),
        ("provider_account.credentials_cleared", {"kinds": ["API_KEY"], "logged_out": True}),
    ]
    commands = await worker_commands(container.bus)
    assert [command.type for command in commands] == [
        CommandType.CONNECT_ACCOUNT,
        CommandType.DISCONNECT_ACCOUNT,
    ]
    for kinds in ([ACCESS_TOKEN], [TOTP_SECRET]):
        call = accounts.clear_credentials(account.id, kinds, actor=ACTOR)
        await failure(call, ValidationFailedError, "credential_kind_not_allowed")


@pytest.mark.usefixtures("accounts")
async def test_removing_a_stored_key_equal_to_the_deployment_key_keeps_the_token(
    container: Container, clock: FakeClock
) -> None:
    service = account_service(container, clock, zerodha_api_key=SecretStr(KITE_KEYS[API_KEY]))
    account = await zerodha(service)
    await store_token(service, account.id, "kite-access-token", expires_at=LATER)

    view = await service.clear_credentials(account.id, [API_KEY], actor=ACTOR)

    assert (view.status, view.has_access_token) == (AccountStatus.AUTHENTICATED, True)
    assert view.credentials[0] == CredentialInfo(
        kind=API_KEY, label="API key", origin=ENVIRONMENT, masked="••••1234"
    )
    assert (await audit_entries(container.db, account.id))[-1].details["logged_out"] is False


async def test_groww_tokens_do_not_depend_on_stored_credentials(accounts: ProviderAccountService) -> None:
    account = await groww(accounts, method=AuthMethod.GROWW_API_KEY_SECRET)
    keys = {API_KEY: "growwapikey1234", API_SECRET: "growwsecret5678"}
    await accounts.set_credentials(account.id, keys, actor=ACTOR)
    await store_token(accounts, account.id, "groww-access-token", expires_at=LATER)

    await accounts.set_credentials(account.id, {API_KEY: "growwapikey9999"}, actor=ACTOR)
    view = await accounts.clear_credentials(account.id, actor=ACTOR)

    assert (view.status, view.has_access_token, view.missing_credentials) == (
        AccountStatus.AUTHENTICATED,
        True,
        (API_KEY, API_SECRET),
    )


# ---- token expiry and decrypted access ------------------------------------------------------------


async def test_expire_tokens_moves_expired_accounts_to_a_login_status(
    accounts: ProviderAccountService, container: Container, clock: FakeClock
) -> None:
    hour = timedelta(hours=1)
    kite = await zerodha(accounts)
    approval = await groww(accounts, "Approval", AuthMethod.GROWW_API_KEY_SECRET)  # no credentials
    pasted = await groww(accounts, "Pasted")
    await accounts.create(Provider.SIMULATOR, "Sim", actor=ACTOR)
    await store_token(accounts, kite.id, "kite-access-token", expires_at=NOW + hour)
    await store_token(accounts, approval.id, "groww-approval-token", expires_at=NOW + hour)
    await store_token(accounts, pasted.id, "groww-pasted-token", expires_at=NOW + 2 * hour)

    assert await accounts.expire_tokens() == []
    clock.advance(hour)
    assert await accounts.expire_tokens() == sorted([kite.id, approval.id])
    assert await accounts.expire_tokens() == []

    expired = await accounts.get(kite.id)
    assert (expired.status, expired.has_access_token, expired.token_expires_at) == (
        AccountStatus.AUTH_REQUIRED,
        False,
        NOW + hour,
    )
    assert (expired.last_error_code, expired.last_error_message) == (
        "token_expired",
        "The access token expired; log in again",
    )
    unconfigured = await accounts.get(approval.id)
    assert (unconfigured.status, unconfigured.last_error_message) == (
        AccountStatus.NEEDS_CREDENTIALS,
        "The access token expired; create a new access token",
    )
    assert (await accounts.get(pasted.id)).status is AccountStatus.AUTHENTICATED
    entry = (await audit_entries(container.db, kite.id))[-1]
    assert (entry.action, entry.actor, entry.details) == (
        "provider_account.token_expired",
        SYSTEM_ACTOR,
        {"provider": "ZERODHA", "label": "Main", "expires_at": (NOW + hour).isoformat()},
    )

    # Views correct a status the sweep has not caught up with yet.
    clock.advance(hour)
    assert (await accounts.get(pasted.id)).status is AccountStatus.AUTH_REQUIRED
    assert await accounts.expire_tokens() == [pasted.id]
    assert (
        await accounts.get(pasted.id)
    ).last_error_message == "The access token expired; set a new access token"


async def test_session_credentials_decrypt_the_token_for_the_worker(accounts: ProviderAccountService) -> None:
    kite = await zerodha(accounts)
    pasted = await groww(accounts)
    for account in (kite, pasted):
        await accounts.set_enabled(account.id, True, actor=ACTOR)
    await store_token(accounts, kite.id, "kite-access-token", expires_at=LATER, user_ref="AB1234")
    await store_token(accounts, pasted.id, "groww-access-token", expires_at=LATER)

    assert await accounts.credential_source(kite.id)() == SessionCredentials(
        access_token="kite-access-token", api_key=KITE_KEYS[API_KEY], expires_at=LATER, user_ref="AB1234"
    )
    assert await accounts.session_credentials(pasted.id) == SessionCredentials(
        access_token="groww-access-token", expires_at=LATER
    )


async def test_session_credentials_need_an_enabled_account_with_a_valid_token(
    accounts: ProviderAccountService, clock: FakeClock
) -> None:
    account = await zerodha(accounts)
    simulator = await accounts.create(Provider.SIMULATOR, "Sim", actor=ACTOR)
    await accounts.set_enabled(simulator.id, True, actor=ACTOR)
    auth_required = "provider_auth_required"

    await failure(accounts.session_credentials(account.id), ProviderNotEnabledError, "provider_not_enabled")
    await accounts.set_enabled(account.id, True, actor=ACTOR)
    error = await failure(accounts.session_credentials(account.id), ProviderAuthRequiredError, auth_required)
    assert error.message == "Account 'Main' has no valid access token; log in again"
    await store_token(accounts, account.id, "kite-access-token", expires_at=NOW + timedelta(hours=1))
    assert (await accounts.session_credentials(account.id)).access_token == "kite-access-token"
    clock.advance(timedelta(hours=1))
    await failure(accounts.session_credentials(account.id), ProviderAuthRequiredError, auth_required)
    call = accounts.session_credentials(simulator.id)
    await failure(call, ValidationFailedError, "credentials_not_applicable")
    await failure(accounts.session_credentials(uuid4()), NotFoundError, "provider_account_not_found")


async def test_session_credentials_report_values_the_keys_cannot_open(
    accounts: ProviderAccountService, container: Container, clock: FakeClock
) -> None:
    account = await zerodha(accounts)
    await accounts.set_enabled(account.id, True, actor=ACTOR)
    await store_token(accounts, account.id, "kite-access-token", expires_at=LATER)
    auth_required = "provider_auth_required"

    stranger = account_service(container, clock, secret_box=SecretBox(os.urandom(32)))
    error = await failure(stranger.session_credentials(account.id), ProviderAuthRequiredError, auth_required)
    assert error.message == (
        "The stored access token of 'Main' cannot be decrypted with the configured encryption keys; "
        "log in again"
    )
    call = keyless(container, clock).session_credentials(account.id)
    await failure(call, ServiceUnavailableError, "encryption_not_configured")

    async with container.db.transaction() as session:
        await session.execute(
            sa.delete(ProviderCredentialRow).where(
                ProviderCredentialRow.account_id == account.id, ProviderCredentialRow.kind == API_KEY
            )
        )
    error = await failure(accounts.session_credentials(account.id), ProviderAuthRequiredError, auth_required)
    assert error.message == "Account 'Main' has no usable API key; set it and log in again"


async def test_resolve_secrets_tells_missing_from_unreadable_values(
    accounts: ProviderAccountService, container: Container, clock: FakeClock
) -> None:
    account = await groww(accounts, method=AuthMethod.GROWW_API_KEY_SECRET)
    keys = {API_KEY: "growwapikey1234", API_SECRET: "growwsecret5678"}
    await accounts.set_credentials(account.id, keys, actor=ACTOR)
    await store_token(accounts, account.id, "groww-access-token", expires_at=LATER)

    secrets = await accounts.resolve_secrets(account.id)
    assert (secrets.require(API_KEY), secrets.require(API_SECRET), secrets.get(ACCESS_TOKEN)) == (
        keys[API_KEY],
        keys[API_SECRET],
        None,
    )
    with_token = await accounts.resolve_secrets(account.id, include_token=True)
    assert with_token.get(ACCESS_TOKEN) == "groww-access-token"
    with pytest.raises(ValidationFailedError) as missing:
        secrets.require(TOTP_SECRET)
    assert (missing.value.code, missing.value.message) == (
        "credentials_missing",
        "Account 'Main' has no TOTP secret; add it first",
    )

    stranger = account_service(container, clock, secret_box=SecretBox(os.urandom(32)))
    unreadable = await stranger.resolve_secrets(account.id, include_token=True)
    assert dict(unreadable.values) == {}
    assert unreadable.unreadable == frozenset({API_KEY, API_SECRET, ACCESS_TOKEN})
    with pytest.raises(ConflictError) as conflict:
        unreadable.require(API_KEY)
    assert conflict.value.code == "credential_unreadable"
    assert "cannot be decrypted" in conflict.value.message
    call = keyless(container, clock).resolve_secrets(account.id)
    await failure(call, ServiceUnavailableError, "encryption_not_configured")
    await failure(accounts.resolve_secrets(uuid4()), NotFoundError, "provider_account_not_found")


# ---- connection history -----------------------------------------------------------------------------


async def test_stream_state_changes_become_connection_history(
    accounts: ProviderAccountService, container: Container
) -> None:
    account = await zerodha(accounts)
    await store_token(accounts, account.id, "kite-access-token", expires_at=LATER)
    observer = AccountConnectionObserver(accounts)
    second = timedelta(seconds=1)
    idle, connecting, connected = ConnectionState.IDLE, ConnectionState.CONNECTING, ConnectionState.CONNECTED
    reconnecting, stopped = ConnectionState.RECONNECTING, ConnectionState.STOPPED

    await observer.on_state_change(change(account.id, connecting, previous=idle, at=second))
    await observer.on_state_change(change(account.id, connected, previous=connecting, at=2 * second))
    await observer.on_state_change(
        change(account.id, reconnecting, previous=connected, reason="socket closed", at=3 * second)
    )
    await accounts.record_state_change(change(uuid4(), stopped, previous=reconnecting, at=4 * second))
    await accounts.record_state_change(change(None, stopped, at=5 * second, provider=Provider.GROWW))

    events = await connection_events(container)
    assert [(event.account_id, event.previous_state, event.state, event.reason) for event in events] == [
        (account.id, idle, connecting, ""),
        (account.id, connecting, connected, ""),
        (account.id, connected, reconnecting, "socket closed"),
        (None, reconnecting, stopped, ""),
        (None, None, stopped, ""),
    ]
    assert [event.stream_id for event in events[-2:]] == ["zerodha:main", "groww:main"]
    assert {event.actor for event in events} == {SYSTEM_ACTOR}
    view = await accounts.get(account.id)
    assert (view.status, view.last_connected_at, view.last_disconnected_at, view.last_error_code) == (
        AccountStatus.AUTHENTICATED,
        NOW + 2 * second,
        NOW + 3 * second,
        None,
    )


async def test_a_rejected_token_needs_login_until_a_reconnect_succeeds(
    accounts: ProviderAccountService, container: Container, clock: FakeClock
) -> None:
    account = await zerodha(accounts)
    await store_token(accounts, account.id, "kite-access-token", expires_at=LATER)
    clock.advance(timedelta(minutes=10))
    rejected = change(
        account.id,
        ConnectionState.AUTH_REQUIRED,
        previous=ConnectionState.CONNECTED,
        reason="Kite rejected the session",
        at=timedelta(minutes=5),
    )

    await accounts.record_state_change(rejected)

    view = await accounts.get(account.id)
    assert (view.status, view.has_access_token, view.last_error_code, view.last_error_message) == (
        AccountStatus.AUTH_REQUIRED,
        True,
        "auth_required",
        "Kite rejected the session",
    )
    assert (view.last_disconnected_at, view.updated_at) == (NOW + timedelta(minutes=5), clock.now)
    entry = (await audit_entries(container.db, account.id))[-1]
    assert (entry.action, entry.actor, entry.details) == (
        "provider_account.auth_lost",
        SYSTEM_ACTOR,
        {"provider": "ZERODHA", "label": "Main", "reason": "Kite rejected the session"},
    )

    await accounts.record_state_change(rejected)  # already AUTH_REQUIRED: no second audit entry
    connected = change(
        account.id, ConnectionState.CONNECTED, previous=ConnectionState.CONNECTING, at=timedelta(minutes=6)
    )
    await accounts.record_state_change(connected)

    healed = await accounts.get(account.id)
    assert (healed.status, healed.last_error_code, healed.last_error_message) == (
        AccountStatus.AUTHENTICATED,
        None,
        None,
    )
    assert (await actions(container, account.id)).count("provider_account.auth_lost") == 1


async def test_a_rejection_older_than_the_latest_login_is_ignored(
    accounts: ProviderAccountService, container: Container
) -> None:
    account = await zerodha(accounts)
    await store_token(accounts, account.id, "kite-access-token", expires_at=LATER)  # logged in at NOW

    await accounts.record_state_change(
        change(account.id, ConnectionState.AUTH_REQUIRED, reason="old token", at=-timedelta(minutes=1))
    )

    view = await accounts.get(account.id)
    assert (view.status, view.last_error_code) == (AccountStatus.AUTHENTICATED, None)
    assert "provider_account.auth_lost" not in await actions(container, account.id)
    assert len(await connection_events(container)) == 1


async def test_a_rejection_after_the_token_expired_forgets_the_token(
    accounts: ProviderAccountService, container: Container, clock: FakeClock
) -> None:
    account = await zerodha(accounts)
    await store_token(accounts, account.id, "kite-access-token", expires_at=NOW + timedelta(hours=1))
    clock.advance(timedelta(hours=2))

    await accounts.record_state_change(
        change(account.id, ConnectionState.AUTH_REQUIRED, reason="session expired", at=timedelta(hours=2))
    )

    view = await accounts.get(account.id)
    assert (view.status, view.has_access_token, view.last_error_code) == (
        AccountStatus.AUTH_REQUIRED,
        False,
        "token_expired",
    )
    assert (await actions(container, account.id))[-1] == "provider_account.token_expired"


async def test_a_rejection_without_a_token_only_records_the_error(
    accounts: ProviderAccountService, container: Container
) -> None:
    account = await zerodha(accounts)
    simulator = await accounts.create(Provider.SIMULATOR, "Sim", actor=ACTOR)

    await accounts.record_state_change(change(account.id, ConnectionState.AUTH_REQUIRED, reason="no session"))
    await accounts.record_state_change(
        change(simulator.id, ConnectionState.AUTH_REQUIRED, reason="ignored", provider=Provider.SIMULATOR)
    )

    view = await accounts.get(account.id)
    assert (view.status, view.last_error_code, view.last_error_message) == (
        AccountStatus.AUTH_REQUIRED,
        "auth_required",
        "no session",
    )
    sim = await accounts.get(simulator.id)
    assert (sim.status, sim.last_error_code) == (AccountStatus.AUTHENTICATED, None)
    assert "provider_account.auth_lost" not in await actions(container, account.id)


# ---- encryption keys ----------------------------------------------------------------------------------


@pytest.mark.usefixtures("accounts")
async def test_rotate_encryption_re_encrypts_with_the_primary_key(
    container: Container, clock: FakeClock
) -> None:
    old_key, new_key = os.urandom(32), os.urandom(32)
    old = account_service(container, clock, secret_box=SecretBox(old_key))
    kite = await zerodha(old)
    await store_token(old, kite.id, "kite-access-token", expires_at=LATER)
    stranger = account_service(container, clock, secret_box=SecretBox(os.urandom(32)))
    lost = await groww(stranger, "Lost", AuthMethod.GROWW_TOTP)
    await stranger.set_credentials(lost.id, {API_KEY: "lostapikey1234"}, actor=ACTOR)
    rotating = account_service(container, clock, secret_box=SecretBox(new_key, [old_key]))
    fresh = await groww(rotating, "Fresh", AuthMethod.GROWW_TOTP)
    await rotating.set_credentials(fresh.id, {API_KEY: "freshapikey123"}, actor=ACTOR)

    report = await rotating.rotate_encryption(actor=ACTOR)

    new_key_id = SecretBox(new_key).primary_key_id
    assert (report.primary_key_id, report.examined, report.rotated, report.failed) == (
        new_key_id,
        5,
        3,
        ("GROWW/Lost:API_KEY",),
    )
    assert {row.key_id for row in (await stored(container, kite.id)).values()} == {new_key_id}
    new_only = account_service(container, clock, secret_box=SecretBox(new_key))
    secrets = await new_only.resolve_secrets(kite.id, include_token=True)
    assert [secrets.get(kind) for kind in (API_KEY, API_SECRET, ACCESS_TOKEN)] == [
        KITE_KEYS[API_KEY],
        KITE_KEYS[API_SECRET],
        "kite-access-token",
    ]

    again = await rotating.rotate_encryption(actor=ACTOR)

    assert (again.examined, again.rotated, again.failed) == (5, 0, ("GROWW/Lost:API_KEY",))
    async with container.db.session() as session:
        entry = await session.scalar(
            select(AuditLogRow)
            .where(AuditLogRow.action == "provider_credentials.rotate")
            .order_by(AuditLogRow.id.desc())
            .limit(1)
        )
    assert entry is not None
    assert (entry.entity_type, entry.actor, entry.details) == (
        "provider_credentials",
        ACTOR,
        {"primary_key_id": new_key_id, "examined": 5, "rotated": 0, "failed": ["GROWW/Lost:API_KEY"]},
    )


@pytest.mark.usefixtures("accounts")
async def test_accounts_work_without_an_encryption_key_until_a_value_must_be_stored(
    container: Container, clock: FakeClock
) -> None:
    service = keyless(
        container,
        clock,
        zerodha_api_key=SecretStr("envapikey9876"),
        zerodha_api_secret=SecretStr("envsecret5432"),
    )
    account = await service.create(Provider.ZERODHA, "Main", actor=ACTOR)

    assert [view.id for view in await service.list_accounts()] == [account.id]
    secrets = await service.resolve_secrets(account.id)
    assert (secrets.get(API_KEY), secrets.get(API_SECRET)) == ("envapikey9876", "envsecret5432")
    unavailable = "encryption_not_configured"
    await failure(
        service.set_credentials(account.id, KITE_KEYS, actor=ACTOR), ServiceUnavailableError, unavailable
    )
    await failure(service.rotate_encryption(actor=ACTOR), ServiceUnavailableError, unavailable)
