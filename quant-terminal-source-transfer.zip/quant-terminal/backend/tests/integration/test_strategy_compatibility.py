"""How each strategy suits an instrument as its workspace streams it, on PostgreSQL: the strategy panel's
checks with the stored warm-up candles, and the same feed checks applied to saved scopes and to what the
strategy worker runs."""

from __future__ import annotations

from collections.abc import AsyncIterator
from datetime import datetime, timedelta
from typing import Any
from uuid import UUID

import pytest
import sqlalchemy as sa

from app.container import Container
from app.core.errors import NotFoundError, ValidationFailedError
from app.domain.enums import (
    CandleInterval,
    CheckStatus,
    CompatibilityAspect,
    DataStatus,
    EventType,
    Exchange,
    InstrumentType,
    MarketRegion,
    Provider,
    Segment,
    SignalType,
    SubscriptionMode,
)
from app.domain.models.strategy import SignalCondition, StrategyMetadata
from app.market_data.candles.store import candle_values, upsert_candles
from app.persistence.models import InstrumentRow
from app.services.strategies import Scope, StrategyService
from app.services.strategy_compatibility import StrategyCompatibility
from app.strategies.base import Strategy, StrategyConfig
from app.strategies.examples.ema_crossover import EmaCrossover
from app.strategies.registry import StrategyRegistry
from tests.candle_support import bar
from tests.integration.provider_support import ACTOR, LAB, NOW, FakeClock, add_rows
from tests.integration.strategy_support import EXAMPLE, wipe_strategies

pytestmark = pytest.mark.integration

SIM = Provider.SIMULATOR
MINUTE = timedelta(minutes=1)
DEPTH_WATCHER = "tests.depth_watcher"
NO_DEPTH = (
    "it needs market depth, which it does not get from the SIMULATOR feed in QUOTE mode: "
    "subscribe the instrument in FULL mode for market depth"
)
SIMULATED = "the data is simulated, so its signals are informational only"
PASSED, WARNING, FAILED = CheckStatus.PASSED, CheckStatus.WARNING, CheckStatus.FAILED


class DepthWatcher(Strategy[StrategyConfig]):
    """Runs on quotes and reads the best bid, which streams with market depth."""

    metadata = StrategyMetadata(
        strategy_id=DEPTH_WATCHER,
        name="Depth watcher",
        description="Reads the best bid from quotes.",
        version="1.0.0",
        author="tests",
        markets=(MarketRegion.LAB,),
        segments=(Segment.CASH,),
        instrument_types=(InstrumentType.EQUITY,),
        event_types=(EventType.QUOTE,),
        signal_conditions=(
            SignalCondition(signal_type=SignalType.BUY, description="The bid rises.", inputs=("bid",)),
        ),
    )
    config_model = StrategyConfig


@pytest.fixture
async def strategies(container: Container, clock: FakeClock) -> AsyncIterator[StrategyService]:
    await wipe_strategies(container.db)
    registry = StrategyRegistry([EmaCrossover, DepthWatcher])
    try:
        yield StrategyService(container.db, container.bus, registry=registry, clock=clock)
    finally:
        await wipe_strategies(container.db)


@pytest.fixture
async def keys(container: Container, symbols: dict[str, UUID]) -> dict[str, str]:
    """ALPHA streams in FULL mode and BRAVO in QUOTE mode in the simulation lab; their canonical keys."""
    await add_rows(
        container,
        symbols,
        [
            (LAB, "ALPHA", SIM, SubscriptionMode.FULL, None),
            (LAB, "BRAVO", SIM, SubscriptionMode.QUOTE, None),
        ],
    )
    async with container.db.session() as session:
        rows = await session.execute(
            sa.select(InstrumentRow.symbol, InstrumentRow.canonical_key).where(
                InstrumentRow.id.in_(symbols.values())
            )
        )
        return dict(rows.all())


async def store_candles(
    container: Container, instrument_id: UUID, ends: list[datetime], *, provider: Provider = SIM
) -> None:
    candles = [
        bar(
            0,
            100,
            start=end - MINUTE,
            status=DataStatus.SIMULATED if provider is SIM else DataStatus.LIVE,
            instrument_id=instrument_id,
            provider=provider,
            exchange=Exchange.SIM,
        )
        for end in ends
    ]
    async with container.db.transaction() as session:
        await upsert_candles(session, [candle_values(candle) for candle in candles])


def checks(result: StrategyCompatibility) -> list[tuple[CompatibilityAspect, CheckStatus, str]]:
    return [(check.aspect, check.status, check.detail) for check in result.checks]


@pytest.mark.usefixtures("keys")
async def test_each_strategy_is_checked_against_the_instrument_with_its_stored_warmup(
    container: Container, symbols: dict[str, UUID], strategies: StrategyService
) -> None:
    alpha = symbols["ALPHA"]
    # 30 closed 1m candles by now count; a later one, and another provider's, do not.
    await store_candles(container, alpha, [NOW - k * MINUTE for k in range(30)] + [NOW + MINUTE])
    await store_candles(
        container, alpha, [NOW - k * MINUTE for k in range(40, 45)], provider=Provider.ZERODHA
    )

    shown = await strategies.compatibility(LAB, alpha, chart_interval=CandleInterval.M5)

    assert (shown.workspace_slug, shown.market_region, shown.instrument_id) == (LAB, MarketRegion.LAB, alpha)
    assert (shown.provider, shown.subscription_mode, shown.chart_interval) == (
        SIM,
        SubscriptionMode.FULL,
        CandleInterval.M5,
    )
    example, watcher = shown.strategies
    assert (example.strategy_id, example.compatible, watcher.strategy_id, watcher.compatible) == (
        EXAMPLE,
        True,
        DEPTH_WATCHER,
        True,
    )
    assert checks(example) == [
        (CompatibilityAspect.MARKET, PASSED, "it supports the LAB market"),
        (CompatibilityAspect.INSTRUMENT, PASSED, "it supports CASH EQUITY instruments on SIM"),
        (
            CompatibilityAspect.TIMEFRAME,
            WARNING,
            "it is evaluated on 1m candles, not the chart's 5m: its signals appear on the 5m candles "
            "containing them",
        ),
        (
            CompatibilityAspect.DATA,
            WARNING,
            f"the SIMULATOR feed in FULL mode sends the prices it needs; {SIMULATED}",
        ),
        (
            CompatibilityAspect.WARMUP,
            WARNING,
            "it will warm up from live candles: 30 of 63 1m candles are stored",
        ),
    ]
    assert [(item.interval, item.needed, item.stored) for item in example.warmup] == [
        (CandleInterval.M1, 63, 30)
    ]
    assert checks(watcher)[2:] == [
        (CompatibilityAspect.TIMEFRAME, PASSED, "it runs on QUOTE market events"),
        (
            CompatibilityAspect.DATA,
            WARNING,
            f"the SIMULATOR feed in FULL mode sends the market depth it needs; {SIMULATED}",
        ),
        (CompatibilityAspect.WARMUP, PASSED, "it needs no warm-up candles"),
    ]


async def test_a_feed_without_the_data_fails_the_check_the_scope_and_the_run(
    symbols: dict[str, UUID], keys: dict[str, str], strategies: StrategyService
) -> None:
    alpha, bravo = symbols["ALPHA"], symbols["BRAVO"]

    shown = await strategies.compatibility(LAB, bravo)
    watcher = next(item for item in shown.strategies if item.strategy_id == DEPTH_WATCHER)
    assert not watcher.compatible
    assert (CompatibilityAspect.DATA, FAILED, NO_DEPTH) in checks(watcher)

    async def save(scope: Scope, **options: Any) -> Any:
        return await strategies.create_configuration(LAB, DEPTH_WATCHER, scope=scope, actor=ACTOR, **options)

    with pytest.raises(ValidationFailedError) as refused:
        await save(Scope.instruments([alpha, bravo]))
    assert refused.value.code == "deployment_scope_rejected"
    assert refused.value.details["problems"] == [{"instrument": keys["BRAVO"], "reason": NO_DEPTH}]

    whole = await save(Scope.workspace())
    await strategies.set_enabled(whole.id, True, actor=ACTOR)
    (runnable,) = await strategies.runnable_deployments()
    assert [(instrument.id, provider) for instrument, provider in runnable.instruments] == [(alpha, SIM)]
    assert dict(runnable.excluded) == {keys["BRAVO"]: NO_DEPTH}


@pytest.mark.usefixtures("keys")
async def test_only_instruments_of_the_workspace_are_checked(
    symbols: dict[str, UUID], strategies: StrategyService
) -> None:
    with pytest.raises(NotFoundError) as missing:
        await strategies.compatibility(LAB, symbols["CHARLIE"])

    assert missing.value.code == "instrument_not_in_workspace"
