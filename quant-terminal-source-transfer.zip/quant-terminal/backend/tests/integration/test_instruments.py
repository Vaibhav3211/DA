"""Instrument master refreshes, search and subscription resolution on PostgreSQL.

Dumps are small synthetic CSVs. Downloads go to ``httpx.MockTransport`` handlers on reserved
``.test`` hosts, so nothing here can reach Zerodha or Groww.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Callable
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

import httpx
import pytest
from pydantic import SecretStr
from sqlalchemy import func, select

from app.container import Container
from app.core.errors import ConflictError, NotFoundError, ProviderError, ValidationFailedError
from app.domain.enums import (
    CredentialKind,
    Exchange,
    InstrumentType,
    OptionType,
    Provider,
    Segment,
    SubscriptionMode,
)
from app.domain.events import CommandType
from app.domain.models import ProviderInstrument
from app.market_data.instruments.sync import LOCK_NAME, SyncStats
from app.persistence.models import AuditLogRow, InstrumentProviderMappingRow, InstrumentRow
from app.services.instruments import (
    AUDIT_ACTION,
    AUDIT_ENTITY,
    SEARCH_LIMIT_MAX,
    DumpSource,
    InstrumentPage,
    InstrumentQuery,
    InstrumentService,
    RefreshReport,
)
from app.services.provider_accounts import ProviderAccountService
from tests.integration.provider_support import (
    ACTOR,
    NOW,
    FakeClock,
    FakeProvider,
    account_service,
    csv_reply,
    failure,
    kite_dump,
    kite_equity,
    store_token,
    wipe_instruments,
    worker_commands,
)

pytestmark = pytest.mark.integration

ZERODHA, GROWW, SIMULATOR = Provider.ZERODHA, Provider.GROWW, Provider.SIMULATOR
GROWW_DUMP_URL = "https://groww-assets.test/instruments/instrument.csv"
GROWW_DUMP_ROUTE = ("GET", "/instruments/instrument.csv")
KITE_DUMP_ROUTE = ("GET", "/instruments")
KITE_KEY = "kite-api-key"
KITE_SECRET = "kite-api-secret"
GROWW_HEADER = (
    "exchange,exchange_token,trading_symbol,groww_symbol,name,instrument_type,segment,series,isin,"
    "underlying_symbol,underlying_exchange_token,expiry_date,strike_price,lot_size,tick_size,"
    "freeze_quantity,is_reserved,buy_allowed,sell_allowed"
)


def groww_equity(token: int, symbol: str, name: str = "", *, isin: str = "", tick: str = "0.05") -> str:
    return f"NSE,{token},{symbol},NSE-{symbol},{name},EQ,CASH,EQ,{isin},,,,,1,{tick},,0,1,1"


def groww_dump(*rows: str) -> bytes:
    return ("\n".join([GROWW_HEADER, *rows]) + "\n").encode()


INFY = kite_equity(408065, "INFY", "INFOSYS", exchange_token=1594)
RELIANCE = kite_equity(738561, "RELIANCE", "RELIANCE INDUSTRIES", exchange_token=2885, tick="0.1")
TCS = kite_equity(2953217, "TCS", "TATA CONSULTANCY SERV LT", exchange_token=11536)
NIFTY_FUT = "9001218,35161,NIFTY26JANFUT,NIFTY,0,2026-01-27,0,0.1,75,FUT,NFO-FUT,NFO"
NIFTY_CE = "9002242,35165,NIFTY2610624000CE,NIFTY,0,2026-01-06,24000,0.05,75,CE,NFO-OPT,NFO"
EQUITIES = [kite_equity(500_000 + n, f"STOCK{n:02d}", exchange_token=n + 1) for n in range(12)]
GROWW_INFY = groww_equity(1594, "INFY", "Infosys Limited", isin="INE009A01021", tick="0.10")
INFY_KEY = "NSE:CASH:EQUITY:INFY"
RELIANCE_KEY = "NSE:CASH:EQUITY:RELIANCE"
FUT_KEY = "NSE:FNO:FUTURE:NIFTY:2026-01-27"
CE_KEY = "NSE:FNO:OPTION:NIFTY:2026-01-06:24000:CE"

type ServiceFactory = Callable[..., InstrumentService]


@pytest.fixture
def remote() -> FakeProvider:
    return FakeProvider()


@pytest.fixture
async def make_service(
    accounts: ProviderAccountService,  # wipes provider accounts before and after the test
    container: Container,
    clock: FakeClock,
    remote: FakeProvider,
    tmp_path: Path,
) -> AsyncIterator[ServiceFactory]:
    """Builds instrument services (settings overridable) on an empty instrument master."""

    def build(**overrides: Any) -> InstrumentService:
        settings = {
            "instrument_cache_dir": str(tmp_path / "cache"),
            "groww_instruments_url": GROWW_DUMP_URL,
            **overrides,
        }
        return InstrumentService(account_service(container, clock, **settings), transport=remote.transport)

    await wipe_instruments(container.db)
    try:
        yield build
    finally:
        await wipe_instruments(container.db)


@pytest.fixture
def service(make_service: ServiceFactory) -> InstrumentService:
    return make_service()


async def load(service: InstrumentService, provider: Provider, data: bytes, **options: Any) -> RefreshReport:
    """Refresh from an operator-supplied dump."""
    return await service.refresh(provider, actor=ACTOR, data=data, **options)


async def stored(
    service: InstrumentService, key: str
) -> tuple[InstrumentRow, list[InstrumentProviderMappingRow]]:
    """The rows behind an instrument, for the bookkeeping columns the domain models leave out."""
    m = InstrumentProviderMappingRow
    async with service.db.session() as session:
        row = await session.scalar(select(InstrumentRow).where(InstrumentRow.canonical_key == key))
        assert row is not None, key
        mappings = await session.scalars(
            select(m).where(m.instrument_id == row.id).order_by(m.valid_from, m.provider)
        )
        return row, list(mappings)


async def refresh_audits(service: InstrumentService) -> list[AuditLogRow]:
    async with service.db.session() as session:
        rows = await session.scalars(
            select(AuditLogRow).where(AuditLogRow.entity_type == AUDIT_ENTITY).order_by(AuditLogRow.id)
        )
        return list(rows)


async def kite_account(accounts: ProviderAccountService) -> UUID:
    """An enabled Zerodha account with an API key."""
    view = await accounts.create(ZERODHA, "Main", actor=ACTOR)
    credentials = {CredentialKind.API_KEY: KITE_KEY, CredentialKind.API_SECRET: KITE_SECRET}
    await accounts.set_credentials(view.id, credentials, actor=ACTOR)
    await accounts.set_enabled(view.id, True, actor=ACTOR)
    return view.id


# ---- applying dumps -----------------------------------------------------------------------------


async def test_a_first_import_creates_instruments_and_mappings(service: InstrumentService) -> None:
    report = await load(
        service,
        ZERODHA,
        kite_dump(INFY, RELIANCE, NIFTY_FUT, NIFTY_CE),
        file_name="kite.csv",
        client_ip="203.0.113.9",
    )

    assert (report.source, report.rows, report.accepted, report.skipped) == (DumpSource.FILE, 4, 4, {})
    assert report.stats == SyncStats(instruments_created=4, mappings_created=4)
    assert (report.account_id, report.cache_path, report.cache_error, report.forced) == (
        None,
        None,
        None,
        False,
    )
    assert report.published
    detail = await service.get(INFY_KEY)
    assert detail.instrument.model_dump(exclude={"id", "updated_at"}) == {
        "canonical_key": INFY_KEY,
        "exchange": Exchange.NSE,
        "segment": Segment.CASH,
        "instrument_type": InstrumentType.EQUITY,
        "symbol": "INFY",
        "name": "INFOSYS",
        "underlying": None,
        "expiry": None,
        "strike": None,
        "option_type": None,
        "lot_size": 1,
        "tick_size": Decimal("0.05"),
        "currency": "INR",
        "isin": None,
        "is_active": True,
    }
    [mapping] = detail.mappings
    assert (mapping.provider, mapping.provider_token, mapping.exchange_token, mapping.provider_symbol) == (
        ZERODHA,
        "408065",
        "1594",
        "INFY",
    )
    assert (mapping.provider_exchange, mapping.provider_segment, mapping.metadata) == (
        "NSE",
        "NSE",
        {"instrument_type": "EQ", "tradable": True},
    )
    assert (mapping.is_active, mapping.valid_from, mapping.valid_to) == (True, NOW, None)
    option = (await service.get(CE_KEY)).instrument
    assert (option.symbol, option.underlying, option.expiry, option.strike, option.option_type) == (
        "NIFTY 06JAN26 24000 CE",
        "NIFTY",
        date(2026, 1, 6),
        Decimal(24000),
        OptionType.CE,
    )
    assert (await service.get(FUT_KEY)).instrument.symbol == "NIFTY 27JAN26 FUT"
    [audit] = await refresh_audits(service)
    assert (audit.actor, audit.action, audit.entity_id, audit.client_ip) == (
        ACTOR,
        AUDIT_ACTION,
        "ZERODHA",
        "203.0.113.9",
    )
    assert audit.details == {
        "source": "FILE",
        "file_name": "kite.csv",
        "account_id": None,
        "rows": 4,
        "accepted": 4,
        "skipped": {},
        "stats": report.stats.model_dump(),
        "forced": False,
    }
    [command] = await worker_commands(service.bus)
    assert (command.type, command.provider, command.issued_by) == (
        CommandType.REFRESH_SUBSCRIPTIONS,
        ZERODHA,
        ACTOR,
    )


async def test_an_unchanged_dump_only_marks_rows_as_seen(
    service: InstrumentService, clock: FakeClock
) -> None:
    dump = kite_dump(INFY, RELIANCE, NIFTY_FUT, NIFTY_CE)
    await load(service, ZERODHA, dump)
    clock.advance(timedelta(hours=1))

    report = await load(service, ZERODHA, dump)

    assert report.stats == SyncStats(mappings_unchanged=4)
    instrument, [mapping] = await stored(service, INFY_KEY)
    assert (instrument.updated_at, instrument.last_seen_at) == (NOW, clock.now)
    assert (mapping.updated_at, mapping.last_seen_at) == (NOW, clock.now)


async def test_changed_attributes_are_updated_in_place(service: InstrumentService, clock: FakeClock) -> None:
    await load(service, ZERODHA, kite_dump(INFY, RELIANCE, NIFTY_FUT))
    clock.advance(timedelta(hours=1))

    report = await load(
        service,
        ZERODHA,
        kite_dump(
            kite_equity(408065, "INFY", "INFOSYS", exchange_token=1594, tick="0.1"),
            kite_equity(738561, "RELIANCE", "RELIANCE INDUSTRIES", exchange_token=2886, tick="0.1", lot=2),
            NIFTY_FUT,
        ),
    )

    # Each row changes different columns: the bulk update by primary key must cope with that.
    assert report.stats == SyncStats(instruments_updated=2, mappings_updated=1, mappings_unchanged=2)
    infy, [infy_mapping] = await stored(service, INFY_KEY)
    reliance, [reliance_mapping] = await stored(service, RELIANCE_KEY)
    assert (infy.tick_size, infy.lot_size, infy.updated_at) == (Decimal("0.1"), 1, clock.now)
    assert (reliance.tick_size, reliance.lot_size, reliance.updated_at) == (Decimal("0.1"), 2, clock.now)
    assert (reliance_mapping.exchange_token, reliance_mapping.updated_at) == ("2886", clock.now)
    assert infy_mapping.updated_at == NOW


async def test_providers_share_an_instrument_and_only_fill_in_what_is_missing(
    service: InstrumentService, clock: FakeClock
) -> None:
    await load(service, ZERODHA, kite_dump(INFY))
    clock.advance(timedelta(minutes=5))

    report = await load(service, GROWW, groww_dump(GROWW_INFY))

    assert report.stats == SyncStats(instruments_updated=1, mappings_created=1)
    detail = await service.get(INFY_KEY)
    # Zerodha's name and tick size stay; the ISIN Zerodha does not list is filled in.
    assert (detail.instrument.name, detail.instrument.tick_size, detail.instrument.isin) == (
        "INFOSYS",
        Decimal("0.05"),
        "INE009A01021",
    )
    assert [(m.provider, m.provider_token) for m in detail.mappings] == [
        (GROWW, "NSE|CASH|1594"),
        (ZERODHA, "408065"),
    ]


async def test_zerodha_overrides_the_lot_and_tick_sizes_of_other_providers(
    service: InstrumentService,
) -> None:
    await load(service, GROWW, groww_dump(GROWW_INFY))

    report = await load(service, ZERODHA, kite_dump(INFY))

    assert report.stats == SyncStats(instruments_updated=1, mappings_created=1)
    instrument = (await service.get(INFY_KEY)).instrument
    assert (instrument.name, instrument.tick_size, instrument.isin) == (
        "Infosys Limited",
        Decimal("0.05"),
        "INE009A01021",
    )


async def test_a_reused_token_moves_to_the_new_contract(service: InstrumentService, clock: FakeClock) -> None:
    await load(service, ZERODHA, kite_dump(NIFTY_FUT, NIFTY_CE))
    clock.now = datetime(2026, 1, 7, 4, 0, tzinfo=UTC)  # the option expired yesterday
    reused = "9002242,35165,NIFTY2612024000CE,NIFTY,0,2026-01-20,24000,0.05,75,CE,NFO-OPT,NFO"

    report = await load(service, ZERODHA, kite_dump(NIFTY_FUT, reused))

    assert report.stats == SyncStats(
        instruments_created=1, instruments_deactivated=1, mappings_moved=1, mappings_unchanged=1
    )
    expired = await service.get(CE_KEY)
    assert not expired.instrument.is_active
    assert [(m.is_active, m.valid_to) for m in expired.mappings] == [(False, clock.now)]
    current = await service.get("NSE:FNO:OPTION:NIFTY:2026-01-20:24000:CE")
    assert current.instrument.is_active
    assert [(m.provider_token, m.is_active, m.valid_from) for m in current.mappings] == [
        ("9002242", True, clock.now)
    ]


async def test_a_renamed_equity_keeps_its_instrument(service: InstrumentService, clock: FakeClock) -> None:
    await load(service, ZERODHA, kite_dump(INFY))
    original = (await service.get(INFY_KEY)).instrument
    clock.advance(timedelta(days=1))
    renamed_row = kite_equity(408065, "INFOSYS", "INFOSYS LIMITED", exchange_token=1594)

    report = await load(service, ZERODHA, kite_dump(renamed_row))

    assert report.stats == SyncStats(instruments_renamed=1, mappings_moved=1)
    await failure(service.get(INFY_KEY), NotFoundError, "instrument_not_found")
    renamed = await service.get(original.id)
    assert (renamed.instrument.canonical_key, renamed.instrument.symbol, renamed.instrument.name) == (
        "NSE:CASH:EQUITY:INFOSYS",
        "INFOSYS",
        "INFOSYS LIMITED",
    )
    assert [(m.provider_symbol, m.is_active) for m in renamed.mappings] == [
        ("INFOSYS", True),
        ("INFY", False),
    ]


async def test_an_instrument_another_provider_lists_is_not_renamed(service: InstrumentService) -> None:
    await load(service, ZERODHA, kite_dump(INFY))
    await load(service, GROWW, groww_dump(GROWW_INFY))

    report = await load(service, ZERODHA, kite_dump(kite_equity(408065, "INFOSYS", exchange_token=1594)))

    assert report.stats == SyncStats(instruments_created=1, mappings_moved=1)
    kept = await service.get(INFY_KEY)
    assert kept.instrument.is_active
    assert [(m.provider, m.is_active) for m in kept.mappings] == [(GROWW, True), (ZERODHA, False)]
    created = await service.get("NSE:CASH:EQUITY:INFOSYS")
    assert [(m.provider, m.provider_token) for m in created.mappings] == [(ZERODHA, "408065")]


async def test_an_instrument_still_listed_under_another_token_is_not_renamed(
    service: InstrumentService, clock: FakeClock
) -> None:
    await load(service, ZERODHA, kite_dump(INFY))
    original = (await service.get(INFY_KEY)).instrument
    clock.advance(timedelta(days=1))
    reused = kite_equity(408065, "INFYNEW", exchange_token=1594)  # INFY's old token, now another symbol's
    relisted = kite_equity(999, "INFY", "INFOSYS", exchange_token=1595)

    report = await load(service, ZERODHA, kite_dump(reused, relisted))

    assert report.stats == SyncStats(instruments_created=1, mappings_created=1, mappings_moved=1)
    kept = await service.get(INFY_KEY)
    assert (kept.instrument.id, kept.instrument.is_active) == (original.id, True)
    assert [(m.provider_token, m.is_active) for m in kept.mappings] == [("999", True), ("408065", False)]
    created = await service.get("NSE:CASH:EQUITY:INFYNEW")
    assert [(m.provider_token, m.is_active) for m in created.mappings] == [("408065", True)]


async def test_a_token_moving_to_a_known_symbol_joins_its_instrument(
    service: InstrumentService, clock: FakeClock
) -> None:
    await load(service, ZERODHA, kite_dump(INFY))
    await load(service, GROWW, groww_dump(groww_equity(1594, "INFOSYS")))
    clock.advance(timedelta(days=1))

    report = await load(service, ZERODHA, kite_dump(kite_equity(408065, "INFOSYS", exchange_token=1594)))

    assert report.stats == SyncStats(instruments_deactivated=1, mappings_moved=1)
    left = await service.get(INFY_KEY)
    assert not left.instrument.is_active
    joined = await service.get("NSE:CASH:EQUITY:INFOSYS")
    assert [(m.provider, m.is_active) for m in joined.mappings] == [(ZERODHA, True), (GROWW, True)]


async def test_unlisted_tokens_are_closed_only_in_the_scopes_the_dump_covers(
    service: InstrumentService, clock: FakeClock
) -> None:
    await load(service, ZERODHA, kite_dump(INFY, RELIANCE, TCS, NIFTY_FUT))
    reliance_id = (await service.get(RELIANCE_KEY)).instrument.id
    clock.advance(timedelta(hours=1))

    # NSE cash only: two of three are gone, but three are too few to suspect a truncated dump.
    report = await load(service, ZERODHA, kite_dump(INFY))

    assert report.stats == SyncStats(instruments_deactivated=2, mappings_unchanged=1, mappings_closed=2)
    assert (await service.get(FUT_KEY)).instrument.is_active
    assert not (await service.get(RELIANCE_KEY)).instrument.is_active
    clock.advance(timedelta(hours=1))

    report = await load(service, ZERODHA, kite_dump(INFY, RELIANCE))

    assert report.stats == SyncStats(instruments_activated=1, mappings_created=1, mappings_unchanged=1)
    relisted = await service.get(RELIANCE_KEY)
    assert (relisted.instrument.id, relisted.instrument.is_active) == (reliance_id, True)
    assert [m.is_active for m in relisted.mappings] == [True, False]


async def test_a_dump_lacking_most_of_a_sizeable_scope_is_refused_unless_forced(
    service: InstrumentService,
) -> None:
    await load(service, ZERODHA, kite_dump(*EQUITIES, NIFTY_FUT))
    truncated = kite_dump(*EQUITIES[:5])

    error = await failure(load(service, ZERODHA, truncated), ConflictError, "instrument_dump_incomplete")

    assert error.details == {"scopes": [{"exchange": "NSE", "segment": "CASH", "missing": 7, "active": 12}]}
    assert len(await refresh_audits(service)) == 1
    assert len(await worker_commands(service.bus)) == 1
    report = await load(service, ZERODHA, truncated, force=True)
    assert (report.forced, report.stats.mappings_closed, report.stats.instruments_deactivated) == (True, 7, 7)
    assert (await refresh_audits(service))[-1].details["forced"] is True


async def test_a_dump_lacking_half_of_a_scope_is_accepted(service: InstrumentService) -> None:
    await load(service, ZERODHA, kite_dump(*EQUITIES))

    report = await load(service, ZERODHA, kite_dump(*EQUITIES[:6]))

    assert (report.stats.mappings_closed, report.stats.mappings_unchanged) == (6, 6)


async def test_tokens_of_rows_that_cannot_be_stored_are_held(
    service: InstrumentService, clock: FakeClock
) -> None:
    await load(service, ZERODHA, kite_dump(INFY, RELIANCE))
    clock.advance(timedelta(hours=1))
    unstorable = kite_equity(738561, "RELIANCE", "R" * 201, exchange_token=2885, tick="0.1")  # name too long

    report = await load(service, ZERODHA, kite_dump(INFY, unstorable))

    assert report.skipped == {"field_too_long": 1}
    assert report.stats == SyncStats(mappings_unchanged=1, mappings_held=1)
    reliance = await service.get(RELIANCE_KEY)
    assert reliance.instrument.is_active
    assert [(m.is_active, m.valid_to) for m in reliance.mappings] == [(True, None)]


async def test_expired_contracts_are_deactivated_by_any_refresh(
    service: InstrumentService, clock: FakeClock
) -> None:
    await load(service, ZERODHA, kite_dump(NIFTY_CE))
    clock.now = datetime(2026, 1, 6, 18, 29, tzinfo=UTC)  # 23:59 on 6 January in India: expiry day
    first = await load(service, GROWW, groww_dump(GROWW_INFY))
    clock.advance(timedelta(minutes=2))

    second = await load(service, GROWW, groww_dump(GROWW_INFY))

    assert first.stats == SyncStats(instruments_created=1, mappings_created=1)
    assert second.stats == SyncStats(instruments_deactivated=1, mappings_unchanged=1)
    option = await service.get(CE_KEY)
    assert not option.instrument.is_active
    assert [m.is_active for m in option.mappings] == [True]  # still listed: only the contract expired


async def test_a_contract_is_live_until_its_expiry_day_ends_in_india(
    service: InstrumentService, clock: FakeClock
) -> None:
    await load(service, ZERODHA, kite_dump(NIFTY_CE))
    clock.now = datetime(2026, 1, 6, 18, 29, tzinfo=UTC)  # 23:59 on 6 January in India: expiry day
    on_expiry_day = await load(service, ZERODHA, kite_dump(NIFTY_CE))
    clock.advance(timedelta(minutes=2))
    late = "9002243,35166,NIFTY2610624100CE,NIFTY,0,2026-01-06,24100,0.05,75,CE,NFO-OPT,NFO"

    next_day = await load(service, ZERODHA, kite_dump(NIFTY_CE, late))

    assert on_expiry_day.stats == SyncStats(mappings_unchanged=1)
    # The late contract is created already expired: inactive, but never counted as deactivated.
    assert next_day.stats == SyncStats(
        instruments_created=1, instruments_deactivated=1, mappings_created=1, mappings_unchanged=1
    )
    assert not (await service.get("NSE:FNO:OPTION:NIFTY:2026-01-06:24100:CE")).instrument.is_active


async def test_a_second_refresh_of_the_same_provider_is_refused(service: InstrumentService) -> None:
    lock = func.pg_advisory_xact_lock(func.hashtext(f"{LOCK_NAME}:{ZERODHA.value}"))
    async with service.db.transaction() as session:  # a Zerodha refresh in progress
        await session.execute(select(lock))

        await failure(load(service, ZERODHA, kite_dump(INFY)), ConflictError, "instrument_refresh_running")
        report = await load(service, GROWW, groww_dump(GROWW_INFY))  # other providers are not blocked

    assert report.stats.instruments_created == 1


# ---- downloads ----------------------------------------------------------------------------------


async def test_a_groww_download_is_cached_before_it_is_applied(
    service: InstrumentService, remote: FakeProvider, tmp_path: Path
) -> None:
    data = groww_dump(GROWW_INFY)
    remote.routes[GROWW_DUMP_ROUTE] = csv_reply(data)

    report = await service.refresh(GROWW, actor=ACTOR)

    assert (report.source, report.account_id, report.cache_error) == (DumpSource.DOWNLOAD, None, None)
    assert report.stats.instruments_created == 1
    assert report.cache_path is not None
    cached = Path(report.cache_path)
    assert (cached.parent, await asyncio.to_thread(cached.read_bytes)) == (tmp_path / "cache" / "groww", data)
    [request] = remote.requests
    assert str(request.url) == GROWW_DUMP_URL
    assert "authorization" not in request.headers


async def test_a_zerodha_download_uses_the_enabled_accounts_credentials(
    service: InstrumentService, accounts: ProviderAccountService, remote: FakeProvider, clock: FakeClock
) -> None:
    account_id = await kite_account(accounts)
    await store_token(accounts, account_id, "kite-token", expires_at=clock.now + timedelta(hours=2))
    remote.routes[KITE_DUMP_ROUTE] = csv_reply(kite_dump(INFY))

    first = await service.refresh(ZERODHA, actor=ACTOR)
    clock.advance(timedelta(hours=3))  # the access token has expired: it is no longer sent
    second = await service.refresh(ZERODHA, actor=ACTOR)

    assert (first.source, first.account_id, second.account_id) == (
        DumpSource.DOWNLOAD,
        account_id,
        account_id,
    )
    with_token, without_token = remote.requests
    assert with_token.headers["authorization"] == f"token {KITE_KEY}:kite-token"
    assert with_token.headers["x-kite-version"] == "3"
    assert "authorization" not in without_token.headers
    assert [audit.details["account_id"] for audit in await refresh_audits(service)] == [str(account_id)] * 2


async def test_the_deployment_api_key_downloads_without_an_account(
    make_service: ServiceFactory, remote: FakeProvider
) -> None:
    remote.routes[KITE_DUMP_ROUTE] = csv_reply(kite_dump(INFY))

    report = await make_service(zerodha_api_key=SecretStr(KITE_KEY)).refresh(ZERODHA, actor=ACTOR)

    assert (report.account_id, report.stats.instruments_created) == (None, 1)
    [request] = remote.requests
    assert "authorization" not in request.headers


async def test_a_zerodha_download_needs_an_api_key(service: InstrumentService, remote: FakeProvider) -> None:
    await failure(service.refresh(ZERODHA, actor=ACTOR), ValidationFailedError, "zerodha_api_key_missing")

    assert remote.requests == []


async def test_only_a_zerodha_account_downloads_the_zerodha_dump(
    service: InstrumentService, accounts: ProviderAccountService, remote: FakeProvider
) -> None:
    groww = await accounts.create(GROWW, "Main", actor=ACTOR)

    call = service.refresh(ZERODHA, actor=ACTOR, account_id=groww.id)

    await failure(call, ValidationFailedError, "instrument_source_invalid")
    assert remote.requests == []


async def test_a_failed_download_changes_nothing(
    service: InstrumentService, remote: FakeProvider, tmp_path: Path
) -> None:
    remote.routes[GROWW_DUMP_ROUTE] = lambda _request: httpx.Response(503, text="maintenance")

    with pytest.raises(ProviderError):
        await service.refresh(GROWW, actor=ACTOR)

    assert await refresh_audits(service) == []
    assert not (tmp_path / "cache").exists()


async def test_caching_is_best_effort_and_optional(
    make_service: ServiceFactory, remote: FakeProvider, tmp_path: Path
) -> None:
    remote.routes[GROWW_DUMP_ROUTE] = csv_reply(groww_dump(GROWW_INFY))
    not_a_directory = tmp_path / "file"
    not_a_directory.write_bytes(b"")

    failed = await make_service(instrument_cache_dir=str(not_a_directory)).refresh(GROWW, actor=ACTOR)
    disabled = await make_service(instrument_cache_dir=" ").refresh(GROWW, actor=ACTOR)

    assert failed.cache_path is None
    assert failed.cache_error  # reported, and the refresh went ahead regardless
    assert failed.stats.instruments_created == 1
    assert (disabled.cache_path, disabled.cache_error) == (None, None)


@pytest.mark.parametrize(
    ("provider", "with_file", "with_account"),
    [(SIMULATOR, True, False), (SIMULATOR, False, True), (ZERODHA, True, True), (GROWW, False, True)],
)
async def test_contradictory_sources_are_refused(
    service: InstrumentService, remote: FakeProvider, provider: Provider, with_file: bool, with_account: bool
) -> None:
    call = service.refresh(
        provider,
        actor=ACTOR,
        data=kite_dump(INFY) if with_file else None,
        account_id=uuid4() if with_account else None,
    )

    await failure(call, ValidationFailedError, "instrument_source_invalid")
    assert remote.requests == []


async def test_the_simulator_refreshes_its_built_in_instruments(service: InstrumentService) -> None:
    report = await service.refresh(SIMULATOR, actor=ACTOR)

    assert (report.source, report.skipped, report.stats.instruments_created) == (
        DumpSource.BUILT_IN,
        {},
        report.accepted,
    )
    page = await service.search(InstrumentQuery(provider=SIMULATOR, active=None, limit=SEARCH_LIMIT_MAX))
    assert len(page.items) == report.accepted
    assert {hit.instrument.exchange for hit in page.items} == {Exchange.SIM}


# ---- reads --------------------------------------------------------------------------------------

CATALOG = (
    INFY,
    kite_equity(4001, "INFYBEES", "NIPPON INDIA ETF", exchange_token=4001),
    kite_equity(4002, "TECHINFY", "TECH SOLUTIONS", exchange_token=4002),
    kite_equity(4003, "MIRA_100", "MIRAE 100%", exchange_token=4003),
    RELIANCE,
    NIFTY_FUT,
    NIFTY_CE,
)
CE_SYMBOL = "NIFTY 06JAN26 24000 CE"
FUT_SYMBOL = "NIFTY 27JAN26 FUT"


@pytest.fixture
async def catalog(service: InstrumentService) -> InstrumentService:
    await load(service, ZERODHA, kite_dump(*CATALOG))
    return service


def symbols(page: InstrumentPage) -> list[str]:
    return [hit.instrument.symbol for hit in page.items]


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("infy", ["INFY", "INFYBEES", "TECHINFY"]),  # exact, then prefix, then other matches
        ("nifty  ce", [CE_SYMBOL]),  # every term must match
        ("nifty2610624000", [CE_SYMBOL]),  # the provider's symbol
        ("india etf", ["INFYBEES"]),  # the name
        ("_", ["MIRA_100"]),  # LIKE wildcards are matched literally
        ("%", ["MIRA_100"]),
    ],
)
async def test_search_text(catalog: InstrumentService, text: str, expected: list[str]) -> None:
    assert symbols(await catalog.search(InstrumentQuery(text=text))) == expected


@pytest.mark.parametrize(
    ("query", "expected"),
    [
        (InstrumentQuery(underlying="nifty"), [CE_SYMBOL, FUT_SYMBOL]),
        (InstrumentQuery(instrument_type=InstrumentType.FUTURE), [FUT_SYMBOL]),
        (InstrumentQuery(segment=Segment.FNO, option_type=OptionType.CE), [CE_SYMBOL]),
        (InstrumentQuery(strike=Decimal(24000)), [CE_SYMBOL]),
        (InstrumentQuery(expiry=date(2026, 1, 27)), [FUT_SYMBOL]),
        (InstrumentQuery(exchange=Exchange.BSE), []),
        (InstrumentQuery(provider=GROWW), []),
        (InstrumentQuery(provider=ZERODHA, text="reliance"), ["RELIANCE"]),
    ],
)
async def test_search_filters(
    catalog: InstrumentService, query: InstrumentQuery, expected: list[str]
) -> None:
    assert symbols(await catalog.search(query)) == expected


async def test_search_lists_cash_instruments_first_then_derivatives_by_expiry(
    catalog: InstrumentService,
) -> None:
    pages = [await catalog.search(InstrumentQuery(limit=3, offset=offset)) for offset in (0, 3, 6)]
    exact_fit = await catalog.search(InstrumentQuery(limit=len(CATALOG)))

    assert [symbols(page) for page in pages] == [
        ["INFY", "INFYBEES", "MIRA_100"],
        ["RELIANCE", "TECHINFY", CE_SYMBOL],
        [FUT_SYMBOL],
    ]
    assert [page.has_more for page in pages] == [True, True, False]
    assert (len(exact_fit.items), exact_fit.has_more) == (len(CATALOG), False)


async def test_search_by_activity(catalog: InstrumentService) -> None:
    await load(catalog, ZERODHA, kite_dump(*(row for row in CATALOG if "TECHINFY" not in row)))

    found = [
        await catalog.search(InstrumentQuery(text="infy", active=active)) for active in (True, False, None)
    ]
    listed = await catalog.search(InstrumentQuery(text="infy", active=None, provider=ZERODHA))

    assert [symbols(page) for page in found] == [
        ["INFY", "INFYBEES"],
        ["TECHINFY"],
        ["INFY", "INFYBEES", "TECHINFY"],
    ]
    assert [hit.providers for hit in found[1].items] == [()]  # its closed mapping lists it nowhere
    assert symbols(listed) == ["INFY", "INFYBEES"]


async def test_search_hits_name_the_providers_listing_them(catalog: InstrumentService) -> None:
    await load(catalog, GROWW, groww_dump(GROWW_INFY))

    page = await catalog.search(InstrumentQuery(text="infy"))

    assert [(hit.instrument.symbol, hit.providers) for hit in page.items] == [
        ("INFY", (GROWW, ZERODHA)),
        ("INFYBEES", (ZERODHA,)),
        ("TECHINFY", (ZERODHA,)),
    ]


async def test_get_accepts_an_id_or_a_canonical_key(catalog: InstrumentService) -> None:
    by_key = await catalog.get("  nse:cash:equity:infy ")

    assert by_key.instrument.canonical_key == INFY_KEY
    assert await catalog.get(by_key.instrument.id) == by_key
    assert await catalog.get(str(by_key.instrument.id)) == by_key
    await failure(catalog.get(uuid4()), NotFoundError, "instrument_not_found")
    await failure(catalog.get("NSE:CASH:EQUITY:MISSING"), NotFoundError, "instrument_not_found")


async def test_get_lists_active_mappings_first_newest_first(
    catalog: InstrumentService, clock: FakeClock
) -> None:
    clock.advance(timedelta(minutes=1))
    await load(catalog, GROWW, groww_dump(GROWW_INFY))
    clock.advance(timedelta(minutes=1))
    relisted = groww_equity(1595, "INFY", "Infosys Limited", isin="INE009A01021", tick="0.10")  # new token
    await load(catalog, GROWW, groww_dump(relisted))

    detail = await catalog.get(INFY_KEY)

    # The closed Groww mapping is newer than Zerodha's active one, yet listed after it.
    assert [(m.provider, m.provider_token, m.is_active) for m in detail.mappings] == [
        (GROWW, "NSE|CASH|1595", True),
        (ZERODHA, "408065", True),
        (GROWW, "NSE|CASH|1594", False),
    ]


async def test_resolve_lists_what_a_provider_subscribes_to(
    catalog: InstrumentService, clock: FakeClock
) -> None:
    await load(catalog, GROWW, groww_dump(GROWW_INFY))
    infy, reliance, option = [
        (await catalog.get(key)).instrument.id for key in (INFY_KEY, RELIANCE_KEY, CE_KEY)
    ]
    clock.now = datetime(2026, 1, 7, 4, 0, tzinfo=UTC)
    await load(catalog, GROWW, groww_dump(GROWW_INFY))  # deactivates the expired option
    unknown = uuid4()

    kite = await catalog.resolve([option, infy, unknown, reliance, infy], ZERODHA, mode=SubscriptionMode.FULL)
    groww = await catalog.resolve([reliance, infy], GROWW)

    assert kite.found[0] == ProviderInstrument(
        instrument_id=infy,
        provider=ZERODHA,
        provider_token="408065",
        exchange_token="1594",
        provider_symbol="INFY",
        provider_exchange="NSE",
        provider_segment="NSE",
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        instrument_type=InstrumentType.EQUITY,
        symbol="INFY",
        expiry=None,
        tick_size=Decimal("0.05"),
        mode=SubscriptionMode.FULL,
    )
    assert [item.instrument_id for item in kite.found] == [infy, reliance]
    assert kite.missing == (option, unknown)
    assert [(item.provider_token, item.mode) for item in groww.found] == [
        ("NSE|CASH|1594", SubscriptionMode.QUOTE)
    ]
    assert groww.missing == (reliance,)
