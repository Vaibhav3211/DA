"""Helpers for strategy, risk and signal integration tests."""

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any
from uuid import UUID

import sqlalchemy as sa

from app.container import Container
from app.domain.enums import DataStatus, MarketRegion, Provider, StrategyRunStatus
from app.domain.models.instrument import Instrument
from app.persistence.database import Database
from app.persistence.models import (
    AuditLogRow,
    BacktestDatasetRow,
    BacktestRunRow,
    RiskDecisionRow,
    RiskRuleRow,
    StrategyDeploymentRow,
    StrategyRow,
    StrategyRunRow,
    SystemFlagRow,
)
from app.risk.rules import SourceData
from app.services import backtests, datasets, risk, strategies
from app.services.instruments import find_instrument
from app.services.kill_switch import FLAG_KEY
from app.services.strategies import DeploymentView, Scope, StrategyService
from app.signals.engine import Proposal, RunContext
from app.strategies.registry import builtin_registry
from tests.integration.provider_support import ACTOR, LAB
from tests.signal_support import make_candidate, make_indicator

EXAMPLE = "example.ema_crossover"
_AUDITED = (strategies.ENTITY, strategies.CATALOGUE_ENTITY, risk.ENTITY, "system_flag")


async def wipe_strategies(db: Database) -> None:
    """Remove strategies with everything that hangs off them, risk rules and their audit entries, and
    release the kill switch."""
    async with db.transaction() as session:
        await session.execute(sa.delete(RiskDecisionRow))
        # Runs, signals and signal events cascade; configurations block a deployment delete otherwise.
        await session.execute(sa.delete(StrategyDeploymentRow))
        await session.execute(sa.delete(StrategyRow))  # versions and configurations cascade
        await session.execute(sa.delete(RiskRuleRow))
        await session.execute(sa.delete(AuditLogRow).where(AuditLogRow.entity_type.in_(_AUDITED)))
        await session.execute(
            sa.update(SystemFlagRow)
            .where(SystemFlagRow.key == FLAG_KEY)
            .values(value={"engaged": False, "reason": None})
        )


async def wipe_backtests(db: Database) -> None:
    """Remove backtest runs and datasets (dataset candles cascade) and their audit entries."""
    async with db.transaction() as session:
        await session.execute(sa.delete(BacktestRunRow))
        await session.execute(sa.delete(BacktestDatasetRow))
        await session.execute(
            sa.delete(AuditLogRow).where(AuditLogRow.entity_type.in_((backtests.ENTITY, datasets.ENTITY)))
        )


async def start_run(db: Database, deployment: DeploymentView, started_at: datetime) -> UUID:
    """A RUNNING run of the deployment, as the strategy worker records it."""
    async with db.transaction() as session:
        row = StrategyRunRow(
            deployment_id=deployment.id,
            strategy_id=deployment.strategy_id,
            strategy_version=deployment.strategy_version,
            configuration_id=deployment.configuration_id,
            config_snapshot=deployment.config,
            config_hash=deployment.config_hash,
            input_context={},
            status=StrategyRunStatus.RUNNING,
            worker_id="test-worker",
            started_at=started_at,
        )
        session.add(row)
        await session.flush()
        return row.id


async def save_example(
    service: StrategyService, *, scope: Scope | None = None, enable: bool = False, **options: Any
) -> DeploymentView:
    """A saved configuration of the example strategy in the simulation lab, watching the whole workspace
    unless ``scope`` says otherwise; ``options`` go to ``create_configuration`` (label, config)."""
    view = await service.create_configuration(
        LAB, EXAMPLE, scope=scope or Scope.workspace(), actor=ACTOR, **options
    )
    return await service.set_enabled(view.id, True, actor=ACTOR) if enable else view


async def example_run(container: Container, now: datetime) -> RunContext:
    """Save the example strategy in the simulation lab with live signals on, and start a run of it at
    ``now``."""
    service = StrategyService(container.db, container.bus, clock=lambda: now)
    deployment = await save_example(service, enable=True)
    return RunContext(
        run_id=await start_run(container.db, deployment, now),
        deployment_id=deployment.id,
        workspace_id=deployment.workspace_id,
        market_region=MarketRegion.LAB,
        metadata=builtin_registry().get(EXAMPLE).metadata,
        configuration_id=deployment.configuration_id,
    )


async def load_instrument(db: Database, ref: UUID | str) -> Instrument:
    """An instrument by id or canonical key."""
    async with db.session() as session:
        return Instrument.model_validate(await find_instrument(session, ref), from_attributes=True)


def proposal(
    instrument: Instrument,
    now: datetime,
    *,
    provider: Provider = Provider.SIMULATOR,
    age_seconds: int = 5,
    **fields: Any,
) -> Proposal:
    """A candidate on ``instrument`` (BUY 100.10, stop 98.05, T1 104.20 unless overridden) from a candle
    that is ``age_seconds`` old at ``now``."""
    status = DataStatus.SIMULATED if provider is Provider.SIMULATOR else DataStatus.LIVE
    candidate = make_candidate(
        **{"instrument_id": instrument.id, "indicator_values": (make_indicator(status),), **fields}
    )
    source = SourceData(
        provider=provider,
        status=status,
        as_of=now - timedelta(seconds=age_seconds),
        last_price=Decimal("100.10"),
        high=Decimal("100.50"),
        low=Decimal("99.80"),
    )
    return Proposal(candidate, instrument, source)
