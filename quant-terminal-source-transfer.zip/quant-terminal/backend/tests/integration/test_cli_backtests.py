"""``qt datasets`` and ``qt backtests`` against PostgreSQL and Redis: a dataset of the recorded session,
history that is missing, the trade rules a backtest needs, its results and trades, results that go out of
date and stay for comparison, and a backtest without trades.

The instruments, the recorded session and the fixture strategies are described in ``history_support``. A
backtest worker runs between commands, as qt-backtest-worker would; nothing reaches a provider.
"""

from __future__ import annotations

import asyncio
import io
import re
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal

import pytest
from structlog.testing import capture_logs

from app.cli import _services, entry
from app.container import Container
from app.core.config import Settings
from app.services.backtests import BacktestService
from app.services.datasets import DatasetService
from app.services.markets import MarketCalendarCache
from app.services.strategies import StrategyService
from app.strategies.registry import StrategyRegistry
from app.workers.backtest_worker import BacktestWorker
from tests.integration.history_support import (
    INDIA,
    NO_RULES,
    NO_WORKER,
    ONE,
    SILENT,
    TARGET_ONLY,
    TRADER,
    TWO,
    add_instruments,
    fixture_registry,
    record_session,
    wipe_lab,
)
from tests.integration.provider_support import FakeClock, FakeProvider, provider_settings

pytestmark = pytest.mark.integration

WORKER = "cli-test-worker"
# tests.backtest_support.trade_rules(), as typed on the command line.
RULES = [
    item
    for rule in (
        "sides=both",
        "opposite_signal=reverse",
        "fill=next-open",
        "exit_check=intrabar",
        "stop_target=signal",
        "sizing=fixed-quantity",
        "quantity=10",
        "initial_capital=100000",
        "fee_pct_per_side=0",
        "fee_per_order=0",
        "slippage_ticks=0",
    )
    for item in ("--rule", rule)
]
NOT_A_FORECAST = "These results replay the past on the dataset's candles: they are not a forecast.\n"


@dataclass(frozen=True)
class Harness:
    """The services the commands use, sharing one registry and one clock (09:30 IST on 5 January 2026),
    and a worker that runs what they queue."""

    settings: Settings
    clock: FakeClock
    registry: StrategyRegistry
    remote: FakeProvider  # records any provider call; nothing here should make one

    def strategies(self, container: Container) -> StrategyService:
        return StrategyService(container.db, container.bus, registry=self.registry, clock=self.clock)

    def datasets(self, container: Container, calendars: MarketCalendarCache | None = None) -> DatasetService:
        if calendars is None:
            calendars = MarketCalendarCache(container.db, container.settings)
        return DatasetService.from_container(
            container, calendars, transport=self.remote.transport, clock=self.clock
        )

    def backtests(self, container: Container) -> BacktestService:
        return BacktestService.from_container(container, registry=self.registry, clock=self.clock)

    def drain(self) -> None:
        """Let a backtest worker take every waiting job, as qt-backtest-worker does."""

        async def drain() -> None:
            container = Container.create(self.settings)
            try:
                calendars = MarketCalendarCache(container.db, container.settings)
                worker = BacktestWorker(
                    self.datasets(container, calendars),
                    self.backtests(container),
                    calendars,
                    worker_id=WORKER,
                    poll_seconds=0,
                    clock=self.clock,
                )
                for _ in range(20):
                    if not await worker.run_once():
                        return
                raise AssertionError("the backtest worker kept finding jobs")
            finally:
                await container.close()

        asyncio.run(drain())


async def _reset_state(settings: Settings) -> None:
    container = Container.create(settings)
    try:
        await wipe_lab(container.db)
        await container.bus.redis.flushdb()
    finally:
        await container.close()


async def _record_session(settings: Settings) -> None:
    """The three instruments, with the session's candles of BTONE recorded from Zerodha's feed."""
    container = Container.create(settings)
    try:
        ids = await add_instruments(container)
        await record_session(container.db, ids[ONE], ONE)
    finally:
        await container.close()


@pytest.fixture
def cli(migrated_database: Settings, monkeypatch: pytest.MonkeyPatch) -> Iterator[Harness]:
    harness = Harness(provider_settings(migrated_database), FakeClock(), fixture_registry(), FakeProvider())
    monkeypatch.setattr("app.cli._console.get_settings", lambda: harness.settings)
    monkeypatch.setattr(entry, "configure_logging", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(_services, "http_transport", lambda: harness.remote.transport)
    monkeypatch.setattr(_services, "strategies", harness.strategies)
    monkeypatch.setattr(_services, "datasets", harness.datasets)
    monkeypatch.setattr(_services, "backtests", harness.backtests)
    with capture_logs():  # a real `qt` prints only warnings, to stderr
        asyncio.run(_reset_state(harness.settings))
        asyncio.run(_record_session(harness.settings))
        yield harness
        asyncio.run(_reset_state(harness.settings))  # leave the shared test database as seeded


def _run(monkeypatch: pytest.MonkeyPatch, args: list[str]) -> int:
    monkeypatch.setattr("sys.stdin", io.StringIO(""))
    return entry.main(args)


def _field(output: str, label: str) -> str:
    """The value of the ``label  value`` row in ``output``."""
    for line in output.splitlines():
        if line.startswith(f"{label}  "):
            return line[len(label) :].strip()
    pytest.fail(f"no {label!r} row in:\n{output}")


def _records(output: str) -> list[dict[str, str]]:
    """The rows of the table in ``output``, by column."""
    header, *rows = (re.split(r"\s{2,}", line.strip()) for line in output.splitlines() if line.strip())
    return [dict(zip(header, row, strict=True)) for row in rows]


def _block(output: str, start: str) -> str:
    """The block of ``output`` (blocks are separated by blank lines) that starts with ``start``."""
    return next(block for block in output.split("\n\n") if block.startswith(start))


def _request(instrument: str = ONE, *options: str) -> list[str]:
    """``qt datasets request`` of the 1-minute candles recorded on 5 January; later ``options`` win."""
    return [
        "datasets",
        "request",
        instrument,
        "--provider",
        "zerodha",
        "--source",
        "recorded",
        "--interval",
        "1m",
        "--from",
        "2026-01-05",
        "--to",
        "2026-01-05",
        *options,
    ]


def _ready_dataset(cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> str:
    """The id of a READY dataset of the recorded session."""
    assert _run(monkeypatch, _request()) == 0
    dataset_id = _field(capsys.readouterr().out, "Dataset")
    cli.drain()
    return dataset_id


def test_a_recorded_session_is_backtested_from_the_command_line(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    # Where BTONE's datasets can come from: here, the candles recorded from Zerodha's feed.
    assert _run(monkeypatch, ["datasets", "sources", ONE]) == 0
    out, err = capsys.readouterr()
    assert _field(out, "Last date") == "2026-01-05: today on NSE, the last date a dataset may cover"
    recorded = _block(out, "ZERODHA recorded: ")
    assert recorded.splitlines()[0] == "ZERODHA recorded: available"
    assert "1m: 13 candles from 2026-01-05 09:15 IST to 2026-01-05 09:30 IST" in recorded
    assert err == f"warning: {NO_WORKER}\n"

    # A request only queues the dataset; asking again while it waits returns the same one.
    assert _run(monkeypatch, _request()) == 0
    out, err = capsys.readouterr()
    dataset_id = _field(out, "Dataset")
    assert (_field(out, "Source"), _field(out, "Status")) == (
        "candles recorded from the ZERODHA live feed",
        "PENDING: waiting for the backtest worker (qt-backtest-worker)",
    )
    follow = f"follow it with qt datasets show {dataset_id}"
    assert err == f"Queued: the backtest worker (qt-backtest-worker) builds it; {follow}\n"
    assert _run(monkeypatch, _request()) == 0
    out, err = capsys.readouterr()
    assert _field(out, "Dataset") == dataset_id
    assert err == f"The same request was already waiting or building, so this is that one; {follow}\n"

    # History that was not recorded is refused, saying what was; nothing is filled in.
    refused = [
        (
            _request(TWO),
            f"error: No closed 1m candles of {TWO} were recorded from ZERODHA between 2026-01-05 and "
            "2026-01-05 (recorded: none)\n",
        ),
        (
            _request(ONE, "--interval", "5m"),
            f"error: No closed 5m candles of {ONE} were recorded from ZERODHA between 2026-01-05 and "
            "2026-01-05 (recorded: 1m: 13 from 2026-01-05 to 2026-01-05)\n",
        ),
        (
            _request(ONE, "--to", "2026-01-06"),
            "error: The last date (2026-01-06) is after today on NSE (2026-01-05)\n",
        ),
        (
            _request(ONE, "--account", "Main"),
            "error: --account applies only to --source provider-history: recorded candles use no account\n",
        ),
    ]
    for args, problem in refused:
        assert _run(monkeypatch, args) == 1
        assert capsys.readouterr().err == problem
    with pytest.raises(SystemExit) as exited:
        _run(monkeypatch, _request(ONE, "--interval", "7m"))
    assert exited.value.code == 2
    assert "invalid interval: '7m'" in capsys.readouterr().err

    # The worker builds it: its coverage against the exchange calendar shows the gap.
    cli.drain()
    assert _run(monkeypatch, ["datasets", "show", dataset_id]) == 0
    out = capsys.readouterr().out
    assert (_field(out, "Status"), _field(out, "Candles")) == (
        "READY since 2026-01-05 09:30 IST",
        "13, from 2026-01-05 09:15 IST to 2026-01-05 09:30 IST",
    )
    assert _field(out, "Coverage") == (
        "86.66%: 13 of the 15 candles the calendar expects on 1 session days; 2 missing in 1 gaps"
    )
    assert _field(out, "Gaps") == "2026-01-05 09:22 IST to 2026-01-05 09:24 IST: 2 missing"
    assert _run(monkeypatch, ["datasets", "list", "--instrument", ONE, "--status", "ready"]) == 0
    assert [
        (row["DATASET"], row["SOURCE"], row["STATUS"], row["CANDLES"], row["COVERAGE"])
        for row in _records(capsys.readouterr().out)
    ] == [(dataset_id, "recorded", "ready", "13", "86.66%")]

    # TRADER, registered and saved for BTONE alone, cannot be backtested before it has trade rules.
    assert _run(monkeypatch, ["strategies", "sync"]) == 0
    create = ["strategies", "create", INDIA, TRADER.strategy_id, "--instrument", ONE, "--label", "Trader"]
    assert _run(monkeypatch, create) == 0
    capsys.readouterr()
    rules = ["backtests", "rules"]
    target = [INDIA, "Trader"]
    assert _run(monkeypatch, [*rules, "show", *target]) == 0
    out = capsys.readouterr().out
    assert (_field(out, "In use"), _field(out, "Problem"), _field(out, "Strategy")) == (
        "none",
        NO_RULES,
        "declares no trade rules",
    )
    run = ["backtests", "run", *target, "--instrument", ONE, "--dataset", dataset_id]
    assert _run(monkeypatch, run) == 1
    assert capsys.readouterr().err == f"error: Cannot backtest 'Trader' on {ONE}: {NO_RULES}\n"
    latest = ["backtests", "latest", *target, "--instrument", ONE]
    assert _run(monkeypatch, latest) == 0
    out, err = capsys.readouterr()
    assert (_field(out, "State"), _field(out, "Cannot run")) == (
        "Not backtested: no backtest of this configuration on this instrument succeeded",
        NO_RULES,
    )
    assert err == f"warning: {NO_WORKER}\n"

    # Rules start from the ones in use: with none in use, every required rule must be given.
    assert _run(monkeypatch, [*rules, "set", *target, "--rule", "quantity=10"]) == 1
    assert capsys.readouterr().err.startswith("error: the trade rules are not valid: ")
    assert _run(monkeypatch, [*rules, "set", *target, *RULES]) == 0
    out, err = capsys.readouterr()
    assert _field(out, "In use") == "the configuration's own"
    values = {row["RULE"]: row["VALUE"] for row in _records(out.split("\n\n")[1])}
    assert (values["fill"], values["quantity"], values["stop_pct"]) == ("next-open", "10", "-")
    assert err == "Saved. Backtests run with other trade rules are now outdated; their results stay.\n"
    assert _run(monkeypatch, [*rules, "set", *target, "--rule", "quantity=10"]) == 0
    assert capsys.readouterr().err == "These were already the configuration's trade rules: nothing changed.\n"

    # Queued once: asking again while it waits returns it; a dataset backtests only its own instrument.
    assert _run(monkeypatch, run) == 0
    out, err = capsys.readouterr()
    run_id = _field(out, "Backtest")
    assert _field(out, "Status") == (
        "QUEUED at 2026-01-05 09:30 IST: waiting for the backtest worker (qt-backtest-worker)"
    )
    assert err == (
        "Queued: the backtest worker (qt-backtest-worker) runs it; follow it with "
        f"qt backtests show {run_id}\nwarning: {NO_WORKER}\n"
    )
    assert _run(monkeypatch, run) == 0
    out, err = capsys.readouterr()
    assert _field(out, "Backtest") == run_id
    assert err.startswith("The same backtest was already queued or running, so this is that one")
    assert _run(monkeypatch, ["backtests", "run", *target, "--instrument", TWO, "--dataset", dataset_id]) == 1
    assert capsys.readouterr().err == (
        f"error: Dataset {dataset_id} holds another instrument's candles, not {TWO}'s\n"
    )

    # The worker runs it: one winning trade, and the metrics that cannot be defined say why.
    cli.drain()
    assert _run(monkeypatch, latest) == 0
    out, err = capsys.readouterr()
    assert (_field(out, "State"), _field(out, "Trade rules"), _field(out, "Backtest")) == (
        "CURRENT: a backtest with the current settings succeeded",
        "the configuration's own",
        run_id,
    )
    assert _field(out, "Data") == "zerodha recorded, 2026-01-05 to 2026-01-05"
    assert err == f"Everything about it: qt backtests show {run_id}\nwarning: {NO_WORKER}\n"

    assert _run(monkeypatch, ["backtests", "show", run_id, "--curve"]) == 0
    out, err = capsys.readouterr()
    assert (_field(out, "Status"), _field(out, "Settings")) == (
        "SUCCEEDED at 2026-01-05 09:30 IST",
        "current: the configuration's settings are still the ones it used",
    )
    assert _field(out, "Coverage").startswith("86.66%: 13 of the 15 candles")
    assert _field(out, "Closed trades") == (
        "1: 1 wins, 0 losses, 0 breakeven (a net result above, below or at 0.00)"
    )
    assert _field(out, "Win rate").startswith("100.00% = winning closed trades / all closed trades x 100")
    assert _field(out, "Net result") == "37.00 (0.04% of the initial capital), after fees and slippage"
    assert _field(out, "Profit factor").startswith(f"undefined: {TARGET_ONLY} = ")
    assert _field(out, "Average loss") == "undefined: No losing trades (the mean net result of losing trades)"
    curve = _records(out.rsplit("\n\n", 1)[1])
    assert [Decimal(point["EQUITY"]) for point in curve] == [
        Decimal(100_000),
        Decimal(100_000),
        Decimal(100_003),
        *[Decimal(100_037)] * 8,
    ]
    assert err == f"Its 1 closed trades: qt backtests trades {run_id}\n{NOT_A_FORECAST}"

    assert _run(monkeypatch, ["backtests", "trades", run_id]) == 0
    out, err = capsys.readouterr()
    [trade] = _records(out)
    assert (trade["#"], trade["SIDE"], trade["QTY"], trade["REASON"], trade["OUTCOME"], trade["FLAGS"]) == (
        "1",
        "long",
        "10",
        "target",
        "win",
        "-",
    )
    assert [trade[column] for column in ("ENTRY", "EXIT", "NET")] == ["100.5", "104.2", "37.00"]
    assert err == f"Trades 1-1 of 1.\nOne trade in detail: qt backtests trade {run_id} NUMBER\n"
    assert _run(monkeypatch, ["backtests", "trade", run_id, "1"]) == 0
    out = capsys.readouterr().out
    assert _field(out, "Trade") == "1 of 1: LONG 10 units"
    assert _field(out, "Entry") == (
        "filled at 100.5 in the candle from 2026-01-05 09:19 IST; reference price 100.5, before slippage"
    )
    assert _field(out, "Exit") == (
        "TARGET: filled at 104.2 in the candle from 2026-01-05 09:20 IST; reference price 104.2"
    )
    assert _field(out, "Levels") == "stop-loss 98.05, target 104.2 (in force when it closed)"
    assert _field(out, "Entry signal") == (
        "BUY decided at 2026-01-05 09:19 IST, the close of the candle from 2026-01-05 09:18 IST"
    )
    assert [line.strip() for line in out.splitlines()[-3:]] == [
        "entry 100.1, stop-loss 98.05, targets T1 104.2",
        "reason: fast EMA crossed above slow EMA",
        "indicators: ema_fast=100",
    ]
    assert _run(monkeypatch, ["backtests", "trade", run_id, "2"]) == 1
    assert capsys.readouterr().err == f"error: backtest {run_id} has no closed trade 2: it has 1\n"

    # Other trade rules outdate the result, which stays for comparison next to the one run with them.
    assert _run(monkeypatch, [*rules, "set", *target, "--rule", "quantity=20"]) == 0
    capsys.readouterr()
    assert _run(monkeypatch, latest) == 0
    out, err = capsys.readouterr()
    assert (_field(out, "State"), _field(out, "Changed"), _field(out, "Backtest")) == (
        "OUTDATED: backtests succeeded, but the settings changed since; the latest is below",
        "trade_rules.quantity",
        f"{run_id} (OUTDATED)",
    )
    assert err == (
        f"Everything about it: qt backtests show {run_id}\n"
        f"Run one over a READY dataset (qt datasets list --instrument {ONE} --interval 1m --status ready): "
        f"qt backtests run {INDIA} Trader --instrument {ONE} --dataset DATASET\n"
        f"warning: {NO_WORKER}\n"
    )
    cli.clock.advance(timedelta(minutes=1))
    assert _run(monkeypatch, run) == 0
    rerun_id = _field(capsys.readouterr().out, "Backtest")
    cli.drain()
    assert _run(monkeypatch, latest) == 0
    out = capsys.readouterr().out
    assert (_field(out, "State"), _field(out, "Backtest"), _field(out, "Older runs")) == (
        "CURRENT: a backtest with the current settings succeeded",
        rerun_id,
        "1 succeeded with other settings, kept for comparison (qt backtests list --workspace "
        f"{INDIA} --config Trader --instrument {ONE})",
    )
    assert _run(monkeypatch, ["backtests", "list", "--workspace", INDIA, "--config", "Trader"]) == 0
    assert [
        (row["BACKTEST"], row["STATUS"], row["TRADES"], row["NET RETURN"], row["SETTINGS"])
        for row in _records(capsys.readouterr().out)
    ] == [(rerun_id, "succeeded", "1", "0.07%", "current"), (run_id, "succeeded", "1", "0.04%", "OUTDATED")]
    assert _run(monkeypatch, ["backtests", "list", "--config", "Trader"]) == 1
    assert capsys.readouterr().err == (
        "error: --workspace and --config go together: they name one saved configuration\n"
    )

    # Without trade rules of its own, the configuration cannot be backtested again.
    assert _run(monkeypatch, [*rules, "clear", *target]) == 0
    out, err = capsys.readouterr()
    assert _field(out, "In use") == "none"
    assert err == (
        "Cleared: no trade rules apply now, so it cannot be backtested until they are set "
        "(qt backtests rules set).\n"
    )
    assert _run(monkeypatch, [*rules, "clear", *target]) == 0
    assert capsys.readouterr().err == "The configuration had no trade rules of its own: nothing changed.\n"
    assert cli.remote.requests == []  # recorded candles: no provider was asked for anything


def test_a_backtest_without_trades_says_its_metrics_are_undefined(
    cli: Harness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    dataset_id = _ready_dataset(cli, monkeypatch, capsys)
    create = ["strategies", "create", INDIA, SILENT.strategy_id, "--instrument", ONE, "--label", "Silent"]
    assert _run(monkeypatch, create) == 0
    assert _run(monkeypatch, ["backtests", "rules", "set", INDIA, "Silent", *RULES]) == 0
    run = ["backtests", "run", INDIA, "Silent", "--instrument", ONE, "--dataset", dataset_id]
    assert _run(monkeypatch, run) == 0
    run_id = _field(capsys.readouterr().out, "Backtest")
    cli.drain()

    assert _run(monkeypatch, ["backtests", "show", run_id]) == 0
    out, err = capsys.readouterr()
    assert _field(out, "Closed trades") == (
        "0: 0 wins, 0 losses, 0 breakeven (a net result above, below or at 0.00)"
    )
    for label in ("Win rate", "Profit factor"):
        assert _field(out, label).startswith("undefined: No closed trades = ")
    assert (_field(out, "Average win"), _field(out, "Net result")) == (
        "undefined: No winning trades (the mean net result of winning trades)",
        "0.00 (0.00% of the initial capital), after fees and slippage",
    )
    assert err == NOT_A_FORECAST
    assert _run(monkeypatch, ["backtests", "trades", run_id]) == 0
    assert capsys.readouterr() == (
        "",
        f"No closed trades: the backtest has not succeeded, or no trade closed (qt backtests show {run_id} "
        "says which).\n",
    )
