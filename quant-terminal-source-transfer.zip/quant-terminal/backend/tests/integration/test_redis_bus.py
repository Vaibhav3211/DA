from __future__ import annotations

import pytest

from app.container import Container

pytestmark = pytest.mark.integration


async def test_stream_publish_read_and_consumer_groups(container: Container) -> None:
    bus = container.bus
    stream = "qt:test:stream"
    first = await bus.publish(stream, {"n": 1})
    await bus.publish_many([(stream, {"n": 2}), (stream, {"n": 3})])
    assert await bus.last_id(stream) != first

    messages = await bus.read({stream: "0-0"}, block_ms=None)
    assert [m.payload["n"] for m in messages] == [1, 2, 3]

    await bus.ensure_group(stream, "g", start_id="0")
    await bus.ensure_group(stream, "g", start_id="0")  # idempotent (BUSYGROUP ignored)
    batch = await bus.read_group("g", "c1", [stream], count=2, block_ms=None)
    assert [m.payload["n"] for m in batch] == [1, 2]
    await bus.ack(stream, "g", batch[0].message_id)

    # Unacknowledged entries are redelivered to the same consumer after a restart.
    pending = await bus.read_group("g", "c1", [stream], pending=True)
    assert [m.payload["n"] for m in pending] == [2]
    rest = await bus.read_group("g", "c1", [stream], block_ms=None)
    assert [m.payload["n"] for m in rest] == [3]


async def test_key_value_helpers(container: Container) -> None:
    bus = container.bus
    await bus.set_json("qt:test:a", {"v": 1})
    await bus.set_json("qt:test:b", {"v": 2}, ttl_seconds=30)
    assert await bus.get_json("qt:test:a") == {"v": 1}
    assert await bus.mget_json(["qt:test:a", "qt:test:missing", "qt:test:b"]) == [{"v": 1}, None, {"v": 2}]
    assert await bus.scan_json("qt:test:*") == {"qt:test:a": {"v": 1}, "qt:test:b": {"v": 2}}
    assert await bus.getdel_json("qt:test:a") == {"v": 1}
    assert await bus.get_json("qt:test:a") is None
    assert 0 < await bus.redis.ttl("qt:test:b") <= 30
