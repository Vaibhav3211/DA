"""``qt strategies``, ``qt risk`` and ``qt signals`` against PostgreSQL and Redis."""

from __future__ import annotations

import asyncio
import io
import re
from collections.abc import Iterator
from uuid import UUID, uuid4

import pytest
from structlog.testing import capture_logs

from app.cli import entry
from app.container import Container
from app.core.config import Settings
from app.domain.models.signal import SIGNAL_DISCLAIMER
from app.market_data.calendars.loader import load_market_calendar
from app.signals.engine import SignalEngine
from tests.integration.provider_support import LAB, FakeClock, wipe_instruments
from tests.integration.strategy_support import (
    EXAMPLE,
    example_run,
    load_instrument,
    proposal,
    wipe_strategies,
)

pytestmark = pytest.mark.integration

ALPHA, BRAVO, CHARLIE = (f"SIM:CASH:EQUITY:{symbol}" for symbol in ("ALPHA", "BRAVO", "CHARLIE"))
DEPLOYMENT_HEADERS = [
    "WORKSPACE",
    "CONFIGURATION",
    "STRATEGY",
    "VERSION",
    "SCOPE",
    "LIVE SIGNALS",
    "MONITORING",
    "LAST RUN",
]
NO_WORKER = "The strategy worker is not running (no recent heartbeat); start qt-strategy-worker"
SIMULATED = "Its instruments use simulated data: its signals are informational only"


async def _reset_state(settings: Settings) -> None:
    container = Container.create(settings)
    try:
        await wipe_strategies(container.db)
        await wipe_instruments(container.db)
        await container.bus.redis.flushdb()
    finally:
        await container.close()


@pytest.fixture
def cli(migrated_database: Settings, monkeypatch: pytest.MonkeyPatch) -> Iterator[Settings]:
    monkeypatch.setattr("app.cli._console.get_settings", lambda: migrated_database)
    monkeypatch.setattr(entry, "configure_logging", lambda *_args, **_kwargs: None)
    with capture_logs():  # a real `qt` prints only warnings, to stderr
        asyncio.run(_reset_state(migrated_database))
        yield migrated_database
        asyncio.run(_reset_state(migrated_database))  # leave the shared test database as seeded


def _run(monkeypatch: pytest.MonkeyPatch, args: list[str]) -> int:
    monkeypatch.setattr("sys.stdin", io.StringIO(""))
    return entry.main(args)


def _field(output: str, label: str) -> str:
    """The value of the ``label  value`` row in ``output``."""
    for line in output.splitlines():
        if line.startswith(f"{label}  "):
            return line[len(label) :].strip()
    pytest.fail(f"no {label!r} row in:\n{output}")


def _continued(output: str, label: str) -> list[str]:
    """The values of the unlabelled rows that follow the ``label`` row."""
    lines = output.splitlines()
    start = next(index for index, line in enumerate(lines) if line.startswith(f"{label}  "))
    values: list[str] = []
    for line in lines[start + 1 :]:
        if not line.startswith(" "):
            break
        values.append(line.strip())
    return values


def _table(output: str) -> list[list[str]]:
    return [re.split(r"\s{2,}", line.strip()) for line in output.splitlines() if line.strip()]


def _section(output: str, title: str) -> str:
    """The lines under ``title:`` up to the next blank line."""
    return output.split(f"\n{title}", 1)[1].split(":\n", 1)[1].split("\n\n", 1)[0]


async def _emit_signals(settings: Settings) -> dict[str, UUID]:
    """An active BUY on ALPHA, and a BUY on BRAVO blocked for its stale data, from the example run."""
    container = Container.create(settings)
    try:
        clock = FakeClock()  # 09:30 IST on 2026-01-05
        run = await example_run(container, clock.now)
        calendar = await load_market_calendar(container.db)
        engine = SignalEngine(container.db, container.bus, container.settings, calendar, clock=clock)
        alpha, bravo = [await load_instrument(container.db, key) for key in (ALPHA, BRAVO)]
        active, blocked = await engine.submit(
            run, [proposal(alpha, clock.now), proposal(bravo, clock.now, age_seconds=600)]
        )
        assert active.signal_id is not None
        assert blocked.signal_id is not None
        return {"active": active.signal_id, "blocked": blocked.signal_id}
    finally:
        await container.close()


def test_a_strategy_goes_from_the_catalogue_to_saved_configurations_and_back(
    cli: Settings, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(monkeypatch, ["strategies", "list"]) == 0
    assert capsys.readouterr().err == "The catalogue is empty: run qt strategies sync.\n"
    assert _run(monkeypatch, ["strategies", "sync"]) == 0
    assert _field(capsys.readouterr().out, "Added") == EXAMPLE
    assert _run(monkeypatch, ["strategies", "sync"]) == 0
    assert capsys.readouterr().out == "The catalogue is up to date.\n"

    assert _run(monkeypatch, ["strategies", "show", EXAMPLE]) == 0
    shown = capsys.readouterr().out
    version = _field(shown, "Version")
    assert (_field(shown, "Markets"), _field(shown, "Candles"), _field(shown, "Configurations")) == (
        "india, lab",
        "1m",
        "0 (0 enabled)",
    )
    assert (_field(shown, "Exchanges"), _field(shown, "Data needed")) == ("any in its markets", "prices only")
    _rows, settings_block, conditions_block = shown.split("\n\n")
    settings = {row[0]: row[1:] for row in _table(settings_block)}
    assert settings["SETTING"] == ["DEFAULT", "ALLOWED", "DESCRIPTION"]
    assert settings["valid_for_minutes"][0] == "15"
    conditions = {row[0]: row[1] for row in _table(conditions_block)}
    assert conditions == {
        "SIGNAL": "INPUTS",
        "BUY": "fast, slow, atr, close",
        "SELL": "fast, slow, atr, close",
    }

    assert _run(monkeypatch, ["instruments", "refresh", "simulator"]) == 0
    assert _run(monkeypatch, ["workspaces", "add", LAB, "simulator", ALPHA, BRAVO]) == 0
    capsys.readouterr()
    create = ["strategies", "create", LAB, EXAMPLE]
    # The whole workspace is never assumed: the scope is chosen explicitly, one way.
    for options, problem in (
        ([], "one of the arguments --instrument --whole-workspace is required"),
        (["--instrument", ALPHA, "--whole-workspace"], "not allowed with argument --instrument"),
    ):
        with pytest.raises(SystemExit) as exited:
            _run(monkeypatch, [*create, *options])
        assert exited.value.code == 2
        assert problem in capsys.readouterr().err
    refused = [
        (["--instrument", CHARLIE], f"error: not instruments of workspace '{LAB}': {CHARLIE}"),
        (["--whole-workspace", "--set", "no_such_setting=1"], "no_such_setting"),
        (["--whole-workspace", "--set", "valid_for_minutes=-5"], "valid_for_minutes"),
        (
            ["--whole-workspace", "--set", "valid_for_minutes"],
            "error: --set expects KEY=VALUE, not 'valid_for_minutes'",
        ),
        (["--whole-workspace", "--label", "   "], "error: A label needs 1 to 80 printable characters"),
    ]
    for options, problem in refused:
        assert _run(monkeypatch, [*create, *options]) == 1
        assert problem in capsys.readouterr().err
    assert _run(monkeypatch, ["strategies", "deployments"]) == 0
    assert capsys.readouterr().err.startswith("No saved configurations.")

    # Instruments by key in any case or by id, in the order given, each once; live signals start off.
    chosen = [*create, "--set", "valid_for_minutes=30", "--instrument", BRAVO, ALPHA.lower(), BRAVO]
    assert _run(monkeypatch, chosen) == 0
    out, err = capsys.readouterr()
    assert (_field(out, "Configuration"), _field(out, "Strategy"), _field(out, "Live signals")) == (
        EXAMPLE,
        f"{EXAMPLE} {version}",
        "off",
    )
    assert (_field(out, "Monitoring"), _field(out, "Warnings")) == ("stopped", SIMULATED)
    assert (_field(out, "Scope"), _continued(out, "Scope")) == ("2 instruments", [BRAVO, ALPHA])
    assert "valid_for_minutes=30" in _field(out, "Settings")
    assert err == f"Its live signals are off. Turn them on: qt strategies enable {LAB} {EXAMPLE}\n"

    # Another configuration of the same strategy: a label in use is refused, and the default is numbered.
    assert _run(monkeypatch, [*create, "--whole-workspace", "--label", EXAMPLE.upper()]) == 1
    assert capsys.readouterr().err == (
        f"error: Workspace '{LAB}' already has a configuration labelled '{EXAMPLE.upper()}'; "
        "choose another label\n"
    )
    assert _run(monkeypatch, [*create, "--whole-workspace"]) == 0
    out, err = capsys.readouterr()
    second = f"{EXAMPLE} 2"
    assert (_field(out, "Configuration"), _field(out, "Scope")) == (
        second,
        "the whole workspace, including instruments added later",
    )
    assert "valid_for_minutes=15" in _field(out, "Settings")
    assert err == f'Its live signals are off. Turn them on: qt strategies enable {LAB} "{second}"\n'

    # Without a strategy worker, monitoring has failed and says why; asking again changes nothing.
    assert _run(monkeypatch, ["strategies", "enable", LAB, EXAMPLE]) == 0
    out, err = capsys.readouterr()
    assert _field(out, "Live signals").startswith("on, by cli since ")
    assert (_field(out, "Monitoring"), _field(out, "Because")) == ("failed", NO_WORKER)
    assert err == (
        "Its live signals are on. The strategy worker (qt-strategy-worker) monitors it on the server, "
        f"whether or not a chart is open, until you turn them off: qt strategies disable {LAB} {EXAMPLE}\n"
    )
    assert _run(monkeypatch, ["strategies", "enable", LAB, EXAMPLE.upper()]) == 0
    again = capsys.readouterr().out
    assert [_field(again, label) for label in ("ID", "Live signals")] == [
        _field(out, label) for label in ("ID", "Live signals")
    ]

    # The same version and settings on an overlapping scope would propose every signal twice.
    assert _run(monkeypatch, ["strategies", "update", LAB, second, "--set", "valid_for_minutes=30"]) == 0
    out, err = capsys.readouterr()
    assert ("valid_for_minutes=30" in _field(out, "Settings"), err) == (True, "")
    assert _run(monkeypatch, ["strategies", "enable", LAB, second]) == 1
    assert capsys.readouterr().err == (
        f"error: Configuration '{EXAMPLE}' already runs {EXAMPLE} {version} with the same settings on "
        f"{BRAVO}, {ALPHA}; stop its live signals first, or change this configuration's settings or scope\n"
    )
    assert _run(monkeypatch, ["strategies", "deployments", "--workspace", LAB]) == 0
    out, err = capsys.readouterr()
    [headers, *rows] = _table(out)
    assert headers == DEPLOYMENT_HEADERS
    assert rows == [
        [LAB, EXAMPLE, EXAMPLE, version, "2 instruments", "on", "failed", "-"],
        [LAB, second, EXAMPLE, version, "whole workspace", "off", "stopped", "-"],
    ]
    assert err == "\n1 blocked or failed; see why: qt strategies status WORKSPACE CONFIGURATION\n"
    assert _run(monkeypatch, ["strategies", "archive", LAB, EXAMPLE]) == 1
    assert capsys.readouterr().err == (
        f"error: Stop the live signals of '{EXAMPLE}' in workspace '{LAB}' before archiving it\n"
    )

    # Saved again while on: renamed, the whole workspace, the defaults; the worker reloads it.
    renamed = "Trend follower"
    reset = ["strategies", "update", LAB, EXAMPLE, "--whole-workspace", "--reset-config", "--label", renamed]
    assert _run(monkeypatch, reset) == 0
    out, err = capsys.readouterr()
    assert (_field(out, "Configuration"), _field(out, "Scope"), _field(out, "Live signals")[:3]) == (
        renamed,
        "the whole workspace, including instruments added later",
        "on,",
    )
    assert "valid_for_minutes=15" in _field(out, "Settings")
    assert err == "Its live signals are on: the strategy worker picks up the change by itself.\n"
    assert _run(monkeypatch, ["strategies", "status", LAB, renamed.upper()]) == 0
    assert _field(capsys.readouterr().out, "Settings") == _field(out, "Settings")
    assert _run(monkeypatch, ["strategies", "runs", "--config", renamed]) == 1
    assert capsys.readouterr().err == "error: --config needs --workspace\n"
    assert _run(monkeypatch, ["strategies", "runs", "--workspace", LAB, "--config", renamed]) == 0
    assert capsys.readouterr().err == "No runs yet.\n"

    assert _run(monkeypatch, ["strategies", "disable", LAB, renamed]) == 0
    out, err = capsys.readouterr()
    assert (_field(out, "Live signals")[:9], _field(out, "Monitoring")) == ("off since", "stopped")
    assert err == "Its live signals are off, so monitoring stops. Its runs and signals stay.\n"

    # A label a shell would mangle is suggested by id. Archived, it frees its label; its id still works.
    odd = "crossover (fast)"
    assert _run(monkeypatch, [*create, "--instrument", ALPHA, "--label", f"  {odd} "]) == 0
    out, err = capsys.readouterr()
    odd_id = _field(out, "ID")
    assert _field(out, "Configuration") == odd
    assert err == f"Its live signals are off. Turn them on: qt strategies enable {LAB} {odd_id}\n"
    assert _run(monkeypatch, ["strategies", "archive", LAB, odd]) == 0
    assert capsys.readouterr().out.startswith(f"Configuration '{odd}' of workspace '{LAB}' is archived (")
    assert _run(monkeypatch, ["strategies", "status", LAB, odd]) == 1
    assert capsys.readouterr().err.startswith(
        f"error: Workspace '{LAB}' has no saved configuration '{odd}' (its configurations: "
    )
    assert _run(monkeypatch, ["strategies", "status", LAB, odd_id]) == 0
    assert _field(capsys.readouterr().out, "Live signals").startswith("off; archived ")
    for action, problem in (
        ("update", f"error: Configuration '{odd}' is archived; save a new configuration instead\n"),
        ("enable", f"error: Cannot turn on live signals for '{odd}' in workspace '{LAB}': it is archived\n"),
    ):
        assert _run(monkeypatch, ["strategies", action, LAB, odd_id]) == 1
        assert capsys.readouterr().err == problem
    for options, listed in (([], [renamed, second]), (["--all"], [renamed, second, odd])):
        assert _run(monkeypatch, ["strategies", "deployments", *options]) == 0
        assert sorted(row[1] for row in _table(capsys.readouterr().out)[1:]) == sorted(listed)

    assert _run(monkeypatch, ["strategies", "list"]) == 0
    [headers, row] = _table(capsys.readouterr().out)
    assert (headers[-1], row[0], row[-1]) == ("CONFIGURATIONS", EXAMPLE, "2 (0 enabled)")
    assert _run(monkeypatch, ["strategies", "status", LAB, "no.such_configuration"]) == 1
    assert capsys.readouterr().err.startswith(f"error: Workspace '{LAB}' has no saved configuration ")


def test_risk_rules_are_tuned_paused_resumed_and_reset(
    cli: Settings, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(monkeypatch, ["risk", "rules"]) == 0
    [headers, *rows] = _table(capsys.readouterr().out)
    rules = {row[0]: row[1:] for row in rows}
    assert headers == ["RULE", "ENABLED", "MANDATORY", "SET BY", "PARAMETERS"]
    assert rules["data_quality"][:2] == ["yes", "yes"]
    assert rules["frequency"][:2] == ["yes", "no"]

    tune = ["risk", "set", "frequency", "--workspace", LAB, "--param", "max_signals=5"]
    assert _run(monkeypatch, tune) == 0
    out = capsys.readouterr().out
    assert (_field(out, "Scope"), _field(out, "Enabled")) == (f"workspace {LAB}", "yes")
    assert "max_signals=5" in _field(out, "Parameters")
    assert "max_signals=3" in _field(out, "Defaults")
    assert _field(out, "Changed").startswith("by cli at ")

    refused = [
        (["set", "data_quality", "--disable"], "data_quality"),
        (["set", "frequency"], "error: nothing to change: give --enable, --disable or --param KEY=VALUE"),
        (["set", "frequency", "--param", "max_signals=many"], "max_signals"),
        (["show", "no_such_rule"], "no_such_rule"),
        (["pause", LAB, "--reason", "   "], "error: --reason cannot be blank"),
    ]
    for args, problem in refused:
        assert _run(monkeypatch, ["risk", *args]) == 1
        assert problem in capsys.readouterr().err

    assert _run(monkeypatch, ["risk", "pause", LAB, "--reason", "  results   day "]) == 0
    out = capsys.readouterr().out
    assert (_field(out, "Rule"), _field(out, "Enabled"), _field(out, "Parameters")) == (
        "workspace_pause",
        "yes",
        "paused=true, reason=results day",
    )
    assert _run(monkeypatch, ["risk", "resume", LAB]) == 0
    out = capsys.readouterr().out
    assert (_field(out, "Enabled"), _field(out, "Parameters")) == ("yes", "paused=false, reason=null")

    assert _run(monkeypatch, ["risk", "reset", "frequency", "--workspace", LAB]) == 0
    out = capsys.readouterr().out
    assert _field(out, "Parameters") == _field(out, "Defaults")
    assert _run(monkeypatch, ["risk", "show", "frequency", "--workspace", LAB]) == 0
    assert "max_signals=3" in _field(capsys.readouterr().out, "Parameters")


def test_signals_are_listed_filtered_paged_and_explained(
    cli: Settings, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(monkeypatch, ["instruments", "refresh", "simulator"]) == 0
    ids = asyncio.run(_emit_signals(cli))
    capsys.readouterr()

    def listed(*options: str) -> dict[str, list[str]]:
        """The listed signals by symbol, with their other columns."""
        assert _run(monkeypatch, ["signals", "list", *options]) == 0
        output = capsys.readouterr()
        assert output.err == ""
        [headers, *rows] = _table(output.out)
        assert headers[:4] == ["GENERATED", "SIGNAL", "WORKSPACE", "SYMBOL"]
        return {row[3]: row for row in rows}

    everything = listed()
    assert sorted(everything) == ["ALPHA", "BRAVO"]
    alpha = everything["ALPHA"]
    assert (alpha[0], alpha[1], alpha[2], alpha[4:8]) == (
        "2026-01-05 09:30 IST",
        str(ids["active"]),
        LAB,
        [EXAMPLE, "buy", "active", "no"],
    )
    assert (alpha[8], alpha[9], alpha[-1]) == ("100.1", "98.05", "simulator")  # no trailing zeros
    assert list(listed("--status", "blocked")) == ["BRAVO"]
    assert list(listed("--open", "--instrument", ALPHA.lower())) == ["ALPHA"]
    filtered = listed("--workspace", LAB, "--strategy", EXAMPLE, "--type", "buy", "--no-actionable")
    assert sorted(filtered) == ["ALPHA", "BRAVO"]
    assert sorted(listed("--since", "2026-01-05", "--until", "2026-01-05")) == ["ALPHA", "BRAVO"]  # IST days
    for options in (
        ["--since", "2026-01-06"],
        ["--until", "2026-01-04"],
        ["--actionable"],
        ["--type", "sell"],
    ):
        assert _run(monkeypatch, ["signals", "list", *options]) == 0
        assert capsys.readouterr() == ("", "No signals match.\n")

    assert _run(monkeypatch, ["signals", "list", "--limit", "1"]) == 0
    first = capsys.readouterr()
    match = re.fullmatch(r"More signals: add --cursor (\S+)\n", first.err)
    assert match is not None
    second = listed("--limit", "1", "--cursor", match.group(1))
    assert {_table(first.out)[1][3], *second} == {"ALPHA", "BRAVO"}

    refused = [
        (["--since", "2026-01-06", "--until", "2026-01-05"], "error: --since must not be after --until\n"),
        (["--limit", "0"], "error: --limit: "),
        (["--cursor", "bogus"], "error: The cursor is not one a signal list returned\n"),
        (["--workspace", "no-such-workspace"], "error: "),
    ]
    for options, problem in refused:
        assert _run(monkeypatch, ["signals", "list", *options]) == 1
        assert capsys.readouterr().err.startswith(problem)

    assert _run(monkeypatch, ["signals", "show", str(ids["blocked"])]) == 0
    shown = capsys.readouterr().out
    assert (_field(shown, "Data source"), _field(shown, "Status"), _field(shown, "Actionable")) == (
        "simulator (simulated data: never actionable)",
        "blocked",
        "no",
    )
    assert (_field(shown, "Entry"), _field(shown, "Stop loss"), _field(shown, "Targets")) == (
        "100.1",
        "98.05",
        "T1 104.2",
    )
    checks = {row[0]: row[1:] for row in _table(_section(shown, "Risk checks"))}
    assert checks["RULE"] == ["RESULT", "MESSAGE"]
    assert checks["data_quality"][0] == "BLOCK"
    assert "source data is 600s old (limit 120s)" in checks["data_quality"][1]
    assert [row[1:] for row in _table(_section(shown, "History"))[1:]] == [
        ["generated", "-", "generated"],
        ["blocked", "generated", "blocked"],
    ]
    assert shown.endswith(f"\n\n{SIGNAL_DISCLAIMER}\n")
    assert _run(monkeypatch, ["signals", "show", str(uuid4())]) == 1
    assert capsys.readouterr().err.startswith("error: Signal ")

    assert _run(monkeypatch, ["strategies", "runs", "--workspace", LAB, "--config", EXAMPLE]) == 0
    [headers, run] = _table(capsys.readouterr().out)
    assert headers[:6] == ["STARTED", "WORKSPACE", "CONFIGURATION", "STRATEGY", "VERSION", "STATUS"]
    assert (run[0], run[1], run[2], run[3], run[5], run[6]) == (
        "2026-01-05 09:30 IST",
        LAB,
        EXAMPLE,
        EXAMPLE,
        "running",
        "0",
    )
