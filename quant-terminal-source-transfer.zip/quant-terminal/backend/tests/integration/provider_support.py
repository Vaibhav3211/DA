"""Helpers for provider account and login integration tests.

Provider HTTP calls go to ``httpx.MockTransport`` handlers and the configured provider hosts use
the reserved ``.test`` domain, so no test can reach Zerodha or Groww.
"""

from __future__ import annotations

import base64
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

import httpx
import pytest
import sqlalchemy as sa
from sqlalchemy import select

from app.container import Container
from app.core.config import AppEnv, Settings
from app.core.errors import AppError
from app.core.security import SecretBox
from app.domain.enums import Provider, SubscriptionMode
from app.domain.events import WorkerCommand
from app.persistence.database import Database
from app.persistence.models import (
    AuditLogRow,
    InstrumentProviderMappingRow,
    InstrumentRow,
    ProviderAccountRow,
    ProviderCapabilityRow,
    ProviderConnectionEventRow,
    ProviderTokenMetadataRow,
    WorkspaceInstrumentRow,
    WorkspaceRow,
)
from app.services.instruments import AUDIT_ENTITY as INSTRUMENTS_AUDIT_ENTITY
from app.services.provider_accounts import ProviderAccountService
from app.streaming.redis_bus import RedisBus, Streams

NOW = datetime(2026, 1, 5, 4, 0, tzinfo=UTC)  # 09:30 IST on a trading day
ACTOR = "user:alice"
REDIRECT_URL = "http://127.0.0.1:8000/api/v1/providers/zerodha/callback"
KITE_LOGIN_URL = "https://kite.test/connect/login"
KITE_BASE_URL = "https://kite.test"
GROWW_BASE_URL = "https://groww.test/v1"
LAB = "simulation-lab"  # an enabled seeded workspace

# (workspace slug, symbol, source provider, subscription mode, pinned account)
type WorkspaceEntry = tuple[str, str, Provider, SubscriptionMode, UUID | None]


@dataclass
class FakeClock:
    now: datetime = NOW

    def __call__(self) -> datetime:
        return self.now

    def advance(self, delta: timedelta) -> None:
        self.now += delta


def provider_settings(settings: Settings, **overrides: Any) -> Settings:
    """Settings without .env provider credentials and with unreachable provider hosts."""
    values: dict[str, Any] = {
        "app_env": AppEnv.DEVELOPMENT,
        "zerodha_api_key": None,
        "zerodha_api_secret": None,
        "zerodha_redirect_url": REDIRECT_URL,
        "zerodha_login_url": KITE_LOGIN_URL,
        "zerodha_api_base_url": KITE_BASE_URL,
        "groww_api_key": None,
        "groww_api_secret": None,
        "groww_api_base_url": GROWW_BASE_URL,
    }
    values.update(overrides)
    return settings.model_copy(update=values)


def account_service(
    container: Container, clock: FakeClock, *, secret_box: SecretBox | None = None, **overrides: Any
) -> ProviderAccountService:
    """An account service on the test database; ``secret_box`` defaults to the container's."""
    return ProviderAccountService(
        container.db,
        container.bus,
        provider_settings(container.settings, **overrides),
        secret_box or container.secret_box,
        clock=clock,
    )


async def wipe_providers(db: Database) -> None:
    """Remove every provider account (credentials and token metadata cascade), event and override."""
    async with db.transaction() as session:
        await session.execute(sa.delete(ProviderConnectionEventRow))
        await session.execute(sa.delete(ProviderCapabilityRow))
        await session.execute(sa.delete(ProviderAccountRow))


async def wipe_instruments(db: Database) -> None:
    """Remove every instrument (mappings first) and the audit entries of refreshes."""
    async with db.transaction() as session:
        await session.execute(sa.delete(InstrumentProviderMappingRow))
        await session.execute(sa.delete(InstrumentRow))
        await session.execute(
            sa.delete(AuditLogRow).where(AuditLogRow.entity_type == INSTRUMENTS_AUDIT_ENTITY)
        )


async def enabled_account(accounts: ProviderAccountService, provider: Provider) -> UUID:
    view = await accounts.create(provider, f"{provider.value} main", actor=ACTOR)
    await accounts.set_enabled(view.id, True, actor=ACTOR)
    return view.id


async def add_rows(container: Container, symbols: dict[str, UUID], rows: list[WorkspaceEntry]) -> None:
    """Add instruments (by symbol) to seeded workspaces (by slug), in the order given."""
    async with container.db.transaction() as session:
        workspaces = dict((await session.execute(select(WorkspaceRow.slug, WorkspaceRow.id))).all())
        session.add_all(
            WorkspaceInstrumentRow(
                workspace_id=workspaces[slug],
                instrument_id=symbols[symbol],
                provider=provider,
                account_id=pin,
                subscription_mode=mode,
                added_at=NOW + timedelta(seconds=n),
                added_by=ACTOR,
            )
            for n, (slug, symbol, provider, mode, pin) in enumerate(rows)
        )


async def store_token(
    accounts: ProviderAccountService,
    account_id: UUID,
    token: str,
    *,
    expires_at: datetime,
    user_ref: str | None = None,
) -> None:
    """Store an access token the way a completed login does."""
    async with accounts.db.transaction() as session:
        row = await accounts.lock_account(session, account_id)
        await accounts.store_access_token(
            session, row, token=token, expires_at=expires_at, user_ref=user_ref, actor=ACTOR
        )


async def failure[E: AppError](call: Awaitable[object], error: type[E], code: str) -> E:
    """Await ``call``, which must raise ``error`` with the given error code."""
    with pytest.raises(error) as excinfo:
        await call
    assert excinfo.value.code == code, f"{excinfo.value.code}: {excinfo.value.message}"
    return excinfo.value


async def worker_commands(bus: RedisBus) -> list[WorkerCommand]:
    messages = await bus.read({Streams.COMMANDS: "0-0"}, block_ms=None)
    return [WorkerCommand.model_validate(message.payload) for message in messages]


async def audit_entries(db: Database, entity_id: UUID) -> list[AuditLogRow]:
    async with db.session() as session:
        rows = await session.scalars(
            select(AuditLogRow).where(AuditLogRow.entity_id == str(entity_id)).order_by(AuditLogRow.id)
        )
        return list(rows)


async def token_metadata(db: Database, account_id: UUID) -> list[ProviderTokenMetadataRow]:
    async with db.session() as session:
        rows = await session.scalars(
            select(ProviderTokenMetadataRow)
            .where(ProviderTokenMetadataRow.account_id == account_id)
            .order_by(ProviderTokenMetadataRow.issued_at, ProviderTokenMetadataRow.fingerprint)
        )
        return list(rows)


# ---- provider HTTP fakes ----------------------------------------------------------------------------

Reply = Callable[[httpx.Request], httpx.Response]


@dataclass
class FakeProvider:
    """Records requests and answers them by (method, path); unknown routes get a 404."""

    routes: dict[tuple[str, str], Reply] = field(default_factory=dict)
    requests: list[httpx.Request] = field(default_factory=list)

    def __call__(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        reply = self.routes.get((request.method, request.url.path))
        if reply is None:
            return httpx.Response(404, json={"status": "error", "message": "no such route"})
        return reply(request)

    @property
    def transport(self) -> httpx.MockTransport:
        return httpx.MockTransport(self)

    def paths(self) -> list[tuple[str, str]]:
        return [(request.method, request.url.path) for request in self.requests]


def kite_ok(data: object) -> Reply:
    return lambda _request: httpx.Response(200, json={"status": "success", "data": data})


def kite_error(status: int, error_type: str, message: str) -> Reply:
    body = {"status": "error", "error_type": error_type, "message": message}
    return lambda _request: httpx.Response(status, json=body)


def groww_ok(payload: object) -> Reply:
    return lambda _request: httpx.Response(200, json={"status": "SUCCESS", "payload": payload})


def groww_failure(status: int, code: str, message: str) -> Reply:
    body = {"status": "FAILURE", "error": {"code": code, "message": message}}
    return lambda _request: httpx.Response(status, json=body)


def groww_jwt(expires_at: datetime) -> str:
    """A JWT-shaped Groww access token with an ``exp`` claim (the signature is not checked)."""

    def segment(value: object) -> str:
        return base64.urlsafe_b64encode(json.dumps(value).encode()).rstrip(b"=").decode()

    return f"{segment({'alg': 'HS256'})}.{segment({'exp': int(expires_at.timestamp())})}.c2lnbmF0dXJl"


def csv_reply(data: bytes) -> Reply:
    return lambda _request: httpx.Response(200, content=data, headers={"content-type": "text/csv"})


# ---- instrument dumps ------------------------------------------------------------------------------

KITE_HEADER = (
    "instrument_token,exchange_token,tradingsymbol,name,last_price,expiry,strike,tick_size,lot_size,"
    "instrument_type,segment,exchange"
)


def kite_equity(
    token: int, symbol: str, name: str = "", *, exchange_token: int, tick: str = "0.05", lot: int = 1
) -> str:
    """One NSE equity row of a Kite instrument dump."""
    return f"{token},{exchange_token},{symbol},{name},0,,0,{tick},{lot},EQ,NSE,NSE"


def kite_dump(*rows: str) -> bytes:
    return ("\n".join([KITE_HEADER, *rows]) + "\n").encode()
