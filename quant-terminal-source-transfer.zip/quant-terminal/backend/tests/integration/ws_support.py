"""An in-process WebSocket client of the app, run in the test's event loop (httpx has no WebSocket)."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Iterable, MutableMapping
from typing import Any, Self

from fastapi import FastAPI

TIMEOUT_SECONDS = 5.0


class WsClosed(Exception):
    """The app closed the connection, or refused the handshake."""

    def __init__(self, code: int, reason: str) -> None:
        super().__init__(f"closed with {code} {reason!r}")
        self.code = code
        self.reason = reason


class WsConnection:
    """One connection, served by the app's ASGI callable in a task.

    ``outbox_size`` bounds the events the app can send before the test takes them, as a client that
    reads slowly does; 0 is unbounded.
    """

    def __init__(
        self,
        app: FastAPI,
        path: str,
        *,
        cookie: str | None = None,
        origin: str | None = None,
        outbox_size: int = 0,
    ) -> None:
        headers = [(b"host", b"testserver")]
        if origin is not None:
            headers.append((b"origin", origin.encode()))
        if cookie is not None:
            headers.append((b"cookie", cookie.encode()))
        self._app = app
        self._scope: dict[str, Any] = {
            "type": "websocket",
            "asgi": {"version": "3.0", "spec_version": "2.4"},
            "http_version": "1.1",
            "scheme": "ws",
            "server": ("testserver", 80),
            "client": ("127.0.0.1", 50123),
            "root_path": "",
            "path": path,
            "raw_path": path.encode(),
            "query_string": b"",
            "headers": headers,
            "subprotocols": [],
        }
        self._inbox: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._outbox: asyncio.Queue[dict[str, Any]] = asyncio.Queue(outbox_size)
        self._task: asyncio.Task[None] | None = None

    async def __aenter__(self) -> Self:
        self._task = asyncio.create_task(self._app(self._scope, self._inbox.get, self._send))
        await self._inbox.put({"type": "websocket.connect"})
        message = await self._next()
        if message["type"] == "websocket.close":
            await self._finish()
            raise WsClosed(message.get("code", 1000), message.get("reason") or "")
        assert message["type"] == "websocket.accept", message
        return self

    async def __aexit__(self, *_: object) -> None:
        await self._finish()

    async def send_json(self, message: Any) -> None:
        await self.send_text(json.dumps(message))

    async def send_text(self, text: str) -> None:
        await self._inbox.put({"type": "websocket.receive", "text": text})

    async def send_bytes(self, data: bytes) -> None:
        await self._inbox.put({"type": "websocket.receive", "bytes": data})

    async def receive(self) -> dict[str, Any]:
        """The next event the app sent. Raises :class:`WsClosed` once the app has closed."""
        message = await self._next()
        if message["type"] == "websocket.close":
            raise WsClosed(message.get("code", 1000), message.get("reason") or "")
        assert message["type"] == "websocket.send", message
        event: dict[str, Any] = json.loads(message["text"])
        return event

    async def expect(self, event_type: str, *, skip: Iterable[str] = ("heartbeat",)) -> dict[str, Any]:
        """The next event, which must be of ``event_type`` once events of the ``skip`` types are passed."""
        skipped = set(skip)
        while True:
            event = await self.receive()
            if event["type"] == event_type:
                return event
            assert event["type"] in skipped, f"expected {event_type}, got {event}"

    async def closed(self) -> WsClosed:
        """How the app closed the connection, passing any events it sent first."""
        while True:
            try:
                await self.receive()
            except WsClosed as closed:
                return closed

    async def _send(self, message: MutableMapping[str, Any]) -> None:
        await self._outbox.put(dict(message))

    async def _next(self) -> dict[str, Any]:
        assert self._task is not None
        getter = asyncio.ensure_future(self._outbox.get())
        done, _ = await asyncio.wait(
            {getter, self._task}, timeout=TIMEOUT_SECONDS, return_when=asyncio.FIRST_COMPLETED
        )
        if getter.done():
            return getter.result()
        getter.cancel()
        if not self._outbox.empty():
            return self._outbox.get_nowait()
        if self._task in done:
            self._task.result()  # raises what the app failed with
            raise AssertionError("the app ended the connection without closing it")
        raise TimeoutError(f"the app sent nothing within {TIMEOUT_SECONDS}s")

    async def _finish(self) -> None:
        """Disconnect (if still connected) and wait for the app to be done with the connection."""
        task = self._task
        if task is None:
            return
        if not task.done():
            await self._inbox.put({"type": "websocket.disconnect", "code": 1000})
        async with asyncio.timeout(TIMEOUT_SECONDS):
            while not task.done():
                while not self._outbox.empty():  # an app blocked on a full outbox can finish
                    self._outbox.get_nowait()
                await asyncio.wait({task}, timeout=0.05)
        task.result()
