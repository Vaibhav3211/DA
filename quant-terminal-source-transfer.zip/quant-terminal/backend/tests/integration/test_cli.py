"""The ``qt`` commands against the integration database (they run their own event loop)."""

from __future__ import annotations

import asyncio
import io
from collections.abc import Iterator
from dataclasses import dataclass

import pytest
from sqlalchemy import delete, func, select

from app.cli import entry
from app.container import Container
from app.core.config import Settings
from app.core.errors import AuthenticationError
from app.persistence.models import AuditLogRow, UserRow
from app.services.audit import CLI_ACTOR
from app.services.auth_service import AuthService
from app.services.kill_switch import KillSwitchService

pytestmark = pytest.mark.integration

FIRST_PASSWORD = "cli-first-password-1"
SECOND_PASSWORD = "cli-second-password-2"


@dataclass(frozen=True)
class CliHarness:
    settings: Settings
    audit_watermark: int  # audit rows written by the test have larger ids


async def _reset_state(settings: Settings) -> int:
    container = Container.create(settings)
    try:
        async with container.db.transaction() as session:
            await session.execute(delete(UserRow))
        await KillSwitchService(container.db, container.bus).set(engaged=False, reason=None, actor="test")
        await container.bus.redis.flushdb()
        async with container.db.session() as session:
            return int(await session.scalar(select(func.coalesce(func.max(AuditLogRow.id), 0))) or 0)
    finally:
        await container.close()


@pytest.fixture
def cli(migrated_database: Settings, monkeypatch: pytest.MonkeyPatch) -> Iterator[CliHarness]:
    monkeypatch.setattr("app.cli._console.get_settings", lambda: migrated_database)
    monkeypatch.setattr(entry, "configure_logging", lambda *_args, **_kwargs: None)
    yield CliHarness(migrated_database, asyncio.run(_reset_state(migrated_database)))
    asyncio.run(_reset_state(migrated_database))  # leave the shared test database as seeded


def _run(monkeypatch: pytest.MonkeyPatch, args: list[str], stdin: str = "") -> int:
    monkeypatch.setattr("sys.stdin", io.StringIO(stdin))
    return entry.main(args)


async def _login_works(settings: Settings, username: str, password: str) -> bool:
    container = Container.create(settings)
    try:
        await AuthService(container.db, container.bus, settings).login(
            username, password, client_ip="127.0.0.1"
        )
    except AuthenticationError:
        return False
    finally:
        await container.close()
    return True


async def _session_token(settings: Settings, username: str, password: str) -> str:
    container = Container.create(settings)
    try:
        token, _user = await AuthService(container.db, container.bus, settings).login(
            username, password, client_ip="127.0.0.1"
        )
        return token
    finally:
        await container.close()


async def _session_is_valid(settings: Settings, token: str) -> bool:
    container = Container.create(settings)
    try:
        return await AuthService(container.db, container.bus, settings).resolve(token) is not None
    finally:
        await container.close()


async def _cli_audit_actions(harness: CliHarness) -> list[str]:
    container = Container.create(harness.settings)
    try:
        async with container.db.session() as session:
            rows = await session.scalars(
                select(AuditLogRow.action)
                .where(AuditLogRow.actor == CLI_ACTOR, AuditLogRow.id > harness.audit_watermark)
                .order_by(AuditLogRow.id)
            )
            return list(rows)
    finally:
        await container.close()


def test_local_user_lifecycle(
    cli: CliHarness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    settings = cli.settings
    assert _run(monkeypatch, ["check-config"]) == 1
    assert "MISSING: run `qt create-admin`" in capsys.readouterr().out

    assert (
        _run(monkeypatch, ["create-admin", "--username", " Admin ", "--password-stdin"], FIRST_PASSWORD) == 0
    )
    assert "Created user 'admin'" in capsys.readouterr().out
    token = asyncio.run(_session_token(settings, "admin", FIRST_PASSWORD))

    # Single-user system: a second user is refused before any password is read.
    assert _run(monkeypatch, ["create-admin", "--username", "other", "--password-stdin"]) == 1
    assert "already exists" in capsys.readouterr().err

    assert _run(monkeypatch, ["reset-password", "--password-stdin"], SECOND_PASSWORD + "\n") == 0
    assert "1 active session(s) revoked" in capsys.readouterr().out
    assert not asyncio.run(_session_is_valid(settings, token))
    assert not asyncio.run(_login_works(settings, "admin", FIRST_PASSWORD))
    assert asyncio.run(_login_works(settings, "admin", SECOND_PASSWORD))

    assert _run(monkeypatch, ["reset-password", "--username", "nobody", "--password-stdin"]) == 1
    assert "user 'nobody' does not exist" in capsys.readouterr().err

    assert _run(monkeypatch, ["check-config"]) == 0
    output = capsys.readouterr().out
    assert "Local user   present" in output
    database_password = settings.database_url.get_secret_value().split("@")[0].rsplit(":", 1)[-1]
    assert f":{database_password}@" not in output
    assert asyncio.run(_cli_audit_actions(cli)) == ["user.create", "user.password_reset"]


def test_kill_switch_commands(
    cli: CliHarness, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(monkeypatch, ["kill-switch", "engage", "--reason", "  provider maintenance  "]) == 0
    engaged = capsys.readouterr().out
    assert "ENGAGED" in engaged
    assert "Reason       provider maintenance\n" in engaged
    assert "Changed by   cli" in engaged

    assert _run(monkeypatch, ["kill-switch", "status"]) == 0
    assert "ENGAGED" in capsys.readouterr().out

    assert _run(monkeypatch, ["kill-switch", "release", "--reason", "maintenance over"]) == 0
    assert "Kill switch  released" in capsys.readouterr().out
    assert asyncio.run(_cli_audit_actions(cli)) == ["kill_switch.engage", "kill_switch.release"]
