"""The signal engine on PostgreSQL and Redis: lifecycle, risk gate, persistence and publishing."""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal
from typing import Any
from uuid import UUID

import pytest
from sqlalchemy import func, select

from app.container import Container
from app.domain.enums import (
    DataStatus,
    Provider,
    RiskOutcome,
    SignalEventType,
    SignalStatus,
    SignalType,
)
from app.domain.events import SignalUpdate
from app.domain.models.instrument import Instrument
from app.domain.models.signal import TargetLevel
from app.market_data.calendars.loader import load_market_calendar
from app.market_data.calendars.service import MarketCalendar
from app.persistence.models import RiskDecisionRow, SignalEventRow, SignalRow
from app.risk.rules import (
    DATA_QUALITY,
    FREQUENCY,
    KILL_SWITCH,
    LIVE_SIGNALS,
    STRATEGY_ENABLED,
    WORKSPACE_PAUSE,
)
from app.services.kill_switch import KillSwitchService
from app.services.risk import RiskRuleService
from app.services.strategies import StrategyService
from app.signals.engine import DeploymentGoneError, Outcome, Proposal, RunContext, SignalEngine
from app.signals.lifecycle import Action
from app.streaming.redis_bus import Streams
from tests.integration.provider_support import ACTOR, LAB, FakeClock
from tests.integration.strategy_support import (
    EXAMPLE,
    example_run,
    load_instrument,
    proposal,
    wipe_strategies,
)

pytestmark = pytest.mark.integration

GENERATED, ACTIVE, BLOCKED = SignalStatus.GENERATED, SignalStatus.ACTIVE, SignalStatus.BLOCKED
SELL_LEVELS: dict[str, Any] = {
    "signal_type": SignalType.SELL,
    "stop_loss": Decimal("102.15"),
    "targets": (TargetLevel(label="T1", price=Decimal("96.00")),),
}
NO_LEVELS: dict[str, Any] = {"entry_price": None, "stop_loss": None, "targets": ()}

type Trail = list[tuple[SignalEventType, SignalStatus | None, SignalStatus]]


@dataclass
class Lab:
    """One running deployment of the example strategy in the simulation lab, trading ALPHA."""

    container: Container
    clock: FakeClock
    calendar: MarketCalendar
    run: RunContext
    alpha: Instrument

    @property
    def validity(self) -> timedelta:
        return timedelta(seconds=self.container.settings.signal_default_validity_seconds)

    def engine(self, *, live_signals: bool = False) -> SignalEngine:
        settings = self.container.settings.model_copy(update={"live_signals_enabled": live_signals})
        return SignalEngine(self.container.db, self.container.bus, settings, self.calendar, clock=self.clock)

    def proposal(
        self, *, provider: Provider = Provider.SIMULATOR, age_seconds: int = 5, **fields: Any
    ) -> Proposal:
        """A candidate on ALPHA (BUY 100.10, stop 98.05, T1 104.20 unless overridden) from a fresh candle."""
        return proposal(self.alpha, self.clock.now, provider=provider, age_seconds=age_seconds, **fields)

    async def submit(self, proposal: Proposal | None = None, *, live_signals: bool = False) -> Outcome:
        [outcome] = await self.engine(live_signals=live_signals).submit(
            self.run, [proposal or self.proposal()]
        )
        return outcome

    async def signal(self, signal_id: UUID | None) -> SignalRow:
        async with self.container.db.session() as session:
            row = await session.get(SignalRow, signal_id)
        assert row is not None
        return row

    async def events(self, signal_id: UUID | None) -> list[SignalEventRow]:
        async with self.container.db.session() as session:
            result = await session.scalars(
                select(SignalEventRow)
                .where(SignalEventRow.signal_id == signal_id)
                .order_by(SignalEventRow.id)
            )
            return list(result)

    async def trail(self, signal_id: UUID | None) -> Trail:
        return [
            (event.event_type, event.from_status, event.to_status) for event in await self.events(signal_id)
        ]

    async def decisions(self, signal_id: UUID | None) -> list[RiskOutcome]:
        async with self.container.db.session() as session:
            result = await session.scalars(
                select(RiskDecisionRow.outcome)
                .where(RiskDecisionRow.signal_id == signal_id)
                .order_by(RiskDecisionRow.evaluated_at)
            )
            return list(result)

    async def count(self, model: type[SignalRow | RiskDecisionRow]) -> int:
        async with self.container.db.session() as session:
            return await session.scalar(select(func.count()).select_from(model)) or 0

    async def published(self) -> list[SignalUpdate]:
        messages = await self.container.bus.read({Streams.SIGNALS: "0-0"}, block_ms=None)
        return [SignalUpdate.model_validate(message.payload) for message in messages]


def blocking_rules(row: SignalRow) -> set[str]:
    checks = row.risk_decision["checks"]
    return {check["rule"] for check in checks if not check["passed"] and check["severity"] == "BLOCK"}


@pytest.fixture
async def lab(container: Container, clock: FakeClock, symbols: dict[str, UUID]) -> AsyncIterator[Lab]:
    await wipe_strategies(container.db)
    try:
        run = await example_run(container, clock.now)
        alpha = await load_instrument(container.db, symbols["ALPHA"])
        yield Lab(container, clock, await load_market_calendar(container.db), run, alpha)
    finally:
        await wipe_strategies(container.db)


async def test_a_simulated_candidate_becomes_an_active_informational_signal(lab: Lab) -> None:
    outcome = await lab.submit()

    assert (outcome.action, outcome.emitted) == (Action.NEW, True)
    row = await lab.signal(outcome.signal_id)
    assert (row.status, row.closed_at, row.valid_until) == (ACTIVE, None, lab.clock.now + lab.validity)
    assert row.is_actionable is False  # simulated data never makes a signal actionable
    assert (row.provider, row.data_status, row.symbol) == (Provider.SIMULATOR, DataStatus.SIMULATED, "ALPHA")
    assert (row.strategy_id, row.strategy_run_id) == (EXAMPLE, lab.run.run_id)
    assert row.risk_reward == Decimal("2.00")
    assert await lab.trail(outcome.signal_id) == [
        (SignalEventType.GENERATED, None, GENERATED),
        (SignalEventType.ACTIVATED, GENERATED, ACTIVE),
    ]
    assert await lab.decisions(outcome.signal_id) == [RiskOutcome.ALLOW]
    [update] = await lab.published()  # GENERATED stays internal; subscribers see the signal once
    assert (update.event_type, update.signal.id, update.signal.status) == (
        SignalEventType.ACTIVATED,
        outcome.signal_id,
        ACTIVE,
    )


async def test_live_candidates_are_blocked_until_live_signals_are_enabled(lab: Lab) -> None:
    live = lab.proposal(provider=Provider.ZERODHA)

    blocked = await lab.submit(live)
    repeated = await lab.submit(live)
    allowed = await lab.submit(live, live_signals=True)

    assert (blocked.action, blocked.blocked, blocked.emitted) == (Action.NEW, True, False)
    row = await lab.signal(blocked.signal_id)
    assert (row.status, row.closed_at, row.valid_until, row.is_actionable) == (
        BLOCKED,
        lab.clock.now,
        None,
        False,
    )
    assert blocking_rules(row) == {LIVE_SIGNALS}
    assert await lab.trail(blocked.signal_id) == [
        (SignalEventType.GENERATED, None, GENERATED),
        (SignalEventType.BLOCKED, GENERATED, BLOCKED),
    ]
    assert (repeated.stored, repeated.blocked, repeated.signal_id) == (False, True, blocked.signal_id)
    assert allowed.emitted
    accepted = await lab.signal(allowed.signal_id)
    assert (accepted.status, accepted.is_actionable, accepted.data_status) == (ACTIVE, True, DataStatus.LIVE)
    assert (await lab.count(SignalRow), await lab.count(RiskDecisionRow)) == (2, 2)


@pytest.mark.parametrize("blocker", [KILL_SWITCH, WORKSPACE_PAUSE, DATA_QUALITY])
async def test_a_blocked_candidate_is_kept_once_with_the_rule_that_blocked_it(lab: Lab, blocker: str) -> None:
    proposal = lab.proposal()
    if blocker == KILL_SWITCH:
        kill_switch = KillSwitchService(lab.container.db, lab.container.bus)
        await kill_switch.set(engaged=True, reason="maintenance", actor=ACTOR)
    elif blocker == WORKSPACE_PAUSE:
        await RiskRuleService(lab.container.db, clock=lab.clock).pause(LAB, reason="earnings", actor=ACTOR)
    else:
        proposal = lab.proposal(age_seconds=600)

    first = await lab.submit(proposal)
    lab.clock.advance(timedelta(minutes=1))
    again = await lab.submit(proposal)

    row = await lab.signal(first.signal_id)
    assert (row.status, blocking_rules(row)) == (BLOCKED, {blocker})
    assert (again.stored, again.signal_id) == (False, first.signal_id)
    assert await lab.count(SignalRow) == 1


async def test_each_batch_is_checked_against_the_deployment_as_it_stands(lab: Lab) -> None:
    strategies = StrategyService(lab.container.db, lab.container.bus, clock=lab.clock)
    deployment_id = lab.run.deployment_id

    await strategies.set_enabled(deployment_id, False, actor=ACTOR)
    disabled = await lab.submit()
    await strategies.set_enabled(deployment_id, True, actor=ACTOR)
    await strategies.update_configuration(deployment_id, config={"valid_for_minutes": 30}, actor=ACTOR)
    redeployed = await lab.submit(lab.proposal(stop_loss=Decimal("98.50")))

    for outcome, problem in ((disabled, "is not enabled"), (redeployed, "changed after this run started")):
        row = await lab.signal(outcome.signal_id)
        assert (row.status, blocking_rules(row)) == (BLOCKED, {STRATEGY_ENABLED})
        [check] = [check for check in row.risk_decision["checks"] if check["rule"] == STRATEGY_ENABLED]
        assert problem in check["message"]
    await wipe_strategies(lab.container.db)
    with pytest.raises(DeploymentGoneError):
        await lab.submit()


async def test_duplicates_are_skipped_and_new_levels_update_the_open_signal(lab: Lab) -> None:
    first = await lab.submit()
    duplicate = await lab.submit()
    lab.clock.advance(timedelta(minutes=1))
    update = await lab.submit(lab.proposal(stop_loss=Decimal("98.50")))

    assert (duplicate.action, duplicate.stored, duplicate.signal_id) == (
        Action.DUPLICATE,
        False,
        first.signal_id,
    )
    assert (update.action, update.emitted, update.signal_id) == (Action.UPDATE, True, first.signal_id)
    row = await lab.signal(first.signal_id)
    assert (row.status, row.update_count, row.stop_loss) == (SignalStatus.UPDATED, 1, Decimal("98.50"))
    assert row.valid_until == lab.clock.now + lab.validity  # an update renews the validity
    events = await lab.events(first.signal_id)
    assert (events[-1].event_type, events[-1].from_status) == (SignalEventType.UPDATED, ACTIVE)
    assert events[-1].details["previous"] == {
        "entry_price": "100.1",
        "stop_loss": "98.05",
        "targets": [{"label": "T1", "price": "104.20"}],
    }
    assert await lab.decisions(first.signal_id) == [RiskOutcome.ALLOW, RiskOutcome.ALLOW]


async def test_an_opposite_entry_supersedes_and_an_exit_closes_the_open_signal(lab: Lab) -> None:
    buy = await lab.submit()
    lab.clock.advance(timedelta(minutes=1))
    sell = await lab.submit(lab.proposal(**SELL_LEVELS))
    lab.clock.advance(timedelta(minutes=1))
    exit_ = await lab.submit(lab.proposal(signal_type=SignalType.EXIT, **NO_LEVELS))

    assert [outcome.action for outcome in (buy, sell, exit_)] == [Action.NEW] * 3
    bought, sold, exited = [await lab.signal(outcome.signal_id) for outcome in (buy, sell, exit_)]
    assert (bought.status, bought.superseded_by) == (SignalStatus.SUPERSEDED, sold.id)
    assert (sold.status, sold.superseded_by, sold.closed_at) == (
        SignalStatus.CLOSED,
        exited.id,
        lab.clock.now,
    )
    assert exited.status is ACTIVE
    events = await lab.events(sold.id)
    assert (events[-1].event_type, events[-1].details) == (
        SignalEventType.CLOSED,
        {"replaced_by": str(exited.id)},
    )


async def test_an_invalidation_closes_the_open_signal_without_the_risk_gate(lab: Lab) -> None:
    opened = await lab.submit()
    invalidation = lab.proposal(
        signal_type=SignalType.INVALIDATED, reasons=("close fell back below the slow EMA",), **NO_LEVELS
    )

    closed = await lab.submit(invalidation)
    ignored = await lab.submit(invalidation)

    assert (closed.action, closed.signal_id, closed.decision) == (Action.INVALIDATE, opened.signal_id, None)
    assert (ignored.action, ignored.stored, ignored.signal_id) == (Action.IGNORE, False, None)
    row = await lab.signal(opened.signal_id)
    assert (row.status, row.closed_at) == (SignalStatus.INVALIDATED, lab.clock.now)
    events = await lab.events(opened.signal_id)
    assert events[-1].details["reasons"] == ["close fell back below the slow EMA"]
    assert await lab.count(RiskDecisionRow) == 1


async def test_the_frequency_limit_blocks_new_entries_but_never_an_exit(lab: Lab) -> None:
    for levels in ({}, SELL_LEVELS, {}):
        assert (await lab.submit(lab.proposal(**levels))).emitted
        lab.clock.advance(timedelta(minutes=1))

    fourth = await lab.submit(lab.proposal(**SELL_LEVELS))
    exit_ = await lab.submit(lab.proposal(signal_type=SignalType.EXIT, **NO_LEVELS))

    assert blocking_rules(await lab.signal(fourth.signal_id)) == {FREQUENCY}
    assert exit_.emitted


async def test_expire_closes_signals_once_their_validity_ends(lab: Lab) -> None:
    opened = await lab.submit()
    engine = lab.engine()

    assert await engine.expire() == 0
    lab.clock.advance(lab.validity)
    assert await engine.expire() == 1

    row = await lab.signal(opened.signal_id)
    assert (row.status, row.closed_at) == (SignalStatus.EXPIRED, lab.clock.now)
    assert (await lab.published())[-1].event_type is SignalEventType.EXPIRED
    assert (await lab.submit()).action is Action.NEW  # nothing is open for the instrument any more
