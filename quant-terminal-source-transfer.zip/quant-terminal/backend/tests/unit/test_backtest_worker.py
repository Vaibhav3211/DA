"""The backtest worker's loop on fake services: the order of its jobs, their keepalives, and failed cycles."""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Iterable, Mapping
from datetime import UTC, datetime
from typing import Any, cast
from uuid import UUID

import pytest
from structlog.testing import capture_logs

from app.domain.enums import BacktestStatus, DatasetStatus
from app.market_data.calendars.service import ExchangeSpec, MarketCalendar
from app.services.backtests import BacktestService
from app.services.datasets import DatasetService
from app.services.markets import MarketCalendarCache
from app.workers.backtest_worker import ABANDONED_AFTER, BacktestWorker
from tests.backtest_support import nse_calendar

NOW = datetime(2026, 11, 2, 4, 30, tzinfo=UTC)
WORKER = "laptop:4242"
POLL = 2.0
DATASET, RUN = UUID(int=1), UUID(int=2)


class Stop(Exception):
    """Ends the worker's loop in a test."""


class FakeJobs:
    """What the worker uses of the dataset service (``build``) or the backtest service (``run``)."""

    def __init__(
        self, name: str, verb: str, finished: DatasetStatus | BacktestStatus, calls: list[str]
    ) -> None:
        self.name, self.verb, self.finished, self.calls = name, verb, finished, calls
        self.waiting: list[UUID] = []
        self.abandoned: list[UUID] = []
        self.stale_before: list[datetime] = []
        self.refreshes: list[bool | Exception] = []  # the next keepalives' outcomes; a job lasts until used
        self.used = asyncio.Event()  # every scripted keepalive happened
        self.refreshed = 0
        self.failure: Exception | None = None  # raised by the next job
        self.calendars: list[MarketCalendar] = []
        self.heartbeat: Callable[[], dict[str, Any]] = dict
        self.seen: list[dict[str, Any]] = []  # the heartbeat details while each job ran

    async def fail_abandoned(self, *, stale_before: datetime) -> list[UUID]:
        self.stale_before.append(stale_before)
        abandoned, self.abandoned = self.abandoned, []
        return abandoned

    async def claim_next(self, worker_id: str) -> UUID | None:
        assert worker_id == WORKER
        self.calls.append(f"claim {self.name}")
        return self.waiting.pop(0) if self.waiting else None

    async def keep_alive(self, job_id: UUID, worker_id: str) -> bool:
        assert worker_id == WORKER
        self.refreshed += 1
        outcome = self.refreshes.pop(0) if self.refreshes else True
        if not self.refreshes:
            self.used.set()
        if isinstance(outcome, Exception):
            raise outcome
        return outcome

    async def work(
        self, job_id: UUID, worker_id: str, calendar: MarketCalendar
    ) -> DatasetStatus | BacktestStatus:
        assert worker_id == WORKER
        self.calls.append(f"{self.verb} {job_id.int}")
        self.calendars.append(calendar)
        self.seen.append(self.heartbeat())
        if self.refreshes:  # busy until every scripted keepalive happened
            await self.used.wait()
        if self.failure is not None:
            failure, self.failure = self.failure, None
            raise failure
        return self.finished

    build_claimed = work
    run_claimed = work


class FakeCalendars:
    def __init__(self, calls: list[str]) -> None:
        self.calls = calls
        self.calendar = nse_calendar()
        self.failure: Exception | None = None  # raised by the next load

    async def get(self) -> tuple[MarketCalendar, tuple[ExchangeSpec, ...]]:
        self.calls.append("calendar")
        if self.failure is not None:
            failure, self.failure = self.failure, None
            raise failure
        return self.calendar, ()


class Rig:
    def __init__(self, *, keepalive_seconds: float = 15.0, stop_after: int = 1) -> None:
        self.calls: list[str] = []
        self.datasets = FakeJobs("dataset", "build", DatasetStatus.READY, self.calls)
        self.backtests = FakeJobs("backtest", "run", BacktestStatus.SUCCEEDED, self.calls)
        self.calendars = FakeCalendars(self.calls)
        self.sleeps: list[float] = []
        self.stop_after = stop_after  # the wait between polls that ends the loop
        self.worker = BacktestWorker(
            cast(DatasetService, self.datasets),
            cast(BacktestService, self.backtests),
            cast(MarketCalendarCache, self.calendars),
            worker_id=WORKER,
            poll_seconds=POLL,
            keepalive_seconds=keepalive_seconds,
            clock=lambda: NOW,
            sleep=self.sleep,
        )
        self.datasets.heartbeat = self.backtests.heartbeat = self.worker.details

    async def sleep(self, seconds: float) -> None:
        self.sleeps.append(seconds)
        if len(self.sleeps) >= self.stop_after:
            raise Stop


def job_events(logs: Iterable[Mapping[str, Any]]) -> list[str]:
    return [entry["event"] for entry in logs if entry["event"].startswith("backtest_job_")]


async def test_datasets_are_built_before_backtests_run_and_an_idle_worker_says_so() -> None:
    r = Rig()
    r.datasets.waiting, r.backtests.waiting = [DATASET], [RUN]
    with capture_logs() as logs:
        assert await r.worker.run_once()
        assert r.calls == ["calendar", "claim dataset", "build 1"]  # a backtest may wait for this dataset
        assert await r.worker.run_once()
        assert r.calls[3:] == ["calendar", "claim dataset", "claim backtest", "run 2"]
        assert not await r.worker.run_once()

    assert r.datasets.calendars[0] is r.backtests.calendars[0] is r.calendars.calendar
    assert r.datasets.seen == [{"worker_id": WORKER, "job": f"dataset {DATASET}"}]
    assert r.backtests.seen == [{"worker_id": WORKER, "job": f"backtest {RUN}"}]
    assert r.worker.details() == {"worker_id": WORKER, "job": None}
    finished = [(entry["event"], entry["status"]) for entry in logs if entry["event"].endswith("_finished")]
    assert finished == [("backtest_dataset_finished", "READY"), ("backtest_run_finished", "SUCCEEDED")]


async def test_jobs_abandoned_by_a_stopped_worker_are_failed_first() -> None:
    r = Rig()
    r.datasets.abandoned, r.backtests.abandoned = [DATASET], [RUN]
    with capture_logs() as logs:
        assert not await r.worker.run_once()
    assert r.datasets.stale_before == r.backtests.stale_before == [NOW - ABANDONED_AFTER]
    assert [entry for entry in logs if entry["event"].endswith("_abandoned")] == [
        {"event": "backtest_dataset_abandoned", "dataset_id": str(DATASET), "log_level": "warning"},
        {"event": "backtest_run_abandoned", "run_id": str(RUN), "log_level": "warning"},
    ]


async def test_the_claim_is_refreshed_while_a_job_runs_and_no_longer_after() -> None:
    r = Rig(keepalive_seconds=0)
    r.backtests.waiting = [RUN]
    r.backtests.refreshes = [True, OSError("database down"), True]
    with capture_logs() as logs:
        assert await r.worker.run_once()
    assert r.backtests.refreshed == 3
    assert job_events(logs) == ["backtest_job_keepalive_failed"]  # and tried again

    await asyncio.sleep(0)
    assert r.backtests.refreshed == 3
    assert not [task for task in asyncio.all_tasks() if task.get_name() == "backtest-keepalive"]


async def test_a_lost_claim_stops_the_refreshes_but_not_the_job() -> None:
    r = Rig(keepalive_seconds=0)
    r.datasets.waiting = [DATASET]
    r.datasets.refreshes = [False]  # e.g. failed as abandoned meanwhile; the service then keeps its result
    with capture_logs() as logs:
        assert await r.worker.run_once()
    assert (r.datasets.refreshed, r.calls[-1]) == (1, "build 1")
    assert job_events(logs) == ["backtest_job_claim_lost"]


async def test_a_failed_cycle_is_logged_and_tried_again_after_the_poll_interval() -> None:
    r = Rig(stop_after=3)
    r.calendars.failure = OSError("database down")
    r.datasets.waiting, r.datasets.failure = [DATASET], RuntimeError("a bug")
    r.backtests.waiting = [RUN]
    with capture_logs() as logs, pytest.raises(Stop):
        await r.worker.run()

    assert r.calls == [
        "calendar",
        *("calendar", "claim dataset", "build 1"),
        *("calendar", "claim dataset", "claim backtest", "run 2"),  # busy: polls again at once
        *("calendar", "claim dataset", "claim backtest"),
    ]
    assert r.sleeps == [POLL, POLL, POLL]
    assert [entry["event"] for entry in logs].count("backtest_worker_cycle_failed") == 2
    assert r.worker.details()["job"] is None
