from __future__ import annotations

import base64
import os

import pytest
from pydantic import SecretStr

from app.core.security import (
    EncryptionError,
    SecretBox,
    generate_encryption_key,
    hash_password,
    hash_token,
    mask_secret,
    verify_password,
)
from tests.conftest import build_settings


def _key() -> bytes:
    return os.urandom(32)


def test_round_trip_and_context_binding() -> None:
    box = SecretBox(_key())
    token = box.encrypt("my-api-secret", context="provider_account:1:API_SECRET")
    assert "my-api-secret" not in token
    assert box.decrypt(token, context="provider_account:1:API_SECRET") == "my-api-secret"
    # A ciphertext copied to another record/field must not decrypt.
    with pytest.raises(EncryptionError):
        box.decrypt(token, context="provider_account:2:API_SECRET")


def test_tampered_ciphertext_fails_authentication() -> None:
    box = SecretBox(_key())
    version, key_id, payload = box.encrypt("value", context="c").split(".", 2)
    raw = bytearray(base64.urlsafe_b64decode(payload))
    raw[-1] ^= 0x01
    tampered = f"{version}.{key_id}.{base64.urlsafe_b64encode(bytes(raw)).decode()}"
    with pytest.raises(EncryptionError, match="authentication"):
        box.decrypt(tampered, context="c")


def test_key_rotation_keeps_old_ciphertexts_readable() -> None:
    old, new = _key(), _key()
    token = SecretBox(old).encrypt("secret", context="c")
    rotated = SecretBox(new, previous_keys=[old])
    assert rotated.decrypt(token, context="c") == "secret"
    assert rotated.needs_rotation(token)
    assert not rotated.needs_rotation(rotated.encrypt("secret", context="c"))
    with pytest.raises(EncryptionError, match="unknown key"):
        SecretBox(new).decrypt(token, context="c")


def test_from_settings_validates_keys() -> None:
    with pytest.raises(EncryptionError, match="not configured"):
        SecretBox.from_settings(build_settings())
    with pytest.raises(EncryptionError, match="32 bytes"):
        SecretBox.from_settings(build_settings(encryption_key=SecretStr("c2hvcnQ=")))
    box = SecretBox.from_settings(build_settings(encryption_key=SecretStr(generate_encryption_key())))
    assert box.decrypt(box.encrypt("x", context="c"), context="c") == "x"


def test_password_hashing() -> None:
    hashed = hash_password("correct horse battery staple")
    assert verify_password(hashed, "correct horse battery staple")
    assert not verify_password(hashed, "wrong password!!")
    assert not verify_password("not-a-hash", "anything")


def test_token_hash_and_masking() -> None:
    assert hash_token("abc") == hash_token("abc") != hash_token("abd")
    assert mask_secret("abcdefghijkl") == "••••ijkl"
    assert mask_secret("short") == "••••"
    assert mask_secret(None) is None
