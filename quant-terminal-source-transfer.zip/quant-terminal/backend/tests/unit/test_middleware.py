from __future__ import annotations

import structlog
from fastapi import APIRouter, FastAPI
from fastapi.testclient import TestClient
from prometheus_client import REGISTRY

from app.api.middleware import (
    OriginCheckMiddleware,
    RequestContextMiddleware,
    SecurityHeadersMiddleware,
    websocket_origin_allowed,
)
from app.core.errors import install_exception_handlers

ALLOWED = ["http://localhost:3000"]


def _client() -> TestClient:
    app = FastAPI()
    install_exception_handlers(app)

    @app.get("/ping")
    async def ping() -> dict[str, object]:
        return {"context": structlog.contextvars.get_contextvars()}

    @app.post("/change")
    async def change() -> dict[str, bool]:
        return {"changed": True}

    app.add_middleware(OriginCheckMiddleware, allowed_origins=ALLOWED)
    app.add_middleware(SecurityHeadersMiddleware, hsts=True)
    app.add_middleware(RequestContextMiddleware)
    return TestClient(app)


def test_cross_origin_state_change_is_rejected() -> None:
    client = _client()
    rejected = client.post("/change", headers={"Origin": "https://evil.example"})
    assert rejected.status_code == 403
    assert rejected.json()["error"]["code"] == "origin_not_allowed"
    assert client.post("/change", headers={"Origin": "http://localhost:3000"}).status_code == 200
    # Non-browser clients send no Origin header and still go through normal authentication.
    assert client.post("/change").status_code == 200
    # Safe methods are never blocked by the origin check.
    assert client.get("/ping", headers={"Origin": "https://evil.example"}).status_code == 200


def test_security_headers_and_request_ids() -> None:
    client = _client()
    response = client.get("/ping", headers={"X-Request-ID": "abcdef123456"})
    assert response.headers["X-Request-ID"] == "abcdef123456"
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
    assert response.headers["Cache-Control"] == "no-store"
    assert "max-age" in response.headers["Strict-Transport-Security"]
    assert response.json()["context"]["correlation_id"] == "abcdef123456"

    generated = client.get("/ping", headers={"X-Request-ID": "bad id with spaces"})
    assert generated.headers["X-Request-ID"] != "bad id with spaces"
    assert len(generated.headers["X-Request-ID"]) == 32


def test_w3c_trace_id_is_bound_to_log_context() -> None:
    trace_id = "4bf92f3577b34da6a3ce929d0e0e4736"
    response = _client().get("/ping", headers={"traceparent": f"00-{trace_id}-00f067aa0ba902b7-01"})
    assert response.json()["context"]["trace_id"] == trace_id


def test_metrics_label_full_route_templates_of_included_routers() -> None:
    items = APIRouter(prefix="/items")

    @items.get("/{item_id}")
    async def item(item_id: str) -> dict[str, str]:
        return {"id": item_id}

    api = APIRouter()
    api.include_router(items)
    app = FastAPI()
    app.include_router(api, prefix="/api/v1")
    app.add_middleware(RequestContextMiddleware)

    def count(route: str, status: str) -> float:
        labels = {"method": "GET", "route": route, "status": status}
        return REGISTRY.get_sample_value("qt_http_requests_total", labels) or 0.0

    matched_before, unmatched_before = count("/api/v1/items/{item_id}", "200"), count("unmatched", "404")
    client = TestClient(app)
    for path in ("/api/v1/items/42", "/api/v1/items/43", "/api/v1/nope"):
        client.get(path)
    assert count("/api/v1/items/{item_id}", "200") == matched_before + 2
    assert count("unmatched", "404") == unmatched_before + 1


def test_websocket_origin_policy() -> None:
    def scope(origin: str | None) -> dict[str, object]:
        headers = [] if origin is None else [(b"origin", origin.encode())]
        return {"type": "websocket", "headers": headers}

    assert websocket_origin_allowed(scope("http://localhost:3000"), ALLOWED)
    assert websocket_origin_allowed(scope("HTTP://LOCALHOST:3000/"), ALLOWED)
    assert not websocket_origin_allowed(scope("https://evil.example"), ALLOWED)
    assert websocket_origin_allowed(scope(None), ALLOWED)
