"""The WebSocket protocol, and how a connection queues, conflates and orders what it is sent."""

from __future__ import annotations

import asyncio
import contextlib
import json
from datetime import UTC, datetime, timedelta
from typing import Any, cast
from uuid import uuid4

import pytest
from pydantic import BaseModel
from starlette.websockets import WebSocket

from app.api.ws.hub import Item, Pair, Subscription, Update, WsClient
from app.api.ws.protocol import (
    MAX_MESSAGE_CHARS,
    Channel,
    Heartbeat,
    ProtocolError,
    Subscribe,
    check_subscription,
    parse_client_message,
    request_id_of,
)
from app.domain.enums import CandleInterval, Provider
from app.services.auth_service import SessionUser
from tests.candle_support import INSTRUMENT, bar

ALPHA: Pair = (Provider.SIMULATOR, uuid4())
BRAVO: Pair = (Provider.SIMULATOR, uuid4())


class Price(BaseModel):
    symbol: str
    price: int


class FakeSocket:
    def __init__(self) -> None:
        self.sent: list[dict[str, Any]] = []

    async def send_text(self, text: str) -> None:
        self.sent.append(json.loads(text))


def _client(*, queue_size: int = 10, drop_limit: int = 100) -> tuple[WsClient, FakeSocket]:
    socket = FakeSocket()
    now = datetime(2026, 1, 5, 4, 0, tzinfo=UTC)
    user = SessionUser(user_id=uuid4(), username="alice", created_at=now, expires_at=now + timedelta(hours=1))
    channels = frozenset(Channel)
    client = WsClient(cast(WebSocket, socket), user, channels, queue_size=queue_size, drop_limit=drop_limit)
    return client, socket


def _subscription(channel: Channel, *pairs: Pair, interval: CandleInterval | None = None) -> Subscription:
    return Subscription(channel, generation=1, pairs=pairs, members=frozenset(pairs), interval=interval)


def _price(symbol: str, price: int) -> Update:
    return Update((symbol, price), Item.of(Price(symbol=symbol, price=price)))


async def _flush(client: WsClient) -> None:
    """Let the client's send loop send what is queued."""
    task = asyncio.create_task(client.send_loop())
    for _ in range(5):
        await asyncio.sleep(0)
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task


def test_messages_are_parsed_strictly_by_action() -> None:
    message = parse_client_message(
        '{"action":"subscribe","channel":"quotes","workspace_id":"lab","request_id":"r-1"}'
    )
    assert isinstance(message, Subscribe)
    assert (message.channel, message.workspace_id, message.depth, message.request_id) == (
        Channel.QUOTES,
        "lab",
        False,
        "r-1",
    )
    assert isinstance(parse_client_message('{"action":"heartbeat"}'), Heartbeat)
    for text in ("{", "[]", '{"action":"resubscribe"}', '{"action":"heartbeat","extra":1}'):
        with pytest.raises(ProtocolError) as invalid:
            parse_client_message(text)
        assert invalid.value.code == "invalid_message"
    with pytest.raises(ProtocolError) as large:
        parse_client_message(" " * (MAX_MESSAGE_CHARS + 1))
    assert large.value.code == "message_too_large"
    assert request_id_of('{"action":"nope","request_id":"r-2"}') == "r-2"
    assert request_id_of('{"request_id":"has spaces"}') is None


@pytest.mark.parametrize(
    ("fields", "code"),
    [
        ({"channel": "feed", "interval": "1m"}, "option_not_allowed"),
        ({"channel": "signals", "depth": True}, "option_not_allowed"),
        ({"channel": "quotes"}, "selection_required"),
        ({"channel": "candles", "workspace_id": "lab"}, "interval_required"),
    ],
)
def test_a_subscription_takes_only_its_channels_options(fields: dict[str, Any], code: str) -> None:
    with pytest.raises(ProtocolError) as refused:
        check_subscription(Subscribe.model_validate({"action": "subscribe", **fields}))
    assert refused.value.code == code


async def test_an_update_replaced_before_it_was_sent_is_dropped_and_events_go_first() -> None:
    client, socket = _client()
    client.subscribe(_subscription(Channel.QUOTES, ALPHA, BRAVO), {})
    client.offer_updates(Channel.QUOTES, {ALPHA: _price("ALPHA", 1), BRAVO: _price("BRAVO", 7)}, 1)
    client.offer_updates(Channel.QUOTES, {ALPHA: _price("ALPHA", 2), BRAVO: _price("BRAVO", 7)}, 1)
    client.reply({"type": "ack"})
    await _flush(client)
    assert [event["type"] for event in socket.sent] == ["ack", "quote.update"]
    assert [item["price"] for item in socket.sent[1]["items"]] == [2, 7]

    client.offer_updates(Channel.QUOTES, {ALPHA: _price("ALPHA", 2), BRAVO: _price("BRAVO", 8)}, 1)
    client.offer_updates(Channel.QUOTES, {ALPHA: _price("ALPHA", 3)}, 0)  # read before the subscription
    await _flush(client)
    assert [[item["price"] for item in event["items"]] for event in socket.sent[2:]] == [[8]]


async def test_a_forming_candle_is_never_sent_after_its_bucket_closed() -> None:
    client, socket = _client()
    pair: Pair = (Provider.ZERODHA, INSTRUMENT)
    client.subscribe(_subscription(Channel.CANDLES, pair, interval=CandleInterval.M1), {})
    first, second = bar(0, "100", closed=False), bar(1, "101", closed=False)

    def forming(mark: str, candle: Any) -> dict[Pair, Update]:
        return {pair: Update(mark, Item.of(candle), bucket_start=candle.bucket_start)}

    client.offer_updates(Channel.CANDLES, forming("first", first), 1)
    client.send_closed_candle(bar(0, "100"), '{"type":"candle.closed"}')
    client.offer_updates(Channel.CANDLES, forming("first, late", first), 1)
    client.offer_updates(Channel.CANDLES, forming("second", second), 1)
    await _flush(client)
    assert [event["type"] for event in socket.sent] == ["candle.closed", "candle.update"]
    assert [candle["close_price"] for candle in socket.sent[1]["items"]] == ["101"]


def test_a_client_whose_queue_overflows_or_that_lags_too_far_behind_is_closed() -> None:
    overflowing, _ = _client(queue_size=2)
    for n in range(3):
        overflowing.reply({"type": "event", "n": n})
    assert (overflowing.close_code, overflowing.close_reason) == (1013, "slow_client")

    lagging, _ = _client(drop_limit=2)
    lagging.subscribe(_subscription(Channel.QUOTES, ALPHA), {})
    for price in range(3):
        lagging.offer_updates(Channel.QUOTES, {ALPHA: _price("ALPHA", price)}, 1)
    assert not lagging.closing.is_set()
    lagging.offer_updates(Channel.QUOTES, {ALPHA: _price("ALPHA", 3)}, 1)
    assert (lagging.close_code, lagging.close_reason) == (1013, "slow_client")
