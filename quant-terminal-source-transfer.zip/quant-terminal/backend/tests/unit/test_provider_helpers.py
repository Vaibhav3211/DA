"""Normalization of user input for provider accounts and login flows."""

from __future__ import annotations

import pytest
from pydantic import SecretStr

from app.core.errors import ValidationFailedError
from app.domain.enums import AuthMethod, CredentialKind
from app.services.provider_accounts import environment_credential, normalize_credential, normalize_label
from app.services.provider_auth import check_redirect_target, clean_access_token
from tests.conftest import build_settings


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("  Main  ", "Main"),
        ("Family\t account\n 2", "Family account 2"),
        ("0.x_y-z", "0.x_y-z"),
        ("A" * 80, "A" * 80),
    ],
)
def test_labels_are_trimmed_with_inner_whitespace_collapsed(raw: str, expected: str) -> None:
    assert normalize_label(raw) == expected


@pytest.mark.parametrize("raw", ["", "   ", "-Main", ".Main", "A" * 81, "Main/2", "Zer\u00f6dha"])
def test_unusable_labels_are_rejected(raw: str) -> None:
    with pytest.raises(ValidationFailedError) as excinfo:
        normalize_label(raw)
    assert excinfo.value.code == "invalid_label"


def test_totp_secrets_are_stored_as_upper_case_base32_without_separators() -> None:
    assert normalize_credential(CredentialKind.TOTP_SECRET, " jbsw y3dp-ehpk\t3pxp ") == "JBSWY3DPEHPK3PXP"


@pytest.mark.parametrize(
    ("value", "message"),
    [
        ("JBSWY3DP!EHPK3PXP", "The TOTP secret is not valid base32"),
        ("JBSWY3DP", "The TOTP secret is too short"),
    ],
)
def test_unusable_totp_secrets_are_rejected_without_echoing_them(value: str, message: str) -> None:
    with pytest.raises(ValidationFailedError) as excinfo:
        normalize_credential(CredentialKind.TOTP_SECRET, value)
    assert (excinfo.value.code, excinfo.value.message) == ("invalid_credential", message)


def test_other_credentials_are_trimmed() -> None:
    assert normalize_credential(CredentialKind.API_KEY, "  key-123_ABC.x \n") == "key-123_ABC.x"


@pytest.mark.parametrize("value", ["   ", "two words", "kl\u00e9", "x" * 4097])
def test_unusable_credentials_are_rejected_without_echoing_them(value: str) -> None:
    with pytest.raises(ValidationFailedError) as excinfo:
        normalize_credential(CredentialKind.API_SECRET, value)
    assert (excinfo.value.code, excinfo.value.message) == (
        "invalid_credential",
        "The API secret must be 1-4096 printable characters without spaces",
    )


def test_deployment_credentials_back_only_the_methods_that_use_them() -> None:
    settings = build_settings().model_copy(
        update={
            "zerodha_api_key": SecretStr(" kitekey "),
            "zerodha_api_secret": SecretStr("   "),
            "groww_api_key": SecretStr("growwkey"),
            "groww_api_secret": SecretStr("growwsecret"),
        }
    )
    zerodha, approval = AuthMethod.ZERODHA_LOGIN_REDIRECT, AuthMethod.GROWW_API_KEY_SECRET

    assert environment_credential(settings, zerodha, CredentialKind.API_KEY) == "kitekey"
    assert environment_credential(settings, zerodha, CredentialKind.API_SECRET) is None  # blank is unset
    assert environment_credential(settings, approval, CredentialKind.API_SECRET) == "growwsecret"
    assert environment_credential(settings, approval, CredentialKind.TOTP_SECRET) is None
    # A TOTP token is not the approval API key, and pasted access tokens need no key at all.
    for method in (AuthMethod.GROWW_TOTP, AuthMethod.GROWW_ACCESS_TOKEN):
        assert environment_credential(settings, method, CredentialKind.API_KEY) is None


@pytest.mark.parametrize(
    ("pasted", "token"),
    [
        ("  ey.J-x_1\n", "ey.J-x_1"),
        ("Bearer ey.J-x_1", "ey.J-x_1"),
        ("bearer\t ey.J-x_1 ", "ey.J-x_1"),
        ("BEARER ey.J-x_1", "ey.J-x_1"),
        ("Bearerey.J-x_1", "Bearerey.J-x_1"),  # no separator, so it is part of the token
    ],
)
def test_pasted_access_tokens_lose_whitespace_and_a_bearer_prefix(pasted: str, token: str) -> None:
    assert clean_access_token(pasted) == token


@pytest.mark.parametrize(
    "pasted",
    ["", " \n ", "two words", "Bearer Bearer ey.J", "ey.Jbearer x", "ey.J\u00e9", "x" * 4097],
)
def test_unusable_access_tokens_are_rejected(pasted: str) -> None:
    with pytest.raises(ValidationFailedError) as excinfo:
        clean_access_token(pasted)
    assert excinfo.value.code == "invalid_token"


@pytest.mark.parametrize(
    ("pasted", "configured"),
    [
        ("https://app.test/cb?request_token=abc", "https://app.test:443/cb/"),
        (" HTTPS://APP.TEST:443/cb/?request_token=abc ", "https://app.test/cb"),
        ("http://app.test:80/cb", " http://APP.test/cb "),
        ("request_token=abc&state=xyz", "https://app.test/cb"),
        ("https://elsewhere.test/cb", None),
    ],
    ids=["default-port", "case-and-slash", "configured-with-spaces", "query-only", "not-configured"],
)
def test_equivalent_redirect_targets_are_accepted(pasted: str, configured: str | None) -> None:
    check_redirect_target(pasted, configured)


def test_redirect_paths_are_case_sensitive() -> None:
    with pytest.raises(ValidationFailedError) as excinfo:
        check_redirect_target("https://app.test/CB", "https://app.test/cb")
    assert excinfo.value.code == "redirect_url_mismatch"
