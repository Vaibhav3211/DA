from __future__ import annotations

import io
import logging

import structlog
from structlog.testing import capture_logs

from app.core.logging import REDACTED, configure_logging, get_logger, redact_text, redact_value


def test_reconfiguring_reaches_loggers_already_in_use() -> None:
    root = logging.getLogger()
    handlers, level = root.handlers[:], root.level
    was_configured, config = structlog.is_configured(), structlog.get_config()
    logger = get_logger("tests.reconfigure")
    output = io.StringIO()
    try:
        configure_logging("INFO", stream=io.StringIO())
        logger.info("first")  # the logger now keeps the processor list it logged with
        configure_logging("INFO", stream=output)
        with capture_logs() as events:
            logger.info("second")
    finally:
        # configure_logging is process-wide: give pytest back its handlers and structlog its settings.
        root.handlers[:] = handlers
        root.setLevel(level)
        if was_configured:
            structlog.configure(**config)
        else:
            structlog.reset_defaults()
    assert [event["event"] for event in events] == ["second"]
    assert output.getvalue() == ""


def test_sensitive_keys_are_redacted_recursively() -> None:
    event = {
        "api_key": "abc123",
        "nested": {"access_token": "tok", "Authorization": "token k:v", "symbol": "RELIANCE"},
        "items": [{"api_secret": "s"}],
        "empty_password": "",
    }
    redacted = redact_value(None, event)
    assert redacted["api_key"] == REDACTED
    assert redacted["nested"]["access_token"] == REDACTED
    assert redacted["nested"]["Authorization"] == REDACTED
    assert redacted["nested"]["symbol"] == "RELIANCE"
    assert redacted["items"][0]["api_secret"] == REDACTED
    assert redacted["empty_password"] == ""


def test_secrets_inside_free_text_are_redacted() -> None:
    url = "wss://ws.kite.trade?api_key=kitekey&access_token=SECRET123&mode=full"
    assert "SECRET123" not in redact_text(url)
    assert "kitekey" not in redact_text(url)
    assert "mode=full" in redact_text(url)
    header = 'headers={"Authorization": "token mykey:mytoken"}'
    assert "mytoken" not in redact_text(header)
    callback = "/callback?request_token=RT42&action=login&status=success"
    assert "RT42" not in redact_text(callback)


def test_bearer_tokens_and_url_passwords_are_redacted() -> None:
    header = "Authorization: Bearer eyJhbGciOi.payload.sig, x-request-id: 42"
    assert redact_text(header) == f"Authorization: Bearer {REDACTED}, x-request-id: 42"
    dsn = "connect failed: postgresql+asyncpg://quant:s3cret@db:5432/qt and redis://:pw@cache:6379/0"
    assert redact_text(dsn) == (
        f"connect failed: postgresql+asyncpg://quant:{REDACTED}@db:5432/qt and redis://:{REDACTED}@cache:6379/0"
    )
    assert redact_text("wss://socket-api.groww.in/ and http://localhost:8000/x") == (
        "wss://socket-api.groww.in/ and http://localhost:8000/x"
    )


def test_feed_credential_keys_are_redacted_but_instrument_tokens_are_not() -> None:
    socket = {"token": "jwt-value", "jwt": "j", "nkey_seed": "SUAB", "subscriptionId": "sub-1"}
    assert redact_value(None, socket) == {
        "token": REDACTED,
        "jwt": REDACTED,
        "nkey_seed": REDACTED,
        "subscriptionId": "sub-1",
    }
    assert redact_value("instrument_token", 256265) == 256265


def test_bare_jwts_and_nkey_seeds_are_redacted() -> None:
    jwt = "eyJ0eXAiOiJKV1QifQ.eyJzdWIiOiJ0ZXN0In0.c2lnbmF0dXJl"
    seed = "SU" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" + "A" * 24
    assert redact_text(f"token {jwt} expired") == f"token {REDACTED} expired"
    assert redact_text(f"unsigned {jwt[:-12]} and seed {seed}") == f"unsigned {REDACTED} and seed {REDACTED}"
    assert redact_text("symbols NIFTY26JAN25000CE, SBIN-EQ and keys.eyJ") == (
        "symbols NIFTY26JAN25000CE, SBIN-EQ and keys.eyJ"
    )
