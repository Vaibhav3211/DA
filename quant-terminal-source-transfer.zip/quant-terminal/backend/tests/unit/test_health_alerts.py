from __future__ import annotations

from datetime import UTC, datetime, timedelta

from app.core.clock import utc_now
from app.domain.enums import AccountStatus, ConnectionState, DataStatus, Provider
from app.domain.models import StreamHealth
from app.observability.health import AccountHealth, SystemHealthService, WorkerStatus
from tests.conftest import build_settings


def _feed(**overrides: object) -> StreamHealth:
    values: dict[str, object] = {
        "provider": Provider.ZERODHA,
        "account_id": None,
        "stream_id": "zerodha-0",
        "state": ConnectionState.CONNECTED,
        "data_status": DataStatus.LIVE,
        "state_since": utc_now(),
        "updated_at": utc_now(),
    }
    values.update(overrides)
    return StreamHealth.model_validate(values)


def _account(**overrides: object) -> AccountHealth:
    values: dict[str, object] = {
        "account_id": "a1",
        "provider": "GROWW",
        "label": "main",
        "status": AccountStatus.AUTHENTICATED,
        "is_enabled": True,
        "token_expires_at": utc_now() + timedelta(hours=5),
    }
    values.update(overrides)
    return AccountHealth.model_validate(values)


def _feed_codes(*feeds: StreamHealth) -> list[str]:
    return [a.code for a in SystemHealthService._feed_alerts(list(feeds))]


def _account_codes(now: datetime, *accounts: AccountHealth) -> list[str]:
    return [a.code for a in SystemHealthService._account_alerts(list(accounts), now)]


def test_feed_alerts() -> None:
    assert _feed_codes(_feed()) == []
    assert _feed_codes(_feed(state=ConnectionState.DISCONNECTED)) == ["provider_disconnected"]
    assert _feed_codes(_feed(auth_required=True)) == ["provider_auth_required"]
    # Stale data only alerts while the market is in session.
    assert _feed_codes(_feed(data_status=DataStatus.STALE, session_open=True)) == ["feed_stale"]
    assert _feed_codes(_feed(data_status=DataStatus.STALE, session_open=False)) == []
    assert _feed_codes(_feed(data_status=DataStatus.STALE)) == []


def test_account_alerts() -> None:
    now = utc_now()
    assert _account_codes(now, _account()) == []
    expired = now - timedelta(seconds=1)
    assert _account_codes(now, _account(token_expires_at=expired)) == ["token_expired"]
    assert _account_codes(now, _account(status=AccountStatus.AUTH_REQUIRED, token_expires_at=expired)) == [
        "token_expired"
    ]
    # Rejected mid-session (token not yet past its expiry) or never authenticated.
    assert _account_codes(now, _account(status=AccountStatus.AUTH_REQUIRED)) == ["auth_required"]
    assert _account_codes(now, _account(status=AccountStatus.AUTH_REQUIRED, token_expires_at=None)) == [
        "auth_required"
    ]
    assert _account_codes(now, _account(token_expires_at=now + timedelta(minutes=10))) == ["token_expiring"]
    assert _account_codes(now, _account(status=AccountStatus.NEEDS_CREDENTIALS, token_expires_at=None)) == [
        "credentials_missing"
    ]
    # Missing credentials and a user logout take precedence over the stale expiry they leave behind.
    assert _account_codes(
        now, _account(status=AccountStatus.NEEDS_CREDENTIALS, token_expires_at=expired)
    ) == ["credentials_missing"]
    assert _account_codes(now, _account(status=AccountStatus.DISCONNECTED, token_expires_at=None)) == [
        "account_disconnected"
    ]
    assert _account_codes(now, _account(is_enabled=False, status=AccountStatus.AUTH_REQUIRED)) == []


class _FakeContainer:
    def __init__(self) -> None:
        self.settings = build_settings(provider_queue_size=100)


def test_worker_alerts() -> None:
    service = SystemHealthService(_FakeContainer())  # type: ignore[arg-type]
    down = WorkerStatus(worker="strategy-worker", alive=False)
    busy = WorkerStatus(worker="market-data-worker", alive=True, details={"queue_depth": 85})
    healthy = WorkerStatus(worker="market-data-worker", alive=True, details={"queue_depth": 10})
    assert [a.code for a in service._worker_alerts([down, busy])] == ["worker_down", "queue_depth_high"]
    assert service._worker_alerts([healthy]) == []


def test_calendar_alerts_warn_before_and_after_published_coverage_ends() -> None:
    service = SystemHealthService(_FakeContainer())  # type: ignore[arg-type]
    now = datetime(2026, 12, 10, 6, 0, tzinfo=UTC)

    def worker(alive: bool = True, **coverage: str) -> WorkerStatus:
        return WorkerStatus(
            worker="market-data-worker", alive=alive, details={"calendar_verified_until": coverage}
        )

    alerts = service._calendar_alerts([worker(NSE="2026-12-31", BSE="2026-12-09", MCX="not-a-date")], now)

    assert [(a.severity, a.code, a.subject) for a in alerts] == [
        ("warning", "calendar_unverified", "BSE"),
        ("info", "calendar_coverage_ending", "NSE"),
    ]
    assert service._calendar_alerts([worker(NSE="2027-06-30")], now) == []
    assert service._calendar_alerts([worker(False, NSE="2026-01-01")], now) == []
