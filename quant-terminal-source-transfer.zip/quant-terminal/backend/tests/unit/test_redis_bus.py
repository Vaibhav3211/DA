from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import UUID, uuid4

from app.domain.enums import CandleInterval, Provider
from app.domain.events import CommandType, WorkerCommand
from app.streaming.redis_bus import Keys, StreamMessage, Streams, _flatten, decode, encode


def test_models_round_trip_with_exact_decimals() -> None:
    command = WorkerCommand(type=CommandType.REFRESH_SUBSCRIPTIONS, provider=Provider.ZERODHA)
    restored = WorkerCommand.model_validate(decode(encode(command)))
    assert restored == command

    payload = {"price": Decimal("1450.05"), "at": datetime(2026, 1, 2, 3, 4, 5, tzinfo=UTC), "id": uuid4()}
    decoded = decode(encode(payload))
    assert decoded["price"] == "1450.05"  # exact, never a binary float
    assert decoded["at"] == "2026-01-02T03:04:05Z"
    assert UUID(decoded["id"]) == payload["id"]


def test_flatten_handles_entries_and_deleted_pending_entries() -> None:
    response = [
        ["qt:md:candles", [("1-0", {"d": '{"a": 1}'}), ("2-0", {})]],
        ["qt:signals", [("3-0", {"d": "[1, 2]"})]],
    ]
    assert _flatten(response) == [
        StreamMessage("qt:md:candles", "1-0", {"a": 1}),
        StreamMessage("qt:md:candles", "2-0", None),
        StreamMessage("qt:signals", "3-0", [1, 2]),
    ]
    assert _flatten(None) == []


def test_stream_and_key_names_are_provider_scoped() -> None:
    instrument = UUID("00000000-0000-0000-0000-000000000001")
    assert Streams.market_events(Provider.GROWW) == "qt:md:events:groww"
    assert set(Streams.all_market_events()) == {
        "qt:md:events:zerodha",
        "qt:md:events:groww",
        "qt:md:events:simulator",
    }
    assert Keys.quote(Provider.ZERODHA, instrument) == f"qt:quote:zerodha:{instrument}"
    assert Keys.partial_candle(Provider.ZERODHA, instrument, CandleInterval.M5).endswith(":5m")
