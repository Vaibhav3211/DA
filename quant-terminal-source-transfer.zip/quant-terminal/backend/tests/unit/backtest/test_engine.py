"""The backtest replay: no look-ahead, fills, exits, sizing and costs, the risk gate, undefined metrics
and replays that cannot run. Candles are 1-minute ALPHA candles from T0, 09:15 IST on a Monday."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from datetime import datetime, timedelta
from decimal import Decimal
from itertools import pairwise
from typing import Any, NoReturn

import pytest

from app.backtest.engine import BacktestError, BacktestResult, Replay, replay_problem, run_backtest, sample
from app.domain.enums import (
    CandleInterval,
    DataRequirement,
    EventType,
    ExitCheck,
    ExitReason,
    FillTiming,
    InstrumentType,
    OppositeSignal,
    PositionSide,
    SignalType,
    SizingMethod,
    StopTargetSource,
    TradeOutcome,
    TradeSides,
)
from app.domain.models import Candle, SignalCandidate
from app.domain.models.backtest import Measure, SignalStats, SkippedEntry, TradeRules
from app.domain.models.signal import TargetLevel
from app.risk.engine import RuleOverride, resolve_policy
from tests.backtest_support import LIMITS, WORKSPACE, Context, by_minute, replay, scripted, trade_rules
from tests.candle_support import INSTRUMENT, T0, bar, closes
from tests.signal_support import ALPHA, make_candidate

M1 = CandleInterval.M1
LONG, SHORT = PositionSide.LONG, PositionSide.SHORT
BUY = make_candidate()  # entry 100.10, stop-loss 98.05, target 104.20
SELL = make_candidate(
    signal_type=SignalType.SELL,
    entry_price=Decimal("100.00"),
    stop_loss=Decimal("102.05"),
    targets=(TargetLevel(label="T1", price=Decimal("95.90")),),
)
EXIT = make_candidate(signal_type=SignalType.EXIT, entry_price=None, stop_loss=None, targets=())
NO_TRADE = "No trade closed in the evaluated period."


def minute(n: int) -> datetime:
    return T0 + timedelta(minutes=n)


def boom(*_args: object) -> NoReturn:
    raise RuntimeError("boom")


async def backtest(
    candles: Sequence[Candle],
    signals: Mapping[int, SignalCandidate],
    rules: TradeRules | None = None,
    **overrides: Any,
) -> BacktestResult:
    """Replay ``candles`` with a strategy proposing ``signals`` by minutes after T0."""
    return await run_backtest(replay(scripted(by_minute(signals)), rules, **overrides), candles, LIMITS)


# ---- look-ahead and fills -----------------------------------------------------------------------------


async def test_the_strategy_sees_each_candle_once_it_closes_and_entries_fill_at_the_next_open() -> None:
    seen: list[tuple[datetime, int, datetime, datetime]] = []
    warmed: list[int] = []

    def decide(candle: Candle, context: Context) -> Sequence[SignalCandidate]:
        history = context.candles(INSTRUMENT, M1)
        seen.append((candle.bucket_start, len(history), history[-1].bucket_start, context.now()))
        return (BUY,) if candle.bucket_start == minute(3) else ()

    entry = scripted(
        decide,
        on_start=lambda context: warmed.append(len(context.candles(INSTRUMENT, M1))),
        warmup_candles=3,
    )
    candles = [
        *closes([100, 100, 100, 100]),
        bar(4, "100.80", open_="100.50", high="101", low="100.20"),
        bar(5, "104", open_="101", high="104.50", low="100.90"),
        bar(6, "104"),
    ]
    result = await run_backtest(replay(entry), candles, LIMITS)

    # The warm-up candles are folded in before the first call. Each call then has the candle that just
    # closed as the latest one, and the clock at its close.
    assert warmed == [3]
    assert seen == [(c.bucket_start, 3, c.bucket_start, c.bucket_end) for c in candles[3:]]
    period = result.summary.period
    assert (period.warmup_candles, period.evaluated_candles) == (3, 4)
    assert (period.dataset_from, period.evaluated_from, period.evaluated_to) == (T0, minute(3), minute(7))

    [trade] = result.trades
    assert (trade.side, trade.quantity, trade.entry_at, trade.entry_price) == (
        LONG,
        10,
        minute(4),
        Decimal("100.50"),
    )
    assert trade.entry_signal.decided_at == minute(4)
    assert (trade.exit_reason, trade.exit_at, trade.exit_price) == (
        ExitReason.TARGET,
        minute(5),
        Decimal("104.20"),
    )
    assert (trade.candles_held, trade.gross_pnl, trade.net_pnl) == (2, Decimal("37.00"), Decimal("37.00"))
    assert (trade.return_pct, trade.outcome) == (Decimal("3.6816"), TradeOutcome.WIN)
    assert [point.equity for point in result.equity_curve] == [
        Decimal(100_000),
        Decimal(100_000),
        Decimal(100_003),
        Decimal(100_037),
        Decimal(100_037),
    ]
    assert result.summary.equity_points == 5

    metrics = result.summary.metrics
    assert (metrics.closed_trades, metrics.wins, metrics.win_rate_pct) == (1, 1, Measure(value=Decimal(100)))
    assert (metrics.net_return_pct, metrics.final_equity) == (Decimal("0.04"), Decimal("100037.00"))
    assert (metrics.max_drawdown, metrics.max_drawdown_pct) == (Decimal(0), Measure(value=Decimal(0)))
    assert metrics.profit_factor == Measure(reason="No losing trades, so there is no loss to divide by")
    assert metrics.average_loss == Measure(reason="No losing trades")
    assert (result.summary.signals.proposed, result.summary.signals.allowed) == (1, 1)
    assert result.summary.notes == ()


async def test_same_close_fills_at_the_deciding_close_and_is_noted_as_optimistic() -> None:
    candles = [
        bar(0, "100", open_="99", high="100", low="97.50"),
        bar(1, "104", open_="100", high="104.50", low="99.50"),
    ]
    result = await backtest(candles, {0: BUY}, trade_rules(fill=FillTiming.SAME_CLOSE))

    [trade] = result.trades
    # Filled at the first candle's close: its low, under the stop-loss, came before the fill.
    assert (trade.entry_at, trade.entry_price) == (T0, Decimal(100))
    assert (trade.exit_reason, trade.exit_at, trade.exit_price, trade.candles_held) == (
        ExitReason.TARGET,
        minute(1),
        Decimal("104.20"),
        1,
    )
    assert (trade.gross_pnl, trade.return_pct) == (Decimal("42.00"), Decimal("4.2000"))
    optimistic = (
        "Decisions filled at the close they were taken at (SAME_CLOSE), a price only known once the "
        "candle had closed, so the results are optimistic."
    )
    assert optimistic in result.summary.notes


# ---- exits --------------------------------------------------------------------------------------------


async def test_a_candle_reaching_both_levels_is_assumed_to_hit_the_stop_loss() -> None:
    candles = [
        bar(0, "100"),
        bar(1, "100.20", open_="100", high="100.50", low="99.80"),
        bar(2, "101", open_="100.20", high="104.50", low="98.00"),
    ]
    result = await backtest(candles, {0: BUY})

    [trade] = result.trades
    assert (trade.exit_reason, trade.exit_at, trade.exit_price) == (
        ExitReason.STOP_LOSS,
        minute(2),
        Decimal("98.05"),
    )
    assert (trade.both_touched, trade.gap_exit) == (True, False)
    assert (trade.candles_held, trade.gross_pnl) == (2, Decimal("-19.50"))
    assert result.summary.metrics.both_touched_trades == 1
    assumed = (
        "In 1 trades one candle reached both the stop-loss and the target; the order inside a candle is "
        "unknown, so the stop-loss was assumed."
    )
    assert assumed in result.summary.notes


async def test_a_candle_opening_beyond_the_stop_loss_exits_at_its_open() -> None:
    candles = [
        bar(0, "100"),
        bar(1, "100.20", open_="100", high="100.50", low="99.80"),
        bar(2, "97.80", open_="97.50", high="98", low="97"),
    ]
    result = await backtest(candles, {0: BUY})

    [trade] = result.trades
    assert (trade.exit_reason, trade.exit_price, trade.gap_exit, trade.both_touched) == (
        ExitReason.STOP_LOSS,
        Decimal("97.50"),
        True,
        False,
    )
    assert trade.gross_pnl == Decimal("-25.00")
    assert result.summary.metrics.gap_exits == 1


async def test_percent_levels_are_set_from_the_entry_fill_instead_of_the_signal() -> None:
    candles = [
        bar(0, "100"),
        bar(1, "100.20", open_="100", high="100.50", low="99.80"),
        bar(2, "100.90", open_="100.20", high="101.10", low="100.10"),  # short of the signal's 104.20
    ]
    rules = trade_rules(stop_target=StopTargetSource.PERCENT, stop_pct=Decimal(2), target_pct=Decimal(1))
    result = await backtest(candles, {0: BUY}, rules)

    [trade] = result.trades
    assert (trade.stop_loss, trade.target) == (Decimal("98.00"), Decimal("101.00"))
    assert (trade.exit_reason, trade.exit_at, trade.exit_price) == (
        ExitReason.TARGET,
        minute(2),
        Decimal("101.00"),
    )
    assert trade.gross_pnl == Decimal("10.00")


async def test_close_exit_checks_decide_on_a_close_and_fill_at_the_next_open() -> None:
    candles = [
        bar(0, "100"),
        bar(1, "100.20", open_="100", high="100.50", low="99.80"),
        bar(2, "99", open_="100.20", high="100.40", low="97"),  # only the low passes the stop-loss
        bar(3, "97.90", open_="99", high="99.20", low="97.50"),  # the close passes it
        bar(4, "97.70", open_="97.80", high="98", low="97.60"),
    ]
    result = await backtest(candles, {0: BUY}, trade_rules(exit_check=ExitCheck.CLOSE))

    [trade] = result.trades
    assert (trade.exit_reason, trade.exit_at, trade.exit_price) == (
        ExitReason.STOP_LOSS,
        minute(4),
        Decimal("97.80"),
    )
    assert (trade.candles_held, trade.gross_pnl) == (3, Decimal("-22.00"))
    closes_only = "Stop-loss and target were checked against closes only, not inside candles."
    assert closes_only in result.summary.notes


@pytest.mark.parametrize("opposite", [OppositeSignal.REVERSE, OppositeSignal.CLOSE])
async def test_an_opposite_signal_closes_the_position_and_may_reverse_it(opposite: OppositeSignal) -> None:
    candles = [
        bar(0, "100"),
        bar(1, "100.50", open_="100", high="100.60", low="99.90"),
        bar(2, "100", open_="100.50", high="100.60", low="99.90"),
        bar(3, "99.60", open_="99.80", high="100", low="99.50"),
    ]
    result = await backtest(candles, {0: BUY, 2: SELL}, trade_rules(opposite_signal=opposite))

    [trade] = result.trades
    assert (trade.side, trade.exit_reason, trade.exit_at, trade.exit_price) == (
        LONG,
        ExitReason.OPPOSITE_SIGNAL,
        minute(3),
        Decimal("99.80"),
    )
    assert trade.gross_pnl == Decimal("-2.00")
    assert trade.exit_signal is not None
    assert trade.exit_signal.signal_type is SignalType.SELL
    position = result.summary.open_position
    if opposite is OppositeSignal.CLOSE:
        assert position is None
    else:
        assert position is not None
        assert (position.side, position.quantity, position.entry_at, position.entry_price) == (
            SHORT,
            10,
            minute(3),
            Decimal("99.80"),
        )
        assert (position.stop_loss, position.target, position.unrealized_pnl) == (
            Decimal("102.05"),
            Decimal("95.90"),
            Decimal("2.00"),
        )


async def test_an_exit_signal_closes_the_position_at_the_next_open() -> None:
    result = await backtest(closes([100, 100, 101, 102]), {0: BUY, 2: EXIT})

    [trade] = result.trades
    assert (trade.exit_reason, trade.exit_at, trade.exit_price, trade.candles_held) == (
        ExitReason.EXIT_SIGNAL,
        minute(3),
        Decimal(102),
        2,
    )
    assert trade.gross_pnl == Decimal("20.00")
    assert trade.exit_signal is not None
    assert trade.exit_signal.signal_type is SignalType.EXIT


async def test_the_holding_limit_closes_the_position_after_that_many_candles() -> None:
    result = await backtest(closes([100, 100, "100.50", 101]), {0: BUY}, trade_rules(max_holding_candles=2))

    [trade] = result.trades
    assert (trade.exit_reason, trade.exit_at, trade.exit_price, trade.candles_held) == (
        ExitReason.MAX_HOLDING,
        minute(3),
        Decimal(101),
        2,
    )
    assert trade.gross_pnl == Decimal("10.00")


# ---- the end of the data ------------------------------------------------------------------------------


async def test_a_position_still_open_at_the_end_is_not_a_closed_trade() -> None:
    candles = [bar(0, "100"), bar(1, "101", open_="100", high="101", low="99.90"), bar(2, "101.50")]
    result = await backtest(candles, {0: BUY})

    summary = result.summary
    assert result.trades == ()
    position = summary.open_position
    assert position is not None
    assert (position.side, position.quantity, position.entry_at, position.entry_price) == (
        LONG,
        10,
        minute(1),
        Decimal(100),
    )
    assert (position.stop_loss, position.target, position.candles_held) == (
        Decimal("98.05"),
        Decimal("104.20"),
        2,
    )
    assert (position.marked_at, position.mark_price, position.unrealized_pnl) == (
        minute(3),
        Decimal("101.50"),
        Decimal("15.00"),
    )
    assert summary.metrics.closed_trades == 0
    assert summary.metrics.win_rate_pct == Measure(reason="No closed trades")
    assert summary.metrics.final_equity == Decimal("100015.00")
    assert summary.notes == (NO_TRADE,)


async def test_an_entry_decided_on_the_last_candle_is_reported_as_pending() -> None:
    result = await backtest(closes([100, 100]), {1: BUY})

    assert result.summary.open_position is None
    assert result.summary.pending_at_end == (
        "LONG entry from the BUY signal decided at 2026-01-05T03:47:00+00:00 had no later candle to fill on",
    )


async def test_zero_trades_leave_the_metrics_undefined_with_reasons() -> None:
    result = await backtest(closes([100, 101, 99]), {})

    summary, metrics = result.summary, result.summary.metrics
    assert (result.trades, summary.open_position, summary.signals) == ((), None, SignalStats())
    assert (metrics.closed_trades, metrics.wins, metrics.losses, metrics.breakevens) == (0, 0, 0, 0)
    assert metrics.win_rate_pct == Measure(reason="No closed trades")
    assert metrics.average_win == Measure(reason="No winning trades")
    assert metrics.average_loss == Measure(reason="No losing trades")
    assert metrics.profit_factor == Measure(reason="No closed trades")
    assert (metrics.max_drawdown, metrics.max_drawdown_pct) == (Decimal(0), Measure(value=Decimal(0)))
    assert metrics.final_equity == Decimal(100_000)
    assert summary.notes == (f"{NO_TRADE} The strategy proposed no signals.",)


# ---- sizing and costs ---------------------------------------------------------------------------------


async def test_risk_sizing_rounds_down_to_the_lot_and_fills_pay_fees_and_slippage() -> None:
    rules = trade_rules(
        sizing=SizingMethod.RISK_PERCENT,
        quantity=None,
        risk_pct=Decimal(1),
        slippage_ticks=2,
        fee_pct_per_side=Decimal("0.1"),
        fee_per_order=Decimal(20),
    )
    candles = [
        bar(0, "100"),
        bar(1, "100.20", open_="100.00", high="100.50", low="99.80"),
        bar(2, "104.30", open_="100.20", high="104.50", low="100.10"),
    ]
    result = await backtest(candles, {0: BUY}, rules, instrument=ALPHA.model_copy(update={"lot_size": 5}))

    [trade] = result.trades
    # 1% of 100000 at risk, 2.05 a unit from the 100.10 fill (2 ticks over the open) to the stop-loss:
    # 487 units, 485 in lots of 5.
    assert trade.quantity == 485
    assert (trade.entry_reference, trade.entry_price) == (Decimal("100.00"), Decimal("100.10"))
    assert (trade.exit_reference, trade.exit_price) == (Decimal("104.20"), Decimal("104.10"))
    # 0.1% of each fill's value plus 20 an order: 68.55 for the entry and 70.49 for the exit.
    assert (trade.fees, trade.slippage) == (Decimal("139.04"), Decimal("97.00"))
    assert (trade.gross_pnl, trade.net_pnl, trade.return_pct) == (
        Decimal("2037.00"),
        Decimal("1800.96"),
        Decimal("3.7133"),
    )
    assert [point.equity for point in result.equity_curve] == [
        Decimal(100_000),
        Decimal(100_000),
        Decimal("99979.95"),
        Decimal("101800.96"),
    ]
    metrics = result.summary.metrics
    assert (metrics.fees, metrics.slippage, metrics.final_equity) == (
        Decimal("139.04"),
        Decimal("97.00"),
        Decimal("101800.96"),
    )
    assert (metrics.max_drawdown, metrics.max_drawdown_pct) == (
        Decimal("20.05"),
        Measure(value=Decimal("0.02")),
    )
    assert (metrics.drawdown_peak_at, metrics.drawdown_trough_at) == (T0, minute(2))


async def test_entries_the_trade_rules_cannot_take_are_skipped_with_the_reason() -> None:
    long_only = await backtest(closes([100, 100]), {0: SELL}, trade_rules(sides=TradeSides.LONG_ONLY))
    assert long_only.summary.skipped_entries == (
        SkippedEntry(
            at=minute(1), signal_type=SignalType.SELL, reason="SHORT trades are not allowed (sides LONG_ONLY)"
        ),
    )
    assert long_only.summary.skipped_entries_total == 1

    gapped = await backtest([bar(0, "100"), bar(1, "98.50", open_="98.00")], {0: BUY})
    assert gapped.summary.skipped_entries == (
        SkippedEntry(
            at=minute(1),
            signal_type=SignalType.BUY,
            reason="the fill price 98.00 was already at or past the stop-loss 98.05",
        ),
    )
    assert (gapped.trades, gapped.summary.open_position) == ((), None)


RISK = {"sizing": SizingMethod.RISK_PERCENT, "quantity": None, "risk_pct": Decimal(1)}


@pytest.mark.parametrize(
    ("overrides", "problem"),
    [
        ({"stop_target": StopTargetSource.PERCENT}, "stop_target PERCENT needs stop_pct, target_pct or both"),
        ({"target_pct": Decimal(2)}, "stop_pct and target_pct apply only to stop_target PERCENT"),
        ({"quantity": None}, "sizing FIXED_QUANTITY needs quantity"),
        ({"amount": Decimal(5000)}, "amount applies only to sizing FIXED_AMOUNT"),
        ({**RISK, "stop_target": StopTargetSource.NONE}, "sizing RISK_PERCENT needs a stop-loss"),
        (
            {**RISK, "stop_target": StopTargetSource.PERCENT, "target_pct": Decimal(2)},
            "sizing RISK_PERCENT needs a stop-loss",
        ),
    ],
)
def test_trade_rules_that_contradict_each_other_are_refused(overrides: dict[str, Any], problem: str) -> None:
    with pytest.raises(ValueError, match=re.escape(problem)):
        trade_rules(**overrides)


# ---- the risk gate ------------------------------------------------------------------------------------


async def test_session_status_blocks_signals_decided_at_the_close_unless_allowed() -> None:
    candles = [bar(373, "100"), bar(374, "100")]  # 15:28 and 15:29 IST; the second ends at the close

    blocked = await backtest(candles, {374: BUY})
    assert (blocked.summary.signals.blocked, blocked.summary.signals.blocked_by_rule) == (
        1,
        {"session_status": 1},
    )
    assert blocked.summary.pending_at_end == ()
    blocked_note = (
        "session_status blocked signals decided while the session was not in an allowed state: 1 POST_CLOSE "
        "(at the close, where daily candles and each session's last candle end). Live signals are blocked "
        "the same way; add the state to the rule's allowed_states to let them through."
    )
    assert blocked_note in blocked.summary.notes

    override = RuleOverride("session_status", None, True, {"allowed_states": ["OPEN", "POST_CLOSE"]})
    allowed = await backtest(candles, {374: BUY}, policy=resolve_policy([override], WORKSPACE))
    assert (allowed.summary.signals.allowed, allowed.summary.signals.blocked) == (1, 0)
    assert allowed.summary.pending_at_end == (
        "LONG entry from the BUY signal decided at 2026-01-05T10:00:00+00:00 had no later candle to fill on",
    )


# ---- what stops a backtest ----------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("warmup", "message"),
    [
        (5, "test.backtest needs 5 1m candles to warm up before it is first called, and the dataset has 3"),
        (3, "no candles are left to evaluate after the 3 warm-up candles"),
    ],
)
async def test_the_dataset_must_cover_the_warm_up_and_more(warmup: int, message: str) -> None:
    with pytest.raises(BacktestError, match=re.escape(message)):
        await run_backtest(replay(scripted(warmup_candles=warmup)), closes([100, 100, 100]), LIMITS)


async def test_a_strategy_failure_stops_the_backtest_and_names_the_candle() -> None:
    failed_call = (
        "test.backtest failed on the candle starting 2026-01-05T03:45:00+00:00: "
        "on_candle raised RuntimeError: boom"
    )
    with pytest.raises(BacktestError, match=re.escape(failed_call)):
        await run_backtest(replay(scripted(boom)), closes([100, 100]), LIMITS)

    failed_start = "test.backtest failed to start: initialize raised RuntimeError: boom"
    with pytest.raises(BacktestError, match=re.escape(failed_start)):
        await run_backtest(replay(scripted(on_start=boom)), closes([100, 100]), LIMITS)


async def test_the_time_limit_stops_a_long_replay() -> None:
    readings = iter([0.0])

    def monotonic() -> float:
        return next(readings, 100.0)

    message = "stopped after 60s at candle 1 of 3; use a shorter dataset or raise BACKTEST_MAX_SECONDS"
    with pytest.raises(BacktestError, match=re.escape(message)):
        await run_backtest(replay(scripted()), closes([100, 100, 100]), LIMITS, monotonic=monotonic)


def test_replays_that_cannot_run_say_why() -> None:
    flat = closes([100, 100])
    index = ALPHA.model_copy(update={"instrument_type": InstrumentType.INDEX})
    no_tick = ALPHA.model_copy(update={"tick_size": None})
    cases: list[tuple[Replay, Sequence[Candle], str]] = [
        (
            replay(scripted(event_types=(EventType.LTP,))),
            flat,
            "test.backtest reacts to market events (LTP), which candles cannot replay",
        ),
        (
            replay(scripted(candle_intervals=(CandleInterval.M5,))),
            flat,
            "test.backtest uses 5m candles; the dataset has 1m candles only",
        ),
        (replay(scripted(), instrument=index), flat, "test.backtest does not support INDEX instruments"),
        (
            replay(scripted(), trade_rules(slippage_ticks=1), instrument=no_tick),
            flat,
            "slippage is set in ticks, and ALPHA has no tick size",
        ),
        (replay(scripted()), [], "the dataset has no candles"),
        (
            replay(scripted(required_data=(DataRequirement.VOLUME,))),
            closes([100, 100], volume=None),
            "test.backtest needs volume, and none of the dataset's candles has it",
        ),
    ]
    for case, candles, problem in cases:
        assert replay_problem(case, candles) == problem
    assert replay_problem(replay(scripted()), flat) is None


async def test_run_backtest_refuses_a_replay_that_cannot_run() -> None:
    with pytest.raises(BacktestError, match="the dataset has no candles"):
        await run_backtest(replay(scripted()), [], LIMITS)


async def test_notes_name_simulated_data_and_candles_without_the_volume_the_strategy_needs() -> None:
    entry = scripted(required_data=(DataRequirement.VOLUME,))
    candles = [bar(0, "100", volume=None), bar(1, "100")]
    result = await run_backtest(replay(entry, simulated=True), candles, LIMITS)

    assert result.summary.notes == (
        "The dataset was recorded from the development simulator: these are not market prices.",
        "1 candles have no volume, which the strategy needs.",
        f"{NO_TRADE} The strategy proposed no signals.",
    )


# ---- the stored equity curve --------------------------------------------------------------------------


def test_a_long_equity_curve_is_sampled_keeping_its_ends_and_extremes() -> None:
    values = {17: 10, 63: 90}
    points = [(minute(i), Decimal(values.get(i, 50))) for i in range(101)]

    kept = sample(points, 10)
    assert len(kept) <= 10
    assert (kept[0], kept[-1]) == (points[0], points[-1])
    assert points[17] in kept
    assert points[63] in kept
    assert all(earlier[0] < later[0] for earlier, later in pairwise(kept))
    assert sample(points[:10], 10) == points[:10]
