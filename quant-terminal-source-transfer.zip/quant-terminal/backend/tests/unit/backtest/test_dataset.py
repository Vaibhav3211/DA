"""Backtest datasets: source candles placed on the exchange calendar, their coverage, identity and replay
form. The calendar is the NSE week in backtest_support (Wednesday a holiday); MCX has no calendar."""

from __future__ import annotations

import re
from collections.abc import Sequence
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from typing import Any

import pytest

from app.backtest.dataset import (
    INCONSISTENT_OHLC,
    BuiltDataset,
    DatasetCandle,
    DatasetError,
    SourceCandle,
    build,
    dataset_sha,
    to_candles,
)
from app.core.config import CandleAnchor
from app.domain.enums import (
    CandleFlag,
    CandleInterval,
    DatasetSource,
    DataStatus,
    Exchange,
    InstrumentType,
    Provider,
)
from app.domain.models import Instrument
from app.domain.models.backtest import GapRange
from tests.backtest_support import FRI, MON, THU, TUE, WED, ist, nse_calendar
from tests.candle_support import bar
from tests.signal_support import ALPHA

M15, H1, D1 = CandleInterval.M15, CandleInterval.H1, CandleInterval.D1
SESSION, CLOCK = CandleAnchor.SESSION, CandleAnchor.CLOCK


def at(day: date, hour: int, minute: int) -> datetime:
    return ist(day, time(hour, minute))


def source(start: datetime, price: str = "100", *, volume: int | None = 10, **fields: Any) -> SourceCandle:
    """A flat source candle at ``price``; ``fields`` override its prices or flags."""
    value = Decimal(price)
    values: dict[str, Any] = {"open": value, "high": value, "low": value, "close": value, "volume": volume}
    return SourceCandle(start, **(values | fields))


def built(
    candles: Sequence[SourceCandle],
    interval: CandleInterval = M15,
    *,
    first_day: date = MON,
    last_day: date | None = None,
    live_anchor: CandleAnchor = SESSION,
    instrument: Instrument = ALPHA,
    **options: Any,
) -> BuiltDataset:
    return build(
        candles,
        calendar=nse_calendar(),
        instrument=instrument,
        interval=interval,
        first_day=first_day,
        last_day=last_day or first_day,
        live_anchor=live_anchor,
        **options,
    )


def test_coverage_counts_the_candles_the_session_expects_and_lists_the_gaps() -> None:
    starts = [at(MON, 9, 15) + timedelta(minutes=15 * i) for i in range(25)]
    missing = {at(MON, 10, 0), at(MON, 10, 15)}
    dataset = built([source(start) for start in starts if start not in missing])

    coverage = dataset.coverage
    assert (
        coverage.anchor,
        coverage.session_days,
        coverage.expected,
        coverage.present,
        coverage.missing,
    ) == (
        "session",
        1,
        25,
        23,
        2,
    )
    assert coverage.coverage_pct == Decimal("92.00")
    assert (coverage.gaps, coverage.gap_total) == (
        (GapRange(start=at(MON, 10, 0), end=at(MON, 10, 30), candles=2),),
        1,
    )
    assert len(dataset.candles) == 23
    assert (dataset.candles[0].start, dataset.candles[-1].end) == (at(MON, 9, 15), at(MON, 15, 30))
    assert coverage.notes == ()


@pytest.mark.parametrize(
    ("starts", "live_anchor", "chosen"),
    [
        ([(9, 15), (10, 15), (11, 15)], CLOCK, SESSION),
        ([(9, 15), (10, 0), (11, 0)], SESSION, CLOCK),
    ],
)
def test_intraday_candles_keep_the_grid_more_of_them_fit_and_say_when_live_candles_differ(
    starts: list[tuple[int, int]], live_anchor: CandleAnchor, chosen: CandleAnchor
) -> None:
    dataset = built([source(at(MON, *start)) for start in starts], H1, live_anchor=live_anchor)

    coverage = dataset.coverage
    assert (coverage.anchor, coverage.expected, coverage.present, coverage.left_out) == (
        chosen.value,
        7,
        3,
        0,
    )
    assert coverage.notes == (
        f"These candles start on the {chosen.value} grid while live candles use {live_anchor.value} "
        "(CANDLE_ANCHOR), so their boundaries differ from live candles.",
    )


def test_daily_candles_span_their_session_and_closed_days_are_left_out() -> None:
    dataset = built([source(at(day, 0, 0)) for day in (MON, TUE, WED, FRI)], D1, last_day=FRI)

    assert [(candle.start, candle.end) for candle in dataset.candles] == [
        (at(day, 9, 15), at(day, 15, 30)) for day in (MON, TUE, FRI)
    ]
    coverage = dataset.coverage
    assert (coverage.anchor, coverage.session_days, coverage.expected, coverage.present) == (None, 4, 4, 3)
    assert coverage.gaps == (GapRange(start=at(THU, 9, 15), end=at(THU, 15, 30), candles=1),)
    assert coverage.left_out_by_reason == {"CLOSED_DAY": 1}
    assert coverage.left_out_examples == ("2026-01-07 00:00: the exchange is closed (holiday)",)


def test_days_without_a_calendar_keep_their_candles_unchecked() -> None:
    mcx = ALPHA.model_copy(update={"exchange": Exchange.MCX})
    dataset = built([source(at(MON, 9, 15))], instrument=mcx)

    [candle] = dataset.candles
    assert (candle.end, candle.flags) == (at(MON, 9, 30), (CandleFlag.OUTSIDE_SESSION.value,))
    coverage = dataset.coverage
    assert (coverage.expected, coverage.coverage_pct, coverage.unknown_days, coverage.unknown_days_total) == (
        0,
        None,
        (MON,),
        1,
    )
    assert coverage.notes == (
        "The MCX calendar is unknown on 1 days: their candles were kept unchecked and flagged "
        "OUTSIDE_SESSION, and nothing is counted as missing on them.",
    )


def test_candles_off_the_calendar_are_left_out_counted_and_described() -> None:
    candles = [source(at(MON, 9, 0)), source(at(MON, 9, 15)), source(at(MON, 9, 20)), source(at(TUE, 9, 15))]
    dataset = built(candles)

    assert [candle.start for candle in dataset.candles] == [at(MON, 9, 15)]
    coverage = dataset.coverage
    assert (coverage.left_out, coverage.left_out_by_reason) == (
        3,
        {"OFF_GRID": 1, "OUTSIDE_DATES": 1, "OUTSIDE_HOURS": 1},
    )
    assert coverage.left_out_examples == (
        "2026-01-05 09:00: outside the session hours",
        "2026-01-05 09:20: not on the session grid of 15m candles",
        "2026-01-06 09:15: outside the requested dates (2026-01-06)",
    )
    assert coverage.notes == ("3 source candles were left out; see left_out_by_reason.",)


def test_candles_that_cannot_have_closed_yet_are_not_missing() -> None:
    coverage = built([source(at(MON, 9, 15))], until=at(MON, 10, 0)).coverage

    assert (coverage.expected, coverage.present, coverage.missing) == (3, 1, 2)


def test_inconsistent_candles_are_kept_and_flagged_and_repeats_are_kept_once() -> None:
    candles = [
        source(at(MON, 9, 15), high=Decimal(99)),  # the high is under the open and close
        source(at(MON, 9, 30), "101"),
        source(at(MON, 9, 30), "102"),
    ]
    dataset = built(candles, requests=3, duplicates=2)

    first, second = dataset.candles
    assert (first.high, first.flags) == (Decimal(99), (INCONSISTENT_OHLC,))
    assert (second.close, second.flags) == (Decimal(101), ())
    coverage = dataset.coverage
    assert (coverage.inconsistent, coverage.duplicates, coverage.requests) == (1, 3, 3)


def test_index_candles_carry_no_volume() -> None:
    index = ALPHA.model_copy(update={"instrument_type": InstrumentType.INDEX})
    dataset = built([source(at(MON, 9, 15), volume=500)], instrument=index)

    [candle] = dataset.candles
    assert (candle.volume, candle.flags) == (None, (CandleFlag.VOLUME_UNAVAILABLE.value,))
    assert dataset.coverage.without_volume == 1
    assert "Index candles carry no volume, so they are flagged VOLUME_UNAVAILABLE." in dataset.coverage.notes


def test_recorded_candles_keep_their_flags_and_count_as_incomplete_after_a_gap() -> None:
    recorded = bar(0, "100", interval=M15, flags=(CandleFlag.GAP_BEFORE,))
    dataset = built([SourceCandle.from_candle(recorded)])

    [candle] = dataset.candles
    assert candle.flags == (CandleFlag.GAP_BEFORE.value,)
    assert dataset.coverage.incomplete == 1


def test_a_source_that_fits_nothing_cannot_form_a_dataset() -> None:
    empty = "the source has no ALPHA 15m candles from 2026-01-05 to 2026-01-05"
    with pytest.raises(DatasetError, match=re.escape(empty)):
        built([])

    closed = (
        "none of the 1 source candles fits the NSE calendar for the ALPHA 15m candles from 2026-01-07 to "
        "2026-01-07 (1 CLOSED_DAY); e.g. 2026-01-07 09:15: the exchange is closed (holiday)"
    )
    with pytest.raises(DatasetError, match=re.escape(closed)):
        built([source(at(WED, 9, 15))], first_day=WED)


def test_days_past_the_published_calendar_have_assumed_hours() -> None:
    later = date(2026, 1, 12)
    coverage = built([source(at(later, 9, 15))], first_day=later).coverage

    assert (coverage.assumed_days, coverage.assumed_days_total, coverage.expected) == ((later,), 1, 25)
    assert coverage.notes == (
        "1 session days are past the published NSE calendar, so their regular hours are assumed.",
    )


def test_the_dataset_sha_depends_on_the_values_not_their_notation() -> None:
    def candle(price: str, *flags: str) -> DatasetCandle:
        value = Decimal(price)
        return DatasetCandle(at(MON, 9, 15), at(MON, 9, 30), value, value, value, value, 10, flags=flags)

    def sha(item: DatasetCandle, provider: Provider = Provider.ZERODHA) -> str:
        return dataset_sha(provider, DatasetSource.PROVIDER_HISTORY, ALPHA.id, M15, [item])

    assert sha(candle("1.50")) == sha(candle("1.5"))
    assert sha(candle("1.5")) != sha(candle("1.5", CandleFlag.GAP_BEFORE.value))
    assert sha(candle("1.5")) != sha(candle("1.5"), Provider.GROWW)


@pytest.mark.parametrize(("simulated", "status"), [(True, DataStatus.SIMULATED), (False, DataStatus.LIVE)])
def test_dataset_candles_replay_as_closed_candles_of_the_feed_they_stand_for(
    simulated: bool, status: DataStatus
) -> None:
    stored = DatasetCandle(
        at(MON, 9, 15),
        at(MON, 9, 30),
        Decimal(100),
        Decimal(101),
        Decimal(99),
        Decimal("100.5"),
        10,
        flags=(CandleFlag.GAP_BEFORE.value, INCONSISTENT_OHLC),
    )
    [candle] = to_candles(
        [stored], instrument=ALPHA, provider=Provider.ZERODHA, interval=M15, simulated=simulated
    )

    assert (candle.instrument_id, candle.bucket_start, candle.bucket_end) == (
        ALPHA.id,
        at(MON, 9, 15),
        at(MON, 9, 30),
    )
    assert (candle.close_price, candle.volume, candle.flags) == (
        Decimal("100.5"),
        10,
        (CandleFlag.GAP_BEFORE,),
    )
    assert (candle.data_status, candle.is_closed, candle.event_count) == (status, True, 0)
