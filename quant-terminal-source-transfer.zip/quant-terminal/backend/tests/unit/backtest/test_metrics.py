from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal

import pytest

from app.backtest.metrics import NO_CLOSED_TRADES, measure, money
from app.domain.enums import ExitReason, PositionSide, SignalType, TradeOutcome
from app.domain.models.backtest import BacktestTrade, Measure, SignalRef
from tests.candle_support import T0

CAPITAL = Decimal(1000)


def at(minutes: int) -> datetime:
    return T0 + timedelta(minutes=minutes)


def trade(
    net: str, *, gross: str | None = None, fees: str = "0", both: bool = False, gap: bool = False
) -> BacktestTrade:
    result = Decimal(net)
    outcome = TradeOutcome.WIN if result > 0 else TradeOutcome.LOSS if result < 0 else TradeOutcome.BREAKEVEN
    return BacktestTrade(
        number=1,
        side=PositionSide.LONG,
        quantity=10,
        entry_at=at(0),
        entry_reference=Decimal(100),
        entry_price=Decimal(100),
        exit_at=at(5),
        exit_reference=Decimal(101),
        exit_price=Decimal(101),
        exit_reason=ExitReason.TARGET,
        stop_loss=None,
        target=None,
        both_touched=both,
        gap_exit=gap,
        candles_held=5,
        gross_pnl=Decimal(gross if gross is not None else net),
        fees=Decimal(fees),
        slippage=Decimal(0),
        net_pnl=result,
        return_pct=Decimal(0),
        outcome=outcome,
        entry_signal=SignalRef(signal_type=SignalType.BUY, decided_at=at(0), candle_start=at(-1)),
    )


def curve(*values: int) -> list[tuple[datetime, Decimal]]:
    return [(at(index), Decimal(value)) for index, value in enumerate(values)]


def test_breakeven_trades_count_as_closed_trades_but_not_as_wins() -> None:
    trades = [trade("10", gross="11", fees="1"), trade("-5", both=True), trade("0", gap=True)]

    metrics = measure(trades, initial_capital=CAPITAL, equity=curve(1000, 1005))

    assert (metrics.closed_trades, metrics.wins, metrics.losses, metrics.breakevens) == (3, 1, 1, 1)
    assert metrics.win_rate_pct == Measure(value=Decimal("33.33"))
    assert metrics.average_win == Measure(value=Decimal(10))
    assert metrics.average_loss == Measure(value=Decimal(-5))
    assert metrics.profit_factor == Measure(value=Decimal(2))
    assert [str(value) for value in (metrics.net_pnl, metrics.gross_pnl, metrics.fees)] == [
        "5.00",
        "6.00",
        "1.00",
    ]
    assert (metrics.net_return_pct, metrics.gross_return_pct) == (Decimal("0.50"), Decimal("0.60"))
    assert (metrics.both_touched_trades, metrics.gap_exits) == (1, 1)
    assert metrics.final_equity == Decimal(1005)


def test_the_maximum_drawdown_is_the_largest_fall_from_an_earlier_peak() -> None:
    metrics = measure([], initial_capital=Decimal(100), equity=curve(100, 120, 90, 130, 110))

    assert metrics.max_drawdown == Decimal(30)
    assert metrics.max_drawdown_pct == Measure(value=Decimal("25.00"))
    assert (metrics.drawdown_peak_at, metrics.drawdown_trough_at) == (at(1), at(2))
    assert metrics.final_equity == Decimal(110)


def test_equity_that_never_falls_has_no_drawdown() -> None:
    metrics = measure([], initial_capital=Decimal(100), equity=curve(100, 100, 105))

    assert metrics.max_drawdown == 0
    assert metrics.max_drawdown_pct == Measure(value=Decimal(0))
    assert (metrics.drawdown_peak_at, metrics.drawdown_trough_at) == (None, None)


def test_a_fall_from_a_peak_that_is_not_positive_has_no_percentage() -> None:
    metrics = measure([], initial_capital=Decimal(100), equity=curve(0, -5))

    assert metrics.max_drawdown == Decimal(5)
    assert metrics.max_drawdown_pct == Measure(reason="The equity peak before the fall was not positive")
    assert (metrics.drawdown_peak_at, metrics.drawdown_trough_at) == (at(0), at(1))


def test_without_trades_or_equity_every_undefined_metric_says_why() -> None:
    metrics = measure([], initial_capital=CAPITAL, equity=[])

    assert (metrics.closed_trades, metrics.wins, metrics.losses, metrics.breakevens) == (0, 0, 0, 0)
    assert metrics.win_rate_pct == Measure(reason=NO_CLOSED_TRADES)
    assert metrics.average_win == Measure(reason="No winning trades")
    assert metrics.average_loss == Measure(reason="No losing trades")
    assert metrics.profit_factor == Measure(reason=NO_CLOSED_TRADES)
    assert metrics.max_drawdown_pct == Measure(reason="No equity points")
    assert (metrics.net_pnl, metrics.net_return_pct, metrics.max_drawdown) == (Decimal(0),) * 3
    assert metrics.final_equity == CAPITAL


def test_the_profit_factor_needs_a_loss_and_is_zero_without_wins() -> None:
    only_wins = measure([trade("10"), trade("0")], initial_capital=CAPITAL, equity=[])
    only_losses = measure([trade("-5"), trade("-3")], initial_capital=CAPITAL, equity=[])

    assert only_wins.profit_factor == Measure(reason="No losing trades, so there is no loss to divide by")
    assert only_wins.win_rate_pct == Measure(value=Decimal(50))
    assert only_losses.profit_factor == Measure(value=Decimal(0))
    assert only_losses.win_rate_pct == Measure(value=Decimal(0))
    assert only_losses.average_win == Measure(reason="No winning trades")
    assert only_losses.average_loss == Measure(value=Decimal(-4))


@pytest.mark.parametrize(
    ("value", "expected"), [("0.125", "0.13"), ("-0.125", "-0.13"), ("2.675", "2.68"), ("7", "7.00")]
)
def test_money_rounds_half_away_from_zero_to_the_cent(value: str, expected: str) -> None:
    assert str(money(Decimal(value))) == expected
