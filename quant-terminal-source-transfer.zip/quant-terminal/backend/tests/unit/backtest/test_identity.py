from __future__ import annotations

import json
from collections.abc import Mapping
from decimal import Decimal
from typing import Any

import pytest

from app.backtest.engine import HISTORY_RULES
from app.backtest.identity import backtest_settings, changed_paths, settings_hash
from app.domain.enums import CandleInterval, FillTiming, TradeRulesSource
from app.domain.models import Instrument
from app.domain.models.backtest import TradeRules
from app.risk.engine import RuleOverride, resolve_policy
from app.risk.rules import DATA_QUALITY, FREQUENCY
from tests.backtest_support import WORKSPACE, scripted, trade_rules
from tests.signal_support import ALPHA


def settings(
    *,
    version: str = "1.0.0",
    config: Mapping[str, Any] | None = None,
    config_hash: str = "a" * 64,
    instrument: Instrument = ALPHA,
    interval: CandleInterval = CandleInterval.M1,
    rules: TradeRules | None = None,
    rules_source: TradeRulesSource = TradeRulesSource.STRATEGY,
    overrides: tuple[RuleOverride, ...] = (),
) -> dict[str, Any]:
    return backtest_settings(
        scripted(version=version),
        config=config if config is not None else {"fast_period": 5},
        config_hash=config_hash,
        instrument=instrument,
        interval=interval,
        rules=rules if rules is not None else trade_rules(),
        rules_source=rules_source,
        policy=resolve_policy(overrides, WORKSPACE),
        signal_validity_seconds=900,
    )


def frequency(enabled: bool, **params: Any) -> tuple[RuleOverride, ...]:
    return (RuleOverride(FREQUENCY, WORKSPACE, enabled, params),)


def test_the_snapshot_records_the_code_and_only_the_risk_rules_history_can_apply() -> None:
    snapshot = settings()

    assert snapshot["strategy"] == {
        "id": "test.backtest",
        "version": "1.0.0",
        "fingerprint": scripted().fingerprint,
    }
    assert snapshot["instrument"] == {
        "id": str(ALPHA.id),
        "interval": CandleInterval.M1.value,
        "lot_size": None,
        "tick_size": "0.05",
    }
    assert list(snapshot["risk"]) == sorted(HISTORY_RULES)
    assert snapshot["risk_not_applied"] == [
        "data_quality",
        "instrument_status",
        "kill_switch",
        "live_signals",
        "strategy_enabled",
        "workspace_pause",
    ]
    assert snapshot["trade_rules"]["initial_capital"] == "100000"
    assert snapshot["trade_rules_source"] == TradeRulesSource.STRATEGY.value
    assert json.loads(json.dumps(snapshot)) == snapshot


def test_equal_decimals_written_differently_are_the_same_settings() -> None:
    old = settings(config={"threshold": Decimal("1.50")})
    new = settings(config={"threshold": Decimal("1.5")})

    assert settings_hash(old) == settings_hash(new)
    assert changed_paths(old, new) == []


@pytest.mark.parametrize(
    ("changes", "paths"),
    [
        pytest.param({"version": "1.0.1"}, ["strategy.version"], id="version"),
        pytest.param(
            {"config": {"fast_period": 8}, "config_hash": "b" * 64},
            ["configuration.config.fast_period"],
            id="parameter",
        ),
        pytest.param(
            {"config": {"fast_period": 5, "slow_period": 20}, "config_hash": "b" * 64},
            ["configuration.config.slow_period"],
            id="new-parameter",
        ),
        pytest.param({"config_hash": "b" * 64}, ["configuration.config_hash"], id="config-hash-only"),
        pytest.param({"interval": CandleInterval.M5}, ["instrument.interval"], id="interval"),
        pytest.param(
            {"instrument": ALPHA.model_copy(update={"lot_size": 50, "tick_size": Decimal("0.1")})},
            ["instrument.lot_size", "instrument.tick_size"],
            id="lot-and-tick-size",
        ),
        pytest.param({"rules": trade_rules(fill=FillTiming.SAME_CLOSE)}, ["trade_rules.fill"], id="fill"),
        pytest.param(
            {"overrides": frequency(True, max_signals=5)},
            ["risk.frequency.params.max_signals"],
            id="history-rule-params",
        ),
        pytest.param(
            {"overrides": frequency(False)},
            ["risk.frequency.enabled", "risk.frequency.params"],
            id="history-rule-disabled",
        ),
    ],
)
def test_a_change_that_can_alter_results_changes_the_hash_and_names_the_paths(
    changes: dict[str, Any], paths: list[str]
) -> None:
    old, new = settings(), settings(**changes)

    assert settings_hash(old) != settings_hash(new)
    assert changed_paths(old, new) == paths


@pytest.mark.parametrize(
    ("old_changes", "new_changes"),
    [
        pytest.param({}, {"rules_source": TradeRulesSource.CONFIGURATION}, id="rules-source"),
        pytest.param(
            {},
            {"overrides": (RuleOverride(DATA_QUALITY, WORKSPACE, True, {"max_age_seconds": 30}),)},
            id="live-only-rule",
        ),
        pytest.param(
            {"overrides": frequency(False)},
            {"overrides": frequency(False, max_signals=5)},
            id="disabled-rule-params",
        ),
    ],
)
def test_a_change_that_cannot_alter_results_keeps_the_hash(
    old_changes: dict[str, Any], new_changes: dict[str, Any]
) -> None:
    old, new = settings(**old_changes), settings(**new_changes)

    assert settings_hash(old) == settings_hash(new)
    assert changed_paths(old, new) == []


def test_values_that_are_not_json_settings_are_refused() -> None:
    with pytest.raises(TypeError, match="set is not a backtest setting value"):
        settings(config={"levels": {1, 2}})


def test_values_of_a_different_json_type_differ() -> None:
    assert changed_paths({"x": 1}, {"x": True}) == ["x"]
    assert changed_paths({"x": 1}, {"x": 1.0}) == ["x"]
    assert changed_paths({"x": 1, "y": 2}, {"x": 1}) == ["y"]
