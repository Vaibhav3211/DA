"""Reading operator-supplied instrument dumps (the CLI's ``--file``)."""

from __future__ import annotations

from pathlib import Path

import pytest

from app.core.errors import ValidationFailedError
from app.services import instruments
from app.services.instruments import read_dump_file


def test_a_dump_file_is_read_whole(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(instruments, "MAX_DUMP_BYTES", 4)
    path = tmp_path / "dump.csv"
    path.write_bytes(b"a,b\n")

    assert read_dump_file(path) == b"a,b\n"


def test_a_dump_file_over_the_size_limit_is_refused(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(instruments, "MAX_DUMP_BYTES", 4)
    path = tmp_path / "dump.csv"
    path.write_bytes(b"a,b,c")

    with pytest.raises(ValidationFailedError) as excinfo:
        read_dump_file(path)

    assert excinfo.value.code == "instrument_file_too_large"


@pytest.mark.parametrize("name", ["missing.csv", "."])
def test_an_unreadable_dump_file_is_refused(tmp_path: Path, name: str) -> None:
    with pytest.raises(ValidationFailedError) as excinfo:
        read_dump_file(tmp_path / name)

    assert excinfo.value.code == "instrument_file_unreadable"
