"""Which instruments a workspace takes: ``UniverseRules`` read from the workspace settings."""

from __future__ import annotations

from typing import Any
from uuid import uuid4

import pytest

from app.domain.enums import Exchange, InstrumentType, Segment
from app.domain.models import Instrument
from app.services.workspaces import TAKES_NOTHING, UnderlyingKind, UniverseRules

# The seeded India workspaces, with fewer index underlyings.
CASH = {"exchanges": ["NSE", "BSE"], "segments": ["CASH"], "instrument_types": ["EQUITY"]}
INDEX_OPTIONS = {
    "exchanges": ["NSE", "BSE"],
    "segments": ["FNO"],
    "instrument_types": ["OPTION"],
    "underlying_kind": "INDEX",
    "index_underlyings": ["NIFTY", "BANKNIFTY"],
}
STOCK_FUTURES = {**INDEX_OPTIONS, "instrument_types": ["FUTURE"], "underlying_kind": "STOCK"}
LAB = {"exchanges": ["SIM"], "segments": ["CASH", "INDEX"]}


def _instrument(
    exchange: Exchange,
    segment: Segment,
    kind: InstrumentType,
    symbol: str,
    underlying: str | None = None,
) -> Instrument:
    return Instrument(
        id=uuid4(),
        canonical_key=f"{exchange}:{segment}:{kind}:{symbol}",
        exchange=exchange,
        segment=segment,
        instrument_type=kind,
        symbol=symbol,
        underlying=underlying,
    )


FNO, OPTION, FUTURE = Segment.FNO, InstrumentType.OPTION, InstrumentType.FUTURE
NIFTY_OPTION = _instrument(Exchange.NSE, FNO, OPTION, "NIFTY26JAN24000CE", " nifty ")
INFY_OPTION = _instrument(Exchange.NSE, FNO, OPTION, "INFY26JAN1500CE", "INFY")
NIFTY_FUTURE = _instrument(Exchange.NSE, FNO, FUTURE, "NIFTY26JANFUT", "NIFTY")
INFY_FUTURE = _instrument(Exchange.BSE, FNO, FUTURE, "INFY26JANFUT", "INFY")
ORPHAN_OPTION = _instrument(Exchange.NSE, FNO, OPTION, "ODD26JAN10CE")
NSE_EQUITY = _instrument(Exchange.NSE, Segment.CASH, InstrumentType.EQUITY, "INFY")
SIM_EQUITY = _instrument(Exchange.SIM, Segment.CASH, InstrumentType.EQUITY, "ALPHA")
SIM_INDEX = _instrument(Exchange.SIM, Segment.INDEX, InstrumentType.INDEX, "SIMIDX")


@pytest.mark.parametrize(
    ("settings", "instrument", "expected"),
    [
        (INDEX_OPTIONS, NIFTY_OPTION, None),
        (
            INDEX_OPTIONS,
            INFY_OPTION,
            "its underlying INFY is not an index this workspace takes (NIFTY, BANKNIFTY)",
        ),
        (INDEX_OPTIONS, NIFTY_FUTURE, "its type FUTURE is not one this workspace takes (OPTION)"),
        (INDEX_OPTIONS, ORPHAN_OPTION, "it has no underlying"),
        (STOCK_FUTURES, INFY_FUTURE, None),
        (
            STOCK_FUTURES,
            NIFTY_FUTURE,
            "its underlying NIFTY is an index; this workspace takes stock derivatives",
        ),
        (CASH, NSE_EQUITY, None),
        (CASH, NIFTY_OPTION, "its segment FNO is not one this workspace takes (CASH)"),
        (CASH, SIM_EQUITY, "its exchange SIM is not one this workspace takes (NSE, BSE)"),
        (LAB, SIM_INDEX, None),
        (LAB, NSE_EQUITY, "its exchange NSE is not one this workspace takes (SIM)"),
        ({}, NSE_EQUITY, f"the workspace takes no instruments: {TAKES_NOTHING}"),
    ],
)
def test_problem(settings: dict[str, Any], instrument: Instrument, expected: str | None) -> None:
    rules = UniverseRules.from_settings(settings)
    assert rules.takes_instruments is bool(settings)
    assert rules.problem(instrument) == expected


def test_from_settings_keeps_only_what_it_knows() -> None:
    rules = UniverseRules.from_settings(
        {
            "exchanges": " nse ",
            "segments": ["fno", "MOON", 7, "FNO", None],
            "instrument_types": {"OPTION": True},
            "underlying_kind": "somewhere",
            "index_underlyings": ["nifty", " Bank  Nifty ", "NIFTY", "", 3],
        }
    )
    assert rules == UniverseRules(
        exchanges=(Exchange.NSE,),
        segments=(Segment.FNO,),
        index_underlyings=("NIFTY", "BANK NIFTY"),
    )
    assert UniverseRules.from_settings({"underlying_kind": "stock"}).underlying_kind is UnderlyingKind.STOCK
    assert UniverseRules.from_settings(["NSE"]) == UniverseRules.from_settings(None) == UniverseRules()
