from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from app.core.config import AppEnv, Settings
from app.main import create_app


@pytest.mark.parametrize(
    ("app_env", "served"),
    [
        (AppEnv.DEVELOPMENT, True),
        (AppEnv.LIVE_DATA, False),
        (AppEnv.REPLAY, False),
        (AppEnv.PRODUCTION, False),
    ],
)
async def test_api_docs_are_served_in_development_only(
    make_settings: Callable[..., Settings], app_env: AppEnv, served: bool
) -> None:
    app = create_app(make_settings().model_copy(update={"app_env": app_env}))
    transport = httpx.ASGITransport(app=app)  # no lifespan: these routes need no container
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        statuses = {path: (await client.get(path)).status_code for path in ("/docs", "/openapi.json")}
    assert statuses == dict.fromkeys(statuses, 200 if served else 404)
