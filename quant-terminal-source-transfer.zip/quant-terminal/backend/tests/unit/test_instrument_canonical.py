"""Canonical instrument keys, display symbols and dump preparation (pure functions)."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any

import pytest
import sqlalchemy as sa

from app.domain.enums import Exchange, InstrumentType, OptionType, Provider, Segment
from app.domain.models import ProviderInstrumentRecord
from app.market_data.instruments.canonical import (
    FIELD_MAX_LENGTHS,
    KEY_MAX_LENGTH,
    SYMBOL_MAX_LENGTH,
    RecordRejected,
    canonicalize,
    contract_date,
    format_strike,
    prepare,
)
from app.persistence.models import InstrumentProviderMappingRow, InstrumentRow
from app.providers.errors import ProviderProtocolError
from app.providers.groww.instruments import parse_instrument_dump as parse_groww
from app.providers.instrument_dump import InstrumentDump
from app.providers.zerodha.instruments import parse_instrument_dump as parse_kite


def record(**changes: Any) -> ProviderInstrumentRecord:
    values: dict[str, Any] = {
        "provider": Provider.ZERODHA,
        "provider_token": "408065",
        "exchange_token": "1594",
        "provider_symbol": "INFY",
        "provider_exchange": "NSE",
        "provider_segment": "NSE",
        "exchange": Exchange.NSE,
        "segment": Segment.CASH,
        "instrument_type": InstrumentType.EQUITY,
        "name": "INFOSYS",
        "lot_size": 1,
        "tick_size": Decimal("0.05"),
    }
    return ProviderInstrumentRecord(**{**values, **changes})


def future(**changes: Any) -> ProviderInstrumentRecord:
    values: dict[str, Any] = {
        "provider_token": "9001218",
        "provider_symbol": "NIFTY26JANFUT",
        "provider_exchange": "NFO",
        "provider_segment": "NFO-FUT",
        "segment": Segment.FNO,
        "instrument_type": InstrumentType.FUTURE,
        "name": "NIFTY",
        "underlying": "NIFTY",
        "expiry": date(2026, 1, 27),
        "lot_size": 75,
    }
    return record(**{**values, **changes})


def option(**changes: Any) -> ProviderInstrumentRecord:
    values: dict[str, Any] = {
        "provider_token": "9002242",
        "provider_symbol": "NIFTY2610624000CE",
        "provider_segment": "NFO-OPT",
        "instrument_type": InstrumentType.OPTION,
        "expiry": date(2026, 1, 6),
        "strike": Decimal("24000"),
        "option_type": OptionType.CE,
    }
    return future(**{**values, **changes})


@pytest.mark.parametrize(
    ("item", "key", "symbol"),
    [
        (record(), "NSE:CASH:EQUITY:INFY", "INFY"),
        (record(provider_symbol=" m&m  fin "), "NSE:CASH:EQUITY:M&M FIN", "M&M FIN"),
        (
            record(provider_symbol="NIFTY 50", segment=Segment.INDEX, instrument_type=InstrumentType.INDEX),
            "NSE:INDEX:INDEX:NIFTY 50",
            "NIFTY 50",
        ),
        (future(), "NSE:FNO:FUTURE:NIFTY:2026-01-27", "NIFTY 27JAN26 FUT"),
        (option(), "NSE:FNO:OPTION:NIFTY:2026-01-06:24000:CE", "NIFTY 06JAN26 24000 CE"),
        (
            option(
                exchange=Exchange.MCX,
                segment=Segment.COMMODITY,
                underlying=" crudeoil ",
                expiry=date(2026, 1, 15),
                strike=Decimal("6000.50"),
                option_type=OptionType.PE,
            ),
            "MCX:COMMODITY:OPTION:CRUDEOIL:2026-01-15:6000.5:PE",
            "CRUDEOIL 15JAN26 6000.5 PE",
        ),
        (
            future(segment=Segment.CURRENCY, underlying="USDINR", expiry=date(2026, 1, 28)),
            "NSE:CURRENCY:FUTURE:USDINR:2026-01-28",
            "USDINR 28JAN26 FUT",
        ),
    ],
)
def test_keys_and_symbols(item: ProviderInstrumentRecord, key: str, symbol: str) -> None:
    canonical = canonicalize(item)
    assert (canonical.key, canonical.symbol) == (key, symbol)


@pytest.mark.parametrize(
    ("strike", "text"),
    [
        (Decimal("24000"), "24000"),
        (Decimal("24000.00"), "24000"),
        (Decimal("2.4E+4"), "24000"),
        (Decimal("1E+2"), "100"),
        (Decimal("80000.50"), "80000.5"),
        (Decimal("0.0025"), "0.0025"),
    ],
)
def test_strike_format(strike: Decimal, text: str) -> None:
    assert format_strike(strike) == text


def test_contract_dates_use_fixed_month_names() -> None:
    names = [contract_date(date(2026, month, 5))[2:5] for month in range(1, 13)]
    assert names == ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
    assert contract_date(date(2030, 5, 31)) == "31MAY30"
    assert contract_date(date(2101, 12, 1)) == "01DEC01"


def test_derivative_fields_are_kept_only_for_derivatives() -> None:
    equity = canonicalize(record(expiry=date(2026, 1, 27), strike=Decimal(5), option_type=OptionType.CE))
    assert (equity.expiry, equity.strike, equity.option_type) == (None, None, None)
    assert not equity.is_derivative
    contract = canonicalize(option(underlying="nifty"))
    assert (contract.underlying, contract.expiry, contract.strike) == (
        "NIFTY",
        date(2026, 1, 6),
        Decimal(24000),
    )
    assert contract.option_type is OptionType.CE
    assert contract.is_derivative


KITE_HEADER = (
    "instrument_token,exchange_token,tradingsymbol,name,last_price,expiry,strike,tick_size,lot_size,"
    "instrument_type,segment,exchange"
)
GROWW_HEADER = (
    "exchange,exchange_token,trading_symbol,groww_symbol,name,instrument_type,segment,series,isin,"
    "underlying_symbol,underlying_exchange_token,expiry_date,strike_price,lot_size,tick_size"
)


def csv(header: str, *rows: str) -> bytes:
    return ("\n".join([header, *rows]) + "\n").encode()


def test_kite_and_groww_rows_of_one_contract_share_a_key() -> None:
    kite = parse_kite(
        csv(
            KITE_HEADER,
            "408065,1594,INFY,INFOSYS,1500.25,,0,0.05,1,EQ,NSE,NSE",
            "256265,1001,NIFTY 50,NIFTY 50,0,,0,0,0,EQ,INDICES,NSE",
            "9001218,35161,NIFTY26JANFUT,NIFTY,0,2026-01-27,0,0.1,75.0,FUT,NFO-FUT,NFO",
            "9002242,35165,NIFTY2610624000CE,NIFTY,0,2026-01-06,24000,0.05,75,CE,NFO-OPT,NFO",
        )
    )
    groww = parse_groww(
        csv(
            GROWW_HEADER,
            "nse,1594,INFY,,Infosys,eq,cash,EQ,,,,,,1,0.05",
            "NSE,NIFTY,NIFTY,NSE-NIFTY,NIFTY 50,IDX,CASH,,,,,,,0,0",
            "NSE,35001,NIFTY26JANFUT,,NIFTY,FUT,FNO,,,NIFTY,26000,2026-01-27,-0.01,75,0.10",
            "NSE,35165,NIFTY2610624000CE,,NIFTY,CE,FNO,,,NIFTY,26000,06-Jan-2026,24000.00,75,0.05",
        ),
        today=date(2026, 1, 5),
    )
    kite_keys = [entry.instrument.key for entry in prepare(kite).entries]
    groww_keys = [entry.instrument.key for entry in prepare(groww).entries]
    shared = [
        "NSE:CASH:EQUITY:INFY",
        "NSE:FNO:FUTURE:NIFTY:2026-01-27",
        "NSE:FNO:OPTION:NIFTY:2026-01-06:24000:CE",
    ]
    # Index names differ between the providers, so their indices are deliberately not linked.
    assert sorted(kite_keys) == sorted([*shared, "NSE:INDEX:INDEX:NIFTY 50"])
    assert sorted(groww_keys) == sorted([*shared, "NSE:INDEX:INDEX:NIFTY"])


@pytest.mark.parametrize(
    ("item", "reason"),
    [
        (future(underlying=None), "invalid_row"),
        (future(underlying="  "), "invalid_row"),
        (future(expiry=None), "invalid_row"),
        (option(strike=None), "invalid_row"),
        (option(strike=Decimal(0)), "invalid_row"),
        (option(option_type=None), "invalid_row"),
        (record(provider_symbol="  "), "invalid_row"),
        (record(provider_symbol="X" * (KEY_MAX_LENGTH - 15)), "key_too_long"),
        (record(provider_symbol="X" * (SYMBOL_MAX_LENGTH + 1)), "field_too_long"),
        (future(underlying="U" * (SYMBOL_MAX_LENGTH - 10)), "field_too_long"),
        (record(underlying="U" * (SYMBOL_MAX_LENGTH + 1)), "field_too_long"),
        (record(name="N" * 201), "field_too_long"),
        (record(isin="INE009A010210"), "field_too_long"),
        (record(exchange_token="1" * 41), "field_too_long"),
        (record(provider_segment="S" * 25), "field_too_long"),
        (record(lot_size=0), "value_out_of_range"),
        (record(lot_size=2**31), "value_out_of_range"),
        (record(tick_size=Decimal("-0.05")), "value_out_of_range"),
        (record(tick_size=Decimal("0.000000001")), "value_out_of_range"),
        (option(strike=Decimal("1E+16")), "value_out_of_range"),
        (option(strike=Decimal("24000.123456789")), "value_out_of_range"),
    ],
)
def test_records_that_cannot_be_stored_are_rejected(item: ProviderInstrumentRecord, reason: str) -> None:
    with pytest.raises(RecordRejected) as caught:
        canonicalize(item)
    assert caught.value.reason == reason


def test_values_at_the_column_limits_are_accepted() -> None:
    longest = canonicalize(
        record(provider_symbol="X" * SYMBOL_MAX_LENGTH, name="N" * 200, isin="INE009A01021")
    )
    assert len(longest.key) == len("NSE:CASH:EQUITY:") + SYMBOL_MAX_LENGTH
    precise = canonicalize(
        option(
            strike=Decimal("9999999999999999.99999999"), tick_size=Decimal("0.00000001"), lot_size=2**31 - 1
        )
    )
    assert precise.strike == Decimal("9999999999999999.99999999")
    assert canonicalize(option(strike=Decimal("24000.123456780"))).key.endswith(":24000.12345678:CE")


def _length(column: sa.ColumnElement[Any]) -> object:
    return getattr(column.type, "length", None)


def test_limits_match_the_schema() -> None:
    instruments, mappings = InstrumentRow.__table__.c, InstrumentProviderMappingRow.__table__.c
    assert _length(instruments.canonical_key) == KEY_MAX_LENGTH
    assert _length(instruments.symbol) == SYMBOL_MAX_LENGTH
    assert _length(instruments.underlying) == SYMBOL_MAX_LENGTH
    assert {name: _length(instruments[name]) for name in ("name", "isin")} == {
        "name": FIELD_MAX_LENGTHS["name"],
        "isin": FIELD_MAX_LENGTHS["isin"],
    }
    provider_fields = {
        name: limit for name, limit in FIELD_MAX_LENGTHS.items() if name not in ("name", "isin")
    }
    assert {name: _length(mappings[name]) for name in provider_fields} == provider_fields
    for name in ("strike", "tick_size"):
        numeric = instruments[name].type
        assert (getattr(numeric, "precision", None), getattr(numeric, "scale", None)) == (24, 8)
    assert isinstance(instruments.lot_size.type, sa.Integer)
    assert not isinstance(instruments.lot_size.type, sa.BigInteger)


def dump_of(*records: ProviderInstrumentRecord, skipped: dict[str, int] | None = None) -> InstrumentDump:
    dump = InstrumentDump(Provider.ZERODHA, records=list(records), rows=len(records))
    dump.skipped.update(skipped or {})
    return dump


def test_prepare_skips_every_record_sharing_a_token_or_a_key() -> None:
    prepared = prepare(
        dump_of(
            record(),
            # token 1 is listed twice: both rows go, even though one has a unique key
            record(provider_token="1", provider_symbol="TCS"),
            record(provider_token="1", provider_symbol="INFY"),
            # tokens 2 and 3 claim the same contract: both go
            future(provider_token="2"),
            future(provider_token="3", provider_symbol="NIFTY-I"),
            option(),
            record(provider_token="4", provider_symbol="  "),
            skipped={"invalid_row": 2, "unsupported_exchange": 1},
        )
    )
    assert [entry.record.provider_token for entry in prepared.entries] == ["408065", "9002242"]
    assert prepared.skipped == {
        "invalid_row": 3,
        "unsupported_exchange": 1,
        "duplicate_token": 2,
        "ambiguous": 2,
    }
    assert prepared.held == {"1", "2", "3", "4"}
    assert (prepared.provider, prepared.rows) == (Provider.ZERODHA, 7)


def test_a_token_whose_other_row_is_rejected_is_used_not_held() -> None:
    prepared = prepare(
        dump_of(
            record(provider_token="5", provider_symbol="TCS"), record(provider_token="5", provider_symbol=" ")
        )
    )
    assert [entry.record.provider_token for entry in prepared.entries] == ["5"]
    assert prepared.held == frozenset()


def test_duplicate_tokens_are_removed_before_keys_are_compared() -> None:
    prepared = prepare(
        dump_of(record(provider_token="1"), future(provider_token="1"), record(provider_token="2"))
    )
    assert [entry.record.provider_token for entry in prepared.entries] == ["2"]
    assert prepared.skipped == {"duplicate_token": 2}


def test_prepare_rejects_a_dump_without_usable_records() -> None:
    with pytest.raises(ProviderProtocolError, match="no usable instruments"):
        prepare(dump_of(record(provider_token="1"), record(provider_token="1", provider_symbol="TCS")))


def test_prepare_rejects_records_of_another_provider() -> None:
    with pytest.raises(ValueError, match="GROWW record in a ZERODHA dump"):
        prepare(dump_of(record(provider=Provider.GROWW)))
