from __future__ import annotations

import argparse
import io
import re
from typing import Any

import pytest

from app.cli import capabilities, entry, system
from app.cli import strategies as strategy_commands
from app.cli._console import CliError, display_url, load_settings, parse_json_assignments
from app.core.config import Settings
from app.strategies.custom import CUSTOM_STRATEGIES
from app.strategies.examples.ema_crossover import EmaCrossover
from tests.conftest import build_settings


@pytest.fixture(autouse=True)
def _keep_test_logging(monkeypatch: pytest.MonkeyPatch) -> None:
    # main() configures process-wide logging; tests must not replace pytest's handlers.
    monkeypatch.setattr(entry, "configure_logging", lambda *_args, **_kwargs: None)


@pytest.mark.parametrize(
    ("url", "expected"),
    [
        ("redis://:s3cret@localhost:6379/0?ssl_cert_reqs=none", "redis://:***@localhost:6379/0"),
        ("postgresql+asyncpg://quant:s3cret@db:5432/qt", "postgresql+asyncpg://quant:***@db:5432/qt"),
        ("redis://localhost:6379/0", "redis://localhost:6379/0"),
    ],
)
def test_display_url_masks_password_and_drops_query(url: str, expected: str) -> None:
    assert display_url(url) == expected


def test_assignments_are_read_as_json_and_kept_as_text_otherwise() -> None:
    items = [
        "period=21",
        " ratio = 1.5 ",
        "enabled=true",
        "until=null",
        "levels=[1, 2]",
        'flag="true"',
        "label=results day",
        "limit=NaN",
        "note=a=b",
        "empty=",
    ]
    assert parse_json_assignments(items, option="--set") == {
        "period": 21,
        "ratio": 1.5,
        "enabled": True,
        "until": None,
        "levels": [1, 2],
        "flag": "true",
        "label": "results day",
        "limit": "NaN",  # not a JSON number: the setting's validation rejects it
        "note": "a=b",
        "empty": "",
    }


@pytest.mark.parametrize(
    ("items", "message"),
    [
        (["period"], "--set expects KEY=VALUE, not 'period'"),
        (["=21"], "--set expects KEY=VALUE, not '=21'"),
        (["period=9", " period =21"], "--set sets period more than once"),
    ],
)
def test_assignments_need_a_key_set_once(items: list[str], message: str) -> None:
    with pytest.raises(CliError, match=f"^{re.escape(message)}$"):
        parse_json_assignments(items, option="--set")


def test_invalid_configuration_is_reported_without_input_values(monkeypatch: pytest.MonkeyPatch) -> None:
    def broken_settings() -> Settings:
        return build_settings(api_port="s3cret-value")

    monkeypatch.setattr("app.cli._console.get_settings", broken_settings)
    with pytest.raises(CliError) as caught:
        load_settings()
    assert "API_PORT" in caught.value.message
    assert "s3cret-value" not in caught.value.message


@pytest.mark.parametrize("reason", ["   ", "x" * 301])
def test_kill_switch_reason_is_validated_before_any_connection(
    reason: str, capsys: pytest.CaptureFixture[str]
) -> None:
    assert entry.main(["kill-switch", "engage", "--reason", reason]) == 1
    assert "--reason must be 1-300 characters" in capsys.readouterr().err


def test_unexpected_errors_are_printed_redacted(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    def failing_command(_args: argparse.Namespace) -> int:
        raise RuntimeError("connect failed: postgresql://quant:s3cret@db:5432/qt")

    monkeypatch.setattr(system, "generate_key", failing_command)
    assert entry.main(["generate-key"]) == 1
    error = capsys.readouterr().err
    assert "RuntimeError: connect failed" in error
    assert "s3cret" not in error


@pytest.mark.parametrize(
    ("args", "message"),
    [
        (["accounts", "add", "zerodha", "Main/1"], "Account labels have 1-80 characters"),
        (
            ["accounts", "add", "groww", "Main", "--method", "login-redirect"],
            "Groww accounts use --method access-token, api-key-secret or totp",
        ),
        (["accounts", "update", "Main"], "nothing to change: give --label and/or --method"),
        (["zerodha", "login"], "run `qt zerodha login` in a terminal"),
        (["instruments", "refresh", "groww", "--account", "Main"], "--account is for Zerodha downloads only"),
        (["instruments", "refresh", "simulator", "--file", "dump.csv"], "it takes no --file"),
        (["instruments", "search", "--limit", "0"], "--limit: Input should be greater than or equal to 1"),
        (["instruments", "search", "x" * 101], "the search text: String should have at most 100 characters"),
        (
            ["capabilities", "set", "zerodha", "depth_levels", "--source", "docs"],
            "expected FIELD=VALUE, not 'depth_levels'",
        ),
        (
            ["capabilities", "set", "zerodha", "verified_on=2026-01-01", "--source", "docs"],
            "'verified_on' is not a capability field that can be set",
        ),
        (
            ["capabilities", "set", "zerodha", "depth_levels=5", "depth_levels=20", "--source", "docs"],
            "depth_levels is given more than once",
        ),
        (
            ["capabilities", "set", "zerodha", "rest_rate_limits={quote", "--source", "docs"],
            "the value of rest_rate_limits is not valid JSON",
        ),
        (["capabilities", "clear", "zerodha", "provider"], "'provider' is not a capability field"),
    ],
)
def test_provider_commands_check_arguments_before_connecting(
    args: list[str], message: str, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    def no_settings() -> Settings:
        pytest.fail("the command loaded its settings before checking its arguments")

    monkeypatch.setattr("app.cli._console.get_settings", no_settings)
    monkeypatch.setattr("sys.stdin", io.StringIO())  # not a console
    assert entry.main(args) == 1
    assert message in capsys.readouterr().err


def test_strategies_check_registers_the_code_without_settings_or_a_database(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    def no_settings() -> Settings:
        pytest.fail("qt strategies check loaded its settings")

    monkeypatch.setattr("app.cli._console.get_settings", no_settings)
    assert entry.main(["strategies", "check"]) == 0
    output = capsys.readouterr().out
    assert re.search(r"example\.ema_crossover\s{2,}1\.1\.0\s{2,}example\s{2,}BUY, SELL\s{2,}1m: \d+", output)
    assert f"Every strategy passes registration ({len(CUSTOM_STRATEGIES)} of them yours" in output

    class Silent(EmaCrossover):
        metadata = EmaCrossover.metadata.model_copy(
            update={"strategy_id": "mine.silent", "signal_conditions": ()}
        )

    monkeypatch.setattr(strategy_commands, "BUILTIN_STRATEGIES", (EmaCrossover, Silent, EmaCrossover))
    assert entry.main(["strategies", "check"]) == 1
    captured = capsys.readouterr()
    assert "error: mine.silent: signal conditions must be declared" in captured.err
    assert "error: duplicate strategy id 'example.ema_crossover'" in captured.err
    assert "passes registration" not in captured.out


@pytest.mark.parametrize("text", ["abc", "nan", "inf"])
def test_prices_must_be_finite_numbers(text: str, capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exited:
        entry.main(["instruments", "search", "--strike", text])
    assert exited.value.code == 2
    assert f"invalid number: '{text}'" in capsys.readouterr().err


@pytest.mark.parametrize(
    ("name", "text", "expected"),
    [
        ("exchanges", "NSE, BSE,", ["NSE", "BSE"]),
        ("exchanges", '["NSE"]', ["NSE"]),
        ("depth_levels", "20", 20),
        ("depth_levels", "null", None),
        ("depth_levels", "many", "many"),  # left for the service to reject with the field's type
        ("streaming", "false", False),
        ("display_name", "123", "123"),
        ("token_expiry", "06:00 IST", "06:00 IST"),
        ("rest_rate_limits", '{"quote": "1/second"}', {"quote": "1/second"}),
    ],
)
def test_capability_values_are_read_by_field_type(name: str, text: str, expected: Any) -> None:
    assert capabilities.parse_value(name, text) == expected
