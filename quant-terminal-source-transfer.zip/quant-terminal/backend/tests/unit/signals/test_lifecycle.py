"""Signal lifecycle planning and the derived signal fields."""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest

from app.domain.enums import RiskOutcome, SignalStatus, SignalType
from app.domain.models.signal import RiskDecision, SignalCandidate, TargetLevel
from app.domain.models.strategy import StrategyMetadata
from app.signals.lifecycle import Action, OpenSignal, is_actionable, plan, risk_reward
from tests.candle_support import T0
from tests.signal_support import METADATA, make_candidate

T1 = TargetLevel(label="T1", price=Decimal("104.20"))
T2 = TargetLevel(label="T2", price=Decimal("106.25"))
# The fixture candidate's levels, written with different trailing zeros.
OPEN_BUY = OpenSignal(
    id=uuid4(),
    signal_type=SignalType.BUY,
    status=SignalStatus.ACTIVE,
    entry_price=Decimal("100.1"),
    stop_loss=Decimal("98.0500"),
    targets=(TargetLevel(label="T1", price=Decimal("104.2")),),
)
INVALIDATION = make_candidate(
    signal_type=SignalType.INVALIDATED, entry_price=None, stop_loss=None, targets=()
)
ALLOW = RiskDecision(outcome=RiskOutcome.ALLOW, checks=(), evaluated_at=T0)
BLOCK = RiskDecision(outcome=RiskOutcome.BLOCK, checks=(), evaluated_at=T0)
INFORMATIONAL = METADATA.model_copy(update={"can_emit_actionable": False})


@pytest.mark.parametrize(
    ("candidate", "open_signal", "expected"),
    [
        pytest.param(make_candidate(), None, Action.NEW, id="nothing-open"),
        pytest.param(make_candidate(), OPEN_BUY, Action.DUPLICATE, id="same-levels"),
        pytest.param(make_candidate(stop_loss=Decimal(99)), OPEN_BUY, Action.UPDATE, id="new-stop"),
        pytest.param(make_candidate(targets=(T1, T2)), OPEN_BUY, Action.UPDATE, id="extra-target"),
        pytest.param(make_candidate(signal_type=SignalType.EXIT), OPEN_BUY, Action.NEW, id="other-type"),
        pytest.param(INVALIDATION, OPEN_BUY, Action.INVALIDATE, id="invalidate"),
        pytest.param(INVALIDATION, None, Action.IGNORE, id="nothing-to-invalidate"),
    ],
)
def test_plan(candidate: SignalCandidate, open_signal: OpenSignal | None, expected: Action) -> None:
    assert plan(candidate, open_signal) is expected


@pytest.mark.parametrize(
    ("signal_type", "decision", "metadata", "simulated", "expected"),
    [
        pytest.param(SignalType.BUY, ALLOW, METADATA, False, True, id="allowed-buy"),
        pytest.param(SignalType.EXIT, ALLOW, METADATA, False, True, id="allowed-exit"),
        pytest.param(SignalType.WATCH, ALLOW, METADATA, False, False, id="watch"),
        pytest.param(SignalType.BUY, BLOCK, METADATA, False, False, id="blocked"),
        pytest.param(SignalType.BUY, ALLOW, INFORMATIONAL, False, False, id="informational-strategy"),
        pytest.param(SignalType.BUY, ALLOW, METADATA, True, False, id="simulated-data"),
    ],
)
def test_is_actionable(
    signal_type: SignalType,
    decision: RiskDecision,
    metadata: StrategyMetadata,
    simulated: bool,
    expected: bool,
) -> None:
    assert is_actionable(signal_type, decision, metadata, simulated=simulated) is expected


@pytest.mark.parametrize(
    ("candidate", "expected"),
    [
        pytest.param(make_candidate(), Decimal("2.00"), id="buy"),
        pytest.param(
            make_candidate(
                signal_type=SignalType.SELL,
                entry_price=Decimal(100),
                stop_loss=Decimal(101),
                targets=(TargetLevel(label="T1", price=Decimal("96.5")),),
            ),
            Decimal("3.50"),
            id="sell",
        ),
        pytest.param(make_candidate(stop_loss=Decimal("100.10")), None, id="no-risk"),
        pytest.param(make_candidate(targets=()), None, id="no-target"),
        pytest.param(make_candidate(signal_type=SignalType.WATCH), None, id="not-an-entry"),
    ],
)
def test_risk_reward(candidate: SignalCandidate, expected: Decimal | None) -> None:
    assert risk_reward(candidate) == expected
