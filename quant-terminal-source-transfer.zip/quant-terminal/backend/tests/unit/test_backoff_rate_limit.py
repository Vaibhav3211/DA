from __future__ import annotations

import asyncio

import pytest

from app.core.backoff import ExponentialBackoff
from app.core.rate_limit import SlidingWindowRateLimiter


def test_backoff_grows_exponentially_with_equal_jitter_and_is_capped() -> None:
    lowest = ExponentialBackoff(initial=1.0, maximum=8.0, rng=lambda: 0.0)
    assert [lowest.next_delay() for _ in range(6)] == [0.5, 1.0, 2.0, 4.0, 4.0, 4.0]
    highest = ExponentialBackoff(initial=1.0, maximum=8.0, rng=lambda: 1.0)
    assert [highest.next_delay() for _ in range(6)] == [1.0, 2.0, 4.0, 8.0, 8.0, 8.0]


def test_backoff_attempt_limit_and_reset() -> None:
    backoff = ExponentialBackoff(max_attempts=2)
    exhausted_after_each_attempt = []
    for _ in range(2):
        backoff.next_delay()
        exhausted_after_each_attempt.append(backoff.exhausted)
    assert exhausted_after_each_attempt == [False, True]
    backoff.reset()
    assert (backoff.attempts, backoff.exhausted) == (0, False)
    assert not ExponentialBackoff(max_attempts=0).exhausted  # 0 = retry forever


def test_backoff_rejects_invalid_parameters() -> None:
    with pytest.raises(ValueError, match="invalid"):
        ExponentialBackoff(initial=0)
    with pytest.raises(ValueError, match="invalid"):
        ExponentialBackoff(initial=10, maximum=1)


async def test_rate_limiter_enforces_every_window(monkeypatch: pytest.MonkeyPatch) -> None:
    now = [0.0]
    sleeps: list[float] = []

    async def fake_sleep(seconds: float) -> None:
        sleeps.append(round(seconds, 6))
        now[0] += seconds

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    limiter = SlidingWindowRateLimiter([(2, 1.0), (3, 60.0)], clock=lambda: now[0])

    await limiter.acquire()
    await limiter.acquire()
    assert sleeps == []
    await limiter.acquire()  # third call in the same second waits for the 1 s window
    assert sleeps == [1.0]
    await limiter.acquire()  # 4th call exceeds 3/minute: waits until the first stamp is 60 s old
    assert sleeps == [1.0, 59.0]
    assert now[0] == 60.0


def test_rate_limiter_validates_windows() -> None:
    with pytest.raises(ValueError, match="positive"):
        SlidingWindowRateLimiter([])
    with pytest.raises(ValueError, match="positive"):
        SlidingWindowRateLimiter([(0, 1.0)])
