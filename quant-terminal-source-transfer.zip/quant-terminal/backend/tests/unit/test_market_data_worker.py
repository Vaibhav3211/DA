from __future__ import annotations

import asyncio
from collections.abc import Iterable, Mapping
from typing import Any, cast
from uuid import UUID, uuid4

import pytest
from redis.exceptions import ConnectionError as RedisConnectionError
from structlog.testing import capture_logs

from app.domain.enums import CalendarOverrideKind, Exchange
from app.domain.events import CommandType, WorkerCommand
from app.market_data.calendars.service import CalendarOverride, DayKind
from app.streaming.redis_bus import RedisBus, StreamMessage, Streams
from app.workers.market_data_worker import MarketDataWorker
from tests.conftest import build_settings
from tests.unit.market_data.test_calendar import MON, calendar

ACCOUNT = uuid4()
HOLIDAY = CalendarOverride(Exchange.NSE, MON, CalendarOverrideKind.HOLIDAY)


def command(kind: CommandType) -> WorkerCommand:
    return WorkerCommand(type=kind, account_id=ACCOUNT)


class CommandStream:
    """The command stream of a Redis bus; the next calls raise ``failures``, in order."""

    def __init__(self) -> None:
        self.entries: list[StreamMessage] = []
        self.failures: list[Exception] = []
        self.offsets: list[str] = []  # where each read started

    def add(self, *payloads: Any) -> None:
        for payload in payloads:
            data = payload.model_dump(mode="json") if isinstance(payload, WorkerCommand) else payload
            self.entries.append(StreamMessage(Streams.COMMANDS, f"{len(self.entries) + 1}-0", data))

    async def last_id(self, stream: str) -> str:
        self._fail()
        return self.entries[-1].message_id if self.entries else "0-0"

    async def read(
        self, offsets: Mapping[str, str], *, count: int = 500, block_ms: int | None = 1000
    ) -> list[StreamMessage]:
        await asyncio.sleep(0)  # a real read waits for entries
        self._fail()
        offset = offsets[Streams.COMMANDS]
        self.offsets.append(offset)
        return [entry for entry in self.entries if _seq(entry.message_id) > _seq(offset)][:count]

    def _fail(self) -> None:
        if self.failures:
            raise self.failures.pop(0)


def _seq(message_id: str) -> int:
    return int(message_id.split("-")[0])


class FakeFeeds:
    def __init__(self, calls: list[str]) -> None:
        self.calls = calls
        self.handled: list[list[WorkerCommand]] = []
        self.reconciled = asyncio.Event()

    async def reconcile(self) -> set[UUID]:
        self.calls.append("reconcile")
        self.reconciled.set()
        return set()

    async def handle(self, commands: Iterable[WorkerCommand]) -> None:
        self.calls.append("handle")
        self.handled.append(list(commands))

    async def stop_all(self) -> None:
        self.calls.append("stop feeds")

    def details(self) -> dict[str, Any]:
        return {"feeds": [], "queue_depth": 0, "queue_capacity": 10}


class FakeWriter:
    def __init__(self, calls: list[str]) -> None:
        self.calls = calls

    def start(self) -> None:
        self.calls.append("start writer")

    async def close(self) -> None:
        self.calls.append("close writer")


class Rig:
    def __init__(self) -> None:
        self.calls: list[str] = []
        self.stream = CommandStream()
        self.feeds = FakeFeeds(self.calls)
        self.calendar = calendar()
        self.now = 0.0
        self.sleeps: list[float] = []
        self.expired: list[UUID] | Exception = []
        self.overrides: list[CalendarOverride] | Exception = []
        self.worker = MarketDataWorker(
            build_settings(),  # upkeep every 30 s, calendar reloads every 300 s
            cast(RedisBus, self.stream),
            self.feeds,
            FakeWriter(self.calls),
            self.calendar,
            expire_tokens=self.expire_tokens,
            load_overrides=self.load_overrides,
            monotonic=lambda: self.now,
            sleep=self.sleep,
        )

    async def expire_tokens(self) -> list[UUID]:
        self.calls.append("expire tokens")
        if isinstance(self.expired, Exception):
            raise self.expired
        return self.expired

    async def load_overrides(self) -> list[CalendarOverride]:
        self.calls.append("load overrides")
        if isinstance(self.overrides, Exception):
            raise self.overrides
        return self.overrides

    async def sleep(self, seconds: float) -> None:
        self.sleeps.append(seconds)

    async def step_at(self, now: float) -> list[str]:
        """Run one step at ``now``; returns what it did."""
        self.now, done = now, len(self.calls)
        await self.worker.step()
        return self.calls[done:]


async def test_the_worker_starts_the_feeds_then_handles_new_commands_in_batches() -> None:
    r = Rig()
    r.stream.add(command(CommandType.CONNECT_ACCOUNT))  # its effect is in the database already
    await r.worker.start()
    assert r.calls == ["expire tokens", "reconcile"]

    login, refresh = command(CommandType.CONNECT_ACCOUNT), command(CommandType.REFRESH_SUBSCRIPTIONS)
    r.stream.add(login, None, {"type": "SELF_DESTRUCT"}, refresh)
    with capture_logs() as logs:
        assert await r.step_at(1.0) == ["handle"]
    assert r.feeds.handled == [[login, refresh]]
    invalid = [entry["message_id"] for entry in logs if entry["event"] == "worker_command_invalid"]
    assert invalid == ["3-0", "4-0"]  # undecodable or unknown commands are skipped

    assert await r.step_at(2.0) == []
    assert r.stream.offsets == ["1-0", "5-0"]


async def test_upkeep_and_calendar_reloads_run_when_due() -> None:
    r = Rig()
    await r.worker.start()
    assert await r.step_at(29.0) == []

    r.expired = [ACCOUNT]
    with capture_logs() as logs:
        assert await r.step_at(30.0) == ["expire tokens", "reconcile"]
    assert [entry["accounts"] for entry in logs if entry["event"] == "access_tokens_expired"] == [
        [str(ACCOUNT)]
    ]

    r.expired = RuntimeError("database down")
    assert await r.step_at(60.0) == ["expire tokens", "reconcile"]  # the feeds are reconciled anyway
    r.expired = []

    r.overrides = [HOLIDAY]
    assert await r.step_at(300.0) == ["load overrides", "expire tokens", "reconcile"]
    assert r.calendar.overrides == {HOLIDAY}
    assert r.calendar.trading_day(Exchange.NSE, MON).kind is DayKind.HOLIDAY

    r.overrides = OSError("database down")
    with capture_logs() as logs:
        await r.step_at(600.0)
    assert [entry["event"] for entry in logs] == ["calendar_reload_failed"]
    assert r.calendar.overrides == {HOLIDAY}  # kept until a reload succeeds

    r.overrides = []
    await r.step_at(900.0)
    assert r.calendar.trading_day(Exchange.NSE, MON).kind is DayKind.SESSION


async def test_commands_are_read_again_once_redis_answers() -> None:
    r = Rig()
    down = RedisConnectionError("Connection refused")
    r.stream.failures = [down, down, down]
    with capture_logs() as logs:
        await r.worker.start()
        assert r.calls == ["expire tokens", "reconcile"]  # the feeds start without Redis too
        await r.step_at(1.0)
        await r.step_at(2.0)
        assert r.sleeps == [1.0, 1.0]

        refresh = command(CommandType.REFRESH_SUBSCRIPTIONS)
        r.stream.add(refresh)  # issued before the worker could see the stream: left to the upkeep
        await r.step_at(3.0)
    events = [entry["event"] for entry in logs if entry["event"].startswith("command_read")]
    assert events == ["command_read_failed", "command_read_recovered"]  # logged once per outage
    assert (r.stream.offsets, r.feeds.handled) == (["1-0"], [])

    r.stream.failures = [RedisConnectionError("Connection reset")]
    await r.step_at(4.0)
    r.stream.add(refresh)
    await r.step_at(5.0)
    assert (r.stream.offsets, r.feeds.handled) == (["1-0", "1-0"], [[refresh]])  # the offset is kept


async def test_a_cancelled_worker_stops_the_feeds_before_the_writer_stores_their_candles() -> None:
    r = Rig()
    task = asyncio.create_task(r.worker.run())
    await r.feeds.reconciled.wait()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert r.calls == ["start writer", "expire tokens", "reconcile", "stop feeds", "close writer"]


def test_the_heartbeat_reports_the_feeds_and_how_far_the_calendars_are_verified() -> None:
    assert Rig().worker.details() == {
        "feeds": [],
        "queue_depth": 0,
        "queue_capacity": 10,
        "calendar_verified_until": {"NSE": "2026-01-16", "BSE": "2026-01-16"},
    }
