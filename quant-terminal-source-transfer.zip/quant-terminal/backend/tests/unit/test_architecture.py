"""Architecture rules for the runtime package (``app``), checked on its source without importing it.

* ADR-011: Phase 1 never places, changes or cancels orders, so runtime code references no broker
  order API. The method names and paths below come from the kiteconnect 5.2.2 and growwapi 1.5.0
  SDK sources.
* The official SDKs are optional cross-check tools (the ``sdk-crosscheck`` extra): runtime code
  never imports them and they are not runtime dependencies.
* ADR-008: strategy and indicator plugins (``app/strategies`` apart from its framework modules) are
  pure computations over what the runtime hands them. They import only an allow-list (a few
  standard-library modules, pydantic and the plugin API) and use no I/O or dynamic-code builtins and
  no wall clock. This is a guard rail for reviews, not a sandbox.

Docstrings are prose and may name these APIs; every other string literal counts, so dynamic imports
(``importlib.import_module("growwapi")``), ``getattr`` lookups and REST paths are caught too.
"""

from __future__ import annotations

import ast
import re
import tomllib
from collections.abc import Iterator
from pathlib import Path

import pytest

BACKEND_DIR = Path(__file__).resolve().parents[2]
APP_DIR = BACKEND_DIR / "app"

SDK_MODULES = ("kiteconnect", "growwapi", "twisted", "autobahn", "google.protobuf")
SDK_DISTRIBUTIONS = frozenset({"kiteconnect", "growwapi", "twisted", "autobahn", "protobuf"})
ORDER_APIS = frozenset(
    {
        # Kite Connect
        "place_order",
        "place_autoslice_order",
        "modify_order",
        "cancel_order",
        "exit_order",
        "convert_position",
        "place_gtt",
        "modify_gtt",
        "delete_gtt",
        "place_mf_order",
        "cancel_mf_order",
        "place_mf_sip",
        "modify_mf_sip",
        "cancel_mf_sip",
        # Groww (which also has place_order, modify_order and cancel_order)
        "create_smart_order",
        "modify_smart_order",
        "cancel_smart_order",
    }
)
# Kite: /orders/..., /gtt/triggers, /mf/orders, /mf/sips, /margins/orders and the position conversion,
# which shares /portfolio/positions with the position list. Groww: /order/... and /order-advance/....
ORDER_PATH = re.compile(r"(?:^|/)(?:orders?|order-advance|gtt|mf/(?:orders|sips)|portfolio/positions)(?:/|$)")
MODULE_NAME = re.compile(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*")


def violations(source: str) -> list[str]:
    """Every rule broken by one module's source, as ``"<line>: <what>"``."""
    tree = ast.parse(source)
    docstrings = _docstrings(tree)
    found: list[str] = []
    for node in ast.walk(tree):
        line = getattr(node, "lineno", 0)
        found.extend(f"{line}: imports {module}" for module in _imported_modules(node) if _is_sdk(module))
        found.extend(f"{line}: references {name}" for name in _names(node) if name in ORDER_APIS)
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in docstrings:
            text = node.value
            if MODULE_NAME.fullmatch(text) and _is_sdk(text):
                found.append(f"{line}: names the module {text}")
            elif text in ORDER_APIS:
                found.append(f"{line}: references {text}")
            elif "/" in text and ORDER_PATH.search(text):  # a bare "orders" is e.g. a depth level's count
                found.append(f"{line}: uses the order API path {text!r}")
    return found


def _is_sdk(module: str) -> bool:
    return any(module == sdk or module.startswith(f"{sdk}.") for sdk in SDK_MODULES)


def _imported_modules(node: ast.AST) -> Iterator[str]:
    if isinstance(node, ast.Import):
        yield from (alias.name for alias in node.names)
    elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module is not None:
        # "from google import protobuf" imports google.protobuf
        yield from (f"{node.module}.{alias.name}" for alias in node.names)


def _names(node: ast.AST) -> Iterator[str]:
    if isinstance(node, ast.Name):
        yield node.id
    elif isinstance(node, ast.Attribute):
        yield node.attr
    elif isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef):
        yield node.name
    elif isinstance(node, ast.keyword | ast.arg) and node.arg is not None:
        yield node.arg
    elif isinstance(node, ast.alias):
        yield node.asname or node.name.rpartition(".")[2]


def _docstrings(tree: ast.Module) -> set[int]:
    found: set[int] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Module | ast.ClassDef | ast.FunctionDef | ast.AsyncFunctionDef) and node.body:
            first = node.body[0]
            if (
                isinstance(first, ast.Expr)
                and isinstance(first.value, ast.Constant)
                and isinstance(first.value.value, str)
            ):
                found.add(id(first.value))
    return found


@pytest.mark.parametrize(
    ("source", "expected"),
    [
        ("import kiteconnect", ["1: imports kiteconnect"]),
        ("from growwapi.groww.client import GrowwAPI", ["1: imports growwapi.groww.client.GrowwAPI"]),
        ("from google import protobuf", ["1: imports google.protobuf"]),
        ("importlib.import_module('twisted.internet')", ["1: names the module twisted.internet"]),
        ("kite.place_order(variety='regular')", ["1: references place_order"]),
        ("getattr(groww, 'create_smart_order')", ["1: references create_smart_order"]),
        ("url = f'{base}/orders/{variety}'", ["1: uses the order API path '/orders/'"]),
        ("\nclient.post('/order-advance/create')", ["2: uses the order API path '/order-advance/create'"]),
        (
            "client.put('portfolio/positions', data=body)",
            ["1: uses the order API path 'portfolio/positions'"],
        ),
        ('"""Never calls place_order or /orders/regular."""', []),
        ("from .groww import client\nsort_order = 1\nborder = 'border/1'\nlog('placing orders off')", []),
        ("DepthLevel(orders=level.get('orders'))", []),  # market depth: orders resting at a price
    ],
)
def test_the_rules_catch_sdk_imports_and_order_apis(source: str, expected: list[str]) -> None:
    assert violations(source) == expected


def test_runtime_code_never_imports_an_sdk_or_references_order_apis() -> None:
    modules = sorted(APP_DIR.rglob("*.py"))
    found = [
        f"{module.relative_to(BACKEND_DIR).as_posix()}:{violation}"
        for module in modules
        for violation in violations(module.read_text(encoding="utf-8"))
    ]
    assert APP_DIR / "providers" / "groww" / "feed.py" in modules  # the scan reaches the adapters
    assert found == []


def distribution(requirement: str) -> str:
    match = re.match(r"[A-Za-z0-9][A-Za-z0-9._-]*", requirement)
    assert match is not None, requirement
    return re.sub(r"[-_.]+", "-", match.group(0)).lower()


def test_the_sdks_are_not_runtime_dependencies() -> None:
    project = tomllib.loads((BACKEND_DIR / "pyproject.toml").read_text(encoding="utf-8"))["project"]
    runtime = {distribution(requirement) for requirement in project["dependencies"]}
    assert sorted(runtime & SDK_DISTRIBUTIONS) == []


STRATEGIES_DIR = APP_DIR / "strategies"
PLUGIN_FRAMEWORK = frozenset({"__init__.py", "base.py", "registry.py", "runtime.py"})  # top level only
PLUGIN_STDLIB = frozenset(
    {
        "__future__",
        "abc",
        "collections",
        "dataclasses",
        "datetime",
        "decimal",
        "enum",
        "functools",
        "itertools",
        "math",
        "operator",
        "statistics",
        "typing",
        "uuid",
    }
)
PLUGIN_PACKAGES = ("pydantic", "app.domain.enums", "app.domain.models", "app.strategies")
PLUGIN_FRAMEWORK_MODULES = ("app.strategies.registry", "app.strategies.runtime")
PLUGIN_BUILTINS = frozenset(
    {"open", "eval", "exec", "compile", "__import__", "breakpoint", "input", "globals", "__builtins__"}
)
CLOCK_READS = frozenset({"now", "utcnow", "today"})


def plugin_violations(source: str, package: str) -> list[str]:
    """Every plugin rule broken by the source of one module of ``package``, as ``"<line>: <what>"``."""
    found: list[str] = []
    for node in ast.walk(ast.parse(source)):
        line = getattr(node, "lineno", 0)
        found.extend(
            f"{line}: imports {module}" for module in _plugin_imports(node, package) if not _allowed(module)
        )
        if isinstance(node, ast.Name) and node.id in PLUGIN_BUILTINS:
            found.append(f"{line}: uses {node.id}")
        elif (
            isinstance(node, ast.Attribute)
            and node.attr in CLOCK_READS
            and isinstance(node.value, ast.Name)
            and node.value.id in {"datetime", "date"}
        ):
            found.append(f"{line}: reads the clock ({node.value.id}.{node.attr})")
    return found


def _plugin_imports(node: ast.AST, package: str) -> Iterator[str]:
    if isinstance(node, ast.Import):
        yield from (alias.name for alias in node.names)
    elif isinstance(node, ast.ImportFrom):
        base = node.module or ""
        if node.level:  # relative to the module's package
            parts = package.split(".")[: len(package.split(".")) - node.level + 1]
            base = ".".join([*parts, node.module] if node.module else parts)
        # "from app.strategies import runtime" imports app.strategies.runtime
        yield from (f"{base}.{alias.name}" for alias in node.names)


def _allowed(module: str) -> bool:
    def within(prefixes: tuple[str, ...]) -> bool:
        return any(module == prefix or module.startswith(f"{prefix}.") for prefix in prefixes)

    if module.partition(".")[0] in PLUGIN_STDLIB:
        return True
    return within(PLUGIN_PACKAGES) and not within(PLUGIN_FRAMEWORK_MODULES)


@pytest.mark.parametrize(
    ("source", "package", "expected"),
    [
        (
            "from __future__ import annotations\nfrom collections.abc import Sequence\n"
            "from decimal import Decimal\nfrom pydantic import Field\nfrom app.domain.models import Candle\n"
            "from app.strategies.base import Strategy\nfrom .base import Indicator\nfrom . import trend",
            "app.strategies.indicators",
            [],
        ),
        ("import os", "app.strategies.examples", ["1: imports os"]),
        ("import httpx", "app.strategies.examples", ["1: imports httpx"]),
        (
            "from app.core.clock import utc_now",
            "app.strategies.examples",
            ["1: imports app.core.clock.utc_now"],
        ),
        (
            "from app.strategies import runtime",
            "app.strategies.examples",
            ["1: imports app.strategies.runtime"],
        ),
        (
            "from ..registry import cache",
            "app.strategies.examples",
            ["1: imports app.strategies.registry.cache"],
        ),
        ("rows = open('prices.csv').read()", "app.strategies.examples", ["1: uses open"]),
        ("\nscore = eval(rule)", "app.strategies.examples", ["2: uses eval"]),
        ("stamp = datetime.now(UTC)", "app.strategies.examples", ["1: reads the clock (datetime.now)"]),
        ("day = candle.start.date()\nopen_ = candle.open", "app.strategies.examples", []),
    ],
)
def test_the_plugin_rules_catch_imports_builtins_and_clock_reads(
    source: str, package: str, expected: list[str]
) -> None:
    assert plugin_violations(source, package) == expected


def test_strategy_plugins_stay_within_the_plugin_api() -> None:
    plugins = [
        module
        for module in sorted(STRATEGIES_DIR.rglob("*.py"))
        if not (module.parent == STRATEGIES_DIR and module.name in PLUGIN_FRAMEWORK)
    ]
    found = [
        f"{module.relative_to(BACKEND_DIR).as_posix()}:{violation}"
        for module in plugins
        for violation in plugin_violations(
            module.read_text(encoding="utf-8"), ".".join(module.relative_to(BACKEND_DIR).parent.parts)
        )
    ]
    assert STRATEGIES_DIR / "examples" / "ema_crossover.py" in plugins  # the scan reaches the plugins
    assert STRATEGIES_DIR / "indicators" / "trend.py" in plugins
    assert found == []
