"""The TypeScript API contract the frontend is built against."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

from app.api.contract import TYPES_PATH, generate, render, ts_type
from app.core.config import Settings

_REF = "#/components/schemas/"


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        ({}, "unknown"),
        ({"$ref": f"{_REF}QuoteView"}, "QuoteView"),
        ({"anyOf": [{"type": "string"}, {"type": "null"}]}, "string | null"),
        ({"type": ["string", "null"]}, "string | null"),
        ({"type": "array", "items": {"anyOf": [{"type": "integer"}, {"type": "null"}]}}, "(number | null)[]"),
        ({"type": "array", "prefixItems": [{"type": "string"}, {"type": "number"}]}, "[string, number]"),
        ({"type": "string", "enum": ["A", "B"]}, '"A" | "B"'),
        ({"const": "subscribe"}, '"subscribe"'),
        ({"type": "object"}, "Record<string, unknown>"),
        ({"type": "object", "additionalProperties": {"type": "boolean"}}, "Record<string, boolean>"),
        (
            {
                "type": "object",
                "additionalProperties": {"$ref": f"{_REF}DataStatus"},
                "propertyNames": {"$ref": f"{_REF}Provider"},
            },
            "Partial<Record<Provider, DataStatus>>",
        ),
    ],
)
def test_json_schemas_become_typescript_types(schema: dict[str, Any], expected: str) -> None:
    assert ts_type(schema) == expected


def test_only_models_the_server_alone_sends_have_every_field_required() -> None:
    model = {
        "type": "object",
        "properties": {"a": {"type": "string"}, "b-c": {"type": "integer"}},
        "required": ["a"],
    }
    text = render({"Sent": model, "Received": model}, {"Sent"})
    assert 'export interface Received {\n  a: string;\n  "b-c"?: number;\n}' in text
    assert 'export interface Sent {\n  a: string;\n  "b-c": number;\n}' in text


def test_a_model_split_into_request_and_response_shapes_is_refused() -> None:
    with pytest.raises(ValueError, match="TradeRules-Input, TradeRules-Output"):
        render({"TradeRules-Input": {"type": "object"}, "TradeRules-Output": {"type": "object"}}, set())


def test_the_frontend_types_are_up_to_date(make_settings: Callable[..., Settings]) -> None:
    if not TYPES_PATH.parents[3].is_dir():
        pytest.skip("no frontend in this checkout")
    expected = generate(make_settings())
    assert TYPES_PATH.read_text(encoding="utf-8") == expected, "run `python -m app.api.contract` in backend/"
