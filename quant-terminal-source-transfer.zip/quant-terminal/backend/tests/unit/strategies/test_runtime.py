"""The strategy runtime: how a run's market state folds candles, and how the runner calls and checks a
plugin (timeouts, failures, the circuit breaker and the market data attached to proposals)."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal
from typing import Any, cast
from uuid import UUID, uuid4

import pytest
from prometheus_client import REGISTRY

from app.domain.enums import (
    CandleInterval,
    DataStatus,
    EventType,
    Exchange,
    InstrumentType,
    MarketRegion,
    Provider,
    Segment,
    SignalType,
)
from app.domain.models import (
    Candle,
    IndicatorRequirement,
    Instrument,
    NormalizedMarketEvent,
    SignalCandidate,
    SignalCondition,
    StrategyMetadata,
)
from app.risk.rules import SourceData
from app.signals.engine import RunContext
from app.strategies.base import Strategy, StrategyConfig, StrategyContext
from app.strategies.registry import RegisteredStrategy, register
from app.strategies.runtime import (
    MAX_CANDIDATES_PER_CALL,
    CircuitBreaker,
    MarketState,
    StrategyRunner,
    WarmupProgress,
)
from tests.candle_support import INSTRUMENT, T0, bar
from tests.signal_support import ALPHA, make_candidate

M1, M5, M15 = CandleInterval.M1, CandleInterval.M5, CandleInterval.M15
ZERODHA = Provider.ZERODHA
NOW = T0 + timedelta(hours=1)
ACCOUNT = UUID("00000000-0000-4000-8000-0000000000aa")
BRAVO = ALPHA.model_copy(
    update={
        "id": UUID("00000000-0000-4000-8000-000000000002"),
        "canonical_key": "NSE:CASH:BRAVO",
        "symbol": "BRAVO",
    }
)

type Trigger = Candle | NormalizedMarketEvent


@dataclass
class Hook:
    """A plugin hook that raises ``error`` while it is set and otherwise returns ``result``."""

    result: object = ()
    error: Exception | None = None
    calls: int = 0

    async def __call__(self, trigger: Trigger | None = None) -> object:
        self.calls += 1
        if self.error is not None:
            raise self.error
        return self.result


@dataclass
class Monotonic:
    now: float = 1000.0

    def __call__(self) -> float:
        return self.now


def plugin(
    on_candle: Callable[[Trigger], Awaitable[object]] | None = None,
    *,
    on_event: Callable[[Trigger], Awaitable[object]] | None = None,
    initialize: Callable[[], Awaitable[object]] | None = None,
    shutdown: Callable[[], Awaitable[object]] | None = None,
    **metadata: Any,
) -> RegisteredStrategy:
    """A plugin whose hooks do what the given callables do (nothing by default). Unless ``metadata`` says
    otherwise it trades 1-minute candles with an EMA(3), keeps a 2-candle history and follows an EMA(2)
    of 5-minute candles."""
    candle_hook, event_hook = on_candle or Hook(), on_event or Hook()
    initialize_hook, shutdown_hook = initialize or Hook(), shutdown or Hook()

    class Plugin(Strategy[StrategyConfig]):
        async def initialize(self, context: StrategyContext[StrategyConfig]) -> None:
            await initialize_hook()

        async def on_candle(
            self, candle: Candle, context: StrategyContext[StrategyConfig]
        ) -> Sequence[SignalCandidate]:
            return cast("Sequence[SignalCandidate]", await candle_hook(candle))

        async def on_market_event(
            self, event: NormalizedMarketEvent, context: StrategyContext[StrategyConfig]
        ) -> Sequence[SignalCandidate]:
            return cast("Sequence[SignalCandidate]", await event_hook(event))

        async def shutdown(self) -> None:
            await shutdown_hook()

    values: dict[str, Any] = {
        "strategy_id": "test.runtime",
        "name": "Runtime fixture",
        "description": "Runtime test plugin.",
        "version": "1.0.0",
        "author": "tests",
        "markets": (MarketRegion.INDIA,),
        "segments": (Segment.CASH,),
        "instrument_types": (InstrumentType.EQUITY,),
        "candle_intervals": (M1,),
        "indicators": (
            IndicatorRequirement(alias="fast", indicator="ema", interval=M1, params={"period": 3}),
            IndicatorRequirement(alias="trend", indicator="ema", interval=M5, params={"period": 2}),
        ),
        "warmup_candles": 2,
        # A condition for every signal type, so a test may propose any of them.
        "signal_conditions": tuple(
            SignalCondition(signal_type=signal_type, description="fixture", inputs=("fast",))
            for signal_type in SignalType
        ),
    }
    Plugin.metadata = StrategyMetadata(**(values | metadata))
    return register(Plugin)


def runner(
    entry: RegisteredStrategy,
    *universe: Instrument,
    timeout: float = 1.0,
    threshold: int = 3,
    reset: float = 30.0,
    monotonic: Monotonic | None = None,
) -> StrategyRunner:
    """A run of the plugin over ``universe`` (ALPHA by default), all from Zerodha."""
    clock = monotonic or Monotonic()
    run = RunContext(
        run_id=uuid4(),
        deployment_id=uuid4(),
        workspace_id=uuid4(),
        market_region=MarketRegion.INDIA,
        metadata=entry.metadata,
    )
    market = MarketState(entry, [(instrument, ZERODHA) for instrument in universe or (ALPHA,)])
    return StrategyRunner(
        entry,
        run,
        StrategyConfig(),
        market,
        timeout_seconds=timeout,
        breaker=CircuitBreaker(threshold, reset, monotonic=clock),
        clock=lambda: NOW,
        monotonic=clock,
    )


def quote(
    instrument_id: UUID = INSTRUMENT,
    *,
    provider: Provider = ZERODHA,
    event_type: EventType = EventType.QUOTE,
) -> NormalizedMarketEvent:
    return NormalizedMarketEvent(
        event_id=uuid4(),
        provider=provider,
        account_id=ACCOUNT,
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        instrument_id=instrument_id,
        provider_instrument_token="1",
        symbol="ALPHA",
        event_type=event_type,
        received_at=NOW,
        processed_at=NOW,
        data_status=DataStatus.LIVE,
        last_price=Decimal("100.25"),
        source_timestamp=NOW - timedelta(seconds=1),
    )


def gauge(strategy: str) -> float:
    return REGISTRY.get_sample_value("qt_strategy_circuit_open", {"strategy": strategy}) or 0.0


def evaluations(strategy: str) -> dict[str, float]:
    outcomes = ("ok", "error", "timeout", "skipped_circuit_open")
    counts = {
        outcome: REGISTRY.get_sample_value(
            "qt_strategy_evaluations_total", {"strategy": strategy, "outcome": outcome}
        )
        for outcome in outcomes
    }
    return {outcome: count for outcome, count in counts.items() if count}


# ---- market state ------------------------------------------------------------------------------------


def test_market_state_folds_newer_closed_candles_of_its_own_series_only() -> None:
    market = MarketState(plugin(), [(ALPHA, ZERODHA)])
    first = bar(0, 100)

    assert market.fold(first)
    ignored = {
        "not newer": bar(0, 101),
        "still forming": bar(1, 101, closed=False),
        "another provider": bar(1, 101, provider=Provider.GROWW),
        "another instrument": bar(1, 101, instrument_id=BRAVO.id),
        "an interval it does not use": bar(1, 101, interval=M15),
    }
    assert [reason for reason, candle in ignored.items() if market.fold(candle)] == []
    assert market.candles(INSTRUMENT, M1) == (first,)
    assert market.latest(INSTRUMENT) == first


def test_history_keeps_the_latest_candles_of_the_strategy_intervals_oldest_first() -> None:
    market = MarketState(plugin(), [(ALPHA, ZERODHA)])  # a 2-candle history
    candles = [bar(index, 100 + index) for index in range(4)]
    five_minutes = bar(0, 100, interval=M5)
    for candle in [*candles[:3], five_minutes]:
        market.fold(candle)

    snapshot = market.candles(INSTRUMENT, M1)
    assert snapshot == (candles[1], candles[2])
    assert market.candles(INSTRUMENT, M1) is snapshot  # shared until the next fold
    market.fold(candles[3])
    assert market.candles(INSTRUMENT, M1) == (candles[2], candles[3])
    assert market.candles(INSTRUMENT, M5) == ()  # indicator-only intervals keep no history
    assert market.candles(BRAVO.id, M1) == ()
    assert market.latest(INSTRUMENT) == five_minutes  # it closed last, at 09:20


def test_indicator_readings_are_cached_until_the_next_fold() -> None:
    market = MarketState(plugin(), [(ALPHA, ZERODHA)])
    for index, close in enumerate((100, 103, 106, 109)):
        market.fold(bar(index, close))

    current = market.indicator_values(INSTRUMENT, 0)
    previous = market.indicator_values(INSTRUMENT, 1)
    # EMA(3) seeds with the average of its first three inputs, then moves halfway to each close.
    assert (previous["fast"].value, current["fast"].value) == (Decimal(103), Decimal(106))
    assert market.indicator_values(INSTRUMENT, 0) is current
    market.fold(bar(4, 112))
    assert market.indicator_values(INSTRUMENT, 1)["fast"].value == current["fast"].value
    with pytest.raises(ValueError, match="lag"):
        market.indicator_values(INSTRUMENT, 2)


def test_warming_counts_the_instruments_short_of_a_warmup_on_any_interval() -> None:
    entry = plugin()
    market = MarketState(entry, [(ALPHA, ZERODHA), (BRAVO, ZERODHA)])
    everything = {M1: entry.warmups[M1], M5: entry.warmups[M5]}
    assert market.warmup() == WarmupProgress(2, everything)

    for index in range(entry.warmups[M1]):
        market.fold(bar(index, 100))
    assert market.warming() == 2  # ALPHA still lacks 5-minute candles
    assert market.warmup() == WarmupProgress(2, everything)  # and BRAVO still needs every candle
    for index in range(entry.warmups[M5]):
        market.fold(bar(index, 100, interval=M5))
    assert market.warming() == 1

    def fold_bravo(indexes: range, interval: CandleInterval = M1) -> None:
        for index in indexes:
            market.fold(bar(index, 50, interval=interval, instrument_id=BRAVO.id, symbol="BRAVO"))

    fold_bravo(range(1))
    # Per interval, the most candles any instrument still needs.
    assert market.warmup() == WarmupProgress(1, {M1: entry.warmups[M1] - 1, M5: entry.warmups[M5]})
    fold_bravo(range(1, entry.warmups[M1]))
    fold_bravo(range(entry.warmups[M5]), M5)
    assert market.warmup() == WarmupProgress(0, {})


# ---- runner ------------------------------------------------------------------------------------------


async def test_a_proposal_carries_the_candle_it_was_computed_from() -> None:
    run = runner(plugin(Hook(result=(make_candidate(),))))
    candle = bar(0, "100.10")

    assert run.fold(candle)
    [proposal] = await run.on_candle(candle)

    assert (proposal.instrument, proposal.source, proposal.account_id) == (
        ALPHA,
        SourceData.from_candle(candle),
        None,
    )
    assert (proposal.candidate.source_candle_interval, proposal.candidate.source_candle_start) == (M1, T0)
    assert run.stats.candles == 1
    assert not run.fold(bar(0, 100, interval=M5))  # it feeds the indicators; the strategy is not called


async def test_a_proposal_on_another_instrument_carries_that_instruments_latest_candle() -> None:
    run = runner(plugin(Hook(result=(make_candidate(instrument_id=BRAVO.id),))), ALPHA, BRAVO)
    trigger = bar(1, 100)
    run.fold(trigger)

    [unknown] = await run.on_candle(trigger)
    bravo = bar(0, 50, instrument_id=BRAVO.id, symbol="BRAVO")
    run.fold(bravo)
    [known] = await run.on_candle(trigger)

    assert (unknown.instrument, unknown.source) == (BRAVO, SourceData(ZERODHA, DataStatus.UNKNOWN, None))
    assert unknown.candidate.source_candle_start is None
    assert (known.source, known.candidate.source_candle_start) == (
        SourceData.from_candle(bravo),
        bravo.bucket_start,
    )


async def test_an_event_is_the_source_of_a_proposal_on_its_instrument() -> None:
    run = runner(plugin(on_event=Hook(result=(make_candidate(),)), event_types=(EventType.QUOTE,)))
    event = quote()

    assert run.wants(event)
    assert not run.wants(quote(provider=Provider.GROWW))
    assert not run.wants(quote(BRAVO.id))
    assert not run.wants(quote(event_type=EventType.DEPTH))
    [proposal] = await run.on_event(event)

    assert (proposal.source, proposal.account_id) == (SourceData.from_event(event), ACCOUNT)
    assert run.stats.events == 1


async def test_failures_open_the_circuit_until_a_trial_call_succeeds() -> None:
    strategy = "test.runtime.circuit"
    hook = Hook(error=RuntimeError("boom"))
    clock = Monotonic()
    run = runner(plugin(hook, strategy_id=strategy), threshold=2, reset=30, monotonic=clock)
    candles = iter([bar(index, 100) for index in range(10)])

    async def evaluate() -> None:
        candle = next(candles)
        run.fold(candle)
        await run.on_candle(candle)

    await evaluate()
    assert not run.circuit_open
    await evaluate()
    assert (run.circuit_open, run.stats.circuit_opened_at, gauge(strategy)) == (True, NOW, 1)
    await evaluate()  # skipped while the circuit is open
    clock.now += 30
    await evaluate()  # the trial call fails: open for another 30 seconds
    clock.now += 29
    await evaluate()
    assert (hook.calls, run.stats.candles, run.stats.failures) == (3, 5, 3)
    assert (run.circuit_open, gauge(strategy)) == (True, 1)

    hook.error = None
    clock.now += 1
    await evaluate()

    assert (run.circuit_open, run.stats.circuit_opened_at, gauge(strategy)) == (False, None, 0)
    assert run.stats.last_error == "on_candle raised RuntimeError: boom"
    assert evaluations(strategy) == {"ok": 1, "error": 3, "skipped_circuit_open": 2}


@pytest.mark.parametrize("blocking", [False, True], ids=["awaits", "blocks-the-loop"])
async def test_a_hook_past_its_timeout_is_a_timeout_and_its_result_is_dropped(blocking: bool) -> None:
    clock = Monotonic()

    async def slow(trigger: Trigger) -> object:
        if blocking:
            clock.now += 0.2  # as if it computed for 200 ms without awaiting
        else:
            await asyncio.sleep(10)
        return (make_candidate(),)

    run = runner(plugin(slow), timeout=0.05, monotonic=clock)
    candle = bar(0, 100)
    run.fold(candle)

    assert await run.on_candle(candle) == []
    assert (run.stats.timeouts, run.stats.failures) == (1, 0)
    assert run.stats.last_error == "on_candle timed out after 0.05s"


@pytest.mark.parametrize(
    ("result", "problem"),
    [
        ("BUY", "returned str, not a sequence of SignalCandidate"),
        (None, "returned NoneType, not a sequence of SignalCandidate"),
        ({"signal": "BUY"}, "returned dict, not a sequence of SignalCandidate"),
        ([object()], "returned a object, not a SignalCandidate"),
        (
            [make_candidate()] * (MAX_CANDIDATES_PER_CALL + 1),
            f"proposed {MAX_CANDIDATES_PER_CALL + 1} candidates; the limit is {MAX_CANDIDATES_PER_CALL}",
        ),
        (
            [make_candidate(instrument_id=BRAVO.id)],
            f"proposed instrument {BRAVO.id}, which it does not cover",
        ),
    ],
    ids=["text", "none", "mapping", "not-a-candidate", "too-many", "uncovered-instrument"],
)
async def test_results_that_break_the_contract_are_failures(result: object, problem: str) -> None:
    run = runner(plugin(Hook(result=result)))
    candle = bar(0, 100)
    run.fold(candle)

    assert await run.on_candle(candle) == []
    assert (run.stats.failures, run.stats.last_error) == (1, f"on_candle broke the contract: {problem}")


async def test_a_signal_type_without_a_declared_condition_breaks_the_contract() -> None:
    sell_only = (SignalCondition(signal_type=SignalType.SELL, description="fixture", inputs=("fast",)),)
    run = runner(plugin(Hook(result=(make_candidate(),)), signal_conditions=sell_only))
    candle = bar(0, 100)
    run.fold(candle)

    assert await run.on_candle(candle) == []  # the BUY is dropped, not recorded
    assert run.stats.last_error == (
        "on_candle broke the contract: proposed a BUY signal without declaring a condition for it"
    )


async def test_initialize_and_shutdown_failures_are_reported_not_raised() -> None:
    strategy = "test.runtime.hooks"
    stop = Hook(error=RuntimeError("socket closed"))
    entry = plugin(
        Hook(error=RuntimeError("boom")),
        initialize=Hook(error=ValueError("no data")),
        shutdown=stop,
        strategy_id=strategy,
    )
    run = runner(entry, threshold=1)
    candle = bar(0, 100)
    run.fold(candle)

    assert await run.initialize() == "initialize raised ValueError: no data"
    await run.on_candle(candle)
    assert gauge(strategy) == 1
    await run.shutdown()
    await run.shutdown()

    assert (stop.calls, gauge(strategy)) == (1, 0)  # called once; the open circuit is no longer counted
