"""Strategy registration: contract checks, warm-ups, declared trade rules and configuration validation."""

from __future__ import annotations

import hashlib
import inspect
import re
from typing import Any
from uuid import uuid4

import pytest

from app.domain.enums import (
    CandleInterval,
    DataRequirement,
    EventType,
    Exchange,
    InstrumentType,
    MarketRegion,
    PluginKind,
    Segment,
    SignalType,
    TradeRulesSource,
)
from app.domain.models import IndicatorRequirement, SignalCondition, StrategyMetadata
from app.services.backtests import _rules_view
from app.strategies.base import Strategy, StrategyConfig
from app.strategies.examples import ema_crossover
from app.strategies.registry import (
    MAX_WARMUP_CANDLES,
    StrategyConfigError,
    StrategyRegistrationError,
    StrategyRegistry,
    UnknownStrategyError,
    builtin_registry,
    register,
)
from tests.backtest_support import trade_rules

M1, M5 = CandleInterval.M1, CandleInterval.M5


def _condition(*inputs: str, signal_type: SignalType = SignalType.BUY) -> SignalCondition:
    return SignalCondition(signal_type=signal_type, description="Fixture condition.", inputs=inputs)


def _metadata(**overrides: Any) -> StrategyMetadata:
    values: dict[str, Any] = {
        "strategy_id": "test.plugin",
        "name": "Test plugin",
        "description": "Registry test plugin.",
        "version": "1.0.0",
        "author": "tests",
        "markets": (MarketRegion.LAB,),
        "segments": (Segment.CASH,),
        "instrument_types": (InstrumentType.EQUITY,),
        "candle_intervals": (M1,),
        "signal_conditions": (_condition("close"),),
    }
    values.update(overrides)
    return StrategyMetadata(**values)


def _plugin(
    metadata: StrategyMetadata, config_model: type[StrategyConfig] = StrategyConfig
) -> type[Strategy[Any]]:
    class Plugin(Strategy[Any]):
        pass

    Plugin.metadata = metadata
    Plugin.config_model = config_model
    return Plugin


def _ema(alias: str, period: int = 9, interval: CandleInterval = M1) -> IndicatorRequirement:
    return IndicatorRequirement(alias=alias, indicator="ema", interval=interval, params={"period": period})


class _NoDefault(StrategyConfig):
    threshold: int


class _WrongMetadata(Strategy[Any]):
    metadata = "not metadata"  # type: ignore[assignment]


class _WrongConfigModel(Strategy[Any]):
    metadata = _metadata(strategy_id="test.wrong_config")
    config_model = dict  # type: ignore[assignment]


class _WrongTradeRules(Strategy[Any]):
    metadata = _metadata(strategy_id="test.wrong_rules")
    config_model = StrategyConfig
    trade_rules = {"sides": "BOTH"}  # type: ignore[assignment]


def test_registers_the_builtin_example() -> None:
    entry = builtin_registry().get("example.ema_crossover")

    assert entry.cls is ema_crossover.EmaCrossover
    assert dict(entry.warmups) == {M1: 63}
    assert entry.session_intervals == frozenset()
    assert dict(entry.default_config) == {
        "stop_atr_multiple": "1.5",
        "target_atr_multiple": "3",
        "valid_for_minutes": 15,
    }
    assert entry.fingerprint == hashlib.sha256(inspect.getsource(ema_crossover).encode()).hexdigest()
    assert entry.metadata.signal_types == {SignalType.BUY, SignalType.SELL}
    assert entry.data_requirements == frozenset()


def test_data_requirements_come_from_declarations_indicators_and_condition_inputs() -> None:
    entry = register(
        _plugin(
            _metadata(
                event_types=(EventType.QUOTE,),
                indicators=(
                    IndicatorRequirement(alias="vwap", indicator="vwap", interval=M1),
                    IndicatorRequirement(alias="bands", indicator="bollinger", interval=M1),
                ),
                required_data=(DataRequirement.OPEN_INTEREST,),
                signal_conditions=(_condition("vwap", "bands.upper", "bid", "close"),),
            )
        )
    )

    # VWAP reads volume; streamed bid and ask come from the depth levels.
    assert entry.data_requirements == {
        DataRequirement.OPEN_INTEREST,
        DataRequirement.VOLUME,
        DataRequirement.MARKET_DEPTH,
    }


def test_eligibility_covers_declared_exchanges_and_instruments() -> None:
    metadata = _metadata(exchanges=(Exchange.SIM,), instrument_keys=("SIM:CASH:EQUITY:ALPHA",))

    assert metadata.eligibility_problem(exchange=Exchange.SIM, instrument_key="SIM:CASH:EQUITY:ALPHA") is None
    assert (
        metadata.eligibility_problem(exchange=Exchange.NSE) == "test.plugin does not support the NSE exchange"
    )
    assert metadata.eligibility_problem(instrument_key="SIM:CASH:EQUITY:BRAVO") == (
        "test.plugin supports only the instruments it lists, and SIM:CASH:EQUITY:BRAVO is not one"
    )
    assert _metadata().eligibility_problem(exchange=Exchange.NSE, instrument_key="NSE:CASH:EQUITY:X") is None


def test_warmups_take_the_longest_need_on_each_interval() -> None:
    entry = register(
        _plugin(
            _metadata(
                warmup_candles=20,
                indicators=(
                    _ema("trend", 30),
                    IndicatorRequirement(alias="rsi", indicator="rsi", interval=M1, params={"period": 14}),
                    IndicatorRequirement(alias="vwap", indicator="vwap", interval=M5),
                    IndicatorRequirement(alias="atr", indicator="atr", interval=M5, params={"period": 14}),
                ),
            )
        )
    )

    # The strategy's own warm-up applies to its candle intervals only.
    assert dict(entry.warmups) == {M1: 30, M5: 14}
    assert entry.session_intervals == {M5}
    assert entry.intervals == {M1, M5}


@pytest.mark.parametrize(
    ("metadata", "config_model", "problem"),
    [
        pytest.param(_metadata(kind=PluginKind.AGENT), StrategyConfig, "kind must be STRATEGY", id="agent"),
        pytest.param(
            _metadata(uses_partial_candles=True),
            StrategyConfig,
            "partial (still forming) candles are not supported",
            id="partial-candles",
        ),
        pytest.param(
            _metadata(segments=()),
            StrategyConfig,
            "supported markets, segments and instrument types must be declared",
            id="no-segments",
        ),
        pytest.param(
            _metadata(candle_intervals=()),
            StrategyConfig,
            "neither candle intervals nor event types are declared",
            id="never-runs",
        ),
        pytest.param(
            _metadata(warmup_candles=MAX_WARMUP_CANDLES + 1),
            StrategyConfig,
            f"warmup_candles must be at most {MAX_WARMUP_CANDLES}",
            id="warmup-too-long",
        ),
        pytest.param(
            _metadata(indicators=(_ema("fast"), _ema("fast", 21))),
            StrategyConfig,
            "duplicate indicator aliases: fast",
            id="duplicate-alias",
        ),
        pytest.param(
            _metadata(indicators=(IndicatorRequirement(alias="x", indicator="nope", interval=M1),)),
            StrategyConfig,
            "indicator x: unknown indicator 'nope'",
            id="unknown-indicator",
        ),
        pytest.param(
            _metadata(indicators=(_ema("fast", 0),)),
            StrategyConfig,
            "indicator fast: period",
            id="invalid-indicator-params",
        ),
        pytest.param(
            _metadata(), _NoDefault, "every configuration field needs a valid default", id="no-default"
        ),
        pytest.param(
            _metadata(signal_conditions=()),
            StrategyConfig,
            "signal conditions must be declared",
            id="no-conditions",
        ),
        pytest.param(
            _metadata(signal_conditions=(_condition("close"), _condition("open"))),
            StrategyConfig,
            "duplicate signal conditions for: BUY",
            id="duplicate-condition",
        ),
        pytest.param(
            _metadata(signal_conditions=(_condition("rsi", "open_interest", "bands.middle"),)),
            StrategyConfig,
            "the BUY condition names unknown inputs: bands.middle, open_interest, rsi",
            id="unknown-inputs",
        ),
        pytest.param(
            _metadata(required_data=(DataRequirement.MARKET_DEPTH,)),
            StrategyConfig,
            "market events are the only source of MARKET_DEPTH; declare event types",
            id="depth-without-events",
        ),
        pytest.param(
            _metadata(segments=(Segment.CASH, Segment.CASH)),
            StrategyConfig,
            "duplicate segments: CASH",
            id="duplicate-segment",
        ),
        pytest.param(
            _metadata(exchanges=(Exchange.SIM, Exchange.NSE)),
            StrategyConfig,
            "exchanges outside the declared markets: NSE",
            id="exchange-outside-markets",
        ),
        pytest.param(
            _metadata(instrument_keys=("SIM:CASH:ALPHA",)),
            StrategyConfig,
            "instrument key 'SIM:CASH:ALPHA' is not a canonical key",
            id="malformed-key",
        ),
        pytest.param(
            _metadata(instrument_keys=("SIM:CASH:EQUITY:alpha",)),
            StrategyConfig,
            "must be upper-case",
            id="lower-case-key",
        ),
        pytest.param(
            _metadata(instrument_keys=("NSE:CASH:EQUITY:INFY",)),
            StrategyConfig,
            "instrument key NSE:CASH:EQUITY:INFY: test.plugin does not support the INDIA market",
            id="key-outside-markets",
        ),
    ],
)
def test_rejects_plugins_that_break_the_contract(
    metadata: StrategyMetadata, config_model: type[StrategyConfig], problem: str
) -> None:
    with pytest.raises(StrategyRegistrationError, match=rf"^test\.plugin: .*{re.escape(problem)}"):
        register(_plugin(metadata, config_model))


@pytest.mark.parametrize(
    ("plugin", "problem"),
    [
        pytest.param(object, "does not subclass Strategy", id="not-a-strategy"),
        pytest.param(_WrongMetadata, "metadata must be a StrategyMetadata", id="metadata-type"),
        pytest.param(_WrongConfigModel, "config_model must subclass StrategyConfig", id="config-model-type"),
        pytest.param(_WrongTradeRules, "trade_rules must be a TradeRules or None", id="trade-rules-type"),
    ],
)
def test_rejects_classes_of_the_wrong_shape(plugin: Any, problem: str) -> None:
    with pytest.raises(StrategyRegistrationError, match=re.escape(problem)):
        register(plugin)


def test_registry_rejects_duplicate_ids() -> None:
    with pytest.raises(StrategyRegistrationError, match=r"duplicate strategy id 'test\.plugin'"):
        StrategyRegistry([_plugin(_metadata()), _plugin(_metadata(version="2.0.0"))])


def test_registry_reports_unknown_strategies() -> None:
    registry = StrategyRegistry([_plugin(_metadata())])

    assert registry.find("missing") is None
    with pytest.raises(UnknownStrategyError, match="unknown strategy 'missing'"):
        registry.get("missing")


def test_declared_trade_rules_apply_until_the_configuration_saves_its_own() -> None:
    declared, own = trade_rules(quantity=5), trade_rules(quantity=20)
    plugin = _plugin(_metadata())
    plugin.trade_rules = declared
    entry = register(plugin)
    deployment = uuid4()

    assert entry.trade_rules == declared
    from_strategy = _rules_view(deployment, None, entry)
    assert (from_strategy.effective, from_strategy.source) == (declared, TradeRulesSource.STRATEGY)
    saved = _rules_view(deployment, own.model_dump(mode="json"), entry)
    assert (saved.effective, saved.source, saved.strategy) == (own, TradeRulesSource.CONFIGURATION, declared)
    neither = _rules_view(deployment, None, register(_plugin(_metadata())))
    assert (neither.effective, neither.source) == (None, None)
    assert neither.problem is not None
    assert neither.problem.startswith("no trade rules are set")


def test_validate_config_fills_in_defaults() -> None:
    config = builtin_registry().get("example.ema_crossover").validate_config({"valid_for_minutes": 5})

    assert config.model_dump(mode="json") == {
        "stop_atr_multiple": "1.5",
        "target_atr_multiple": "3",
        "valid_for_minutes": 5,
    }


@pytest.mark.parametrize(
    ("raw", "field"),
    [
        pytest.param({"stop_loss": 1}, "stop_loss", id="unknown-key"),
        pytest.param({"stop_atr_multiple": 0}, "stop_atr_multiple", id="out-of-range"),
        pytest.param({"valid_for_minutes": "soon"}, "valid_for_minutes", id="wrong-type"),
    ],
)
def test_validate_config_rejects_invalid_values(raw: dict[str, Any], field: str) -> None:
    entry = builtin_registry().get("example.ema_crossover")

    with pytest.raises(StrategyConfigError, match=rf"^example\.ema_crossover: .*{field}"):
        entry.validate_config(raw)
