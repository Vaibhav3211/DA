"""How a saved configuration's live monitoring is summed up: one state, its reasons and its warnings."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

import pytest

from app.domain.enums import MarketRegion, MonitoringState, ScopeKind, StrategyRunStatus
from app.risk.engine import RuleOverride, resolve_policy
from app.risk.rules import WORKSPACE_PAUSE
from app.services.kill_switch import KillSwitchState
from app.services.strategies import DeploymentView, RunView
from app.services.strategy_monitoring import (
    LIVE_SIGNALS_OFF,
    Monitoring,
    MonitoringInputs,
    MonitoringWarmup,
    derive_monitoring,
    signal_blocks,
)

STOPPED, STARTING, WARMING_UP, RUNNING, BLOCKED, FAILED = (
    MonitoringState.STOPPED,
    MonitoringState.STARTING,
    MonitoringState.WARMING_UP,
    MonitoringState.RUNNING,
    MonitoringState.BLOCKED,
    MonitoringState.FAILED,
)
WORKSPACE = UUID("00000000-0000-4000-8000-0000000000a1")
CONFIGURATION = UUID("00000000-0000-4000-8000-0000000000c1")
ENABLED_AT = datetime(2026, 1, 5, 4, 0, tzinfo=UTC)
KILL_SWITCH = "Kill switch is engaged (drill)"
NO_WORKER = "The strategy worker is not running (no recent heartbeat); start qt-strategy-worker"
WAITING = "Waiting for the strategy worker to start a run with the current settings"
SIMULATED = "Its instruments use simulated data: its signals are informational only"


def run(status: StrategyRunStatus = StrategyRunStatus.RUNNING, **changes: Any) -> RunView:
    values: dict[str, Any] = {
        "id": UUID("00000000-0000-4000-8000-0000000000e1"),
        "deployment_id": UUID("00000000-0000-4000-8000-0000000000d1"),
        "deployment_label": "trend",
        "workspace_slug": "india-equity",
        "strategy_id": "my.trend",
        "strategy_version": "1.0.0",
        "configuration_id": CONFIGURATION,
        "config_hash": "c" * 64,
        "code_fingerprint": "f" * 64,
        "status": status,
        "worker_id": "worker-1",
        "started_at": ENABLED_AT + timedelta(seconds=5),
        "stopped_at": None,
        "heartbeat_at": None,
        "instruments": 2,
        "excluded": 0,
        "instruments_warming": 0,
        "warmup_remaining": {},
        "events_processed": 0,
        "candles_processed": 0,
        "signals_emitted": 0,
        "failures": 0,
        "timeouts": 0,
        "last_error": None,
        "circuit_opened_at": None,
    }
    return RunView(**(values | changes))


def deployment(*, enabled: bool = True, last_run: RunView | None = None, **changes: Any) -> DeploymentView:
    values: dict[str, Any] = {
        "id": UUID("00000000-0000-4000-8000-0000000000d1"),
        "workspace_id": WORKSPACE,
        "workspace_slug": "india-equity",
        "market_region": MarketRegion.INDIA,
        "strategy_id": "my.trend",
        "strategy_version": "1.0.0",
        "code_fingerprint": "f" * 64,
        "label": "trend",
        "configuration_id": CONFIGURATION,
        "config": {},
        "config_hash": "c" * 64,
        "scope_kind": ScopeKind.WORKSPACE,
        "instrument_ids": (),
        "is_enabled": enabled,
        "enabled_by": "admin" if enabled else None,
        "enabled_at": ENABLED_AT if enabled else None,
        "disabled_at": None,
        "archived_at": None,
        "created_at": ENABLED_AT - timedelta(days=1),
        "updated_at": ENABLED_AT,
        "blocked_reason": None,
        "last_run": last_run,
    }
    return DeploymentView(**(values | changes))


def monitor(
    view: DeploymentView,
    *,
    worker_problem: str | None = None,
    instruments: int = 2,
    live_instruments: int | None = None,
    excluded: Mapping[str, str] | None = None,
    blocks: Sequence[str] = (),
    live_signals_enabled: bool = True,
) -> Monitoring:
    """The monitoring of ``view``: by default its scope resolves to two instruments on live data, the
    worker is up and nothing blocks signals."""
    return derive_monitoring(
        MonitoringInputs(
            deployment=view,
            worker_problem=worker_problem,
            instruments=instruments,
            live_instruments=instruments if live_instruments is None else live_instruments,
            excluded=excluded or {},
            signal_blocks=blocks,
            live_signals_enabled=live_signals_enabled,
        )
    )


def test_a_configuration_whose_live_signals_are_off_is_stopped_and_says_what_would_block_it() -> None:
    assert monitor(deployment(enabled=False)) == Monitoring(state=STOPPED)
    assert monitor(deployment(enabled=False), blocks=[KILL_SWITCH], worker_problem=NO_WORKER) == Monitoring(
        state=STOPPED, warnings=(f"If enabled, it would be blocked: {KILL_SWITCH}",)
    )
    # What stops it running at all is the one thing worth saying.
    gone = deployment(enabled=False, blocked_reason="its code is gone")
    assert monitor(gone, blocks=[KILL_SWITCH]).warnings == (
        "If enabled, it would be blocked: its code is gone",
    )
    assert monitor(deployment(enabled=False), live_signals_enabled=False).warnings == (
        f"If enabled, it would be blocked: {LIVE_SIGNALS_OFF}",
    )


def test_an_enabled_configuration_that_cannot_run_is_blocked_before_anything_else() -> None:
    gone = deployment(blocked_reason="its code is gone", last_run=run(StrategyRunStatus.FAILED))
    assert monitor(gone, worker_problem=NO_WORKER, blocks=[KILL_SWITCH]) == Monitoring(
        state=BLOCKED, reasons=("its code is gone",)
    )
    assert monitor(deployment(), instruments=0).reasons == (
        "Its scope has no instruments: the workspace has none",
    )
    excluded = {f"NSE:CASH:S{index}": "no live feed" for index in range(7)}
    blocked = monitor(deployment(), instruments=0, excluded=excluded)
    assert blocked.state is BLOCKED
    assert blocked.reasons == (
        "None of the instruments in its scope can run: "
        + "; ".join(f"NSE:CASH:S{index}: no live feed" for index in range(5))
        + "; and 2 more",
    )


@pytest.mark.parametrize(
    ("last_run", "reason"),
    [
        (None, NO_WORKER),  # the worker is checked before its runs
        (
            run(StrategyRunStatus.FAILED, last_error="plugin raised KeyError"),
            "Its run failed: plugin raised KeyError",
        ),
        (
            run(StrategyRunStatus.CIRCUIT_OPEN, last_error="timeout"),
            "The strategy kept failing, so the worker paused calling it (circuit open); last error: timeout",
        ),
    ],
)
def test_a_missing_worker_or_a_failed_run_means_monitoring_failed(
    last_run: RunView | None, reason: str
) -> None:
    problem = NO_WORKER if last_run is None else None
    failed = monitor(deployment(last_run=last_run), worker_problem=problem, blocks=[KILL_SWITCH])
    assert (failed.state, failed.reasons) == (FAILED, (reason,))


def test_rules_that_block_every_signal_block_a_running_configuration() -> None:
    paused = "Signals are paused for this workspace (results day)"
    assert monitor(deployment(last_run=run()), blocks=[KILL_SWITCH, paused]) == Monitoring(
        state=BLOCKED, reasons=(KILL_SWITCH, paused)
    )
    # LIVE_SIGNALS_ENABLED=false blocks it when every instrument is live, and only warns otherwise.
    assert monitor(deployment(last_run=run()), live_signals_enabled=False) == Monitoring(
        state=BLOCKED, reasons=(LIVE_SIGNALS_OFF,)
    )
    mixed = monitor(deployment(last_run=run()), live_instruments=1, live_signals_enabled=False)
    assert mixed == Monitoring(
        state=RUNNING,
        warnings=(f"{LIVE_SIGNALS_OFF}: the signals of 1 of its 2 instruments are blocked",),
    )


@pytest.mark.parametrize(
    ("last_run", "reason"),
    [
        (None, WAITING),
        (run(started_at=ENABLED_AT - timedelta(minutes=1)), WAITING),  # before live signals were turned on
        (run(strategy_version="0.9.0"), WAITING),  # an older version
        (run(configuration_id=UUID("00000000-0000-4000-8000-0000000000c2")), WAITING),  # older settings
        (run(StrategyRunStatus.STOPPED, stopped_at=ENABLED_AT + timedelta(minutes=1)), WAITING),
        (run(StrategyRunStatus.STARTING), "The run is loading the stored candles it warms up from"),
    ],
)
def test_until_a_run_of_the_current_settings_is_loaded_it_is_starting(
    last_run: RunView | None, reason: str
) -> None:
    assert monitor(deployment(last_run=last_run)) == Monitoring(state=STARTING, reasons=(reason,))


def test_a_run_short_of_closed_candles_is_warming_up_then_running() -> None:
    warming = run(instruments_warming=1, warmup_remaining={"1m": 14, "5m": 3})
    assert monitor(deployment(last_run=warming)) == Monitoring(
        state=WARMING_UP,
        reasons=(
            "1 of 2 instruments still lack the closed candles the strategy needs; their signals start once "
            "they have them",
        ),
        warmup=MonitoringWarmup(instruments=1, of=2, remaining={"1m": 14, "5m": 3}),
    )
    assert monitor(deployment(last_run=run())) == Monitoring(state=RUNNING)
    limited = monitor(deployment(last_run=run()), live_instruments=0, excluded={"NSE:CASH:X": "delisted"})
    assert limited == Monitoring(
        state=RUNNING, warnings=(SIMULATED, "1 instrument left out: NSE:CASH:X: delisted")
    )


def test_signal_blocks_name_the_kill_switch_a_paused_workspace_and_unreadable_rule_settings() -> None:
    def blocks(kill_switch: KillSwitchState, *overrides: RuleOverride) -> list[str]:
        return signal_blocks(kill_switch, resolve_policy(overrides, WORKSPACE))

    off = KillSwitchState(engaged=False)
    assert blocks(off) == []
    assert blocks(KillSwitchState(engaged=True, reason="drill")) == [KILL_SWITCH]
    assert blocks(KillSwitchState(engaged=True)) == ["Kill switch is engaged (no reason given)"]
    pause = RuleOverride(WORKSPACE_PAUSE, WORKSPACE, True, {"paused": True, "reason": "results day"})
    elsewhere = RuleOverride(WORKSPACE_PAUSE, UUID(int=1), True, {"paused": True, "reason": "other"})
    assert blocks(off, pause) == ["Signals are paused for this workspace (results day)"]
    assert blocks(off, elsewhere) == []
    broken = RuleOverride("frequency", None, True, {"max_signals": "many"})
    [problem] = blocks(off, broken)
    assert problem.startswith("Risk rule frequency has invalid stored parameters (max_signals: ")
    assert problem.endswith("); fix with qt risk set or qt risk reset")
    assert blocks(off, RuleOverride("frequency", None, False, {"max_signals": "many"})) == []  # disabled
