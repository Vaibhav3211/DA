"""The example EMA crossover strategy and the strategy context it reads."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from decimal import Decimal
from uuid import UUID, uuid4

import pytest
import structlog

from app.domain.enums import CandleInterval, DataStatus, Exchange, InstrumentType, Segment, SignalType
from app.domain.models import Candle, IndicatorValue, Instrument, SignalCandidate
from app.strategies.base import StrategyContext
from app.strategies.examples.ema_crossover import EmaCrossover, EmaCrossoverConfig
from tests.candle_support import INSTRUMENT, T0, bar, closes

M1 = CandleInterval.M1
ALPHA = Instrument(
    id=INSTRUMENT,
    canonical_key="NSE:CASH:ALPHA",
    exchange=Exchange.NSE,
    segment=Segment.CASH,
    instrument_type=InstrumentType.EQUITY,
    symbol="ALPHA",
    tick_size=Decimal("0.05"),
)


@dataclass
class FakeMarket:
    """Indicator readings by lag (0: after the latest candle, 1: after the one before)."""

    readings: Mapping[int, Mapping[str, str | None]]
    history: Sequence[Candle] = ()
    known: Mapping[UUID, Instrument] = field(default_factory=lambda: {INSTRUMENT: ALPHA})

    @property
    def instrument_ids(self) -> frozenset[UUID]:
        return frozenset(self.known)

    def instrument(self, instrument_id: UUID) -> Instrument | None:
        return self.known.get(instrument_id)

    def indicator_values(self, instrument_id: UUID, lag: int) -> Mapping[str, IndicatorValue]:
        return {
            name: IndicatorValue(
                name=name,
                indicator="atr" if name == "atr" else "ema",
                version="1.0",
                value=None if value is None else Decimal(value),
                interval=M1,
                data_status=DataStatus.LIVE,
            )
            for name, value in self.readings.get(lag, {}).items()
        }

    def candles(self, instrument_id: UUID, interval: CandleInterval) -> Sequence[Candle]:
        return self.history


def _context(
    market: FakeMarket, config: EmaCrossoverConfig | None = None
) -> StrategyContext[EmaCrossoverConfig]:
    return StrategyContext(
        config=config or EmaCrossoverConfig(),
        run_id=uuid4(),
        deployment_id=uuid4(),
        workspace_id=uuid4(),
        market=market,
        clock=lambda: T0,
        log=structlog.stdlib.get_logger("test"),
    )


def _emas(previous: tuple[str, str], current: tuple[str, str], atr: str | None = "1.37") -> FakeMarket:
    """EMA(9) and EMA(21) after the previous and the latest candle."""
    return FakeMarket(
        {
            1: {"fast": previous[0], "slow": previous[1], "atr": atr},
            0: {"fast": current[0], "slow": current[1], "atr": atr},
        }
    )


async def _propose(
    market: FakeMarket, config: EmaCrossoverConfig | None = None, candle: Candle | None = None
) -> Sequence[SignalCandidate]:
    return await EmaCrossover().on_candle(candle or bar(70, "100.10"), _context(market, config))


@pytest.mark.parametrize(
    ("previous", "current", "signal_type", "stop", "target"),
    [
        # 100.10 -/+ 1.5 x 1.37 = 98.045 / 102.155; 100.10 +/- 3 x 1.37 = 104.21 / 95.99 (half up to 0.05)
        pytest.param(("99.9", "100"), ("100.2", "100"), SignalType.BUY, "98.05", "104.20", id="cross-above"),
        pytest.param(("100.1", "100"), ("99.8", "100"), SignalType.SELL, "102.15", "96.00", id="cross-below"),
    ],
)
async def test_crossover_proposes_atr_levels_on_the_tick(
    previous: tuple[str, str], current: tuple[str, str], signal_type: SignalType, stop: str, target: str
) -> None:
    (signal,) = await _propose(_emas(previous, current))

    assert (signal.signal_type, signal.entry_price, signal.stop_loss) == (
        signal_type,
        Decimal("100.10"),
        Decimal(stop),
    )
    assert [level.price for level in signal.targets] == [Decimal(target)]


@pytest.mark.parametrize("tick", ["0.05", "0.05000000"])  # as written, and as read from the database
async def test_proposal_explains_itself_and_points_at_its_candle(tick: str) -> None:
    candle = bar(70, "100.10")
    market = _emas(("99.9", "100"), ("100.2", "100"))
    market.known = {INSTRUMENT: ALPHA.model_copy(update={"tick_size": Decimal(tick)})}

    (signal,) = await _propose(market, EmaCrossoverConfig(valid_for_minutes=5), candle)

    assert signal.reasons[0] == "EMA(9) 100.2 crossed above EMA(21) 100 (previous candle: 99.9 vs 100)"
    assert "stop-loss 98.05, target 104.20" in signal.explanation
    assert "price trades below the stop-loss 98.05" in signal.invalidation_conditions
    assert [reading.name for reading in signal.indicator_values] == ["fast", "slow", "atr"]
    assert signal.valid_for_seconds == 300
    assert (signal.source_candle_interval, signal.source_candle_start, signal.source_event_time) == (
        M1,
        candle.bucket_start,
        candle.last_event_at,
    )
    assert signal.score is None


@pytest.mark.parametrize(
    "market",
    [
        pytest.param(_emas(("100.2", "100"), ("100.3", "100")), id="no-crossover"),
        pytest.param(FakeMarket({0: {"fast": "100.2", "slow": "100", "atr": "1.37"}}), id="warming-up"),
        pytest.param(_emas(("99.9", "100"), ("100.2", "100"), atr=None), id="no-atr"),
        # 1.5 x 0.01 rounds back to the entry on a 0.05 tick: no usable stop-loss.
        pytest.param(_emas(("99.9", "100"), ("100.2", "100"), atr="0.01"), id="atr-below-tick"),
    ],
)
async def test_proposes_nothing(market: FakeMarket) -> None:
    assert await _propose(market) == ()


@pytest.mark.parametrize(
    ("count", "expected"),
    [(None, [0, 1, 2]), (5, [0, 1, 2]), (2, [1, 2]), (0, [])],
)
def test_context_candles_are_the_latest_oldest_first(count: int | None, expected: list[int]) -> None:
    history = closes(["1", "2", "3"])
    context = _context(FakeMarket({}, history=history))

    assert list(context.candles(INSTRUMENT, M1, count)) == [history[i] for i in expected]
