from __future__ import annotations

import math
import statistics
from collections.abc import Sequence
from datetime import datetime, timedelta
from decimal import Decimal
from fractions import Fraction
from typing import Any

import pytest

from app.domain.enums import CandleFlag, CandleInterval, DataStatus, Exchange
from app.domain.models import Candle, IndicatorRequirement, IndicatorValue
from app.strategies.indicators import Indicator, IndicatorConfigError, SessionRef, create_indicator
from tests.candle_support import T0, bar, closes

TOLERANCE = Decimal("1E-9")

# StockCharts' 14-period RSI worked example: closes and the published RSI from the 15th close on.
RSI_CLOSES = [
    "44.3389",
    "44.0902",
    "44.1497",
    "43.6124",
    "44.3278",
    "44.8264",
    "45.0955",
    "45.4245",
    "45.8433",
    "46.0826",
    "45.8931",
    "46.0328",
    "45.6140",
    "46.2820",
    "46.2820",
    "46.0028",
    "46.0328",
    "46.4116",
    "46.2222",
    "45.6439",
    "46.2122",
    "46.2521",
    "45.7137",
    "46.4515",
    "45.7835",
    "45.3548",
    "44.0288",
    "44.1783",
    "44.2181",
    "44.5672",
    "43.4205",
    "42.6628",
    "43.1314",
]
RSI_PUBLISHED = [
    "70.53",
    "66.32",
    "66.55",
    "69.41",
    "66.36",
    "57.97",
    "62.93",
    "63.26",
    "56.06",
    "62.38",
    "54.71",
    "50.42",
    "39.99",
    "41.46",
    "41.87",
    "45.46",
    "37.30",
    "33.08",
    "37.77",
]


def make(indicator: str, interval: CandleInterval = CandleInterval.M1, **params: Any) -> Indicator[Any]:
    return create_indicator(
        IndicatorRequirement(alias="x", indicator=indicator, interval=interval, params=params)
    )


def run(indicator: Indicator[Any], candles: Sequence[Candle]) -> list[Decimal | None]:
    """The primary output after each candle."""
    results = []
    for candle in candles:
        assert indicator.update(candle)
        results.append(indicator.values()[0].value)
    return results


def feed(indicator: Indicator[Any], candles: Sequence[Candle]) -> dict[str, Decimal | None]:
    """Every output (by name) after the last candle."""
    for candle in candles:
        indicator.update(candle)
    return {value.name: value.value for value in indicator.values()}


def close_to(value: Decimal | None, expected: Fraction | Decimal) -> bool:
    if value is None:
        return False
    if isinstance(expected, Fraction):
        expected = Decimal(expected.numerator) / Decimal(expected.denominator)
    return abs(value - expected) < TOLERANCE


# ---- known values ------------------------------------------------------------------------------------


def test_sma_and_ema_warm_up_then_follow_their_definitions() -> None:
    assert run(make("sma", period=3), closes([1, 2, 3, 4])) == [None, None, 2, 3]
    # alpha 2/(3+1), seeded with the SMA of the first three closes.
    assert run(make("ema", period=3), closes([1, 2, 3, 4, 5])) == [None, None, 2, 3, 4]


def test_macd_matches_hand_computed_values() -> None:
    macd = make("macd", fast=2, slow=3, signal=2)
    values = feed(macd, closes([1, 2, 4, 8, 16]))

    assert macd.warmup_candles == 4
    assert close_to(values["x"], Fraction(239, 108))
    assert close_to(values["x.signal"], Fraction(589, 324))
    assert close_to(values["x.histogram"], Fraction(32, 81))


def test_macd_line_appears_before_its_signal() -> None:
    macd = make("macd", fast=2, slow=3, signal=2)

    assert feed(macd, closes([1, 2, 4])) == {
        "x": Decimal("0.8333333333"),
        "x.signal": None,
        "x.histogram": None,
    }
    assert not macd.ready


def test_rsi_matches_the_published_stockcharts_example() -> None:
    values = run(make("rsi", period=14), closes(RSI_CLOSES))

    assert values[:14] == [None] * 14
    assert [f"{value:.2f}" for value in values[14:] if value is not None] == RSI_PUBLISHED


def test_rsi_is_100_without_losses_and_0_without_gains() -> None:
    assert run(make("rsi", period=2), closes([1, 2, 3]))[-1] == 100
    assert run(make("rsi", period=2), closes([3, 2, 1]))[-1] == 0


def test_atr_and_atr_percent_use_wilder_smoothing_of_the_true_range() -> None:
    candles = [
        bar(0, 9, high=10, low=8),  # TR 2: high - low, no previous close
        bar(1, 11, high=12, low=9),  # TR 3
        bar(2, "10.5", high=11, low=10),  # TR 1: |low - previous close|
        bar(3, 12, high=13, low=11),  # TR 2.5: high - previous close
    ]
    atr = run(make("atr", period=3), candles)
    percent = run(make("atr_percent", period=3), candles)

    assert atr[:3] == [None, None, 2]
    assert close_to(atr[3], Fraction(13, 6))  # (2 * 2 + 2.5) / 3
    assert close_to(percent[3], Fraction(13, 6) / 12 * 100)


def test_bollinger_bands_use_the_population_standard_deviation() -> None:
    values = feed(make("bollinger", period=4, multiplier=2), closes([1, 2, 3, 4]))
    deviation = 2 * Decimal("1.25").sqrt()
    lower = Decimal("2.5") - deviation

    assert values["x"] == Decimal("2.5")
    assert close_to(values["x.upper"], Decimal("2.5") + deviation)
    assert close_to(values["x.lower"], lower)
    assert close_to(values["x.bandwidth"], 2 * deviation / Decimal("2.5"))
    assert close_to(values["x.percent_b"], (4 - lower) / (2 * deviation))


def test_bollinger_percent_b_is_undefined_on_a_flat_series() -> None:
    values = feed(make("bollinger", period=3), closes([5, 5, 5]))

    assert values == {"x": 5, "x.upper": 5, "x.lower": 5, "x.bandwidth": 0, "x.percent_b": None}


def test_supertrend_follows_the_pine_band_rules() -> None:
    supertrend = make("supertrend", period=1, multiplier=1)
    candles = [
        bar(0, 9, high=10, low=8),
        bar(1, "12.5", high=13, low=11),
        bar(2, 13, high=14, low=12),
        bar(3, "9.5", high=12, low=9),
    ]
    readings: list[tuple[object, ...]] = []
    for candle in candles:
        supertrend.update(candle)
        readings.append(tuple(value.value for value in supertrend.values()))

    # (line, direction, upper, lower)
    assert readings == [
        (11, -1, 11, 7),  # starts in a downtrend on the basic bands
        (8, 1, 11, 8),  # close above the held upper band: uptrend on the lower band
        (11, 1, 15, 11),  # the lower band only rises while trending up
        (Decimal("14.5"), -1, Decimal("14.5"), 11),  # close below the lower band: downtrend
    ]


def test_returns_stdev_is_the_sample_deviation_of_log_returns() -> None:
    values = run(make("returns_stdev", period=2), closes([100, 110, 99]))
    expected = statistics.stdev([math.log(110 / 100), math.log(99 / 110)])

    assert values[:2] == [None, None]
    assert values[2] is not None
    assert abs(float(values[2]) - expected) < 1e-9


def test_volume_average_and_relative_volume() -> None:
    candles = [bar(i, 100, volume=volume) for i, volume in enumerate([100, 300, 200, 600])]

    assert run(make("volume_sma", period=2), candles) == [None, 200, 250, 400]
    # Latest volume over the average of the previous two.
    assert run(make("relative_volume", period=2), candles) == [None, None, 1, Decimal("2.4")]


def test_missing_volume_makes_volume_readings_none_while_it_is_in_the_window() -> None:
    candles = [bar(i, 100, volume=volume) for i, volume in enumerate([100, None, 300, 500])]

    assert run(make("volume_sma", period=2), candles) == [None, None, None, 400]


# ---- session indicators --------------------------------------------------------------------------------


def nse_sessions(exchange: Exchange, at: datetime) -> SessionRef:
    """A session opening at 09:15 IST (03:45 UTC) every UTC day."""
    del exchange
    return SessionRef(at.date(), datetime.combine(at.date(), T0.timetz()))


def session_indicator(indicator: str, **params: Any) -> Indicator[Any]:
    requirement = IndicatorRequirement(
        alias="x", indicator=indicator, interval=CandleInterval.M1, params=params
    )
    return create_indicator(requirement, sessions=nse_sessions)


def test_vwap_restarts_each_session_and_needs_every_volume() -> None:
    vwap = session_indicator("vwap")
    next_day = T0 + timedelta(days=1)
    candles = [
        bar(0, 10, volume=100),
        bar(1, 20, volume=300),
        bar(0, 30, volume=50, start=next_day),
        bar(0, 40, volume=None, start=next_day + timedelta(minutes=1)),
        bar(0, 50, volume=10, start=next_day + timedelta(minutes=2)),
    ]

    assert run(vwap, candles) == [10, Decimal("17.5"), 30, None, None]
    assert (vwap.values()[0].input_from, vwap.values()[0].input_count) == (next_day, 3)


def test_opening_range_appears_once_its_window_is_over() -> None:
    opening = session_indicator("opening_range", minutes=3, buffer_percent=1)
    candles = [
        bar(0, 101, high=105, low=100),
        bar(1, 102, high=103, low=99),
        bar(2, 103, high=104, low=101),
        bar(3, 110, high=111, low=109),  # after the window: the range is unchanged
    ]
    readings = []
    for candle in candles:
        opening.update(candle)
        readings.append({value.name: value.value for value in opening.values()})

    assert readings[1]["x"] is None
    assert readings[2] == readings[3]
    assert readings[3] == {
        "x": 105,
        "x.low": 99,
        "x.breakout_up": Decimal("106.05"),
        "x.breakout_down": Decimal("98.01"),
        "x.width": 6,
    }
    assert opening.values()[0].input_count == 3


@pytest.mark.parametrize(
    ("first", "flags"),
    [(1, ()), (0, (CandleFlag.PARTIAL_START,))],
    ids=["first-bucket-missing", "partial-first-bucket"],
)
def test_opening_range_is_none_unless_its_start_was_observed(
    first: int, flags: tuple[CandleFlag, ...]
) -> None:
    opening = session_indicator("opening_range", minutes=3)
    candles = [bar(first, 100, flags=flags), *closes([101, 102, 103], first=first + 1)]

    assert feed(opening, candles)["x"] is None


def test_opening_range_minutes_must_be_whole_candles() -> None:
    requirement = IndicatorRequirement(
        alias="orb", indicator="opening_range", interval=CandleInterval.M5, params={"minutes": 12}
    )

    with pytest.raises(IndicatorConfigError, match="orb: opening_range minutes"):
        create_indicator(requirement)


# ---- engine behaviour --------------------------------------------------------------------------------


def test_only_newer_closed_candles_of_the_interval_are_used() -> None:
    sma = make("sma", period=2)
    sma.update(bar(1, 10))

    assert not sma.update(bar(2, 50, closed=False))
    assert not sma.update(bar(2, 50, interval=CandleInterval.M5))
    assert not sma.update(bar(1, 50))  # duplicate
    assert not sma.update(bar(0, 50))  # older
    assert sma.update(bar(2, 20))
    assert sma.values()[0].value == 15


def test_window_readings_trace_their_inputs_and_label_degraded_data() -> None:
    sma = make("sma", period=2)
    candles = [bar(0, 1), bar(1, 2, status=DataStatus.STALE), bar(2, 3), bar(3, 4)]
    readings: list[IndicatorValue] = []
    for candle in candles:
        sma.update(candle)
        readings.append(sma.values()[0])

    assert [reading.data_status for reading in readings] == [
        DataStatus.LIVE,
        DataStatus.STALE,
        DataStatus.STALE,
        DataStatus.LIVE,  # the stale candle has left the window
    ]
    last = readings[-1]
    assert (last.input_from, last.input_to, last.input_count) == (
        candles[2].bucket_start,
        candles[3].bucket_end,
        2,
    )
    assert (last.indicator, last.version, last.params) == ("sma", "1.0", {"period": 2, "source": "close"})


def test_recursive_readings_cover_every_input_but_label_recent_ones() -> None:
    ema = make("ema", period=2)
    candles = [bar(0, 1, status=DataStatus.DELAYED), *closes([2, 3, 4], first=1)]
    feed(ema, candles)
    reading = ema.values()[0]

    assert (reading.input_from, reading.input_count) == (candles[0].bucket_start, 4)
    assert reading.data_status is DataStatus.LIVE


def test_simulated_inputs_are_labelled_simulated() -> None:
    ema = make("ema", period=2)
    feed(ema, closes([1, 2, 3], status=DataStatus.SIMULATED))

    assert ema.values()[0].data_status is DataStatus.SIMULATED


def test_the_previous_reading_is_available_with_lag() -> None:
    ema = make("ema", period=1)
    feed(ema, closes([1, 2, 3]))

    assert ema.values(lag=1)[0].value == 2
    assert ema.values()[0].value == 3
    with pytest.raises(ValueError, match="lag"):
        ema.values(lag=2)


def test_long_expansions_are_rounded_to_ten_places() -> None:
    assert run(make("sma", period=3), closes([1, 1, 2]))[-1] == Decimal("1.3333333333")


@pytest.mark.parametrize(
    ("indicator", "params", "message"),
    [
        ("nope", {}, "unknown indicator 'nope'"),
        ("sma", {"period": 0}, "period: Input should be greater than or equal to 1"),
        ("sma", {"length": 3}, "length: Extra inputs are not permitted"),
        ("macd", {"fast": 30, "slow": 26}, "fast must be shorter than slow"),
    ],
)
def test_invalid_requirements_are_rejected(indicator: str, params: dict[str, Any], message: str) -> None:
    requirement = IndicatorRequirement(
        alias="x", indicator=indicator, interval=CandleInterval.M1, params=params
    )

    with pytest.raises(IndicatorConfigError, match=message):
        create_indicator(requirement)
