"""How each strategy suits an instrument as its workspace streams it: the strategy panel's checks."""

from __future__ import annotations

from dataclasses import replace
from typing import Any
from uuid import UUID

import pytest

from app.core.config import DEFAULT_CANDLE_INTERVALS
from app.domain.enums import (
    CandleInterval,
    CheckStatus,
    CompatibilityAspect,
    DataRequirement,
    EventType,
    Exchange,
    InstrumentType,
    MarketRegion,
    Provider,
    Segment,
    SignalType,
    SubscriptionMode,
)
from app.domain.models import IndicatorRequirement, SignalCondition, StrategyMetadata
from app.persistence.models import InstrumentRow
from app.providers.delivery import FeedDelivery
from app.services.strategy_compatibility import (
    INACTIVE,
    CompatibilityInputs,
    StrategyCompatibility,
    WarmupCoverage,
    check_compatibility,
    instrument_problem,
)
from app.strategies.base import Strategy, StrategyConfig
from app.strategies.registry import RegisteredStrategy, register

M1, M5 = CandleInterval.M1, CandleInterval.M5
PASSED, WARNING, FAILED = CheckStatus.PASSED, CheckStatus.WARNING, CheckStatus.FAILED
MARKET, INSTRUMENT, TIMEFRAME, DATA, WARMUP = (
    CompatibilityAspect.MARKET,
    CompatibilityAspect.INSTRUMENT,
    CompatibilityAspect.TIMEFRAME,
    CompatibilityAspect.DATA,
    CompatibilityAspect.WARMUP,
)


def strategy(**overrides: Any) -> RegisteredStrategy:
    values: dict[str, Any] = {
        "strategy_id": "my.trend",
        "name": "Trend",
        "description": "Compatibility test strategy.",
        "version": "1.0.0",
        "author": "tests",
        "markets": (MarketRegion.INDIA,),
        "segments": (Segment.CASH,),
        "instrument_types": (InstrumentType.EQUITY,),
        "candle_intervals": (M1,),
        "warmup_candles": 20,
        "signal_conditions": (
            SignalCondition(signal_type=SignalType.BUY, description="Close rises.", inputs=("close",)),
        ),
    }
    values.update(overrides)

    class Plugin(Strategy[Any]):
        metadata = StrategyMetadata(**values)
        config_model = StrategyConfig

    return register(Plugin)


def instrument(**overrides: Any) -> InstrumentRow:
    values: dict[str, Any] = {
        "id": UUID("00000000-0000-4000-8000-0000000000f1"),
        "canonical_key": "NSE:CASH:EQUITY:INFY",
        "exchange": Exchange.NSE,
        "segment": Segment.CASH,
        "instrument_type": InstrumentType.EQUITY,
        "symbol": "INFY",
        "is_active": True,
    }
    values.update(overrides)
    return InstrumentRow(**values)


def inputs(**overrides: Any) -> CompatibilityInputs:
    values: dict[str, Any] = {
        "market": MarketRegion.INDIA,
        "instrument": instrument(),
        "provider": Provider.ZERODHA,
        "mode": SubscriptionMode.QUOTE,
        "built": frozenset(DEFAULT_CANDLE_INTERVALS),
        "stored": {M1: 20},
        "feeds": FeedDelivery(),
    }
    values.update(overrides)
    return CompatibilityInputs(**values)


def check(result: StrategyCompatibility, aspect: CompatibilityAspect) -> tuple[CheckStatus, str]:
    found = next(item for item in result.checks if item.aspect is aspect)
    return found.status, found.detail


def test_a_suitable_strategy_passes_every_check() -> None:
    result = check_compatibility(strategy(), inputs(stored={M1: 25}))

    assert result.compatible
    assert [(item.aspect, item.status, item.detail) for item in result.checks] == [
        (MARKET, PASSED, "it supports the INDIA market"),
        (INSTRUMENT, PASSED, "it supports CASH EQUITY instruments on NSE"),
        (TIMEFRAME, PASSED, "it is evaluated on 1m candles"),
        (DATA, PASSED, "the ZERODHA feed in QUOTE mode sends the prices it needs"),
        (WARMUP, PASSED, "enough closed candles are stored to warm up now (20 of 20 1m candles)"),
    ]
    assert result.warmup == (WarmupCoverage(interval=M1, needed=20, stored=20),)
    assert (result.strategy_id, result.version) == ("my.trend", "1.0.0")


@pytest.mark.parametrize(
    ("changes", "expected"),
    [
        ({"market": MarketRegion.LAB}, "my.trend does not support the LAB market"),
        # An India workspace holding a simulator instrument: the instrument's market counts too.
        (
            {"instrument": instrument(exchange=Exchange.SIM, canonical_key="SIM:CASH:EQUITY:ALPHA")},
            "my.trend does not support the LAB market",
        ),
    ],
)
def test_the_workspace_and_instrument_markets_must_be_supported(
    changes: dict[str, Any], expected: str
) -> None:
    result = check_compatibility(strategy(), inputs(**changes))

    assert check(result, MARKET) == (FAILED, expected)
    assert not result.compatible


@pytest.mark.parametrize(
    ("entry", "row", "expected"),
    [
        (strategy(), instrument(is_active=False), (FAILED, INACTIVE)),
        (
            strategy(),
            instrument(segment=Segment.FNO, instrument_type=InstrumentType.FUTURE),
            (FAILED, "my.trend does not support the FNO segment"),
        ),
        (
            strategy(instrument_keys=("NSE:CASH:EQUITY:TCS",)),
            instrument(),
            (
                FAILED,
                "my.trend supports only the instruments it lists, and NSE:CASH:EQUITY:INFY is not one",
            ),
        ),
        (
            strategy(instrument_keys=("NSE:CASH:EQUITY:INFY",)),
            instrument(),
            (PASSED, "NSE:CASH:EQUITY:INFY is one of the instruments it lists"),
        ),
    ],
)
def test_the_instrument_must_be_active_and_declared(
    entry: RegisteredStrategy, row: InstrumentRow, expected: tuple[CheckStatus, str]
) -> None:
    assert check(check_compatibility(entry, inputs(instrument=row)), INSTRUMENT) == expected


def test_candles_the_platform_does_not_build_fail_the_timeframe_check() -> None:
    result = check_compatibility(strategy(), inputs(built=frozenset({M5})))

    assert check(result, TIMEFRAME) == (FAILED, "it needs 1m candles, which CANDLE_INTERVALS does not build")
    assert check(result, WARMUP) == (WARNING, "it cannot warm up: 1m candles are not built")
    assert not result.compatible


@pytest.mark.parametrize(
    ("chart", "expected"),
    [
        (None, (PASSED, "it is evaluated on 1m candles")),
        (M1, (PASSED, "it is evaluated on 1m candles, the chart's interval")),
        (
            M5,
            (
                WARNING,
                "it is evaluated on 1m candles, not the chart's 5m: "
                "its signals appear on the 5m candles containing them",
            ),
        ),
    ],
)
def test_a_chart_on_another_interval_is_a_warning(
    chart: CandleInterval | None, expected: tuple[CheckStatus, str]
) -> None:
    result = check_compatibility(strategy(), inputs(chart_interval=chart))

    assert check(result, TIMEFRAME) == expected
    assert result.compatible


def test_an_event_strategy_reports_its_events_and_indicator_candles() -> None:
    entry = strategy(
        candle_intervals=(),
        warmup_candles=0,
        event_types=(EventType.QUOTE,),
        indicators=(IndicatorRequirement(alias="fast", indicator="ema", interval=M5, params={"period": 3}),),
        signal_conditions=(
            SignalCondition(signal_type=SignalType.BUY, description="Above.", inputs=("last_price", "fast")),
        ),
    )

    result = check_compatibility(entry, inputs(stored={M5: 1}))

    assert check(result, TIMEFRAME) == (
        PASSED,
        "it runs on QUOTE market events, with indicators on 5m candles",
    )
    assert check(result, WARMUP) == (
        WARNING,
        "it will warm up from live candles: 1 of 3 5m candles are stored",
    )
    assert result.warmup == (WarmupCoverage(interval=M5, needed=3, stored=1),)


def test_data_the_feed_does_not_send_fails_with_the_fix() -> None:
    entry = strategy(required_data=(DataRequirement.VOLUME,))

    result = check_compatibility(entry, inputs(mode=SubscriptionMode.LTP))

    assert check(result, DATA) == (
        FAILED,
        "it needs traded volume, which it does not get from the ZERODHA feed in LTP mode: "
        "subscribe the instrument in QUOTE mode for traded volume",
    )
    assert not result.compatible
    assert check(check_compatibility(entry, inputs()), DATA) == (
        PASSED,
        "the ZERODHA feed in QUOTE mode sends the traded volume it needs",
    )


@pytest.mark.parametrize(
    ("event_types", "mode", "expected"),
    [
        (
            (EventType.LTP,),
            SubscriptionMode.QUOTE,
            "it runs only on LTP events, which the ZERODHA feed in QUOTE mode does not send for this "
            "instrument (it sends QUOTE); subscribe the instrument in LTP mode",
        ),
        (
            (EventType.DEPTH,),
            SubscriptionMode.FULL,
            "it runs only on DEPTH events, which the ZERODHA feed in FULL mode does not send for this "
            "instrument (it sends QUOTE)",
        ),
    ],
)
def test_an_event_strategy_fails_when_the_feed_sends_none_of_its_events(
    event_types: tuple[EventType, ...], mode: SubscriptionMode, expected: str
) -> None:
    entry = strategy(
        candle_intervals=(),
        warmup_candles=0,
        event_types=event_types,
        signal_conditions=(
            SignalCondition(signal_type=SignalType.BUY, description="Moves.", inputs=("last_price",)),
        ),
    )

    assert check(check_compatibility(entry, inputs(mode=mode)), DATA) == (FAILED, expected)


def test_events_the_feed_does_not_send_and_simulated_data_are_warnings() -> None:
    entry = strategy(
        markets=(MarketRegion.LAB,),
        event_types=(EventType.QUOTE, EventType.DEPTH),
        required_data=(DataRequirement.MARKET_DEPTH,),
    )
    lab = inputs(
        market=MarketRegion.LAB,
        instrument=instrument(exchange=Exchange.SIM, canonical_key="SIM:CASH:EQUITY:ALPHA"),
        provider=Provider.SIMULATOR,
        mode=SubscriptionMode.FULL,
    )

    result = check_compatibility(entry, lab)

    assert check(result, DATA) == (
        WARNING,
        "the SIMULATOR feed in FULL mode sends the market depth it needs; it also takes DEPTH events, "
        "which the SIMULATOR feed in FULL mode does not send; the data is simulated, so its signals are "
        "informational only",
    )
    assert result.compatible


def test_no_warmup_needed_passes() -> None:
    result = check_compatibility(strategy(warmup_candles=0), inputs(stored={}))

    assert check(result, WARMUP) == (PASSED, "it needs no warm-up candles")
    assert result.warmup == ()


def test_the_instrument_problem_is_its_listing_then_its_feed() -> None:
    entry = strategy(required_data=(DataRequirement.VOLUME,))
    feeds = FeedDelivery()
    args = (Provider.GROWW, SubscriptionMode.QUOTE, feeds)

    assert instrument_problem(entry, instrument(is_active=False), *args) == INACTIVE
    assert instrument_problem(entry, instrument(), *args) == (
        "it needs traded volume, which it does not get from the GROWW feed in QUOTE mode: "
        "the GROWW feed's volume is used only when GROWW_FEED_VOLUME_IS_CUMULATIVE=true"
    )
    cumulative = replace(feeds, groww_volume_is_cumulative=True)
    assert instrument_problem(entry, instrument(), Provider.GROWW, SubscriptionMode.QUOTE, cumulative) is None
