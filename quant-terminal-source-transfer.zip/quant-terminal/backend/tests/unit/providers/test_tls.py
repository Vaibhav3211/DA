"""The shared provider trust store: loaded once per process, chosen as httpx chooses its default."""

from __future__ import annotations

import ssl
from collections.abc import Iterator

import certifi
import pytest

from app.providers.http import create_http_client
from app.providers.tls import prepare_tls, tls_context, tls_context_for

OVERRIDES = ("SSL_CERT_FILE", "SSL_CERT_DIR")


@pytest.fixture
def fresh_trust_store(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """No environment overrides, and no cached context before or after the test."""
    for name in OVERRIDES:
        monkeypatch.delenv(name, raising=False)
    tls_context.cache_clear()
    yield
    tls_context.cache_clear()


@pytest.fixture
def context_builds(monkeypatch: pytest.MonkeyPatch, fresh_trust_store: None) -> list[dict[str, str]]:
    """Record trust store loads; each yields a bare client context instead of reading CA files."""
    builds: list[dict[str, str]] = []

    def create_default_context(**kwargs: str) -> ssl.SSLContext:
        builds.append(kwargs)
        return ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)

    monkeypatch.setattr(ssl, "create_default_context", create_default_context)
    return builds


async def test_provider_connections_load_the_trust_store_once(context_builds: list[dict[str, str]]) -> None:
    await prepare_tls()
    clients = [create_http_client(base_url="https://api.kite.trade", timeout=5.0) for _ in range(3)]
    feeds = {tls_context_for("wss://socket-api.groww.in"), tls_context_for("WSS://ws.kite.trade")}
    for client in clients:
        await client.aclose()
    assert context_builds == [{"cafile": certifi.where()}]
    assert feeds == {tls_context()}


@pytest.mark.parametrize(
    ("environment", "expected"),
    [
        ({"SSL_CERT_FILE": "corporate.pem"}, {"cafile": "corporate.pem"}),
        ({"SSL_CERT_DIR": "certs"}, {"capath": "certs"}),
        ({"SSL_CERT_FILE": "corporate.pem", "SSL_CERT_DIR": "certs"}, {"cafile": "corporate.pem"}),
        ({"SSL_CERT_FILE": "", "SSL_CERT_DIR": "certs"}, {"capath": "certs"}),
    ],
)
def test_environment_overrides_take_precedence_as_in_httpx(
    monkeypatch: pytest.MonkeyPatch,
    context_builds: list[dict[str, str]],
    environment: dict[str, str],
    expected: dict[str, str],
) -> None:
    for name, value in environment.items():
        monkeypatch.setenv(name, value)
    tls_context()
    assert context_builds == [expected]


@pytest.mark.usefixtures("fresh_trust_store")
def test_secure_urls_verify_the_server_certificate() -> None:
    context = tls_context_for("WSS://socket-api.groww.in")
    assert context is not None
    assert (context.verify_mode, context.check_hostname) == (ssl.CERT_REQUIRED, True)
    assert context.cert_store_stats()["x509_ca"] > 0
    assert tls_context_for("ws://127.0.0.1:4222") is None
