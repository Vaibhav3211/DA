"""Hand-written protobuf encodings of Groww feed messages (see ``app.providers.groww.proto``).

Fields are written in field-number order and zero values are omitted, as proto3 encoders do.
"""

from __future__ import annotations

import struct
from collections.abc import Sequence

LIVE_PRICE = 4
MARKET_DEPTH = 5
LIVE_INDEX = 6

CASH = 0
FNO = 1
BSE = 0
NSE = 1

TS_MILLIS = 1_767_586_530_000  # 2026-01-05 04:15:30 UTC (09:45:30 IST)

LIVE_PRICE_NUMBERS = {
    "ts_in_millis": 1,
    "open": 2,
    "high": 3,
    "low": 4,
    "close": 5,
    "volume": 6,
    "value": 7,
    "bid_qty": 8,
    "offer_qty": 9,
    "avg_price": 10,
    "high_price_range": 11,
    "low_price_range": 12,
    "ltp": 13,
    "open_interest": 14,
    "low_trade_range": 15,
    "high_trade_range": 16,
}

type BookEntry = tuple[int, float, float]  # (map key, price, qty)


def varint(value: int) -> bytes:
    value &= (1 << 64) - 1  # negative int32/int64 values use ten bytes
    out = bytearray()
    while value > 0x7F:
        out.append(value & 0x7F | 0x80)
        value >>= 7
    out.append(value)
    return bytes(out)


def tag(number: int, wire_type: int) -> bytes:
    return varint(number << 3 | wire_type)


def double_field(number: int, value: float) -> bytes:
    return tag(number, 1) + struct.pack("<d", value)


def varint_field(number: int, value: int) -> bytes:
    return tag(number, 0) + varint(value)


def bytes_field(number: int, value: bytes) -> bytes:
    return tag(number, 2) + varint(len(value)) + value


def live_price(**values: float) -> bytes:
    unknown = set(values) - set(LIVE_PRICE_NUMBERS)
    if unknown:
        raise TypeError(f"unknown live price fields: {sorted(unknown)}")
    return b"".join(
        double_field(number, values[name]) for name, number in LIVE_PRICE_NUMBERS.items() if values.get(name)
    )


def index_value(value: float, ts_in_millis: float = TS_MILLIS) -> bytes:
    return (double_field(1, ts_in_millis) if ts_in_millis else b"") + (
        double_field(2, value) if value else b""
    )


def book_entry(key: int, price: float, qty: float) -> bytes:
    """One map entry; like protobuf, the key and value are always written."""
    level = (double_field(1, price) if price else b"") + (double_field(2, qty) if qty else b"")
    return varint_field(1, key) + bytes_field(2, level)


def depth(
    *, buy: Sequence[BookEntry] = (), sell: Sequence[BookEntry] = (), ts_in_millis: float = TS_MILLIS
) -> bytes:
    return (
        (double_field(1, ts_in_millis) if ts_in_millis else b"")
        + b"".join(bytes_field(2, book_entry(*entry)) for entry in buy)
        + b"".join(bytes_field(3, book_entry(*entry)) for entry in sell)
    )


def feed_message(
    member: int | None,
    body: bytes = b"",
    *,
    symbol: str = "",
    segment: int = CASH,
    exchange: int = NSE,
) -> bytes:
    """A ``StocksSocketResponseProtoDto``; a selected oneof member is written even when empty."""
    return (
        (bytes_field(1, symbol.encode()) if symbol else b"")
        + (varint_field(2, segment) if segment else b"")
        + (varint_field(3, exchange) if exchange else b"")
        + (bytes_field(member, body) if member is not None else b"")
    )
