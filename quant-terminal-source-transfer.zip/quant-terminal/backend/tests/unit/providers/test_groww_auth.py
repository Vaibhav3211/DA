"""Groww token, TOTP and feed-credential helpers (pure functions; no provider is contacted)."""

from __future__ import annotations

import base64
import json
from datetime import UTC, datetime, timedelta, timezone

import nkeys
import pytest
from nats.aio.client import Client as NATS
from nats.aio.client import RawCredentials

from app.core.clock import IST
from app.core.errors import ValidationFailedError
from app.providers.errors import ProviderProtocolError
from app.providers.groww.auth import (
    approval_checksum,
    jwt_expiry,
    nats_credentials,
    new_user_nkey,
    next_daily_reset,
    token_expiry,
)
from app.providers.groww.totp import secret_bytes, totp_code
from tests.unit.providers.fake_groww import FEED_JWT

EPOCH = datetime(1970, 1, 1, tzinfo=UTC)
RFC_SECRET = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"  # base32 of b"12345678901234567890" (RFC 6238)
ISSUED = datetime(2026, 1, 5, 4, 15, 30, tzinfo=UTC)  # 09:45:30 IST


def segment(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode()


HEADER = segment(b'{"alg":"none"}')
NOT_JSON = segment(b"not json")
NOT_UTF8 = segment(b"\x80abc")


def jwt(claims: object) -> str:
    return f"{HEADER}.{segment(json.dumps(claims).encode())}.c2ln"


# ---- TOTP ------------------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("seconds", "code"),
    [
        (59, "287082"),
        (1111111109, "081804"),
        (1111111111, "050471"),
        (1234567890, "005924"),
        (2000000000, "279037"),
        (20000000000, "353130"),
    ],
)
def test_totp_matches_the_rfc_6238_sha1_vectors(seconds: int, code: str) -> None:
    assert totp_code(RFC_SECRET, now=EPOCH + timedelta(seconds=seconds)) == code


def test_totp_depends_on_the_instant_not_the_time_zone() -> None:
    instant = EPOCH + timedelta(seconds=1111111109)
    assert totp_code(RFC_SECRET, now=instant.astimezone(IST)) == "081804"


@pytest.mark.parametrize(
    "secret",
    [
        "gezdgnbvgy3tqojqgezdgnbvgy3tqojq",
        " GEZD GNBV-GY3T QOJQ\tGEZD-GNBV GY3T QOJQ ",
        "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ====",
    ],
)
def test_totp_secrets_are_normalised(secret: str) -> None:
    assert secret_bytes(secret) == b"12345678901234567890"


def test_totp_secrets_may_omit_their_padding() -> None:
    raw = b"0123456789abcdef"  # 26 base32 characters plus six padding characters
    assert secret_bytes(base64.b32encode(raw).decode().rstrip("=")) == raw


@pytest.mark.parametrize(
    ("secret", "message"),
    [
        ("A", "not valid base32"),
        ("GEZDGNBV0Y3TQOJQ", "not valid base32"),
        ("GEZDGNBV!Y3TQOJQ", "not valid base32"),
        ("", "too short"),
        ("JBSWY3DP", "too short"),  # 5 bytes
    ],
)
def test_invalid_totp_secrets_are_rejected(secret: str, message: str) -> None:
    with pytest.raises(ValidationFailedError) as caught:
        secret_bytes(secret)
    assert message in caught.value.message


def test_totp_rejects_naive_datetimes() -> None:
    with pytest.raises(ValueError, match="naive"):
        totp_code(RFC_SECRET, now=datetime(2026, 1, 5, 9, 45))


# ---- access tokens ---------------------------------------------------------------------------------


def test_approval_checksum_is_sha256_of_secret_and_timestamp() -> None:
    assert (
        approval_checksum("apisecret", 1767586530)
        == "515d53656374e0d8e3c512984967d644a9eb39d905a3ceb5395b7f7822758577"
    )


@pytest.mark.parametrize(
    ("claims", "expected"),
    [
        ({"exp": 1767657600}, datetime(2026, 1, 6, tzinfo=UTC)),
        ({"exp": 1767657600.5}, datetime(2026, 1, 6, 0, 0, 0, 500000, tzinfo=UTC)),
        ({"exp": True}, None),
        ({"exp": "1767657600"}, None),
        ({"sub": "user"}, None),
        ([1767657600], None),
        ({"exp": 1e15}, None),
        ({"exp": 1e20}, None),
        ({"exp": 10**400}, None),
        ({"exp": float("nan")}, None),
        ({"exp": float("inf")}, None),
    ],
)
def test_jwt_expiry_reads_only_plausible_exp_claims(claims: object, expected: datetime | None) -> None:
    assert jwt_expiry(jwt(claims)) == expected


@pytest.mark.parametrize(
    "token",
    [
        "opaque-access-token",
        "a.b",
        "a.b.c.d",
        f"x.{NOT_JSON}.y",
        f"x.{NOT_UTF8}.y",
        "x.a.y",  # one base64 character cannot encode a byte
    ],
)
def test_tokens_that_are_not_jwts_have_no_expiry(token: str) -> None:
    assert jwt_expiry(token) is None


@pytest.mark.parametrize(
    ("issued_at", "expected"),
    [
        (datetime(2026, 1, 5, 9, 45, tzinfo=IST), datetime(2026, 1, 6, 0, 30, tzinfo=UTC)),
        (datetime(2026, 1, 5, 5, 59, 59, tzinfo=IST), datetime(2026, 1, 5, 0, 30, tzinfo=UTC)),
        (datetime(2026, 1, 5, 6, 0, tzinfo=IST), datetime(2026, 1, 6, 0, 30, tzinfo=UTC)),
        (datetime(2026, 1, 4, 23, 0, tzinfo=UTC), datetime(2026, 1, 5, 0, 30, tzinfo=UTC)),
        (datetime(2026, 1, 5, tzinfo=timezone(timedelta(hours=-5))), datetime(2026, 1, 6, 0, 30, tzinfo=UTC)),
        (datetime(2026, 12, 31, 12, 0, tzinfo=IST), datetime(2027, 1, 1, 0, 30, tzinfo=UTC)),
    ],
)
def test_daily_reset_is_the_next_0600_ist(issued_at: datetime, expected: datetime) -> None:
    reset = next_daily_reset(issued_at)
    assert reset == expected
    assert reset.tzinfo is UTC


@pytest.mark.parametrize(
    ("token", "expected"),
    [
        (jwt({"exp": 1767657600}), datetime(2026, 1, 6, tzinfo=UTC)),
        (jwt({"exp": int(ISSUED.timestamp())}), datetime(2026, 1, 6, 0, 30, tzinfo=UTC)),
        (jwt({"exp": 1_000_000_000}), datetime(2026, 1, 6, 0, 30, tzinfo=UTC)),
        ("opaque-access-token", datetime(2026, 1, 6, 0, 30, tzinfo=UTC)),
    ],
)
def test_token_expiry_prefers_a_future_exp_claim(token: str, expected: datetime) -> None:
    assert token_expiry(token, ISSUED) == expected


def test_token_expiry_rejects_naive_datetimes() -> None:
    with pytest.raises(ValueError, match="naive"):
        token_expiry(jwt({"exp": 1767657600}), datetime(2026, 1, 5, 9, 45))


# ---- feed credentials ------------------------------------------------------------------------------


def test_user_nkeys_are_fresh_and_keep_the_seed_out_of_repr() -> None:
    first, second = new_user_nkey(), new_user_nkey()
    assert first.public_key != second.public_key
    assert first.seed != second.seed
    assert first.public_key.startswith("U")
    assert len(first.public_key) == 56
    assert first.seed.startswith("SU")
    assert len(first.seed) == 58
    assert nkeys.from_seed(first.seed.encode()).public_key == first.public_key.encode()
    assert first.seed not in repr(first)
    assert first.public_key in repr(first)


async def test_nats_credentials_are_readable_by_nats_py() -> None:
    pair = new_user_nkey()
    text = nats_credentials(FEED_JWT, pair.seed)
    assert text == (
        f"-----BEGIN NATS USER JWT-----\n{FEED_JWT}\n------END NATS USER JWT------\n\n"
        f"-----BEGIN USER NKEY SEED-----\n{pair.seed}\n------END USER NKEY SEED------\n"
    )
    client = NATS()
    assert bytes(client._read_creds_user_jwt(RawCredentials(text))) == FEED_JWT.encode()
    assert bytes(client._read_creds_user_nkey(RawCredentials(text))) == pair.seed.encode()


@pytest.mark.parametrize(
    "token",
    ["", "header.payload", f"{FEED_JWT}\n-----BEGIN USER NKEY SEED-----", "a b.c.d", f"{FEED_JWT}.extra"],
)
def test_malformed_feed_tokens_are_protocol_errors(token: str) -> None:
    with pytest.raises(ProviderProtocolError, match="malformed feed token"):
        nats_credentials(token, new_user_nkey().seed)


@pytest.mark.parametrize(
    "seed",
    ["", "SA" + "A" * 56, "SU" + "A" * 55, "SU" + "a" * 56, "SU" + "A" * 55 + "1", "SU" + "A" * 56 + "\n"],
)
def test_only_user_seeds_are_accepted(seed: str) -> None:
    with pytest.raises(ValueError, match="not an NKEY user seed"):
        nats_credentials(FEED_JWT, seed)
