"""Market availability comes from the providers' capabilities, and unavailable markets say why."""

from __future__ import annotations

from collections.abc import Iterable

from app.domain.enums import Exchange, Provider
from app.providers.capabilities import GROWW, ZERODHA, all_default_capabilities
from app.services.market_availability import MarketAvailability, market_availability

CALENDARS = (Exchange.NSE, Exchange.BSE)
NO_MCX_CALENDAR = "MCX has no trading calendar yet, so its sessions show as UNKNOWN"


def by_key(markets: Iterable[MarketAvailability]) -> dict[str, MarketAvailability]:
    return {market.key: market for market in markets}


def test_the_documented_capabilities_stream_the_indian_markets_only() -> None:
    markets = market_availability(all_default_capabilities(), calendars=CALENDARS)

    assert [(m.key, m.available, m.providers, m.planned_milestone) for m in markets] == [
        ("india-equity", True, (Provider.ZERODHA, Provider.GROWW), None),
        ("mcx-commodities", True, (Provider.ZERODHA,), None),
        ("nse-currency", True, (Provider.ZERODHA,), None),
        ("crypto", False, (), "M11"),
        ("spot-forex", False, (), "M12"),
        ("spot-metals", False, (), "M13"),
    ]
    found = by_key(markets)
    assert found["india-equity"].reason == "Streamed by Zerodha Kite Connect and Groww Trading API"
    assert found["india-equity"].notes == ()
    assert found["mcx-commodities"].notes[-1] == NO_MCX_CALENDAR
    assert (found["crypto"].reason, found["spot-metals"].reason, found["spot-metals"].region) == (
        "No provider adapter streams crypto yet",
        "No provider adapter streams spot metals yet",
        None,
    )


def test_a_market_is_unavailable_once_no_provider_streams_all_its_venues() -> None:
    without_mcx = ZERODHA.model_copy(update={"exchanges": (Exchange.NSE, Exchange.BSE)})
    not_streaming = GROWW.model_copy(update={"streaming": False})

    found = by_key(market_availability([without_mcx, not_streaming], calendars=(*CALENDARS, Exchange.MCX)))

    commodities = found["mcx-commodities"]
    assert (commodities.available, commodities.providers, commodities.planned_milestone) == (False, (), None)
    assert commodities.reason == "No provider's capabilities include streaming MCX COMMODITY"
    assert NO_MCX_CALENDAR not in commodities.notes  # MCX has a calendar here
    assert found["india-equity"].providers == (Provider.ZERODHA,)
