"""SimulatorAdapter: simulated mode only, synthetic SIM instruments only, every event SIMULATED."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from decimal import Decimal
from typing import Any
from uuid import UUID

import pytest

from app.core.config import AppEnv, Settings
from app.domain.enums import (
    ConnectionState,
    DataStatus,
    EventType,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
)
from app.providers.capabilities import default_capabilities
from app.providers.errors import ProviderNotEnabledError, UnsupportedInstrumentError
from app.providers.simulator import adapter as adapter_module
from app.providers.simulator.adapter import SimulatorAdapter
from app.providers.simulator.instruments import REFERENCE_PRICES, synthetic_instrument_dump
from tests.unit.providers.listeners import RecordingListener
from tests.unit.providers.simulator_helpers import sim_instrument

ACCOUNT = UUID("00000000-0000-4000-8000-000000000053")
DISABLED = (
    "Simulator (synthetic data) cannot stream: it runs only when APP_ENV is development or replay "
    "and SIMULATOR_ENABLED=true"
)


def adapter(settings: Settings) -> SimulatorAdapter:
    return SimulatorAdapter(
        account_id=ACCOUNT, settings=settings, capabilities=default_capabilities(Provider.SIMULATOR)
    )


def enabled(make_settings: Callable[..., Settings], **overrides: Any) -> Settings:
    values: dict[str, Any] = {"simulator_enabled": True, "simulator_tick_interval_seconds": 0.01}
    values.update(overrides)
    return make_settings(**values)


async def test_adapter_streams_simulated_events_without_credentials(
    make_settings: Callable[..., Settings],
) -> None:
    feed = adapter(enabled(make_settings, simulator_seed=1))
    alpha = sim_instrument("ALPHA")
    await feed.subscribe([alpha])
    await feed.connect()
    try:
        snapshot = await asyncio.wait_for(feed.next_event(), timeout=10)
        update = await asyncio.wait_for(feed.next_event(), timeout=10)
        health = await feed.health()
    finally:
        await feed.disconnect()

    assert (snapshot.instrument_id, snapshot.symbol, snapshot.exchange, snapshot.segment) == (
        alpha.instrument_id,
        "ALPHA",
        Exchange.SIM,
        Segment.CASH,
    )
    assert (snapshot.provider, snapshot.event_type, snapshot.last_price) == (
        Provider.SIMULATOR,
        EventType.QUOTE,
        Decimal("2450.00"),
    )
    assert snapshot.data_status is update.data_status is DataStatus.SIMULATED
    assert (health.state, health.data_status) == (ConnectionState.CONNECTED, DataStatus.SIMULATED)
    assert [stream.data_status for stream in health.streams] == [DataStatus.SIMULATED]
    assert health.message is None  # no credentials were ever needed
    stopped = await feed.health()
    assert (stopped.state, stopped.data_status) == (ConnectionState.STOPPED, DataStatus.SIMULATED)


@pytest.mark.parametrize(
    "overrides",
    [
        {},
        {"market_data_enabled": True},  # live market data does not enable the simulator
        {"app_env": AppEnv.LIVE_DATA, "market_data_enabled": True},
    ],
)
async def test_connect_is_refused_outside_simulated_mode(
    make_settings: Callable[..., Settings], overrides: dict[str, Any]
) -> None:
    feed = adapter(make_settings(**overrides))
    with pytest.raises(ProviderNotEnabledError) as caught:
        await feed.connect()
    assert caught.value.message == DISABLED
    assert (await feed.health()).state is ConnectionState.IDLE


async def test_adapter_streams_only_synthetic_sim_instruments(make_settings: Callable[..., Settings]) -> None:
    feed = adapter(enabled(make_settings))
    with pytest.raises(UnsupportedInstrumentError) as caught:
        await feed.subscribe([sim_instrument("RELIANCE", exchange=Exchange.NSE)])
    assert (
        caught.value.message == "Simulator (synthetic data) does not stream NSE CASH instruments (RELIANCE)"
    )
    assert feed.subscriptions == {}


@pytest.mark.parametrize(
    ("tick_interval", "heartbeat_timeout", "expected"),
    [(0.5, 10.0, 0.5), (5.0, 6.0, 2.0), (2.0, 0.0, 2.0)],
)
def test_sessions_tick_well_within_the_heartbeat_timeout(
    make_settings: Callable[..., Settings],
    monkeypatch: pytest.MonkeyPatch,
    tick_interval: float,
    heartbeat_timeout: float,
    expected: float,
) -> None:
    created: list[dict[str, Any]] = []
    monkeypatch.setattr(adapter_module, "SimulatorSession", lambda **options: created.append(options))
    feed = adapter(
        enabled(
            make_settings,
            simulator_tick_interval_seconds=tick_interval,
            feed_heartbeat_timeout_seconds=heartbeat_timeout,
        )
    )
    feed.create_session(0)
    feed.create_session(0)
    assert created == [{"market": feed.market, "account_id": ACCOUNT, "interval": expected}] * 2


async def test_prices_and_volume_continue_across_reconnects(make_settings: Callable[..., Settings]) -> None:
    feed = adapter(enabled(make_settings, simulator_seed=3))
    alpha = sim_instrument("ALPHA")
    first = feed.create_session(0)
    before = RecordingListener()
    await first.open(before)
    await first.subscribe([alpha])
    runner = asyncio.create_task(first.run())
    try:
        await before.wait_until(lambda: any(tick.volume for tick in before.ticks))
    finally:
        await first.close()
        await asyncio.wait_for(runner, timeout=5)

    second = feed.create_session(0)
    after = RecordingListener()
    await second.open(after)
    await second.subscribe([alpha])
    await second.close()
    last, resumed = before.ticks[-1], after.ticks[0]
    fields = ("last_price", "volume", "open_price", "high_price", "low_price", "average_price")
    assert [getattr(resumed, name) for name in fields] == [getattr(last, name) for name in fields]


def test_the_synthetic_catalog_is_streamable_by_the_simulator() -> None:
    dump = synthetic_instrument_dump()
    caps = default_capabilities(Provider.SIMULATOR)
    tokens = {record.provider_token for record in dump.records}
    assert dump.provider is Provider.SIMULATOR
    assert dump.rows == len(dump.records) == len(tokens) == 10
    assert tokens == set(REFERENCE_PRICES)
    for record in dump.records:
        assert (record.provider, record.exchange) == (Provider.SIMULATOR, Exchange.SIM)
        assert record.segment in caps.segments
        assert record.instrument_type in caps.instrument_types
        assert record.tradable is (record.instrument_type is InstrumentType.EQUITY)
        assert record.metadata == {"synthetic": True}
        assert (record.name or "").endswith("(synthetic)")
        tick_size = record.tick_size
        assert tick_size is not None
        assert REFERENCE_PRICES[record.provider_token] % tick_size == 0
