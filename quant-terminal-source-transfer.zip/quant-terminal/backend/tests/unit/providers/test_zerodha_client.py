from __future__ import annotations

import hashlib
from collections.abc import Callable
from datetime import UTC, date, datetime
from typing import Any
from urllib.parse import parse_qs

import httpx
import pytest

from app.core.errors import AppError
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderProtocolError,
    ProviderRateLimitedError,
    ProviderRequestRejectedError,
    ProviderUnavailableError,
)
from app.providers.zerodha import client as client_module
from app.providers.zerodha.client import KiteRestClient, quote_key

BASE_URL = "https://kite.test"
API_KEY = "kitekey123"
API_SECRET = "kitesecret456"
REQUEST_TOKEN = "ReqToken1234"
ACCESS_TOKEN = "AccessTok789"

Handler = Callable[[httpx.Request], httpx.Response]


def make_client(handler: Handler, **kwargs: Any) -> KiteRestClient:
    return KiteRestClient(
        api_key=API_KEY, base_url=BASE_URL, transport=httpx.MockTransport(handler), **kwargs
    )


def ok(data: object) -> httpx.Response:
    return httpx.Response(200, json={"status": "success", "data": data})


def kite_error(status: int, error_type: str, message: str) -> httpx.Response:
    return httpx.Response(status, json={"status": "error", "error_type": error_type, "message": message})


async def test_token_exchange_posts_the_checksum_and_authenticates_later_calls() -> None:
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        if request.url.path == "/session/token":
            return ok(
                {
                    "user_id": "AB1234",
                    "access_token": ACCESS_TOKEN,
                    "refresh_token": "",
                    "login_time": "2026-01-05 09:15:02",
                    "exchanges": ["NSE", "NFO", 7],
                    "products": ["CNC", "MIS"],
                }
            )
        return ok({"user_id": "AB1234", "exchanges": ["NSE"], "products": ["CNC"]})

    async with make_client(handler) as client:
        session = await client.generate_session(REQUEST_TOKEN, API_SECRET)
        profile = await client.profile()

    exchange, profile_request = seen
    assert (exchange.method, exchange.url.path) == ("POST", "/session/token")
    checksum = hashlib.sha256(f"{API_KEY}{REQUEST_TOKEN}{API_SECRET}".encode()).hexdigest()
    assert parse_qs(exchange.content.decode()) == {
        "api_key": [API_KEY],
        "request_token": [REQUEST_TOKEN],
        "checksum": [checksum],
    }
    assert exchange.headers["X-Kite-Version"] == "3"
    assert exchange.headers["User-Agent"].startswith("quant-terminal/")
    assert "Authorization" not in exchange.headers
    assert profile_request.headers["Authorization"] == f"token {API_KEY}:{ACCESS_TOKEN}"

    assert session.user_id == "AB1234"
    assert session.issued_at == datetime(2026, 1, 5, 3, 45, 2, tzinfo=UTC)
    assert session.expires_at == datetime(2026, 1, 6, 0, 30, tzinfo=UTC)  # 06:00 IST next day
    assert session.exchanges == ("NSE", "NFO")
    assert session.products == ("CNC", "MIS")
    assert ACCESS_TOKEN not in repr(session)
    assert (profile.user_id, profile.exchanges) == ("AB1234", ("NSE",))


async def test_token_exchange_without_login_time_uses_the_clock() -> None:
    now = datetime(2026, 1, 5, 4, 0, tzinfo=UTC)
    async with make_client(
        lambda _request: ok({"user_id": "AB1234", "access_token": ACCESS_TOKEN}), clock=lambda: now
    ) as client:
        session = await client.generate_session(REQUEST_TOKEN, API_SECRET)
    assert session.issued_at == now


@pytest.mark.parametrize(
    "data",
    [None, [], {"user_id": "AB1234"}, {"user_id": "AB1234", "access_token": ""}, {"access_token": "tok"}],
)
async def test_token_exchange_without_a_session_is_a_protocol_error(data: object) -> None:
    async with make_client(lambda _request: ok(data)) as client:
        with pytest.raises(ProviderProtocolError):
            await client.generate_session(REQUEST_TOKEN, API_SECRET)


@pytest.mark.parametrize(
    ("response", "expected"),
    [
        (
            kite_error(403, "TokenException", "Incorrect `api_key` or `access_token`."),
            ProviderAuthRequiredError,
        ),
        (kite_error(403, "PermissionException", "Insufficient permission"), ProviderRequestRejectedError),
        (kite_error(400, "InputException", "Invalid instrument"), ProviderRequestRejectedError),
        (kite_error(429, "NetworkException", "Too many requests"), ProviderRateLimitedError),
        (kite_error(502, "NetworkException", "Gateway timed out"), ProviderUnavailableError),
        (kite_error(500, "GeneralException", "Unknown error"), ProviderUnavailableError),
        (httpx.Response(401, json={"status": "error", "message": "bad"}), ProviderAuthRequiredError),
        (httpx.Response(503, text="<html>maintenance</html>"), ProviderUnavailableError),
        (
            httpx.Response(502, text="{", headers={"content-type": "application/json"}),
            ProviderUnavailableError,
        ),
        (httpx.Response(401, json=["not", "an", "object"]), ProviderAuthRequiredError),
        (httpx.Response(429, text="slow down"), ProviderRateLimitedError),
        (httpx.Response(200, text="{", headers={"content-type": "application/json"}), ProviderProtocolError),
        (httpx.Response(200, json=["not", "an", "object"]), ProviderProtocolError),
        (
            httpx.Response(200, text="<html></html>", headers={"content-type": "text/html"}),
            ProviderProtocolError,
        ),
    ],
)
async def test_failures_are_translated(response: httpx.Response, expected: type[AppError]) -> None:
    async with make_client(lambda _request: response, access_token=ACCESS_TOKEN) as client:
        with pytest.raises(expected) as caught:
            await client.profile()
    assert ACCESS_TOKEN not in caught.value.message


async def test_error_messages_are_redacted() -> None:
    message = f"Invalid access_token={ACCESS_TOKEN}"
    async with make_client(
        lambda _request: kite_error(403, "TokenException", message), access_token=ACCESS_TOKEN
    ) as client:
        with pytest.raises(ProviderAuthRequiredError) as caught:
            await client.profile()
    assert ACCESS_TOKEN not in caught.value.message


@pytest.mark.parametrize(
    ("failure", "text"),
    [(httpx.ConnectError, "failed: ConnectError"), (httpx.ReadTimeout, "timed out")],
)
async def test_transport_failures_do_not_echo_the_request(
    failure: type[httpx.TransportError], text: str
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise failure(f"cannot reach {request.url}", request=request)

    async with make_client(handler, access_token=ACCESS_TOKEN) as client:
        with pytest.raises(ProviderUnavailableError) as caught:
            await client.invalidate_access_token()
    assert text in caught.value.message
    assert ACCESS_TOKEN not in caught.value.message
    assert caught.value.__cause__ is None
    assert caught.value.__suppress_context__


async def test_authenticated_calls_need_an_access_token() -> None:
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return ok({})

    async with make_client(handler) as client:
        with pytest.raises(ProviderAuthRequiredError):
            await client.profile()
        with pytest.raises(ProviderAuthRequiredError):
            await client.quote(["NSE:INFY"])
    assert requests == []


async def test_logout_invalidates_the_token_and_forgets_it() -> None:
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return ok(True)

    async with make_client(handler, access_token=ACCESS_TOKEN) as client:
        await client.invalidate_access_token()
        await client.invalidate_access_token()  # nothing left to invalidate
        with pytest.raises(ProviderAuthRequiredError):
            await client.profile()
    [logout] = requests
    assert (logout.method, logout.url.path) == ("DELETE", "/session/token")
    assert dict(logout.url.params) == {"api_key": API_KEY, "access_token": ACCESS_TOKEN}
    assert "Authorization" not in logout.headers


async def test_instrument_dump_is_downloaded_as_csv_with_a_long_timeout() -> None:
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, content=b"instrument_token\n1\n", headers={"content-type": "text/csv"})

    async with make_client(handler) as anonymous:
        assert await anonymous.instruments_csv("NFO") == b"instrument_token\n1\n"
    async with make_client(handler, access_token=ACCESS_TOKEN) as authenticated:
        await authenticated.instruments_csv()

    first, second = requests
    assert first.url.path == "/instruments/NFO"
    assert "Authorization" not in first.headers
    assert first.extensions["timeout"]["read"] == client_module.INSTRUMENTS_TIMEOUT_SECONDS
    assert second.url.path == "/instruments"
    assert second.headers["Authorization"] == f"token {API_KEY}:{ACCESS_TOKEN}"


@pytest.mark.parametrize(
    ("method", "path", "batch_setting"),
    [
        ("quote", "/quote", "QUOTE_BATCH_SIZE"),
        ("ohlc", "/quote/ohlc", "LTP_OHLC_BATCH_SIZE"),
        ("ltp", "/quote/ltp", "LTP_OHLC_BATCH_SIZE"),
    ],
)
async def test_quote_requests_are_deduplicated_and_batched(
    monkeypatch: pytest.MonkeyPatch, method: str, path: str, batch_setting: str
) -> None:
    monkeypatch.setattr(client_module, batch_setting, 2)
    monkeypatch.setattr(client_module, "QUOTE_RATE_PER_SECOND", 1000)  # no real waiting in tests
    batches: list[list[str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == path
        keys = request.url.params.get_list("i")
        batches.append(keys)
        return ok({key: {"last_price": 1.5} for key in keys})

    keys = [quote_key("NSE", "INFY"), "NSE:TCS", "NSE:INFY", "BSE:SENSEX", "NFO:NIFTY26JANFUT"]
    async with make_client(handler, access_token=ACCESS_TOKEN) as client:
        result = await getattr(client, method)(keys)
        assert await getattr(client, method)([]) == {}
    assert batches == [["NSE:INFY", "NSE:TCS"], ["BSE:SENSEX", "NFO:NIFTY26JANFUT"]]
    assert list(result) == ["NSE:INFY", "NSE:TCS", "BSE:SENSEX", "NFO:NIFTY26JANFUT"]


async def test_historical_candles_cover_whole_exchange_days() -> None:
    requests: list[httpx.Request] = []
    rows = [["2026-01-05T09:15:00+0530", 100, 101, 99, 100.5, 1200, 0]]

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return ok({"candles": rows})

    async with make_client(handler, access_token=ACCESS_TOKEN) as client:
        minutes = await client.historical_candles(
            "738561", "minute", date(2026, 1, 5), date(2026, 1, 9), oi=True
        )
        days = await client.historical_candles("738561", "day", date(2026, 1, 5), date(2026, 1, 5))

    assert minutes == days == rows
    first, second = requests
    assert (first.method, first.url.path) == ("GET", "/instruments/historical/738561/minute")
    assert dict(first.url.params) == {"from": "2026-01-05 00:00:00", "to": "2026-01-09 23:59:59", "oi": "1"}
    assert first.headers["Authorization"] == f"token {API_KEY}:{ACCESS_TOKEN}"
    assert (second.url.path, second.url.params["oi"]) == ("/instruments/historical/738561/day", "0")


@pytest.mark.parametrize("data", [None, {}, {"candles": {"0": []}}])
async def test_a_historical_response_without_a_candle_list_is_refused(data: object) -> None:
    async with make_client(lambda _request: ok(data), access_token=ACCESS_TOKEN) as client:
        with pytest.raises(ProviderProtocolError, match="historical candle response has no candle list"):
            await client.historical_candles("738561", "day", date(2026, 1, 5), date(2026, 1, 5))
