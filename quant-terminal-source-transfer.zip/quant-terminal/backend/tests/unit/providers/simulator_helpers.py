"""Simulator instruments shared by the simulator tests."""

from __future__ import annotations

from decimal import Decimal
from uuid import NAMESPACE_URL, uuid5

from app.domain.enums import Exchange, InstrumentType, Provider, Segment, SubscriptionMode
from app.domain.models import ProviderInstrument
from app.providers.simulator.instruments import EQUITY_TICK_SIZE, INDEX_TICK_SIZE


def sim_instrument(
    symbol: str = "ALPHA",
    mode: SubscriptionMode = SubscriptionMode.QUOTE,
    *,
    index: bool = False,
    exchange: Exchange = Exchange.SIM,
    tick_size: Decimal | None = None,
) -> ProviderInstrument:
    """An instrument mapped for the simulator; SIM tokens match the synthetic catalog."""
    segment = Segment.INDEX if index else Segment.CASH
    token = f"{exchange.value}:{symbol}"
    return ProviderInstrument(
        instrument_id=uuid5(NAMESPACE_URL, token),
        provider=Provider.SIMULATOR,
        provider_token=token,
        exchange_token=None,
        provider_symbol=symbol,
        provider_exchange=exchange.value,
        provider_segment=segment.value,
        exchange=exchange,
        segment=segment,
        instrument_type=InstrumentType.INDEX if index else InstrumentType.EQUITY,
        symbol=symbol,
        tick_size=tick_size or (INDEX_TICK_SIZE if index else EQUITY_TICK_SIZE),
        mode=mode,
    )
