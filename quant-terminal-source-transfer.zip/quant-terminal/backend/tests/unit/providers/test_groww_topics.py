"""Groww provider tokens and live-feed subjects.

The SDK cross-check reads growwapi's ``constants.py`` with ``ast`` (never importing or running the
SDK) and is skipped when the optional ``sdk-crosscheck`` extra is not installed.
"""

from __future__ import annotations

import ast

import pytest

from app.domain.enums import Exchange, Segment, SubscriptionMode
from app.providers.groww.topics import (
    FeedKey,
    FeedKind,
    feed_subjects,
    format_provider_token,
    parse_provider_token,
)
from tests.unit.providers.groww_sdk import sdk_file


@pytest.mark.parametrize(
    ("token", "key"),
    [
        ("NSE|CASH|2885", FeedKey(Exchange.NSE, Segment.CASH, "2885")),
        ("BSE|CASH|500325", FeedKey(Exchange.BSE, Segment.CASH, "500325")),
        ("NSE|FNO|35001", FeedKey(Exchange.NSE, Segment.FNO, "35001")),
        ("BSE|FNO|1129100", FeedKey(Exchange.BSE, Segment.FNO, "1129100")),
        ("NSE|INDEX|NIFTY", FeedKey(Exchange.NSE, Segment.INDEX, "NIFTY")),
        ("NSE|INDEX|NIFTY_BANK-1", FeedKey(Exchange.NSE, Segment.INDEX, "NIFTY_BANK-1")),
        ("BSE|INDEX|1", FeedKey(Exchange.BSE, Segment.INDEX, "1")),
        ("NSE|CASH|" + "9" * 64, FeedKey(Exchange.NSE, Segment.CASH, "9" * 64)),
    ],
)
def test_provider_tokens_round_trip(token: str, key: FeedKey) -> None:
    assert parse_provider_token(token) == key
    assert key.provider_token == token
    assert format_provider_token(key.exchange, key.segment, key.exchange_token) == token


@pytest.mark.parametrize(
    "token",
    [
        "",
        "2885",
        "NSE|CASH|",
        "NSE|CASH",
        "NSE|CASH|2885|1",
        "nse|CASH|2885",
        "NSE|cash|2885",
        "MCX|FNO|1",
        "NSE|CURRENCY|1",
        "NSE|COMMODITY|1",
        "SIM|CASH|1",
        "NSE|CASH|28.85",
        "NSE|CASH|*",
        "NSE|CASH|>",
        "NSE|CASH|2885.>",
        "NSE|CASH|28 85",
        "NSE|CASH|2885\n",
        " NSE|CASH|2885",
        "NSE|CASH|\u0662\u0668",
        "NSE|CASH|" + "9" * 65,
    ],
)
def test_tokens_outside_the_allow_list_are_rejected(token: str) -> None:
    with pytest.raises(ValueError, match="not a Groww provider token"):
        parse_provider_token(token)


@pytest.mark.parametrize(
    ("exchange", "segment", "exchange_token"),
    [
        (Exchange.MCX, Segment.FNO, "1"),
        (Exchange.SIM, Segment.CASH, "1"),
        (Exchange.NSE, Segment.CURRENCY, "1"),
        (Exchange.NSE, Segment.COMMODITY, "1"),
        (Exchange.NSE, Segment.CASH, ""),
        (Exchange.NSE, Segment.CASH, "a.b"),
        (Exchange.NSE, Segment.CASH, "*"),
        (Exchange.NSE, Segment.CASH, "1|2"),
    ],
)
def test_unstreamable_instruments_have_no_provider_token(
    exchange: Exchange, segment: Segment, exchange_token: str
) -> None:
    with pytest.raises(ValueError, match="not a Groww provider token"):
        format_provider_token(exchange, segment, exchange_token)


@pytest.mark.parametrize(
    ("token", "mode", "subjects"),
    [
        ("NSE|CASH|2885", SubscriptionMode.LTP, [("/ld/eq/nse/price.2885", FeedKind.PRICE)]),
        ("NSE|CASH|2885", SubscriptionMode.QUOTE, [("/ld/eq/nse/price.2885", FeedKind.PRICE)]),
        (
            "NSE|CASH|2885",
            SubscriptionMode.FULL,
            [("/ld/eq/nse/price.2885", FeedKind.PRICE), ("/ld/eq/nse/book.2885", FeedKind.DEPTH)],
        ),
        ("BSE|CASH|500325", SubscriptionMode.QUOTE, [("/ld/eq/bse/price.500325", FeedKind.PRICE)]),
        ("NSE|FNO|35001", SubscriptionMode.LTP, [("/ld/fo/nse/price.35001", FeedKind.PRICE)]),
        (
            "BSE|FNO|1129100",
            SubscriptionMode.FULL,
            [("/ld/fo/bse/price.1129100", FeedKind.PRICE), ("/ld/fo/bse/book.1129100", FeedKind.DEPTH)],
        ),
        ("NSE|INDEX|NIFTY", SubscriptionMode.LTP, [("/ld/indices/nse/price.NIFTY", FeedKind.INDEX)]),
        ("NSE|INDEX|NIFTY", SubscriptionMode.FULL, [("/ld/indices/nse/price.NIFTY", FeedKind.INDEX)]),
        ("BSE|INDEX|1", SubscriptionMode.QUOTE, [("/ld/indices/bse/price.1", FeedKind.INDEX)]),
    ],
)
def test_feed_subjects(token: str, mode: SubscriptionMode, subjects: list[tuple[str, FeedKind]]) -> None:
    assert list(feed_subjects(parse_provider_token(token), mode)) == subjects


# ---- growwapi SDK cross-check (static) ---------------------------------------------------------

# SDK FeedConstants attribute names per (exchange, segment, payload kind).
SDK_PREFIXES = {
    (Exchange.NSE, Segment.CASH, FeedKind.PRICE): "EQUITY_NSE_LIVE_PRICES",
    (Exchange.BSE, Segment.CASH, FeedKind.PRICE): "EQUITY_BSE_LIVE_PRICES",
    (Exchange.NSE, Segment.CASH, FeedKind.DEPTH): "EQUITY_NSE_MARKET_DEPTH",
    (Exchange.BSE, Segment.CASH, FeedKind.DEPTH): "EQUITY_BSE_MARKET_DEPTH",
    (Exchange.NSE, Segment.FNO, FeedKind.PRICE): "DERIVATIVES_NSE_LIVE_PRICES",
    (Exchange.BSE, Segment.FNO, FeedKind.PRICE): "DERIVATIVES_BSE_LIVE_PRICES",
    (Exchange.NSE, Segment.FNO, FeedKind.DEPTH): "DERIVATIVES_NSE_MARKET_DEPTH",
    (Exchange.BSE, Segment.FNO, FeedKind.DEPTH): "DERIVATIVES_BSE_MARKET_DEPTH",
    (Exchange.NSE, Segment.INDEX, FeedKind.INDEX): "NSE_LIVE_INDEX",
    (Exchange.BSE, Segment.INDEX, FeedKind.INDEX): "BSE_LIVE_INDEX",
}


@pytest.fixture(scope="module")
def sdk_feed_constants() -> dict[str, str]:
    """String constants of growwapi's ``FeedConstants`` class, read without importing the SDK."""
    source = sdk_file("groww", "constants.py").read_text(encoding="utf-8")
    [feed_constants] = [
        node
        for node in ast.parse(source).body
        if isinstance(node, ast.ClassDef) and node.name == "FeedConstants"
    ]
    constants: dict[str, str] = {}
    for node in feed_constants.body:
        targets: list[ast.expr]
        value: ast.expr | None
        if isinstance(node, ast.AnnAssign):
            targets, value = [node.target], node.value
        elif isinstance(node, ast.Assign):
            targets, value = node.targets, node.value
        else:
            continue
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            constants.update({target.id: value.value for target in targets if isinstance(target, ast.Name)})
    return constants


def test_subjects_match_the_sdk_feed_constants(sdk_feed_constants: dict[str, str]) -> None:
    for (exchange, segment, kind), name in SDK_PREFIXES.items():
        subjects = dict(feed_subjects(FeedKey(exchange, segment, "1234"), SubscriptionMode.FULL))
        expected = sdk_feed_constants[name] + "1234"
        assert subjects[expected] is kind, (exchange, segment, kind)


def test_every_sdk_market_data_feed_is_mapped(sdk_feed_constants: dict[str, str]) -> None:
    """A new SDK feed type must be reviewed. ``price_detailed`` is deliberately unused (its payload
    is undocumented)."""
    market_data = {
        name
        for name, value in sdk_feed_constants.items()
        if value.startswith("/ld/") and "/price_detailed." not in value
    }
    assert market_data == set(SDK_PREFIXES.values())
