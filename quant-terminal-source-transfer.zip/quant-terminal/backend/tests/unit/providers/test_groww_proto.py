"""Groww feed protobuf decoding.

Every case is decoded by ``app.providers.groww.proto`` and, when the optional SDK is installed, by
the SDK's generated protobuf module, so both must agree on the expected values.
"""

from __future__ import annotations

import dataclasses
import math
import random
from types import ModuleType
from typing import Any

import pytest

from app.providers.groww.proto import (
    BookLevel,
    FeedMessage,
    IndexValue,
    LivePoint,
    LivePrice,
    MarketDepthPoint,
    ProtoDecodeError,
    decode_feed_message,
)
from tests.unit.providers.groww_frames import (
    BSE,
    CASH,
    FNO,
    LIVE_INDEX,
    LIVE_PRICE,
    MARKET_DEPTH,
    NSE,
    TS_MILLIS,
    bytes_field,
    depth,
    double_field,
    feed_message,
    index_value,
    live_price,
    tag,
    varint,
    varint_field,
)
from tests.unit.providers.groww_sdk import load_feed_pb2

PRICE_VALUES: dict[str, float] = {
    "ts_in_millis": TS_MILLIS,
    "open": 1500.5,
    "high": 1525.0,
    "low": 1490.25,
    "close": 1495.0,
    "volume": 1_234_567.0,
    "value": 1.85e9,
    "bid_qty": 300.0,
    "offer_qty": 450.0,
    "avg_price": 1510.75,
    "high_price_range": 1644.5,
    "low_price_range": 1345.5,
    "ltp": 1512.4,
    "open_interest": 98_765.0,
    "low_trade_range": 1400.0,
    "high_trade_range": 1600.0,
}


def unknown_fields(first: int) -> bytes:
    """One field of every skippable wire type, numbered from ``first``."""
    return (
        varint_field(first, 1)
        + double_field(first + 1, 1.5)
        + bytes_field(first + 2, b"\xff\x00")
        + tag(first + 3, 5)
        + b"\x01\x02\x03\x04"
    )


def book_entry_with(key: int, *value_chunks: bytes) -> bytes:
    return varint_field(1, key) + b"".join(bytes_field(2, chunk) for chunk in value_chunks)


CASES = [
    pytest.param(b"", FeedMessage("", 0, 0, None), id="empty"),
    pytest.param(feed_message(None, symbol="SBIN"), FeedMessage("SBIN", CASH, NSE, None), id="no-point"),
    pytest.param(
        feed_message(LIVE_PRICE, live_price(**PRICE_VALUES), symbol="RELIANCE"),
        FeedMessage("RELIANCE", CASH, NSE, LivePrice(**PRICE_VALUES)),
        id="live-price",
    ),
    pytest.param(feed_message(LIVE_PRICE), FeedMessage("", CASH, NSE, LivePrice()), id="empty-live-price"),
    pytest.param(
        feed_message(
            LIVE_PRICE, live_price(open=-1.5, high=math.inf, low=-math.inf, ltp=1e308, volume=5e-324)
        ),
        FeedMessage(
            "", CASH, NSE, LivePrice(open=-1.5, high=math.inf, low=-math.inf, ltp=1e308, volume=5e-324)
        ),
        id="extreme-doubles",
    ),
    pytest.param(
        feed_message(LIVE_INDEX, index_value(24_350.65), symbol="NIFTY", exchange=BSE),
        FeedMessage("NIFTY", CASH, BSE, IndexValue(TS_MILLIS, 24_350.65)),
        id="index",
    ),
    pytest.param(feed_message(LIVE_INDEX), FeedMessage("", CASH, NSE, IndexValue()), id="empty-index"),
    pytest.param(
        feed_message(
            MARKET_DEPTH,
            depth(buy=[(0, 1512.3, 40), (1, 1512.2, 0), (2, 0, 5)], sell=[(0, 1512.5, 25), (0, 1512.6, 30)]),
            symbol="NIFTY26JANFUT",
            segment=FNO,
        ),
        FeedMessage(
            "NIFTY26JANFUT",
            FNO,
            NSE,
            MarketDepthPoint(
                ts_in_millis=TS_MILLIS,
                buy_book={0: BookLevel(1512.3, 40), 1: BookLevel(1512.2, 0), 2: BookLevel(0, 5)},
                sell_book={0: BookLevel(1512.6, 30)},  # a repeated key replaces the earlier entry
            ),
        ),
        id="depth",
    ),
    pytest.param(
        feed_message(MARKET_DEPTH, depth(buy=[(2**31 - 1, 1, 1), (-(2**31), 2, 2)], sell=[(-1, 3, 3)])),
        FeedMessage(
            "",
            CASH,
            NSE,
            MarketDepthPoint(
                TS_MILLIS,
                {2**31 - 1: BookLevel(1, 1), -(2**31): BookLevel(2, 2)},
                {-1: BookLevel(3, 3)},
            ),
        ),
        id="int32-map-keys",
    ),
    pytest.param(
        feed_message(MARKET_DEPTH),
        FeedMessage("", CASH, NSE, MarketDepthPoint(0.0, {}, {})),
        id="empty-depth",
    ),
    pytest.param(
        bytes_field(LIVE_PRICE, live_price(ltp=10, volume=5)) + bytes_field(LIVE_PRICE, live_price(ltp=11)),
        FeedMessage("", 0, 0, LivePrice(ltp=11, volume=5)),
        id="member-chunks-merge",
    ),
    pytest.param(
        bytes_field(LIVE_PRICE, live_price(ltp=10)) + bytes_field(LIVE_INDEX, index_value(7, ts_in_millis=0)),
        FeedMessage("", 0, 0, IndexValue(value=7)),
        id="oneof-switch",
    ),
    pytest.param(
        bytes_field(LIVE_PRICE, live_price(ltp=10, volume=5))
        + bytes_field(LIVE_INDEX, index_value(7))
        + bytes_field(LIVE_PRICE, live_price(ltp=12)),
        FeedMessage("", 0, 0, LivePrice(ltp=12)),
        id="oneof-switch-back-starts-empty",
    ),
    pytest.param(
        bytes_field(MARKET_DEPTH, depth(buy=[(0, 10, 1)]))
        + bytes_field(MARKET_DEPTH, depth(buy=[(1, 9, 2)], sell=[(0, 11, 3)], ts_in_millis=0)),
        FeedMessage(
            "",
            0,
            0,
            MarketDepthPoint(TS_MILLIS, {0: BookLevel(10, 1), 1: BookLevel(9, 2)}, {0: BookLevel(11, 3)}),
        ),
        id="depth-chunks-merge",
    ),
    pytest.param(
        bytes_field(
            MARKET_DEPTH,
            bytes_field(2, book_entry_with(3, double_field(1, 10.5), double_field(2, 4.0)))
            + bytes_field(3, b""),
        ),
        FeedMessage("", 0, 0, MarketDepthPoint(0.0, {3: BookLevel(10.5, 4.0)}, {0: BookLevel()})),
        id="map-entry-chunks-merge-and-empty-entry",
    ),
    pytest.param(
        bytes_field(1, b"OLD")
        + bytes_field(1, "\u20b9 TEST".encode())
        + varint_field(2, 1)
        + varint_field(2, -1)
        + varint_field(3, (1 << 32) + 6),
        FeedMessage("\u20b9 TEST", -1, 6, None),
        id="repeated-scalars-and-int32",
    ),
    pytest.param(
        unknown_fields(7)
        + feed_message(
            MARKET_DEPTH,
            depth(buy=[(1, 9.5, 1)])
            # Unknown fields go in the map value, not the entry itself: upb moves an entry that has
            # its own unknown fields to the parent's unknown set, other runtimes keep it.
            + bytes_field(2, book_entry_with(2, double_field(1, 10.0) + unknown_fields(3)))
            + unknown_fields(4),
            symbol="SBIN",
        )
        + unknown_fields(1 << 20),
        FeedMessage(
            "SBIN", CASH, NSE, MarketDepthPoint(TS_MILLIS, {1: BookLevel(9.5, 1), 2: BookLevel(10.0)}, {})
        ),
        id="unknown-fields-depth",
    ),
    pytest.param(
        feed_message(LIVE_PRICE, live_price(ltp=10) + unknown_fields(17)),
        FeedMessage("", CASH, NSE, LivePrice(ltp=10)),
        id="unknown-fields-live-price",
    ),
    pytest.param(
        feed_message(LIVE_INDEX, index_value(5) + unknown_fields(3)),
        FeedMessage("", CASH, NSE, IndexValue(TS_MILLIS, 5)),
        id="unknown-fields-index",
    ),
]


@pytest.mark.parametrize(("frame", "expected"), CASES)
def test_decoding(frame: bytes, expected: FeedMessage) -> None:
    assert decode_feed_message(frame) == expected


@pytest.mark.parametrize(
    ("frame", "message"),
    [
        (b"\x00", "field number 0 is invalid"),
        (b"\x80", "truncated varint"),
        (tag(2, 0) + b"\x81", "truncated varint"),
        (tag(2, 0) + b"\xff" * 10 + b"\x01", "varint is longer than 10 bytes"),
        (tag(7, 1) + b"\x00" * 7, "truncated 64-bit field"),
        (tag(9, 2) + varint(5) + b"abcd", "truncated length-delimited field"),
        (tag(9, 2) + varint(1 << 63), "truncated length-delimited field"),
        (tag(10, 5) + b"\x00" * 3, "truncated 32-bit field"),
        (tag(7, 3), "unsupported wire type 3"),
        (tag(7, 4), "unsupported wire type 4"),
        (tag(7, 6), "unsupported wire type 6"),
        (tag(7, 7), "unsupported wire type 7"),
        (varint_field(1, 5), "field 1 has wire type 0, expected length-delimited"),
        (bytes_field(1, b"\xff"), "string field is not valid UTF-8"),
        (bytes_field(1, b"\xed\xa0\x80"), "string field is not valid UTF-8"),  # an encoded UTF-16 surrogate
        (bytes_field(2, b"\x01"), "field 2 has wire type 2, expected a varint"),
        (double_field(3, 1.0), "field 3 has wire type 1, expected a varint"),
        (varint_field(LIVE_PRICE, 1), "field 4 has wire type 0, expected length-delimited"),
        (double_field(MARKET_DEPTH, 1.0), "field 5 has wire type 1, expected length-delimited"),
        (feed_message(LIVE_PRICE, varint_field(13, 5)), "field 13 has wire type 0, expected a double"),
        (feed_message(LIVE_PRICE, tag(13, 5) + b"\x00" * 4), "field 13 has wire type 5, expected a double"),
        (feed_message(LIVE_INDEX, b"\x11\x00"), "truncated 64-bit field"),
        (feed_message(LIVE_INDEX, bytes_field(2, b"")), "field 2 has wire type 2, expected a double"),
        (feed_message(MARKET_DEPTH, varint_field(1, 5)), "field 1 has wire type 0, expected a double"),
        (
            feed_message(MARKET_DEPTH, varint_field(2, 1)),
            "field 2 has wire type 0, expected length-delimited",
        ),
        (feed_message(MARKET_DEPTH, bytes_field(2, b"\x0a")), "truncated varint"),
        (
            feed_message(MARKET_DEPTH, bytes_field(3, bytes_field(1, b"x"))),
            "field 1 has wire type 2, expected a varint",
        ),
        (
            feed_message(MARKET_DEPTH, bytes_field(3, double_field(2, 1.0))),
            "field 2 has wire type 1, expected length-delimited",
        ),
        (
            feed_message(MARKET_DEPTH, bytes_field(2, book_entry_with(1, varint_field(1, 5)))),
            "field 1 has wire type 0, expected a double",
        ),
    ],
)
def test_invalid_messages_are_rejected(frame: bytes, message: str) -> None:
    with pytest.raises(ProtoDecodeError) as excinfo:
        decode_feed_message(frame)
    assert excinfo.value.message == message


def test_arbitrary_bytes_only_raise_decode_errors() -> None:
    rng = random.Random(20260105)
    seeds = [frame for frame, _ in (case.values for case in CASES) if isinstance(frame, bytes) and frame]
    decoded = rejected = 0
    for _ in range(4000):
        if rng.random() < 0.5:
            data = rng.randbytes(rng.randrange(64))
        else:
            mutated = bytearray(rng.choice(seeds))
            for _ in range(rng.randrange(1, 4)):
                mutated[rng.randrange(len(mutated))] = rng.randrange(256)
            data = bytes(mutated[: rng.randrange(len(mutated) + 1)])
        try:
            decode_feed_message(data)
        except ProtoDecodeError:
            rejected += 1
        else:
            decoded += 1
    assert decoded > 100
    assert rejected > 100


# ---- growwapi SDK cross-check ------------------------------------------------------------------


@pytest.fixture(scope="module")
def sdk_pb2() -> ModuleType:
    return load_feed_pb2()


def camel(name: str) -> str:
    head, *rest = name.split("_")
    return head + "".join(word.capitalize() for word in rest)


def from_sdk(message: Any) -> FeedMessage:
    """Our representation of a parsed SDK ``StocksSocketResponseProtoDto``."""
    member = message.WhichOneof("livePoint")
    point: LivePoint | None = None
    if member == "stockLivePrice":
        price = message.stockLivePrice
        point = LivePrice(
            **{field.name: getattr(price, camel(field.name)) for field in dataclasses.fields(LivePrice)}
        )
    elif member == "stocksLiveIndices":
        point = IndexValue(message.stocksLiveIndices.tsInMillis, message.stocksLiveIndices.value)
    elif member == "stocksMarketDepth":
        book = message.stocksMarketDepth
        point = MarketDepthPoint(
            book.tsInMillis,
            {key: BookLevel(level.price, level.qty) for key, level in book.buyBook.items()},
            {key: BookLevel(level.price, level.qty) for key, level in book.sellBook.items()},
        )
    else:
        assert member is None
    return FeedMessage(message.symbol, message.segment, message.exchange, point)


@pytest.mark.parametrize(("frame", "expected"), CASES)
def test_sdk_parses_the_same_values(sdk_pb2: ModuleType, frame: bytes, expected: FeedMessage) -> None:
    assert from_sdk(sdk_pb2.StocksSocketResponseProtoDto.FromString(frame)) == expected


def test_sdk_encoded_messages_decode_identically(sdk_pb2: ModuleType) -> None:
    dto = sdk_pb2.StocksSocketResponseProtoDto
    with_empty_price = dto(symbol="EMPTY")
    with_empty_price.stockLivePrice.SetInParent()
    messages = [
        dto(),
        with_empty_price,
        dto(
            symbol="RELIANCE",
            segment=CASH,
            exchange=NSE,
            stockLivePrice=sdk_pb2.StocksLivePriceProto(
                **{camel(name): value for name, value in PRICE_VALUES.items()}
            ),
        ),
        dto(
            symbol="NIFTY 50", exchange=BSE, stocksLiveIndices=sdk_pb2.StocksLiveIndicesProto(value=24_350.65)
        ),
        dto(
            symbol="\u20b9 FUT",
            segment=FNO,
            exchange=6,
            stocksMarketDepth=sdk_pb2.StocksMarketDepthProto(
                tsInMillis=TS_MILLIS,
                buyBook={0: sdk_pb2.BookProto(price=1512.3, qty=40), -5: sdk_pb2.BookProto()},
                sellBook={2**31 - 1: sdk_pb2.BookProto(price=1e300, qty=5e-324)},
            ),
        ),
        dto(segment=-2, exchange=9),  # open enums keep unknown values
    ]
    for message in messages:
        assert decode_feed_message(message.SerializeToString()) == from_sdk(message)
