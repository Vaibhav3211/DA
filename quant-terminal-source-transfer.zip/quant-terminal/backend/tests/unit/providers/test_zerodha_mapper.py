from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from typing import Any
from uuid import uuid4

import pytest

from app.domain.enums import EventType, VolumeSemantics
from app.domain.models import ProviderTick
from app.providers.zerodha.exceptions import KiteFrameError
from app.providers.zerodha.mapper import (
    is_heartbeat,
    parse_frame,
    parse_packet,
    rest_quote_to_tick,
)
from tests.unit.providers.kite_frames import (
    BCD_FUTURE,
    CDS_FUTURE,
    EXCHANGE_TIME,
    MCX_FUTURE,
    NCO_FUTURE,
    NFO_OPTION,
    NIFTY_50,
    NSE_INFY,
    TRADE_TIME,
    frame,
    full_packet,
    index_packet,
    ltp_packet,
    quote_packet,
)

ACCOUNT = uuid4()
NOW = datetime(2026, 1, 5, 4, 15, 31, tzinfo=UTC)


def parse(packet: bytes) -> ProviderTick:
    return parse_packet(packet, account_id=ACCOUNT, received_at=NOW)


def test_ltp_packet() -> None:
    tick = parse(ltp_packet(NSE_INFY, 150025))
    assert tick.event_type is EventType.LTP
    assert tick.provider_token == str(NSE_INFY)
    assert tick.account_id == ACCOUNT
    assert tick.last_price == Decimal("1500.25")
    assert tick.volume is None
    assert tick.volume_semantics is VolumeSemantics.UNAVAILABLE


@pytest.mark.parametrize(
    ("token", "raw", "expected"),
    [
        (NSE_INFY, 150025, "1500.25"),
        (MCX_FUTURE, 7123400, "71234.00"),
        (CDS_FUTURE, 832512500, "83.2512500"),
        (BCD_FUTURE, 832525, "83.2525"),
        (NCO_FUTURE, 51234, "5.1234"),
    ],
)
def test_prices_are_scaled_exactly_per_segment(token: int, raw: int, expected: str) -> None:
    assert str(parse(ltp_packet(token, raw)).last_price) == expected


def test_index_packets_report_previous_close_and_exchange_time_in_full_mode() -> None:
    fields = {"last": 2410050, "high": 2420000, "low": 2400000, "open_": 2405000, "close": 2401000}
    quote = parse(index_packet(NIFTY_50, **fields))
    full = parse(index_packet(NIFTY_50, **fields, timestamp=EXCHANGE_TIME))
    for tick in (quote, full):
        assert tick.event_type is EventType.INDEX_VALUE
        assert tick.last_price == Decimal("24100.50")
        assert (tick.open_price, tick.high_price, tick.low_price) == (
            Decimal("24050.00"),
            Decimal("24200.00"),
            Decimal("24000.00"),
        )
        assert tick.previous_close == Decimal("24010.00")
        assert tick.close_price is None  # Kite's close is the previous session close
    assert quote.source_timestamp is None
    assert full.source_timestamp == datetime(2026, 1, 5, 4, 15, 30, tzinfo=UTC)


def test_quote_packet_keeps_cumulative_volume_and_treats_zero_prices_as_missing() -> None:
    tick = parse(
        quote_packet(NSE_INFY, last=150025, average=149850, volume=0, buy_qty=700, sell_qty=0, close=149575)
    )
    assert tick.event_type is EventType.QUOTE
    assert tick.average_price == Decimal("1498.50")
    assert tick.volume == 0
    assert tick.volume_semantics is VolumeSemantics.CUMULATIVE_DAY
    assert (tick.total_buy_quantity, tick.total_sell_quantity) == (700, 0)
    assert tick.last_quantity is None  # zero last-traded quantity means "not reported"
    assert (tick.open_price, tick.high_price, tick.low_price) == (None, None, None)
    assert tick.previous_close == Decimal("1495.75")
    assert tick.market_depth is None


def test_full_packet_for_a_derivative_has_depth_open_interest_and_timestamps() -> None:
    tick = parse(
        full_packet(
            NFO_OPTION,
            last=12050,
            last_qty=75,
            volume=1_500_000,
            oi=250_000,
            oi_high=260_000,
            oi_low=240_000,
            bids=[(150, 12045, 3), (75, 12040, 1)],
            asks=[(300, 12055, 4)],
        )
    )
    assert tick.event_type is EventType.QUOTE
    assert (tick.open_interest, tick.open_interest_day_high, tick.open_interest_day_low) == (
        250_000,
        260_000,
        240_000,
    )
    assert tick.last_trade_time == datetime.fromtimestamp(TRADE_TIME, tz=UTC)
    assert tick.source_timestamp == datetime.fromtimestamp(EXCHANGE_TIME, tz=UTC)
    depth = tick.market_depth
    assert depth is not None
    assert [(level.price, level.quantity, level.orders) for level in depth.bids] == [
        (Decimal("120.45"), 150, 3),
        (Decimal("120.40"), 75, 1),
    ]
    assert [(level.price, level.quantity) for level in depth.asks] == [(Decimal("120.55"), 300)]
    assert (tick.bid, tick.bid_quantity, tick.ask, tick.ask_quantity) == (
        Decimal("120.45"),
        150,
        Decimal("120.55"),
        300,
    )


def test_full_packet_for_cash_equity_has_no_open_interest() -> None:
    tick = parse(full_packet(NSE_INFY, last=150025, oi=0))
    assert tick.open_interest is None
    assert tick.market_depth is not None
    assert tick.market_depth.bids == ()


def test_frame_with_several_packets() -> None:
    parsed = parse_frame(
        frame(ltp_packet(NSE_INFY, 150025), full_packet(NFO_OPTION, last=12050)),
        account_id=ACCOUNT,
        received_at=NOW,
    )
    assert [tick.event_type for tick in parsed.ticks] == [EventType.LTP, EventType.QUOTE]
    assert parsed.malformed == 0
    assert parsed.error is None


def test_truncated_frame_keeps_complete_packets_and_counts_the_rest() -> None:
    data = frame(ltp_packet(NSE_INFY, 150025), quote_packet(NSE_INFY, last=150030))
    parsed = parse_frame(data[:-10], account_id=ACCOUNT, received_at=NOW)
    assert len(parsed.ticks) == 1
    assert parsed.malformed == 1
    assert parsed.error is not None
    assert "truncated" in parsed.error


def test_unknown_packet_length_is_counted_without_losing_other_packets() -> None:
    parsed = parse_frame(
        frame(b"\x00" * 12, ltp_packet(NSE_INFY, 150025)), account_id=ACCOUNT, received_at=NOW
    )
    assert len(parsed.ticks) == 1
    assert parsed.malformed == 1
    assert parsed.error == "unexpected packet length 12"
    with pytest.raises(KiteFrameError, match="unexpected packet length"):
        parse(b"\x00" * 12)


def test_heartbeats_and_empty_frames() -> None:
    assert is_heartbeat(b"\x00")
    assert not is_heartbeat(frame())
    empty = parse_frame(frame(), account_id=ACCOUNT, received_at=NOW)
    assert (empty.ticks, empty.malformed) == ((), 0)


def test_identical_packets_have_identical_digests() -> None:
    first = parse(ltp_packet(NSE_INFY, 150025))
    same = parse(ltp_packet(NSE_INFY, 150025))
    other = parse(ltp_packet(NSE_INFY, 150030))
    assert first.raw_payload_hash == same.raw_payload_hash
    assert first.raw_payload_hash != other.raw_payload_hash


# ---- REST quotes -----------------------------------------------------------------------------------


def test_rest_full_quote() -> None:
    tick = rest_quote_to_tick(
        {
            "instrument_token": NSE_INFY,
            "timestamp": "2026-01-05 09:45:30",
            "last_trade_time": "2026-01-05 09:45:29",
            "last_price": 1500.25,
            "last_quantity": 5,
            "buy_quantity": 1000,
            "sell_quantity": 2000,
            "volume": 123456,
            "average_price": 1498.5,
            "oi": 0,
            "ohlc": {"open": 1490, "high": 1510.5, "low": 1485, "close": 1495.75},
            "depth": {
                "buy": [
                    {"price": 1500.2, "quantity": 10, "orders": 2},
                    {"price": 0, "quantity": 0, "orders": 0},
                ],
                "sell": [{"price": 1500.3, "quantity": 7, "orders": 1}],
            },
        },
        account_id=ACCOUNT,
        received_at=NOW,
    )
    assert tick.event_type is EventType.QUOTE
    assert tick.last_price == Decimal("1500.25")
    assert tick.previous_close == Decimal("1495.75")
    assert (tick.volume, tick.volume_semantics) == (123456, VolumeSemantics.CUMULATIVE_DAY)
    assert tick.source_timestamp == datetime(2026, 1, 5, 4, 15, 30, tzinfo=UTC)  # IST → UTC
    assert tick.open_interest is None
    assert tick.market_depth is not None
    assert len(tick.market_depth.bids) == 1
    assert (tick.bid, tick.ask) == (Decimal("1500.2"), Decimal("1500.3"))


def test_rest_ltp_and_index_quotes() -> None:
    ltp = rest_quote_to_tick(
        {"instrument_token": NSE_INFY, "last_price": 1500.25}, account_id=None, received_at=NOW
    )
    index = rest_quote_to_tick(
        {"instrument_token": NIFTY_50, "last_price": 24100.5, "ohlc": {"close": 24010}},
        account_id=None,
        received_at=NOW,
    )
    assert ltp.event_type is EventType.LTP
    assert index.event_type is EventType.INDEX_VALUE
    assert index.previous_close == Decimal("24010")
    with pytest.raises(KiteFrameError, match="instrument_token"):
        rest_quote_to_tick({"last_price": 1}, account_id=None, received_at=NOW)


# ---- cross-check against the official SDK parser (test-only dependency) ----------------------------


def _number(value: Decimal | int | None) -> float:
    return 0.0 if value is None else float(value)


def test_parser_matches_the_pykiteconnect_reference_parser() -> None:
    ticker_module = pytest.importorskip("kiteconnect.ticker")
    data = frame(
        ltp_packet(NSE_INFY, 150025),
        ltp_packet(CDS_FUTURE, 832512500),
        ltp_packet(NCO_FUTURE, 51234),
        ltp_packet(MCX_FUTURE, 7123400),
        index_packet(NIFTY_50, last=2410050, high=2420000, low=2400000, open_=2405000, close=2401000),
        index_packet(
            NIFTY_50,
            last=2410050,
            high=2420000,
            low=2400000,
            open_=2405000,
            close=2401000,
            timestamp=EXCHANGE_TIME,
        ),
        quote_packet(
            NSE_INFY,
            last=150025,
            last_qty=5,
            average=149850,
            volume=123456,
            buy_qty=700,
            sell_qty=900,
            open_=149000,
            high=151050,
            low=148500,
            close=149575,
        ),
        full_packet(
            NFO_OPTION,
            last=12050,
            last_qty=75,
            average=12010,
            volume=1_500_000,
            buy_qty=40_000,
            sell_qty=35_000,
            open_=11800,
            high=12500,
            low=11500,
            close=11900,
            oi=250_000,
            oi_high=260_000,
            oi_low=240_000,
            bids=[(150, 12045, 3), (75, 12040, 1), (225, 12035, 2), (75, 12030, 1), (600, 12025, 5)],
            asks=[(300, 12055, 4), (150, 12060, 2), (75, 12065, 1), (450, 12070, 3), (150, 12075, 1)],
        ),
        full_packet(BCD_FUTURE, last=832525, volume=1000, close=832000, bids=[(1, 832520, 1)]),
    )
    reference: list[dict[str, Any]] = ticker_module.KiteTicker("api_key", "access_token")._parse_binary(data)
    ticks = parse_frame(data, account_id=None, received_at=NOW).ticks
    assert len(ticks) == len(reference)
    for ours, theirs in zip(ticks, reference, strict=True):
        assert int(ours.provider_token) == theirs["instrument_token"]
        assert _number(ours.last_price) == pytest.approx(theirs["last_price"])
        if "ohlc" in theirs:
            ohlc = theirs["ohlc"]
            assert _number(ours.open_price) == pytest.approx(ohlc["open"])
            assert _number(ours.high_price) == pytest.approx(ohlc["high"])
            assert _number(ours.low_price) == pytest.approx(ohlc["low"])
            assert _number(ours.previous_close) == pytest.approx(ohlc["close"])
        if "volume_traded" in theirs:
            assert ours.volume == theirs["volume_traded"]
            assert _number(ours.last_quantity) == theirs["last_traded_quantity"]
            assert _number(ours.average_price) == pytest.approx(theirs["average_traded_price"])
            assert ours.total_buy_quantity == theirs["total_buy_quantity"]
            assert ours.total_sell_quantity == theirs["total_sell_quantity"]
        if "exchange_timestamp" in theirs:
            assert ours.source_timestamp is not None
            # The SDK returns naive local time; compare instants.
            assert ours.source_timestamp.timestamp() == theirs["exchange_timestamp"].timestamp()
        if "depth" in theirs:
            assert ours.last_trade_time is not None
            assert ours.last_trade_time.timestamp() == theirs["last_trade_time"].timestamp()
            assert ours.market_depth is not None
            for side, levels in (("buy", ours.market_depth.bids), ("sell", ours.market_depth.asks)):
                expected = [level for level in theirs["depth"][side] if level["price"]]
                assert len(levels) == len(expected)
                for level, ref in zip(levels, expected, strict=True):
                    assert float(level.price) == pytest.approx(ref["price"])
                    assert (level.quantity, level.orders) == (ref["quantity"], ref["orders"])
            if ours.open_interest is not None:
                assert ours.open_interest == theirs["oi"]
