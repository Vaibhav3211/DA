"""Kite WebSocket session and adapter against a loopback server (no provider is contacted)."""

from __future__ import annotations

import asyncio
import json
import socket
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from decimal import Decimal
from http import HTTPStatus
from typing import Any
from uuid import uuid4

import pytest
from websockets.asyncio.server import ServerConnection, serve
from websockets.http11 import Request, Response

from app.core.config import Settings
from app.core.errors import AppError
from app.domain.enums import (
    ConnectionState,
    DataStatus,
    EventType,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
    SubscriptionMode,
)
from app.domain.models import ProviderInstrument
from app.providers.base import SessionCredentials
from app.providers.capabilities import default_capabilities
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderProtocolError,
    ProviderRateLimitedError,
    ProviderUnavailableError,
    UnsupportedInstrumentError,
)
from app.providers.http import USER_AGENT
from app.providers.zerodha.adapter import ZerodhaAdapter
from app.providers.zerodha.stream import KiteStreamSession
from tests.unit.providers.kite_frames import NFO_OPTION, NIFTY_50, NSE_INFY, frame, full_packet, ltp_packet
from tests.unit.providers.listeners import RecordingListener

pytestmark = pytest.mark.usefixtures("no_proxy_for_loopback")

API_KEY = "kitekey123"
ACCESS_TOKEN = "AccessTok789"
ACCOUNT = uuid4()
NOW = datetime(2026, 1, 5, 4, 15, 31, tzinfo=UTC)

type Handler = Callable[[ServerConnection], Awaitable[None]]


def instrument(token: int | str, mode: SubscriptionMode = SubscriptionMode.QUOTE) -> ProviderInstrument:
    return ProviderInstrument(
        instrument_id=uuid4(),
        provider=Provider.ZERODHA,
        provider_token=str(token),
        exchange_token=None,
        provider_symbol="INFY",
        provider_exchange="NSE",
        provider_segment="NSE",
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        instrument_type=InstrumentType.EQUITY,
        symbol="INFY",
        mode=mode,
    )


async def credentials() -> SessionCredentials:
    return SessionCredentials(access_token=ACCESS_TOKEN, api_key=API_KEY)


def session(url: str, source: Callable[[], Awaitable[SessionCredentials]] = credentials) -> KiteStreamSession:
    return KiteStreamSession(url=url, credentials=source, account_id=ACCOUNT, clock=lambda: NOW)


@asynccontextmanager
async def kite_server(handler: Handler, *, reject: HTTPStatus | None = None) -> AsyncIterator[str]:
    def process_request(connection: ServerConnection, _request: Request) -> Response | None:
        return None if reject is None else connection.respond(reject, "rejected\n")

    async with serve(handler, "127.0.0.1", 0, process_request=process_request) as server:
        port = server.sockets[0].getsockname()[1]
        yield f"ws://127.0.0.1:{port}"


async def test_session_subscribes_and_streams_until_a_clean_close() -> None:
    handshake: dict[str, str] = {}
    received: list[Any] = []

    async def handler(connection: ServerConnection) -> None:
        assert connection.request is not None
        handshake["path"] = connection.request.path
        handshake["version"] = connection.request.headers.get("X-Kite-Version", "")
        handshake["agent"] = connection.request.headers.get("User-Agent", "")
        handshake["extensions"] = connection.request.headers.get("Sec-WebSocket-Extensions", "")
        for _ in range(4):
            received.append(json.loads(await connection.recv()))
        await connection.send(b"\x00")
        await connection.send(frame(ltp_packet(NSE_INFY, 150025), full_packet(NFO_OPTION, last=12050)))
        await connection.send(json.dumps({"type": "order", "data": {"order_id": "1"}}))
        await connection.send(json.dumps({"type": "error", "data": f"bad access_token={ACCESS_TOKEN}"}))
        await connection.send(json.dumps({"type": "message", "data": "  Welcome  "}))
        await connection.send("not json")
        await connection.send("[1, 2]")
        await connection.send(frame(b"\x00" * 12))
        await connection.close()

    listener = RecordingListener()
    async with kite_server(handler) as url:
        stream = session(url)
        await stream.open(listener)
        await stream.subscribe(
            [
                instrument(NSE_INFY, SubscriptionMode.LTP),
                instrument(NFO_OPTION, SubscriptionMode.FULL),
                instrument(NIFTY_50, SubscriptionMode.LTP),
            ]
        )
        await stream.unsubscribe([instrument(NIFTY_50)])
        await asyncio.wait_for(stream.run(), timeout=5)
        await stream.close()
        await stream.close()

    assert handshake == {
        "path": f"/?api_key={API_KEY}&access_token={ACCESS_TOKEN}",
        "version": "3",
        "agent": USER_AGENT,
        "extensions": "",
    }
    assert received == [
        {"a": "subscribe", "v": [NSE_INFY, NFO_OPTION, NIFTY_50]},
        {"a": "mode", "v": ["ltp", [NSE_INFY, NIFTY_50]]},
        {"a": "mode", "v": ["full", [NFO_OPTION]]},
        {"a": "unsubscribe", "v": [NIFTY_50]},
    ]
    assert listener.heartbeats == 6  # one binary heartbeat and every text frame
    ticks, empty = listener.tick_batches
    assert [(tick.provider_token, tick.event_type) for tick in ticks] == [
        (str(NSE_INFY), EventType.LTP),
        (str(NFO_OPTION), EventType.QUOTE),
    ]
    assert all(tick.account_id == ACCOUNT and tick.received_at == NOW for tick in ticks)
    assert empty == ()
    assert listener.malformed == [
        ("text frame is not JSON", 1),
        ("text frame is not a JSON object", 1),
        ("unexpected packet length 12", 1),
    ]
    [(error_text, is_error), notice] = listener.notices
    assert is_error
    assert ACCESS_TOKEN not in error_text
    assert notice == ("Welcome", False)


async def test_existing_query_strings_are_extended() -> None:
    paths: list[str] = []

    async def handler(connection: ServerConnection) -> None:
        assert connection.request is not None
        paths.append(connection.request.path)

    async with kite_server(handler) as url:
        stream = session(f"{url}/feed?client=qt")
        await stream.open(RecordingListener())
        await asyncio.wait_for(stream.run(), timeout=5)
        await stream.close()
    assert paths == [f"/feed?client=qt&api_key={API_KEY}&access_token={ACCESS_TOKEN}"]


async def test_abnormal_close_is_a_retryable_failure() -> None:
    async def handler(connection: ServerConnection) -> None:
        await connection.close(code=1011, reason="upstream failure")

    async with kite_server(handler) as url:
        stream = session(url)
        await stream.open(RecordingListener())
        with pytest.raises(ProviderUnavailableError, match="close code 1011 \\(upstream failure\\)"):
            await asyncio.wait_for(stream.run(), timeout=5)
        await stream.close()


@pytest.mark.parametrize(
    ("status", "error"),
    [
        (HTTPStatus.FORBIDDEN, ProviderAuthRequiredError),
        (HTTPStatus.BAD_REQUEST, ProviderAuthRequiredError),
        (HTTPStatus.TOO_MANY_REQUESTS, ProviderRateLimitedError),
        (HTTPStatus.SERVICE_UNAVAILABLE, ProviderUnavailableError),
    ],
)
async def test_refused_handshakes_are_classified(status: HTTPStatus, error: type[AppError]) -> None:
    async def handler(_connection: ServerConnection) -> None:
        raise AssertionError("the handshake must not complete")

    async with kite_server(handler, reject=status) as url:
        with pytest.raises(error) as caught:
            await session(url).open(RecordingListener())
    assert f"HTTP {status.value}" in caught.value.message
    assert ACCESS_TOKEN not in caught.value.message


async def test_unreachable_endpoint_is_unavailable_without_echoing_the_url() -> None:
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    with pytest.raises(ProviderUnavailableError) as caught:
        await session(f"ws://127.0.0.1:{port}").open(RecordingListener())
    assert ACCESS_TOKEN not in caught.value.message


async def test_invalid_url_is_a_protocol_error_and_sessions_are_single_use() -> None:
    stream = session("http://127.0.0.1:1/not-a-websocket")
    with pytest.raises(ProviderProtocolError) as caught:
        await stream.open(RecordingListener())
    assert ACCESS_TOKEN not in caught.value.message
    with pytest.raises(RuntimeError, match="only be opened once"):
        await stream.open(RecordingListener())


async def test_session_needs_an_api_key_and_a_connection() -> None:
    async def without_key() -> SessionCredentials:
        return SessionCredentials(access_token=ACCESS_TOKEN)

    with pytest.raises(ProviderAuthRequiredError, match="API key"):
        await session("ws://127.0.0.1:1", without_key).open(RecordingListener())
    unopened = session("ws://127.0.0.1:1")
    await unopened.subscribe([])  # nothing to send
    with pytest.raises(ProviderUnavailableError, match="not connected"):
        await unopened.subscribe([instrument(NSE_INFY)])
    await unopened.close()


# ---- adapter ---------------------------------------------------------------------------------------


def adapter(settings: Settings) -> ZerodhaAdapter:
    return ZerodhaAdapter(
        account_id=ACCOUNT,
        settings=settings,
        capabilities=default_capabilities(Provider.ZERODHA),
        credentials=credentials,
    )


async def test_adapter_streams_normalized_events(make_settings: Callable[..., Settings]) -> None:
    async def handler(connection: ServerConnection) -> None:
        await connection.recv()  # subscribe
        await connection.recv()  # mode
        await connection.send(frame(ltp_packet(NSE_INFY, 150025), ltp_packet(NFO_OPTION, 12050)))
        await connection.wait_closed()

    async with kite_server(handler) as url:
        feed = adapter(make_settings(zerodha_ws_url=url, market_data_enabled=True))
        infy = instrument(NSE_INFY, SubscriptionMode.LTP)
        await feed.subscribe([infy])
        await feed.connect()
        try:
            event = await asyncio.wait_for(feed.next_event(), timeout=10)
            health = await feed.health()
        finally:
            await feed.disconnect()

    assert (event.instrument_id, event.symbol, event.exchange) == (infy.instrument_id, "INFY", Exchange.NSE)
    assert (event.event_type, event.last_price) == (EventType.LTP, Decimal("1500.25"))
    assert event.data_status is DataStatus.LIVE
    assert feed.queue.qsize() == 0  # the unsubscribed token was dropped, not misattributed
    assert health.state is ConnectionState.CONNECTED
    assert (await feed.health()).state is ConnectionState.STOPPED


@pytest.mark.parametrize("token", ["INFY", "0", "-5", "4294967296", "\u0661\u0662\u0663", ""])
async def test_adapter_rejects_instruments_without_a_kite_token(
    make_settings: Callable[..., Settings], token: str
) -> None:
    with pytest.raises(UnsupportedInstrumentError, match="Kite instrument token"):
        await adapter(make_settings()).subscribe([instrument(token)])
