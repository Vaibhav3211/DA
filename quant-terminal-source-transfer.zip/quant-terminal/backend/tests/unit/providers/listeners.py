"""A stream listener that records every callback, shared by the provider session tests."""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Sequence

from app.domain.models import ProviderTick


class RecordingListener:
    def __init__(self) -> None:
        self.calls = 0
        self.heartbeats = 0
        self.tick_batches: list[tuple[ProviderTick, ...]] = []
        self.malformed: list[tuple[str, int]] = []
        self.notices: list[tuple[str, bool]] = []
        self._changed = asyncio.Event()

    def on_heartbeat(self) -> None:
        self.heartbeats += 1
        self._record()

    def on_ticks(self, ticks: Sequence[ProviderTick]) -> None:
        self.tick_batches.append(tuple(ticks))
        self._record()

    def on_malformed(self, reason: str, count: int = 1) -> None:
        self.malformed.append((reason, count))
        self._record()

    def on_notice(self, message: str, *, error: bool = False) -> None:
        self.notices.append((message, error))
        self._record()

    @property
    def ticks(self) -> list[ProviderTick]:
        return [tick for batch in self.tick_batches for tick in batch]

    async def wait_until(self, predicate: Callable[[], bool]) -> None:
        """Wait for callbacks that sessions deliver from their own tasks."""
        async with asyncio.timeout(5):
            while not predicate():
                self._changed.clear()
                await self._changed.wait()

    def _record(self) -> None:
        self.calls += 1
        self._changed.set()
