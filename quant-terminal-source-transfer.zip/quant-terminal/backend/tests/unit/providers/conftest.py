"""Fixtures for provider tests. Nothing here may reach a real provider or the network."""

from __future__ import annotations

import pytest


@pytest.fixture
def no_proxy_for_loopback(monkeypatch: pytest.MonkeyPatch) -> None:
    """Keep loopback WebSocket tests off any system or environment proxy."""
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
