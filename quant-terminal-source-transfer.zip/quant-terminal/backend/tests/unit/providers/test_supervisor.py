"""The provider-neutral streaming core: event queue, shard planning, StreamSupervisor and the
MarketDataAdapter base, driven by scripted sessions that never touch the network.

Watchdogs, staleness and event rates read an injected clock, so time-dependent behaviour is driven
by advancing that clock instead of sleeping. Retry delays are real but long (10 s and more), so a
test that accidentally waits for one times out instead of passing slowly.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from collections.abc import AsyncIterator, Callable, Sequence
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any, ClassVar
from uuid import UUID

import pytest
from prometheus_client import REGISTRY
from structlog.testing import capture_logs

from app.core.clock import utc_now
from app.core.config import Settings
from app.domain.enums import (
    ConnectionState,
    DataStatus,
    EventType,
    Exchange,
    Provider,
    Segment,
    SubscriptionMode,
)
from app.domain.models import NormalizedMarketEvent, ProviderHealth, ProviderInstrument, ProviderTick
from app.providers.base import (
    EventQueue,
    MarketDataAdapter,
    SessionCredentials,
    StateChange,
    StreamListener,
    StreamSession,
    StreamSupervisor,
    SupervisorConfig,
    aggregate_state,
    normalize_tick,
    plan_shards,
)
from app.providers.capabilities import default_capabilities
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderNotEnabledError,
    SubscriptionCapacityError,
    UnsupportedInstrumentError,
)
from tests.unit.providers.simulator_helpers import sim_instrument

ACCOUNT = UUID("00000000-0000-4000-8000-000000000071")
START = datetime(2025, 1, 6, 4, 0, tzinfo=UTC)
STREAM_0 = f"simulator:{ACCOUNT}:0"
STREAM_1 = f"simulator:{ACCOUNT}:1"
State = ConnectionState


# ---- fakes and helpers ---------------------------------------------------------------------------


class FakeClock:
    """Wall-clock and monotonic time that move only when a test advances them."""

    def __init__(self) -> None:
        self.elapsed = 0.0

    def now(self) -> datetime:
        return START + timedelta(seconds=self.elapsed)

    def monotonic(self) -> float:
        return 1_000.0 + self.elapsed

    def advance(self, seconds: float) -> None:
        self.elapsed += seconds


def labels(instruments: Sequence[ProviderInstrument]) -> list[str]:
    return [f"{instrument.provider_token}/{instrument.mode.value}" for instrument in instruments]


class FakeSession(StreamSession):
    """A scripted provider connection that records what it is asked to do."""

    def __init__(
        self,
        *,
        open_error: Exception | None = None,
        subscribe_error: Exception | None = None,
        open_hangs: bool = False,
    ) -> None:
        self.open_error = open_error
        self.subscribe_error = subscribe_error
        self.open_hangs = open_hangs
        self.subscribed: list[list[str]] = []
        self.unsubscribed: list[list[str]] = []
        self.closed = 0
        self._listener: StreamListener | None = None
        self._ended = asyncio.Event()
        self._run_error: Exception | None = None

    @property
    def listener(self) -> StreamListener:
        if self._listener is None:
            pytest.fail("the session was never opened")
        return self._listener

    async def open(self, listener: StreamListener) -> None:
        if self.open_hangs:
            await asyncio.Event().wait()
        if self.open_error is not None:
            raise self.open_error
        self._listener = listener

    async def subscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        if self.subscribe_error is not None:
            raise self.subscribe_error
        self.subscribed.append(labels(instruments))

    async def unsubscribe(self, instruments: Sequence[ProviderInstrument]) -> None:
        self.unsubscribed.append(labels(instruments))

    async def run(self) -> None:
        await self._ended.wait()
        if self._run_error is not None:
            raise self._run_error

    async def close(self) -> None:
        self.closed += 1
        self._ended.set()

    def end(self, error: Exception | None = None) -> None:
        """The provider ends the connection: cleanly, or with ``error``."""
        self._run_error = error
        self._ended.set()


class Sessions:
    """Session factory: scripted sessions (or factory errors) first, then healthy sessions."""

    def __init__(self, *script: FakeSession | Exception) -> None:
        self._script = list(script)
        self.created: list[FakeSession] = []

    def __call__(self) -> StreamSession:
        step = self._script.pop(0) if self._script else FakeSession()
        if isinstance(step, Exception):
            raise step
        self.created.append(step)
        return step

    @property
    def last(self) -> FakeSession:
        return self.created[-1]


async def eventually(predicate: Callable[[], object]) -> None:
    """Wait (at most 5 s) for something a supervisor does in its own task."""
    async with asyncio.timeout(5):
        while not predicate():  # noqa: ASYNC110  (polled: the state spans sessions, supervisors and tasks)
            await asyncio.sleep(0.001)


def tick(
    token: str = "SIM:ALPHA",  # noqa: S107  (an instrument token, not a secret)
    *,
    price: str = "100",
    digest: str | None = None,
    delay: float | None = None,
    provider_delay: float | None = None,
) -> ProviderTick:
    """A quote received at START; ``delay``/``provider_delay`` date its exchange/provider timestamp."""
    return ProviderTick(
        provider=Provider.SIMULATOR,
        account_id=ACCOUNT,
        provider_token=token,
        event_type=EventType.QUOTE,
        received_at=START,
        last_price=Decimal(price),
        source_timestamp=None if delay is None else START - timedelta(seconds=delay),
        provider_timestamp=None if provider_delay is None else START - timedelta(seconds=provider_delay),
        raw_payload_hash=digest,
    )


def symbols(*names: str) -> list[ProviderInstrument]:
    return [sim_instrument(name) for name in names]


class Supervised:
    """A supervisor over scripted sessions, recording its state changes and the ticks it passes on."""

    def __init__(
        self, sessions: Sessions, config: SupervisorConfig, session_open: Callable[[], bool | None]
    ) -> None:
        self.sessions = sessions
        self.clock = FakeClock()
        self.changes: list[StateChange] = []
        self.batches: list[list[ProviderTick]] = []
        self.supervisor = StreamSupervisor(
            provider=Provider.SIMULATOR,
            account_id=ACCOUNT,
            stream_id="test:0",
            session_factory=sessions,
            config=config,
            tick_handler=lambda _supervisor, ticks: self.batches.append(list(ticks)),
            on_state_change=self.changes.append,
            session_open=session_open,
            clock=self.clock.now,
            monotonic=self.clock.monotonic,
            rng=lambda: 0.0,  # each retry delay is half its cap: 10 s, 20 s, 40 s, 40 s, ...
        )

    @property
    def states(self) -> list[ConnectionState]:
        return [change.state for change in self.changes]

    @property
    def reason(self) -> str:
        return self.changes[-1].reason

    async def wait_for(self, state: ConnectionState) -> None:
        await eventually(lambda: self.supervisor.state is state)

    async def connect(self) -> FakeSession:
        self.supervisor.start()
        await self.wait_for(State.CONNECTED)
        return self.sessions.last


@pytest.fixture
async def supervise() -> AsyncIterator[Callable[..., Supervised]]:
    """Build supervisors with the watchdogs off unless a test turns them on; all stop afterwards."""
    built: list[Supervised] = []

    def build(
        *script: FakeSession | Exception,
        session_open: Callable[[], bool | None] = lambda: None,
        **config: Any,
    ) -> Supervised:
        values: dict[str, Any] = {
            "heartbeat_timeout": 0.0,
            "tick_silence_timeout": 0.0,
            "reconnect_initial": 20.0,
            "reconnect_max": 80.0,
            "connect_timeout": 1.0,
            **config,
        }
        feed = Supervised(Sessions(*script), SupervisorConfig(**values), session_open)
        built.append(feed)
        return feed

    yield build
    for feed in built:
        await feed.supervisor.stop()


# ---- event queue ---------------------------------------------------------------------------------


def market_event(price: str) -> NormalizedMarketEvent:
    return normalize_tick(
        tick(price=price), sim_instrument(), processed_at=START, data_status=DataStatus.LIVE
    )


def dropped_metric(reason: str) -> float:
    labels = {"provider": Provider.SIMULATOR.value, "reason": reason}
    return REGISTRY.get_sample_value("qt_market_events_dropped_total", labels) or 0.0


async def test_a_full_queue_drops_the_oldest_event_and_counts_the_drop() -> None:
    queue = EventQueue(Provider.SIMULATOR, capacity=2)
    first, second, third = (market_event(price) for price in ("1", "2", "3"))
    before = dropped_metric("queue_full")

    assert [queue.put(event) for event in (first, second, third)] == [False, False, True]
    assert (queue.qsize(), queue.capacity, queue.dropped) == (2, 2, 1)
    assert dropped_metric("queue_full") == before + 1
    assert await queue.get() is second
    assert await queue.get() is third


@pytest.mark.parametrize("capacity", [0, -5])
def test_queue_capacity_must_be_positive(capacity: int) -> None:
    with pytest.raises(ValueError, match="queue capacity must be positive"):
        EventQueue(Provider.SIMULATOR, capacity)


# ---- shard planning ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("current", "expected"),
    [
        # Existing assignments stay put; new instruments fill the first connection with room.
        ({"SIM:B": 1}, {"SIM:A": 0, "SIM:B": 1, "SIM:C": 0, "SIM:D": 1}),
        # Assignments on a full connection, or on one that no longer exists (2), move.
        (
            {"SIM:A": 2, "SIM:B": 0, "SIM:C": 0, "SIM:D": 0},
            {"SIM:A": 1, "SIM:B": 0, "SIM:C": 0, "SIM:D": 1},
        ),
    ],
)
def test_shard_plans_keep_assignments_that_still_fit(
    current: dict[str, int], expected: dict[str, int]
) -> None:
    plan = plan_shards(current, symbols("A", "B", "C", "D"), shard_capacity=2, max_shards=2)
    assert plan == expected


def test_shard_plans_count_the_slots_each_instrument_uses() -> None:
    full = sim_instrument("A", SubscriptionMode.FULL)
    plan = plan_shards(
        {},
        [full, *symbols("B", "C")],
        shard_capacity=3,
        max_shards=2,
        cost=lambda instrument: 2 if instrument.mode is SubscriptionMode.FULL else 1,
    )
    assert plan == {"SIM:A": 0, "SIM:B": 0, "SIM:C": 1}


def test_shard_plans_refuse_more_instruments_than_the_connections_hold() -> None:
    with pytest.raises(SubscriptionCapacityError) as caught:
        plan_shards({"SIM:A": 0}, symbols("A", "B", "C"), shard_capacity=1, max_shards=2)
    assert caught.value.message == (
        "cannot subscribe 2 more instrument(s): the limit is 1 per connection x 2 connection(s) per account"
    )
    assert caught.value.details == {"shard_capacity": 1, "max_shards": 2, "in_use": 2}


@pytest.mark.parametrize(
    ("states", "expected"),
    [
        ([], State.IDLE),
        ([State.CONNECTED, State.AUTH_REQUIRED, State.RECONNECTING], State.AUTH_REQUIRED),
        ([State.CONNECTED, State.CONNECTED], State.CONNECTED),
        ([State.STOPPED, State.STOPPED], State.STOPPED),
        ([State.CONNECTED, State.RECONNECTING], State.RECONNECTING),
        ([State.IDLE, State.CONNECTING], State.CONNECTING),
        # A connection added for new instruments is still starting: not an outage.
        ([State.CONNECTED, State.IDLE], State.CONNECTING),
        ([State.CONNECTED, State.CONNECTING], State.CONNECTING),
        ([State.CONNECTED, State.DISCONNECTED], State.DISCONNECTED),
    ],
)
def test_an_account_state_summarizes_its_connections(
    states: list[ConnectionState], expected: ConnectionState
) -> None:
    assert aggregate_state(states) is expected


# ---- supervisor: subscriptions and ticks ---------------------------------------------------------


async def test_the_supervisor_subscribes_the_desired_set_and_then_only_differences(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise()
    alpha, beta, gamma = symbols("ALPHA", "BETA", "GAMMA")
    feed.supervisor.set_desired([alpha, beta])
    feed.supervisor.start()
    feed.supervisor.start()  # already running: no second connection
    await eventually(lambda: feed.sessions.created and feed.sessions.last.subscribed)
    session = feed.sessions.last
    assert feed.states == [State.CONNECTING, State.CONNECTED]
    assert session.subscribed == [["SIM:ALPHA/QUOTE", "SIM:BETA/QUOTE"]]

    feed.supervisor.set_desired([alpha, beta])  # unchanged: nothing is sent again
    feed.supervisor.set_desired([alpha, beta, gamma])
    await eventually(lambda: len(session.subscribed) == 2)
    feed.supervisor.set_desired([sim_instrument("ALPHA", SubscriptionMode.FULL), gamma])
    await eventually(lambda: len(session.subscribed) == 3)

    assert session.subscribed[1:] == [["SIM:GAMMA/QUOTE"], ["SIM:ALPHA/FULL"]]
    assert session.unsubscribed == [["SIM:ALPHA/QUOTE", "SIM:BETA/QUOTE"]]  # a new mode resubscribes
    health = feed.supervisor.health()
    assert (health.subscribed_instruments, health.desired_instruments) == (2, 2)
    assert len(feed.sessions.created) == 1


async def test_exact_repeats_of_the_latest_payload_are_dropped_and_counted(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise()
    session = await feed.connect()
    first, repeat, newer = tick(digest="d1"), tick(digest="d1"), tick(price="101", digest="d2")
    other = tick("SIM:BETA", digest="d1")  # the same digest for another instrument is not a repeat
    plain = tick()

    session.listener.on_ticks([first, repeat, other])
    session.listener.on_ticks([repeat])  # nothing new: the handler is not called
    session.listener.on_ticks([newer, first])  # an older payload after a newer one is a real update
    session.listener.on_ticks([plain, plain])  # without a digest nothing counts as a repeat

    assert feed.batches == [[first, other], [newer, first], [plain, plain]]
    health = feed.supervisor.health()
    assert (health.events_received, health.duplicate_events) == (6, 2)


async def test_implausible_ticks_are_dropped_and_counted_as_malformed(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise(max_future_skew=30.0)
    session = await feed.connect()
    good, negative, future = tick(), tick(price="-1"), tick("SIM:BETA", delay=-60.0)
    before = dropped_metric("invalid")

    session.listener.on_ticks([negative, good, future])
    session.listener.on_ticks([negative])  # nothing valid: the handler is not called

    assert feed.batches == [[good]]
    health = feed.supervisor.health()
    assert (health.events_received, health.malformed_events, health.last_event_at) == (1, 3, START)
    assert dropped_metric("invalid") == before + 3


async def test_health_reports_unknown_live_delayed_and_stale_data(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise(stale_after=30.0, delayed_latency=2.0)
    session = await feed.connect()
    waiting = feed.supervisor.health()  # connected, but nothing received yet

    session.listener.on_ticks([tick(delay=0.5), tick("SIM:BETA", delay=0.5)])
    live = feed.supervisor.health()
    session.listener.on_ticks([tick(price="101", delay=13.0)])  # smoothed: 500 + 0.2 x (13000 - 500)
    delayed = feed.supervisor.health()
    feed.clock.advance(31)
    stale = feed.supervisor.health()

    assert waiting.data_status is DataStatus.UNKNOWN
    assert (live.data_status, live.source_latency_ms, live.stale_seconds, live.events_per_second) == (
        DataStatus.LIVE,
        500.0,
        0.0,
        0.2,
    )
    assert (delayed.data_status, delayed.source_latency_ms) == (DataStatus.DELAYED, 3000.0)
    assert (stale.data_status, stale.stale_seconds, stale.events_per_second) == (DataStatus.STALE, 31.0, 0.0)
    assert (stale.events_received, stale.last_event_at) == (3, START)


@pytest.mark.parametrize(
    ("simulated", "received", "expected"),
    [
        (False, tick(), DataStatus.LIVE),  # no source timestamp: the latency is unknown
        (False, tick(delay=2.0), DataStatus.LIVE),
        (False, tick(delay=2.5), DataStatus.DELAYED),
        (False, tick(provider_delay=2.5), DataStatus.DELAYED),  # the provider's timestamp is the fallback
        (True, tick(delay=2.5), DataStatus.SIMULATED),
    ],
)
def test_each_event_is_labelled_by_its_own_latency(
    simulated: bool, received: ProviderTick, expected: DataStatus
) -> None:
    supervisor = StreamSupervisor(
        provider=Provider.SIMULATOR,
        account_id=ACCOUNT,
        stream_id="test:0",
        session_factory=Sessions(),
        config=SupervisorConfig(delayed_latency=2.0, simulated=simulated),
        tick_handler=lambda _supervisor, _ticks: None,
    )
    assert supervisor.event_status(received) is expected


async def test_provider_notices_and_malformed_payloads_show_in_health_without_secrets(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise()
    session = await feed.connect()
    with capture_logs() as logs:
        session.listener.on_malformed("truncated frame", 3)
        session.listener.on_notice("feed maintenance at 23:00")
        informed = feed.supervisor.health()
        session.listener.on_notice("subscribe failed for token=abc123secret " + "x" * 400, error=True)
    health = feed.supervisor.health()

    assert (informed.malformed_events, informed.last_error) == (3, None)
    assert health.last_error == ("subscribe failed for token=***REDACTED*** " + "x" * 400)[:300]
    assert [entry["event"] for entry in logs] == [
        "feed_malformed_payload",
        "feed_provider_notice",
        "feed_provider_error",
    ]
    assert "abc123secret" not in repr(logs)


# ---- supervisor: failures and reconnects ---------------------------------------------------------


@pytest.mark.parametrize(
    ("script", "reason"),
    [
        pytest.param(
            lambda: FakeSession(open_error=OSError("connection refused")),
            "connect failed: OSError: connection refused",
            id="refused",
        ),
        pytest.param(lambda: FakeSession(open_hangs=True), "connect failed: TimeoutError", id="timeout"),
        pytest.param(
            lambda: FakeSession(subscribe_error=RuntimeError("subscribe frame rejected")),
            "subscription failed: RuntimeError: subscribe frame rejected",
            id="subscribe",
        ),
        pytest.param(
            lambda: RuntimeError("no such shard"),
            "internal error: RuntimeError: no such shard",
            id="session-factory-bug",
        ),
    ],
)
async def test_failures_are_reported_and_retried(
    supervise: Callable[..., Supervised], script: Callable[[], FakeSession | Exception], reason: str
) -> None:
    feed = supervise(script(), connect_timeout=0.01)
    feed.supervisor.set_desired([sim_instrument()])
    feed.supervisor.start()
    await feed.wait_for(State.RECONNECTING)
    failed = feed.supervisor.health()

    feed.supervisor.request_reconnect("operator retry")  # skips the remaining 10 s
    await feed.wait_for(State.CONNECTED)
    await eventually(lambda: feed.sessions.last.subscribed)

    assert feed.reason == "connected"
    assert feed.changes[-2].reason == f"{reason}; retrying in 10.0s"
    assert (failed.data_status, failed.last_error) == (DataStatus.RECONNECTING, reason)
    assert feed.supervisor.health().last_error is None


@pytest.mark.parametrize("where", ["open", "subscribe", "stream"])
async def test_rejected_credentials_stop_retrying_until_restarted(
    supervise: Callable[..., Supervised], where: str
) -> None:
    rejected = ProviderAuthRequiredError("the access token was rejected")
    session = FakeSession(
        open_error=rejected if where == "open" else None,
        subscribe_error=rejected if where == "subscribe" else None,
    )
    feed = supervise(session)
    feed.supervisor.set_desired([sim_instrument()])
    feed.supervisor.start()
    if where == "stream":
        await eventually(lambda: session.subscribed)
        session.end(rejected)
    await eventually(lambda: not feed.supervisor.running)
    health = feed.supervisor.health()

    assert (feed.states[-1], feed.reason) == (State.AUTH_REQUIRED, "the access token was rejected")
    assert (health.auth_required, health.last_error) == (True, "the access token was rejected")
    assert (health.data_status, health.reconnect_count) == (DataStatus.DISCONNECTED, 0)
    assert (len(feed.sessions.created), session.closed) == (1, 1)

    await feed.connect()  # e.g. after a new login
    assert feed.supervisor.health().auth_required is False


async def test_a_lost_connection_is_restored_with_the_full_desired_set(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise()
    feed.supervisor.set_desired(symbols("ALPHA", "BETA"))
    first = await feed.connect()
    await eventually(lambda: first.subscribed)
    first.listener.on_ticks([tick(digest="d1")])

    first.end(ConnectionResetError("reset by peer"))
    await feed.wait_for(State.RECONNECTING)
    lost = feed.supervisor.health()
    feed.supervisor.request_reconnect("operator retry")
    await eventually(lambda: len(feed.sessions.created) == 2 and feed.sessions.last.subscribed)
    second = feed.sessions.last
    first.listener.on_ticks([tick(price="99")])  # late callbacks from the closed connection are ignored
    second.listener.on_ticks([tick(digest="d1")])  # payload digests start afresh on a new connection

    assert feed.states == [State.CONNECTING, State.CONNECTED, State.RECONNECTING, State.CONNECTED]
    assert feed.changes[2].reason == "connection lost: ConnectionResetError: reset by peer; retrying in 10.0s"
    assert (lost.data_status, lost.reconnect_count) == (DataStatus.RECONNECTING, 1)
    assert (lost.subscribed_instruments, lost.desired_instruments) == (0, 2)
    assert first.closed == 1
    assert second.subscribed == [["SIM:ALPHA/QUOTE", "SIM:BETA/QUOTE"]]
    assert feed.batches == [[tick(digest="d1")], [tick(digest="d1")]]


async def test_retry_delays_grow_until_a_connection_stays_up(supervise: Callable[..., Supervised]) -> None:
    feed = supervise(stable_after=30.0)
    feed.supervisor.start()
    reasons = []
    for stays_up in (0, 0, 0, 30):
        await feed.wait_for(State.CONNECTED)
        feed.clock.advance(stays_up)
        feed.sessions.last.end()
        await feed.wait_for(State.RECONNECTING)
        reasons.append(feed.reason)
        feed.supervisor.request_reconnect("retry now")

    delays = ("10.0", "20.0", "40.0", "10.0")  # the stable fourth connection reset the backoff
    assert reasons == [f"connection closed by provider; retrying in {delay}s" for delay in delays]
    assert feed.supervisor.health().reconnect_count == 4


async def test_a_requested_reconnect_replaces_the_connection_at_once(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise()
    first = await feed.connect()
    feed.supervisor.request_reconnect("the access token was refreshed")
    await eventually(lambda: len(feed.sessions.created) == 2)
    await feed.wait_for(State.CONNECTED)

    assert feed.states == [State.CONNECTING, State.CONNECTED, State.RECONNECTING, State.CONNECTED]
    assert feed.changes[2].reason == "reconnect requested: the access token was refreshed"
    assert (first.closed, feed.supervisor.health().reconnect_count) == (1, 1)


async def test_the_supervisor_gives_up_after_the_configured_retries(
    supervise: Callable[..., Supervised],
) -> None:
    refused = [FakeSession(open_error=OSError("connection refused")) for _ in range(3)]
    feed = supervise(*refused, reconnect_initial=0.001, reconnect_max=0.002, reconnect_max_attempts=2)
    feed.supervisor.start()
    await eventually(lambda: not feed.supervisor.running)

    assert (feed.states[-1], feed.reason) == (
        State.DISCONNECTED,
        "connect failed: OSError: connection refused; gave up after 2 attempts",
    )
    assert len(feed.sessions.created) == 3
    assert feed.supervisor.health().data_status is DataStatus.DISCONNECTED
    await feed.connect()  # e.g. once the network is back


async def test_stopping_closes_the_connection_and_clears_subscriptions(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise()
    feed.supervisor.set_desired([sim_instrument()])
    session = await feed.connect()
    await eventually(lambda: session.subscribed)
    await feed.supervisor.stop("disconnected")
    health = feed.supervisor.health()

    assert (feed.states[-1], feed.reason, feed.supervisor.running) == (State.STOPPED, "disconnected", False)
    assert (health.data_status, health.subscribed_instruments, health.desired_instruments) == (
        DataStatus.DISCONNECTED,
        0,
        1,
    )
    assert session.closed == 1


async def test_stopping_interrupts_a_retry_delay(supervise: Callable[..., Supervised]) -> None:
    feed = supervise(FakeSession(open_error=OSError("connection refused")))
    feed.supervisor.start()
    await feed.wait_for(State.RECONNECTING)
    async with asyncio.timeout(1):  # not the 10 s retry delay
        await feed.supervisor.stop("account disabled")
    assert (feed.states[-1], feed.reason, feed.supervisor.running) == (
        State.STOPPED,
        "account disabled",
        False,
    )


# ---- supervisor: watchdogs -----------------------------------------------------------------------


async def test_a_connection_without_data_or_heartbeats_is_replaced(
    supervise: Callable[..., Supervised],
) -> None:
    feed = supervise(heartbeat_timeout=0.04)  # checked every 0.01 s
    session = await feed.connect()
    feed.clock.advance(0.03)
    session.listener.on_heartbeat()
    feed.clock.advance(0.03)
    session.listener.on_malformed("unparseable frame")  # any message shows the connection is alive
    await asyncio.sleep(0.05)
    assert feed.supervisor.state is State.CONNECTED

    feed.clock.advance(0.05)
    await feed.wait_for(State.RECONNECTING)
    assert feed.reason == "no data or heartbeat for 0.04s; retrying in 10.0s"
    assert feed.supervisor.health().last_heartbeat_at == START + timedelta(seconds=0.03)


async def test_tick_silence_reconnects_only_while_the_market_is_open(
    supervise: Callable[..., Supervised],
) -> None:
    market_open: list[bool | None] = [None]
    feed = supervise(heartbeat_timeout=0.04, tick_silence_timeout=60.0, session_open=lambda: market_open[0])
    feed.supervisor.set_desired([sim_instrument()])
    session = await feed.connect()
    await eventually(lambda: session.subscribed)
    feed.clock.advance(61)
    session.listener.on_heartbeat()  # heartbeats still arrive, but no ticks
    await asyncio.sleep(0.05)
    assert feed.supervisor.state is State.CONNECTED  # market hours unknown: silence is expected

    market_open[0] = True
    await feed.wait_for(State.RECONNECTING)
    assert feed.reason == "no ticks for 60s while the market is open; retrying in 10.0s"


# ---- adapter -------------------------------------------------------------------------------------


class FakeAdapter(MarketDataAdapter):
    provider: ClassVar[Provider] = Provider.SIMULATOR

    def __init__(self, **options: Any) -> None:
        super().__init__(**options)
        self.script: defaultdict[int, list[FakeSession]] = defaultdict(list)
        self.sessions: defaultdict[int, list[FakeSession]] = defaultdict(list)

    def create_session(self, shard: int) -> StreamSession:
        scripted = self.script[shard]
        session = scripted.pop(0) if scripted else FakeSession()
        self.sessions[shard].append(session)
        return session

    def subscribed(self, shard: int) -> list[str]:
        """Everything the latest connection of ``shard`` subscribed."""
        sessions = self.sessions[shard]
        return [label for call in sessions[-1].subscribed for label in call] if sessions else []


@pytest.fixture
async def adapters(
    make_settings: Callable[..., Settings],
) -> AsyncIterator[Callable[..., FakeAdapter]]:
    """Build adapters with room for 2 instruments x 2 connections; all disconnect afterwards."""
    built: list[FakeAdapter] = []

    def build(
        *, settings: dict[str, Any] | None = None, caps: dict[str, Any] | None = None, **options: Any
    ) -> FakeAdapter:
        values: dict[str, Any] = {
            "market_data_enabled": True,
            "feed_heartbeat_timeout_seconds": 0.0,
            "feed_tick_silence_reconnect_seconds": 0.0,
            "reconnect_initial_delay_seconds": 20.0,
            "reconnect_max_delay_seconds": 80.0,
            **(settings or {}),
        }
        changes: dict[str, Any] = {
            "display_name": "Test feed",
            "max_instruments_per_connection": 2,
            "max_connections_per_account": 2,
            **(caps or {}),
        }
        adapter = FakeAdapter(
            account_id=ACCOUNT,
            settings=make_settings(**values),
            capabilities=default_capabilities(Provider.SIMULATOR).model_copy(update=changes),
            **options,
        )
        built.append(adapter)
        return adapter

    yield build
    for adapter in built:
        await adapter.disconnect()


async def combined_state(adapter: FakeAdapter, state: ConnectionState) -> ProviderHealth:
    """Wait (at most 5 s) until the adapter's combined state is ``state``; returns that health."""
    async with asyncio.timeout(5):
        while (health := await adapter.health()).state is not state:  # noqa: ASYNC110  (polled, as above)
            await asyncio.sleep(0.001)
    return health


def test_an_adapter_needs_capabilities_for_its_own_provider(make_settings: Callable[..., Settings]) -> None:
    with pytest.raises(ValueError, match="FakeAdapter streams SIMULATOR, but was given ZERODHA capabilities"):
        FakeAdapter(
            account_id=ACCOUNT, settings=make_settings(), capabilities=default_capabilities(Provider.ZERODHA)
        )


@pytest.mark.parametrize(
    ("market_data_enabled", "streaming", "reason"),
    [
        (False, True, "live market data is off (set MARKET_DATA_ENABLED=true)"),
        (True, False, "streaming is turned off in its capability configuration"),
    ],
)
async def test_connect_is_refused_when_streaming_is_not_allowed(
    adapters: Callable[..., FakeAdapter], market_data_enabled: bool, streaming: bool, reason: str
) -> None:
    feed = adapters(settings={"market_data_enabled": market_data_enabled}, caps={"streaming": streaming})
    with pytest.raises(ProviderNotEnabledError) as caught:
        await feed.connect()
    health = await feed.health()
    assert caught.value.message == f"Test feed cannot stream: {reason}"
    assert (health.state, health.data_status, health.streams) == (State.IDLE, DataStatus.DISCONNECTED, ())


async def test_instruments_are_spread_over_connections_and_emptied_ones_close(
    adapters: Callable[..., FakeAdapter],
) -> None:
    feed = adapters()
    await feed.subscribe(symbols("A", "B", "C"))  # planned before connecting
    await feed.connect()
    await feed.connect()  # already connected: nothing changes
    await eventually(lambda: feed.subscribed(0) and feed.subscribed(1))
    both = await combined_state(feed, State.CONNECTED)

    await feed.unsubscribe(symbols("C"))
    extra = feed.sessions[1][0]
    await eventually(lambda: extra.closed)
    remaining = await feed.health()

    assert (feed.subscribed(0), feed.subscribed(1)) == (["SIM:A/QUOTE", "SIM:B/QUOTE"], ["SIM:C/QUOTE"])
    assert [stream.stream_id for stream in both.streams] == [STREAM_0, STREAM_1]
    assert both.data_status is DataStatus.UNKNOWN  # connected, nothing received yet
    assert [stream.stream_id for stream in remaining.streams] == [STREAM_0]
    assert (len(feed.sessions[0]), len(feed.sessions[1])) == (1, 1)  # the first connection was untouched


async def test_subscriptions_beyond_capacity_change_nothing(adapters: Callable[..., FakeAdapter]) -> None:
    feed = adapters()
    await feed.subscribe(symbols("A", "B", "C"))
    with pytest.raises(SubscriptionCapacityError):
        await feed.subscribe(symbols("D", "E"))
    assert list(feed.subscriptions) == ["SIM:A", "SIM:B", "SIM:C"]

    await feed.set_subscriptions(symbols("D", "E"))  # replaces the whole set
    assert list(feed.subscriptions) == ["SIM:D", "SIM:E"]


@pytest.mark.parametrize("method", ["subscribe", "set_subscriptions"])
@pytest.mark.parametrize(
    ("instrument", "message"),
    [
        (
            sim_instrument("ALPHA").model_copy(update={"provider": Provider.ZERODHA}),
            "ALPHA is mapped for ZERODHA, not SIMULATOR",
        ),
        (sim_instrument("ALPHA", SubscriptionMode.FULL), "Test feed does not support FULL subscriptions"),
    ],
)
async def test_instruments_the_feed_cannot_stream_are_refused(
    adapters: Callable[..., FakeAdapter], method: str, instrument: ProviderInstrument, message: str
) -> None:
    feed = adapters(caps={"subscription_modes": (SubscriptionMode.LTP, SubscriptionMode.QUOTE)})
    with pytest.raises(UnsupportedInstrumentError) as caught:
        await getattr(feed, method)([sim_instrument("BETA"), instrument])
    assert caught.value.message == message
    assert feed.subscriptions == {}


async def test_ticks_become_events_for_subscribed_instruments_only(
    adapters: Callable[..., FakeAdapter],
) -> None:
    feed = adapters(queue_capacity=2)
    alpha = sim_instrument("ALPHA")
    await feed.subscribe([alpha])
    await feed.connect()
    await eventually(lambda: feed.subscribed(0))
    listener = feed.sessions[0][0].listener

    listener.on_ticks([tick(price="1"), tick("SIM:GHOST", price="2")])  # GHOST was never subscribed
    event = await feed.next_event()
    listener.on_ticks([tick(price=price) for price in ("2", "3", "4")])  # one more than the queue holds
    newest = [(await feed.next_event()).last_price for _ in range(2)]
    stream = (await feed.health()).streams[0]

    assert (event.instrument_id, event.symbol, event.exchange, event.segment) == (
        alpha.instrument_id,
        "ALPHA",
        Exchange.SIM,
        Segment.CASH,
    )
    assert (event.provider, event.account_id, event.provider_instrument_token) == (
        Provider.SIMULATOR,
        ACCOUNT,
        "SIM:ALPHA",
    )
    assert (event.last_price, event.received_at, event.data_status) == (Decimal("1"), START, DataStatus.LIVE)
    assert newest == [Decimal("3"), Decimal("4")]
    assert (stream.dropped_events, feed.queue.dropped) == (2, 1)  # the unmapped tick and the evicted event


class RecordingObserver:
    """Records state changes; recording the first one fails, as a database outage would."""

    def __init__(self) -> None:
        self.changes: list[tuple[str, ConnectionState | None, ConnectionState, str]] = []

    async def on_state_change(self, change: StateChange) -> None:
        self.changes.append((change.stream_id, change.previous, change.state, change.reason))
        if len(self.changes) == 1:
            raise RuntimeError("database unavailable")


async def test_state_changes_reach_the_observer_in_order_despite_its_failures(
    adapters: Callable[..., FakeAdapter],
) -> None:
    observer = RecordingObserver()
    feed = adapters(observer=observer)
    with capture_logs() as logs:
        await feed.connect()
        await eventually(lambda: len(observer.changes) == 2)
        await feed.disconnect()  # delivers the remaining changes before returning

    assert observer.changes == [
        (STREAM_0, State.IDLE, State.CONNECTING, "connecting"),
        (STREAM_0, State.CONNECTING, State.CONNECTED, "connected"),
        (STREAM_0, State.CONNECTED, State.STOPPED, "disconnected"),
    ]
    failures = [entry["error"] for entry in logs if entry["event"] == "feed_state_change_not_recorded"]
    assert failures == ["RuntimeError: database unavailable"]


async def test_state_listeners_see_every_change_and_their_failures_do_not_break_the_feed(
    adapters: Callable[..., FakeAdapter],
) -> None:
    seen: list[tuple[ConnectionState | None, ConnectionState]] = []

    def listener(change: StateChange) -> None:
        seen.append((change.previous, change.state))
        if change.state is State.CONNECTING:
            raise RuntimeError("bookkeeping failed")

    feed = adapters(state_listener=listener)  # no observer: the listener alone is called
    await feed.subscribe([sim_instrument("ALPHA")])
    with capture_logs() as logs:
        await feed.connect()
        await eventually(lambda: feed.subscribed(0))
        feed.sessions[0][0].listener.on_ticks([tick(price=price) for price in ("1", "2", "3")])
        first, rest, nothing = feed.queue.drain(2), feed.queue.drain(5), feed.queue.drain(5)
        await feed.disconnect()

    assert seen == [
        (State.IDLE, State.CONNECTING),
        (State.CONNECTING, State.CONNECTED),
        (State.CONNECTED, State.STOPPED),
    ]
    assert [event.last_price for event in first + rest] == [Decimal("1"), Decimal("2"), Decimal("3")]
    assert (len(first), nothing, feed.queue.qsize()) == (2, [], 0)
    failures = [entry["error"] for entry in logs if entry["event"] == "feed_state_listener_failed"]
    assert failures == ["RuntimeError: bookkeeping failed"]


async def test_reconnect_requests_restart_streams_and_use_new_credentials(
    adapters: Callable[..., FakeAdapter],
) -> None:
    feed = adapters()
    feed.script[0].append(FakeSession(open_error=ProviderAuthRequiredError("the access token was rejected")))
    await feed.connect()
    rejected = await combined_state(feed, State.AUTH_REQUIRED)

    feed.request_reconnect("logged in again")  # restarts the stream that stopped
    await combined_state(feed, State.CONNECTED)
    feed.request_reconnect("the access token was refreshed")  # replaces the running connection
    await eventually(lambda: len(feed.sessions[0]) == 3)
    restarted = await combined_state(feed, State.CONNECTED)
    await feed.disconnect()
    feed.request_reconnect("ignored while disconnected")

    assert (rejected.message, rejected.data_status) == (
        "the access token was rejected",
        DataStatus.DISCONNECTED,
    )
    assert (restarted.message, restarted.streams[0].reconnect_count) == (None, 1)
    assert len(feed.sessions[0]) == 3
    assert (await feed.health()).state is State.STOPPED


async def test_credentials_must_exist_and_be_unexpired(adapters: Callable[..., FakeAdapter]) -> None:
    with pytest.raises(ProviderAuthRequiredError) as missing:
        await adapters().load_credentials()

    expired_at = utc_now() - timedelta(minutes=1)
    current = SessionCredentials("expired-access-value", expires_at=expired_at)
    loads = 0

    async def source() -> SessionCredentials:
        nonlocal loads
        loads += 1
        return current

    feed = adapters(credentials=source)
    with pytest.raises(ProviderAuthRequiredError) as expired:
        await feed.load_credentials()
    current = SessionCredentials("fresh-access-value", "api-key-1", utc_now() + timedelta(hours=8))
    loaded = await feed.load_credentials()  # never cached: every attempt reads the latest
    health = await feed.health()

    assert missing.value.message == "Test feed has no credential source"
    assert expired.value.message == (
        f"the Test feed access token expired at {expired_at.isoformat()}; log in again"
    )
    assert (loaded, loads) == (current, 2)
    assert feed.token_expires_at == health.token_expires_at == current.expires_at
    assert "fresh-access-value" not in repr(loaded)
    assert "api-key-1" not in repr(loaded)


async def test_market_hours_are_checked_for_the_exchanges_each_connection_streams(
    adapters: Callable[..., FakeAdapter],
) -> None:
    asked: list[frozenset[Exchange]] = []

    def session_open(exchanges: frozenset[Exchange]) -> bool | None:
        asked.append(exchanges)
        return True

    feed = adapters(session_open=session_open)
    await feed.connect()
    idle = await feed.health()  # nothing assigned: no exchange to ask about
    await feed.subscribe([sim_instrument("ALPHA")])
    streaming = await feed.health()

    assert (idle.streams[0].session_open, streaming.streams[0].session_open) == (None, True)
    assert asked == [frozenset({Exchange.SIM})]
