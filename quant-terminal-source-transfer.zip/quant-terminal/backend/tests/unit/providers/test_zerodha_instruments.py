from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from app.domain.enums import Exchange, InstrumentType, OptionType, Provider, Segment
from app.domain.models import ProviderInstrumentRecord
from app.providers.errors import ProviderProtocolError
from app.providers.zerodha.instruments import parse_instrument_dump

HEADER = (
    "instrument_token,exchange_token,tradingsymbol,name,last_price,expiry,strike,tick_size,lot_size,"
    "instrument_type,segment,exchange"
)
ROWS = [
    "408065,1594,INFY,INFOSYS,1500.25,,0,0.05,1,EQ,NSE,NSE",
    "128053508,500209,INFY,INFOSYS,1500.1,,0,0.05,1,EQ,BSE,BSE",
    "256265,1001,NIFTY 50,NIFTY 50,0,,0,0,0,EQ,INDICES,NSE",
    "265,1,SENSEX,,0,,0,0,0,EQ,INDICES,BSE",
    "9001218,35161,NIFTY26JANFUT,NIFTY,0,2026-01-27,0,0.1,75.0,FUT,NFO-FUT,NFO",
    "9002242,35165,NIFTY2610624000CE,NIFTY,0,2026-01-06,24000,0.05,75,CE,NFO-OPT,NFO",
    "220000005,859375,SENSEX26JANFUT,SENSEX,0,2026-01-29,0,0.05,20,FUT,BFO-FUT,BFO",
    "1280003,5000,USDINR26JANFUT,USDINR,0,2026-01-28,0,0.0025,1,FUT,CDS-FUT,CDS",
    "112000007,437500,CRUDEOIL26JAN6000PE,CRUDEOIL,0,2026-01-15,6000.5,0.1,1,PE,MCX-OPT,MCX",
    "76812,300,GOLDGUINEA26JANFUT,GOLDGUINEA,0,2026-01-30,0,1,1,FUT,NCO-FUT,NCO",
    "300012,1172,WEIRD,,0,,0,0,0,XX,NSE,NSE",
    # unsupported exchanges
    "500001,1,SOMETHING,,0,,0,0.05,1,EQ,NSEIX,NSEIX",
    "500002,2,GIFT NIFTY,,0,,0,0,0,EQ,INDICES,NSEIX",
    # invalid rows
    "abc,1,BAD,,0,,0,0.05,1,EQ,NSE,NSE",
    "0,1,ZERO,,0,,0,0.05,1,EQ,NSE,NSE",
    "4294967296,1,HUGE,,0,,0,0.05,1,EQ,NSE,NSE",
    "600001,1,,,0,,0,0.05,1,EQ,NSE,NSE",
    "600002,1,NIFTYNOEXPFUT,NIFTY,0,,0,0.1,75,FUT,NFO-FUT,NFO",
    "600003,1,NIFTYNOSTRIKECE,NIFTY,0,2026-01-06,0,0.05,75,CE,NFO-OPT,NFO",
    "600004,1,NIFTYBADDATEPE,NIFTY,0,06-01-2026,24000,0.05,75,PE,NFO-OPT,NFO",
    "600005,1,BADLOT,,0,,0,0.05,1.5,EQ,NSE,NSE",
]


def dump(*rows: str, header: str = HEADER) -> bytes:
    return ("\n".join([header, *rows]) + "\n").encode()


@pytest.fixture(scope="module")
def records() -> dict[str, ProviderInstrumentRecord]:
    parsed = parse_instrument_dump(dump(*ROWS))
    assert parsed.provider is Provider.ZERODHA
    assert parsed.rows == len(ROWS)
    assert parsed.skipped == {"unsupported_exchange": 2, "invalid_row": 8}
    return {record.provider_token: record for record in parsed.records}


def test_cash_equity(records: dict[str, ProviderInstrumentRecord]) -> None:
    infy = records["408065"]
    assert (infy.exchange, infy.segment, infy.instrument_type) == (
        Exchange.NSE,
        Segment.CASH,
        InstrumentType.EQUITY,
    )
    assert (infy.provider_symbol, infy.provider_exchange, infy.provider_segment) == ("INFY", "NSE", "NSE")
    assert (infy.exchange_token, infy.name, infy.lot_size, infy.tick_size) == (
        "1594",
        "INFOSYS",
        1,
        Decimal("0.05"),
    )
    assert infy.tradable
    assert (infy.expiry, infy.underlying, infy.strike, infy.option_type) == (None, None, None, None)
    assert infy.metadata == {"instrument_type": "EQ"}
    assert records["128053508"].exchange is Exchange.BSE


def test_indices_are_not_tradable(records: dict[str, ProviderInstrumentRecord]) -> None:
    nifty, sensex = records["256265"], records["265"]
    assert (nifty.exchange, nifty.segment, nifty.instrument_type) == (
        Exchange.NSE,
        Segment.INDEX,
        InstrumentType.INDEX,
    )
    assert (sensex.exchange, sensex.segment) == (Exchange.BSE, Segment.INDEX)
    assert sensex.name == "SENSEX"  # falls back to the symbol
    assert not nifty.tradable
    assert (nifty.tick_size, nifty.lot_size) == (None, None)


def test_futures_and_options(records: dict[str, ProviderInstrumentRecord]) -> None:
    future, call = records["9001218"], records["9002242"]
    assert (future.exchange, future.segment, future.instrument_type) == (
        Exchange.NSE,
        Segment.FNO,
        InstrumentType.FUTURE,
    )
    assert (future.underlying, future.expiry, future.strike, future.lot_size) == (
        "NIFTY",
        date(2026, 1, 27),
        None,
        75,
    )
    assert (call.instrument_type, call.option_type, call.strike) == (
        InstrumentType.OPTION,
        OptionType.CE,
        Decimal("24000"),
    )
    put = records["112000007"]
    assert (put.exchange, put.segment, put.option_type, put.strike) == (
        Exchange.MCX,
        Segment.COMMODITY,
        OptionType.PE,
        Decimal("6000.5"),
    )


@pytest.mark.parametrize(
    ("token", "exchange", "segment"),
    [
        ("220000005", Exchange.BSE, Segment.FNO),
        ("1280003", Exchange.NSE, Segment.CURRENCY),
        ("76812", Exchange.NSE, Segment.COMMODITY),
    ],
)
def test_exchange_codes_map_to_canonical_exchange_and_segment(
    records: dict[str, ProviderInstrumentRecord], token: str, exchange: Exchange, segment: Segment
) -> None:
    assert (records[token].exchange, records[token].segment) == (exchange, segment)


def test_unknown_instrument_types_are_kept_as_other(records: dict[str, ProviderInstrumentRecord]) -> None:
    other = records["300012"]
    assert other.instrument_type is InstrumentType.OTHER
    assert other.metadata == {"instrument_type": "XX"}
    assert (other.tick_size, other.lot_size) == (None, None)


def test_columns_are_found_by_name_with_bom_and_extra_cells() -> None:
    header = (
        "exchange,segment,instrument_type,lot_size,tick_size,strike,expiry,name,tradingsymbol,"
        "exchange_token,instrument_token,extra"
    )
    data = "\ufeff".encode() + dump("NSE,NSE,EQ,1,0.05,0,,INFOSYS,INFY,1594,408065,x,surplus", header=header)
    [record] = parse_instrument_dump(data).records
    assert (record.provider_token, record.provider_symbol, record.exchange) == (
        "408065",
        "INFY",
        Exchange.NSE,
    )


@pytest.mark.parametrize(
    ("data", "message"),
    [
        (dump(*ROWS[:3], header=HEADER.replace("tradingsymbol", "symbol")), "lacks column"),
        (dump(header=HEADER), "no usable instruments"),
        (dump(*ROWS[11:], header=HEADER), "no usable instruments"),
        (b"", "lacks column"),
        (HEADER.encode() + b"\n\xff\xfe\n", "not UTF-8"),
    ],
)
def test_unusable_dumps_are_rejected(data: bytes, message: str) -> None:
    with pytest.raises(ProviderProtocolError, match=message):
        parse_instrument_dump(data)
