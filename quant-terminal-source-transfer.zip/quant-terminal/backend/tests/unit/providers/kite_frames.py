"""Builders for Kite ticker binary payloads, following the documented packet layout.

Prices are raw integers (paise for most segments). Tokens encode the segment in the low byte.
"""

from __future__ import annotations

import struct

NSE_INFY = 408065  # segment 1 (NSE)
NIFTY_50 = 256265  # segment 9 (indices)
NFO_OPTION = (12345 << 8) | 2
CDS_FUTURE = (5000 << 8) | 3
BCD_FUTURE = (100 << 8) | 6
MCX_FUTURE = (2000 << 8) | 7
NCO_FUTURE = (300 << 8) | 12

EXCHANGE_TIME = 1_767_586_530  # 2026-01-05 04:15:30 UTC
TRADE_TIME = 1_767_586_529

type Level = tuple[int, int, int]  # quantity, raw price, orders


def ltp_packet(token: int, last: int) -> bytes:
    return struct.pack(">2I", token, last)


def index_packet(
    token: int, *, last: int, high: int, low: int, open_: int, close: int, timestamp: int | None = None
) -> bytes:
    body = struct.pack(">7I", token, last, high, low, open_, close, 0)  # bytes 24-28: change (unused)
    return body if timestamp is None else body + struct.pack(">I", timestamp)


def quote_packet(
    token: int,
    *,
    last: int,
    last_qty: int = 0,
    average: int = 0,
    volume: int = 0,
    buy_qty: int = 0,
    sell_qty: int = 0,
    open_: int = 0,
    high: int = 0,
    low: int = 0,
    close: int = 0,
) -> bytes:
    return struct.pack(
        ">11I", token, last, last_qty, average, volume, buy_qty, sell_qty, open_, high, low, close
    )


def full_packet(
    token: int,
    *,
    last: int,
    bids: list[Level] | None = None,
    asks: list[Level] | None = None,
    trade_time: int = TRADE_TIME,
    timestamp: int = EXCHANGE_TIME,
    oi: int = 0,
    oi_high: int = 0,
    oi_low: int = 0,
    **quote: int,
) -> bytes:
    body = quote_packet(token, last=last, **quote)
    body += struct.pack(">5I", trade_time, oi, oi_high, oi_low, timestamp)
    empty: Level = (0, 0, 0)
    levels = ((bids or []) + [empty] * 5)[:5] + ((asks or []) + [empty] * 5)[:5]
    for quantity, price, orders in levels:
        body += struct.pack(">IIH2x", quantity, price, orders)
    assert len(body) == 184
    return body


def frame(*packets: bytes) -> bytes:
    data = struct.pack(">H", len(packets))
    for packet in packets:
        data += struct.pack(">H", len(packet)) + packet
    return data
