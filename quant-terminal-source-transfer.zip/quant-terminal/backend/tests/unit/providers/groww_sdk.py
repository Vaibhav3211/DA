"""Read-only access to the optional growwapi SDK for cross-check tests.

The SDK package is never imported or executed: tests parse its source with ``ast`` or load one
generated protobuf module by file path. Cross-checks skip when the ``sdk-crosscheck`` extra is not
installed.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType

import pytest

_FEED_PB2_MODULE = "_qt_groww_sdk_stocks_socket_response_pb2"


def sdk_file(*parts: str) -> Path:
    spec = importlib.util.find_spec("growwapi")  # a top-level lookup does not execute the package
    if spec is None or not spec.submodule_search_locations:
        pytest.skip("the growwapi SDK (optional sdk-crosscheck extra) is not installed")
    return Path(spec.submodule_search_locations[0], *parts)


def load_feed_pb2() -> ModuleType:
    """The SDK's generated ``stocks_socket_response_pb2`` module (descriptor code only), loaded once."""
    module = sys.modules.get(_FEED_PB2_MODULE)
    if module is not None:
        return module
    pytest.importorskip(
        "google.protobuf", reason="the protobuf runtime (sdk-crosscheck extra) is not installed"
    )
    spec = importlib.util.spec_from_file_location(
        _FEED_PB2_MODULE, sdk_file("groww", "proto", "stocks_socket_response_pb2.py")
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    sys.modules[_FEED_PB2_MODULE] = module
    return module
