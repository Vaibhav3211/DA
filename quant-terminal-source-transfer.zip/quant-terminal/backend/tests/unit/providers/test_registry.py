"""Provider registry: one adapter per provider, explicit enablement and never a silent fallback."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any
from uuid import UUID

import pytest

from app.core.config import AppEnv, Settings
from app.domain.enums import Provider
from app.providers.capabilities import default_capabilities
from app.providers.errors import ProviderNotEnabledError
from app.providers.groww.adapter import GrowwAdapter
from app.providers.registry import adapter_class, create_adapter, disabled_reason, streamable_providers

ACCOUNT = UUID("00000000-0000-4000-8000-000000000054")
LIVE_OFF = "live market data is off (set MARKET_DATA_ENABLED=true)"
SIMULATOR_OFF = "it runs only when APP_ENV is development or replay and SIMULATOR_ENABLED=true"
LIVE = (Provider.ZERODHA, Provider.GROWW)


def test_every_provider_has_its_own_adapter() -> None:
    assert {provider: adapter_class(provider).provider for provider in Provider} == {
        provider: provider for provider in Provider
    }
    # Only the simulator labels its events SIMULATED; live adapters never do.
    assert [provider for provider in Provider if adapter_class(provider).simulated] == [Provider.SIMULATOR]


@pytest.mark.parametrize(
    ("overrides", "streamable"),
    [
        ({}, ()),
        ({"market_data_enabled": True}, LIVE),
        ({"simulator_enabled": True}, (Provider.SIMULATOR,)),
        ({"market_data_enabled": True, "simulator_enabled": True}, (*LIVE, Provider.SIMULATOR)),
        ({"app_env": AppEnv.REPLAY, "simulator_enabled": True}, (Provider.SIMULATOR,)),
        ({"app_env": AppEnv.LIVE_DATA, "market_data_enabled": True}, LIVE),
    ],
)
def test_settings_decide_which_providers_may_stream(
    make_settings: Callable[..., Settings], overrides: dict[str, Any], streamable: tuple[Provider, ...]
) -> None:
    settings = make_settings(**overrides)
    assert streamable_providers(settings) == streamable
    reasons = {provider: disabled_reason(provider, settings) for provider in Provider}
    assert reasons == {
        provider: None
        if provider in streamable
        else (SIMULATOR_OFF if provider is Provider.SIMULATOR else LIVE_OFF)
        for provider in Provider
    }


async def test_a_live_provider_that_may_not_stream_is_refused_not_simulated(
    make_settings: Callable[..., Settings],
) -> None:
    settings = make_settings(simulator_enabled=True)  # the simulator could run; live data is off
    with pytest.raises(ProviderNotEnabledError) as caught:
        create_adapter(Provider.ZERODHA, account_id=ACCOUNT, settings=settings)
    assert caught.value.message == f"Zerodha Kite Connect cannot stream: {LIVE_OFF}"
    assert (caught.value.status_code, caught.value.code) == (409, "provider_not_enabled")

    # Adapters built without the registry are gated when they connect.
    direct = GrowwAdapter(
        account_id=ACCOUNT, settings=settings, capabilities=default_capabilities(Provider.GROWW)
    )
    with pytest.raises(ProviderNotEnabledError) as refused:
        await direct.connect()
    assert refused.value.message == f"Groww Trading API cannot stream: {LIVE_OFF}"


@pytest.mark.parametrize("provider", list(Provider))
def test_adapters_get_the_default_capabilities(
    make_settings: Callable[..., Settings], provider: Provider
) -> None:
    settings = make_settings(market_data_enabled=True, simulator_enabled=True)
    feed = create_adapter(provider, account_id=ACCOUNT, settings=settings)
    assert type(feed) is adapter_class(provider)
    assert feed.capabilities == default_capabilities(provider)
    assert feed.account_id == ACCOUNT


def test_capabilities_must_belong_to_the_provider(make_settings: Callable[..., Settings]) -> None:
    with pytest.raises(
        ValueError, match=r"^ZerodhaAdapter streams ZERODHA, but was given GROWW capabilities$"
    ):
        create_adapter(
            Provider.ZERODHA,
            account_id=ACCOUNT,
            settings=make_settings(market_data_enabled=True),
            capabilities=default_capabilities(Provider.GROWW),
        )


def test_streaming_turned_off_in_the_capabilities_is_refused(make_settings: Callable[..., Settings]) -> None:
    capabilities = default_capabilities(Provider.GROWW).model_copy(update={"streaming": False})
    with pytest.raises(ProviderNotEnabledError) as caught:
        create_adapter(
            Provider.GROWW,
            account_id=ACCOUNT,
            settings=make_settings(market_data_enabled=True),
            capabilities=capabilities,
        )
    assert caught.value.message == (
        "Groww Trading API cannot stream: streaming is turned off in its capability configuration"
    )
