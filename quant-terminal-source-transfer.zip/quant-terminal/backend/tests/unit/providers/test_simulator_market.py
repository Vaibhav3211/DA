"""SimulatedMarket: deterministic, bounded and internally consistent synthetic prices."""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from itertools import pairwise
from typing import Any
from uuid import UUID

import pytest

from app.core.clock import IST
from app.domain.enums import EventType, Exchange, SubscriptionMode, VolumeSemantics
from app.domain.models import ProviderInstrument, ProviderTick
from app.providers.simulator.instruments import REFERENCE_PRICES
from app.providers.simulator.market import SimulatedMarket
from tests.unit.providers.simulator_helpers import sim_instrument

ACCOUNT = UUID("00000000-0000-4000-8000-000000000051")
START = datetime(2026, 1, 5, 9, 0, tzinfo=UTC)


def market(**options: Any) -> SimulatedMarket:
    options.setdefault("reference_prices", REFERENCE_PRICES)
    return SimulatedMarket(**options)


def stream(
    source: SimulatedMarket, instrument: ProviderInstrument, steps: int, *, start: datetime = START
) -> list[ProviderTick]:
    """One step per second; only the updates that produced a tick."""
    ticks: list[ProviderTick] = []
    for second in range(steps):
        tick = source.step(instrument, account_id=ACCOUNT, now=start + timedelta(seconds=second))
        if tick is not None:
            ticks.append(tick)
    return ticks


def known[T](value: T | None) -> T:
    assert value is not None
    return value


def test_the_same_seed_reproduces_the_same_ticks() -> None:
    def run(seed: int) -> list[dict[str, Any]]:
        source = market(seed=seed)
        instruments = [sim_instrument("ALPHA", SubscriptionMode.FULL), sim_instrument("SIM50", index=True)]
        return [
            tick.model_dump()
            for second in range(300)
            for item in instruments
            if (tick := source.step(item, account_id=ACCOUNT, now=START + timedelta(seconds=second)))
            is not None
        ]

    first = run(7)
    assert len(first) > 200
    assert first == run(7)
    assert first != run(8)


@pytest.mark.parametrize(
    ("instrument", "grid"),
    [
        (sim_instrument("ALPHA"), Decimal("0.05")),
        (sim_instrument("ALPHA", tick_size=Decimal("0.10")), Decimal("0.10")),
        # Without a tick size: 0.05 for stocks, 0.01 for indices.
        (sim_instrument("NEWCO").model_copy(update={"tick_size": None}), Decimal("0.05")),
        (sim_instrument("NEWIDX", index=True).model_copy(update={"tick_size": None}), Decimal("0.01")),
    ],
)
def test_prices_stay_on_the_tick_grid_within_the_daily_band(
    instrument: ProviderInstrument, grid: Decimal
) -> None:
    ticks = stream(
        market(seed=3, volatility=0.05, update_probability=1.0, trade_probability=1.0), instrument, 2_000
    )
    previous_close = known(ticks[0].previous_close)
    lower, upper = previous_close * Decimal("0.8"), previous_close * Decimal("1.2")
    for tick in ticks:
        prices = (tick.last_price, tick.open_price, tick.high_price, tick.low_price, tick.bid, tick.ask)
        assert all(price % grid == 0 for price in prices if price is not None)
        assert lower <= known(tick.last_price) <= upper
    # The walk is volatile enough to reach both edges of the band, and is clamped there.
    assert min(known(tick.low_price) for tick in ticks) == lower
    assert max(known(tick.high_price) for tick in ticks) == upper


def test_quotes_are_internally_consistent() -> None:
    ticks = stream(
        market(seed=11, volatility=0.002, update_probability=1.0, trade_probability=0.5),
        sim_instrument("CHARLIE"),
        1_000,
    )
    assert len(ticks) == 1_000
    for tick in ticks:
        low, high, last = known(tick.low_price), known(tick.high_price), known(tick.last_price)
        assert tick.event_type is EventType.QUOTE
        assert tick.volume_semantics is VolumeSemantics.CUMULATIVE_DAY
        assert low <= known(tick.open_price) <= high
        assert low <= last <= high
        assert known(tick.bid) <= last <= known(tick.ask)
        assert known(tick.bid) < known(tick.ask)
        assert known(tick.bid_quantity) > 0
        assert known(tick.ask_quantity) > 0
        assert tick.market_depth is None
        assert tick.received_at == tick.source_timestamp
        if known(tick.volume):
            assert low <= known(tick.average_price) <= high
            assert tick.last_trade_time is not None
        assert ProviderTick.model_validate(tick.model_dump()).model_dump() == tick.model_dump()
    trades = 0
    for before, after in pairwise(ticks):
        traded = known(after.volume) - known(before.volume)
        assert traded >= 0  # cumulative for the day
        if traded:
            trades += 1
            assert after.last_quantity == traded
            assert after.last_trade_time == after.received_at
        else:
            assert after.last_price == before.last_price  # the price moves only on trades
    assert 0 < trades < len(ticks) - 1  # both trades and book-only updates happen


def test_full_mode_adds_five_levels_of_depth() -> None:
    ticks = stream(market(seed=5, update_probability=1.0), sim_instrument("ECHO", SubscriptionMode.FULL), 200)
    assert len(ticks) == 200
    for tick in ticks:
        depth = known(tick.market_depth)
        bids = [level.price for level in depth.bids]
        asks = [level.price for level in depth.asks]
        assert len(bids) == len(set(bids)) == 5
        assert len(asks) == len(set(asks)) == 5
        assert bids == sorted(bids, reverse=True)  # strictly descending, as the prices are distinct
        assert asks == sorted(asks)
        assert bids[0] < asks[0]
        assert (tick.bid, tick.bid_quantity) == (depth.bids[0].price, depth.bids[0].quantity)
        assert (tick.ask, tick.ask_quantity) == (depth.asks[0].price, depth.asks[0].quantity)
        assert all(1 <= (level.orders or 0) <= level.quantity for level in (*depth.bids, *depth.asks))


def test_the_book_never_goes_below_one_tick() -> None:
    penny = market(seed=1, reference_prices={"SIM:PENNY": Decimal("0.05")}, volatility=0.0)
    tick = penny.snapshot(sim_instrument("PENNY", SubscriptionMode.FULL), account_id=ACCOUNT, now=START)
    depth = known(tick.market_depth)
    assert [level.price for level in depth.bids] == [Decimal("0.05")]
    assert len(depth.asks) == 5
    assert all(level.price > Decimal("0.05") for level in depth.asks)


def test_ltp_subscribers_see_only_trades() -> None:
    quiet = market(seed=2, update_probability=1.0, trade_probability=0.0)
    assert stream(quiet, sim_instrument("GOLF", SubscriptionMode.LTP), 50) == []

    busy = market(seed=2, update_probability=1.0, trade_probability=1.0)
    ticks = stream(busy, sim_instrument("GOLF", SubscriptionMode.LTP), 50)
    assert len(ticks) == 50
    assert {tick.event_type for tick in ticks} == {EventType.LTP}
    assert all(tick.volume is None and tick.open_price is None and tick.bid is None for tick in ticks)


@pytest.mark.parametrize(
    ("mode", "event_type"),
    [
        (SubscriptionMode.QUOTE, EventType.INDEX_VALUE),
        (SubscriptionMode.FULL, EventType.INDEX_VALUE),
        (SubscriptionMode.LTP, EventType.LTP),
    ],
)
def test_indices_move_on_every_update_without_volume_or_depth(
    mode: SubscriptionMode, event_type: EventType
) -> None:
    source = market(seed=9, update_probability=1.0, trade_probability=0.0)
    ticks = stream(source, sim_instrument("SIM50", mode, index=True), 100)
    assert len(ticks) == 100
    assert {tick.event_type for tick in ticks} == {event_type}
    assert len({tick.last_price for tick in ticks}) > 1  # indices move although nothing trades
    for tick in ticks:
        assert (tick.volume, tick.volume_semantics) == (None, VolumeSemantics.UNAVAILABLE)
        assert (tick.bid, tick.market_depth, tick.last_quantity, tick.average_price) == (
            None,
            None,
            None,
            None,
        )
        assert (tick.open_price is None) is (mode is SubscriptionMode.LTP)


@pytest.mark.parametrize(
    ("exchange", "last_step", "other_midnight", "own_midnight"),
    [
        # The synthetic SIM exchange trades on UTC days; 18:30 UTC is only midnight in India.
        (
            Exchange.SIM,
            datetime(2026, 1, 5, 18, 29, 59, tzinfo=UTC),
            datetime(2026, 1, 5, 18, 30, tzinfo=UTC),
            datetime(2026, 1, 6, 0, 0, tzinfo=UTC),
        ),
        # Indian exchanges trade on IST days.
        (
            Exchange.NSE,
            datetime(2026, 1, 5, 23, 59, 59, tzinfo=UTC),
            datetime(2026, 1, 6, 0, 0, tzinfo=UTC),
            datetime(2026, 1, 6, 18, 30, tzinfo=UTC),
        ),
    ],
)
def test_the_day_rolls_over_at_midnight_exchange_time(
    exchange: Exchange, last_step: datetime, other_midnight: datetime, own_midnight: datetime
) -> None:
    source = market(seed=4, volatility=0.01, update_probability=1.0, trade_probability=1.0)
    item = sim_instrument("ROLL", exchange=exchange)
    last = stream(source, item, 30, start=last_step - timedelta(seconds=29))[-1]
    assert known(last.volume) > 0

    same_day = source.snapshot(item, account_id=ACCOUNT, now=other_midnight)
    assert (same_day.volume, same_day.previous_close) == (last.volume, last.previous_close)

    next_day = source.snapshot(item, account_id=ACCOUNT, now=own_midnight)
    assert next_day.last_price == last.last_price
    prices = (next_day.previous_close, next_day.open_price, next_day.high_price, next_day.low_price)
    assert prices == (last.last_price,) * 4
    assert (next_day.volume, next_day.last_quantity, next_day.average_price) == (0, None, None)
    assert next_day.last_trade_time == last.last_trade_time  # the last trade happened the day before


def test_starting_prices_come_from_reference_prices_or_the_token() -> None:
    items = (sim_instrument("ALPHA"), sim_instrument("NEWCO"), sim_instrument("NEWIDX", index=True))
    first, second = (
        {item.symbol: market(seed=seed).snapshot(item, account_id=ACCOUNT, now=START) for item in items}
        for seed in (1, 2)
    )
    prices = {symbol: known(tick.last_price) for symbol, tick in first.items()}
    assert prices == {symbol: tick.last_price for symbol, tick in second.items()}  # independent of the seed
    assert prices["ALPHA"] == Decimal("2450.00")
    assert 50 <= prices["NEWCO"] < 5_000
    assert 5_000 <= prices["NEWIDX"] < 55_000
    fresh = first["ALPHA"]
    assert (fresh.open_price, fresh.high_price, fresh.low_price, fresh.previous_close) == (
        fresh.last_price,
    ) * 4
    assert (fresh.volume, fresh.last_quantity, fresh.average_price, fresh.last_trade_time) == (
        0,
        None,
        None,
        None,
    )


def test_times_must_be_aware_and_are_reported_in_utc() -> None:
    source = market(seed=1)
    with pytest.raises(ValueError, match="naive datetime"):
        source.snapshot(sim_instrument(), account_id=ACCOUNT, now=datetime(2026, 1, 5, 9, 0))
    tick = source.snapshot(sim_instrument(), account_id=ACCOUNT, now=datetime(2026, 1, 5, 14, 30, tzinfo=IST))
    assert tick.received_at == tick.source_timestamp == START
    assert tick.received_at.tzinfo is UTC


@pytest.mark.parametrize(
    ("options", "message"),
    [
        ({"volatility": -0.1}, "volatility must be at least 0 and below 1"),
        ({"volatility": 1.0}, "volatility must be at least 0 and below 1"),
        ({"volatility": float("nan")}, "volatility must be at least 0 and below 1"),
        ({"update_probability": 0.0}, "update_probability must be above 0 and at most 1"),
        ({"update_probability": float("nan")}, "update_probability must be above 0 and at most 1"),
        ({"trade_probability": 1.5}, "trade_probability must be between 0 and 1"),
        (
            {"reference_prices": {"SIM:X": Decimal(0)}},
            "the reference price for 'SIM:X' must be a positive number",
        ),
        (
            {"reference_prices": {"SIM:X": Decimal("NaN")}},
            "the reference price for 'SIM:X' must be a positive number",
        ),
    ],
)
def test_invalid_parameters_are_rejected(options: dict[str, Any], message: str) -> None:
    with pytest.raises(ValueError, match=f"^{re.escape(message)}$"):
        SimulatedMarket(**options)
