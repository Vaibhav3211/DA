from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

import pytest

from app.domain.enums import EventType, Provider
from app.domain.models import ProviderTick
from app.providers.validation import tick_problem

RECEIVED = datetime(2026, 1, 5, 4, 0, tzinfo=UTC)
LIMIT = timedelta(seconds=30)


def quote(**fields: Any) -> ProviderTick:
    """Built without validation, as mappers on the hot path may produce values pydantic would reject."""
    plain = ProviderTick(
        provider=Provider.SIMULATOR,
        account_id=None,
        provider_token="SIM:ALPHA",
        event_type=EventType.QUOTE,
        received_at=RECEIVED,
        last_price=Decimal("100"),
    )
    return plain.model_copy(update=fields)


@pytest.mark.parametrize(
    ("fields", "problem"),
    [
        ({"last_price": Decimal(0)}, "last_price is not a positive number"),
        ({"bid": Decimal(-1)}, "bid is not a positive number"),
        ({"ask": Decimal("NaN")}, "ask is not a positive number"),
        ({"high_price": Decimal("Infinity")}, "high_price is not a positive number"),
        ({"volume": -1}, "volume is negative"),
        ({"open_interest": -5}, "open_interest is negative"),
        ({"high_price": Decimal(99), "low_price": Decimal(100)}, "high_price is below low_price"),
        (
            {"source_timestamp": RECEIVED + timedelta(seconds=31)},
            "source_timestamp is 31s ahead of the receive time",
        ),
        (
            {"provider_timestamp": RECEIVED + timedelta(minutes=5)},
            "provider_timestamp is 300s ahead of the receive time",
        ),
    ],
)
def test_implausible_ticks_are_explained(fields: dict[str, Any], problem: str) -> None:
    assert tick_problem(quote(**fields), max_future=LIMIT) == problem


def test_plausible_ticks_pass() -> None:
    tick = quote(
        volume=0,
        high_price=Decimal(100),
        low_price=Decimal(100),
        source_timestamp=RECEIVED + LIMIT,  # small clock differences are tolerated
        provider_timestamp=RECEIVED - timedelta(days=1),  # old data is a freshness concern, not invalid
    )

    assert tick_problem(tick, max_future=LIMIT) is None
    assert tick_problem(quote(last_price=None), max_future=LIMIT) is None
