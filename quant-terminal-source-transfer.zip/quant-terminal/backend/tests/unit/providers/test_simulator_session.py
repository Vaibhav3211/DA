"""SimulatorSession: a snapshot on subscribe, ticks on a timer, heartbeats when nothing changed."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from decimal import Decimal
from uuid import UUID

import pytest

from app.domain.enums import SubscriptionMode
from app.providers.errors import ProviderUnavailableError
from app.providers.simulator.instruments import REFERENCE_PRICES
from app.providers.simulator.market import SimulatedMarket
from app.providers.simulator.session import SIMULATED_NOTICE, SimulatorSession
from tests.unit.providers.listeners import RecordingListener
from tests.unit.providers.simulator_helpers import sim_instrument

ACCOUNT = UUID("00000000-0000-4000-8000-000000000052")
NOW = datetime(2026, 1, 5, 9, 0, tzinfo=UTC)
NOT_CONNECTED = r"^the simulator stream is not connected$"


def session(*, trade_probability: float = 1.0, interval: float = 0.01) -> SimulatorSession:
    market = SimulatedMarket(
        seed=1,
        reference_prices=REFERENCE_PRICES,
        update_probability=1.0,
        trade_probability=trade_probability,
    )
    return SimulatorSession(market=market, account_id=ACCOUNT, interval=interval, clock=lambda: NOW)


async def test_open_announces_synthetic_data_and_is_single_use() -> None:
    stream = session()
    listener = RecordingListener()
    await stream.open(listener)
    assert listener.notices == [(SIMULATED_NOTICE, False)]
    with pytest.raises(RuntimeError, match="can only be opened once"):
        await stream.open(RecordingListener())
    await stream.close()


async def test_calls_need_an_open_session() -> None:
    unopened = session()
    await unopened.subscribe([])
    await unopened.unsubscribe([])
    with pytest.raises(ProviderUnavailableError, match=NOT_CONNECTED):
        await unopened.subscribe([sim_instrument()])
    with pytest.raises(ProviderUnavailableError, match=NOT_CONNECTED):
        await unopened.unsubscribe([sim_instrument()])
    with pytest.raises(ProviderUnavailableError, match=NOT_CONNECTED):
        await unopened.run()

    closed = session()
    await closed.open(RecordingListener())
    await closed.close()
    await closed.close()  # idempotent
    with pytest.raises(ProviderUnavailableError, match=NOT_CONNECTED):
        await closed.subscribe([sim_instrument()])
    with pytest.raises(ProviderUnavailableError, match=NOT_CONNECTED):
        await closed.run()


async def test_subscriptions_get_a_snapshot_then_streamed_ticks() -> None:
    stream = session()
    listener = RecordingListener()
    alpha = sim_instrument("ALPHA", SubscriptionMode.FULL)
    index = sim_instrument("SIM50", index=True)
    await stream.open(listener)
    await stream.subscribe([alpha, index])
    snapshot = listener.tick_batches[0]
    assert [(tick.provider_token, tick.last_price) for tick in snapshot] == [
        ("SIM:ALPHA", Decimal("2450.00")),
        ("SIM:SIM50", Decimal("22000.00")),
    ]
    assert {(tick.account_id, tick.received_at) for tick in snapshot} == {(ACCOUNT, NOW)}

    runner = asyncio.create_task(stream.run())
    try:
        await listener.wait_until(lambda: len(listener.tick_batches) >= 4)
        await stream.unsubscribe([alpha])
        unsubscribed_at = len(listener.tick_batches)
        await listener.wait_until(lambda: len(listener.tick_batches) >= unsubscribed_at + 3)
    finally:
        await stream.close()
        await asyncio.wait_for(runner, timeout=5)  # a clean close ends run() without an error

    streamed = listener.tick_batches[1:unsubscribed_at]
    assert {tuple(tick.provider_token for tick in batch) for batch in streamed} == {
        ("SIM:ALPHA", "SIM:SIM50")
    }
    after = listener.tick_batches[unsubscribed_at:]
    assert {tuple(tick.provider_token for tick in batch) for batch in after} == {("SIM:SIM50",)}
    assert listener.heartbeats == 0


async def test_rounds_without_changes_send_heartbeats() -> None:
    # An LTP subscriber of a stock that never trades sees no changes at all.
    stream = session(trade_probability=0.0)
    listener = RecordingListener()
    await stream.open(listener)
    await stream.subscribe([sim_instrument("GOLF", SubscriptionMode.LTP)])
    runner = asyncio.create_task(stream.run())
    try:
        await listener.wait_until(lambda: listener.heartbeats >= 3)
    finally:
        await stream.close()
        await asyncio.wait_for(runner, timeout=5)
    assert len(listener.tick_batches) == 1  # only the subscription snapshot


@pytest.mark.parametrize("interval", [0.0, -1.0, float("nan"), float("inf")])
def test_the_interval_must_be_a_positive_number(interval: float) -> None:
    with pytest.raises(ValueError, match="must be a positive number of seconds"):
        session(interval=interval)
