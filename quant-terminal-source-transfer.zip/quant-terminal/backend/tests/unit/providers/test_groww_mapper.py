"""Groww feed messages and REST snapshots mapped to ``ProviderTick``."""

from __future__ import annotations

import math
import warnings
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any
from uuid import uuid4

import pytest

from app.domain.enums import EventType, Provider, Segment, VolumeSemantics
from app.domain.models import DepthLevel, MarketDepth, ProviderTick
from app.providers.base import payload_digest
from app.providers.groww.exceptions import GrowwPayloadError
from app.providers.groww.mapper import feed_message_to_tick, rest_ltp_to_tick, rest_quote_to_tick
from app.providers.groww.proto import (
    BookLevel,
    FeedMessage,
    IndexValue,
    LivePoint,
    LivePrice,
    MarketDepthPoint,
)
from app.providers.groww.topics import FeedKind
from tests.unit.providers.groww_frames import TS_MILLIS

ACCOUNT = uuid4()
NOW = datetime(2026, 1, 5, 4, 15, 31, tzinfo=UTC)
PROVIDER_TIME = datetime(2026, 1, 5, 4, 15, 30, tzinfo=UTC)  # TS_MILLIS
RAW = b"\x0a\x08RELIANCE"
CASH_TOKEN = "NSE|CASH|2885"


def feed_tick(
    point: LivePoint | None,
    *,
    kind: FeedKind = FeedKind.PRICE,
    segment: Segment = Segment.CASH,
    token: str = CASH_TOKEN,
    volume_is_cumulative: bool = False,
) -> ProviderTick | None:
    tick = feed_message_to_tick(
        FeedMessage("RELIANCE", 0, 1, point),
        kind=kind,
        provider_token=token,
        segment=segment,
        raw=RAW,
        account_id=ACCOUNT,
        received_at=NOW,
        volume_is_cumulative=volume_is_cumulative,
    )
    if tick is not None:
        # Feed ticks skip validation (model_construct); the mapped values must still be valid.
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            assert ProviderTick.model_validate(tick.model_dump()) == tick
    return tick


def expected_tick(event_type: EventType, *, token: str = CASH_TOKEN, **fields: Any) -> ProviderTick:
    return ProviderTick(
        provider=Provider.GROWW,
        account_id=ACCOUNT,
        provider_token=token,
        event_type=event_type,
        received_at=NOW,
        raw_payload_hash=payload_digest(RAW),
        **fields,
    )


FULL_PRICE = LivePrice(
    ts_in_millis=TS_MILLIS,
    open=1500.5,
    high=1525.0,
    low=1490.25,
    close=1495.0,
    volume=1_234_567.0,
    value=1.85e9,
    bid_qty=300.0,
    offer_qty=450.0,
    avg_price=1510.75,
    high_price_range=1644.5,
    low_price_range=1345.5,
    ltp=1512.4,
    open_interest=98_765.0,
    low_trade_range=1400.0,
    high_trade_range=1600.0,
)


# ---- feed --------------------------------------------------------------------------------------


def test_last_price_only_is_an_ltp_tick() -> None:
    assert feed_tick(LivePrice(ts_in_millis=TS_MILLIS, ltp=1512.4)) == expected_tick(
        EventType.LTP, last_price=Decimal("1512.4"), provider_timestamp=PROVIDER_TIME
    )


def test_cash_live_price_is_a_quote_without_volume_or_open_interest() -> None:
    assert feed_tick(FULL_PRICE) == expected_tick(
        EventType.QUOTE,
        last_price=Decimal("1512.4"),
        provider_timestamp=PROVIDER_TIME,
        open_price=Decimal("1500.5"),
        high_price=Decimal("1525"),
        low_price=Decimal("1490.25"),
        previous_close=Decimal("1495"),
        average_price=Decimal("1510.75"),
        bid_quantity=300,
        ask_quantity=450,
    )


def test_fno_live_price_adds_open_interest_and_confirmed_cumulative_volume() -> None:
    tick = feed_tick(FULL_PRICE, segment=Segment.FNO, token="NSE|FNO|35001", volume_is_cumulative=True)
    assert tick is not None
    assert (tick.event_type, tick.open_interest) == (EventType.QUOTE, 98_765)
    assert (tick.volume, tick.volume_semantics) == (1_234_567, VolumeSemantics.CUMULATIVE_DAY)
    assert (tick.bid, tick.ask) == (None, None)  # the price feed carries quantities only


def test_zero_volume_stays_unavailable_even_when_cumulative() -> None:
    tick = feed_tick(LivePrice(ltp=10.5), volume_is_cumulative=True)
    assert tick is not None
    assert (tick.event_type, tick.volume, tick.volume_semantics) == (
        EventType.LTP,
        None,
        VolumeSemantics.UNAVAILABLE,
    )


def test_quote_values_without_a_last_price() -> None:
    assert feed_tick(LivePrice(close=1495.0, bid_qty=10.0)) == expected_tick(
        EventType.QUOTE, previous_close=Decimal("1495"), bid_quantity=10
    )


def test_absent_and_invalid_values_become_none() -> None:
    point = LivePrice(
        ltp=1512.4, open=0.0, high=-1.0, low=math.nan, close=math.inf, bid_qty=1e19, offer_qty=-2.0
    )
    assert feed_tick(point) == expected_tick(EventType.LTP, last_price=Decimal("1512.4"))


@pytest.mark.parametrize("millis", [0.0, -1.0, math.nan, math.inf, 1e20])
def test_unusable_provider_timestamps_are_dropped(millis: float) -> None:
    tick = feed_tick(LivePrice(ts_in_millis=millis, ltp=100.0))
    assert tick is not None
    assert tick.provider_timestamp is None


def test_index_value() -> None:
    tick = feed_tick(
        IndexValue(TS_MILLIS, 24_350.65), kind=FeedKind.INDEX, segment=Segment.INDEX, token="NSE|INDEX|NIFTY"
    )
    assert tick == expected_tick(
        EventType.INDEX_VALUE,
        token="NSE|INDEX|NIFTY",
        last_price=Decimal("24350.65"),
        provider_timestamp=PROVIDER_TIME,
    )


def test_market_depth_is_sorted_best_first_and_sets_the_touch() -> None:
    point = MarketDepthPoint(
        TS_MILLIS,
        buy_book={
            0: BookLevel(1512.2, 40),
            1: BookLevel(1512.3, 10),
            2: BookLevel(0, 0),
            3: BookLevel(1512.1, 0),
        },
        sell_book={0: BookLevel(1512.6, 30), 1: BookLevel(1512.5, 25), 2: BookLevel(math.nan, 5)},
    )
    assert feed_tick(point, kind=FeedKind.DEPTH) == expected_tick(
        EventType.DEPTH,
        provider_timestamp=PROVIDER_TIME,
        market_depth=MarketDepth(
            bids=(
                DepthLevel(price=Decimal("1512.3"), quantity=10),
                DepthLevel(price=Decimal("1512.2"), quantity=40),
            ),
            asks=(
                DepthLevel(price=Decimal("1512.5"), quantity=25),
                DepthLevel(price=Decimal("1512.6"), quantity=30),
            ),
        ),
        bid=Decimal("1512.3"),
        bid_quantity=10,
        ask=Decimal("1512.5"),
        ask_quantity=25,
    )


def test_one_sided_and_empty_books() -> None:
    sells_only = feed_tick(MarketDepthPoint(0.0, {}, {0: BookLevel(99.5, 3)}), kind=FeedKind.DEPTH)
    assert sells_only == expected_tick(
        EventType.DEPTH,
        market_depth=MarketDepth(asks=(DepthLevel(price=Decimal("99.5"), quantity=3),)),
        ask=Decimal("99.5"),
        ask_quantity=3,
    )
    # A timestamped empty book is news (the book emptied); an untimestamped one carries nothing.
    assert feed_tick(MarketDepthPoint(TS_MILLIS, {}, {}), kind=FeedKind.DEPTH) == expected_tick(
        EventType.DEPTH, market_depth=MarketDepth(), provider_timestamp=PROVIDER_TIME
    )


@pytest.mark.parametrize(
    ("point", "kind"),
    [
        (None, FeedKind.PRICE),
        (LivePrice(), FeedKind.PRICE),
        (LivePrice(ts_in_millis=TS_MILLIS), FeedKind.PRICE),
        (
            LivePrice(ltp=-1.0, open=math.nan, close=0.0, bid_qty=-5.0, volume=5.0, open_interest=7.0),
            FeedKind.PRICE,
        ),
        (IndexValue(TS_MILLIS, 0.0), FeedKind.INDEX),
        (IndexValue(TS_MILLIS, -1.5), FeedKind.INDEX),
        (IndexValue(TS_MILLIS, math.inf), FeedKind.INDEX),
        (MarketDepthPoint(0.0, {}, {}), FeedKind.DEPTH),
        (MarketDepthPoint(0.0, {0: BookLevel()}, {1: BookLevel(0.0, 5.0)}), FeedKind.DEPTH),
    ],
)
def test_points_without_usable_values_produce_no_tick(point: LivePoint | None, kind: FeedKind) -> None:
    assert feed_tick(point, kind=kind) is None


@pytest.mark.parametrize(
    ("point", "kind", "message"),
    [
        (IndexValue(value=1.0), FeedKind.PRICE, "the price feed delivered a IndexValue payload"),
        (LivePrice(ltp=1.0), FeedKind.INDEX, "the index feed delivered a LivePrice payload"),
        (LivePrice(ltp=1.0), FeedKind.DEPTH, "the depth feed delivered a LivePrice payload"),
        (
            MarketDepthPoint(TS_MILLIS, {}, {}),
            FeedKind.PRICE,
            "the price feed delivered a MarketDepthPoint payload",
        ),
    ],
)
def test_payloads_from_the_wrong_feed_are_rejected(point: LivePoint, kind: FeedKind, message: str) -> None:
    with pytest.raises(GrowwPayloadError) as excinfo:
        feed_tick(point, kind=kind)
    assert excinfo.value.message == message


# ---- REST snapshots ----------------------------------------------------------------------------

QUOTE: dict[str, Any] = {
    "average_price": 1510.75,
    "bid_quantity": 300,
    "bid_price": 1512.3,
    "day_change": 17.4,
    "day_change_perc": 1.16,
    "upper_circuit_limit": 1644.5,
    "lower_circuit_limit": 1345.5,
    "ohlc": {"open": 1500.5, "high": 1525, "low": 1490.25, "close": 1495},
    "depth": {
        "buy": [{"price": 1512.2, "quantity": 40}, {"price": 1512.3, "quantity": 300}],
        "sell": [{"price": 1512.6, "quantity": 30}, {"price": 1512.5, "quantity": 450}],
    },
    "high_trade_range": None,
    "implied_volatility": None,
    "last_trade_quantity": 5,
    "last_trade_time": 1_767_586_529_000,
    "low_trade_range": None,
    "last_price": 1512.4,
    "market_cap": None,
    "offer_price": 1512.5,
    "offer_quantity": 450,
    "oi_day_change": 0,
    "oi_day_change_percentage": 0,
    "open_interest": 98_765,
    "previous_open_interest": None,
    "total_buy_quantity": 120_000,
    "total_sell_quantity": 95_000,
    "volume": 1_234_567,
    "week_52_high": 1608.8,
    "week_52_low": 1114.85,
}


def quote_tick(
    payload: dict[str, Any], *, segment: Segment = Segment.CASH, token: str = CASH_TOKEN
) -> ProviderTick:
    return rest_quote_to_tick(
        payload, provider_token=token, segment=segment, account_id=ACCOUNT, received_at=NOW
    )


def test_rest_quote() -> None:
    assert quote_tick(QUOTE) == ProviderTick(
        provider=Provider.GROWW,
        account_id=ACCOUNT,
        provider_token=CASH_TOKEN,
        event_type=EventType.QUOTE,
        received_at=NOW,
        last_price=Decimal("1512.4"),
        open_price=Decimal("1500.5"),
        high_price=Decimal("1525"),
        low_price=Decimal("1490.25"),
        previous_close=Decimal("1495"),
        average_price=Decimal("1510.75"),
        last_quantity=5,
        total_buy_quantity=120_000,
        total_sell_quantity=95_000,
        last_trade_time=datetime(2026, 1, 5, 4, 15, 29, tzinfo=UTC),
        bid=Decimal("1512.3"),
        bid_quantity=300,
        ask=Decimal("1512.5"),
        ask_quantity=450,
        volume=1_234_567,
        volume_semantics=VolumeSemantics.CUMULATIVE_DAY,
        market_depth=MarketDepth(
            bids=(
                DepthLevel(price=Decimal("1512.3"), quantity=300),
                DepthLevel(price=Decimal("1512.2"), quantity=40),
            ),
            asks=(
                DepthLevel(price=Decimal("1512.5"), quantity=450),
                DepthLevel(price=Decimal("1512.6"), quantity=30),
            ),
        ),
    )


def test_rest_quote_open_interest_is_fno_only() -> None:
    assert quote_tick(QUOTE, segment=Segment.FNO, token="NSE|FNO|35001").open_interest == 98_765
    assert quote_tick(QUOTE).open_interest is None


def test_rest_quote_touch_falls_back_to_the_depth_as_a_price_quantity_pair() -> None:
    payload = {key: value for key, value in QUOTE.items() if key not in ("bid_price", "offer_price")}
    payload.update(bid_quantity=7, offer_quantity=None)
    tick = quote_tick(payload)
    assert (tick.bid, tick.bid_quantity, tick.ask, tick.ask_quantity) == (
        Decimal("1512.3"),
        300,
        Decimal("1512.5"),
        450,
    )


def test_rest_quote_event_types() -> None:
    assert quote_tick({"last_price": 100}).event_type is EventType.LTP
    assert quote_tick({"last_price": 100, "volume": 5}).event_type is EventType.QUOTE
    index = quote_tick({"last_price": 24_350.65, "ohlc": {"close": 24_300}}, segment=Segment.INDEX)
    assert (index.event_type, index.last_price, index.previous_close) == (
        EventType.INDEX_VALUE,
        Decimal("24350.65"),
        Decimal("24300"),
    )


def test_rest_quote_values_are_read_tolerantly() -> None:
    tick = quote_tick(
        {
            "last_price": "1512.40",
            "average_price": True,
            "ohlc": [1, 2, 3, 4],
            "bid_price": "abc",
            "offer_price": "Infinity",
            "bid_quantity": 2**70,
            "offer_quantity": 1e30,
            "total_buy_quantity": "5",
            "total_sell_quantity": 7.0,
            "last_trade_quantity": False,
            "last_trade_time": 10**400,
            "volume": -1,
            "depth": {
                "buy": [{"price": 99, "quantity": 1}, "level", {"price": 98}, {"price": -1, "quantity": 5}],
                "sell": {"price": 101, "quantity": 1},
            },
        }
    )
    assert tick == ProviderTick(
        provider=Provider.GROWW,
        account_id=ACCOUNT,
        provider_token=CASH_TOKEN,
        event_type=EventType.QUOTE,
        received_at=NOW,
        last_price=Decimal("1512.40"),
        total_sell_quantity=7,
        bid=Decimal("99"),
        bid_quantity=1,
        market_depth=MarketDepth(bids=(DepthLevel(price=Decimal("99"), quantity=1),)),
    )


@pytest.mark.parametrize("value", [True, -5, math.nan, "soon"])
def test_unusable_last_trade_times_are_dropped(value: object) -> None:
    assert quote_tick({"last_price": 1, "last_trade_time": value}).last_trade_time is None


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {
            "last_price": 0,
            "volume": 0,
            "ohlc": {"open": None},
            "depth": {"buy": [], "sell": []},
            "open_interest": 0,
        },
        {"last_price": None, "status": "SUCCESS"},
    ],
)
@pytest.mark.parametrize("segment", [Segment.CASH, Segment.FNO])
def test_rest_quotes_without_usable_values_are_rejected(payload: dict[str, Any], segment: Segment) -> None:
    with pytest.raises(GrowwPayloadError, match="the Groww quote has no usable values"):
        quote_tick(payload, segment=segment)


@pytest.mark.parametrize(
    ("value", "segment", "event_type", "price"),
    [
        (1512.4, Segment.CASH, EventType.LTP, Decimal("1512.4")),
        (24_350, Segment.INDEX, EventType.INDEX_VALUE, Decimal("24350")),
        ("101.05", Segment.FNO, EventType.LTP, Decimal("101.05")),
    ],
)
def test_rest_ltp(value: object, segment: Segment, event_type: EventType, price: Decimal) -> None:
    tick = rest_ltp_to_tick(
        value, provider_token=CASH_TOKEN, segment=segment, account_id=None, received_at=NOW
    )
    assert (tick.event_type, tick.last_price, tick.account_id, tick.provider) == (
        event_type,
        price,
        None,
        Provider.GROWW,
    )


@pytest.mark.parametrize("value", [None, 0, -1.5, True, "x", math.nan, math.inf, {"ltp": 1}, [1]])
def test_rest_ltp_without_a_usable_price_is_rejected(value: object) -> None:
    with pytest.raises(GrowwPayloadError, match="the Groww LTP response has no usable price"):
        rest_ltp_to_tick(
            value, provider_token=CASH_TOKEN, segment=Segment.CASH, account_id=None, received_at=NOW
        )
