"""A loopback stand-in for Groww's live feed (nothing here contacts Groww).

It serves the feed-token REST endpoint (through ``httpx.MockTransport``) and a NATS-over-WebSocket
server implementing what nats-py 2.16 uses: INFO with a nonce, CONNECT with a user JWT and a nonce
signature (verified against the NKEY public key of the token request), PING/PONG, SUB/UNSUB and MSG.
The handler records what it sees and never asserts; tests inspect the recorded state.
"""

from __future__ import annotations

import asyncio
import base64
import json
import secrets
from collections.abc import AsyncIterator, Callable, Collection, Mapping
from contextlib import asynccontextmanager, suppress
from http import HTTPStatus
from typing import Any

import httpx
import nacl.exceptions
import nacl.signing
from websockets.asyncio.server import ServerConnection, serve
from websockets.exceptions import ConnectionClosed
from websockets.http11 import Request, Response

from app.providers.groww.constants import SOCKET_TOKEN_PATH

# Unroutable on purpose: requests must go through the mock transport, never a socket.
API_BASE_URL = "http://127.0.0.1:9/v1"
FEED_JWT = "eyJ0eXAiOiJKV1QifQ.eyJzdWIiOiJ0ZXN0In0.c2lnbmF0dXJl"


class FakeGroww:
    def __init__(
        self,
        access_token: str,
        *,
        refuse: Collection[str] = (),
        reject_connect: bool = False,
        send_info: bool = True,
        handshake_status: HTTPStatus | None = None,
    ) -> None:
        self.access_token = access_token
        self.refuse = frozenset(refuse)
        self.reject_connect = reject_connect
        self.send_info = send_info
        self.handshake_status = handshake_status
        self.answer_pings = True
        self.token_requests: list[httpx.Request] = []
        self.socket_keys: list[str] = []
        self.handshakes = 0
        self.disconnects = 0  # WebSocket connections that have ended, whichever side closed them
        self.connect_options: list[dict[str, Any]] = []
        self.connects: list[bool] = []  # whether each CONNECT carried a valid JWT and signature
        self.pings = 0
        self.sub_commands: list[str] = []  # every SUB subject, in order
        self.subscriptions: dict[str, str] = {}  # live subscriptions: subject -> sid
        self.refused: list[str] = []
        self.unsubscribed: list[str] = []
        self._sids: dict[str, str] = {}
        self._connection: ServerConnection | None = None
        self._changed = asyncio.Event()

    # -- REST -------------------------------------------------------------------------------------

    def rest(self, request: httpx.Request) -> httpx.Response:
        self.token_requests.append(request)
        self._changed.set()
        if request.method != "POST" or request.url.path != "/v1" + SOCKET_TOKEN_PATH:
            return _failure(404, "GA404", "not found")
        if request.headers.get("Authorization") != f"Bearer {self.access_token}":
            return _failure(401, "GA005", "invalid token")
        self.socket_keys.append(str(json.loads(request.content).get("socketKey")))
        return httpx.Response(200, json={"status": "SUCCESS", "payload": {"token": FEED_JWT}})

    # -- NATS over WebSocket ----------------------------------------------------------------------

    @asynccontextmanager
    async def server(self) -> AsyncIterator[str]:
        def process_request(connection: ServerConnection, _request: Request) -> Response | None:
            self.handshakes += 1
            self._changed.set()
            if self.handshake_status is None:
                return None
            return connection.respond(self.handshake_status, "refused\n")

        async with serve(self._handle, "127.0.0.1", 0, process_request=process_request) as server:
            port = server.sockets[0].getsockname()[1]
            yield f"ws://127.0.0.1:{port}"

    async def publish(self, subject: str, payload: bytes, *, sid: str | None = None) -> None:
        sid = self.subscriptions[subject] if sid is None else sid
        await self.send_raw(f"MSG {subject} {sid} {len(payload)}\r\n".encode() + payload + b"\r\n")

    async def send_raw(self, data: bytes) -> None:
        if self._connection is None:
            raise RuntimeError("no client is connected")
        await self._connection.send(data)

    async def close(self) -> None:
        if self._connection is not None:
            await self._connection.close()

    async def wait_until(self, predicate: Callable[[], bool]) -> None:
        async with asyncio.timeout(5):
            while not predicate():
                self._changed.clear()
                await self._changed.wait()

    async def _handle(self, connection: ServerConnection) -> None:
        try:
            await self._converse(connection)
        finally:
            self.disconnects += 1
            self._changed.set()

    async def _converse(self, connection: ServerConnection) -> None:
        self._connection = connection
        nonce = secrets.token_urlsafe(16)
        authorized = False
        buffer = b""
        with suppress(ConnectionClosed):
            if self.send_info:
                info = {
                    "server_id": "FAKE",
                    "version": "2.10.0",
                    "proto": 1,
                    "headers": True,
                    "max_payload": 1_048_576,
                    "auth_required": True,
                    "nonce": nonce,
                }
                await connection.send(b"INFO " + json.dumps(info).encode() + b"\r\n")
            async for message in connection:
                buffer += message if isinstance(message, bytes) else message.encode()
                while b"\r\n" in buffer:
                    line, buffer = buffer.split(b"\r\n", 1)
                    op, _, rest = line.decode().partition(" ")
                    if op == "CONNECT":
                        options = json.loads(rest)
                        authorized = self._verify(options, nonce)
                        self.connect_options.append(options)
                        self.connects.append(authorized)
                    elif op == "PING":
                        if not authorized:
                            await connection.send(b"-ERR 'Authorization Violation'\r\n")
                            await connection.close()
                            return
                        self.pings += 1
                        if self.answer_pings:
                            await connection.send(b"PONG\r\n")
                    elif op == "SUB":
                        await self._subscribe(connection, rest.split())
                    elif op == "UNSUB":
                        subject = self._sids.pop(rest.split()[0], None)
                        if subject is not None:
                            self.subscriptions.pop(subject, None)
                            self.unsubscribed.append(subject)
                    self._changed.set()

    async def _subscribe(self, connection: ServerConnection, parts: list[str]) -> None:
        subject, sid = parts[0], parts[-1]  # SUB <subject> [queue group] <sid>
        self.sub_commands.append(subject)
        if subject in self.refuse:
            self.refused.append(subject)
            await connection.send(
                f"-ERR 'Permissions Violation for Subscription to \"{subject}\"'\r\n".encode()
            )
            return
        self.subscriptions[subject] = sid
        self._sids[sid] = subject

    def _verify(self, options: Mapping[str, Any], nonce: str) -> bool:
        signature = options.get("sig")
        if self.reject_connect or not self.socket_keys or options.get("jwt") != FEED_JWT:
            return False
        if not isinstance(signature, str):
            return False
        public_key = self.socket_keys[-1]
        try:
            raw_key = base64.b32decode(public_key + "=" * (-len(public_key) % 8))
            raw_signature = base64.urlsafe_b64decode(
                signature.replace("+", "-").replace("/", "_") + "=" * (-len(signature) % 4)
            )
            nacl.signing.VerifyKey(raw_key[1:-2]).verify(nonce.encode(), raw_signature)
        except (nacl.exceptions.BadSignatureError, ValueError):
            return False
        return True


def _failure(status: int, code: str, message: str) -> httpx.Response:
    return httpx.Response(status, json={"status": "FAILURE", "error": {"code": code, "message": message}})
