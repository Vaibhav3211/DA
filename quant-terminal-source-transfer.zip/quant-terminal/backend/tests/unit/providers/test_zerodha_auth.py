from __future__ import annotations

from datetime import UTC, datetime
from urllib.parse import parse_qs, urlsplit

import pytest

from app.core.clock import IST
from app.core.errors import ValidationFailedError
from app.providers.errors import ProviderRequestRejectedError
from app.providers.zerodha.auth import (
    build_login_url,
    parse_ist_timestamp,
    parse_redirect,
    session_checksum,
    token_expiry,
)


def test_login_url_carries_the_state_back_through_redirect_params() -> None:
    url = build_login_url("https://login.test/connect/login", "kitekey123", "st/a+te=1&x")
    parts = urlsplit(url)
    query = parse_qs(parts.query)
    assert f"{parts.scheme}://{parts.netloc}{parts.path}" == "https://login.test/connect/login"
    assert query["v"] == ["3"]
    assert query["api_key"] == ["kitekey123"]
    assert parse_qs(query["redirect_params"][0]) == {"state": ["st/a+te=1&x"]}


def test_session_checksum_is_sha256_of_key_token_and_secret() -> None:
    assert (
        session_checksum("a", "b", "c") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    )


@pytest.mark.parametrize(
    "value",
    [
        "https://app.test/callback?request_token=AbCd1234EfGh&action=login&status=success&state=s1",
        "?request_token=AbCd1234EfGh&action=login&status=success&state=s1",
        " request_token=AbCd1234EfGh&action=login&status=success&state=s1 ",
    ],
)
def test_redirect_parsing(value: str) -> None:
    redirect = parse_redirect(value)
    assert (redirect.request_token, redirect.state, redirect.status, redirect.action) == (
        "AbCd1234EfGh",
        "s1",
        "success",
        "login",
    )
    assert "AbCd1234EfGh" not in repr(redirect)
    assert "s1" not in repr(redirect)


def test_redirect_without_status_or_state_is_accepted() -> None:
    redirect = parse_redirect("request_token=AbCd1234EfGh")
    assert (redirect.state, redirect.status) == (None, None)


@pytest.mark.parametrize(
    ("value", "error"),
    [
        ("status=cancelled&request_token=AbCd1234EfGh", ProviderRequestRejectedError),
        ("action=login&status=success", ValidationFailedError),
        ("request_token=&status=success", ValidationFailedError),
        ("request_token=short", ValidationFailedError),
        ("request_token=AbCd1234%27%3B--", ValidationFailedError),
        ("request_token=AbCd1234EfGh&request_token=Other1234567", ValidationFailedError),
        ("request_token=AbCd1234EfGh&state=a&state=b", ValidationFailedError),
    ],
)
def test_invalid_redirects_are_rejected(value: str, error: type[Exception]) -> None:
    with pytest.raises(error):
        parse_redirect(value)


@pytest.mark.parametrize(
    ("issued_ist", "expires_ist"),
    [
        (datetime(2026, 1, 5, 10, 0, tzinfo=IST), datetime(2026, 1, 6, 6, 0, tzinfo=IST)),
        (datetime(2026, 1, 5, 5, 59, 59, tzinfo=IST), datetime(2026, 1, 5, 6, 0, tzinfo=IST)),
        (datetime(2026, 1, 5, 6, 0, tzinfo=IST), datetime(2026, 1, 6, 6, 0, tzinfo=IST)),
        (datetime(2026, 1, 5, 23, 59, tzinfo=IST), datetime(2026, 1, 6, 6, 0, tzinfo=IST)),
    ],
)
def test_access_tokens_expire_at_the_next_0600_ist(issued_ist: datetime, expires_ist: datetime) -> None:
    expiry = token_expiry(issued_ist.astimezone(UTC))
    assert expiry == expires_ist
    assert expiry.tzinfo is UTC


def test_token_expiry_rejects_naive_datetimes() -> None:
    with pytest.raises(ValueError, match="naive"):
        token_expiry(datetime(2026, 1, 5, 10, 0))


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("2026-01-05 09:45:30", datetime(2026, 1, 5, 4, 15, 30, tzinfo=UTC)),
        ("2026-01-05T09:45:30", None),
        ("", None),
        (None, None),
        (1767586530, None),
    ],
)
def test_ist_timestamps(value: object, expected: datetime | None) -> None:
    assert parse_ist_timestamp(value) == expected
