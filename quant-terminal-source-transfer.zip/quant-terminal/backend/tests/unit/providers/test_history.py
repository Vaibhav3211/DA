"""Historical candles read from provider rows and downloaded window by window (no provider is contacted)."""

from __future__ import annotations

import math
import re
from collections.abc import Sequence
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo

import pytest

from app.domain.enums import CandleInterval, Provider, Segment
from app.providers.errors import ProviderProtocolError
from app.providers.history import (
    GROWW_HISTORY,
    KITE_HISTORY,
    HistoricalCandle,
    HistorySupport,
    date_windows,
    download,
    merge,
    parse_rows,
    parse_time,
)

IST = ZoneInfo("Asia/Kolkata")
OPEN = datetime(2026, 1, 5, 3, 45, tzinfo=UTC)  # 09:15 IST
STAMP = "2026-01-05T09:15:00+0530"


def candle(minute: int, close: str = "100") -> HistoricalCandle:
    price = Decimal(close)
    return HistoricalCandle(OPEN + timedelta(minutes=minute), price, price, price, price, None, None)


@pytest.mark.parametrize(
    "value",
    [
        STAMP,
        "2026-01-05T09:15:00+05:30",
        "2026-01-05T03:45:00Z",
        "2026-01-05 09:15:00",  # no offset: exchange-local time
        1767584700,
        1767584700.0,
        1767584700000,  # milliseconds
    ],
)
def test_timestamps_are_read_as_utc(value: object) -> None:
    assert parse_time(value, IST) == OPEN


@pytest.mark.parametrize("value", ["x", "", True, 0, -5, math.nan, None, [STAMP]])
def test_unreadable_timestamps_are_refused(value: object) -> None:
    with pytest.raises(ValueError, match="unreadable timestamp"):
        parse_time(value, IST)


def test_rows_become_candles_with_optional_volume_and_open_interest() -> None:
    rows = [
        [STAMP, 100, "101.5", 99.25, 100.5, 1200, 30],
        ["2026-01-05T09:16:00+0530", 100.5, 101, 100, 100.75],
        ["2026-01-05T09:17:00+0530", 100.75, 101, 100, 101, 900.0, None],
    ]

    candles = parse_rows(rows, provider=Provider.ZERODHA, zone=IST)

    assert candles == [
        HistoricalCandle(OPEN, Decimal(100), Decimal("101.5"), Decimal("99.25"), Decimal("100.5"), 1200, 30),
        HistoricalCandle(
            OPEN + timedelta(minutes=1),
            Decimal("100.5"),
            Decimal(101),
            Decimal(100),
            Decimal("100.75"),
            None,
            None,
        ),
        HistoricalCandle(
            OPEN + timedelta(minutes=2),
            Decimal("100.75"),
            Decimal(101),
            Decimal(100),
            Decimal(101),
            900,
            None,
        ),
    ]


@pytest.mark.parametrize(
    ("row", "problem"),
    [
        ("not a row", "expected [timestamp, open, high, low, close, volume, oi]"),
        ([STAMP, 1, 2, 1], "expected [timestamp, open, high, low, close, volume, oi]"),
        (["x", 1, 2, 1, 2], "unreadable timestamp 'x'"),
        ([STAMP, "abc", 2, 1, 2], "open 'abc' is not a number"),
        ([STAMP, True, 2, 1, 2], "open True is not a number"),
        ([STAMP, 1, 0, 1, 2], "high 0 is not a positive price"),
        ([STAMP, 1, 2, 1, "NaN"], "close 'NaN' is not a positive price"),
        ([STAMP, 1, 2, 1, 2, 1.5], "volume 1.5 is not a count"),
        ([STAMP, 1, 2, 1, 2, -3], "volume -3 is negative"),
        ([STAMP, 1, 2, 1, 2, 10, "x"], "open interest 'x' is not a count"),
    ],
)
def test_a_row_that_cannot_be_read_is_refused_with_its_position(row: object, problem: str) -> None:
    rows = [[STAMP, 1, 2, 1, 2], row]

    with pytest.raises(ProviderProtocolError) as caught:
        parse_rows(rows, provider=Provider.ZERODHA, zone=IST)

    assert str(caught.value) == f"ZERODHA historical candle 1 could not be read: {problem}"


def test_date_windows_cover_the_range_without_overlap() -> None:
    day = date(2026, 1, 1)

    assert date_windows(day, date(2026, 1, 10), 4) == [
        (day, date(2026, 1, 4)),
        (date(2026, 1, 5), date(2026, 1, 8)),
        (date(2026, 1, 9), date(2026, 1, 10)),
    ]
    assert date_windows(day, day, 4) == [(day, day)]
    assert date_windows(date(2026, 1, 2), day, 4) == []
    with pytest.raises(ValueError, match="max_days must be positive"):
        date_windows(day, day, 0)


def test_merge_keeps_the_first_candle_of_each_start_in_time_order() -> None:
    later, earlier, repeat = candle(1, "101"), candle(0), candle(1, "999")

    assert merge([later, earlier, repeat]) == ([earlier, later], 1)


async def test_a_download_is_split_into_windows_the_provider_accepts() -> None:
    calls: list[tuple[str, date, date]] = []
    boundary = "2026-01-30T15:29:00+0530"
    responses = {
        date(2026, 1, 1): [[boundary, 1, 1, 1, 1, 5], ["2026-01-02T09:15:00+0530", 1, 1, 1, 1, 5]],
        date(2026, 1, 31): [[boundary, 2, 2, 2, 2, 7], ["2026-02-02T09:15:00+0530", 3, 3, 3, 3, 5]],
    }

    async def fetch(name: str, first: date, last: date) -> Sequence[object]:
        calls.append((name, first, last))
        return responses[first]

    history = await download(KITE_HISTORY, CandleInterval.M1, date(2026, 1, 1), date(2026, 2, 15), IST, fetch)

    assert calls == [
        ("minute", date(2026, 1, 1), date(2026, 1, 30)),
        ("minute", date(2026, 1, 31), date(2026, 2, 15)),
    ]
    assert (history.requests, history.duplicates) == (2, 1)
    assert [(c.start.astimezone(IST).isoformat(), c.close) for c in history.candles] == [
        ("2026-01-02T09:15:00+05:30", Decimal(1)),
        ("2026-01-30T15:29:00+05:30", Decimal(1)),
        ("2026-02-02T09:15:00+05:30", Decimal(3)),
    ]


async def test_a_download_refuses_an_interval_the_provider_does_not_offer() -> None:
    async def fetch(name: str, first: date, last: date) -> Sequence[object]:
        raise AssertionError("nothing should be requested")

    with pytest.raises(ValueError, match=re.escape("ZERODHA has no 1s historical candles")):
        await download(KITE_HISTORY, CandleInterval.S1, date(2026, 1, 5), date(2026, 1, 5), IST, fetch)


@pytest.mark.parametrize(
    ("support", "segment", "interval", "problem"),
    [
        (
            GROWW_HISTORY,
            Segment.INDEX,
            CandleInterval.D1,
            "GROWW historical candles cover CASH, FNO instruments, not INDEX",
        ),
        (
            KITE_HISTORY,
            Segment.CASH,
            CandleInterval.S1,
            "ZERODHA historical candles come in 1m, 3m, 5m, 15m, 30m, 1h, 1d, not 1s",
        ),
        (KITE_HISTORY, Segment.INDEX, CandleInterval.D1, None),
    ],
)
def test_support_says_why_a_provider_cannot_supply_candles(
    support: HistorySupport, segment: Segment, interval: CandleInterval, problem: str | None
) -> None:
    assert support.problem(segment, interval) == problem
