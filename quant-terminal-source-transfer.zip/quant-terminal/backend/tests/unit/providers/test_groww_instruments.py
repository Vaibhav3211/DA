"""Groww instrument master parsing (synthetic CSV rows; nothing is downloaded)."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from app.domain.enums import Exchange, InstrumentType, OptionType, Provider, Segment
from app.domain.models import ProviderInstrumentRecord
from app.providers.errors import ProviderProtocolError
from app.providers.groww.instruments import parse_expiry, parse_instrument_dump

TODAY = date(2026, 1, 5)
HEADER = (
    "exchange,exchange_token,trading_symbol,groww_symbol,name,instrument_type,segment,series,isin,"
    "underlying_symbol,underlying_exchange_token,expiry_date,strike_price,lot_size,tick_size,"
    "freeze_quantity,is_reserved,buy_allowed,sell_allowed"
)
SUPPORTED = [
    "NSE,2885,RELIANCE,NSE-RELIANCE,Reliance Industries,EQ,CASH,EQ,INE002A01018,,,,,1,0.10,,0,1,1",
    "BSE,500325,RELIANCE,BSE-RELIANCE,Reliance Industries,EQ,CASH,A,INE002A01018,,,,,1,0.05,,0,1,1",
    "nse,1594,INFY,,Infosys,eq,cash,EQ,,,,,,1,0.05,,,,",
    "NSE,NIFTY,NIFTY,NSE-NIFTY,NIFTY 50,IDX,CASH,,,,,,,0,0,,0,0,0",
    "BSE,1,SENSEX,,,,INDICES,,,,,,,,,,,,",
    "NSE,35001,NIFTY26JANFUT,NSE-NIFTY-27Jan26-FUT,NIFTY,FUT,FNO,,,NIFTY,26000,2026-01-27,-0.01,75,0.10,1800,0,1,1",
    "NSE,35165,NIFTY2610624000CE,,NIFTY,CE,FNO,,,NIFTY,26000,06-Jan-2026,24000,75,0.05,1800,0,1,1",
    "BSE,1129100,SENSEX2610880000PE,,SENSEX,PE,FNO,,,SENSEX,1,08/01/2026,80000.5,20,0.05,,0,1,1",
    "NSE,35002,BANKNIFTY26JANFUT,,BANKNIFTY,FUT,FNO,,,,,2026-01-27T00:00:00,0,30.0,0.20,,,,",
    "NSE,99999,GOLDBEES,,Gold ETF,ETF,CASH,EQ,,,,,,1,0.01,,,,",
]
SKIPPED = [
    "MCX,1,CRUDEOIL26JANFUT,,CRUDEOIL,FUT,COMMODITY,,,CRUDEOIL,,2026-01-19,,100,1,,,,",
    "NSEIX,2,GIFTNIFTY,,,EQ,CASH,,,,,,,1,0.5,,,,",
    "NSE,7,NSETEST,,NSETEST,EQ,CASH,,,,,,,1,0.05,,,,",
    "BSE,8,ABC,,BSETEST LTD,EQ,CASH,,,,,,,1,0.05,,,,",
    "NSE,9,XYZ26JANFUT,,XYZ,FUT,FNO,,,nsetest,,2026-01-27,,1,0.05,,,,",
    "NSE,10,USDINR26JANFUT,,USDINR,FUT,CURRENCY,,,USDINR,,2026-01-28,,1000,0.0025,,,,",
    "NSE,12.5,DOTTED,,,EQ,CASH,,,,,,,1,0.05,,,,",
    "NSE,>,WILDCARD,,,EQ,CASH,,,,,,,1,0.05,,,,",
    "NSE,,EMPTYTOKEN,,,EQ,CASH,,,,,,,1,0.05,,,,",
    "NSE,11,,,,EQ,CASH,,,,,,,1,0.05,,,,",
    "NSE,12,BADTICK,,,EQ,CASH,,,,,,,1,abc,,,,",
    "NSE,13,NOEXPIRYFUT,,NIFTY,FUT,FNO,,,NIFTY,,,,75,0.1,,,,",
    "NSE,14,NOUNDERLYINGFUT,,,FUT,FNO,,,,,2026-01-27,,75,0.1,,,,",
    "NSE,15,NOSTRIKECE,,NIFTY,CE,FNO,,,NIFTY,,2026-01-06,0,75,0.05,,,,",
    "NSE,16,BADMONTHPE,,NIFTY,PE,FNO,,,NIFTY,,06-Foo-2026,24000,75,0.05,,,,",
    "NSE,17,BADLOT,,,EQ,CASH,,,,,,,1.5,0.05,,,,",
    "NSE,18,FARFUT,,NIFTY,FUT,FNO,,,NIFTY,,2040-01-01,,75,0.1,,,,",
    "NSE,2885,RELIANCE-DUP,,,EQ,CASH,,,,,,,1,0.05,,,,",
]


def dump(*rows: str, header: str = HEADER) -> bytes:
    return ("\n".join([header, *rows]) + "\n").encode()


@pytest.fixture(scope="module")
def records() -> dict[str, ProviderInstrumentRecord]:
    parsed = parse_instrument_dump(dump(*SUPPORTED, *SKIPPED), today=TODAY)
    assert parsed.provider is Provider.GROWW
    assert parsed.rows == len(SUPPORTED) + len(SKIPPED)
    assert parsed.skipped == {
        "unsupported_exchange": 2,
        "test_instrument": 3,
        "unsupported_segment": 1,
        "unsupported_token": 3,
        "invalid_row": 7,
        "implausible_expiry": 1,
        "duplicate_token": 1,
    }
    assert len(parsed.records) == len(SUPPORTED)
    return {record.provider_token: record for record in parsed.records}


def test_cash_equities(records: dict[str, ProviderInstrumentRecord]) -> None:
    assert records["NSE|CASH|2885"] == ProviderInstrumentRecord(
        provider=Provider.GROWW,
        provider_token="NSE|CASH|2885",
        exchange_token="2885",
        provider_symbol="RELIANCE",
        provider_exchange="NSE",
        provider_segment="CASH",
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        instrument_type=InstrumentType.EQUITY,
        name="Reliance Industries",
        lot_size=1,
        tick_size=Decimal("0.10"),
        isin="INE002A01018",
        metadata={"instrument_type": "EQ", "groww_symbol": "NSE-RELIANCE", "series": "EQ"},
    )
    assert (records["BSE|CASH|500325"].exchange, records["BSE|CASH|500325"].segment) == (
        Exchange.BSE,
        Segment.CASH,
    )
    infy = records["NSE|CASH|1594"]  # vocabulary is case-insensitive; raw values are kept
    assert (infy.exchange, infy.instrument_type) == (Exchange.NSE, InstrumentType.EQUITY)
    assert (infy.provider_exchange, infy.provider_segment, infy.isin) == ("nse", "cash", None)
    assert infy.metadata == {"instrument_type": "eq", "series": "EQ"}


def test_indices_are_not_tradable(records: dict[str, ProviderInstrumentRecord]) -> None:
    nifty, sensex = records["NSE|INDEX|NIFTY"], records["BSE|INDEX|1"]
    assert (nifty.segment, nifty.instrument_type, nifty.name) == (
        Segment.INDEX,
        InstrumentType.INDEX,
        "NIFTY 50",
    )
    assert (nifty.provider_segment, nifty.tick_size, nifty.lot_size) == ("CASH", None, None)
    assert not nifty.tradable
    assert (sensex.exchange, sensex.segment, sensex.name, sensex.metadata) == (
        Exchange.BSE,
        Segment.INDEX,
        "SENSEX",  # falls back to the symbol
        {},
    )


def test_futures(records: dict[str, ProviderInstrumentRecord]) -> None:
    nifty = records["NSE|FNO|35001"]
    assert (nifty.exchange, nifty.segment, nifty.instrument_type) == (
        Exchange.NSE,
        Segment.FNO,
        InstrumentType.FUTURE,
    )
    assert (nifty.underlying, nifty.expiry, nifty.strike, nifty.option_type, nifty.lot_size) == (
        "NIFTY",
        date(2026, 1, 27),
        None,  # the placeholder strike of a future is ignored
        None,
        75,
    )
    bank = records["NSE|FNO|35002"]
    assert (bank.underlying, bank.expiry, bank.lot_size) == ("BANKNIFTY", date(2026, 1, 27), 30)


def test_options(records: dict[str, ProviderInstrumentRecord]) -> None:
    call, put = records["NSE|FNO|35165"], records["BSE|FNO|1129100"]
    assert (call.instrument_type, call.option_type, call.strike, call.expiry) == (
        InstrumentType.OPTION,
        OptionType.CE,
        Decimal("24000"),
        date(2026, 1, 6),
    )
    assert (put.exchange, put.option_type, put.strike, put.expiry, put.lot_size) == (
        Exchange.BSE,
        OptionType.PE,
        Decimal("80000.5"),
        date(2026, 1, 8),
        20,
    )


def test_unknown_instrument_types_are_kept_as_other(records: dict[str, ProviderInstrumentRecord]) -> None:
    etf = records["NSE|CASH|99999"]
    assert (etf.instrument_type, etf.tradable, etf.expiry) == (InstrumentType.OTHER, True, None)
    assert etf.metadata == {"instrument_type": "ETF", "series": "EQ"}


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("", None),
        ("2026-01-27", date(2026, 1, 27)),
        ("2026-01-27T15:30:00", date(2026, 1, 27)),
        ("2026-01-27 15:30:00", date(2026, 1, 27)),
        ("27-01-2026", date(2026, 1, 27)),
        ("27/01/2026", date(2026, 1, 27)),
        ("27 Jan 2026", date(2026, 1, 27)),
        ("27-JAN-2026", date(2026, 1, 27)),
        ("7-1-2026", date(2026, 1, 7)),
    ],
)
def test_expiry_formats(value: str, expected: date | None) -> None:
    assert parse_expiry(value) == expected


@pytest.mark.parametrize(
    ("value", "message"),
    [
        ("27-Foo-2026", "unrecognised expiry month"),
        ("2026/01/27", "unrecognised expiry date"),
        ("tomorrow", "unrecognised expiry date"),
        ("\u0662\u0667-01-2026", "unrecognised expiry date"),
        ("31-02-2026", "day is out of range"),
        ("27-13-2026", "month must be in 1..12"),
    ],
)
def test_invalid_expiries(value: str, message: str) -> None:
    with pytest.raises(ValueError, match=message):
        parse_expiry(value)


def test_columns_are_found_by_name_with_bom_and_extra_cells() -> None:
    header = "exchange_token,exchange,trading_symbol,segment,instrument_type"
    data = "\ufeff".encode() + dump("2885,NSE,RELIANCE,CASH,EQ,surplus", header=header)
    [record] = parse_instrument_dump(data, today=TODAY).records
    assert (record.provider_token, record.provider_symbol, record.instrument_type) == (
        "NSE|CASH|2885",
        "RELIANCE",
        InstrumentType.EQUITY,
    )
    assert (record.tick_size, record.lot_size, record.isin, record.metadata) == (
        None,
        None,
        None,
        {"instrument_type": "EQ"},
    )


@pytest.mark.parametrize(
    ("data", "message"),
    [
        (
            dump(*SUPPORTED, header=HEADER.replace(",segment,", ",market_segment,")),
            "lacks column\\(s\\): segment",
        ),
        (dump(), "no usable instruments \\(0 rows\\)"),
        (dump(*SKIPPED[:-1]), "no usable instruments"),
        (b"", "lacks column"),
        (HEADER.encode() + b"\n\xff\xfe\n", "not UTF-8"),
    ],
)
def test_unusable_dumps_are_rejected(data: bytes, message: str) -> None:
    with pytest.raises(ProviderProtocolError, match=message):
        parse_instrument_dump(data, today=TODAY)
