"""What each live feed sends for an instrument by subscription mode, and why a consumer misses data."""

from __future__ import annotations

from collections.abc import Collection

import pytest

from app.domain.enums import DataRequirement, EventType, InstrumentType, Provider, Segment, SubscriptionMode
from app.providers.delivery import FeedDelivery, labels

LTP, QUOTE, FULL = SubscriptionMode.LTP, SubscriptionMode.QUOTE, SubscriptionMode.FULL
VOLUME, OI, DEPTH = DataRequirement.VOLUME, DataRequirement.OPEN_INTEREST, DataRequirement.MARKET_DEPTH
ZERODHA, GROWW, SIMULATOR = Provider.ZERODHA, Provider.GROWW, Provider.SIMULATOR
type Kind = tuple[Segment, InstrumentType]
EQUITY: Kind = (Segment.CASH, InstrumentType.EQUITY)
FUTURE: Kind = (Segment.FNO, InstrumentType.FUTURE)
COMMODITY_FUTURE: Kind = (Segment.COMMODITY, InstrumentType.FUTURE)
INDEX: Kind = (Segment.INDEX, InstrumentType.INDEX)
PLAIN = FeedDelivery()
CUMULATIVE = FeedDelivery(groww_volume_is_cumulative=True)


def shortfall(
    provider: Provider,
    mode: SubscriptionMode,
    kind: Kind,
    needs: Collection[DataRequirement],
    event_types: Collection[EventType] = (),
    *,
    candles: bool = True,
    feeds: FeedDelivery = PLAIN,
) -> str | None:
    segment, instrument_type = kind
    return feeds.shortfall(
        provider,
        mode,
        segment=segment,
        instrument_type=instrument_type,
        needs=needs,
        event_types=event_types,
        candles=candles,
    )


@pytest.mark.parametrize(
    ("provider", "mode", "kind", "expected"),
    [
        (ZERODHA, LTP, FUTURE, {EventType.LTP: ()}),
        (ZERODHA, LTP, INDEX, {EventType.LTP: ()}),
        (ZERODHA, QUOTE, EQUITY, {EventType.QUOTE: (VOLUME,)}),
        (ZERODHA, QUOTE, INDEX, {EventType.INDEX_VALUE: ()}),
        (ZERODHA, FULL, EQUITY, {EventType.QUOTE: (VOLUME, DEPTH)}),
        (ZERODHA, FULL, FUTURE, {EventType.QUOTE: (VOLUME, OI, DEPTH)}),
        (ZERODHA, FULL, COMMODITY_FUTURE, {EventType.QUOTE: (VOLUME, OI, DEPTH)}),
        (GROWW, LTP, EQUITY, {EventType.QUOTE: ()}),
        (GROWW, QUOTE, FUTURE, {EventType.QUOTE: (OI,)}),
        (GROWW, FULL, EQUITY, {EventType.QUOTE: (), EventType.DEPTH: (DEPTH,)}),
        (GROWW, FULL, INDEX, {EventType.INDEX_VALUE: ()}),
        (SIMULATOR, LTP, EQUITY, {EventType.LTP: ()}),
        (SIMULATOR, QUOTE, EQUITY, {EventType.QUOTE: (VOLUME,)}),
        (SIMULATOR, QUOTE, INDEX, {EventType.INDEX_VALUE: ()}),
        (SIMULATOR, FULL, FUTURE, {EventType.QUOTE: (VOLUME, DEPTH)}),
    ],
)
def test_each_feed_sends_these_events_with_this_data(
    provider: Provider,
    mode: SubscriptionMode,
    kind: Kind,
    expected: dict[EventType, tuple[DataRequirement, ...]],
) -> None:
    segment, instrument_type = kind
    delivery = PLAIN.of(provider, mode, segment=segment, instrument_type=instrument_type)

    assert dict(delivery.events) == {event_type: frozenset(data) for event_type, data in expected.items()}


def test_groww_quotes_carry_volume_only_when_it_is_cumulative() -> None:
    plain = PLAIN.of(GROWW, QUOTE, segment=Segment.CASH, instrument_type=InstrumentType.EQUITY)
    cumulative = CUMULATIVE.of(GROWW, QUOTE, segment=Segment.CASH, instrument_type=InstrumentType.EQUITY)

    assert plain.data == frozenset()
    assert cumulative.data == {VOLUME}


def test_candles_carry_the_feeds_volume_whatever_events_the_consumer_takes() -> None:
    delivery = PLAIN.of(ZERODHA, QUOTE, segment=Segment.CASH, instrument_type=InstrumentType.EQUITY)

    assert delivery.reaching((), candles=True) == {VOLUME}
    assert delivery.reaching((), candles=False) == frozenset()
    assert delivery.reaching((EventType.LTP,), candles=False) == frozenset()


@pytest.mark.parametrize(
    ("provider", "mode", "kind", "needs", "event_types", "feeds"),
    [
        (ZERODHA, QUOTE, EQUITY, (VOLUME,), (), PLAIN),
        (ZERODHA, FULL, FUTURE, (VOLUME, OI, DEPTH), (EventType.QUOTE,), PLAIN),
        (GROWW, QUOTE, EQUITY, (VOLUME,), (), CUMULATIVE),
        (GROWW, FULL, FUTURE, (OI, DEPTH), (EventType.QUOTE, EventType.DEPTH), PLAIN),
        (SIMULATOR, FULL, EQUITY, (VOLUME, DEPTH), (EventType.QUOTE,), PLAIN),
    ],
)
def test_no_shortfall_when_the_feed_sends_everything_needed(
    provider: Provider,
    mode: SubscriptionMode,
    kind: Kind,
    needs: tuple[DataRequirement, ...],
    event_types: tuple[EventType, ...],
    feeds: FeedDelivery,
) -> None:
    assert shortfall(provider, mode, kind, needs, event_types, feeds=feeds) is None


@pytest.mark.parametrize(
    ("provider", "mode", "kind", "needs", "event_types", "expected"),
    [
        (
            ZERODHA,
            QUOTE,
            FUTURE,
            (OI,),
            (EventType.QUOTE,),
            "it needs open interest, which it does not get from the ZERODHA feed in QUOTE mode: "
            "subscribe the instrument in FULL mode for open interest",
        ),
        (
            # Volume is fixed by QUOTE and depth by FULL: one subscription in FULL fixes both.
            ZERODHA,
            LTP,
            EQUITY,
            (VOLUME, DEPTH),
            (EventType.QUOTE,),
            "it needs traded volume and market depth, which it does not get from the ZERODHA feed in LTP "
            "mode: subscribe the instrument in FULL mode for traded volume and market depth",
        ),
        (
            ZERODHA,
            LTP,
            EQUITY,
            (OI, DEPTH),
            (EventType.QUOTE,),
            "it needs open interest and market depth, which it does not get from the ZERODHA feed in LTP "
            "mode: subscribe the instrument in FULL mode for market depth; only futures and options have "
            "open interest",
        ),
        (
            ZERODHA,
            FULL,
            INDEX,
            (VOLUME,),
            (),
            "it needs traded volume, which it does not get from the ZERODHA feed in FULL mode: "
            "indices have no traded volume",
        ),
        (
            ZERODHA,
            FULL,
            EQUITY,
            (OI,),
            (EventType.QUOTE,),
            "it needs open interest, which it does not get from the ZERODHA feed in FULL mode: "
            "only futures and options have open interest",
        ),
        (
            GROWW,
            QUOTE,
            EQUITY,
            (VOLUME,),
            (),
            "it needs traded volume, which it does not get from the GROWW feed in QUOTE mode: "
            "the GROWW feed's volume is used only when GROWW_FEED_VOLUME_IS_CUMULATIVE=true",
        ),
        (
            GROWW,
            FULL,
            EQUITY,
            (DEPTH,),
            (EventType.QUOTE,),
            "it needs market depth, which it does not get from the GROWW feed in FULL mode: "
            "the GROWW feed sends market depth only in DEPTH events, which it does not take",
        ),
        (
            GROWW,
            QUOTE,
            EQUITY,
            (DEPTH,),
            (EventType.QUOTE, EventType.DEPTH),
            "it needs market depth, which it does not get from the GROWW feed in QUOTE mode: "
            "subscribe the instrument in FULL mode for market depth",
        ),
        (
            SIMULATOR,
            FULL,
            FUTURE,
            (OI,),
            (EventType.QUOTE,),
            "it needs open interest, which it does not get from the SIMULATOR feed in FULL mode: "
            "the SIMULATOR feed does not send open interest for this instrument",
        ),
    ],
)
def test_a_shortfall_says_what_is_missing_and_why(
    provider: Provider,
    mode: SubscriptionMode,
    kind: Kind,
    needs: tuple[DataRequirement, ...],
    event_types: tuple[EventType, ...],
    expected: str,
) -> None:
    assert shortfall(provider, mode, kind, needs, event_types) == expected


def test_labels_follow_a_fixed_order() -> None:
    assert labels([DEPTH, VOLUME, OI]) == "traded volume, open interest and market depth"
    assert labels([DEPTH]) == "market depth"
    assert labels([]) == "nothing"
