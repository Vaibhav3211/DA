"""Groww feed session and adapter against a loopback NATS-over-WebSocket fake (Groww is never contacted)."""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Sequence
from datetime import UTC, datetime
from decimal import Decimal
from http import HTTPStatus
from typing import Any, cast
from uuid import uuid4

import aiohttp
import httpx
import pytest
from nats import errors as nats_errors

from app.core.config import Settings
from app.core.errors import AppError
from app.domain.enums import (
    ConnectionState,
    DataStatus,
    EventType,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
    SubscriptionMode,
    VolumeSemantics,
)
from app.domain.models import ProviderInstrument, ProviderTick
from app.providers.base import SessionCredentials
from app.providers.capabilities import default_capabilities
from app.providers.errors import (
    ProviderAuthRequiredError,
    ProviderRateLimitedError,
    ProviderUnavailableError,
    UnsupportedInstrumentError,
)
from app.providers.groww import adapter as adapter_module
from app.providers.groww import feed as feed_module
from app.providers.groww.adapter import GrowwAdapter
from app.providers.groww.constants import PENDING_MESSAGES_LIMIT
from app.providers.groww.feed import GrowwFeedSession, _connect_error
from tests.unit.providers.fake_groww import API_BASE_URL, FEED_JWT, FakeGroww
from tests.unit.providers.groww_frames import (
    FNO,
    LIVE_INDEX,
    LIVE_PRICE,
    MARKET_DEPTH,
    TS_MILLIS,
    depth,
    feed_message,
    index_value,
    live_price,
)
from tests.unit.providers.listeners import RecordingListener

pytestmark = pytest.mark.usefixtures("no_proxy_for_loopback")

ACCESS_TOKEN = "groww-access-token-123"
ACCOUNT = uuid4()
NOW = datetime(2026, 1, 5, 4, 15, 31, tzinfo=UTC)
PROVIDER_TIME = datetime(2026, 1, 5, 4, 15, 30, tzinfo=UTC)  # TS_MILLIS

CASH_PRICE = "/ld/eq/nse/price.2885"
CASH_BOOK = "/ld/eq/nse/book.2885"
FNO_PRICE = "/ld/fo/nse/price.35001"
NIFTY_VALUE = "/ld/indices/nse/price.NIFTY"
AUTH_REJECTED = "the Groww feed rejected the connection credentials (authorization violation)"


def instrument(
    token: str,
    mode: SubscriptionMode = SubscriptionMode.QUOTE,
    *,
    exchange: Exchange = Exchange.NSE,
    segment: Segment = Segment.CASH,
    provider: Provider = Provider.GROWW,
    symbol: str = "RELIANCE",
) -> ProviderInstrument:
    instrument_type = {Segment.INDEX: InstrumentType.INDEX, Segment.FNO: InstrumentType.FUTURE}.get(
        segment, InstrumentType.EQUITY
    )
    return ProviderInstrument(
        instrument_id=uuid4(),
        provider=provider,
        provider_token=token,
        exchange_token=token.rpartition("|")[2],
        provider_symbol=symbol,
        provider_exchange=exchange.value,
        provider_segment=segment.value,
        exchange=exchange,
        segment=segment,
        instrument_type=instrument_type,
        symbol=symbol,
        mode=mode,
    )


async def credentials() -> SessionCredentials:
    return SessionCredentials(access_token=ACCESS_TOKEN)


def session(fake: FakeGroww, url: str, **overrides: Any) -> GrowwFeedSession:
    options: dict[str, Any] = {
        "socket_url": url,
        "api_base_url": API_BASE_URL,
        "credentials": credentials,
        "account_id": ACCOUNT,
        "heartbeat_interval": 5.0,
        "clock": lambda: NOW,
        "http_transport": httpx.MockTransport(fake.rest),
    }
    return GrowwFeedSession(**(options | overrides))


def price_message(**values: float) -> bytes:
    return feed_message(LIVE_PRICE, live_price(**values), symbol="RELIANCE")


async def test_session_streams_routes_and_resubscribes_feed_subjects() -> None:
    fake = FakeGroww(ACCESS_TOKEN)
    listener = RecordingListener()
    reliance = instrument("NSE|CASH|2885", SubscriptionMode.FULL)
    future = instrument("NSE|FNO|35001", SubscriptionMode.LTP, segment=Segment.FNO, symbol="NIFTY26JANFUT")
    nifty = instrument("NSE|INDEX|NIFTY", SubscriptionMode.LTP, segment=Segment.INDEX, symbol="NIFTY 50")

    async with fake.server() as url:
        stream = session(fake, url, heartbeat_interval=0.2, volume_is_cumulative=True)
        await stream.open(listener)
        await stream.subscribe([reliance, future, nifty])
        await fake.wait_until(lambda: len(fake.subscriptions) == 4)

        async def deliver(subject: str, payload: bytes, *, sid: str | None = None) -> None:
            calls = listener.calls
            await fake.publish(subject, payload, sid=sid)
            await listener.wait_until(lambda: listener.calls > calls)

        await deliver(CASH_PRICE, price_message(ts_in_millis=TS_MILLIS, ltp=1512.4, close=1495, volume=5e5))
        await deliver(
            CASH_BOOK, feed_message(MARKET_DEPTH, depth(buy=[(0, 1512.3, 10)], sell=[(0, 1512.5, 25)]))
        )
        await deliver(
            FNO_PRICE,
            feed_message(
                LIVE_PRICE, live_price(ltp=24_410, volume=75_000, open_interest=1_250_000), segment=FNO
            ),
        )
        await deliver(NIFTY_VALUE, feed_message(LIVE_INDEX, index_value(24_350.65)))
        await deliver(CASH_PRICE, b"\xff")
        await deliver(CASH_PRICE, feed_message(LIVE_INDEX, index_value(1.0)))
        await deliver(FNO_PRICE, b"")
        # A subject without a route (e.g. in flight while it was unsubscribed) only proves liveness.
        await deliver("/ld/eq/nse/price.9999", price_message(ltp=1.0), sid=fake.subscriptions[CASH_PRICE])

        await stream.subscribe([future])  # already subscribed
        await stream.subscribe([instrument("NSE|CASH|2885", SubscriptionMode.QUOTE)])  # FULL -> QUOTE
        await stream.unsubscribe([nifty, instrument("NSE|CASH|1594")])
        await fake.wait_until(lambda: len(fake.unsubscribed) == 2)
        await deliver(CASH_PRICE, price_message(ltp=1513.0))

        pings = fake.pings
        run = asyncio.create_task(stream.run())
        await listener.wait_until(lambda: listener.heartbeats == 2)  # an idle connection is pinged
        await fake.close()
        with pytest.raises(ProviderUnavailableError) as caught:
            await asyncio.wait_for(run, timeout=5)
        await stream.close()
        await stream.close()

    assert len(fake.socket_keys) == 1
    assert fake.socket_keys[0].startswith("U")  # a fresh NKEY user key
    assert fake.connects == [True]  # the feed JWT was presented and the nonce signed with its seed
    assert (fake.connect_options[0]["jwt"], fake.connect_options[0]["verbose"]) == (FEED_JWT, False)
    assert fake.sub_commands == [CASH_PRICE, CASH_BOOK, FNO_PRICE, NIFTY_VALUE]
    assert fake.unsubscribed == [CASH_BOOK, NIFTY_VALUE]
    assert set(fake.subscriptions) == {CASH_PRICE, FNO_PRICE}
    assert fake.pings > pings

    assert [len(batch) for batch in listener.tick_batches] == [1, 1, 1, 1, 0, 1]
    price, book, fno, index, quote = listener.ticks
    assert [(tick.provider_token, tick.event_type) for tick in listener.ticks] == [
        ("NSE|CASH|2885", EventType.QUOTE),
        ("NSE|CASH|2885", EventType.DEPTH),
        ("NSE|FNO|35001", EventType.QUOTE),
        ("NSE|INDEX|NIFTY", EventType.INDEX_VALUE),
        ("NSE|CASH|2885", EventType.LTP),
    ]
    assert all(
        (tick.provider, tick.account_id, tick.received_at) == (Provider.GROWW, ACCOUNT, NOW)
        for tick in listener.ticks
    )
    assert (price.last_price, price.previous_close, price.volume, price.provider_timestamp) == (
        Decimal("1512.4"),
        Decimal("1495"),
        500_000,
        PROVIDER_TIME,
    )
    assert (book.bid, book.bid_quantity, book.ask, book.ask_quantity) == (
        Decimal("1512.3"),
        10,
        Decimal("1512.5"),
        25,
    )
    assert (fno.last_price, fno.open_interest, fno.volume, fno.volume_semantics) == (
        Decimal("24410"),
        1_250_000,
        75_000,
        VolumeSemantics.CUMULATIVE_DAY,
    )
    assert (index.last_price, quote.last_price) == (Decimal("24350.65"), Decimal("1513"))
    assert listener.malformed == [
        ("truncated varint", 1),
        ("the price feed delivered a IndexValue payload", 1),
    ]
    assert listener.notices == []
    assert caught.value.message == "the Groww feed connection closed: UnexpectedEOF: nats: unexpected EOF"


async def test_refused_subscriptions_are_reported_and_the_feed_stays_up() -> None:
    fake = FakeGroww(ACCESS_TOKEN, refuse={CASH_BOOK})
    listener = RecordingListener()
    async with fake.server() as url:
        stream = session(fake, url)
        await stream.open(listener)
        await stream.subscribe([instrument("NSE|CASH|2885", SubscriptionMode.FULL)])
        await listener.wait_until(lambda: bool(listener.notices))
        await fake.publish(CASH_PRICE, price_message(ltp=1512.4))
        await listener.wait_until(lambda: bool(listener.tick_batches))
        await stream.close()
    assert fake.refused == [CASH_BOOK]
    assert listener.notices == [
        (
            "Groww refused a feed subscription: nats: permissions violation for subscription to "
            f'"{CASH_BOOK}"',
            True,
        )
    ]


async def test_dropped_messages_are_reported_once() -> None:
    fake = FakeGroww(ACCESS_TOKEN)
    listener = RecordingListener()
    async with fake.server() as url:
        stream = session(fake, url)
        await stream.open(listener)
        await stream.subscribe([instrument("NSE|CASH|2885", SubscriptionMode.LTP)])
        await fake.wait_until(lambda: CASH_PRICE in fake.subscriptions)
        payload = price_message(ltp=1512.4)
        message = f"MSG {CASH_PRICE} {fake.subscriptions[CASH_PRICE]} {len(payload)}\r\n".encode() + payload
        # One frame: nats-py parses it without yielding, so the subscription queue overflows.
        await fake.send_raw((message + b"\r\n") * (PENDING_MESSAGES_LIMIT + 5))
        await listener.wait_until(lambda: len(listener.tick_batches) == PENDING_MESSAGES_LIMIT)
        await stream.close()
    assert listener.notices == [
        ("Groww feed messages were dropped because processing fell behind (NATS slow consumer)", True)
    ]


async def test_server_errors_end_the_session_with_their_reason() -> None:
    fake = FakeGroww(ACCESS_TOKEN)
    async with fake.server() as url:
        stream = session(fake, url)
        await stream.open(RecordingListener())
        await fake.send_raw(b"-ERR 'User Authentication Expired'\r\n")
        with pytest.raises(ProviderUnavailableError) as caught:
            await asyncio.wait_for(stream.run(), timeout=5)
        await stream.close()
    assert (
        caught.value.message == "the Groww feed connection closed: Error: nats: user authentication expired"
    )


async def test_unanswered_pings_fail_subscribe_and_heartbeat(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(feed_module, "FLUSH_TIMEOUT_SECONDS", 0.2)
    fake = FakeGroww(ACCESS_TOKEN)
    async with fake.server() as url:
        stream = session(fake, url, heartbeat_interval=0.2)
        await stream.open(RecordingListener())
        fake.answer_pings = False
        with pytest.raises(
            ProviderUnavailableError, match=r"^the Groww feed did not answer within 0.2s \(subscribe\)$"
        ):
            await stream.subscribe([instrument("NSE|CASH|2885")])
        with pytest.raises(
            ProviderUnavailableError, match=r"^the Groww feed did not answer within 0.2s \(ping\)$"
        ):
            await asyncio.wait_for(stream.run(), timeout=5)
        await stream.close()


async def test_a_stopped_reading_loop_is_not_mistaken_for_a_healthy_connection() -> None:
    fake = FakeGroww(ACCESS_TOKEN)
    async with fake.server() as url:
        stream = session(fake, url, heartbeat_interval=0.2)
        await stream.open(RecordingListener())
        client = stream._client
        assert client is not None
        reading = client._reading_task
        assert reading is not None
        reading.cancel()
        with pytest.raises(ProviderUnavailableError, match=r"^the Groww feed client stopped reading$"):
            await asyncio.wait_for(stream.run(), timeout=5)
        await stream.close()


async def test_a_listener_defect_ends_the_session() -> None:
    class DefectiveListener(RecordingListener):
        def on_ticks(self, ticks: Sequence[ProviderTick]) -> None:
            raise RuntimeError("listener defect")

    fake = FakeGroww(ACCESS_TOKEN)
    async with fake.server() as url:
        stream = session(fake, url)
        await stream.open(DefectiveListener())
        await stream.subscribe([instrument("NSE|CASH|2885")])
        await fake.wait_until(lambda: CASH_PRICE in fake.subscriptions)
        await fake.publish(CASH_PRICE, price_message(ltp=1512.4))
        with pytest.raises(RuntimeError, match=r"^listener defect$"):
            await asyncio.wait_for(stream.run(), timeout=5)
        await stream.close()


# ---- connection failures -------------------------------------------------------------------------


async def test_rejected_feed_credentials() -> None:
    fake = FakeGroww(ACCESS_TOKEN, reject_connect=True)
    async with fake.server() as url:
        with pytest.raises(ProviderUnavailableError) as caught:
            await session(fake, url).open(RecordingListener())
    assert caught.value.message == AUTH_REJECTED
    assert (fake.handshakes, fake.connects) == (1, [False])


@pytest.mark.parametrize(
    ("status", "error", "text"),
    [
        (
            HTTPStatus.TOO_MANY_REQUESTS,
            ProviderRateLimitedError,
            "Groww refused the feed connection: too many connection attempts (HTTP 429)",
        ),
        (
            HTTPStatus.SERVICE_UNAVAILABLE,
            ProviderUnavailableError,
            "Groww refused the feed connection (HTTP 503)",
        ),
    ],
)
async def test_refused_handshakes_are_classified(
    status: HTTPStatus, error: type[AppError], text: str
) -> None:
    fake = FakeGroww(ACCESS_TOKEN, handshake_status=status)
    async with fake.server() as url:
        with pytest.raises(error) as caught:
            await session(fake, url).open(RecordingListener())
    assert caught.value.message == text
    assert (fake.handshakes, len(fake.socket_keys)) == (2, 1)  # nats-py tries twice with one feed JWT


async def test_an_invalid_access_token_fails_before_the_feed_is_contacted() -> None:
    fake = FakeGroww("a-different-access-token")
    async with fake.server() as url:
        stream = session(fake, url)
        with pytest.raises(ProviderAuthRequiredError, match=r"\(invalid token; code GA005\)") as caught:
            await stream.open(RecordingListener())
        with pytest.raises(RuntimeError, match=r"^a Groww feed session can only be opened once$"):
            await stream.open(RecordingListener())
    assert ACCESS_TOKEN not in caught.value.message
    assert (len(fake.token_requests), fake.handshakes) == (1, 0)


async def test_a_server_that_never_greets_times_out() -> None:
    fake = FakeGroww(ACCESS_TOKEN, send_info=False)
    async with fake.server() as url:
        with pytest.raises(ProviderUnavailableError, match=r"^the Groww feed connection timed out$"):
            await session(fake, url, connect_timeout=0.5).open(RecordingListener())
    assert fake.handshakes == 1


async def test_a_cancelled_open_closes_the_half_open_connection() -> None:
    fake = FakeGroww(ACCESS_TOKEN)
    fake.answer_pings = False  # the client waits for the PONG that completes its handshake
    async with fake.server() as url:
        stream = session(fake, url)
        opening = asyncio.create_task(stream.open(RecordingListener()))
        await fake.wait_until(lambda: fake.pings == 1)
        opening.cancel()  # as the supervisor's connect timeout does
        with pytest.raises(asyncio.CancelledError):
            await opening
        await fake.wait_until(lambda: fake.disconnects == 1)
        with pytest.raises(ProviderUnavailableError, match=r"^the Groww feed is not connected$"):
            await stream.subscribe([instrument("NSE|CASH|2885")])
    assert fake.connects == [True]


def handshake_error(status: int) -> aiohttp.WSServerHandshakeError:
    return aiohttp.WSServerHandshakeError(cast(Any, None), (), status=status)


@pytest.mark.parametrize(
    ("exc", "recorded", "error", "text"),
    [
        (TimeoutError(), None, ProviderUnavailableError, "the Groww feed connection timed out"),
        (
            nats_errors.NoServersError(),
            TimeoutError(),
            ProviderUnavailableError,
            "the Groww feed connection timed out",
        ),
        (
            nats_errors.NoServersError(),
            handshake_error(401),
            ProviderUnavailableError,
            "Groww refused the feed connection (HTTP 401)",
        ),
        (nats_errors.AuthorizationError(), None, ProviderUnavailableError, AUTH_REJECTED),
        (nats_errors.Error("nats: 'Authorization Violation'"), None, ProviderUnavailableError, AUTH_REJECTED),
        (
            nats_errors.NoServersError(),
            None,
            ProviderUnavailableError,
            "the Groww feed connection failed: NoServersError: nats: no servers available for connection",
        ),
        (
            OSError("connection reset"),
            handshake_error(429),
            ProviderUnavailableError,
            "the Groww feed connection failed: OSError: connection reset",
        ),
    ],
)
def test_connect_failures_are_classified(
    exc: Exception, recorded: Exception | None, error: type[AppError], text: str
) -> None:
    classified = _connect_error(exc, recorded)
    assert (type(classified), classified.message) == (error, text)


async def test_sessions_validate_their_settings_and_need_a_connection() -> None:
    fake = FakeGroww(ACCESS_TOKEN)
    for invalid in ({"heartbeat_interval": 0}, {"connect_timeout": -1.0}):
        with pytest.raises(ValueError, match=r"^heartbeat_interval and connect_timeout must be positive$"):
            session(fake, "ws://127.0.0.1:9", **invalid)
    unopened = session(fake, "ws://127.0.0.1:9")
    await unopened.subscribe([])
    await unopened.unsubscribe([])
    with pytest.raises(ProviderUnavailableError, match=r"^the Groww feed is not connected$"):
        await unopened.subscribe([instrument("NSE|CASH|2885")])
    with pytest.raises(ProviderUnavailableError, match=r"^the Groww feed is not connected$"):
        await unopened.unsubscribe([instrument("NSE|CASH|2885")])
    with pytest.raises(ProviderUnavailableError, match=r"^the Groww feed is not connected$"):
        await unopened.run()
    await unopened.close()
    assert fake.token_requests == []


# ---- adapter ---------------------------------------------------------------------------------------


def adapter(settings: Settings) -> GrowwAdapter:
    return GrowwAdapter(
        account_id=ACCOUNT,
        settings=settings,
        capabilities=default_capabilities(Provider.GROWW),
        credentials=credentials,
    )


def test_adapter_slot_cost_counts_feed_subjects(make_settings: Callable[..., Settings]) -> None:
    feed = adapter(make_settings())
    costs = [
        feed.slot_cost(instrument("NSE|CASH|2885", SubscriptionMode.LTP)),
        feed.slot_cost(instrument("NSE|FNO|35001", SubscriptionMode.QUOTE, segment=Segment.FNO)),
        feed.slot_cost(instrument("BSE|CASH|500325", SubscriptionMode.FULL, exchange=Exchange.BSE)),
        feed.slot_cost(instrument("NSE|INDEX|NIFTY", SubscriptionMode.FULL, segment=Segment.INDEX)),
    ]
    assert costs == [1, 1, 2, 1]


@pytest.mark.parametrize(
    ("item", "text"),
    [
        (
            instrument("NSE|CASH|2885", provider=Provider.ZERODHA),
            "RELIANCE is mapped for ZERODHA, not GROWW",
        ),
        (
            instrument("MCX|FNO|1", exchange=Exchange.MCX, segment=Segment.COMMODITY),
            "Groww Trading API does not stream MCX COMMODITY instruments (RELIANCE)",
        ),
        (instrument("2885"), "RELIANCE has no valid Groww feed token; refresh the instrument master"),
        # NATS wildcards or separators would reach unrelated subjects such as order updates.
        (instrument("NSE|CASH|>"), "RELIANCE has no valid Groww feed token; refresh the instrument master"),
        (instrument("NSE|CASH|*"), "RELIANCE has no valid Groww feed token; refresh the instrument master"),
        (
            instrument("NSE|CASH|2885.x"),
            "RELIANCE has no valid Groww feed token; refresh the instrument master",
        ),
        (
            instrument("BSE|CASH|500325"),
            "RELIANCE has a Groww feed token for another exchange or segment; refresh the instrument master",
        ),
        (
            instrument("NSE|FNO|35001"),
            "RELIANCE has a Groww feed token for another exchange or segment; refresh the instrument master",
        ),
    ],
)
async def test_adapter_rejects_instruments_it_cannot_stream(
    make_settings: Callable[..., Settings], item: ProviderInstrument, text: str
) -> None:
    feed = adapter(make_settings())
    with pytest.raises(UnsupportedInstrumentError) as caught:
        await feed.subscribe([item])
    assert caught.value.message == text
    assert feed.subscriptions == {}


@pytest.mark.parametrize(("timeout", "interval"), [(0.3, 0.5), (6.0, 2.0), (60.0, 5.0)])
def test_adapter_sessions_ping_after_a_third_of_the_heartbeat_timeout(
    make_settings: Callable[..., Settings], monkeypatch: pytest.MonkeyPatch, timeout: float, interval: float
) -> None:
    created: list[dict[str, Any]] = []
    monkeypatch.setattr(adapter_module, "GrowwFeedSession", lambda **options: created.append(options))
    settings = make_settings(feed_heartbeat_timeout_seconds=timeout, groww_feed_volume_is_cumulative=True)
    feed = adapter(settings)
    feed.create_session(0)
    assert created == [
        {
            "socket_url": settings.groww_socket_url,
            "api_base_url": settings.groww_api_base_url,
            "credentials": feed.load_credentials,
            "account_id": ACCOUNT,
            "heartbeat_interval": interval,
            "volume_is_cumulative": True,
        }
    ]


async def test_adapter_streams_normalized_events(
    make_settings: Callable[..., Settings], monkeypatch: pytest.MonkeyPatch
) -> None:
    fake = FakeGroww(ACCESS_TOKEN)
    monkeypatch.setattr(
        adapter_module,
        "GrowwFeedSession",
        lambda **options: GrowwFeedSession(**options, http_transport=httpx.MockTransport(fake.rest)),
    )
    reliance = instrument("NSE|CASH|2885", SubscriptionMode.LTP)
    async with fake.server() as url:
        feed = adapter(
            make_settings(groww_socket_url=url, groww_api_base_url=API_BASE_URL, market_data_enabled=True)
        )
        await feed.subscribe([reliance])
        await feed.connect()
        try:
            await fake.wait_until(lambda: CASH_PRICE in fake.subscriptions)
            # No feed timestamp, so freshness is judged by the real receive time.
            await fake.publish(CASH_PRICE, price_message(ltp=1512.4))
            event = await asyncio.wait_for(feed.next_event(), timeout=10)
            health = await feed.health()
        finally:
            await feed.disconnect()

    assert (event.instrument_id, event.symbol, event.exchange) == (
        reliance.instrument_id,
        "RELIANCE",
        Exchange.NSE,
    )
    assert (event.provider, event.event_type, event.last_price) == (
        Provider.GROWW,
        EventType.LTP,
        Decimal("1512.4"),
    )
    assert event.data_status is DataStatus.LIVE
    assert health.state is ConnectionState.CONNECTED
    assert (await feed.health()).state is ConnectionState.STOPPED
