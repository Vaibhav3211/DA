"""Risk gate: rule outcomes, simulated data and policy layering."""

from __future__ import annotations

import dataclasses
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any
from uuid import uuid4

import pytest

from app.domain.enums import (
    CandleFlag,
    DataStatus,
    InstrumentType,
    MarketRegion,
    MarketSessionState,
    Provider,
    RiskOutcome,
    SignalType,
)
from app.domain.models.signal import RiskCheck, RiskDecision, SignalCandidate, TargetLevel
from app.risk.engine import RiskPolicy, RuleOverride, evaluate, resolve_policy
from app.risk.rules import (
    BUILTIN_RULES,
    DATA_QUALITY,
    ELIGIBILITY,
    FREQUENCY,
    INSTRUMENT_STATUS,
    KILL_SWITCH,
    LIVE_SIGNALS,
    PRICE_SANITY,
    SESSION_STATUS,
    STOP_LOSS_REQUIRED,
    STRATEGY_ENABLED,
    VOLATILITY_LIMIT,
    WORKSPACE_PAUSE,
    FrequencyParams,
    NoParams,
    RecentSignal,
    RiskInput,
    RiskRule,
    SourceData,
)
from tests.candle_support import T0, bar
from tests.signal_support import ALPHA, METADATA, make_candidate, make_indicator

NOW = T0 + timedelta(minutes=30)
DEFAULT_POLICY = resolve_policy((), None)


def _input(*, candidate: SignalCandidate | None = None, **overrides: Any) -> RiskInput:
    # The source candle closes at NOW: 100.10 with a 0.5% range.
    data = RiskInput(
        candidate=candidate or make_candidate(),
        metadata=METADATA,
        instrument=ALPHA,
        market_region=MarketRegion.INDIA,
        source=SourceData.from_candle(bar(29, "100.10", high="100.40", low="99.90")),
        session_state=MarketSessionState.OPEN,
        trading_date=date(2026, 1, 5),
        deployment_enabled=True,
        kill_switch_engaged=False,
        live_signals_enabled=True,
    )
    return dataclasses.replace(data, **overrides)


def _source(**overrides: Any) -> SourceData:
    return dataclasses.replace(_input().source, **overrides)


def _decide(data: RiskInput, policy: RiskPolicy = DEFAULT_POLICY) -> RiskDecision:
    return evaluate(data, policy, NOW)


def _check(decision: RiskDecision, rule: str) -> RiskCheck | None:
    return next((check for check in decision.checks if check.rule == rule), None)


def test_clean_candidate_passes_every_rule() -> None:
    decision = _decide(_input())

    assert decision.outcome is RiskOutcome.ALLOW
    assert [check.rule for check in decision.checks] == [rule.key for rule in BUILTIN_RULES]
    assert all(check.passed for check in decision.checks)
    assert decision.evaluated_at == NOW


@pytest.mark.parametrize(
    ("overrides", "rule", "message"),
    [
        pytest.param(
            {"kill_switch_engaged": True, "kill_switch_reason": "manual"},
            KILL_SWITCH,
            "Kill switch is engaged (manual)",
            id="kill-switch",
        ),
        pytest.param(
            {"live_signals_enabled": False}, LIVE_SIGNALS, "LIVE_SIGNALS_ENABLED=true", id="live-off"
        ),
        pytest.param({"deployment_enabled": False}, STRATEGY_ENABLED, "is not enabled", id="disabled"),
        pytest.param(
            {"deployment_problem": "workspace india is disabled"},
            STRATEGY_ENABLED,
            "blocked: workspace india is disabled",
            id="deployment-blocked",
        ),
        pytest.param({"source": _source(status=DataStatus.STALE)}, DATA_QUALITY, "data is STALE", id="stale"),
        pytest.param(
            {"source": _source(as_of=NOW - timedelta(minutes=5))},
            DATA_QUALITY,
            "source data is 300s old (limit 120s)",
            id="old-data",
        ),
        pytest.param(
            {"source": _source(flags=frozenset({CandleFlag.DISCONNECTED_DURING}))},
            DATA_QUALITY,
            "candle flagged DISCONNECTED_DURING",
            id="disconnected-candle",
        ),
        pytest.param(
            {"instrument": ALPHA.model_copy(update={"is_active": False})},
            INSTRUMENT_STATUS,
            "ALPHA is inactive",
            id="inactive",
        ),
        pytest.param(
            {"instrument": ALPHA.model_copy(update={"expiry": date(2026, 1, 2)})},
            INSTRUMENT_STATUS,
            "ALPHA expired on 2026-01-02",
            id="expired",
        ),
        pytest.param(
            {"instrument": ALPHA.model_copy(update={"instrument_type": InstrumentType.INDEX})},
            ELIGIBILITY,
            "INDEX",
            id="instrument-type",
        ),
        pytest.param(
            {"universe_problem": "ALPHA is outside the workspace universe"},
            ELIGIBILITY,
            "outside the workspace universe",
            id="universe",
        ),
        pytest.param(
            {"session_state": MarketSessionState.CLOSED},
            SESSION_STATUS,
            "NSE session is CLOSED (allowed: OPEN)",
            id="closed",
        ),
        pytest.param(
            {"recent_signals": (RecentSignal(NOW - timedelta(minutes=50), SignalType.SELL),) * 3},
            FREQUENCY,
            "3 signals for this instrument in the last 60 min (limit 3)",
            id="frequency",
        ),
        pytest.param(
            {"candidate": make_candidate(stop_loss=Decimal(101))},
            PRICE_SANITY,
            "stop-loss 101 must be below 100.10 for BUY",
            id="stop-wrong-side",
        ),
        pytest.param(
            {"candidate": make_candidate(entry_price=Decimal(103))},
            PRICE_SANITY,
            "entry 103 is 2.90% from the last price 100.10 (limit 2%)",
            id="entry-far",
        ),
        pytest.param(
            {"source": _source(high=Decimal(104), low=Decimal(97))},
            VOLATILITY_LIMIT,
            "source candle range 6.99% exceeds 5%",
            id="wide-candle",
        ),
        pytest.param(
            {"candidate": make_candidate(stop_loss=Decimal(85))},
            VOLATILITY_LIMIT,
            "stop-loss is 15.08% from entry (limit 10%)",
            id="far-stop",
        ),
        pytest.param(
            {"candidate": make_candidate(stop_loss=None)},
            STOP_LOSS_REQUIRED,
            "BUY signals require a stop-loss",
            id="no-stop",
        ),
    ],
)
def test_rule_blocks(overrides: dict[str, Any], rule: str, message: str) -> None:
    decision = _decide(_input(**overrides))

    check = _check(decision, rule)
    assert decision.outcome is RiskOutcome.BLOCK
    assert check is not None
    assert not check.passed
    assert check.severity == "BLOCK"
    assert message in check.message


@pytest.mark.parametrize(
    ("overrides", "rule", "message"),
    [
        pytest.param(
            {"source": _source(status=DataStatus.DELAYED)}, DATA_QUALITY, "data is DELAYED", id="delayed"
        ),
        pytest.param(
            {"source": _source(flags=frozenset({CandleFlag.GAP_BEFORE}))},
            DATA_QUALITY,
            "candle flagged GAP_BEFORE",
            id="gap",
        ),
        pytest.param(
            {"instrument": ALPHA.model_copy(update={"expiry": date(2026, 1, 5)})},
            INSTRUMENT_STATUS,
            "ALPHA expires today",
            id="expiry-day",
        ),
        pytest.param(
            {"candidate": make_candidate(stop_loss=Decimal("98.03"))},
            PRICE_SANITY,
            "stop-loss not on the 0.05 tick",
            id="off-tick",
        ),
    ],
)
def test_rule_warns_without_blocking(overrides: dict[str, Any], rule: str, message: str) -> None:
    decision = _decide(_input(**overrides))

    check = _check(decision, rule)
    assert decision.outcome is RiskOutcome.ALLOW
    assert check is not None
    assert check.severity == "WARN"
    assert not check.passed
    assert check.message == message


def test_sell_levels_are_checked_on_the_other_side() -> None:
    candidate = make_candidate(
        signal_type=SignalType.SELL,
        stop_loss=Decimal("99.00"),
        targets=(TargetLevel(label="T1", price=Decimal("101.00")),),
    )

    decision = _decide(_input(candidate=candidate))

    assert decision.blocking_reasons == [
        "stop-loss 99.00 must be above 100.10 for SELL; target T1 101.00 must be below 100.10 for SELL"
    ]


def test_simulated_data_needs_no_live_flag_but_quality_still_applies() -> None:
    simulated = _input(
        source=_source(provider=Provider.SIMULATOR, status=DataStatus.SIMULATED), live_signals_enabled=False
    )

    allowed = _decide(simulated)
    blocked = _decide(
        dataclasses.replace(
            simulated, candidate=make_candidate(indicator_values=(make_indicator(DataStatus.STALE),))
        )
    )

    assert simulated.uses_simulated_data
    assert allowed.outcome is RiskOutcome.ALLOW
    # SIMULATED ranks above STALE in worst_status; the gate must still see the stale input.
    assert blocked.blocking_reasons == ["data is STALE"]


def test_frequency_counts_only_new_entry_signals_inside_the_window() -> None:
    old, recent = NOW - timedelta(minutes=61), NOW - timedelta(minutes=1)
    history = (
        *(RecentSignal(old, SignalType.BUY),) * 3,
        RecentSignal(recent, SignalType.BUY),
        *(RecentSignal(recent, SignalType.EXIT),) * 3,
    )
    busy = (RecentSignal(recent, SignalType.BUY),) * 5

    fresh = _decide(_input(recent_signals=history))
    update = _decide(_input(recent_signals=busy, is_update=True))
    exit_signal = _decide(_input(candidate=make_candidate(signal_type=SignalType.EXIT), recent_signals=busy))

    check = _check(fresh, FREQUENCY)
    assert check is not None
    assert check.message == "1 of 3 signals used in the last 60 min"
    assert update.outcome is RiskOutcome.ALLOW
    assert _check(update, FREQUENCY) is None
    # Exits are not rate-limited by default.
    assert _check(exit_signal, FREQUENCY) is None


def test_informational_signals_need_no_stop_loss() -> None:
    candidate = make_candidate(signal_type=SignalType.WATCH, entry_price=None, stop_loss=None, targets=())

    decision = _decide(_input(candidate=candidate))

    assert decision.outcome is RiskOutcome.ALLOW
    assert _check(decision, STOP_LOSS_REQUIRED) is None


def test_policy_layers_override_defaults_in_order() -> None:
    workspace = uuid4()
    overrides = [
        RuleOverride(FREQUENCY, None, True, {"max_signals": 5, "window_minutes": 30}),
        RuleOverride(FREQUENCY, workspace, True, {"max_signals": 1}),
        RuleOverride(FREQUENCY, uuid4(), True, {"max_signals": 50}),
    ]

    global_rule = resolve_policy(overrides, None).get(FREQUENCY)
    workspace_rule = resolve_policy(overrides, workspace).get(FREQUENCY)

    assert global_rule.params == FrequencyParams(max_signals=5, window_minutes=30)
    assert global_rule.source == "global"
    assert workspace_rule.params == FrequencyParams(max_signals=1, window_minutes=30)
    assert workspace_rule.source == "workspace"
    assert resolve_policy([], workspace).get(FREQUENCY).source == "default"


def test_optional_rules_can_be_disabled_but_mandatory_rules_cannot() -> None:
    policy = resolve_policy(
        [RuleOverride(STOP_LOSS_REQUIRED, None, False, {}), RuleOverride(KILL_SWITCH, None, False, {})], None
    )

    decision = _decide(_input(candidate=make_candidate(stop_loss=None), kill_switch_engaged=True), policy)

    skipped = _check(decision, STOP_LOSS_REQUIRED)
    assert decision.blocking_reasons == ["Kill switch is engaged (no reason given)"]
    assert skipped is not None
    assert skipped.message == "Skipped: disabled by the global setting"


def test_rule_parameters_change_the_outcome() -> None:
    workspace = uuid4()
    policy = resolve_policy(
        [
            RuleOverride(WORKSPACE_PAUSE, workspace, True, {"paused": True, "reason": "results day"}),
            RuleOverride(DATA_QUALITY, None, True, {"block_delayed": True}),
        ],
        workspace,
    )

    decision = _decide(_input(source=_source(status=DataStatus.DELAYED)), policy)

    assert decision.blocking_reasons == [
        "Signals are paused for this workspace (results day)",
        "data is DELAYED",
    ]


def test_invalid_stored_parameters_fail_closed() -> None:
    policy = resolve_policy([RuleOverride(FREQUENCY, None, True, {"max_signals": 0})], None)

    decision = _decide(_input(), policy)

    check = _check(decision, FREQUENCY)
    assert policy.get(FREQUENCY).params is None
    assert decision.outcome is RiskOutcome.BLOCK
    assert check is not None
    assert check.message.startswith("Stored parameters are invalid (max_signals:")


def test_a_failing_rule_blocks() -> None:
    def explode(data: RiskInput, params: NoParams, now: datetime) -> RiskCheck:
        raise RuntimeError("boom")

    policy = resolve_policy([], None, rules=(RiskRule("exploding", "fails", NoParams, explode),))

    assert _decide(_input(), policy).blocking_reasons == ["Rule failed: RuntimeError: boom"]
