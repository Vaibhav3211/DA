from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from app.core.config import AppEnv, Settings
from app.domain.enums import CandleInterval
from tests.conftest import TEST_DATABASE_URL, build_settings


def test_order_execution_can_never_be_enabled() -> None:
    with pytest.raises(ValidationError, match="ORDER_EXECUTION_ENABLED"):
        build_settings(order_execution_enabled=True)


@pytest.mark.parametrize("env", [AppEnv.LIVE_DATA, AppEnv.PRODUCTION])
def test_simulator_is_rejected_outside_development_and_replay(env: AppEnv) -> None:
    with pytest.raises(ValidationError, match="SIMULATOR_ENABLED"):
        build_settings(app_env=env, simulator_enabled=True, cookie_secure=True, encryption_key="x" * 44)


@pytest.mark.parametrize("env", [AppEnv.DEVELOPMENT, AppEnv.REPLAY])
def test_simulated_mode_only_in_development_or_replay(env: AppEnv) -> None:
    assert build_settings(app_env=env, simulator_enabled=True).is_simulated_mode
    assert not build_settings(app_env=env).is_simulated_mode


def test_replay_never_streams_live_market_data() -> None:
    with pytest.raises(ValidationError, match="MARKET_DATA_ENABLED must be false when APP_ENV is replay"):
        build_settings(app_env=AppEnv.REPLAY, market_data_enabled=True)
    assert build_settings(app_env=AppEnv.LIVE_DATA, market_data_enabled=True).market_data_enabled


def test_production_requires_secure_cookies_and_encryption_key() -> None:
    with pytest.raises(ValidationError, match="COOKIE_SECURE"):
        build_settings(app_env=AppEnv.PRODUCTION, encryption_key="k")
    with pytest.raises(ValidationError, match="ENCRYPTION_KEY"):
        build_settings(app_env=AppEnv.PRODUCTION, cookie_secure=True)


def test_allowed_origins_accepts_comma_separated_env_value(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ALLOWED_ORIGINS", "http://localhost:3000, http://127.0.0.1:3000 ,")
    settings = build_settings()
    assert settings.allowed_origins == ["http://localhost:3000", "http://127.0.0.1:3000"]


def test_live_features_are_disabled_by_default() -> None:
    settings = build_settings()
    assert not settings.market_data_enabled
    assert not settings.live_signals_enabled
    assert not settings.order_execution_enabled
    assert not settings.simulator_enabled


def test_candle_intervals_accept_a_comma_separated_list_and_are_ordered(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CANDLE_INTERVALS", "1h, 1m,1s,1m,")

    assert build_settings().candle_intervals == [CandleInterval.S1, CandleInterval.M1, CandleInterval.H1]


@pytest.mark.parametrize(
    ("value", "message"), [(" , ", "at least one interval"), ("1m,2m", "candle_intervals.1")]
)
def test_candle_intervals_must_name_supported_intervals(
    monkeypatch: pytest.MonkeyPatch, value: str, message: str
) -> None:
    monkeypatch.setenv("CANDLE_INTERVALS", value)

    with pytest.raises(ValidationError, match=message):
        build_settings()


def test_empty_values_in_env_files_mean_not_set(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    for name in ("ZERODHA_API_KEY", "ENCRYPTION_KEY", "API_PORT"):
        monkeypatch.delenv(name, raising=False)
    env_file = tmp_path / ".env"
    env_file.write_text("ZERODHA_API_KEY=\nENCRYPTION_KEY=\nAPI_PORT=8100\n", encoding="utf-8")
    settings = Settings(_env_file=env_file, database_url=TEST_DATABASE_URL)
    assert (settings.zerodha_api_key, settings.encryption_key, settings.api_port) == (None, None, 8100)
