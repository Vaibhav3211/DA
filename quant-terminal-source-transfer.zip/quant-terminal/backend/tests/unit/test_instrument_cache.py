from __future__ import annotations

import os
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from app.core.clock import IST
from app.domain.enums import Provider
from app.market_data.instruments.cache import cache_dump

AT = datetime(2026, 1, 5, 9, 30, 15, 123456, tzinfo=IST)


def names(folder: Path) -> list[str]:
    return sorted(path.name for path in folder.iterdir())


def test_a_dump_is_stored_under_its_provider_with_a_utc_timestamp(tmp_path: Path) -> None:
    path = cache_dump(tmp_path, Provider.GROWW, b"exchange,symbol\n", at=AT)
    assert path == tmp_path / "groww" / "20260105T040015123456Z.csv"
    assert path.read_bytes() == b"exchange,symbol\n"
    assert names(path.parent) == [path.name]  # no temporary file is left behind


def test_only_the_newest_copies_are_kept_and_other_files_are_never_touched(tmp_path: Path) -> None:
    folder = tmp_path / "zerodha"
    folder.mkdir()
    unrelated = ["20260101T000000000000Z.csv.bak", "instruments.csv", "notes.txt"]
    for name in unrelated:
        (folder / name).write_bytes(b"keep me")
    (folder / "20250101T000000000000Z.csv").mkdir()  # a directory with a cache-like name
    written = [
        cache_dump(tmp_path, Provider.ZERODHA, bytes([n]), at=AT + timedelta(minutes=n)) for n in range(5)
    ]
    expected = sorted([*unrelated, "20250101T000000000000Z.csv", *(path.name for path in written[2:])])
    assert names(folder) == expected


def test_the_new_copy_is_kept_even_when_the_clock_went_back(tmp_path: Path) -> None:
    newer = [cache_dump(tmp_path, Provider.GROWW, b"x", at=AT + timedelta(days=n)) for n in (1, 2, 3)]
    older = cache_dump(tmp_path, Provider.GROWW, b"y", at=AT)
    assert names(tmp_path / "groww") == sorted([older.name, newer[1].name, newer[2].name])


def test_a_failed_write_leaves_no_partial_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    first = cache_dump(tmp_path, Provider.GROWW, b"old", at=AT)

    def fail(source: str, target: Path) -> None:
        raise OSError("disk full")

    monkeypatch.setattr(os, "replace", fail)
    with pytest.raises(OSError, match="disk full"):
        cache_dump(tmp_path, Provider.GROWW, b"new", at=AT + timedelta(minutes=1))
    assert names(tmp_path / "groww") == [first.name]
    assert first.read_bytes() == b"old"
