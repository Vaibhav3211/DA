from __future__ import annotations

from uuid import UUID, uuid4

import pytest

from app.domain.enums import Provider, SubscriptionMode
from app.market_data.subscriptions import Assignment, SkipReason, StreamAccount, WantedInstrument, assign

LTP, QUOTE, FULL = SubscriptionMode.LTP, SubscriptionMode.QUOTE, SubscriptionMode.FULL
KITE = StreamAccount(uuid4(), Provider.ZERODHA, "kite")
GROWW = StreamAccount(uuid4(), Provider.GROWW, "groww")
SPARE_KITE = uuid4()  # a Zerodha account that is not enabled
A, B, C = uuid4(), uuid4(), uuid4()


def want(
    instrument: UUID,
    provider: Provider = Provider.ZERODHA,
    mode: SubscriptionMode = QUOTE,
    account: UUID | None = None,
) -> WantedInstrument:
    return WantedInstrument(instrument, provider, account, mode)


def requests(result: Assignment) -> list[tuple[StreamAccount, dict[UUID, SubscriptionMode]]]:
    return [(request.account, dict(request.modes)) for request in result.requests]


def skips(result: Assignment) -> list[tuple[UUID, Provider, UUID | None, SkipReason]]:
    return [(s.instrument_id, s.provider, s.account_id, s.reason) for s in result.skipped]


def test_rows_go_to_the_enabled_account_of_their_provider() -> None:
    result = assign([KITE, GROWW], [want(A), want(B, Provider.GROWW), want(C, account=KITE.account_id)])

    assert requests(result) == [(KITE, {A: QUOTE, C: QUOTE}), (GROWW, {B: QUOTE})]
    assert result.skipped == ()


def test_an_instrument_is_subscribed_once_in_the_richest_mode() -> None:
    result = assign([KITE], [want(A, mode=LTP), want(B, mode=FULL), want(A, mode=FULL), want(B, mode=LTP)])

    assert list(result.requests[0].modes.items()) == [(A, FULL), (B, FULL)]


def test_rows_without_a_serving_account_are_skipped_once_per_provider_and_instrument() -> None:
    rows = [
        want(A, account=SPARE_KITE),
        want(A, account=SPARE_KITE, mode=FULL),
        want(B, Provider.GROWW),
        want(B, Provider.GROWW, account=uuid4()),
    ]

    result = assign([KITE], rows)

    assert requests(result) == [(KITE, {})]
    assert skips(result) == [
        (A, Provider.ZERODHA, SPARE_KITE, SkipReason.ACCOUNT_NOT_ENABLED),
        (B, Provider.GROWW, None, SkipReason.NO_ENABLED_ACCOUNT),
    ]


def test_a_skip_is_dropped_when_another_row_gets_the_instrument_from_that_provider() -> None:
    result = assign([KITE], [want(A, account=SPARE_KITE), want(A, mode=LTP)])

    assert requests(result) == [(KITE, {A: LTP})]
    assert result.skipped == ()


def test_another_provider_never_stands_in() -> None:
    result = assign([KITE], [want(A), want(A, Provider.GROWW)])

    assert requests(result) == [(KITE, {A: QUOTE})]
    assert skips(result) == [(A, Provider.GROWW, None, SkipReason.NO_ENABLED_ACCOUNT)]


def test_enabled_accounts_are_planned_without_instruments() -> None:
    assert requests(assign([KITE, GROWW], [])) == [(KITE, {}), (GROWW, {})]


def test_two_enabled_accounts_of_one_provider_are_rejected() -> None:
    with pytest.raises(ValueError, match="more than one enabled ZERODHA account"):
        assign([KITE, StreamAccount(uuid4(), Provider.ZERODHA, "second")], [])
