from __future__ import annotations

import asyncio
from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, cast
from uuid import UUID

import pytest
from prometheus_client import REGISTRY
from redis.exceptions import RedisError

from app.domain.enums import CandleFlag, ConnectionState, DataStatus, Provider
from app.domain.events import FeedStateChange
from app.domain.models import Candle, ProviderHealth, StreamHealth
from app.market_data import pipeline as pipeline_module
from app.market_data.candles.writer import CandleWriter
from app.market_data.pipeline import FeedChangePublisher, MarketDataPipeline, PipelineConfig
from app.providers.base import EventQueue, StateChange
from app.streaming.redis_bus import Batch, Keys, RedisBus, Streams
from tests.unit.market_data.test_candle_builder import ACCOUNT, ALPHA, M1, Feed, at, builder, event, metric

EVENTS = Streams.market_events(Provider.ZERODHA)
PARTIAL = Keys.partial_candle(Provider.ZERODHA, ALPHA, M1)


class FakeBus:
    """Applies writes like Redis would: stream entries are appended, keys are set or deleted."""

    def __init__(self) -> None:
        self.streams: defaultdict[str, list[Any]] = defaultdict(list)
        self.keys: dict[str, tuple[Any, float | None]] = {}
        self.failures: list[BaseException] = []
        self.writes = 0

    async def write(self, batch: Batch, *, maxlen: int | None = None) -> None:
        self._fail()
        self.writes += 1
        for stream, payload in batch.entries:
            self.streams[stream].append(payload)
        for key, value, ttl in batch.values:
            self.keys[key] = (value, ttl)
        for key in batch.deletes:
            self.keys.pop(key, None)

    async def publish(self, stream: str, payload: Any, *, maxlen: int | None = None) -> str:
        self._fail()
        self.streams[stream].append(payload)
        return f"{len(self.streams[stream])}-0"

    def _fail(self) -> None:
        if self.failures:
            raise self.failures.pop(0)


@dataclass
class FakeSource:
    provider: Provider = Provider.ZERODHA
    account_id: UUID | None = ACCOUNT
    queue: EventQueue = field(default_factory=lambda: EventQueue(Provider.ZERODHA, 100))
    streams: tuple[StreamHealth, ...] = ()

    async def health(self) -> ProviderHealth:
        return ProviderHealth(
            provider=self.provider,
            account_id=self.account_id,
            state=ConnectionState.CONNECTED,
            data_status=DataStatus.LIVE,
            streams=self.streams,
        )


class FakeWriter:
    def __init__(self) -> None:
        self.added: list[Candle] = []

    def add(self, candles: Iterable[Candle]) -> None:
        self.added.extend(candles)


@dataclass
class Clock:
    now: datetime
    elapsed: float = 0.0

    def __call__(self) -> datetime:
        return self.now

    def monotonic(self) -> float:
        return self.elapsed

    def advance(self, seconds: float) -> None:
        self.now += timedelta(seconds=seconds)
        self.elapsed += seconds


@dataclass
class Rig:
    source: FakeSource
    bus: FakeBus
    writer: FakeWriter
    clock: Clock
    pipeline: MarketDataPipeline


def rig(*, checkpoint: float = 0.0, idle: float = 0.25) -> Rig:
    source, bus, writer, clock = FakeSource(), FakeBus(), FakeWriter(), Clock(at("09:15:00"))
    config = PipelineConfig(
        quote_ttl_seconds=600,
        partial_interval_seconds=1,
        feed_status_interval_seconds=1,
        checkpoint_interval_seconds=checkpoint,
        lateness=timedelta(seconds=2),
        idle_seconds=idle,
    )
    pipeline = MarketDataPipeline(
        source,
        cast(RedisBus, bus),
        builder(Feed(at("09:14:00")), M1),
        cast(CandleWriter, writer),
        config,
        clock=clock,
        monotonic=clock.monotonic,
    )
    return Rig(source, bus, writer, clock, pipeline)


def stream(stream_id: str) -> StreamHealth:
    when = at("09:14:00")
    return StreamHealth(
        provider=Provider.ZERODHA,
        account_id=ACCOUNT,
        stream_id=stream_id,
        state=ConnectionState.CONNECTED,
        data_status=DataStatus.LIVE,
        state_since=when,
        updated_at=when,
    )


def sample(name: str, **labels: str) -> float:
    return REGISTRY.get_sample_value(name, labels) or 0.0


@pytest.fixture
def no_retry_delay(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(pipeline_module, "RETRY_DELAYS", (0.0, 0.0, 0.0))


async def test_batches_publish_events_merged_quotes_and_closed_candles() -> None:
    r = rig()
    published = metric("qt_market_events_published_total", event_type="QUOTE")

    assert await r.pipeline.process([event(at("09:15:10"), "100", volume=1000), event(at("09:15:20"), "101")])

    assert [e.last_price for e in r.bus.streams[EVENTS]] == [Decimal(100), Decimal(101)]
    quote, ttl = r.bus.keys[Keys.quote(Provider.ZERODHA, ALPHA)]
    assert (quote.last_price, quote.volume, ttl) == (Decimal(101), 1000, 600)  # volume kept from before
    assert metric("qt_market_events_published_total", event_type="QUOTE") == published + 2

    r.clock.now = at("09:16:02")  # bucket end plus lateness
    await r.pipeline.maintain()
    [closed] = r.bus.streams[Streams.CANDLES]
    assert (closed.close_price, closed.event_count, closed.is_closed) == (Decimal(101), 2, True)
    assert r.bus.keys[PARTIAL] == (closed, 60 + 300)
    assert r.writer.added == [closed]


async def test_a_backlog_keeps_buckets_open_until_their_events_are_processed() -> None:
    r = rig()
    await r.pipeline.process([event(at("09:15:30"), "100")])
    r.source.queue.put(event(at("09:15:59"), "102"))  # received in time, still queued
    r.clock.now = at("09:16:05")

    await r.pipeline.maintain()
    assert r.bus.streams[Streams.CANDLES] == []

    await r.pipeline.process(r.source.queue.drain(10))
    await r.pipeline.maintain()
    [closed] = r.bus.streams[Streams.CANDLES]
    assert (closed.event_count, closed.close_price) == (2, Decimal(102))


@pytest.mark.usefixtures("no_retry_delay")
async def test_redis_failures_are_retried_then_counted_while_candles_continue() -> None:
    r = rig()
    errors = sample("qt_redis_errors_total", operation="publish_events")
    lost_events = metric("qt_market_events_dropped_total", reason="publish_failed")
    lost_candles = sample("qt_candles_dropped_total", reason="publish_failed")

    r.bus.failures.append(RedisError("blip"))
    assert await r.pipeline.process([event(at("09:15:10"), "100")])
    r.bus.failures.extend(RedisError("down") for _ in range(4))
    assert not await r.pipeline.process([event(at("09:15:20"), "105")])
    r.clock.now = at("09:16:02")
    r.bus.failures.extend(OSError("down") for _ in range(4))
    await r.pipeline.maintain()

    assert [e.last_price for e in r.bus.streams[EVENTS]] == [Decimal(100)]
    assert sample("qt_redis_errors_total", operation="publish_events") == errors + 5
    assert metric("qt_market_events_dropped_total", reason="publish_failed") == lost_events + 1
    assert r.bus.streams[Streams.CANDLES] == []
    assert sample("qt_candles_dropped_total", reason="publish_failed") == lost_candles + 1
    assert [(c.close_price, c.event_count) for c in r.writer.added] == [(Decimal(105), 2)]


async def test_partials_and_feed_state_are_published_on_their_intervals() -> None:
    r = rig()
    r.source.streams = (stream("zerodha:a:0"), stream("zerodha:a:1"))
    r.clock.now = at("09:15:10") + timedelta(milliseconds=250)
    await r.pipeline.process([event(at("09:15:10"), "100")])
    await r.pipeline.maintain()

    partial, ttl = r.bus.keys[PARTIAL]
    assert (partial.close_price, partial.is_closed, ttl) == (Decimal(100), False, 360)
    state, state_ttl = r.bus.keys[Keys.feed_state("zerodha:a:0")]
    assert (state.processing_latency_ms, state_ttl) == (250.0, 5.0)

    r.source.streams = r.source.streams[:1]
    await r.pipeline.process([event(at("09:15:11"), "101")])
    writes = r.bus.writes
    r.clock.advance(0.5)
    await r.pipeline.maintain()
    assert r.bus.writes == writes  # nothing is due yet

    r.clock.advance(0.5)
    await r.pipeline.maintain()
    assert r.bus.keys[PARTIAL][0].close_price == Decimal(101)
    assert Keys.feed_state("zerodha:a:0") in r.bus.keys
    assert Keys.feed_state("zerodha:a:1") not in r.bus.keys  # the stream went away


async def test_a_closed_candle_does_not_replace_a_newer_forming_one() -> None:
    r = rig()
    r.clock.now = at("09:16:01")
    await r.pipeline.process([event(at("09:15:50"), "100"), event(at("09:16:01"), "101")])
    await r.pipeline.maintain()  # the 09:15 bucket waits out the lateness allowance

    r.clock.advance(1.5)
    await r.pipeline.maintain()

    [closed] = r.bus.streams[Streams.CANDLES]
    shown = r.bus.keys[PARTIAL][0]
    assert (closed.bucket_start, shown.bucket_start, shown.is_closed) == (
        at("09:15:00"),
        at("09:16:00"),
        False,
    )


async def test_forming_candles_are_checkpointed_on_their_interval() -> None:
    r = rig(checkpoint=60)
    await r.pipeline.process([event(at("09:15:10"), "100")])
    r.clock.advance(59)
    await r.pipeline.maintain()
    assert r.writer.added == []

    r.clock.advance(1)
    await r.pipeline.maintain()
    [checkpoint] = r.writer.added
    assert (checkpoint.bucket_start, checkpoint.is_closed) == (at("09:15:00"), False)
    assert r.bus.streams[Streams.CANDLES] == []  # the bucket stays open


async def test_stopping_publishes_the_backlog_and_saves_open_buckets() -> None:
    r = rig(idle=0.01)
    r.source.streams = (stream("zerodha:a:0"),)
    await r.pipeline.maintain()
    assert Keys.feed_state("zerodha:a:0") in r.bus.keys

    r.clock.now = at("09:16:15")
    r.pipeline.start()
    r.source.queue.put(event(at("09:15:10"), "100"))
    r.source.queue.put(event(at("09:16:10"), "101"))
    await asyncio.sleep(0)
    await r.pipeline.stop()

    assert not r.pipeline.running
    assert [e.last_price for e in r.bus.streams[EVENTS]] == [Decimal(100), Decimal(101)]
    [closed] = r.bus.streams[Streams.CANDLES]
    assert [(c.bucket_start, c.is_closed) for c in r.writer.added] == [
        (at("09:15:00"), True),
        (at("09:16:00"), False),
    ]
    assert closed == r.writer.added[0]
    assert CandleFlag.DISCONNECTED_DURING in r.writer.added[1].flags
    assert Keys.feed_state("zerodha:a:0") not in r.bus.keys


class RecordingObserver:
    def __init__(self, failure: Exception | None = None) -> None:
        self.changes: list[StateChange] = []
        self.failure = failure

    async def on_state_change(self, change: StateChange) -> None:
        self.changes.append(change)
        if self.failure is not None:
            raise self.failure


def change(state: ConnectionState, previous: ConnectionState | None) -> StateChange:
    return StateChange(
        provider=Provider.ZERODHA,
        account_id=ACCOUNT,
        stream_id="zerodha:a:0",
        previous=previous,
        state=state,
        reason="test",
        occurred_at=at("09:15:00"),
    )


async def test_state_changes_are_announced_and_recorded_independently() -> None:
    bus, inner = FakeBus(), RecordingObserver()
    publisher = FeedChangePublisher(cast(RedisBus, bus), inner)

    await publisher.on_state_change(change(ConnectionState.CONNECTING, None))
    bus.failures.append(RedisError("down"))
    await publisher.on_state_change(change(ConnectionState.CONNECTED, ConnectionState.CONNECTING))

    [announced] = bus.streams[Streams.FEED]
    assert isinstance(announced, FeedStateChange)
    assert (announced.previous_state, announced.state) == (ConnectionState.IDLE, ConnectionState.CONNECTING)
    assert [c.state for c in inner.changes] == [ConnectionState.CONNECTING, ConnectionState.CONNECTED]

    failing = FeedChangePublisher(cast(RedisBus, bus), RecordingObserver(RuntimeError("database down")))
    with pytest.raises(RuntimeError, match="database down"):
        await failing.on_state_change(change(ConnectionState.RECONNECTING, ConnectionState.CONNECTED))
    assert len(bus.streams[Streams.FEED]) == 2
