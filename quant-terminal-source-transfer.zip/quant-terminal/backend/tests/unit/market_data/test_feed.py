from __future__ import annotations

from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

from app.domain.enums import ConnectionState, Provider
from app.market_data.feed import FeedTracker, Periods
from app.providers.base import StateChange

T0 = datetime(2026, 1, 5, 4, 0, tzinfo=UTC)
ALPHA, BETA = uuid4(), uuid4()


def at(seconds: float) -> datetime:
    return T0 + timedelta(seconds=seconds)


def change(seconds: float, state: ConnectionState, stream: int = 0) -> StateChange:
    return StateChange(
        provider=Provider.SIMULATOR,
        account_id=None,
        stream_id=f"simulator:none:{stream}",
        previous=None,
        state=state,
        reason="test",
        occurred_at=at(seconds),
    )


def tracker(*changes: StateChange, subscribed: tuple[UUID, ...] = (ALPHA,)) -> FeedTracker:
    feed = FeedTracker()
    feed.note_subscriptions(subscribed, at(0))
    for item in changes:
        feed.on_state_change(item)
    return feed


def test_coverage_starts_when_the_feed_is_up_and_the_instrument_subscribed() -> None:
    feed = tracker(change(5, ConnectionState.CONNECTING), change(10, ConnectionState.CONNECTED))
    feed.note_subscriptions((ALPHA, BETA), at(20))

    assert feed.is_up
    assert feed.coverage_start(ALPHA, at(9)) is None
    assert feed.coverage_start(ALPHA, at(15)) == at(10)
    assert feed.coverage_start(BETA, at(15)) is None
    assert feed.coverage_start(BETA, at(25)) == at(20)
    assert feed.coverage_start(uuid4(), at(25)) is None
    assert feed.covered(ALPHA, at(10), at(30))
    assert not feed.covered(ALPHA, at(5), at(30))
    assert not feed.covered(BETA, at(10), at(30))
    assert not feed.interrupted(ALPHA, at(0), at(60))


def test_a_reconnect_breaks_coverage_and_interrupts_the_spans_it_falls_in() -> None:
    feed = tracker(
        change(10, ConnectionState.CONNECTED),
        change(30, ConnectionState.RECONNECTING),
        change(40, ConnectionState.CONNECTED),
    )

    assert feed.coverage_start(ALPHA, at(29)) == at(10)
    assert feed.coverage_start(ALPHA, at(35)) is None
    assert feed.coverage_start(ALPHA, at(45)) == at(40)
    assert feed.covered(ALPHA, at(10), at(30))
    assert not feed.covered(ALPHA, at(20), at(45))
    assert feed.interrupted(ALPHA, at(30), at(31))
    assert feed.interrupted(ALPHA, at(25), at(35))
    assert not feed.interrupted(ALPHA, at(20), at(30))  # the drop at 30 belongs to the next span
    assert not feed.interrupted(ALPHA, at(35), at(60))


def test_streams_still_starting_are_not_an_outage_but_any_failed_stream_is() -> None:
    feed = tracker(change(10, ConnectionState.CONNECTED), change(20, ConnectionState.IDLE, stream=1))
    seen = [feed.is_up]
    feed.on_state_change(change(21, ConnectionState.CONNECTING, stream=1))
    seen.append(feed.is_up)
    feed.on_state_change(change(30, ConnectionState.AUTH_REQUIRED, stream=1))
    seen.append(feed.is_up)
    feed.on_state_change(change(40, ConnectionState.STOPPED, stream=1))  # stopped streams are forgotten
    seen.append(feed.is_up)
    feed.note_disconnect(at(50))
    seen.append(feed.is_up)

    assert seen == [True, True, False, True, False]
    assert feed.coverage_start(ALPHA, at(45)) == at(40)
    assert feed.interrupted(ALPHA, at(45), at(55))


def test_unsubscribing_ends_coverage_and_resubscribing_starts_it_again() -> None:
    feed = tracker(change(10, ConnectionState.CONNECTED), subscribed=(ALPHA, BETA))
    feed.note_subscriptions((BETA,), at(20))
    feed.note_subscriptions((ALPHA, BETA), at(30))

    assert feed.coverage_start(ALPHA, at(25)) is None
    assert feed.coverage_start(ALPHA, at(35)) == at(30)
    assert feed.interrupted(ALPHA, at(15), at(25))
    assert not feed.interrupted(BETA, at(15), at(25))
    assert not feed.covered(ALPHA, at(10), at(35))


def test_forgotten_history_makes_answers_conservative() -> None:
    feed = FeedTracker(retention=timedelta(seconds=100))
    feed.note_subscriptions((ALPHA,), at(0))
    feed.on_state_change(change(10, ConnectionState.CONNECTED))
    feed.on_state_change(change(20, ConnectionState.DISCONNECTED))
    feed.on_state_change(change(200, ConnectionState.CONNECTED))  # prunes the period that ended at 20

    assert feed.coverage_start(ALPHA, at(15)) is None
    assert feed.interrupted(ALPHA, at(15), at(16))
    assert feed.interrupted(ALPHA, at(20), at(300))
    assert not feed.interrupted(ALPHA, at(21), at(300))
    assert feed.coverage_start(ALPHA, at(250)) == at(200)


def test_periods_stay_ordered_and_prune_the_oldest_beyond_the_limit() -> None:
    periods = Periods()
    periods.open(at(10))
    periods.close(at(20))
    periods.open(at(15))  # a clock step back never makes periods overlap
    periods.close(at(30))
    periods.open(at(40))

    assert periods.starts == [at(10), at(20), at(40)]
    assert periods.ended_within(at(25), at(31))
    assert not periods.ended_within(at(31), at(100))
    assert periods.prune(at(0), keep=2) == at(20)
    assert periods.starts == [at(20), at(40)]
    assert periods.prune(at(100), keep=10) == at(30)
    assert periods.starts == [at(40)]
    assert periods.is_open
