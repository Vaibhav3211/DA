from __future__ import annotations

from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal
from uuid import UUID, uuid4

import pytest
from prometheus_client import REGISTRY

from app.core.config import CandleAnchor
from app.domain.enums import (
    CandleFlag,
    CandleInterval,
    ConnectionState,
    DataStatus,
    EventType,
    Exchange,
    Provider,
    Segment,
    VolumeSemantics,
)
from app.domain.models import NormalizedMarketEvent
from app.market_data.candles.builder import CandleBuilder, Slot, bucket_for
from app.market_data.feed import FeedTracker
from app.providers.base import StateChange
from tests.unit.market_data.test_calendar import MON, SAT, TUE, WED, calendar, ist

ALPHA, BETA, ACCOUNT = uuid4(), uuid4(), uuid4()
M1, M5, H1, D1 = CandleInterval.M1, CandleInterval.M5, CandleInterval.H1, CandleInterval.D1
F = CandleFlag
REASONS = ("no_price", "outside_session")


def at(clock: str, day: date = MON) -> datetime:
    return ist(day, time.fromisoformat(clock))


class Feed:
    """Feed coverage: connected since ``since`` with the instruments (default ALPHA) subscribed."""

    def __init__(self, since: datetime, *instruments: UUID) -> None:
        self.tracker = FeedTracker()
        self.tracker.note_subscriptions(instruments or (ALPHA,), since)
        self.set(since, ConnectionState.CONNECTED)

    def set(self, when: datetime, state: ConnectionState) -> None:
        self.tracker.on_state_change(
            StateChange(
                provider=Provider.ZERODHA,
                account_id=ACCOUNT,
                stream_id="zerodha:test:0",
                previous=None,
                state=state,
                reason="test",
                occurred_at=when,
            )
        )


def builder(
    feed: Feed, *intervals: CandleInterval, anchor: CandleAnchor = CandleAnchor.SESSION
) -> CandleBuilder:
    return CandleBuilder(
        Provider.ZERODHA,
        intervals or (M1,),
        calendar(),
        feed.tracker,
        anchor=anchor,
        lateness=timedelta(seconds=2),
    )


def event(
    when: datetime,
    price: str | None,
    *,
    instrument: UUID = ALPHA,
    volume: int | None = None,
    exchange: Exchange = Exchange.NSE,
    status: DataStatus = DataStatus.LIVE,
    stamped: bool = True,
) -> NormalizedMarketEvent:
    return NormalizedMarketEvent(
        event_id=uuid4(),
        provider=Provider.ZERODHA,
        account_id=ACCOUNT,
        exchange=exchange,
        segment=Segment.CASH,
        instrument_id=instrument,
        provider_instrument_token="1",
        symbol="ALPHA",
        event_type=EventType.QUOTE,
        received_at=when,
        processed_at=when,
        data_status=status,
        last_price=None if price is None else Decimal(price),
        volume=volume,
        volume_semantics=VolumeSemantics.UNAVAILABLE if volume is None else VolumeSemantics.CUMULATIVE_DAY,
        source_timestamp=when if stamped else None,
    )


def metric(name: str, **labels: str) -> float:
    return REGISTRY.get_sample_value(name, {"provider": Provider.ZERODHA.value, **labels}) or 0.0


@pytest.mark.parametrize(
    ("clock", "interval", "anchor", "bounds"),
    [
        ("09:15:00", M1, CandleAnchor.SESSION, ("09:15", "09:16")),
        ("15:29:59", CandleInterval.M3, CandleAnchor.SESSION, ("15:27", "15:30")),
        ("10:14:59", H1, CandleAnchor.SESSION, ("09:15", "10:15")),
        ("15:20:00", H1, CandleAnchor.SESSION, ("15:15", "15:30")),  # the last bucket ends at the close
        ("09:20:00", H1, CandleAnchor.CLOCK, ("09:15", "10:00")),  # clock buckets start at the open
        ("10:30:00", H1, CandleAnchor.CLOCK, ("10:00", "11:00")),
        ("12:00:00", D1, CandleAnchor.CLOCK, ("09:15", "15:30")),
    ],
)
def test_buckets_follow_the_session(
    clock: str, interval: CandleInterval, anchor: CandleAnchor, bounds: tuple[str, str]
) -> None:
    slot = bucket_for(calendar(), Exchange.NSE, at(clock), interval, anchor)

    assert slot == Slot(at(bounds[0]), at(bounds[1]), MON, at("09:15"))


@pytest.mark.parametrize("when", [at("09:14:59"), at("15:30"), at("11:00", WED), at("11:00", SAT)])
def test_there_are_no_buckets_outside_the_session(when: datetime) -> None:
    assert bucket_for(calendar(), Exchange.NSE, when, M1, CandleAnchor.SESSION) is None


def test_unknown_hours_follow_the_local_day_and_the_simulator_trades_around_the_clock() -> None:
    days = calendar()
    sim_time = datetime(2026, 1, 10, 23, 59, 30, tzinfo=UTC)  # a Saturday
    sim_day = datetime(2026, 1, 10, tzinfo=UTC)

    assert bucket_for(days, Exchange.MCX, at("23:10"), H1, CandleAnchor.SESSION) == Slot(
        at("23:00"), at("00:00", TUE), MON, None
    )
    assert bucket_for(days, Exchange.MCX, at("01:00"), D1, CandleAnchor.SESSION) == Slot(
        at("00:00"), at("00:00", TUE), MON, None
    )
    assert bucket_for(days, Exchange.SIM, sim_time, M1, CandleAnchor.SESSION) == Slot(
        sim_time.replace(second=0), sim_day + timedelta(days=1), sim_day.date(), sim_day
    )

    candles = builder(Feed(at("08:00")))
    candles.add(event(at("23:10"), "50", exchange=Exchange.MCX))
    [candle] = candles.partials()
    assert candle.flags == (F.VOLUME_UNAVAILABLE, F.OUTSIDE_SESSION)


def test_a_candle_takes_open_and_close_by_event_time_whatever_the_arrival_order() -> None:
    candles = builder(Feed(at("09:00")))
    skipped = {reason: metric("qt_candle_events_skipped_total", reason=reason) for reason in REASONS}
    for clock, price in [("09:20:10", "101"), ("09:20:05", "100"), ("09:20:30", "104"), ("09:20:50", "102")]:
        candles.add(event(at(clock), price))
    candles.add(event(at("09:20:20"), "99", status=DataStatus.DELAYED))
    candles.add(event(at("09:20:40"), "103", stamped=False))
    candles.add(event(at("09:20:45"), None))
    candles.add(event(at("15:45"), "100"))

    assert candles.close_due(at("09:21:01")) == []
    [candle] = candles.close_due(at("09:21:02"))
    prices = (candle.open_price, candle.high_price, candle.low_price, candle.close_price)
    assert prices == (Decimal(100), Decimal(104), Decimal(99), Decimal(102))
    assert (candle.first_event_at, candle.last_event_at, candle.event_count) == (
        at("09:20:05"),
        at("09:20:50"),
        6,
    )
    assert (candle.is_closed, candle.is_complete, candle.data_status) == (True, True, DataStatus.DELAYED)
    assert (candle.volume, candle.flags) == (None, (F.VOLUME_UNAVAILABLE, F.RECEIVE_TIME_BASIS))
    assert {
        reason: metric("qt_candle_events_skipped_total", reason=reason) - count
        for reason, count in skipped.items()
    } == dict.fromkeys(REASONS, 1.0)


def test_late_events_are_rejected_and_revise_the_last_closed_candle_once() -> None:
    candles = builder(Feed(at("09:00")), M1, M5)
    candles.add(event(at("09:20:10"), "100"))
    [closed] = candles.close_due(at("09:21:02"))
    late = metric("qt_candle_late_events_total")

    candles.add(event(at("09:20:59"), "90"))  # too late for 09:20, still inside the open 09:20 5m bucket
    candles.add(event(at("09:20:58"), "91"))
    candles.add(event(at("09:19:30"), "80"))  # its buckets closed (unseen) before the horizon

    assert metric("qt_candle_late_events_total") == late + 3
    [revision] = candles.take_revisions()
    assert revision == closed.model_copy(
        update={"flags": (F.LATE_EVENTS_IGNORED, F.VOLUME_UNAVAILABLE), "revision": 1}
    )
    assert candles.take_revisions() == []
    [five] = candles.close_due(at("09:25:02"))
    assert (five.interval, five.low_price, five.close_price, five.event_count) == (
        M5,
        Decimal(90),
        Decimal(90),
        3,
    )


def test_feed_coverage_marks_partial_gapped_and_interrupted_candles() -> None:
    feed = Feed(at("09:00"))
    candles = builder(feed)
    candles.add(event(at("09:20:10"), "100"))
    feed.set(at("09:20:30"), ConnectionState.RECONNECTING)
    feed.set(at("09:22:40"), ConnectionState.CONNECTED)
    feed.tracker.note_subscriptions((ALPHA, BETA), at("09:22:50"))
    candles.add(event(at("09:22:45"), "101"))
    candles.add(event(at("09:22:55"), "50", instrument=BETA))
    candles.add(event(at("09:23:10"), "102"))

    dropped, resumed, joined, steady = candles.close_due(at("09:24:02"))

    assert (dropped.flags[0], dropped.data_status) == (F.DISCONNECTED_DURING, DataStatus.RECONNECTING)
    assert resumed.flags[:2] == (F.PARTIAL_START, F.GAP_BEFORE)  # reconnected mid-bucket, 09:21 is missing
    assert (joined.instrument_id, joined.flags[:2]) == (BETA, (F.PARTIAL_START, F.GAP_BEFORE))
    assert (steady.bucket_start, steady.is_complete, steady.data_status) == (
        at("09:23"),
        True,
        DataStatus.LIVE,
    )
    assert not resumed.is_complete


def test_volume_is_the_cumulative_increase_and_unknown_when_it_cannot_be_derived() -> None:
    feed = Feed(at("09:00"))
    candles = builder(feed, M1, D1)
    for clock, volume in [("09:15:05", 1000), ("09:15:40", 1500), ("09:15:30", 1200), ("09:16:10", 1800)]:
        candles.add(event(at(clock), "100", volume=volume))
    candles.add(event(at("09:17:10"), "100", volume=1700))  # decreased
    feed.set(at("09:17:30"), ConnectionState.RECONNECTING)
    feed.set(at("09:18:20"), ConnectionState.CONNECTED)
    candles.add(event(at("09:18:30"), "100", volume=2500))  # coverage broke since the previous value
    candles.add(event(at("09:19:10"), "100", volume=2600))
    candles.add(event(at("09:20:10"), "100"))  # no volume reported
    feed.tracker.note_subscriptions((ALPHA, BETA), at("09:30"))
    candles.add(event(at("09:30:05"), "50", instrument=BETA, volume=5000))  # first value after the open

    minutes = candles.close_due(at("09:31:02"))
    daily = {candle.instrument_id: candle for candle in candles.partials() if candle.interval is D1}

    assert [(c.volume, [f for f in c.flags if f.name.startswith("VOLUME")]) for c in minutes] == [
        (1500, []),
        (300, []),
        (None, [F.VOLUME_INCOMPLETE, F.VOLUME_RESET]),
        (None, [F.VOLUME_INCOMPLETE]),
        (100, []),
        (None, [F.VOLUME_UNAVAILABLE]),
        (None, [F.VOLUME_INCOMPLETE]),
    ]
    assert (daily[ALPHA].volume, daily[ALPHA].flags) == (2600, (F.DISCONNECTED_DURING, F.VOLUME_RESET))
    # The account's feed dropped during BETA's session too, before BETA was subscribed.
    assert (daily[BETA].volume, daily[BETA].flags) == (5000, (F.PARTIAL_START, F.DISCONNECTED_DURING))


def test_partials_report_the_newest_forming_candle_of_changed_series() -> None:
    candles = builder(Feed(at("09:00")), M1, M5)
    candles.add(event(at("09:20:10"), "100"))
    candles.add(event(at("09:21:01"), "101"))

    partials = {(c.interval, c.bucket_start, c.is_closed) for c in candles.partials()}

    assert partials == {(M1, at("09:21"), False), (M5, at("09:20"), False)}
    assert candles.partials() == []


def test_forming_candles_resume_after_a_restart() -> None:
    first = builder(Feed(at("09:00")), M1, D1)
    first.add(event(at("09:20:10"), "100", volume=1000))
    first.add(event(at("09:20:20"), "105", volume=1100))

    checkpoint = first.checkpoint()  # keeps the buckets open
    assert first.open_buckets == 2
    flushed = first.flush_open()

    assert checkpoint == flushed
    assert {(c.interval, c.is_closed, c.data_status, c.volume) for c in flushed} == {
        (M1, False, DataStatus.DISCONNECTED, 1000 + 100),
        (D1, False, DataStatus.DISCONNECTED, 1100),
    }
    assert all(F.DISCONNECTED_DURING in c.flags for c in flushed)
    assert (first.open_buckets, first.flush_open()) == (0, [])

    second = builder(Feed(at("09:20:40")), M1, D1)
    moved = flushed[0].model_copy(update={"bucket_end": at("09:20:30")})  # no longer a valid bucket
    assert second.seed([*flushed, moved]) == 2
    second.add(event(at("09:20:50"), "98", volume=1300))
    [minute] = second.close_due(at("09:21:02"))
    [daily] = second.partials()

    prices = (minute.open_price, minute.high_price, minute.low_price, minute.close_price)
    assert prices == (Decimal(100), Decimal(105), Decimal(98), Decimal(98))
    assert (minute.event_count, minute.volume, F.VOLUME_INCOMPLETE in minute.flags) == (3, None, True)
    assert (daily.volume, daily.data_status, daily.event_count) == (1300, DataStatus.DISCONNECTED, 3)
    assert F.DISCONNECTED_DURING in daily.flags
