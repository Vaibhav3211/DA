from __future__ import annotations

from collections.abc import AsyncIterator, Mapping, Sequence
from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any, cast
from uuid import UUID, uuid4

import pytest
from prometheus_client import REGISTRY

from app.domain.enums import CandleInterval, DataStatus, Exchange, Provider, Segment
from app.domain.models import Candle
from app.market_data.candles import writer as writer_module
from app.market_data.candles.writer import CandleWriter
from app.persistence.database import Database

START = datetime(2026, 1, 5, 3, 45, tzinfo=UTC)


class FakeDatabase:
    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        yield None


class FakeStore:
    """Stands in for ``upsert_candles``: records the rows, or raises the queued failures first."""

    def __init__(self) -> None:
        self.rows: list[Mapping[str, Any]] = []
        self.failures: list[BaseException] = []

    async def __call__(self, session: object, rows: Sequence[Mapping[str, Any]]) -> None:
        if self.failures:
            raise self.failures.pop(0)
        self.rows.extend(rows)

    def closes(self) -> list[tuple[UUID, Decimal]]:
        return [(row["instrument_id"], row["close_price"]) for row in self.rows]


@pytest.fixture
def store(monkeypatch: pytest.MonkeyPatch) -> FakeStore:
    fake = FakeStore()
    monkeypatch.setattr(writer_module, "upsert_candles", fake)
    return fake


def writer(max_pending: int = 100) -> CandleWriter:
    return CandleWriter(cast(Database, FakeDatabase()), interval_seconds=60, max_pending=max_pending)


def candle(instrument_id: UUID, close: str = "100", *, closed: bool = True) -> Candle:
    price = Decimal(close)
    return Candle(
        provider=Provider.ZERODHA,
        account_id=None,
        instrument_id=instrument_id,
        symbol="ALPHA",
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        interval=CandleInterval.M1,
        bucket_start=START,
        bucket_end=START + timedelta(minutes=1),
        open_price=price,
        high_price=price,
        low_price=price,
        close_price=price,
        volume=None,
        event_count=1,
        is_closed=closed,
        data_status=DataStatus.LIVE,
        first_event_at=START,
        last_event_at=START,
    )


def dropped(reason: str) -> float:
    return REGISTRY.get_sample_value("qt_candles_dropped_total", {"reason": reason}) or 0.0


async def test_a_failed_flush_keeps_the_rows_and_newer_versions_replace_them(store: FakeStore) -> None:
    a, b = uuid4(), uuid4()
    candles = writer()
    candles.add([candle(a, "100"), candle(b)])
    store.failures.append(OSError("database unreachable"))

    with pytest.raises(OSError, match="unreachable"):
        await candles.flush()
    candles.add([candle(a, "101")])

    assert candles.pending == 2
    assert await candles.flush() == 2
    assert store.closes() == [(b, Decimal(100)), (a, Decimal(101))]
    assert candles.pending == 0


async def test_a_full_backlog_drops_the_oldest_rows(store: FakeStore) -> None:
    oldest, older, newer, newest = uuid4(), uuid4(), uuid4(), uuid4()
    candles = writer(max_pending=2)
    before = dropped("persist_backlog")

    candles.add([candle(oldest, closed=False), candle(older), candle(newer)])
    candles.add([candle(newest)])
    await candles.flush()

    assert [instrument for instrument, _ in store.closes()] == [newer, newest]
    assert dropped("persist_backlog") == before + 1  # forming candles are not counted


async def test_closing_writes_what_is_pending_or_counts_the_loss(store: FakeStore) -> None:
    a, b = uuid4(), uuid4()
    saved = writer()
    saved.start()
    saved.add([candle(a)])
    await saved.close()
    assert store.closes() == [(a, Decimal(100))]

    lost = writer()
    lost.add([candle(a), candle(b, closed=False)])
    store.failures.append(OSError("database unreachable"))
    before = dropped("persist_failed")
    await lost.close()
    assert (lost.pending, dropped("persist_failed")) == (0, before + 1)
