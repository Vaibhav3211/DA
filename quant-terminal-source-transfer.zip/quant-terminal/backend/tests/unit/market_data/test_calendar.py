from __future__ import annotations

from datetime import UTC, date, datetime, time, timedelta
from zoneinfo import ZoneInfo

import pytest
from structlog.testing import capture_logs

from app.domain.enums import CalendarOverrideKind, Exchange, MarketSessionState
from app.market_data.calendars.loader import load_library_schedules
from app.market_data.calendars.service import (
    CalendarOverride,
    DayKind,
    ExchangeSpec,
    LibrarySchedule,
    MarketCalendar,
)

IST = ZoneInfo("Asia/Kolkata")
OPEN, CLOSE = time(9, 15), time(15, 30)
MON, TUE, WED, THU, FRI, SAT = (date(2026, 1, day) for day in range(5, 11))
PUBLISHED_UNTIL = date(2026, 1, 16)
LATER_MON, LATER_SAT = date(2026, 1, 19), date(2026, 1, 24)


def ist(day: date, at: time) -> datetime:
    return datetime.combine(day, at, tzinfo=IST).astimezone(UTC)


# Two published weeks; the first Wednesday is a holiday.
SCHEDULE = LibrarySchedule(
    sessions={
        day: (ist(day, OPEN), ist(day, CLOSE))
        for day in (MON, TUE, THU, FRI, *(date(2026, 1, day) for day in range(12, 17)))
    },
    first_session=MON,
    last_session=PUBLISHED_UNTIL,
    weekmask="1111100",
    regular_open=OPEN,
    regular_close=CLOSE,
)
SPECS = (
    ExchangeSpec(Exchange.NSE, IST, "XBOM"),
    ExchangeSpec(Exchange.BSE, IST, "XBOM"),
    ExchangeSpec(Exchange.MCX, IST),  # no published calendar
    ExchangeSpec(Exchange.SIM, ZoneInfo("UTC")),
)


def calendar(*overrides: CalendarOverride, extend: bool = True) -> MarketCalendar:
    return MarketCalendar(SPECS, {"XBOM": SCHEDULE}, overrides, extend_beyond_coverage=extend)


@pytest.mark.parametrize(
    ("at", "state"),
    [
        (time(8, 59), MarketSessionState.CLOSED),
        (time(9, 0), MarketSessionState.PRE_OPEN),
        (time(9, 15), MarketSessionState.OPEN),
        (time(15, 29, 59), MarketSessionState.OPEN),
        (time(15, 30), MarketSessionState.POST_CLOSE),
        (time(16, 0), MarketSessionState.CLOSED),
    ],
)
def test_a_published_session_moves_through_its_states(at: time, state: MarketSessionState) -> None:
    status = calendar().status(Exchange.NSE, ist(MON, at))

    assert status.state is state
    assert (status.day.kind, status.day.verified, status.day.special) == (DayKind.SESSION, True, False)
    assert (status.day.open_at, status.day.close_at) == (ist(MON, OPEN), ist(MON, CLOSE))


def test_exchange_days_follow_the_exchange_timezone() -> None:
    late_monday_utc = datetime(2026, 1, 5, 20, 0, tzinfo=UTC)  # 01:30 on Tuesday in India

    assert calendar().trading_day_at(Exchange.NSE, late_monday_utc).session_date == TUE
    assert calendar().trading_day_at(Exchange.SIM, late_monday_utc).session_date == MON


def test_unpublished_weekdays_are_holidays_and_weekends_are_closed() -> None:
    markets = calendar()

    holiday = markets.status(Exchange.NSE, ist(WED, time(11)))
    weekend = markets.status(Exchange.BSE, ist(SAT, time(11)))

    assert (holiday.state, holiday.day.kind, holiday.day.open_at) == (
        MarketSessionState.HOLIDAY,
        DayKind.HOLIDAY,
        None,
    )
    assert (weekend.state, weekend.day.kind, weekend.day.verified) == (
        MarketSessionState.CLOSED,
        DayKind.WEEKEND,
        True,
    )


def test_overrides_add_special_sessions_and_holidays() -> None:
    muhurat = CalendarOverride(
        Exchange.NSE, SAT, CalendarOverrideKind.SPECIAL_SESSION, time(18, 0), time(19, 15)
    )
    regular_hours = CalendarOverride(Exchange.BSE, SAT, CalendarOverrideKind.SPECIAL_SESSION)
    closed = CalendarOverride(Exchange.NSE, TUE, CalendarOverrideKind.HOLIDAY)
    markets = calendar(muhurat, regular_hours, closed)

    special = markets.status(Exchange.NSE, ist(SAT, time(18, 30)))
    assert (special.state, special.day.special) == (MarketSessionState.OPEN, True)
    assert (special.day.open_at, special.day.close_at) == (ist(SAT, time(18, 0)), ist(SAT, time(19, 15)))
    assert markets.trading_day(Exchange.BSE, SAT).open_at == ist(SAT, OPEN)
    holiday = markets.status(Exchange.NSE, ist(TUE, time(11)))
    assert (holiday.state, holiday.day.special) == (MarketSessionState.HOLIDAY, True)
    assert markets.status(Exchange.BSE, ist(TUE, time(11))).state is MarketSessionState.OPEN


@pytest.mark.parametrize(
    "override",
    [
        CalendarOverride(Exchange.NSE, SAT, CalendarOverrideKind.SPECIAL_SESSION, time(19), time(18)),
        CalendarOverride(Exchange.MCX, SAT, CalendarOverrideKind.SPECIAL_SESSION),  # no regular hours
    ],
)
def test_special_sessions_without_usable_hours_are_unknown(override: CalendarOverride) -> None:
    day = calendar(override).trading_day(override.exchange, SAT)

    assert (day.kind, day.special, day.verified) == (DayKind.UNKNOWN, True, False)


def test_replacing_overrides_forgets_answers_already_given() -> None:
    markets = calendar()
    assert markets.trading_day(Exchange.NSE, TUE).kind is DayKind.SESSION

    markets.set_overrides([CalendarOverride(Exchange.NSE, TUE, CalendarOverrideKind.HOLIDAY)])

    assert markets.trading_day(Exchange.NSE, TUE).kind is DayKind.HOLIDAY


def test_regular_hours_are_assumed_but_unverified_past_the_published_calendar() -> None:
    markets = calendar()

    weekday = markets.trading_day(Exchange.NSE, LATER_MON)
    weekend = markets.trading_day(Exchange.NSE, LATER_SAT)

    assert (weekday.kind, weekday.verified) == (DayKind.SESSION, False)
    assert (weekday.open_at, weekday.close_at) == (ist(LATER_MON, OPEN), ist(LATER_MON, CLOSE))
    assert (weekend.kind, weekend.verified) == (DayKind.WEEKEND, False)
    assert markets.coverage() == {Exchange.NSE: PUBLISHED_UNTIL, Exchange.BSE: PUBLISHED_UNTIL}


def test_without_extension_days_past_the_published_calendar_are_unknown() -> None:
    markets = calendar(extend=False)

    assert markets.trading_day(Exchange.NSE, LATER_MON).kind is DayKind.UNKNOWN
    assert markets.status(Exchange.NSE, ist(LATER_MON, time(11))).state is MarketSessionState.UNKNOWN


@pytest.mark.parametrize(
    ("exchange", "day"),
    [
        (Exchange.NSE, date(2026, 1, 2)),  # before the first published session
        (Exchange.MCX, MON),  # no calendar at all
    ],
)
def test_days_no_calendar_describes_are_unknown(exchange: Exchange, day: date) -> None:
    trading_day = calendar().trading_day(exchange, day)

    assert (trading_day.kind, trading_day.verified) == (DayKind.UNKNOWN, False)


def test_unconfigured_exchanges_are_unknown() -> None:
    markets = MarketCalendar([], {})

    assert markets.trading_day(Exchange.NSE, MON).kind is DayKind.UNKNOWN
    assert markets.timezone(Exchange.NSE) == ZoneInfo("UTC")


def test_the_simulator_trades_around_the_clock() -> None:
    markets = calendar()
    for at in (datetime(2026, 1, 10, 0, 0, tzinfo=UTC), datetime(2026, 1, 10, 23, 59, 59, tzinfo=UTC)):
        status = markets.status(Exchange.SIM, at)
        assert (status.state, status.day.kind) == (MarketSessionState.OPEN, DayKind.SESSION)
        assert status.day.close_at == datetime(2026, 1, 11, tzinfo=UTC)


@pytest.mark.parametrize(
    ("exchanges", "at", "expected"),
    [
        ({Exchange.NSE, Exchange.MCX}, ist(MON, time(11)), True),  # one open exchange is enough
        ({Exchange.NSE, Exchange.MCX}, ist(MON, time(17)), None),  # MCX might be trading
        ({Exchange.NSE, Exchange.BSE}, ist(MON, time(17)), False),
        ({Exchange.NSE}, ist(WED, time(11)), False),
        (set(), ist(MON, time(11)), False),
    ],
)
def test_streams_are_in_session_when_any_of_their_exchanges_is(
    exchanges: set[Exchange], at: datetime, expected: bool | None
) -> None:
    assert calendar().session_open(exchanges, at) is expected


def test_the_xbom_library_calendar_loads_and_unknown_codes_are_skipped() -> None:
    with capture_logs() as logs:
        schedules = load_library_schedules(["XBOM", "NO-SUCH-CALENDAR"])

    xbom = schedules["XBOM"]
    assert set(schedules) == {"XBOM"}
    assert [entry["event"] for entry in logs] == ["calendar_load_failed"]
    assert (xbom.weekmask, xbom.regular_open, xbom.regular_close) == ("1111100", OPEN, CLOSE)
    assert xbom.sessions[date(2024, 1, 2)] == (ist(date(2024, 1, 2), OPEN), ist(date(2024, 1, 2), CLOSE))
    assert date(2024, 1, 26) not in xbom.sessions  # Republic Day
    assert xbom.last_session - xbom.first_session > timedelta(days=365)
