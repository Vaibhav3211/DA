from __future__ import annotations

from collections.abc import Callable, Collection, Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any, cast
from uuid import UUID, uuid4

import pytest

from app.domain.enums import (
    CandleFlag,
    CandleInterval,
    ConnectionState,
    DataStatus,
    Exchange,
    InstrumentType,
    Provider,
    Segment,
)
from app.domain.events import CommandType, WorkerCommand
from app.domain.models import Candle, ProviderHealth, ProviderInstrument
from app.market_data import pipeline as pipeline_module
from app.market_data.candles.store import Listing
from app.market_data.candles.writer import CandleWriter
from app.market_data.manager import ConnectionManager
from app.market_data.subscriptions import (
    AccountPlan,
    IdleAccount,
    Skipped,
    SkipReason,
    StreamAccount,
    SubscriptionPlan,
)
from app.providers.base import EventQueue, StateChange
from app.providers.capabilities import default_capabilities
from app.providers.errors import ProviderNotEnabledError, SubscriptionCapacityError
from app.streaming.redis_bus import RedisBus
from tests.conftest import build_settings
from tests.unit.market_data.test_calendar import calendar
from tests.unit.market_data.test_candle_builder import ACCOUNT, ALPHA, BETA, M1, at, event
from tests.unit.market_data.test_pipeline import Clock, FakeBus

KITE = StreamAccount(ACCOUNT, Provider.ZERODHA, "kite")
GROWW = StreamAccount(uuid4(), Provider.GROWW, "groww")


@pytest.fixture(autouse=True)
def quick_stop(monkeypatch: pytest.MonkeyPatch) -> None:
    """Pipelines stop without waiting out their idle poll (what is queued is still processed)."""
    monkeypatch.setattr(pipeline_module, "_STOP_GRACE_SECONDS", 0.0)


def listing(instrument_id: UUID, provider: Provider) -> ProviderInstrument:
    return ProviderInstrument(
        instrument_id=instrument_id,
        provider=provider,
        provider_token=instrument_id.hex[:8],
        exchange_token=None,
        provider_symbol="ALPHA",
        provider_exchange="NSE",
        provider_segment="NSE",
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        instrument_type=InstrumentType.EQUITY,
        symbol="ALPHA",
    )


def plan(account: StreamAccount, *instruments: UUID, **capabilities: Any) -> AccountPlan:
    return AccountPlan(
        account,
        default_capabilities(account.provider).model_copy(update=capabilities),
        tuple(listing(instrument_id, account.provider) for instrument_id in instruments),
    )


def fields(account: StreamAccount) -> dict[str, str]:
    return {"provider": account.provider.value, "account_id": str(account.account_id), "label": account.label}


def command(kind: CommandType, account: StreamAccount | None = None) -> WorkerCommand:
    if account is None:
        return WorkerCommand(type=kind)
    return WorkerCommand(type=kind, provider=account.provider, account_id=account.account_id)


class FakePlanner:
    def __init__(self, *accounts: AccountPlan) -> None:
        self.result: SubscriptionPlan | Exception = SubscriptionPlan(accounts)
        self.calls = 0

    def set(
        self, *accounts: AccountPlan, idle: tuple[IdleAccount, ...] = (), skipped: tuple[Skipped, ...] = ()
    ) -> None:
        self.result = SubscriptionPlan(accounts, idle, skipped)

    async def plan(self) -> SubscriptionPlan:
        self.calls += 1
        if isinstance(self.result, Exception):
            raise self.result
        return self.result


class FakeAdapter:
    """Records what it was asked to do in the shared call log; connecting brings its stream up."""

    def __init__(
        self,
        plan: AccountPlan,
        listener: Callable[[StateChange], None],
        clock: Clock,
        calls: list[str],
        *,
        capacity: int | None,
        connect_error: Exception | None,
    ) -> None:
        self.provider = plan.account.provider
        self.account_id: UUID | None = plan.account.account_id
        self.queue = EventQueue(self.provider, 100)
        self.requested: list[tuple[UUID, ...]] = []
        self.accepted: list[tuple[UUID, ...]] = []
        self.reconnects: list[str] = []
        self.connected = False
        self._label = plan.account.label
        self._listener = listener
        self._clock = clock
        self._calls = calls
        self._capacity = capacity
        self._connect_error = connect_error

    async def health(self) -> ProviderHealth:
        return ProviderHealth(
            provider=self.provider,
            account_id=self.account_id,
            state=ConnectionState.CONNECTED if self.connected else ConnectionState.IDLE,
            data_status=DataStatus.LIVE if self.connected else DataStatus.DISCONNECTED,
        )

    async def connect(self) -> None:
        self._calls.append(f"{self._label} connect")
        if self._connect_error is not None:
            raise self._connect_error
        self.connected = True
        self._listener(
            StateChange(
                provider=self.provider,
                account_id=self.account_id,
                stream_id=f"{self._label}:0",
                previous=None,
                state=ConnectionState.CONNECTED,
                reason="test",
                occurred_at=self._clock(),
            )
        )

    async def disconnect(self) -> None:
        self._calls.append(f"{self._label} disconnect")
        self.connected = False

    async def set_subscriptions(self, instruments: Sequence[ProviderInstrument]) -> None:
        self._calls.append(f"{self._label} subscribe")
        ids = tuple(instrument.instrument_id for instrument in instruments)
        self.requested.append(ids)
        if self._capacity is not None and len(ids) > self._capacity:
            raise SubscriptionCapacityError(f"{len(ids)} instruments exceed the capacity of {self._capacity}")
        self.accepted.append(ids)

    def request_reconnect(self, reason: str) -> None:
        self.reconnects.append(reason)


class Adapters:
    """An adapter factory that keeps the adapters it made."""

    def __init__(self, clock: Clock, calls: list[str]) -> None:
        self.made: list[FakeAdapter] = []
        self.capacity: int | None = None
        self.failures: dict[UUID, Exception] = {}  # raised once by the factory
        self.connect_failures: dict[UUID, Exception] = {}  # raised once by the adapter's connect
        self._clock = clock
        self._calls = calls

    def __call__(self, plan: AccountPlan, listener: Callable[[StateChange], None]) -> FakeAdapter:
        account_id = plan.account.account_id
        if account_id in self.failures:
            raise self.failures.pop(account_id)
        adapter = FakeAdapter(
            plan,
            listener,
            self._clock,
            self._calls,
            capacity=self.capacity,
            connect_error=self.connect_failures.pop(account_id, None),
        )
        self.made.append(adapter)
        return adapter

    def of(self, account: StreamAccount) -> FakeAdapter:
        return next(adapter for adapter in reversed(self.made) if adapter.account_id == account.account_id)


class Store:
    """The candle writer and its table: forming candles can be loaded once they were flushed."""

    def __init__(self, calls: list[str]) -> None:
        self.added: list[Candle] = []
        self._saved = 0
        self._calls = calls

    def add(self, candles: Iterable[Candle]) -> None:
        self.added.extend(candles)

    async def flush(self) -> None:
        self._calls.append("flush")
        self._saved = len(self.added)

    async def load(
        self,
        provider: Provider,
        instruments: Mapping[UUID, Listing],
        intervals: Collection[CandleInterval],
        after: datetime,
    ) -> list[Candle]:
        self._calls.append("load")
        return [
            candle
            for candle in self.added[: self._saved]
            if not candle.is_closed
            and candle.provider is provider
            and candle.instrument_id in instruments
            and candle.interval in intervals
            and candle.bucket_end > after
        ]


@dataclass
class Rig:
    planner: FakePlanner
    adapters: Adapters
    store: Store
    clock: Clock
    calls: list[str]
    manager: ConnectionManager


def rig(*accounts: AccountPlan) -> Rig:
    calls: list[str] = []
    clock = Clock(at("09:14:00"))
    planner, adapters, store = FakePlanner(*accounts), Adapters(clock, calls), Store(calls)
    manager = ConnectionManager(
        build_settings(candle_intervals=[M1], candle_checkpoint_interval_seconds=0),
        planner,
        adapters,
        cast(RedisBus, FakeBus()),
        cast(CandleWriter, store),
        calendar(),
        store.load,
        clock=clock,
        monotonic=clock.monotonic,
    )
    return Rig(planner, adapters, store, clock, calls, manager)


async def test_feeds_follow_the_plan() -> None:
    r = rig(plan(KITE, ALPHA), plan(GROWW))

    assert await r.manager.reconcile() == {KITE.account_id, GROWW.account_id}
    kite, groww = r.adapters.made
    # Instruments are subscribed and saved forming candles resumed before a feed connects.
    assert r.calls == ["kite subscribe", "flush", "load", "kite connect", "groww subscribe", "groww connect"]
    assert (kite.accepted, groww.accepted, kite.connected) == ([(ALPHA,)], [()], True)

    renamed = StreamAccount(KITE.account_id, KITE.provider, "kite 2")
    unlisted = Skipped(BETA, Provider.ZERODHA, KITE.account_id, SkipReason.NOT_LISTED, "inactive")
    r.planner.set(plan(renamed, ALPHA), idle=(IdleAccount(GROWW, "log in again"),), skipped=(unlisted,))
    assert await r.manager.reconcile() == set()

    assert r.calls[6:] == ["groww disconnect"]  # the Kite feed carries on under its new label
    assert r.manager.details() == {
        "feeds": [{**fields(renamed), "instruments": 1, "planned": 1, "refused": None, "queued_events": 0}],
        "failed": [],
        "idle": [{**fields(GROWW), "reason": "log in again"}],
        "skipped": {"not_listed": 1},
        "queue_depth": 0,
        "queue_capacity": 100,
    }

    r.planner.result = RuntimeError("database down")
    assert await r.manager.reconcile() == set()
    assert kite.connected  # without a plan the feeds stream what they streamed

    await r.manager.stop_all()
    details = r.manager.details()
    assert (kite.connected, details["feeds"], details["queue_capacity"]) == (False, [], 20_000)


async def test_a_feed_restarts_when_its_capabilities_change_and_resumes_its_forming_candles() -> None:
    r = rig(plan(KITE, ALPHA))
    await r.manager.reconcile()
    r.adapters.made[0].queue.put(event(at("09:15:10"), "100"))
    assert (r.manager.details()["queue_depth"], r.manager.details()["queue_capacity"]) == (1, 100)
    r.clock.now = at("09:15:20")

    r.planner.set(plan(KITE, ALPHA, max_instruments_per_connection=100))
    assert await r.manager.reconcile() == {KITE.account_id}
    r.adapters.made[1].queue.put(event(at("09:15:40"), "105"))
    r.clock.now = at("09:16:05")
    await r.manager.stop_all()

    # The old feed hands over its forming candle, which is stored before the new feed loads it.
    assert r.calls[4:] == [
        "kite disconnect",
        "kite subscribe",
        "flush",
        "load",
        "kite connect",
        "kite disconnect",
    ]
    forming, closed = r.store.added
    assert (forming.is_closed, forming.event_count) == (False, 1)
    prices = (closed.open_price, closed.close_price)
    assert (closed.is_closed, prices, closed.event_count) == (True, (Decimal(100), Decimal(105)), 2)


async def test_instruments_added_mid_bucket_are_covered_from_their_subscription() -> None:
    r = rig(plan(KITE, ALPHA))
    await r.manager.reconcile()  # connected at 09:14
    [adapter] = r.adapters.made

    r.clock.now = at("09:15:30")
    r.planner.set(plan(KITE, ALPHA, BETA))
    assert await r.manager.reconcile() == set()
    adapter.queue.put(event(at("09:15:35"), "100"))
    adapter.queue.put(event(at("09:15:40"), "50", instrument=BETA))
    r.clock.now = at("09:16:05")
    await r.manager.stop_all()

    assert adapter.accepted == [(ALPHA,), (ALPHA, BETA)]
    partial = {candle.instrument_id: CandleFlag.PARTIAL_START in candle.flags for candle in r.store.added}
    assert partial == {ALPHA: False, BETA: True}


async def test_a_refused_instrument_set_keeps_the_previous_one_until_the_plan_changes() -> None:
    r = rig(plan(KITE, ALPHA))
    r.adapters.capacity = 1
    await r.manager.reconcile()
    [adapter] = r.adapters.made

    r.planner.set(plan(KITE, ALPHA, BETA))
    await r.manager.reconcile()
    await r.manager.reconcile()  # the same plan is not tried again

    assert (adapter.requested, adapter.accepted) == ([(ALPHA,), (ALPHA, BETA)], [(ALPHA,)])
    [feed] = r.manager.details()["feeds"]
    assert (feed["instruments"], feed["planned"]) == (1, 2)
    assert feed["refused"] == "SubscriptionCapacityError: 2 instruments exceed the capacity of 1"

    r.planner.set(plan(KITE, BETA))
    await r.manager.reconcile()
    assert adapter.accepted == [(ALPHA,), (BETA,)]
    assert r.manager.details()["feeds"][0]["refused"] is None
    await r.manager.stop_all()


async def test_feeds_that_fail_to_start_are_reported_and_retried() -> None:
    r = rig(plan(KITE, ALPHA), plan(GROWW))
    r.adapters.failures[KITE.account_id] = ProviderNotEnabledError("Zerodha streaming is turned off")
    r.adapters.connect_failures[GROWW.account_id] = OSError("network unreachable")

    assert await r.manager.reconcile() == set()
    assert r.calls == ["groww subscribe", "groww connect", "groww disconnect"]
    assert r.manager.details()["failed"] == [
        {**fields(KITE), "error": "ProviderNotEnabledError: Zerodha streaming is turned off"},
        {**fields(GROWW), "error": "OSError: network unreachable"},
    ]

    r.planner.set(plan(GROWW))
    assert await r.manager.reconcile() == {GROWW.account_id}
    details = r.manager.details()
    assert ([feed["label"] for feed in details["feeds"]], details["failed"]) == (["groww"], [])
    await r.manager.stop_all()


async def test_a_command_batch_reconciles_once_and_reconnects_feeds_whose_credentials_changed() -> None:
    r = rig(plan(KITE, ALPHA))
    await r.manager.reconcile()
    [kite] = r.adapters.made

    await r.manager.handle(
        [command(CommandType.REFRESH_INSTRUMENTS), command(CommandType.RELOAD_DEPLOYMENTS)]
    )
    assert r.planner.calls == 1  # neither changes what is streamed

    r.planner.set(plan(KITE, ALPHA), plan(GROWW))
    await r.manager.handle(
        [
            command(CommandType.CONNECT_ACCOUNT, KITE),
            command(CommandType.DISCONNECT_ACCOUNT, KITE),
            command(CommandType.CONNECT_ACCOUNT, GROWW),  # its new feed reads the new credentials anyway
            command(CommandType.REFRESH_SUBSCRIPTIONS),
        ]
    )

    assert r.planner.calls == 2
    assert (kite.reconnects, r.adapters.of(GROWW).reconnects) == (["credentials changed"], [])
    await r.manager.stop_all()
