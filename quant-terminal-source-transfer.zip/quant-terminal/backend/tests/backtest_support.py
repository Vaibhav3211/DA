"""Backtest fixtures: a one-week exchange calendar, a scripted strategy and replay defaults."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal
from typing import Any
from uuid import UUID
from zoneinfo import ZoneInfo

from app.backtest.engine import Limits, Replay
from app.domain.enums import (
    CandleInterval,
    Exchange,
    ExitCheck,
    FillTiming,
    InstrumentType,
    MarketRegion,
    OppositeSignal,
    Provider,
    Segment,
    SignalType,
    SizingMethod,
    StopTargetSource,
    TradeSides,
)
from app.domain.models import Candle, SignalCandidate, SignalCondition, StrategyMetadata
from app.domain.models.backtest import TradeRules
from app.market_data.calendars.service import ExchangeSpec, LibrarySchedule, MarketCalendar
from app.risk.engine import resolve_policy
from app.strategies.base import Strategy, StrategyConfig, StrategyContext
from app.strategies.registry import RegisteredStrategy, register
from tests.candle_support import T0
from tests.signal_support import ALPHA

IST = ZoneInfo("Asia/Kolkata")
OPEN, CLOSE = time(9, 15), time(15, 30)
# The published NSE week; Wednesday is a holiday.
MON, TUE, WED, THU, FRI = (date(2026, 1, day) for day in range(5, 10))
WORKSPACE = UUID("00000000-0000-4000-8000-0000000000cc")
LIMITS = Limits(strategy_timeout_seconds=1.0, max_seconds=60.0, signal_validity_seconds=900)

type Context = StrategyContext[StrategyConfig]
type Decide = Callable[[Candle, Context], Sequence[SignalCandidate]]


def ist(day: date, at: time) -> datetime:
    return datetime.combine(day, at, tzinfo=IST).astimezone(UTC)


SCHEDULE = LibrarySchedule(
    sessions={day: (ist(day, OPEN), ist(day, CLOSE)) for day in (MON, TUE, THU, FRI)},
    first_session=MON,
    last_session=FRI,
    weekmask="1111100",
    regular_open=OPEN,
    regular_close=CLOSE,
)


def nse_calendar(*, extend: bool = True) -> MarketCalendar:
    """NSE on the week above, with regular hours assumed after it when ``extend``; MCX has no calendar."""
    specs = (ExchangeSpec(Exchange.NSE, IST, "XBOM"), ExchangeSpec(Exchange.MCX, IST))
    return MarketCalendar(specs, {"XBOM": SCHEDULE}, (), extend_beyond_coverage=extend)


def scripted(
    decide: Decide | None = None,
    *,
    on_start: Callable[[Context], None] | None = None,
    **metadata: Any,
) -> RegisteredStrategy:
    """A strategy that proposes what ``decide`` returns for each candle (nothing by default) and calls
    ``on_start`` from ``initialize``. Unless ``metadata`` says otherwise it trades 1-minute candles of
    Indian cash equities, has no warm-up and declares a condition for every signal type."""

    class Plugin(Strategy[StrategyConfig]):
        async def initialize(self, context: Context) -> None:
            if on_start is not None:
                on_start(context)

        async def on_candle(self, candle: Candle, context: Context) -> Sequence[SignalCandidate]:
            return decide(candle, context) if decide is not None else ()

    values: dict[str, Any] = {
        "strategy_id": "test.backtest",
        "name": "Backtest fixture",
        "description": "Backtest test plugin.",
        "version": "1.0.0",
        "author": "tests",
        "markets": (MarketRegion.INDIA,),
        "segments": (Segment.CASH,),
        "instrument_types": (InstrumentType.EQUITY,),
        "candle_intervals": (CandleInterval.M1,),
        "can_emit_actionable": True,
        "signal_conditions": tuple(
            SignalCondition(signal_type=signal_type, description="fixture", inputs=("close",))
            for signal_type in SignalType
        ),
    }
    Plugin.metadata = StrategyMetadata(**(values | metadata))
    return register(Plugin)


def by_minute(signals: Mapping[int, SignalCandidate]) -> Decide:
    """Propose ``signals[n]`` on the candle that starts ``n`` minutes after T0."""

    def decide(candle: Candle, context: Context) -> Sequence[SignalCandidate]:
        minute = int((candle.bucket_start - T0) / timedelta(minutes=1))
        return (signals[minute],) if minute in signals else ()

    return decide


def trade_rules(**overrides: Any) -> TradeRules:
    """Both sides, reversing on opposite signals, next-open fills, intrabar exits at the signal's levels,
    10 units per entry and no costs."""
    fields: dict[str, Any] = {
        "sides": TradeSides.BOTH,
        "opposite_signal": OppositeSignal.REVERSE,
        "fill": FillTiming.NEXT_OPEN,
        "exit_check": ExitCheck.INTRABAR,
        "stop_target": StopTargetSource.SIGNAL,
        "sizing": SizingMethod.FIXED_QUANTITY,
        "quantity": 10,
        "initial_capital": Decimal(100_000),
        "fee_pct_per_side": Decimal(0),
        "fee_per_order": Decimal(0),
        "slippage_ticks": 0,
    }
    fields.update(overrides)
    return TradeRules(**fields)


def replay(entry: RegisteredStrategy, rules: TradeRules | None = None, **overrides: Any) -> Replay:
    """``entry`` with its default configuration on ALPHA's 1-minute Zerodha candles, under the default
    risk policy."""
    fields: dict[str, Any] = {
        "entry": entry,
        "config": entry.validate_config(entry.default_config),
        "instrument": ALPHA,
        "provider": Provider.ZERODHA,
        "interval": CandleInterval.M1,
        "rules": rules if rules is not None else trade_rules(),
        "policy": resolve_policy((), WORKSPACE),
        "calendar": nse_calendar(),
        "market_region": MarketRegion.INDIA,
        "workspace_id": WORKSPACE,
        "deployment_id": UUID(int=2),
        "run_id": UUID(int=3),
    }
    fields.update(overrides)
    return Replay(**fields)
