"""Candle fixtures shared by the strategy, risk and signal tests."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from uuid import UUID

from app.domain.enums import CandleFlag, CandleInterval, DataStatus, Exchange, Provider, Segment
from app.domain.models import Candle

# 09:15 IST, the NSE open on a Monday.
T0 = datetime(2026, 1, 5, 3, 45, tzinfo=UTC)
INSTRUMENT = UUID("00000000-0000-4000-8000-000000000001")

type Price = int | str | Decimal


def bar(
    index: int,
    close: Price,
    *,
    high: Price | None = None,
    low: Price | None = None,
    open_: Price | None = None,
    volume: int | None = 100,
    status: DataStatus = DataStatus.LIVE,
    interval: CandleInterval = CandleInterval.M1,
    closed: bool = True,
    flags: Sequence[CandleFlag] = (),
    start: datetime | None = None,
    instrument_id: UUID = INSTRUMENT,
    provider: Provider = Provider.ZERODHA,
    exchange: Exchange = Exchange.NSE,
    symbol: str = "ALPHA",
) -> Candle:
    """The ``index``-th candle of ``interval`` after ``T0`` (or at ``start``)."""
    begin = start if start is not None else T0 + timedelta(seconds=index * interval.seconds)
    end = begin + timedelta(seconds=interval.seconds)
    close_price = Decimal(close)
    open_price = Decimal(open_) if open_ is not None else close_price
    high_price = Decimal(high) if high is not None else max(open_price, close_price)
    low_price = Decimal(low) if low is not None else min(open_price, close_price)
    return Candle(
        provider=provider,
        account_id=None,
        instrument_id=instrument_id,
        symbol=symbol,
        exchange=exchange,
        segment=Segment.CASH,
        interval=interval,
        bucket_start=begin,
        bucket_end=end,
        open_price=open_price,
        high_price=high_price,
        low_price=low_price,
        close_price=close_price,
        volume=volume,
        event_count=1,
        is_closed=closed,
        data_status=status,
        flags=tuple(flags),
        first_event_at=begin,
        last_event_at=end - timedelta(seconds=1),
    )


def closes(
    values: Iterable[Price],
    *,
    first: int = 0,
    status: DataStatus = DataStatus.LIVE,
    volume: int | None = 100,
    interval: CandleInterval = CandleInterval.M1,
    instrument_id: UUID = INSTRUMENT,
) -> list[Candle]:
    """Consecutive candles closing at ``values`` (flat bars: open = high = low = close)."""
    return [
        bar(first + i, value, status=status, volume=volume, interval=interval, instrument_id=instrument_id)
        for i, value in enumerate(values)
    ]
