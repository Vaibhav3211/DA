"""Opt-in smoke tests against real Zerodha and Groww accounts. Read-only: they never place orders.

They check what the offline suites cannot: that the stored tokens work, that the REST API agrees with
the instrument master, and that each streaming adapter connects, subscribes, stays up and parses real
packets in every subscription mode. Run them where the providers are reachable, from ``backend``,
after setting up the accounts (``qt accounts --help``), logging in for the day (``qt zerodha login``,
``qt groww create-token`` or ``qt groww set-token``) and loading the instrument master
(``qt instruments refresh zerodha``, ``qt instruments refresh groww``)::

    RUN_LIVE_SMOKE=1 pytest -m live tests/live                  # bash
    $env:RUN_LIVE_SMOKE = "1"; pytest -m live tests/live        # PowerShell

Each provider uses its enabled account, or the account (label or id) named by
``LIVE_ZERODHA_ACCOUNT`` / ``LIVE_GROWW_ACCOUNT``; a provider with neither is skipped. Optional
variables, set in the shell rather than in ``.env``:

- ``LIVE_ZERODHA_INSTRUMENTS`` / ``LIVE_GROWW_INSTRUMENTS``: comma-separated canonical keys of liquid
  instruments (default: RELIANCE, INFY and the provider's NIFTY 50 index).
- ``LIVE_EXPECT_TICKS``: ``auto`` (the default: NSE hours, Monday to Friday 09:15-15:30 IST, holidays
  unknown), ``1`` or ``0``. Without ticks, a stream passes when it connects, subscribes and stays up
  on heartbeats alone.
- ``LIVE_TICK_TIMEOUT``: seconds to wait for every instrument's data while ticks are expected
  (default 30).

Settings come from ``backend/.env``, with MARKET_DATA_ENABLED forced on in this process only. The
tests read accounts, tokens and instruments from the database but write nothing, publish nothing to
Redis, and open one provider connection at a time.
"""

from __future__ import annotations

import asyncio
import contextlib
import itertools
import math
import operator
import os
from collections import defaultdict
from collections.abc import AsyncIterator, Mapping, Sequence
from dataclasses import dataclass
from datetime import time, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Final
from uuid import UUID

import pytest

from app.container import Container
from app.core.clock import IST, utc_now
from app.core.config import Settings
from app.core.errors import NotFoundError
from app.domain.enums import ConnectionState, DataStatus, Provider, Segment, SubscriptionMode
from app.domain.models import MarketDepth, NormalizedMarketEvent, ProviderHealth, ProviderInstrument
from app.providers.base import MarketDataAdapter, SessionCredentials, StateChange
from app.providers.errors import ProviderAuthRequiredError, ProviderNotEnabledError
from app.providers.groww.client import GrowwRestClient, exchange_symbol
from app.providers.registry import create_adapter
from app.providers.zerodha.client import KiteRestClient, quote_key
from app.services.capabilities import CapabilityService
from app.services.instruments import InstrumentService
from app.services.provider_accounts import ProviderAccountService, ProviderAccountView

BACKEND_DIR: Final = Path(__file__).resolve().parents[2]

pytestmark = [
    pytest.mark.live,
    pytest.mark.skipif(
        os.environ.get("RUN_LIVE_SMOKE") != "1", reason="live provider smoke tests need RUN_LIVE_SMOKE=1"
    ),
]

PROVIDERS: Final = [pytest.param(Provider.ZERODHA, id="zerodha"), pytest.param(Provider.GROWW, id="groww")]
MODES: Final = [
    pytest.param(mode, id=mode.value.lower())
    for mode in (SubscriptionMode.LTP, SubscriptionMode.QUOTE, SubscriptionMode.FULL)
]
# Index keys differ: Kite calls the index "NIFTY 50", Groww "NIFTY" (see market_data/instruments).
DEFAULT_INSTRUMENTS: Final[Mapping[Provider, tuple[str, ...]]] = {
    Provider.ZERODHA: ("NSE:CASH:EQUITY:RELIANCE", "NSE:CASH:EQUITY:INFY", "NSE:INDEX:INDEX:NIFTY 50"),
    Provider.GROWW: ("NSE:CASH:EQUITY:RELIANCE", "NSE:CASH:EQUITY:INFY", "NSE:INDEX:INDEX:NIFTY"),
}
NSE_HOURS: Final = (time(9, 15), time(15, 30))
CONNECT_TIMEOUT: Final = 45.0  # above the supervisor's own 30 s connect timeout
DISCONNECT_TIMEOUT: Final = 15.0
DEFAULT_TICK_TIMEOUT: Final = 30.0
QUIET_WINDOW: Final = 15.0  # the least time a stream must stay up on heartbeats alone
# Loose bounds: they catch time-zone and unit mistakes (hours, orders of magnitude), not clock drift.
MAX_FUTURE_SKEW: Final = timedelta(minutes=5)
MAX_EXCHANGE_AGE: Final = timedelta(hours=1)
# A stream price this far from the REST last price points to a scaling or offset mistake.
PRICE_TOLERANCE: Final = Decimal("0.05")
PRICE_FIELDS: Final = (
    "last_price",
    "average_price",
    "open_price",
    "high_price",
    "low_price",
    "close_price",
    "previous_close",
    "bid",
    "ask",
)
TIMESTAMP_FIELDS: Final = ("source_timestamp", "provider_timestamp", "last_trade_time")
FAILED_STATES: Final = frozenset(
    {
        ConnectionState.RECONNECTING,
        ConnectionState.DISCONNECTED,
        ConnectionState.AUTH_REQUIRED,
        ConnectionState.STOPPED,
    }
)
REPORT_LIMIT: Final = 25


@dataclass(frozen=True, slots=True)
class LiveServices:
    settings: Settings
    accounts: ProviderAccountService
    instruments: InstrumentService
    capabilities: CapabilityService


@pytest.fixture
async def live() -> AsyncIterator[LiveServices]:
    settings = Settings(_env_file=str(BACKEND_DIR / ".env"), market_data_enabled=True)
    container = Container.create(settings)
    try:
        accounts = ProviderAccountService.from_container(container)
        yield LiveServices(
            settings=settings,
            accounts=accounts,
            instruments=InstrumentService(accounts, transport=None),
            capabilities=CapabilityService.from_container(container),
        )
    finally:
        await container.close()


# ---- tests ---------------------------------------------------------------------------------------


@pytest.mark.parametrize("provider", PROVIDERS)
async def test_the_stored_access_token_passes_a_profile_check(live: LiveServices, provider: Provider) -> None:
    account = await _account(live, provider)
    credentials = await _credentials(live, account)
    user: str | None
    if provider is Provider.ZERODHA:
        async with _kite(live, credentials) as kite:
            kite_profile = await kite.profile()
        user, exchanges = kite_profile.user_id, kite_profile.exchanges
    else:
        async with _groww(live, credentials) as groww:
            groww_profile = await groww.profile()
        user, exchanges = groww_profile.user_ref, groww_profile.exchanges
    assert user, "the profile names no user: check the profile field mapping"
    if account.provider_user_ref is not None:
        assert user == account.provider_user_ref, "the token belongs to another user than the account"
    assert "NSE" in exchanges, f"NSE is not among the enabled exchanges {exchanges}"


@pytest.mark.parametrize("provider", PROVIDERS)
async def test_rest_last_prices_agree_with_the_instrument_master(
    live: LiveServices, provider: Provider
) -> None:
    account = await _account(live, provider)
    credentials = await _credentials(live, account)
    instruments = await _instruments(live, provider, SubscriptionMode.LTP)
    prices = await _rest_prices(live, credentials, instruments)
    off_grid = [
        f"{instrument.symbol}: {prices[instrument.provider_token]} is not a multiple of the tick size "
        f"{instrument.tick_size}"
        for instrument in instruments
        if instrument.segment is not Segment.INDEX
        and instrument.tick_size
        and prices[instrument.provider_token] % instrument.tick_size
    ]
    assert not off_grid, _report(off_grid, hint="refresh the instrument master if tick sizes changed")


@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("provider", PROVIDERS)
async def test_the_stream_connects_and_delivers_consistent_events(
    live: LiveServices, provider: Provider, mode: SubscriptionMode
) -> None:
    account = await _account(live, provider)
    credentials = await _credentials(live, account)  # fails early, with the login hint
    instruments = await _instruments(live, provider, mode)
    by_token = {instrument.provider_token: instrument for instrument in instruments}
    expect_ticks = _ticks_expected()
    needs: dict[UUID, frozenset[str]] = {}
    if expect_ticks:
        seconds = _env_seconds("LIVE_TICK_TIMEOUT", DEFAULT_TICK_TIMEOUT)
        needs = {instrument.instrument_id: _needs(provider, mode, instrument) for instrument in instruments}
    else:
        # Long enough for the watchdog to replace a connection that heartbeats do not keep alive.
        seconds = max(QUIET_WINDOW, live.settings.feed_heartbeat_timeout_seconds * 1.5)
    states = _StateLog()
    adapter = create_adapter(
        provider,
        account_id=account.id,
        settings=live.settings,
        capabilities=await live.capabilities.effective(provider, account.id),
        credentials=live.accounts.credential_source(account.id),
        observer=states,
        session_open=lambda _exchanges: expect_ticks,
    )
    await adapter.subscribe(instruments)
    try:
        await adapter.connect()
        await _wait_until_connected(adapter, states)
        events = await _collect(adapter, seconds, needs)
        health = await adapter.health()
    finally:
        async with asyncio.timeout(DISCONNECT_TIMEOUT):
            await adapter.disconnect()

    problems = _health_problems(health, len(instruments))
    for event in events:
        problems += _event_problems(event, by_token, account_id=account.id, market_open=expect_ticks)
    problems += _missing_data(events, instruments, needs, seconds)
    hint = "is the exchange closed for a holiday? then set LIVE_EXPECT_TICKS=0" if expect_ticks else None
    assert not problems, _report(problems, hint=hint)

    latest = {event.provider_instrument_token: event.last_price for event in events if event.last_price}
    if latest:
        rest = await _rest_prices(live, credentials, [by_token[token] for token in latest])
        apart = [
            f"{by_token[token].symbol}: stream {price}, REST {rest[token]}"
            for token, price in latest.items()
            if abs(price - rest[token]) > rest[token] * PRICE_TOLERANCE
        ]
        assert not apart, _report(apart, hint="stream and REST prices differ by more than 5%")


# ---- setup helpers -------------------------------------------------------------------------------


def _env(name: str) -> str | None:
    return os.environ.get(name, "").strip() or None


def _env_seconds(name: str, default: float) -> float:
    text = _env(name)
    if text is None:
        return default
    try:
        seconds = float(text)
    except ValueError:
        pytest.fail(f"{name} must be a number of seconds, not {text!r}")
    if not 0 < seconds < math.inf:
        pytest.fail(f"{name} must be a positive number of seconds, not {text!r}")
    return seconds


def _ticks_expected() -> bool:
    """Whether NSE should be trading now. LIVE_EXPECT_TICKS overrides; holidays are not known."""
    flag = (_env("LIVE_EXPECT_TICKS") or "auto").lower()
    if flag in {"1", "0"}:
        return flag == "1"
    if flag != "auto":
        pytest.fail(f"LIVE_EXPECT_TICKS must be auto, 1 or 0, not {flag!r}")
    now = utc_now().astimezone(IST)
    opens, closes = NSE_HOURS
    return now.weekday() < 5 and opens <= now.time() < closes


async def _account(live: LiveServices, provider: Provider) -> ProviderAccountView:
    variable = f"LIVE_{provider.value.upper()}_ACCOUNT"
    ref = _env(variable)
    if ref is not None:
        return await live.accounts.resolve_ref(ref, provider=provider)
    enabled = [view for view in await live.accounts.list_accounts(provider) if view.is_enabled]
    if not enabled:
        pytest.skip(f"no enabled {provider.value} account: enable one or set {variable}")
    return enabled[0]


async def _credentials(live: LiveServices, account: ProviderAccountView) -> SessionCredentials:
    try:
        return await live.accounts.session_credentials(account.id)
    except (ProviderAuthRequiredError, ProviderNotEnabledError) as exc:
        pytest.fail(f"{account.provider.value} account '{account.label}': {exc}")


async def _instruments(
    live: LiveServices, provider: Provider, mode: SubscriptionMode
) -> tuple[ProviderInstrument, ...]:
    variable = f"LIVE_{provider.value.upper()}_INSTRUMENTS"
    configured = _env(variable)
    if configured is None:
        keys = list(DEFAULT_INSTRUMENTS[provider])
    else:
        keys = [key.strip() for key in configured.split(",") if key.strip()]
        if not keys:
            pytest.fail(f"{variable} lists no instrument keys")
    key_by_id: dict[UUID, str] = {}
    unknown: list[str] = []
    for key in keys:
        try:
            key_by_id[(await live.instruments.get(key)).instrument.id] = key
        except NotFoundError:
            unknown.append(key)
    resolved = await live.instruments.resolve(list(key_by_id), provider, mode=mode)
    missing = unknown + [key_by_id[instrument_id] for instrument_id in resolved.missing]
    if missing:
        pytest.fail(
            f"not in the {provider.value} instrument master: {', '.join(missing)}. Run "
            f"`qt instruments refresh {provider.value.lower()}` or set {variable} to other keys"
        )
    return resolved.found


def _kite(live: LiveServices, credentials: SessionCredentials) -> KiteRestClient:
    assert credentials.api_key is not None, "Zerodha session credentials always carry the API key"
    return KiteRestClient(
        api_key=credentials.api_key,
        base_url=live.settings.zerodha_api_base_url,
        access_token=credentials.access_token,
    )


def _groww(live: LiveServices, credentials: SessionCredentials) -> GrowwRestClient:
    return GrowwRestClient(base_url=live.settings.groww_api_base_url, access_token=credentials.access_token)


async def _rest_prices(
    live: LiveServices, credentials: SessionCredentials, instruments: Sequence[ProviderInstrument]
) -> dict[str, Decimal]:
    """REST last prices by provider token. Fails unless every instrument has a positive price."""
    raw: dict[str, Any] = {}
    if instruments[0].provider is Provider.ZERODHA:
        keys = {quote_key(item.provider_exchange, item.provider_symbol): item for item in instruments}
        async with _kite(live, credentials) as kite:
            raw = await kite.ltp(list(keys))
    else:
        keys = {exchange_symbol(item.provider_exchange, item.provider_symbol): item for item in instruments}
        segments: defaultdict[str, list[str]] = defaultdict(list)
        for key, instrument in keys.items():
            segments[instrument.provider_segment].append(key)
        async with _groww(live, credentials) as groww:
            for segment, symbols in segments.items():
                raw.update(await groww.ltp(segment, symbols))
    prices: dict[str, Decimal] = {}
    unreadable: list[str] = []
    for key, instrument in keys.items():
        price = _price(raw.get(key))
        if price is None or price <= 0:
            unreadable.append(f"{key}: {raw.get(key)!r}")
        else:
            prices[instrument.provider_token] = price
    assert not unreadable, _report(unreadable, hint=f"no REST last price; response keys {sorted(raw)}")
    return prices


def _price(value: object) -> Decimal | None:
    """A REST last price: Kite returns objects with ``last_price``, Groww bare numbers."""
    if isinstance(value, Mapping):
        value = value.get("last_price")
    if isinstance(value, bool) or not isinstance(value, Decimal | int | float | str):
        return None
    try:
        price = Decimal(str(value))
    except InvalidOperation:
        return None
    return price if price.is_finite() else None


# ---- stream helpers ------------------------------------------------------------------------------


class _StateLog:
    """A StreamObserver that queues every connection state change."""

    def __init__(self) -> None:
        self.changes: asyncio.Queue[StateChange] = asyncio.Queue()

    async def on_state_change(self, change: StateChange) -> None:
        self.changes.put_nowait(change)


async def _wait_until_connected(adapter: MarketDataAdapter, states: _StateLog) -> None:
    """Return once every stream is CONNECTED; fail as soon as a connection attempt fails."""
    try:
        async with asyncio.timeout(CONNECT_TIMEOUT):
            while True:
                change = await states.changes.get()
                if change.state in FAILED_STATES:
                    pytest.fail(
                        f"{change.stream_id} went {change.state.value} before connecting: {change.reason}"
                    )
                if (await adapter.health()).state is ConnectionState.CONNECTED:
                    return
    except TimeoutError:
        health = await adapter.health()
        pytest.fail(f"not connected after {CONNECT_TIMEOUT:g}s: {health.state.value} ({health.message})")


def _needs(provider: Provider, mode: SubscriptionMode, instrument: ProviderInstrument) -> frozenset[str]:
    """What a live session delivers within seconds for a liquid instrument in ``mode``."""
    needs = {"price"}
    if instrument.segment is Segment.INDEX or mode is SubscriptionMode.LTP:
        return frozenset(needs)
    if mode is SubscriptionMode.FULL:
        needs.add("depth")
    if provider is Provider.ZERODHA:
        needs.add("volume")  # Kite quote and full packets carry the day's volume
        if mode is SubscriptionMode.FULL:
            needs.add("exchange time")  # only full packets carry the exchange timestamp
    return frozenset(needs)


def _features(event: NormalizedMarketEvent) -> set[str]:
    features: set[str] = set()
    if event.last_price is not None:
        features.add("price")
    if event.volume is not None:
        features.add("volume")
    if event.market_depth is not None and event.market_depth.bids and event.market_depth.asks:
        features.add("depth")
    if event.source_timestamp is not None:
        features.add("exchange time")
    return features


async def _collect(
    adapter: MarketDataAdapter, seconds: float, needs: Mapping[UUID, frozenset[str]]
) -> list[NormalizedMarketEvent]:
    """Events for ``seconds``, or until every instrument has shown the data it ``needs``."""
    events: list[NormalizedMarketEvent] = []
    shown: defaultdict[UUID, set[str]] = defaultdict(set)
    with contextlib.suppress(TimeoutError):
        async with asyncio.timeout(seconds):
            while not needs or any(need - shown[key] for key, need in needs.items()):
                event = await adapter.next_event()
                events.append(event)
                shown[event.instrument_id] |= _features(event)
    return events


def _missing_data(
    events: Sequence[NormalizedMarketEvent],
    instruments: Sequence[ProviderInstrument],
    needs: Mapping[UUID, frozenset[str]],
    seconds: float,
) -> list[str]:
    shown: defaultdict[UUID, set[str]] = defaultdict(set)
    for event in events:
        shown[event.instrument_id] |= _features(event)
    problems: list[str] = []
    for instrument in instruments:
        missing = needs.get(instrument.instrument_id, frozenset()) - shown[instrument.instrument_id]
        if missing:
            problems.append(f"{instrument.symbol}: no {', '.join(sorted(missing))} within {seconds:g}s")
    return problems


def _health_problems(health: ProviderHealth, instruments: int) -> list[str]:
    problems: list[str] = []
    if health.state is not ConnectionState.CONNECTED:
        problems.append(f"the stream is {health.state.value}: {health.message}")
    for stream in health.streams:
        name = stream.stream_id
        if stream.reconnect_count:
            problems.append(f"{name} reconnected {stream.reconnect_count} time(s): {stream.last_error}")
        if stream.malformed_events:
            problems.append(f"{name} could not parse {stream.malformed_events} message(s); see the log")
        if stream.dropped_events:
            problems.append(f"{name} dropped {stream.dropped_events} event(s)")
        if stream.last_message_at is None:
            problems.append(f"{name} received neither ticks nor heartbeats")
    subscribed = sum(stream.subscribed_instruments for stream in health.streams)
    if subscribed != instruments:
        problems.append(f"{subscribed} of {instruments} instruments are subscribed")
    return problems


def _event_problems(
    event: NormalizedMarketEvent,
    by_token: Mapping[str, ProviderInstrument],
    *,
    account_id: UUID,
    market_open: bool,
) -> list[str]:
    instrument = by_token.get(event.provider_instrument_token)
    if instrument is None:
        return [f"an event for the unsubscribed token {event.provider_instrument_token}"]
    name = f"{instrument.symbol} {event.event_type.value}"
    problems: list[str] = []
    if event.provider is not instrument.provider or event.account_id != account_id:
        problems.append(f"{name}: attributed to {event.provider.value} account {event.account_id}")
    identity = (event.instrument_id, event.symbol, event.exchange, event.segment)
    if identity != (instrument.instrument_id, instrument.symbol, instrument.exchange, instrument.segment):
        problems.append(f"{name}: attributed to {event.exchange.value} {event.segment.value} {event.symbol}")
    if event.data_status not in (DataStatus.LIVE, DataStatus.DELAYED):
        problems.append(f"{name}: data status {event.data_status.value}")
    for field in PRICE_FIELDS:
        value = getattr(event, field)
        if value is not None and value <= 0:
            problems.append(f"{name}: {field} {value}")
    low, high, last = event.low_price, event.high_price, event.last_price
    if low is not None and high is not None:
        if low > high:
            problems.append(f"{name}: low {low} above high {high}")
        elif market_open and last is not None and not low <= last <= high:
            problems.append(f"{name}: last price {last} outside the day's range {low} to {high}")
    if event.market_depth is not None:
        problems += _depth_problems(name, event.market_depth)
    for field in TIMESTAMP_FIELDS:
        stamp = getattr(event, field)
        if stamp is not None and stamp - event.received_at > MAX_FUTURE_SKEW:
            problems.append(f"{name}: {field} {stamp.isoformat()} is ahead of its receipt")
    reference = event.reference_timestamp
    if market_open and reference is not None and event.received_at - reference > MAX_EXCHANGE_AGE:
        problems.append(f"{name}: exchange time {reference.isoformat()} is over an hour old")
    return problems


def _depth_problems(name: str, depth: MarketDepth) -> list[str]:
    problems: list[str] = []
    for side, levels, in_order in (("bid", depth.bids, operator.ge), ("ask", depth.asks, operator.le)):
        for level in levels:
            if level.price <= 0 or level.quantity <= 0:
                problems.append(f"{name}: {side} level {level.quantity} @ {level.price}")
        prices = [level.price for level in levels]
        if not all(in_order(first, second) for first, second in itertools.pairwise(prices)):
            problems.append(f"{name}: {side} prices out of order {[str(price) for price in prices]}")
    return problems


def _report(problems: Sequence[str], *, hint: str | None = None) -> str:
    unique = list(dict.fromkeys(problems))
    title = f"{len(unique)} problem(s)" + (f" ({hint})" if hint else "")
    lines = [f"{title}:", *(f"  - {problem}" for problem in unique[:REPORT_LIMIT])]
    if len(unique) > REPORT_LIMIT:
        lines.append(f"  ... and {len(unique) - REPORT_LIMIT} more")
    return "\n".join(lines)
