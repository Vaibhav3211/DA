"""Alembic environment: async engine, URL from application settings, all ORM tables registered."""

from __future__ import annotations

import asyncio
import re
from logging.config import fileConfig
from typing import Any

from alembic import context
from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import create_async_engine

import app.persistence.models  # noqa: F401  (registers every table on Base.metadata)
from app.core.config import get_settings
from app.persistence.database import Base, to_async_url

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name, disable_existing_loggers=False)

target_metadata = Base.metadata

# Daily partitions of market_events are created/dropped at runtime, not by migrations.
_RUNTIME_PARTITION = re.compile(r"^market_events_p\d{8}$")


def _database_url() -> str:
    # Callers (e.g. the integration-test harness) may pass an explicit URL programmatically.
    explicit = config.attributes.get("database_url")
    if explicit:
        return to_async_url(str(explicit))
    return to_async_url(get_settings().database_url.get_secret_value())


def _include_object(obj: Any, name: str | None, type_: str, reflected: bool, compare_to: Any) -> bool:
    return not (type_ == "table" and name is not None and _RUNTIME_PARTITION.match(name))


def _configure(**kwargs: Any) -> None:
    context.configure(
        target_metadata=target_metadata,
        compare_type=True,
        compare_server_default=True,
        include_object=_include_object,
        **kwargs,
    )


def run_migrations_offline() -> None:
    _configure(url=_database_url(), literal_binds=True, dialect_opts={"paramstyle": "named"})
    with context.begin_transaction():
        context.run_migrations()


def _run_sync(connection: Connection) -> None:
    _configure(connection=connection)
    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online() -> None:
    engine = create_async_engine(_database_url(), poolclass=pool.NullPool)
    try:
        async with engine.connect() as connection:
            await connection.run_sync(_run_sync)
    finally:
        await engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
