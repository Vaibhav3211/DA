"""saved strategy configurations

Revision ID: 0002
Revises: 0001
Create Date: 2026-11-02 08:30:30

Turns strategy deployments into saved configurations (docs/specification-extension.md, M8):
- a strategy can have several configurations in one workspace. Each has a label, unique among the
  workspace's configurations that are not archived. Existing deployments are labelled with their strategy
  id, which was unique per workspace;
- a configuration's scope names its kind. An empty scope used to mean the whole workspace, so existing
  empty scopes become WORKSPACE scopes and keep their behaviour;
- configurations are archived instead of deleted, so their signal history stays;
- runs record their warm-up progress.

The downgrade restores one deployment per strategy and workspace. It stops, changing nothing, while a
workspace holds several configurations of one strategy, archived ones included.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "0002"
down_revision: str | Sequence[str] | None = "0001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_SCOPE_KIND = sa.Enum("INSTRUMENTS", "WORKSPACE", name="scopekind", native_enum=False, length=40)
_LABEL_INDEX = "uq_strategy_deployments_workspace_label"
_ACTIVE = sa.text("archived_at IS NULL")


def upgrade() -> None:
    op.drop_constraint(
        op.f("uq_strategy_deployments_workspace_id_strategy_id"), "strategy_deployments", type_="unique"
    )
    op.add_column("strategy_deployments", sa.Column("label", sa.String(length=80), nullable=True))
    op.add_column("strategy_deployments", sa.Column("scope_kind", _SCOPE_KIND, nullable=True))
    op.add_column("strategy_deployments", sa.Column("archived_at", sa.DateTime(timezone=True), nullable=True))
    # A missing or empty instrument list meant the whole workspace. Anything else stays an instrument
    # scope, so a scope the application cannot read still blocks its deployment instead of widening it.
    op.execute(
        """
        UPDATE strategy_deployments
        SET label = strategy_id,
            scope_kind = CASE
                WHEN COALESCE(scope -> 'instrument_ids', CAST('[]' AS jsonb)) = CAST('[]' AS jsonb)
                    THEN 'WORKSPACE'
                ELSE 'INSTRUMENTS'
            END
        """
    )
    op.alter_column("strategy_deployments", "label", existing_type=sa.String(length=80), nullable=False)
    op.alter_column("strategy_deployments", "scope_kind", existing_type=_SCOPE_KIND, nullable=False)
    op.create_index(
        op.f("ix_strategy_deployments_workspace_id"),
        "strategy_deployments",
        ["workspace_id", "strategy_id"],
        unique=False,
    )
    op.create_index(
        _LABEL_INDEX, "strategy_deployments", ["workspace_id", "label"], unique=True, postgresql_where=_ACTIVE
    )

    op.add_column(
        "strategy_runs", sa.Column("instruments_warming", sa.Integer(), server_default="0", nullable=False)
    )
    op.add_column(
        "strategy_runs",
        sa.Column(
            "warmup_remaining", postgresql.JSONB(astext_type=sa.Text()), server_default="{}", nullable=False
        ),
    )


def downgrade() -> None:
    shared = op.get_bind().scalar(
        sa.text(
            """
            SELECT count(*) FROM (
                SELECT 1 FROM strategy_deployments GROUP BY workspace_id, strategy_id HAVING count(*) > 1
            ) AS shared
            """
        )
    )
    if shared:
        raise RuntimeError(
            f"Cannot downgrade: {shared} workspace(s) hold several saved configurations of one strategy "
            "(archived ones included). Keep one configuration per strategy and workspace, then try again."
        )
    op.drop_column("strategy_runs", "warmup_remaining")
    op.drop_column("strategy_runs", "instruments_warming")

    op.drop_index(_LABEL_INDEX, table_name="strategy_deployments", postgresql_where=_ACTIVE)
    op.drop_index(op.f("ix_strategy_deployments_workspace_id"), table_name="strategy_deployments")
    # WORKSPACE scopes are stored with no instruments, which is what the whole workspace meant before.
    op.drop_column("strategy_deployments", "archived_at")
    op.drop_column("strategy_deployments", "scope_kind")
    op.drop_column("strategy_deployments", "label")
    op.create_unique_constraint(
        op.f("uq_strategy_deployments_workspace_id_strategy_id"),
        "strategy_deployments",
        ["workspace_id", "strategy_id"],
    )
