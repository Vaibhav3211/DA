"""historical datasets and backtests

Revision ID: 0003
Revises: 0002
Create Date: 2026-11-02 12:52:53

Adds backtests (docs/specification-extension.md, M9; docs/backtesting.md):
- backtest_datasets: frozen copies of one instrument's candles at one interval over a range of dates,
  downloaded from a provider's historical API or copied from the candles the platform recorded, with
  their coverage and a hash of their content;
- backtest_dataset_candles: those candles;
- backtest_runs: backtests of a saved configuration on one instrument and dataset, with the settings
  they used, the hash of those settings, and their results;
- strategy_deployments.backtest_rules: the trade rules saved with a configuration.

The downgrade drops all of it, including every dataset and backtest result.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "0003"
down_revision: str | Sequence[str] | None = "0002"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_PROVIDER = sa.Enum("ZERODHA", "GROWW", "SIMULATOR", name="provider", native_enum=False, length=40)
_INTERVAL = sa.Enum(
    "1s", "1m", "3m", "5m", "15m", "30m", "1h", "1d", name="candleinterval", native_enum=False, length=8
)
_SOURCE = sa.Enum(
    "PROVIDER_HISTORY", "RECORDED", "SIMULATED", name="datasetsource", native_enum=False, length=40
)
_DATASET_STATUS = sa.Enum(
    "PENDING", "BUILDING", "READY", "FAILED", name="datasetstatus", native_enum=False, length=40
)
_RUN_STATUS = sa.Enum(
    "QUEUED", "RUNNING", "SUCCEEDED", "FAILED", name="backteststatus", native_enum=False, length=40
)


def upgrade() -> None:
    op.add_column(
        "strategy_deployments",
        sa.Column("backtest_rules", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    )

    op.create_table(
        "backtest_datasets",
        sa.Column("instrument_id", sa.Uuid(), nullable=False),
        sa.Column("provider", _PROVIDER, nullable=False),
        sa.Column("account_id", sa.Uuid(), nullable=True),
        sa.Column("source", _SOURCE, nullable=False),
        sa.Column("interval", _INTERVAL, nullable=False),
        sa.Column("date_from", sa.Date(), nullable=False),
        sa.Column("date_to", sa.Date(), nullable=False),
        sa.Column("status", _DATASET_STATUS, nullable=False),
        sa.Column("requested_by", sa.String(length=64), nullable=True),
        sa.Column("worker_id", sa.String(length=120), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error", sa.String(length=500), nullable=True),
        sa.Column("candle_count", sa.Integer(), server_default="0", nullable=False),
        sa.Column("first_candle_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_candle_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("content_sha", sa.String(length=64), nullable=True),
        sa.Column("coverage", postgresql.JSONB(astext_type=sa.Text()), server_default="{}", nullable=False),
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(
            ["instrument_id"],
            ["instruments.id"],
            name=op.f("fk_backtest_datasets_instrument_id_instruments"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_backtest_datasets")),
    )
    op.create_index(
        op.f("ix_backtest_datasets_instrument_id"),
        "backtest_datasets",
        ["instrument_id", "interval", "created_at"],
        unique=False,
    )
    op.create_index(op.f("ix_backtest_datasets_status"), "backtest_datasets", ["status"], unique=False)

    op.create_table(
        "backtest_dataset_candles",
        sa.Column("dataset_id", sa.Uuid(), nullable=False),
        sa.Column("bucket_start", sa.DateTime(timezone=True), nullable=False),
        sa.Column("bucket_end", sa.DateTime(timezone=True), nullable=False),
        sa.Column("open_price", sa.Numeric(precision=24, scale=8), nullable=False),
        sa.Column("high_price", sa.Numeric(precision=24, scale=8), nullable=False),
        sa.Column("low_price", sa.Numeric(precision=24, scale=8), nullable=False),
        sa.Column("close_price", sa.Numeric(precision=24, scale=8), nullable=False),
        sa.Column("volume", sa.BigInteger(), nullable=True),
        sa.Column("open_interest", sa.BigInteger(), nullable=True),
        sa.Column("flags", postgresql.ARRAY(sa.String(length=32)), server_default="{}", nullable=False),
        sa.ForeignKeyConstraint(
            ["dataset_id"],
            ["backtest_datasets.id"],
            name=op.f("fk_backtest_dataset_candles_dataset_id_backtest_datasets"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("dataset_id", "bucket_start", name=op.f("pk_backtest_dataset_candles")),
    )

    op.create_table(
        "backtest_runs",
        sa.Column("deployment_id", sa.Uuid(), nullable=False),
        sa.Column("instrument_id", sa.Uuid(), nullable=False),
        sa.Column("dataset_id", sa.Uuid(), nullable=False),
        sa.Column("dataset_sha", sa.String(length=64), nullable=False),
        sa.Column("strategy_id", sa.String(length=64), nullable=False),
        sa.Column("strategy_version", sa.String(length=32), nullable=False),
        sa.Column("code_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("configuration_id", sa.Uuid(), nullable=False),
        sa.Column("config_hash", sa.String(length=64), nullable=False),
        sa.Column("interval", _INTERVAL, nullable=False),
        sa.Column("settings", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("settings_hash", sa.String(length=64), nullable=False),
        sa.Column("status", _RUN_STATUS, nullable=False),
        sa.Column("requested_by", sa.String(length=64), nullable=True),
        sa.Column("worker_id", sa.String(length=120), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error", sa.String(length=500), nullable=True),
        sa.Column("summary", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("equity_curve", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("trades", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("trade_count", sa.Integer(), server_default="0", nullable=False),
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(
            ["dataset_id"],
            ["backtest_datasets.id"],
            name=op.f("fk_backtest_runs_dataset_id_backtest_datasets"),
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["deployment_id"],
            ["strategy_deployments.id"],
            name=op.f("fk_backtest_runs_deployment_id_strategy_deployments"),
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["instrument_id"],
            ["instruments.id"],
            name=op.f("fk_backtest_runs_instrument_id_instruments"),
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_backtest_runs")),
    )
    op.create_index(
        op.f("ix_backtest_runs_deployment_id"),
        "backtest_runs",
        ["deployment_id", "instrument_id", "created_at"],
        unique=False,
    )
    op.create_index(op.f("ix_backtest_runs_status"), "backtest_runs", ["status"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_backtest_runs_status"), table_name="backtest_runs")
    op.drop_index(op.f("ix_backtest_runs_deployment_id"), table_name="backtest_runs")
    op.drop_table("backtest_runs")
    op.drop_table("backtest_dataset_candles")
    op.drop_index(op.f("ix_backtest_datasets_status"), table_name="backtest_datasets")
    op.drop_index(op.f("ix_backtest_datasets_instrument_id"), table_name="backtest_datasets")
    op.drop_table("backtest_datasets")
    op.drop_column("strategy_deployments", "backtest_rules")
