# ADR-011: No order execution in Phase 1

**Status:** Accepted and implemented.

## Context

The specification starts with observation and signal generation only. Real-money order execution is a
separate, disabled-by-default phase (Phase 3) that needs its own approval, and must not arrive as a side
effect of Phase 1. A guard should make accidental order code fail fast instead of relying on review
alone.

## Decision

- No code places, changes or cancels orders, and no runtime code calls a provider's order API.
- `backend/tests/unit/test_architecture.py` reads the runtime source (`app/`) without importing it, and
  fails if the code:
  - imports a provider SDK or its transport (`kiteconnect`, `growwapi`, `twisted`, `autobahn`,
    `google.protobuf`), including through dynamic imports;
  - names a Kite or Groww order method (such as `place_order`, `modify_order`, `cancel_order`,
    `place_gtt` or `create_smart_order`) or an order API path (Kite `/orders`, `/gtt`, `/mf/orders`,
    `/mf/sips` and the position conversion; Groww `/order` and `/order-advance`).
- A second test fails if any SDK becomes a runtime dependency.
- `ORDER_EXECUTION_ENABLED` exists only as a guard: the settings refuse to load when it is `true`.
- Signals are research output. Their entry price, stop-loss and targets are shown, never sent anywhere.

## Consequences

- Trades are placed by hand, outside the platform.
- Adding execution needs a new ADR that supersedes this one, the removal of these guards, and execution
  risk controls of its own.
