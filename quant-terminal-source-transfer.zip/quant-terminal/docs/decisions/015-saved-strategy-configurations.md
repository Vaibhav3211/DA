# ADR-015: Saved strategy configurations are deployments

**Status:** Accepted and implemented at M8; the backtest part at M9
([ADR-016](016-frozen-datasets-and-queued-backtests.md)).

## Context

The strategy workflow ([specification extension](../specification-extension.md), EXT-1, EXT-3 and
EXT-5) needs one saved configuration for the chart, backtests and live signals. A deployment already
stored a strategy, its version, an immutable settings snapshot, a scope and an enabled flag, but a
workspace could hold only one per strategy, and an empty scope silently meant the whole workspace. A
separate configuration table would have had to stay in step with it.

## Decision

- A saved configuration is a deployment (`strategy_deployments`). A workspace can hold several per
  strategy. Each has a label, unique among the workspace's unarchived configurations: the service
  compares labels case-insensitively under the workspace's row lock, and a partial unique index backs it.
- Its settings live in an immutable snapshot (`strategy_configurations`) with their hash. Saving other
  settings points the configuration at another snapshot; identical settings reuse one. Each run records
  the snapshot, its hash and the code fingerprint, and each signal its run, so editing a configuration
  never rewrites its history.
- Its scope is explicit: `INSTRUMENTS` with instrument ids, or `WORKSPACE`. Creating one through the API
  or `qt` requires a scope. Migration `0002_strategy_configurations` rewrote empty scopes as `WORKSPACE`.
- Saving never turns live signals on. Enabling is a separate action, and enabling again changes nothing.
  It is refused for an archived configuration, a code problem (a strategy missing from the code, a
  version mismatch, an unreadable scope), or a duplicate: another enabled configuration of the workspace
  running the same strategy version with the same settings hash on an overlapping scope. Enabling takes
  the workspace's row lock, so two enables cannot both pass the check.
- Stopping always works. Configurations are archived, never deleted, and only once stopped.
- The monitoring state (stopped, blocked, failed, starting, warming up, running) is not stored. It is
  derived when read, from the configuration, its latest run of the current settings, the strategy
  worker's heartbeat and the risk rules that block every signal.
- Backtests (M9) record the same configuration, snapshot and code fingerprint, plus the dataset's content
  hash and a settings hash ([ADR-016](016-frozen-datasets-and-queued-backtests.md)). The trade rules saved
  with a configuration (`strategy_deployments.backtest_rules`) are used only by backtests; changing them
  outdates its backtests.

## Consequences

- The strategy worker, risk gate and signal lifecycle needed no new concept; they still run deployments.
- The database, the API (`/api/v1/deployments`) and `qt strategies deployments` keep the name
  "deployment"; the interface and the guides say "saved configuration".
- Conditions that may pass, such as a disabled workspace, the kill switch or `LIVE_SIGNALS_ENABLED=false`,
  do not refuse enabling: the configuration shows **Blocked** with the reason until they clear.
- Saving an enabled configuration with other settings, instruments or version restarts its run. Its open
  signals stay open until they expire.
- See [live monitoring](../operations/live-monitoring.md) for the controls and states.
