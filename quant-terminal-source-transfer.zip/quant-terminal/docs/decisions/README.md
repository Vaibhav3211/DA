# Architecture decisions

Each record states a decision, why it was made and what follows from it. The records describe the code
as built. Where the build differs from the original plan, the record says so.

| ADR | Decision | Status |
| --- | --- | --- |
| [001](001-modular-monolith.md) | One Python package, three processes | Accepted; amended at M9 for a fourth, the backtest worker |
| [002](002-asyncio-workers.md) | Plain asyncio workers, no task queue | Accepted; the planned instrument-refresh scheduler was not built; amended at M9 for backtest jobs |
| [003](003-redis-streams-event-bus.md) | Redis Streams between processes, PostgreSQL as the system of record | Accepted; amended at M4; raw-tick storage not built |
| [004](004-decimal-and-utc.md) | Decimal prices and UTC timestamps | Accepted |
| [005](005-zerodha-own-client.md) | Own asyncio client for the Kite ticker | Accepted; live behaviour unverified |
| [006](006-groww-nats-client.md) | Own NATS client for the Groww feed | Accepted; live behaviour unverified |
| [007](007-feed-state-and-no-silent-switching.md) | Explicit feed states, no silent source switching | Accepted |
| [008](008-trusted-strategy-plugins.md) | Trusted in-repo strategy plugins | Accepted; amended at M8 for your own strategies |
| [009](009-app-auth-sessions.md) | One local user, server-side sessions, SameSite=Lax cookie with Origin checks | Accepted |
| [010](010-secret-encryption.md) | Provider secrets encrypted at rest, secrets redacted from logs | Accepted |
| [011](011-no-order-execution.md) | No order execution in Phase 1 | Accepted |
| [012](012-websocket-conflation.md) | Per-client filtered, conflated WebSocket queues | Accepted |
| [013](013-frontend-stack.md) | Frontend stack: Next.js, TanStack Query, Zustand | Accepted; never compiled yet |
| [014](014-rest-proxy-direct-websockets.md) | REST through the Next.js proxy, WebSockets direct, Kite callback on the frontend origin | Accepted; never run yet |
| [015](015-saved-strategy-configurations.md) | Saved strategy configurations are deployments, with explicit scope and separate enabling | Accepted; backtest part at M9 |
| [016](016-frozen-datasets-and-queued-backtests.md) | Frozen, content-hashed datasets; backtests queued as PostgreSQL rows for a backtest worker | Accepted (M9); provider downloads unverified |

To change a decision, add an amendment section to its record, or write a new record with the next
number that supersedes it.
