# ADR-003: Redis Streams between processes, PostgreSQL as the system of record

**Status:** Accepted and implemented; amended at M4. Raw-tick storage was not built.

## Context

The market-data worker produces ticks, candles and feed status that the strategy worker and the API need
promptly. Memory must stay bounded when a reader falls behind, a short window should be readable again
after a restart, and storing every tick would cost disk space for a use that has not been measured.

## Decision

- **Redis Streams** carry events between processes: `qt:md:events:<provider>`, `qt:md:candles`,
  `qt:md:feed`, `qt:signals` and `qt:commands`. Each stream is trimmed with `MAXLEN ~`
  (`REDIS_STREAM_MAXLEN`, 200,000). Readers use plain `XREAD` from the tail.
- **Redis keys** hold the latest values: quotes, forming candles, feed health and worker heartbeats.
- Entries are JSON in which prices are strings ([ADR-004](004-decimal-and-utc.md)).
- **PostgreSQL** is the system of record: configuration, instruments, candles, strategy runs, signals,
  risk decisions and the audit log.
- **Raw ticks are not stored.** The plan made tick storage opt-in and retention-limited
  (`TICK_PERSISTENCE_ENABLED`). The setting exists (default `false`), but nothing implements it, and the
  `market_events` table stays empty.

The stream and key names are listed in
[system-architecture.md](../architecture/system-architecture.md#storage).

## Amendment (M4): no consumer group for the strategy worker

A consumer group would hand a restarted strategy worker the candles published while it was down, and
the strategies would treat them as live data. Instead:

- each strategy run warms up: its indicators take the stored candles that closed up to five minutes
  earlier, then the last ten minutes of the candle stream;
- the strategy itself is called only with candles that close while it runs;
- with no consumer group to share the work, exactly one strategy worker runs per platform.

## Consequences

- Redis memory is bounded by the stream length. A reader that falls further behind than that loses the
  trimmed entries.
- Publishing to the streams is best effort, and the database is the source of truth. A lost signal or
  feed event means a browser misses a live update; the stored data is not affected.
- Redis must not evict keys: the Docker Redis runs with `--appendonly yes` and
  `--maxmemory-policy noeviction`.
- There is no tick history. Analysis and warm-ups work from stored candles.
