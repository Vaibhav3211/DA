# ADR-012: Per-client filtered, conflated WebSocket queues

**Status:** Accepted (M5) and implemented.

## Context

A quote can change many times a second, but a browser can show only a few updates a second. A slow or
background tab must not grow the server's memory or delay other clients, and events such as a closed
candle or a signal change must not be lost to conflation.

## Decision

- There are three endpoints: `/ws/v1/market`, `/ws/v1/signals` and `/ws/v1/system`. Each client
  subscribes to what it shows (at most 1500 provider and instrument pairs per selection) and receives
  only that.
- **Latest values** (quotes, forming candles, feed and system status) are read at most
  `WS_MAX_UPDATES_PER_SECOND` (4) times a second and conflated per client. An item is queued only when
  it changed, and a queued item that is replaced before it is sent is dropped.
- **Events** (`candle.closed`, `feed.state_change`, `signal.update`) and replies keep their order and are
  never conflated, up to `WS_CLIENT_QUEUE_SIZE` (500) frames.
- A client whose queue overflows, or that lets more than `WS_SLOW_CLIENT_DROP_LIMIT` (2000) updates be
  replaced before reading them, is closed with 1013 `slow_client`.
- Each user may hold 10 connections per API process, and each connection may send 100 messages per
  10 seconds.

## Consequences

- A browser always sees the newest value, not every tick. The WebSocket is a display feed, not a tick
  recorder.
- Memory per client is bounded.
- After a reconnect a client reloads its REST snapshot; the frontend does this.
- The limits apply to each API process separately.

[websocket-protocol.md](../websocket-protocol.md) describes the messages.
