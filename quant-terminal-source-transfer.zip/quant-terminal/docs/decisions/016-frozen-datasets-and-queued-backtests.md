# ADR-016: Frozen datasets and queued backtests

**Status:** Accepted and implemented at M9. The Zerodha and Groww downloads are tested against fixtures
only; real downloads are unverified.

## Context

Backtests ([specification extension](../specification-extension.md), EXT-3.2 to EXT-3.4 and EXT-4) must
be reproducible. A result has to name the code, settings and candles it used, and a change to any of them
must mark it outdated without rewriting it. Building a dataset can take many rate-limited provider
requests (Kite allows 3 historical requests per second), and replaying a long range takes time. Neither
may run inside an API request or slow the feeds and live signals. Phase 1 has no task queue
([ADR-002](002-asyncio-workers.md)), and Redis holds only streams and short-lived keys
([ADR-003](003-redis-streams-event-bus.md)).

## Decision

- **Datasets are frozen.** A dataset (`backtest_datasets`, with its candles in `backtest_dataset_candles`)
  holds one instrument's candles at one interval over a range of exchange-local dates, from one source:
  the provider's historical-candle API, downloaded only when asked; the candles recorded from the live
  feed; or simulator candles, labelled SIMULATED. Once READY it never changes. A SHA-256 of its candles
  (`content_sha`) identifies it, and its coverage against the exchange calendar lists what is missing.
  Missing candles are never filled in or taken from another source.
- **A backtest records what it ran with.** A `backtest_runs` row holds the configuration, its settings
  snapshot and their hash, the strategy's id, version and code fingerprint, and the dataset with its
  content hash. It also holds a settings document with its own hash: the engine version, the strategy's
  identity, the parameters, the instrument, interval, lot and tick size, the trade rules, the signal
  validity and the history risk rules. The summary, equity curve and trades are stored on the same row.
- **Outdated is derived, never stored.** A succeeded backtest is current while the configuration's
  settings still give its settings hash, and outdated once they do not. Nothing reruns a backtest by
  itself, and earlier runs are kept for comparison. Asking again for the same configuration, instrument,
  dataset and settings while that backtest is queued, running or succeeded returns it instead of running
  it twice.
- **The rows are the queue.** Datasets go from PENDING to BUILDING, then READY or FAILED; backtests from
  QUEUED to RUNNING, then SUCCEEDED or FAILED. The API checks a request, stores the row and answers 202.
  It never downloads history or replays candles.
- **A fourth process does the work.** `qt-backtest-worker`
  ([ADR-001](001-modular-monolith.md#amendment-m9-the-backtest-worker)) takes one job at a time, oldest
  first and datasets before backtests, and claims it with `SELECT … FOR UPDATE SKIP LOCKED`. While a job
  runs, it refreshes the claim every 15 seconds. Before each poll, it fails jobs that have shown no
  progress for 5 minutes. Before replaying, it checks that the dataset, the strategy's code, the settings
  hash and the stored candles' hash are unchanged, and fails the backtest if not. It publishes a heartbeat
  like the other workers, and the API warns while the heartbeat is missing.
- **Jobs are bounded.** `BACKTEST_MAX_CANDLES` limits a dataset and `BACKTEST_MAX_SECONDS` a replay. A
  backtest stores at most 20,000 closed trades.

## Consequences

- Every result can be traced to its code fingerprint, settings hash and dataset hash. A backtest whose
  code, settings or candles change between queueing and replaying fails instead of mixing them.
- No broker, job framework or new store: PostgreSQL holds the jobs and their results, which survive a
  restart of any process. Nothing retries a failed job; you queue it again.
- Run exactly one backtest worker. It downloads one dataset at a time under the provider's rate limits,
  which are applied inside the process, so a second worker could exceed them.
- One job at a time: a long download delays the backtests queued after it.
- Stopping the worker abandons its job. The job fails once a worker runs again, and must be queued again.
- Datasets and backtests accumulate in PostgreSQL: nothing deletes them yet.
- A backtest replays one instrument at one interval, for strategies that use closed candles only.
- See [backtesting](../backtesting.md).
