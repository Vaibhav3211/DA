# ADR-004: Decimal prices and UTC timestamps

**Status:** Accepted and implemented.

## Context

Prices must stay exact from the provider to the screen. Binary floating point cannot represent most
decimal prices, and rounding errors would reach candles, risk checks and signal levels. Providers send
prices in their own units: Kite, for example, sends integers in paise (see
[zerodha.md](../providers/zerodha.md)). Times must compare correctly across providers, the database
and the browser, while Indian market sessions are defined in India time.

## Decision

- Prices are `Decimal` in the domain and `NUMERIC` in PostgreSQL. Each provider adapter's mapper is the
  only place that converts provider units. A missing value stays `None`; it is never turned into 0.
- Indicators compute with `Decimal` too.
- Every timestamp is timezone-aware and in UTC. `Asia/Kolkata` is used only for market sessions and
  calendars (`app/core/clock.py`, `app/market_data/calendars/`) and for display in the frontend
  (`src/lib/format.ts`).
- Prices cross process and network boundaries as decimal strings: in Redis entries, REST responses and
  WebSocket frames.

## Consequences

- Candles, risk checks and signal levels carry no floating-point rounding.
- Clients read prices as strings, not JSON numbers. The frontend's generated API types declare them as
  `string`.
