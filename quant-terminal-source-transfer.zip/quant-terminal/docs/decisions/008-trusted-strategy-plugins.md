# ADR-008: Trusted in-repo strategy plugins

**Status:** Accepted and implemented.

## Context

Strategies are Python code. Running untrusted code safely needs a sandbox, such as a separate process or
container with resource limits, which Phase 1 does not have. A strategy bug must still not stop the
worker, other strategies or the API.

## Decision

- Strategies are trusted plugins that live in the repository, under `backend/app/strategies/`, and are
  listed in `BUILTIN_STRATEGIES` (`strategies/registry.py`). Nothing is uploaded or loaded at run time;
  adding a strategy is a code change.
- The registry validates every plugin when it is built, so a broken plugin fails start-up. Each run
  records the plugin's fingerprint (the SHA-256 of its module's source).
- Plugins run only in `qt-strategy-worker`, never in the API process.
- Each hook runs under `STRATEGY_TIMEOUT_SECONDS` (0.5). A hook that awaits past it is cancelled. A hook
  that blocks the event loop cannot be interrupted: the overrun is detected afterwards and the result
  discarded.
- An exception affects only its own run. A per-strategy circuit breaker opens after
  `STRATEGY_FAILURE_THRESHOLD` (5) consecutive errors or timeouts, and lets one trial call through after
  `STRATEGY_CIRCUIT_RESET_SECONDS` (60).
- A strategy sees only its context and can only propose signals. Every proposal goes through the risk
  gate.
- `backend/tests/unit/test_architecture.py` keeps plugins within the plugin API. They may import only a
  few standard-library modules (such as `decimal`, `math`, `statistics` and `datetime`), `pydantic`, the
  domain enums and models, and `app.strategies` apart from its registry and runtime. They may not use
  `open`, `eval`, `exec`, `compile` or `__import__`, or read the clock.

## Consequences

- A plugin that blocks still stalls the strategy worker, and every other run in it, for as long as it
  blocks; the timeout only discards its result.
- The static checks are a guard rail for review, not a sandbox.
- Running strategies written by others needs a sandboxed process or container, which is left to a later
  phase.

## Amendment (M8): your own strategies

- Your strategies live in `backend/app/strategies/custom/` and are listed in `CUSTOM_STRATEGIES`
  (`strategies/custom/__init__.py`). The registry appends them to the examples in `BUILTIN_STRATEGIES`,
  so they are validated, fingerprinted and confined in the same way: the plugin rules above apply to
  them too.
- `qt strategies check` validates every declaration without starting anything. After a restart of the
  API and the strategy worker, the worker adds new strategies and versions to the catalogue (as do
  `qt strategies sync` and **Sync catalogue**).
- A browser code editor or code upload is still out of scope; it needs the sandbox above.
- See [registering your own strategy](../strategy-registration.md).
