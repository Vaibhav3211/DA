# ADR-013: Frontend stack

**Status:** Accepted (M6). Written, but never compiled or run (see the last consequence).

## Context

The terminal combines ordinary REST screens (workspaces, providers, strategies, signals) with live data
that changes several times a second, and charts. It must stay type-safe against the API's models.

## Decision

| Concern | Choice |
| --- | --- |
| Framework | Next.js 16 (App Router), React 19, TypeScript |
| REST state | TanStack Query 5 |
| Live WebSocket state | Zustand stores (`src/lib/live/store.ts`) |
| UI | Tailwind CSS 4 with shadcn/ui conventions (Radix UI primitives, `class-variance-authority`, lucide icons); a dark-only terminal theme |
| Charts | `lightweight-charts` 5 |
| API types | `src/lib/api/types.gen.ts`, generated from the backend models with `python -m app.api.contract`; a backend unit test fails when it is out of date |
| Tests | Vitest with Testing Library and jsdom; one Playwright smoke test that signs in through the real API |

## Consequences

- Node.js 22.12 or later is required.
- `next`, `react`, `react-dom`, TanStack Query and `lightweight-charts` are pinned exactly; the other
  packages use caret ranges until the first `npm install` writes `package-lock.json`. Keep that file:
  later setups run `npm ci`.
- The app was written on a machine where packages could not be installed, so it has never been compiled
  or run. Work through the [first-run checklist](../../frontend/README.md#first-run-checklist) once.
