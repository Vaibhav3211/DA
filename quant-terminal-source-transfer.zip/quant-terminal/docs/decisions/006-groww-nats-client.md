# ADR-006: Own NATS client for the Groww feed

**Status:** Accepted and implemented. The transport was taken from the SDK source; live behaviour is
unverified.

## Context

Groww's live feed is NATS over WebSocket with protobuf payloads. Groww's prose documentation does not
describe the transport, so the details come from the official SDK, `growwapi` 1.5.0. Its source shows
that the SDK:

- writes the socket JWT and the NKEY seed in plain text to `a.creds` and `b.creds` in its own
  site-packages directory and never deletes them, so two accounts would overwrite each other's files;
- makes network calls when `GrowwAPI` is constructed;
- caps `certifi` below 2026, `pandas` below 3 and `protobuf` below 6.

## Decision

- `backend/app/providers/groww/` has its own feed client on `nats-py[aiohttp]`. Each connection creates
  a fresh Ed25519 NKEY pair (`nkeys`, `pynacl`), exchanges the public key for a socket JWT and signs the
  server's nonce. The seed exists only in memory, for that connection attempt.
- A small built-in decoder (`groww/proto.py`) reads the protobuf payloads.
- LTP and QUOTE use the price subject, and FULL adds the book (depth) subject; indices have only a
  value feed. Instrument tokens pass a strict allow-list before they become subjects, so a NATS
  wildcard cannot subscribe the connection to unrelated subjects.
- An `httpx` client makes the REST calls.
- `growwapi` and `protobuf` are only in the `sdk-crosscheck` extra, which tests use to cross-check the
  decoder. The architecture test keeps both out of the runtime code and its dependencies.

## Consequences

- No credential files on disk and no SDK network calls. `certifi` stays at 2025.11.12 so that the
  cross-check extra can still be installed alongside.
- Groww can change an undocumented transport without notice. [groww.md](../providers/groww.md#verifying-live)
  lists the open questions.
- One feed connection per account is assumed, with up to 1000 subscriptions on it.
