# ADR-009: One local user, server-side sessions, SameSite=Lax cookie with Origin checks

**Status:** Accepted and implemented.

## Context

One person uses the terminal. The browser needs authenticated REST calls and WebSockets, and the Kite
login returns through a cross-site redirect that must be matched to the user who started it. An external
identity provider would be more than this needs.

## Decision

- **One local user**, created with `qt create-admin`. Passwords (12 to 256 characters) are hashed with
  argon2.
- **Server-side sessions in Redis.** A session token is 32 random bytes. Redis stores only its SHA-256
  (`qt:session:<hash>`), plus a per-user set used to revoke every session at once. A session lasts at
  most `SESSION_TTL_SECONDS` (12 hours).
- **Cookie:** HttpOnly and `SameSite=Lax`, and `Secure` with `COOKIE_SECURE=true`.
- **Origin checks:** a POST, PUT, PATCH or DELETE that carries an `Origin` header must come from
  `ALLOWED_ORIGINS`, or it is refused with 403 `origin_not_allowed`. A WebSocket handshake from another
  origin is always refused, and open sockets check their session again every 15 s.
- **Kite login state:** random and single-use. Redis keeps its hash for 10 minutes, with the account and
  who started the login, and consumes it atomically (`GETDEL`).
- **Brute-force limits** per address and per user; see
  [secrets-and-auth.md](../security/secrets-and-auth.md#terminal-sign-in).

### Why Lax and not Strict

The return from Kite to the callback is a cross-site top-level navigation. A Strict cookie is not sent
on it, so the callback could not match the state to the session. Lax still withholds the cookie from
cross-site subrequests and POSTs, and the Origin check refuses cross-site state-changing requests.

## Consequences

- One user, and no second factor.
- Requests without an `Origin` header (curl, server-to-server calls) skip the Origin check but still need
  a session.
- The `qt` command line does not sign in: it works on PostgreSQL and Redis directly, so anyone who can
  run it with `backend/.env` has full control.
- Behind the Next.js proxy, every browser shares the per-address limits
  ([ADR-014](014-rest-proxy-direct-websockets.md)).
