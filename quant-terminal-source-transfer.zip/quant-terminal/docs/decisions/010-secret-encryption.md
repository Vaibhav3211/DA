# ADR-010: Provider secrets encrypted at rest, secrets redacted from logs

**Status:** Accepted and implemented.

## Context

Provider API keys, API secrets and access tokens are stored in PostgreSQL. A database dump or backup must
not reveal them, the API must never return them, and logs must never contain them.

## Decision

- Each value is encrypted with AES-256-GCM (`cryptography`) and a random 96-bit nonce. The associated
  data, `provider_account:<id>:<kind>`, ties a ciphertext to its account and field. The stored form is
  `v1.<key id>.<base64>`.
- The key comes from `ENCRYPTION_KEY` (`qt generate-key`). `ENCRYPTION_PREVIOUS_KEYS` and
  `qt rotate-encryption-key` rotate it. In production, load the key from a secret manager rather than a
  file.
- Credentials are write-only: the API and the CLI show a masked API key and which kinds are configured.
  Decrypted values exist only in memory, while a feed connects or a login runs.
- A structlog redaction step replaces secrets with `***REDACTED***` before any log line is written.
- With `APP_ENV=production`, the settings refuse to load without `ENCRYPTION_KEY` and
  `COOKIE_SECURE=true`.

## Consequences

- Without the key, stored credentials can be neither read nor used. Back it up offline: losing it means
  entering every credential and logging in to every provider again.
- In development the key sits in `backend/.env`, which is therefore as sensitive as the credentials.
- [secrets-and-auth.md](../security/secrets-and-auth.md) describes key rotation and the full redaction
  list.
