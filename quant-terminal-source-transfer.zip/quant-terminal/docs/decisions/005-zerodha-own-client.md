# ADR-005: Own asyncio client for the Kite ticker

**Status:** Accepted and implemented. Live behaviour is unverified until the live smoke tests run.

## Context

The market-data worker streams several accounts from one asyncio event loop, and starts and stops feeds
as the database changes. Kite's official Python library, `kiteconnect` 5.2.2, streams through
`KiteTicker`, which runs on Twisted (the library pins `autobahn[twisted]==19.11.2`). Twisted's reactor
runs once per process and cannot be restarted, which does not fit an asyncio worker with per-account
feeds. The Kite WebSocket protocol and its binary packet layout are documented, and the platform needs
only a few REST calls.

## Decision

- `backend/app/providers/zerodha/` has its own streaming client on `websockets`, with up to 3000
  instruments per connection and 3 connections per API key, and a binary tick parser built from the
  documented packet layout.
- An `httpx` client makes the REST calls: the session exchange and logout, the profile (token check)
  and the instrument dump. `/quote/ltp` is used only by the live smoke tests.
- `kiteconnect` is only in the optional `sdk-crosscheck` extra. When it is installed, a unit test
  checks the parser against its reference parser.
- `backend/tests/unit/test_architecture.py` fails if runtime code imports `kiteconnect`, `twisted` or
  `autobahn`, or if any of them becomes a runtime dependency.

## Consequences

- One event loop holds every Kite connection, and feeds can stop and restart freely.
- The client and parser are maintained here: a protocol change at Kite needs a code change. Fixture
  tests cover the parser; [zerodha.md](../providers/zerodha.md#verifying-live) lists what still needs a
  live check.
