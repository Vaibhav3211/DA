# ADR-001: Modular monolith with three processes

**Status:** Accepted and implemented; amended at M9 for a fourth process, the backtest worker.

## Context

Phase 1 serves one user on one machine. It holds provider WebSocket feeds open for the whole trading
session, builds candles, runs strategies and serves a terminal UI. Feed handling must not run in API
request handlers: restarting the API or a slow request must not interrupt the feeds, and a busy feed
must not slow the API. Separate services would add deployment and versioning work that one user does
not need.

## Decision

- One Python package, `backend/app`, has three entry points that run as separate processes and share
  PostgreSQL and Redis:

  | Process | Role |
  | --- | --- |
  | `qt-api` | REST, WebSockets, health and metrics. Calls provider REST APIs only on request (logins, token checks, instrument refreshes) and never runs a feed. |
  | `qt-market-data-worker` | Every provider feed, the event pipeline and the candle builder. |
  | `qt-strategy-worker` | Strategies, the risk gate and signals. |

- The `qt` command line administers the platform through the same services as the API.
- Packages keep the layers apart (`api`, `services`, `domain`, `providers`, `market_data`,
  `strategies`, `signals`, `risk`, `persistence`, `streaming`). See
  [system-architecture.md](../architecture/system-architecture.md#backend-packages).
- The processes communicate only through Redis and PostgreSQL ([ADR-003](003-redis-streams-event-bus.md)).

## Consequences

- One code base, one dependency set and one image (`backend/Dockerfile`) serve all three processes.
- The workers follow the database. They reconcile with it periodically, and at once when a command
  arrives on `qt:commands`, so a lost command only delays a change.
- Run exactly one market-data worker and one strategy worker. There is no leader election: a second
  market-data worker would open duplicate provider connections, and a second strategy worker would
  evaluate every deployment twice.
- Several API processes can run, but the WebSocket connection limit (10 per user) applies to each
  process separately.

## Amendment (M9): the backtest worker

- A fourth entry point, `qt-backtest-worker`, builds historical datasets and runs backtests
  ([ADR-016](016-frozen-datasets-and-queued-backtests.md)). It shares the package, the image, PostgreSQL
  and Redis, and runs no feed and no live strategy.
- `scripts\start-dev.ps1` opens it in its own window, and Docker Compose runs it as the `backtest-worker`
  service.
- The API only queues backtest jobs; it never downloads history or replays candles.
- Run exactly one backtest worker, as for the other workers: it downloads one dataset at a time under
  the provider's rate limits, so a second worker could exceed them.
