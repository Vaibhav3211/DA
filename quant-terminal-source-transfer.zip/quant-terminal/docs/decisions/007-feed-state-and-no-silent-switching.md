# ADR-007: Explicit feed states, no silent source switching

**Status:** Accepted and implemented.

## Context

A signal computed from stale or missing data is worse than no signal. A feed can be connected but
silent, reconnecting or refused for authorization, and the market can be closed. Quietly switching an
instrument to another provider, or to the simulator, when its feed fails would mix sources with
different timestamps, symbols and quality, and would hide the outage.

## Decision

- Every provider-account stream has an explicit connection state (`IDLE`, `CONNECTING`, `CONNECTED`,
  `RECONNECTING`, `DISCONNECTED`, `AUTH_REQUIRED`, `STOPPED`) and a data status (`LIVE`, `DELAYED`,
  `STALE`, `RECONNECTING`, `DISCONNECTED` or `UNKNOWN`; simulator data is always `SIMULATED`).
- Market sessions have a separate state: `PRE_OPEN`, `OPEN`, `POST_CLOSE`, `CLOSED`, `HOLIDAY` or
  `UNKNOWN`.
- A supervisor per stream reconnects with jittered backoff; a requested reconnect skips the backoff.
  A heartbeat watchdog reconnects after `FEED_HEARTBEAT_TIMEOUT_SECONDS` (10) without data or heartbeat.
  A tick-silence watchdog reconnects after `FEED_TICK_SILENCE_RECONNECT_SECONDS` (120) without ticks,
  but only while the stream is subscribed and the session is open.
- An account's state combines its streams. Streams still starting next to connected ones read as
  `CONNECTING`, not as an outage.
- **No silent switching.** Each workspace instrument names its source provider and may pin an account.
  When that feed fails, the instrument's data turns stale or disconnected; no other provider takes over,
  and the simulator is never attached to real exchange symbols. Changing the source is an explicit,
  audited workspace change.
- The `data_quality` risk rule blocks signals while the feed is `STALE`, `RECONNECTING`, `DISCONNECTED`
  or `UNKNOWN`.

## Consequences

- Outages show up in the feed status, the health alerts and the data badges instead of being hidden.
- There is no automatic failover. During an outage the affected instruments produce no actionable
  signals until the feed recovers or the user changes the source.
- An illiquid instrument reads `STALE` after `DATA_STALE_AFTER_SECONDS` (30) without ticks, even when its
  feed is healthy.
