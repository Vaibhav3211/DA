# ADR-014: REST through the Next.js proxy, WebSockets direct, Kite callback on the frontend origin

**Status:** Accepted (M6). Never run yet: verify with the frontend's
[first-run checklist](../../frontend/README.md#first-run-checklist).

## Context

The API listens on port 8000 and the frontend on port 3000. Pages calling the API's origin directly
would need CORS with credentials. Next.js rewrites proxy HTTP requests, but they do not carry
WebSockets.

## Decision

- **REST** goes to `/api/v1/...` on the frontend's origin. `next.config.ts` rewrites `/api/:path*` to
  `BACKEND_URL`, which is fixed at build time. The session cookie is therefore first-party, no CORS is
  needed, and the app never reads the HttpOnly cookie.
- **WebSockets** go straight to the API: to `NEXT_PUBLIC_WS_URL`, or to `ws://<page host>:8000` when it
  is empty. Browsers send cookies to every port of the same host, so the session cookie reaches the
  API.
- **The Kite callback uses the frontend origin:** `ZERODHA_REDIRECT_URL` is
  `http://localhost:3000/api/v1/providers/zerodha/callback`. The callback is proxied like any REST call
  and answers with a 303 to `FRONTEND_BASE_URL/providers?zerodha=connected` (or
  `?zerodha=error&code=...`). A login started by `qt zerodha login` shows the address to paste instead.

## Consequences

- The browser must reach both ports under the same host name. Open `http://localhost:3000`, not
  `127.0.0.1`, which is not in the default `ALLOWED_ORIGINS`.
- The API sees every proxied request as coming from the Next.js server. Every browser shares the
  per-address sign-in limits, and audit entries show the proxy's address. `X-Forwarded-For` is not
  trusted.
- The redirect URL registered in the Kite developer console must equal `ZERODHA_REDIRECT_URL` exactly.
  Change an older `backend/.env` that still points at port 8000.
- Unverified until the frontend runs: that the proxy forwards cookies, the `Origin` header and the
  callback's 303 as expected.
