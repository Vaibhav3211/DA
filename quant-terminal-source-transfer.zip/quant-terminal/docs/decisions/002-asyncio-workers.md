# ADR-002: Plain asyncio workers, no task queue

**Status:** Accepted and implemented, except the planned instrument-refresh scheduler (see
[Not built](#not-built)). Amended at M9 for backtest jobs.

## Context

The workers' load is long-lived: provider connections stay open all session, candles form continuously
and strategies react to them. Task-queue frameworks such as Celery, ARQ or Dramatiq are built for short,
independent jobs. They would add a broker protocol, job retries and worker pools that this load does not
use.

## Decision

- Each worker is a plain asyncio process with its own loops.
- The market-data worker runs a supervisor per provider stream and an upkeep loop. Every
  `SUBSCRIPTION_RECONCILE_INTERVAL_SECONDS` (30), the upkeep loop expires the access tokens that have
  run out and reconciles the feeds with the database. A command on `qt:commands` triggers it at once.
- The strategy worker reads the candle stream (and the event streams, for strategies that ask for
  them), refreshes its deployments every `DEPLOYMENT_REFRESH_SECONDS` (10) and expires open signals at
  their `valid_until`.
- Supervision is outside the processes. Docker Compose restarts the containers
  (`restart: unless-stopped`); locally, `scripts\start-dev.ps1` starts each process in its own window.
- On Ctrl+C or SIGTERM a worker stops cleanly: the market-data worker disconnects its feeds and stores
  the candles still forming. SIGTERM handling is not available on Windows. Compose gives the
  market-data worker 30 s to stop.

## Not built

The plan also put a scheduler for instrument refreshes into the worker. It was not built. The instrument
masters are refreshed by hand, with `qt instruments refresh <provider>` or
`POST /api/v1/instruments/refresh`, as a step of each trading day (see the
[live-feed runbook](../operations/live-feed-runbook.md#each-trading-day)). A second refresh for a
provider whose refresh is still running is refused with `instrument_refresh_running`.

## Consequences

- Few moving parts: no extra broker, job tables or worker pools.
- Nothing retries a failed job. Each loop logs its own errors and tries again on its next pass; a failed
  token-expiry check, for example, is logged and the reconciliation still runs.
- The instrument masters go stale unless someone refreshes them.

## Amendment (M9): backtest jobs

- Building datasets and running backtests are independent jobs, the load task queues are built for.
  They still get no task queue: the backtest worker is another plain asyncio process, and its jobs are
  PostgreSQL rows claimed with `SELECT … FOR UPDATE SKIP LOCKED`
  ([ADR-016](016-frozen-datasets-and-queued-backtests.md)).
- `backtest_datasets` and `backtest_runs` are therefore job tables, as well as the records of the
  results. There is still no broker or worker pool.
- The worker fails a job that has shown no progress for 5 minutes. Nothing retries a failed job: you
  queue it again.
