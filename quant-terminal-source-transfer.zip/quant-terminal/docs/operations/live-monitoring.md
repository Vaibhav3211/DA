# Live monitoring

How to run a saved strategy configuration on live data, watch how it is doing, read its signals and stop
it. To add your own strategy first, see [strategy-registration.md](../strategy-registration.md). Signals
are information only: nothing in the platform places orders
([ADR-011](../decisions/011-no-order-execution.md)).

Run `qt` with the backend virtual environment active (`backend\.venv\Scripts\Activate.ps1`). Below,
`WORKSPACE` is a workspace slug and `CONFIGURATION` is a saved configuration's label or id
(`qt strategies deployments` lists them).

## Before you start

- **The strategy worker runs.** Monitoring happens in `qt-strategy-worker`, which `scripts\start-dev.ps1`
  starts together with the API and the market-data worker.
- **The instruments stream.** They are in the workspace and their provider is connected; see the
  [live-feed runbook](live-feed-runbook.md#before-the-first-live-day).
- **Signals on live data are allowed.** Until `LIVE_SIGNALS_ENABLED=true` is set in `backend/.env`, the
  `live_signals` risk rule blocks every signal on live (non-simulator) data. The API and the strategy
  worker read the setting at start-up, so restart both after changing it. Signals on simulated data are
  never actionable, whatever the setting.

## The Strategy panel

Select an instrument on a workspace page. The **Strategy** panel beside its chart shows:

- **Saved configurations** that cover the instrument, each with its monitoring state, settings and
  actions.
- **Strategies:** every strategy in the code, with its version, description and a verdict for this
  instrument: **Compatible**, **Compatible with warnings** or **Not compatible**. The verdict sums up five
  checks: Market, Instrument, Timeframe (against the chart's interval), Data and Warm-up. Expand a
  strategy to read each check, the closed candles stored for its warm-up, its signal conditions and
  everything it needs.

A strategy marked **Not catalogued** or **Catalogue outdated** needs **Sync catalogue** (or
`qt strategies sync`) before you can configure it, so that its settings form matches the code.

## Saving a configuration

A saved configuration is one strategy version with its settings and its instruments. Its live signals,
its chart markers and its [backtests](../backtesting.md) all use it.

1. Expand a compatible strategy and choose **New configuration…**.
2. Fill in the settings. The form is generated from the strategy's settings model; **Reset to defaults**
   restores the strategy's defaults.
3. Choose its instruments:
   - **Chosen instruments**, by default the chart's instrument. Instruments added to the workspace later
     are not included.
   - **The whole workspace**, including instruments added later. This needs an explicit confirmation:
     "I want this configuration to watch every instrument in WORKSPACE, not only the ones I chose."
4. Save. Saving starts nothing: live signals stay off.

From the command line, with the template strategy of the
[registration guide](../strategy-registration.md#template):

```powershell
qt strategies create india-equity my.rsi_reversion --instrument NSE:CASH:EQUITY:INFY --set oversold=25
qt strategies create india-equity my.rsi_reversion --whole-workspace --label "rsi all"
```

`--instrument` takes one or more canonical keys and can be repeated. The label defaults to the strategy
id, numbered if it is taken. A workspace can hold several configurations of the same strategy (for
example, with different settings or instruments), each with its own label.

## Four separate actions

Each saved configuration in the Strategy panel has four actions, and none of them triggers another.
Opening a chart, choosing a strategy, saving a configuration and applying it to the chart never start
monitoring.

| Action | What it does |
| --- | --- |
| **Apply to chart** | Draws the signals the configuration has stored for this instrument, and the trades of its current backtest, on the chart. Press it again to remove them. It starts nothing. The page remembers what is applied only until it reloads. |
| **Run backtest…** | Opens the backtest dialog: choose (or request) historical candles of the instrument, then queue a backtest on the backtest worker. It does not start live signals. Each configuration shows its latest backtest on the instrument, or "Not backtested" ([backtesting](../backtesting.md)). |
| **Enable live signals…** | Asks first, then has the strategy worker monitor the configuration on the server. |
| **Stop live signals** | Stops monitoring at once, without asking. |

**Edit…** and **Archive** are described [below](#editing-and-upgrading). The workspace page's
**Strategies** tab lists every configuration of the workspace, and the **Strategies** page lists them per
strategy, with the run history. Both have the live-signal, edit and archive controls, but not
**Apply to chart** or **Run backtest…**.

## Enabling live signals

**Enable live signals…** opens a dialog with the strategy, workspace, instruments and settings, and these
notes:

- "Monitoring runs on the server, not in this browser: it carries on after you close the chart or the
  browser, until you stop live signals."
- "Every signal still goes through the risk rules, data freshness included. Blocked signals are kept with
  their reasons."
- "Signals are information only: nothing here places orders."

A **Before you enable** box lists the configuration's current warnings, including anything that would
block it right now, such as the kill switch or `LIVE_SIGNALS_ENABLED=false`. Confirm with **Enable live
signals**. From the command line:

```powershell
qt strategies enable WORKSPACE CONFIGURATION
```

The API records the change in the audit log (`strategy.enable`) and tells the strategy worker through
`RELOAD_DEPLOYMENTS`. The worker also re-reads the configurations every `DEPLOYMENT_REFRESH_SECONDS`
(10 s), so a lost command only delays the start. The worker then starts a run: it warms the indicators
up from stored candles and calls the strategy with each candle that closes from then on (see
[from candle to signal](../architecture/data-flow.md#4-from-candle-to-signal)).

**Where it runs.** Closing the chart, the tab or the browser, or signing out, changes nothing: the
strategy worker monitors every enabled configuration until its live signals are stopped. Restarting the
API changes nothing either. If the strategy worker stops, monitoring stops with it and the configuration
shows **Failed**. When the worker starts again, it resumes every enabled configuration, warming up from
stored candles. Candles that closed while it was down only warm the indicators up: the strategy is not
called with them, so they produce no signals.

**Enabling again is safe.** Enabling a configuration whose live signals are already on changes nothing:
there is never a second run of the same configuration. Enabling is refused, with the reason shown in
the dialog or printed by `qt`, when:

| Refusal | Message |
| --- | --- |
| It is archived | "Cannot turn on live signals for 'LABEL' in workspace 'WORKSPACE': it is archived" |
| Its code no longer fits | "Cannot turn on live signals for 'LABEL' in workspace 'WORKSPACE': PROBLEM", where the problem is one of the code problems listed under **Blocked** in [monitoring states](#monitoring-states) |
| It would duplicate another | "Configuration 'OTHER' already runs STRATEGY VERSION with the same settings on INSTRUMENTS; stop its live signals first, or change this configuration's settings or scope" |

The duplicate check applies to enabled configurations of the same workspace that run the same strategy
version with the same settings on overlapping instruments. The message names the instruments both
watch, or says "the whole workspace" when both watch all of it. Enabling locks the workspace while it
checks, so two enables at the same moment cannot both get through.

Enabling is *not* refused for conditions that may pass, such as a disabled workspace, the kill switch or
`LIVE_SIGNALS_ENABLED=false`: the configuration is enabled and shows **Blocked** with the reason until
the condition clears.

## Monitoring states

The Strategy panel, the configuration lists and the rows under the chart show each configuration's state
as a badge; the panel and the lists also show its reasons and warnings. They refresh every 15 seconds.
`qt strategies deployments` prints the state in its MONITORING column, and
`qt strategies status WORKSPACE CONFIGURATION` prints it with its reasons (`Because`), warm-up progress
and warnings, followed by the last run: its status, instruments covered, candles, events and signals
processed, failures, timeouts, an open circuit and the last error.

The first state that applies is shown:

| State (`qt`) | Meaning | Reasons you may see | What to do |
| --- | --- | --- | --- |
| **Stopped** (`stopped`) | Live signals are off: nothing monitors it. | None. Warnings start with "If enabled, it would be blocked: …". | Enable it when ready. |
| **Blocked** (`blocked`) | Live signals are on, but it cannot run. | "workspace WORKSPACE is disabled"; "strategy ID is no longer in the code"; "it was saved with version A but the code has B; save it again to upgrade"; "its instrument scope is unreadable or empty; save it again with its instruments"; "Its scope has no instruments: the workspace has none"; "None of the instruments in its scope can run: KEY: REASON; …" | Switch the workspace on; restore the strategy's code or stop live signals; save the configuration again ([Editing and upgrading](#editing-and-upgrading)); add instruments, or fix the listed reasons. |
| **Failed** (`failed`) | Live signals are on, but the run failed or the strategy worker is not reporting. | "The strategy worker is not running (no recent heartbeat); start qt-strategy-worker"; "The strategy worker's heartbeat cannot be read from Redis (ERROR)"; "Its run failed: ERROR"; "The strategy kept failing, so the worker paused calling it (circuit open); last error: ERROR" | Start the worker or Redis. For a run failure, fix the cause in the error (see below). |
| **Blocked** (`blocked`) | It runs, but the risk gate blocks every signal it proposes. | "Kill switch is engaged (REASON)"; "Signals are paused for this workspace (REASON)"; "Risk rule KEY has invalid stored parameters (ERROR); fix with qt risk set or qt risk reset"; "Signals on live data are disabled (set LIVE_SIGNALS_ENABLED=true to allow them)" | Release the kill switch, resume the workspace, fix the rule, or set the flag and restart the API and the strategy worker. Meanwhile, each proposed signal is stored as `BLOCKED` with its reasons. |
| **Starting** (`starting`) | The worker is starting a run of the current settings. | "Waiting for the strategy worker to start a run with the current settings"; "The run is loading the stored candles it warms up from" | Wait; a command starts it within moments, a refresh within 10 s. |
| **Warming up** (`warming-up`) | It runs, but some instruments still lack the closed candles the strategy needs. | "N of M instruments still lack the closed candles the strategy needs; their signals start once they have them" | Wait. `qt strategies status` shows the most candles still needed per interval. |
| **Running** (`running`) | The strategy worker monitors it. | None. | Nothing. |

During warm-up the strategy is still called with each closed candle, but its indicators have no value
until they have enough candles, so a strategy that waits for its indicators proposes nothing yet.

**Run failures.** A run fails when it cannot start (for example "invalid configuration: …", or "it needs
INTERVAL candles, which CANDLE_INTERVALS does not build") or when updating its market state raises. The
worker retries after a growing delay. It does not retry the two problems above until the configuration
changes or the worker restarts. After `STRATEGY_FAILURE_THRESHOLD` (5) consecutive errors or timeouts
of the strategy itself, its circuit opens: the worker lets one trial call through every
`STRATEGY_CIRCUIT_RESET_SECONDS` (60 s), and a successful one closes the circuit. A code fix needs a restart of the strategy worker; see
[troubleshooting](troubleshooting.md#signals).

**Warnings** limit a configuration without changing its state:

- "Signals on live data are disabled (…): the signals of X of its Y instruments are blocked", when only
  some of its instruments use live data.
- "Its instruments use simulated data: its signals are informational only".
- "N instruments left out: KEY: REASON; …", for instruments of its scope that cannot run.

Risk rules that judge each signal on its own, such as data freshness, the session, frequency, price
sanity and volatility, do not change the state: each signal they block is stored as `BLOCKED` with its
own reasons. The rules are listed in [from candle to signal](../architecture/data-flow.md#4-from-candle-to-signal).

## Signals on the chart

**Apply to chart** adds a row under the chart with the configuration's number, label, strategy version,
monitoring state and how many of its signals fall on the chart's bars. Its **×** removes it from the
chart; its live signals are not affected. Several configurations can be applied at once, each with its
own number.

| Marker | Signal |
| --- | --- |
| Green ▲ below the bar | BUY |
| Red ▼ above the bar | SELL |
| Yellow ■ above the bar | EXIT |
| Grey, same shapes | Blocked by the risk rules |

- A marker carries its configuration's number. It sits on the chart bar in which its signal became known:
  the bar holding the last second of the candle that produced it or, when the signal was generated
  before that candle closed (or names no candle), the bar holding the moment it was generated.
- The chart loads the newest 200 signals of each applied configuration for the instrument. Signals older
  than the first bar are only in the signal history. HOLD, WATCH and INVALIDATED signals are not drawn.
- The markers update while you watch: the browser is always subscribed to signal changes.
- These are live signals. The trades of a configuration's current backtest are drawn as muted circles
  labelled like `1·BT3` ([backtest trades on the chart](../backtesting.md#backtest-trades-on-the-chart)).
- **List the N marked signals** lists the newest 100 marked signals.

Clicking a marker opens the signal. When several markers share the bar, a row of buttons lets you pick
one.

## Reading a signal

The signal's dialog, also opened from the signal lists, shows:

| Part | Contents |
| --- | --- |
| Header | Type, symbol, exchange and segment, strategy id and when it was generated |
| Badges | Status, actionable or informational, the risk outcome and the data quality when it was generated |
| Levels | Entry, stop loss, risk : reward, score (its definition on hover) and targets, where the strategy supplied them |
| **Why** | The strategy's explanation and reasons |
| **Invalidated when** | The conditions that would invalidate it, if any |
| **Indicators** | Each indicator's value, version, input candles (count, interval, first and last) and data quality |
| **Configuration** | The saved configuration's label, the strategy version, the settings, the settings hash, the code fingerprint, when the run started, and the configuration id. A note warns when the configuration has been edited since: the settings shown are the ones that generated the signal. |
| **Risk gate** | The outcome, when it was evaluated, and every check: passed, or failed as `BLOCK` or `WARN`, with its message. Earlier decisions of the same signal are listed below. |
| **History** | Its lifecycle events (generated, updated, superseded, closed, expired, …) |
| **Provenance** | Strategy and version, workspace, provider, source candle, source event, last update, valid until, closed, superseded by, saved configuration id, run and signal id |

A signal is **actionable** only when the risk gate allowed it, it is a BUY, SELL or EXIT, its strategy
declares `can_emit_actionable`, and it is based on live data. Every other signal is informational.

**Signal history.** The **Signals** page lists every signal and filters by workspace, strategy, type,
status, actionable or informational, dates and open signals; the workspace page has its own list. From the
command line:

```powershell
qt signals list --workspace WORKSPACE --strategy STRATEGY_ID --instrument NSE:CASH:EQUITY:INFY --open
qt signals list --status blocked --since 2025-01-01
qt signals show SIGNAL_ID     # levels, reasons, indicators, risk checks and history
```

**Lifecycle.** A configuration has at most one open signal per instrument. A repeat of the open signal
with changed levels updates it, a different signal supersedes it, an EXIT closes it, and an INVALIDATED
candidate closes it as invalidated. An open signal expires at its *valid until*: the strategy's
`valid_for_seconds`, or `SIGNAL_DEFAULT_VALIDITY_SECONDS` (900 s) when it sets none. The strategy worker
sweeps for expired signals every 15 seconds. See
[from candle to signal](../architecture/data-flow.md#4-from-candle-to-signal).

## Stopping live signals

**Stop live signals** in the Strategy panel or a configuration list, or:

```powershell
qt strategies disable WORKSPACE CONFIGURATION
```

- From that moment, the `strategy_enabled` risk rule blocks every signal the configuration proposes. The
  worker stops its run when the command arrives, or at its next refresh (within 10 s). A signal proposed
  in between is stored as `BLOCKED`.
- **Open signals stay open** until they expire at their *valid until*. Stopping does not close them.
- Stopping always works, even after the strategy's code is gone. Its runs and signals stay.
- Stopping again changes nothing. The audit log records `strategy.disable`.

To block signals more widely, use the kill switch (every workspace) or a workspace pause; see
[stopping signals](live-feed-runbook.md#stopping-signals). Those keep the configurations enabled, and they
show **Blocked** until released.

## Editing and upgrading

**Edit…** opens the configuration's form with its saved settings and instruments. While its live signals
are on, the form says so: on **Save**, the strategy worker restarts monitoring with the new settings,
instruments or version, and a change that would duplicate another enabled configuration is refused. The
audit log records `strategy.deploy`.

```powershell
qt strategies update WORKSPACE CONFIGURATION --set oversold=20
qt strategies update WORKSPACE CONFIGURATION --instrument NSE:CASH:EQUITY:TCS   # replaces its instruments
qt strategies update WORKSPACE CONFIGURATION --reset-config      # start from the defaults
qt strategies update WORKSPACE CONFIGURATION                     # move it to the code's version
```

**A new strategy version.** When the code's version changes, configurations saved with the old version
show **Blocked**: "it was saved with version A but the code has B; save it again to upgrade". Sync the
catalogue (restarting the strategy worker does it too), then save each configuration again with
**Edit…** → **Save** or `qt strategies update`. **Edit…** stays disabled until the catalogue has the
code's version. See [versions and code identity](../strategy-registration.md#versions-and-code-identity).

Each signal keeps the settings, strategy version and code fingerprint of the run that generated it, so
editing a configuration never rewrites its history.

## Archiving

**Archive** appears once live signals are off (`qt strategies archive WORKSPACE CONFIGURATION`; it refuses
while they are on). An archived configuration leaves the lists and frees its label. Its runs and signals
stay, but it cannot be edited or enabled again: save a new configuration instead.
`qt strategies deployments --all` still lists it.

## Command reference

```powershell
qt strategies list                                   # the catalogue
qt strategies show STRATEGY_ID                       # what it needs and its settings
qt strategies check                                  # whether every strategy in the code registers
qt strategies sync                                   # bring the catalogue up to date with the code
qt strategies deployments [--workspace WORKSPACE] [--strategy STRATEGY_ID] [--all]
qt strategies status WORKSPACE CONFIGURATION         # state, reasons, warnings, last run
qt strategies create WORKSPACE STRATEGY_ID (--instrument KEY ... | --whole-workspace) [--label LABEL] [--set NAME=VALUE ...]
qt strategies update WORKSPACE CONFIGURATION [--instrument KEY ... | --whole-workspace] [--label LABEL] [--set NAME=VALUE ...] [--reset-config]
qt strategies enable WORKSPACE CONFIGURATION
qt strategies disable WORKSPACE CONFIGURATION
qt strategies archive WORKSPACE CONFIGURATION
qt strategies runs [--workspace WORKSPACE] [--strategy STRATEGY_ID] [--config CONFIGURATION] [--limit N]
```

`qt strategies deployments` ends with "N blocked or failed; see why: qt strategies status WORKSPACE
CONFIGURATION" when some need attention.

Backtests have their own commands, `qt datasets` and `qt backtests`
([command reference](../backtesting.md#command-and-api-reference)).
