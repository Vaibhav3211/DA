# Troubleshooting

Start with two checks:

- `qt check-config` prints the effective settings, with secrets masked, and tests the PostgreSQL and
  Redis connections.
- The **System** page, or `GET /api/v1/system/health`, lists every alert. The alerts are explained in the
  [runbook](live-feed-runbook.md#watching-the-feed).

Problems in the browser are covered in the [frontend README](../../frontend/README.md#troubleshooting)
and WebSocket close codes in [websocket-protocol.md](../websocket-protocol.md#close-codes-and-reconnecting).

## Configuration

| Symptom | Cause and fix |
| --- | --- |
| A changed setting has no effect | Each process reads its settings once, at start-up: restart the API and the workers. Settings come from `backend/.env`, then a `.env` in the current directory, then environment variables, each overriding the one before. `qt check-config` shows the result. |
| Start-up fails with `SIMULATOR_ENABLED is only allowed when APP_ENV is development or replay` | Turn the simulator off, or use one of those environments. |
| Start-up fails with `MARKET_DATA_ENABLED must be false when APP_ENV is replay` | Replay never streams live data. |
| Start-up fails with `COOKIE_SECURE must be true in production` or `ENCRYPTION_KEY is required in production` | `APP_ENV=production` needs both. See [secrets and authentication](../security/secrets-and-auth.md). |
| Start-up fails with `ORDER_EXECUTION_ENABLED must be false` | Order execution is not implemented. |
| Logs are hard to read in a terminal | `LOG_JSON=true` (the default) writes JSON lines; `LOG_JSON=false` writes readable console output. |

## Signing in to the terminal

| Symptom | Cause and fix |
| --- | --- |
| 403 `origin_not_allowed` | The page's origin is not in `ALLOWED_ORIGINS`. Open `http://localhost:3000`, or add the origin and restart the API. Use `localhost`, not `127.0.0.1`, in every browser-facing URL so the session cookie is sent. |
| "Too many failed sign-in attempts" | See [terminal sign-in](../security/secrets-and-auth.md#terminal-sign-in). `qt reset-password` sets a new password and unlocks the user. |

## Provider accounts and logins

| Error code or symptom | Cause and fix |
| --- | --- |
| `provider_account_already_enabled` | Only one account per provider can be enabled. Disable the other one first. |
| "Streaming is off for this provider: live market data is off" | Set `MARKET_DATA_ENABLED=true` and restart the API and the market-data worker. |
| `redirect_url_mismatch` | The address pasted into `qt zerodha login` is not `ZERODHA_REDIRECT_URL`. Paste the address the browser showed after the Kite login, and make sure the Kite app's redirect URL equals `ZERODHA_REDIRECT_URL` exactly. |
| `login_state_missing` | The redirect carried no login state. Start the login again. |
| `login_state_mismatch` | The login was started from the command line (paste the address into the waiting `qt zerodha login`), or by another terminal user. |
| `provider_user_mismatch` | The account is bound to a different Kite user. Log in as that user, or add a separate account. |
| `token_budget_exhausted` | Groww allows 150 access-token requests per account in 24 hours. Wait before creating another. |
| `auth_required` or `token_expired` alert every morning | Expected: tokens stop working around 06:00 IST. Follow the [daily routine](live-feed-runbook.md#each-trading-day). |

## Instruments and subscriptions

| Error code or symptom | Cause and fix |
| --- | --- |
| `zerodha_api_key_missing` | The Zerodha download needs a Kite API key. Enable a Zerodha account, set `ZERODHA_API_KEY`, or import a downloaded dump with `qt instruments refresh zerodha --file PATH`. |
| `instrument_dump_incomplete` | In an exchange and segment with at least 10 active instruments, the dump lacks more than half of them. Check the source. If the instruments really were withdrawn, rerun with `--force` to close them. |
| `instrument_refresh_running` | Another refresh of the same provider is running. Wait for it. |
| `qt workspaces show` lists `skipped: … has no enabled account` | Enable an account of that provider. |
| `skipped: its workspace pins a … account that is not enabled` | The instrument was added with `--account` for an account that is now disabled. Enable it, or remove and add the instrument again. |
| `skipped: not listed by …` | The instrument is inactive or missing from the provider's instrument master. Refresh the instruments. |
| `skipped:` with a reason about exchanges, segments or modes | The provider does not offer it. See the [capability matrix](../providers/capability-matrix.md). |
| `skipped: it is not in the current plan; show the workspace again` | The workspace changed while the command was building its plan. Run the command again. |

## Feed and data quality

| Symptom | Cause and fix |
| --- | --- |
| No data at all | Check, in order: `MARKET_DATA_ENABLED`, `qt accounts list` (is the account enabled and `AUTHENTICATED`?), `qt workspaces show` (are instruments `planned`?), the `worker_down` alert, and the market hours. |
| One instrument shows `STALE` | It has not traded for `DATA_STALE_AFTER_SECONDS` (30). Normal for illiquid instruments: a quiet instrument cannot be told apart from one the feed stopped sending. |
| `feed_stale` alert | A whole stream sent nothing for 30 s during market hours. The provider may be lagging. While the market is open, the stream reconnects on its own after `FEED_TICK_SILENCE_RECONNECT_SECONDS` (120) without ticks. |
| Data shows `DELAYED` | Events arrive more than `DATA_DELAYED_LATENCY_SECONDS` (2) after the time the provider stamped on them. Check the provider, and that the computer's clock is synchronised (Windows: Settings → Time & language → Date & time, *Set time automatically*). |
| `provider_disconnected` keeps coming back | The alert message carries the last error. `qt_feed_reconnects_total` counts the attempts. |
| Groww candles have no volume | Expected until `GROWW_FEED_VOLUME_IS_CUMULATIVE=true`. Set it only after confirming on the live feed that `volume` is the day's cumulative volume ([Groww field mapping](../providers/groww.md#field-mapping)). |
| `calendar_unverified` or `calendar_coverage_ending` | The exchange calendar of the installed `exchange_calendars` runs out. Update the package, or add calendar overrides. |

`qt_market_events_dropped_total{reason}` counts the events dropped before publishing:

| Reason | Meaning and fix |
| --- | --- |
| `queue_full` | The worker processes events more slowly than they arrive (see the `queue_depth_high` alert). Stream fewer instruments, or look for slow Redis or PostgreSQL. |
| `malformed` | A provider message could not be parsed. The log has `feed_malformed_payload`; a provider format change needs a code fix. |
| `invalid` | An event failed validation; the log has `feed_invalid_tick` with the problem. Timestamps more than `EVENT_MAX_FUTURE_SECONDS` (30) ahead usually mean the computer's clock is behind. |
| `duplicate` | The same payload as the previous event of that instrument. Harmless. |
| `unmapped` | The provider token has no instrument. Refresh the instruments. |
| `publish_failed` | Publishing to Redis failed. Check Redis and `qt_redis_errors_total`. |

## Signals

| Symptom | Cause and fix |
| --- | --- |
| Signals are `BLOCKED` | `qt signals show SIGNAL_ID` lists every risk check. Common causes: `LIVE_SIGNALS_ENABLED=false`, the kill switch (`qt kill-switch status`), or a paused workspace (`qt risk show workspace_pause --workspace WORKSPACE`). |
| No signals at all | `qt strategies deployments` shows each saved configuration's monitoring state, and `qt strategies status WORKSPACE CONFIGURATION` shows why (`Because`), its warm-up, and its last run, failures and last error. A configuration whose live signals are off shows **Stopped**: turn them on with `qt strategies enable WORKSPACE CONFIGURATION`. |
| A configuration shows **Blocked**, **Failed** or **Warming up** | Its reasons say why. [Monitoring states](live-monitoring.md#monitoring-states) lists every reason and what to do. |
| Enabling is refused with "already runs … with the same settings" | Another enabled configuration of the workspace runs the same strategy version with the same settings on some of the same instruments. Stop its live signals, or change this configuration's settings or instruments. |
| A strategy stopped evaluating | After `STRATEGY_FAILURE_THRESHOLD` (5) consecutive errors or timeouts its circuit opens, and one trial call goes through every `STRATEGY_CIRCUIT_RESET_SECONDS` (60). `qt strategies status` shows "Circuit open" and the last error; `qt_strategy_circuit_open` counts the open circuits per strategy. |

## Backtests

The [backtesting guide](../backtesting.md) explains every refusal and result. The usual problems:

| Symptom | Cause and fix |
| --- | --- |
| "The backtest worker is not running, so queued jobs wait; start qt-backtest-worker" | Start `qt-backtest-worker` (with the backend virtual environment active), or rerun `scripts\start-dev.ps1`. Run exactly one. The System page's `worker_down` alert does not watch this worker, so the warning appears only beside datasets and backtests. |
| A dataset stays `PENDING`, or a backtest `QUEUED`, while the worker runs | The worker takes one job at a time, datasets first, oldest first, so an earlier download or replay is still going. `qt datasets list --status building` and `qt backtests list --status running` show it. |
| A request for candles is refused at once | The message says why: reversed or future dates, more than 20 years, more candles than `BACKTEST_MAX_CANDLES`, a segment or interval the provider does not offer, no recorded candles in the range, or no enabled account for the provider. A Groww download also needs the instrument's Groww symbol: refresh the Groww instrument master. See [requesting candles](../backtesting.md#requesting-candles). |
| A dataset is `FAILED` | `qt datasets show DATASET_ID` gives the reason; fix the cause and request it again, since a failed dataset is never reused. A provider error usually means the access token expired (log in again) or, for Zerodha, that the Kite Connect app lacks the paid plan ([requirements](../providers/zerodha.md#subscription-requirements)). "The backtest worker stopped while building it" means the worker stopped, or lost the database, for 5 minutes. |
| A backtest is refused when queued | See [why a backtest is refused](../backtesting.md#why-a-backtest-is-refused). The usual causes are an instrument outside the configuration's scope, no trade rules, and a dataset at another interval than the strategy's. |
| A backtest is `FAILED` with "… queue it again" | The dataset, the strategy's code or the configuration's settings changed after it was queued, or the worker stopped while running it. Queue it again. |
| A backtest fails with "stopped after … at candle i of n" | It reached `BACKTEST_MAX_SECONDS` (600). Use a shorter dataset, or raise the limit and restart the backtest worker. |
| No trades, or far fewer than expected | The results' **Signals: not trades** section counts the signals each risk rule blocked. Signals decided on a session's last candle, and on every daily candle, fall in `POST_CLOSE` and are blocked by `session_status`: see [signals at the close](../backtesting.md#signals-at-the-close-and-session_status). Also check `sides`, and the entries not taken, which list their reasons. |
| The panel shows **Outdated** | Settings changed since that backtest, and the panel lists which. The result is kept; run a new backtest for the current settings. Changing the workspace's history risk rules (`session_status`, `frequency`, `price_sanity`, `volatility_limit`, `stop_loss_required`) outdates its backtests too. |
| "Backtest trades not drawn: …" above the chart | Only the current backtest is drawn, and only when the chart shows the interval and provider it replayed. Follow the reason, for example by switching the chart's interval. |

## Workers and stores

| Alert | Fix |
| --- | --- |
| `postgres_unavailable`, `redis_unavailable` | Start them: `docker compose -f infra\docker-compose.yml up -d --wait postgres redis`. |
| `worker_down` | Start `qt-market-data-worker` or `qt-strategy-worker` (with the backend virtual environment active), or rerun `scripts\start-dev.ps1`. Workers report every 5 s; a worker silent for 15 s counts as down. The backtest worker is not watched here: see [Backtests](#backtests). |
| `queue_depth_high` | See `queue_full` above. |
