# Live-feed runbook

Day-to-day operation of the live Zerodha and Groww feeds. Installation is in the
[README](../../README.md), provider details are in [zerodha.md](../providers/zerodha.md) and
[groww.md](../providers/groww.md), and problems are in [troubleshooting.md](troubleshooting.md).

Run `qt` with the backend virtual environment active (`backend\.venv\Scripts\Activate.ps1`). It reads
`backend/.env` from any working directory. Times are IST. NSE and BSE trade 09:15 to 15:30 on weekdays.

## Before the first live day

1. **Provider accounts.** Add an account, store its credentials and enable it, as described in
   [Zerodha: setting up an account](../providers/zerodha.md#setting-up-an-account) and
   [Groww: setting up an account](../providers/groww.md#setting-up-an-account-and-daily-tokens). Only one
   account per provider can be enabled.
2. **Turn live data on.** Set `MARKET_DATA_ENABLED=true` in `backend/.env`, then restart the API, the
   market-data worker and the strategy worker: each process reads its settings once, at start-up.
3. **Log in and load instruments** as in the [daily routine](#each-trading-day).
4. **Choose what to stream.** The first migration creates the India workspaces, enabled but empty:
   `india-equity`, `india-indices`, `india-index-futures`, `india-index-options`, `india-stock-futures`,
   `india-stock-options` and `india-long-term`. Add instruments by canonical key:

   ```powershell
   qt instruments search INFY --exchange nse --type equity
   qt workspaces add india-equity zerodha NSE:CASH:EQUITY:INFY NSE:CASH:EQUITY:RELIANCE   # --mode ltp|quote|full
   qt workspaces show india-equity
   ```

   Each instrument streams from the provider you name; the platform never switches providers on its
   own. `qt workspaces show` lists each instrument as `planned (<account>)` or `skipped: <reason>`. The
   market-data worker applies a change at once.
5. **Signals (optional).** The `live_signals` risk rule blocks every signal on live data until
   `LIVE_SIGNALS_ENABLED=true` (restart the API and the strategy worker after setting it). Save a
   configuration of a strategy for the instruments it should watch, then turn its live signals on, with
   the **Strategy** panel beside a chart or from the command line:

   ```powershell
   qt strategies list
   qt strategies create india-equity STRATEGY_ID --instrument NSE:CASH:EQUITY:INFY
   qt strategies enable india-equity CONFIGURATION
   qt strategies deployments            # each configuration's monitoring state
   ```

   [Live monitoring](live-monitoring.md) explains the states, the signal markers and how to stop live
   signals.

## Each trading day

Kite and Groww access tokens stop working overnight (around 06:00 IST), and nothing renews them. Before
09:15:

| Step | Command | Web app |
| --- | --- | --- |
| 1. Start the platform | `scripts\start-dev.ps1`, or the compose `app` profile | |
| 2. Log in to Zerodha | `qt zerodha login` | Providers → **Sign in with Kite** |
| 3. Create or paste the Groww token | `qt groww create-token`, or `qt groww set-token` | Providers → **Sign in** (**Renew token** once signed in) |
| 4. Refresh the instrument masters (Zerodha after about 08:30) | `qt instruments refresh zerodha`, then `qt instruments refresh groww` | |
| 5. Check | `qt accounts list`, `qt workspaces show india-equity` | System page |

- Log in before refreshing: the Zerodha download sends the day's access token when there is one.
- A stored token makes the market-data worker connect within moments; it does not need a restart.
- After a refresh the worker resubscribes with the new mappings. Kite reuses the tokens of expired
  contracts, so skipping the Zerodha refresh can attach ticks to the wrong instrument.

## Watching the feed

The **System** page, and `GET /api/v1/system/health` for a signed-in session, report an overall
`status`:

- `ok`: no warnings;
- `degraded`: at least one warning or critical alert;
- `down`: PostgreSQL or Redis is unreachable.

The report also lists the feature flags, the kill switch, the workers, every provider stream and
every account. Its alerts:

| Code | Severity | Meaning |
| --- | --- | --- |
| `postgres_unavailable`, `redis_unavailable` | critical | A store cannot be reached |
| `worker_down` | critical | A worker has sent no heartbeat for 15 s |
| `queue_depth_high` | warning | The market-data ingest queue is at least 80 % full (`PROVIDER_QUEUE_SIZE`, 20000) |
| `provider_auth_required` | critical | A stream was refused for authentication |
| `provider_disconnected` | critical (disconnected) or warning (reconnecting) | A stream is down |
| `feed_stale` | warning | A stream has had no data for `DATA_STALE_AFTER_SECONDS` (30 s) during market hours |
| `token_expired`, `auth_required` | critical | An enabled account needs a new login or token |
| `token_expiring` | info | An enabled account's token expires within 30 minutes |
| `account_disconnected` | warning | An enabled account was logged out |
| `credentials_missing` | warning | An enabled account lacks a credential its method needs |
| `kill_switch_engaged` | warning | Actionable signals are blocked |
| `calendar_unverified` | warning | The published exchange calendar has run out: regular weekday hours are assumed if `CALENDAR_EXTEND_BEYOND_COVERAGE` is on, otherwise sessions are unknown |
| `calendar_coverage_ending` | info | The published calendar ends within `CALENDAR_COVERAGE_WARNING_DAYS` (30) |

Without a session, `GET /health/live` answers while the API process runs, and `GET /health/ready` returns
503 unless PostgreSQL and Redis respond.

**Metrics.** Prometheus metrics are at `/metrics` on the API. Each worker serves its own on
`127.0.0.1:<port>/metrics` when `MARKET_DATA_WORKER_METRICS_PORT` or `STRATEGY_WORKER_METRICS_PORT` is
not 0. Useful series:

- `qt_feed_connected`, `qt_feed_subscriptions`, `qt_feed_reconnects_total`;
- `qt_provider_ticks_received_total`, `qt_market_events_published_total`;
- `qt_market_events_dropped_total{reason}`, where the reason is `queue_full`, `malformed`, `invalid`,
  `duplicate`, `unmapped` or `publish_failed`;
- `qt_event_source_latency_seconds`, `qt_candle_late_events_total`, `qt_candles_dropped_total{reason}`;
- `qt_signals_total`, `qt_strategy_circuit_open`, `qt_redis_errors_total`, `qt_db_write_errors_total`.

## Stopping signals

```powershell
qt kill-switch engage --reason "news event"     # blocks every new actionable signal
qt kill-switch status
qt kill-switch release --reason "resolved"      # all other risk checks still apply
qt risk pause india-equity --reason "checking feed"
qt risk resume india-equity
```

The System page has the same kill switch. Engaging, releasing, pausing and resuming are all recorded
in the audit log. Market data keeps streaming either way; nothing in the platform places orders.

## During the day

- **A token stops working.** Once a token's expiry has passed, the worker marks the account
  `AUTH_REQUIRED` at its next reconciliation (every `SUBSCRIPTION_RECONCILE_INTERVAL_SECONDS`, 30 s).
  A stream the provider refuses for authentication marks it the same way but keeps the token, since
  the refusal may be temporary: if a later connection succeeds, the account returns to
  `AUTHENTICATED`. Otherwise log in or create a token again; the feed resumes on its own.
- **Connection drops.** Streams reconnect on their own and report `RECONNECTING` meanwhile. A quote or
  candle shows the worst of its stored status, its feed's state and its age; see
  [data status](../architecture/data-flow.md#3-data-status).
- **Changing `backend/.env`.** Restart the processes that use the changed setting.

## Shutting down

- **Development:** press Ctrl+C in the worker and API windows opened by `scripts\start-dev.ps1`. On
  Ctrl+C the market-data worker disconnects its feeds and stores the forming candles before it exits.
  Then stop PostgreSQL and Redis with `docker compose -f infra\docker-compose.yml stop`.
- **Containers:** `docker compose -f infra/docker-compose.yml --profile app stop`. The market-data worker
  gets 30 s to store its candles.

To end a Kite session early, run `qt zerodha logout`. `qt groww logout` deletes the stored Groww
token, which stays valid at Groww until it expires.
