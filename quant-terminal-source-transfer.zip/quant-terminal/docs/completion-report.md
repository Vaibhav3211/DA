# Completion report

Phase 1, the first milestone of the build specification (§31), as of **2026-11-02**, followed by
[M8](#m8-strategy-panel-saved-configurations-and-live-monitoring) and
[M9](#m9-historical-data-and-backtests), the first two milestones of the
[specification extension](specification-extension.md). The work was done on a machine with no access
to Zerodha or Groww and no way to install the frontend's npm packages, so every Phase 1 item is
reported at one of these levels:

| Level | Meaning |
| --- | --- |
| Implemented | The code exists. |
| Fixture-tested | Automated tests pass against sample provider payloads and files, with no provider network access. |
| Simulator-tested | Exercised in the [simulator run](#simulator-run): real processes, PostgreSQL, Redis and the built-in simulator. |
| Live-tested | Exercised against a real Zerodha or Groww account. **Nothing is live-tested yet.** |
| Not implemented | Not built in Phase 1. |

## Summary

- Every §31 item is implemented, except that the UI has no separate label for replayed data, because
  historical playback is not built. The backend's unit and integration tests pass. In a four-hour
  simulator run, data labelled `SIMULATED` flowed from the market-data worker to a signed-in WebSocket
  client.
- **Live connectivity to Zerodha and Groww is unverified.** As §31 requires, this milestone is not
  reported as live-tested.
- **The frontend has never been compiled**, and its 14 test files have never run.

## Definition of done (§31)

| # | Item | Status | Evidence |
| --- | --- | --- | --- |
| 1 | The backend starts cleanly using documented commands | Simulator-tested | The API and both workers started with clean logs using the manual commands under [Run](../README.md#run). `scripts\start-dev.ps1` was not used for this run. |
| 2 | PostgreSQL migrations apply | Fixture-tested | `tests/integration/test_migrations.py` checks that a migrated test database matches the models. `alembic check` finds no drift. |
| 3 | Redis is reachable and health checks work | Simulator-tested | `/health/ready` reported PostgreSQL and Redis healthy; both workers published heartbeats. Also `tests/integration/test_redis_bus.py`. |
| 4 | Zerodha authenticates and receives real live events | Fixture-tested; **live unverified** | `tests/unit/providers/test_zerodha_auth.py`, `test_zerodha_client.py`, `test_zerodha_stream.py`, `tests/integration/test_provider_auth.py`. See [verifying live](providers/zerodha.md#verifying-live). |
| 5 | Groww authenticates and receives real live events | Fixture-tested; **live unverified** | `tests/unit/providers/test_groww_auth.py`, `test_groww_client.py`, `test_groww_feed.py`, `test_groww_proto.py`, `test_groww_topics.py`. The NATS transport is known only from the SDK source: see [verifying live](providers/groww.md#verifying-live). |
| 6 | Both adapters publish the same canonical event schema | Fixture-tested | `test_zerodha_mapper.py`, `test_groww_mapper.py`, `test_validation.py`, `tests/unit/market_data/test_pipeline.py`. Simulator events used the same schema. |
| 7 | Provider identity and timestamps remain intact | Fixture-tested; simulator-tested | Every simulator event, quote and candle kept its `provider`, `account_id` and source, receive and processing times. |
| 8 | Instrument mapping works for real provider identifiers | Fixture-tested | `test_zerodha_instruments.py`, `test_groww_instruments.py`, `tests/unit/test_instrument_canonical.py`, `tests/integration/test_instruments.py`, all with sample files. No real instrument dump has been downloaded. |
| 9 | Feed health moves through connect, live, stale, disconnect and reconnect | Fixture-tested; partly simulator-tested | `tests/unit/providers/test_supervisor.py`, `tests/unit/market_data/test_feed.py`. The simulator run showed only `IDLE`, `CONNECTING`, `CONNECTED`. |
| 10 | Live quotes reach an authenticated frontend WebSocket client | Fixture-tested; simulator-tested with a script | `tests/integration/test_ws_api.py`. In the simulator run, a signed-in Python client received quote, candle and feed frames. Not yet tried with live data or the frontend. |
| 11 | The UI distinguishes live, delayed, stale, disconnected, replay and simulated data | Implemented except replay; **never compiled** | `frontend/src/lib/status.ts` labels all seven data statuses, and draws `SIMULATED` hatched and violet. There is no replay label, because historical playback is not implemented. |
| 12 | A sample strategy consumes normalized events and emits an explainable signal | Fixture-tested | `tests/unit/strategies/test_example_strategy.py`, `tests/integration/test_strategy_worker.py`, `tests/integration/test_signal_engine.py`. The simulator run loaded the strategy but created no deployment. |
| 13 | Stale data blocks actionable signals | Fixture-tested | `tests/unit/risk/test_risk_gate.py`: `STALE`, `RECONNECTING`, `DISCONNECTED` and `UNKNOWN` block. `DELAYED` warns unless `block_delayed` is set. |
| 14 | No broker order can be placed | Implemented; fixture-tested | There is no order code, start-up fails with `ORDER_EXECUTION_ENABLED=true`, and `tests/unit/test_architecture.py` fails if application code calls a broker order API ([ADR-011](decisions/011-no-order-execution.md)). |
| 15 | Automated unit and integration tests pass | Backend: yes. Frontend: not run | See [checks](#checks). |
| 16 | Documentation explains setup, credentials, entitlements, limitations and troubleshooting | Done | The [README](../README.md), every document §32 asks for, the [WebSocket protocol](websocket-protocol.md) and 14 [decision records](decisions/README.md). |

## Checks

Run on 2026-11-02 on Windows with Python 3.13.14 and Docker 29.5.3, from `backend`:

| Check | Command | Result |
| --- | --- | --- |
| Lint | `ruff check .` | Passed |
| Format | `ruff format --check .` | 269 files already formatted |
| Types | `mypy app tests` | No issues in 267 source files |
| Unit tests | `pytest` | 1008 passed in 23.6 s |
| Integration tests | `pytest -m integration` | 252 passed in 149 s, against PostgreSQL and Redis in Docker |
| Migrations | `alembic check` | No new upgrade operations detected |
| Live smoke tests | `pytest -m live tests/live` | 10 tests, **not run**: no provider account |
| Dependency audits | `scripts\check.ps1 -Audit` | **Not run** on this machine |
| Frontend | `npm run check`, `npm run build` | **Not run**: packages not installed |

## Simulator run

On 2026-11-02 the API and both workers ran for about four hours with `SIMULATOR_ENABLED=true`, against
PostgreSQL and Redis in Docker. The setup followed
[Try it with the simulator](../README.md#try-it-with-the-simulator): 10 simulator instruments, an
account named `Lab` and the `simulation-lab` workspace with ALPHA and BRAVO in quote mode.

| Area | Result |
| --- | --- |
| Health | `/health/live` alive; `/health/ready` ready, with PostgreSQL and Redis healthy; `qt accounts list` showed `Lab` ready |
| Feed | `IDLE`, `CONNECTING`, `CONNECTED`. After about 100 s: 214 events at 2 per second, none malformed, dropped or duplicated, 4.8 ms processing latency |
| Data | Events, latest quotes, closed 1-minute candles and feed health all carried provider `SIMULATOR` and status `SIMULATED` |
| Sign-in | Wrong password 401; foreign `Origin` 403; no cookie 401. The session cookie is `HttpOnly`, `SameSite=lax`, valid for 12 hours, and not `Secure` in development |
| WebSocket | Foreign `Origin` refused with 403; no session closed with 4401 `unauthenticated`. Signed in: in 10 s, the welcome frame, three acknowledgements, quote and candle snapshots, 15 quote updates, 10 candle updates and 10 feed-status frames, with every `data_status` `SIMULATED`. An unknown channel returned `channel_not_available` |
| Sign-out | The REST API then answered 401, and the open WebSocket closed with 4401 `session_expired` at its next 15-second session check |

Also observed:

- Both workers lost Redis at the same moment (`Timeout reading from localhost:6379`), and both
  recovered on their own within 5 s; the feed did not reconnect.
- The strategy worker logged `strategy_code_changed_without_version_bump` once. The example
  strategy's source had changed since this development database recorded it, so the new fingerprint
  was stored. A new database registers the strategy as new instead.

Not exercised: the stale, disconnect and reconnect states; strategy deployments and signals; the
frontend.

## Known limitations

Not implemented in Phase 1:

- Order placement, by design ([ADR-011](decisions/011-no-order-execution.md)).
- Tick storage. `TICK_PERSISTENCE_ENABLED` exists, but ticks are not stored, and `market_events` and
  `system_metrics_snapshots` stay empty. Candles are stored.
- Historical playback. `APP_ENV=replay` only allows the simulator and forbids
  `MARKET_DATA_ENABLED`, so replayed data cannot be told apart from simulated data.
- Scheduled instrument refresh. `REFRESH_INSTRUMENTS` is defined, but nothing issues it: refresh the
  instrument masters each trading day.
- More than one market-data or strategy worker: there is no leader election.
- A frontend Content-Security-Policy, and a second sign-in factor.

Behaviour to know about:

- A quote that has not changed for 30 seconds reads `STALE`, even for a quiet instrument on a healthy
  feed.
- After a market-data worker restart, quotes are rebuilt from new events only. Fields that a provider
  sends separately can be missing until it sends them again.
- Nothing missed over a WebSocket is replayed: clients resubscribe and reload the REST snapshots.
  Publishing signals to `qt:signals` is best effort; the database is the source of truth.
- Editing a workspace's universe does not change open WebSocket subscriptions: resubscribe.
- The limit of 10 WebSocket connections per user applies per API process.
- Behind the Next.js proxy, the per-address sign-in limits are shared by every browser.
- `/metrics` needs no sign-in, which is why the API binds to `127.0.0.1`. PostgreSQL and Redis are
  reached without TLS by default. See [known gaps](security/secrets-and-auth.md#known-gaps).
- Capability overrides are managed only from the CLI (`qt capabilities`).
- A strategy hook that blocks the event loop stalls the strategy worker; its timeout only detects this
  afterwards.
- Groww candles have no volume until `GROWW_FEED_VOLUME_IS_CUMULATIVE=true` is confirmed and set.

Unverified:

- Live connectivity, streaming, depth and token expiry for both providers, and the open questions in
  each provider's "Verifying live" section.
- The frontend: installing, compiling, testing, building and running it.
- Dependency audits (`pip-audit` and `npm audit`).

## Verify first on the development machine

1. Run `scripts\setup-dev.ps1`, then `scripts\check.ps1 -Integration -Audit`. With the frontend's
   packages installed, the check script also lints, type-checks, tests and builds the frontend.
2. Work through the frontend's [first-run checklist](../frontend/README.md#first-run-checklist) with the
   simulator.
3. Zerodha: register `http://localhost:3000/api/v1/providers/zerodha/callback` as the Kite app's
   redirect URL, then follow [Live data](../README.md#live-data) and
   [verifying live](providers/zerodha.md#verifying-live).
4. Groww: create the day's token and work through [verifying live](providers/groww.md#verifying-live),
   including whether `volume` is cumulative before setting `GROWW_FEED_VOLUME_IS_CUMULATIVE=true`.
5. From `backend`, run the read-only live smoke tests:
   `$env:RUN_LIVE_SMOKE = "1"; pytest -m live tests/live`.
6. Record any value that differs with `qt capabilities set` (see the
   [capability matrix](providers/capability-matrix.md)), then use the
   [live-feed runbook](operations/live-feed-runbook.md) for the first live day.
7. Request a few days of history from each provider with **Get candles…** or `qt datasets request`,
   check the dataset's [coverage](backtesting.md#coverage-how-complete-the-candles-are), and compare a
   few of its candles with the provider's own chart.

## M8: strategy panel, saved configurations and live monitoring

M8 is the first milestone of the [specification extension](specification-extension.md), whose
requirement IDs are used below. It reuses the Phase 1 strategy plugins, registry, deployments, strategy
worker, risk gate, settings forms and chart. A saved configuration is a deployment with a label and an
explicit scope ([ADR-015](decisions/015-saved-strategy-configurations.md)).

Here, verified means automated tests: the backend's against PostgreSQL and Redis in Docker, and the
frontend's helper functions under Node. No part of M8 ran against live data or in a browser, and the
API and workers have not run as processes with the M8 code.

### M8 checks

Run on 2026-11-02 on the same machine as the [Phase 1 checks](#checks):

| Check | Command | Result |
| --- | --- | --- |
| Lint | `ruff check .` | Passed |
| Format | `ruff format --check .` | 281 files already formatted |
| Types | `mypy app tests` | No issues in 278 source files |
| Unit tests | `pytest` | 1087 passed in 27.7 s |
| Integration tests | `pytest -m integration` | 264 passed in 200 s, against PostgreSQL and Redis in Docker |
| Migrations | `tests/integration/test_migrations.py`, in the integration tests | A freshly migrated database matches the models, and `0002` keeps existing deployments. `alembic check` was not run against the development database, which is still at `0001` |
| API contract | `python -m app.api.contract <file>` | Identical to `frontend/src/lib/api/types.gen.ts` |
| Frontend helpers | `src/lib/strategies.test.ts` and `src/lib/chart.test.ts` | 20 passed, under Node with a minimal stand-in for Vitest kept outside the repository |
| Frontend types | The TypeScript compiler, with the npm packages replaced by untyped stubs | 77 files and 2 diagnostics, both caused by the stubs: `process` needs `@types/node`, and the stubbed `zustand` returns `any`. No unescaped quotes in JSX text |
| Frontend | `npm run check`, `npm run build` | **Not run**: packages not installed |
| Links | A link check kept outside the repository | 165 relative links in 31 Markdown files resolve |

### Implemented and verified

- **Your own strategies (EXT-2.1 to 2.3).** A strategy declares its name, description, ID, version,
  markets and instruments, timeframes, indicators, warm-up, settings with defaults and validation, and
  signal conditions with their inputs. The registry rejects strategies that break the contract or
  reuse an ID. `qt strategies check` checks your code without settings or a database, and after a
  catalogue sync the API and CLI list the strategy. The template in the
  [registration guide](strategy-registration.md) was verified by registering it temporarily. Tests:
  `tests/unit/strategies/test_registry.py`, `tests/unit/test_cli.py`,
  `tests/integration/test_cli_strategies.py` and `test_rest_api.py`.
- **Compatibility (EXT-1.3).** Each strategy is checked against an instrument: the market, the
  instrument, the data its feed sends, the timeframe and the stored warm-up candles, with every failure
  and warning explained. Tests: `tests/unit/strategies/test_compatibility.py`,
  `tests/unit/providers/test_delivery.py` and `tests/integration/test_strategy_compatibility.py`.
- **Saved configurations (EXT-1.4 to 1.7, and EXT-3.1 and 3.2 for live signals).** A configuration is
  saved stopped, with a label, its settings and a scope chosen explicitly: some instruments, or the
  whole workspace. An empty scope, a scope over the limit, and instruments that do not suit the
  strategy or are not in the workspace are refused. Several labelled configurations can exist side by
  side. Each run records the configuration it ran and the code fingerprint, and each signal keeps them:
  the label, settings, settings hash, code fingerprint, and whether the configuration still has those
  settings. Migration `0002` keeps existing deployments. Tests:
  `tests/integration/test_strategy_service.py`, `test_strategy_runs.py`, `test_strategy_worker.py`,
  `test_signal_service.py`, `test_migrations.py` and `test_rest_api.py`.
- **Live monitoring (EXT-5.1 to 5.3, 5.6 and 5.7).** Only Enable starts monitoring, and Stop ends it.
  Monitoring reads Stopped, Starting, Warming up, Running, Blocked or Failed, with reasons and
  warnings: no strategy-worker heartbeat, a failed run, the kill switch, a paused workspace,
  `LIVE_SIGNALS_ENABLED=false`, risk rules that block every signal, or a configuration that cannot run
  as saved. Enabling an enabled configuration changes nothing. Another configuration with the same
  strategy version and settings on an overlapping scope is refused, naming the instruments both would
  watch. The risk gate and freshness checks still decide every signal. Tests:
  `tests/unit/strategies/test_monitoring.py`, `tests/integration/test_strategy_service.py`,
  `test_strategy_worker.py`, `test_cli_strategies.py` and `test_rest_api.py`.
- **Signal explanations (EXT-5.9, server side).** The signal detail adds the configuration above to the
  Phase 1 explanation: conditions, indicator values, instrument, provider, timestamps, entry, stop and
  targets, and the risk decision with its reasons. Tests: `tests/integration/test_signal_service.py`.
- **Market availability (EXT-6.1, 6.3 and 6.4, server side).** It comes from the effective provider
  capabilities. NSE and BSE markets are available through Zerodha and Groww, and MCX commodities and
  NSE currency derivatives through Zerodha. Crypto, spot Forex and spot metals such as XAUUSD are
  unavailable, each with its reason and planned milestone. Tests:
  `tests/unit/providers/test_market_availability.py` and `test_rest_api.py`.
- **Frontend helpers.** Scope summaries, compatibility verdicts, the numbering of configurations
  applied to the chart, catalogue-sync summaries and the placement of signal markers on candles.
- **Documentation (EXT-7.3, except interpreting results).**
  [Registering a strategy](strategy-registration.md), [live monitoring](operations/live-monitoring.md),
  [ADR-015](decisions/015-saved-strategy-configurations.md) and the
  [ADR-008](decisions/008-trusted-strategy-plugins.md) amendment.
- **Validation (EXT-7.2, in part).** The tests above cover a wrong instrument scope, pressing Enable
  twice and blocked live signals.

### Implemented but unverified

The frontend has not been compiled, rendered or run; it was only type-checked with stubs.

- The Strategy panel beside each chart (EXT-1.1, 1.2, 1.6 and 1.8): the strategies with their
  descriptions, versions and compatibility, the configurations covering the instrument, and separate
  **Apply to chart**, **Run backtest** (disabled until [M9](#m9-historical-data-and-backtests)),
  **Enable live signals** and **Stop live signals** buttons.
- The configuration dialog (EXT-1.4, 1.5 and 2.4): settings forms generated from the strategy's
  schema, a scope that starts with the instrument in view, and a confirmation before the whole
  workspace is chosen.
- Monitoring in the browser (EXT-5.2, 5.4 and 5.5): the state badges, reasons and warnings; the Enable
  confirmation, which explains that monitoring runs on the server and carries on after the chart or
  browser is closed; and Stop.
- Signals on the chart (EXT-5.8 and 5.9): BUY, SELL and EXIT markers drawn with lightweight-charts, and
  the signal detail, with its new Configuration section, opened by clicking a marker or from the list
  of marked signals. Only the marker placement is tested.
- The Market availability card on the overview page (EXT-6.1 and 6.4).
- The API and strategy worker running the M8 code as processes, with the simulator or live data.

### Remaining work

- **M9, historical data and backtests:** implemented; see [M9](#m9-historical-data-and-backtests), whose
  remaining work lists M10 to M13.
- **On the development machine:** install the frontend's packages, run `npm run check` and
  `npm run build`, and work through item 9 of the
  [first-run checklist](../frontend/README.md#first-run-checklist).
- The configurations applied to a chart are forgotten when the page reloads.

## M9: historical data and backtests

M9 is the second milestone of the [specification extension](specification-extension.md). It reuses the
strategy plugins and registry, saved configurations, risk rules, exchange calendars, provider clients,
chart and Strategy panel. A backtest replays a saved configuration's strategy over a frozen dataset of
candles, as a job run by a backtest worker
([ADR-016](decisions/016-frozen-datasets-and-queued-backtests.md)). The
[backtesting guide](backtesting.md) explains how to use it.

As for M8, verified means automated tests. The Zerodha and Groww history downloads were tested against
fixtures shaped like their documentation, not a real account. No part of M9 ran in a browser, the API
and backtest worker have not run as processes with the M9 code, and no result in this report comes from
real market data.

### M9 checks

Run on 2026-11-02 on the same machine as the [Phase 1 checks](#checks):

| Check | Command | Result |
| --- | --- | --- |
| Lint | `ruff check .` | Passed |
| Format | `ruff format --check .` | 309 files already formatted |
| Types | `mypy app tests` | No issues in 305 source files |
| Unit tests | `pytest` | 1207 passed in 34.5 s |
| Integration tests | `pytest -m integration` | 275 passed in 209 s, against PostgreSQL and Redis in Docker |
| Migrations | `tests/integration/test_migrations.py`, in the integration tests | A freshly migrated database, `0003` included, matches the models. The development database is still at `0001` |
| API contract | `python -m app.api.contract <file>` | Identical to `frontend/src/lib/api/types.gen.ts` |
| Frontend helpers | `src/lib/backtests.test.ts`, `strategies.test.ts` and `chart.test.ts` | 37 passed, under Node with the same stand-in for Vitest |
| Frontend types | The TypeScript compiler, with the npm packages replaced by untyped stubs | 87 files and the same 2 diagnostics caused by the stubs |
| Frontend | `npm run check`, `npm run build` | **Not run**: packages not installed |
| Links | A link check kept outside the repository | 244 relative links in 33 Markdown files resolve, anchors included |

### Implemented and verified

- **Datasets (EXT-4.2, and EXT-3.2 for the data).** A dataset freezes the candles of one instrument at
  one interval over a range of dates, from one source: provider history from Zerodha or Groww, candles
  recorded from the live feed, or simulated candles. Its coverage counts the candles the exchange
  calendar expects, lists the gaps, and flags inconsistent candles, candles off the calendar and
  recorded candles after a feed gap. A hash of its candle values identifies it. Downloads are split into
  windows the provider accepts, and a source that cannot supply the candles says why. Tests:
  `tests/unit/backtest/test_dataset.py`, `tests/unit/providers/test_history.py`,
  `test_zerodha_client.py`, `test_groww_client.py` and `tests/integration/test_backtests.py`.
- **Trade rules (EXT-4.3).** Nothing is calculated until the rules are set: the sides traded, what an
  opposite signal does, when fills happen, where the stop-loss and target come from and how they are
  checked, an optional holding limit, sizing, starting capital, fees and slippage. They are saved with
  the configuration or declared by the strategy, and the configuration's own rules win. Rules that
  contradict each other are refused. Tests: `tests/unit/backtest/test_engine.py`,
  `tests/unit/strategies/test_registry.py` and `tests/integration/test_backtests.py`.
- **The engine (EXT-4.1 and 4.4).** One saved configuration, one instrument and one interval; the
  dataset must cover the strategy's warm-up and more. The strategy sees each candle only after it
  closes, and a decision fills at the next candle's open, or at the deciding close if chosen, which the
  results note as optimistic. A candle that reaches both the stop-loss and the target is assumed to hit
  the stop-loss, and one that opens beyond the stop-loss exits at its open. Fills pay fees and slippage,
  sizing rounds down to the lot, and the risk rules that apply to history decide each signal. A position
  still open at the end, and an entry decided on the last candle, are reported apart from the closed
  trades. A strategy failure or the time limit stops the replay and names the candle. Tests:
  `tests/unit/backtest/test_engine.py`.
- **Results (EXT-4.5 and 4.6).** The testing period, source and coverage; closed trades with wins,
  losses and breakevens; the win rate, defined as wins ÷ closed trades × 100, with breakevens counted as
  closed trades; average win and loss; gross and net return; profit factor; maximum drawdown; the equity
  curve; and each closed trade. A metric that cannot be calculated, such as any ratio without closed
  trades or the profit factor without a loss, is reported as undefined with the reason. The win rate
  comes only from closed trades, never from signal counts or a strategy's confidence, and results on
  simulated candles say so. Tests: `tests/unit/backtest/test_metrics.py`, `test_engine.py`,
  `tests/integration/test_backtests.py` and `test_cli_backtests.py`.
- **Reproducible and outdated results (EXT-3.1 to 3.4).** One saved configuration serves the chart,
  backtests and live signals. A backtest records a settings hash of the strategy's ID, version and code
  fingerprint, the settings, the instrument and interval, the trade rules (sizing, fees, slippage and
  fills) and the risk rules that apply to history. It also points to its dataset, which records the
  source, provider, dates and a hash of the candles. A change that can alter results marks older
  backtests outdated and names what changed; they stay for comparison, and repeating the same backtest
  returns the existing one. `GET /backtests/latest` returns, for a configuration and an instrument, the
  latest successful backtest with the current settings (`CURRENT`), else the latest successful one
  (`OUTDATED`), else `NOT_BACKTESTED`. It never queues a backtest, so nothing reruns on price updates.
  Tests: `tests/unit/backtest/test_identity.py`, `tests/integration/test_backtests.py` and
  `test_rest_api.py`.
- **Queued jobs.** One backtest worker builds requested datasets before running queued backtests. A job
  left by a stopped worker is failed and can be queued again. Tests: `tests/unit/test_backtest_worker.py`
  and `tests/integration/test_backtests.py`.
- **Command line and API.** `qt datasets` and `qt backtests`, and the REST calls in the
  [reference](backtesting.md#command-and-api-reference). Migration `0003` adds the tables. Tests:
  `tests/integration/test_cli_backtests.py`, `test_rest_api.py` and `test_migrations.py`.
- **Frontend helpers.** Trade-rule checks, decimal comparisons, the rules shown, results formatting, the
  equity curve and the backtest trades drawn on the chart: `src/lib/backtests.test.ts`.
- **Documentation (EXT-7.3).** The [backtesting guide](backtesting.md), including
  [reading the results](backtesting.md#reading-the-results);
  [ADR-016](decisions/016-frozen-datasets-and-queued-backtests.md); and amendments to ADR-001, 002 and
  015. With M8's documents, EXT-7.3 is complete.
- **The journey, automated (EXT-7.1).** One test runs the whole journey over the REST API, against
  PostgreSQL and Redis, with fixture candles and a fixture strategy that buys at 09:18 each session. It
  opens BTONE's chart and finds the strategy suits it, saves a configuration for BTONE alone with trade
  rules, builds a dataset of the recorded session (two candles missing) and backtests it, and reads the
  result and its one trade. The next morning it turns live signals on twice, which starts one run warmed
  up from the stored candles, and the 09:18 candle becomes an actionable BUY. It then inspects the
  signal's configuration, levels, indicator values and risk decision, and turns live signals off: the run
  stops, the backtest stays current and the signal stays in the history. Test:
  `test_a_strategy_goes_from_the_chart_through_a_backtest_to_live_signals_and_back_over_the_api` in
  `tests/integration/test_rest_api.py`.
- **Validation (EXT-7.2).** With M8's tests, all six checks are automated: a wrong instrument scope,
  outdated results, missing history, zero trades, pressing Enable twice and blocked live signals.

### Implemented but unverified

The frontend has not been compiled, rendered or run; it was only type-checked with stubs.

- The **Backtest** summary in the Strategy panel (EXT-3.4): Current, Outdated or Not backtested, with
  **Results…**, **All runs…** and **Trade rules…**.
- **Run backtest…** (EXT-1.8) and **Get candles…**: choosing or requesting a dataset, its coverage, and
  following the job.
- The trade-rules dialog, the results view with its equity curve and trade list, and the run history.
- Backtest trades on the chart (EXT-5.10): muted markers, unlike live signals, drawn only while
  **Backtest trades** is on.
- Real history downloads from Zerodha and Groww.
- The API and backtest worker running the M9 code as processes, whether started by
  `scripts\start-dev.ps1` or as the Compose `backtest-worker` service.
- Any backtest on real market data.

### Remaining work

- **M10:** the whole journey of EXT-7.1, as the automated test above runs it, but in the browser on one
  Indian instrument with real data and one of your strategies, on the development machine: download
  history and check its coverage, run a backtest, read its results, enable live signals, inspect a
  signal and stop monitoring.
- **M11 to M13:** crypto, Forex and metals providers, keeping spot metals such as XAUUSD apart from MCX
  contracts. Until then these markets show as unavailable.
- **On the development machine:** install the frontend's packages, run `npm run check` and
  `npm run build`, and work through items 9 and 10 of the
  [first-run checklist](../frontend/README.md#first-run-checklist).
- The first version's [known limitations](backtesting.md#known-limitations), among them one instrument
  and interval per backtest, no margin, leverage or contract-expiry model, no MCX calendar for coverage,
  and no way to delete datasets or backtests.

Update this report as each item is verified.
