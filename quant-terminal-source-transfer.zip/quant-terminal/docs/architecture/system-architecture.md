# System architecture

Quant Terminal is a modular monolith. One Python package (`backend/app`) runs as four separate
processes, which share PostgreSQL and Redis. A Next.js terminal (`frontend/`) talks to the API.
Phase 1 covers market data, candles, indicators and risk-gated signals, and M9 adds backtests on stored
candles; there is no order placement (see [ADR-011](../decisions/011-no-order-execution.md)).

```text
 Zerodha Kite WebSocket ─┐
 Groww feed (NATS/WS) ───┼──> qt-market-data-worker ───────────── upsert candles ──┐
 Simulator (synthetic) ──┘    adapters → pipeline → candle builder                  │
                                   │ XADD streams, SET latest values                 v
                                   v                                            PostgreSQL
                    Redis: qt:md:events:<provider> · qt:md:candles · qt:md:feed   (system of record)
                           qt:quote:* · qt:candle:partial:* · qt:feed:*               ^   ^
                                   │ XREAD from the tail                             │   │
                 ┌─────────────────┴──────────────────┐                              │   │
                 v                                    v                              │   │
        qt-strategy-worker                     qt-api (FastAPI) ─────────────────────┘   │
        indicators → strategies → risk →       REST /api/v1 · WS /ws/v1/*                │
        signals ── XADD qt:signals ──> Redis   per-client filtered, conflated queues     │
           └──────────────────────────────────────── signals, risk decisions, runs ──────┘
                                                      │
                                                      v
                                  Next.js terminal (REST through its proxy, WebSockets direct)
```

Backtests stay off this live path. The API and the CLI queue a dataset or a backtest as a row in
PostgreSQL, and `qt-backtest-worker` claims the oldest, builds the dataset or replays the backtest, and
stores the result. It uses Redis only for its heartbeat. See [data flow](data-flow.md#backtests) and
[ADR-016](../decisions/016-frozen-datasets-and-queued-backtests.md).

## Processes

| Process | Entry point | Role |
| --- | --- | --- |
| API | `qt-api` (`app.main:run`) | REST under `/api/v1`, WebSockets under `/ws/v1`, `/health/live`, `/health/ready` and Prometheus `/metrics`. Handles the Kite login callback. Calls provider REST APIs only on request (logins, token checks, instrument refreshes); it never runs a feed. |
| Market-data worker | `qt-market-data-worker` | Streams every enabled provider account, normalizes and validates events, builds candles, publishes to Redis and stores candles in PostgreSQL. |
| Strategy worker | `qt-strategy-worker` | Runs deployed strategies on closed candles (and on market events, for strategies that ask for them), passes their proposals through the risk gate and records signals. |
| Backtest worker | `qt-backtest-worker` | Builds requested datasets (downloading provider historical candles, or copying candles already stored) and runs queued backtests, one job at a time, oldest first. It needs no live feed. |
| CLI | `qt` (`app.cli:main`) | Administration: keys, the admin user, provider accounts and logins, instruments, capabilities, workspaces, strategies, datasets and backtests, risk and the kill switch. |
| Frontend | `npm run dev` / `npm start` in `frontend/` | The terminal UI; see [frontend/README.md](../../frontend/README.md). |

Run exactly one market-data worker, one strategy worker and one backtest worker per platform. There is
no leader election: two market-data workers would open duplicate provider connections, and two strategy
workers would evaluate every deployment twice. Two backtest workers would not take the same job, but
each would keep to the providers' rate limits on its own, so together they could exceed them. If you
run several API processes, the WebSocket connection limit (10 per user) applies to each process
separately.

The market-data and strategy workers follow the database. They reconcile with it periodically
(`SUBSCRIPTION_RECONCILE_INTERVAL_SECONDS`, default 30; `DEPLOYMENT_REFRESH_SECONDS`, default 10) and
at once when a command arrives on `qt:commands`. A lost command only delays a change. See
[data-flow.md](data-flow.md#commands). The backtest worker reads no commands: when idle, it looks for
queued jobs every `BACKTEST_POLL_SECONDS` (default 2).

## Backend packages

| Package | Contents |
| --- | --- |
| `api` | FastAPI routers (`v1/endpoints`), request and response schemas, dependencies (session, origin), middleware (security headers, request logging), the WebSocket gateway (`ws/`), and the generator of the frontend's API types (`contract.py`). |
| `cli` | The `qt` command. |
| `core` | Settings (`config.py`), errors, logging and redaction, encryption and passwords (`security.py`), backoff, rate limiting, clock. |
| `domain` | Enums, events and pydantic models shared by every layer. |
| `providers` | The adapter contract (`base.py`), capabilities, the registry, the Zerodha, Groww and simulator adapters, and historical-candle downloads (`history.py`). |
| `market_data` | Subscription planning, the connection manager, the pipeline, feed coverage, market calendars, instruments (sync, cache, canonical identity) and candles (builder, store, writer). |
| `strategies` | The plugin contract, registry, runtime (timeouts, circuit breaker), indicators and the example strategy. |
| `signals`, `risk` | The signal engine and lifecycle; the risk rules and engine. |
| `backtest` | Datasets on the exchange calendar (coverage, gaps, content hash), the replay engine, its metrics, and the settings identity that marks results outdated. It does no I/O. |
| `services` | Use cases shared by the API and the CLI: accounts, provider logins, instruments, workspaces, watchlists, quotes, candles, strategies, signals, datasets, backtests, risk, kill switch, audit. |
| `persistence` | SQLAlchemy models, the database session, repositories. Migrations are in `backend/alembic/`. |
| `streaming` | `redis_bus.py`: stream and key names, JSON encoding, batched writes. |
| `observability` | Health endpoints, worker heartbeats, Prometheus metrics. |
| `workers` | The three worker entry points and shutdown handling. |

## Storage

**PostgreSQL** is the system of record:

| Area | Tables |
| --- | --- |
| Users | `users` |
| Reference data | `exchanges`, `market_segments`, `instruments`, `instrument_provider_mappings`, `market_calendar_overrides` |
| Providers | `provider_accounts`, `provider_credentials` (encrypted), `provider_tokens_metadata`, `provider_capabilities` (overrides), `provider_connection_events` |
| Market data | `candles` (closed and forming candles) |
| Workspaces | `workspaces`, `workspace_instruments`, `watchlists`, `watchlist_items` |
| Strategies | `strategies`, `strategy_versions`, `strategy_configurations`, `strategy_deployments`, `strategy_runs` |
| Signals and risk | `signals`, `signal_events`, `risk_decisions`, `risk_rules` |
| Backtests | `backtest_datasets`, `backtest_dataset_candles`, `backtest_runs` (each run's summary, equity curve and trades are stored on its row). A configuration's own trade rules are in `strategy_deployments.backtest_rules`. |
| System | `audit_logs`, `system_flags` (kill switch) |

`market_events` and `system_metrics_snapshots` exist in the schema, but nothing writes them in
Phase 1: tick persistence (`TICK_PERSISTENCE_ENABLED`) is not implemented.

**Redis** carries live data between processes. Streams are trimmed with `MAXLEN ~`
(`REDIS_STREAM_MAXLEN`, default 200,000); every entry has one field, `d`, holding JSON in which prices
are strings, so they never pass through binary floating point.

| Name | Kind | Written by | Read by |
| --- | --- | --- | --- |
| `qt:md:events:<provider>` | stream | market-data worker | strategy worker (runs that ask for events) |
| `qt:md:candles` | stream | market-data worker (closed candles) | strategy worker, API |
| `qt:md:feed` | stream | market-data worker (connection state changes) | API |
| `qt:signals` | stream | signal engine (after commit) | API |
| `qt:commands` | stream | API and CLI | market-data and strategy workers |
| `qt:quote:<provider>:<instrument>` | key | market-data worker | API (expires after `QUOTE_CACHE_TTL_SECONDS`, default 7 days) |
| `qt:candle:partial:<provider>:<instrument>:<interval>` | key | market-data worker (forming candles) | API |
| `qt:feed:<provider>:<account>:<shard>` | key | market-data worker (connection health, every second) | API |
| `qt:worker:<name>` | key | each worker's heartbeat | API health |
| `qt:flags:kill_switch` | key | kill-switch service (a cached mirror of `system_flags`) | API and CLI; the signal engine reads `system_flags` inside its transaction |
| `qt:session:*`, `qt:user_sessions:*`, `qt:login:attempts:*`, `qt:zerodha:pending:*` | keys | API | API |

The Docker Redis runs with `--appendonly yes` and `--maxmemory-policy noeviction`, so session keys are
never evicted silently.

## Run modes

`APP_ENV` is `development` (the default), `live_data`, `replay` or `production`. Real providers stream
only with `MARKET_DATA_ENABLED=true`. The simulator streams only with `SIMULATOR_ENABLED=true`, only in
`development` or `replay`, and its data is always labelled `SIMULATED`. `ORDER_EXECUTION_ENABLED` must
stay `false`: there is no order code.

`MARKET_DATA_ENABLED`, `SIMULATOR_ENABLED` and `LIVE_SIGNALS_ENABLED` do not affect the backtest worker.
It downloads history only for a dataset you request, and the signals it replays are kept with their
backtest: they never become live signals.

## Deployment

- **Local development** (Windows): `scripts\setup-dev.ps1`, then `scripts\start-dev.ps1`. PostgreSQL and
  Redis run in Docker, and the API, the workers and the frontend run from the local environments, each
  in its own window. See the [README](../../README.md).
- **Containers:** `docker compose -f infra/docker-compose.yml --profile app up -d --build` adds a
  one-shot `migrate` service and the `api`, `market-data-worker`, `strategy-worker` and
  `backtest-worker` services, built from `backend/Dockerfile`. Every port binds to `127.0.0.1`.

## Related documents

- [Data flow](data-flow.md)
- [WebSocket protocol](../websocket-protocol.md)
- [Providers](../providers/capability-matrix.md)
- [Secrets and authentication](../security/secrets-and-auth.md)
- [Live-feed runbook](../operations/live-feed-runbook.md)
- [Architecture decisions](../decisions/README.md)
