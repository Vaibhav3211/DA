# Data flow

How a provider tick becomes a quote, a candle, a signal and a browser update, and how stored candles
become a [backtest](#backtests). Stream and key names are listed in
[system-architecture.md](system-architecture.md#storage).

## 1. What gets streamed

The market-data worker plans its subscriptions from the database (`market_data/subscriptions.py`):

1. It takes the instruments of every **enabled workspace** and the **enabled provider accounts**. Only
   one account per provider can be enabled at a time.
2. Each workspace row is served by its provider's enabled account. When several workspaces want the same
   instrument, the highest subscription mode wins (FULL over QUOTE over LTP).
3. Rows that cannot be served are skipped with a reason that the workspace's universe shows:
   `no_enabled_account`, `account_not_enabled` (the workspace pins a different account),
   `streaming_disabled` (by the settings or the capabilities), `not_listed` (inactive, or not listed by
   that provider) or `unsupported` (outside the account's exchanges, segments or modes).

The worker re-plans every `SUBSCRIPTION_RECONCILE_INTERVAL_SECONDS` (30) and at once after a command.
Feeds of accounts that are no longer planned stop, new ones start, and running feeds take their new
instrument set. If an account's credentials change, its feed reconnects. An instrument set larger than
the account's connections can hold is refused; the previous set keeps streaming.

## 2. From tick to quote and candle

```text
provider frame ─> parser ─> mapper ─> validation ─> pipeline batch ─┬─> XADD qt:md:events:<provider>
 (binary / protobuf)   (Decimal, UTC, None for missing)             ├─> merge into qt:quote:<provider>:<id>
                                                                    └─> candle builder ─┬─> closed: CandleWriter → candles table
                                                                                        │           XADD qt:md:candles
                                                                                        └─> forming: SET qt:candle:partial:*
```

- **Parsing and mapping** happen only in each provider's adapter. Prices become `Decimal`, timestamps
  become UTC, and missing values stay `None`; a missing value is never turned into 0.
- **Validation** (`providers/validation.py`) drops what no market produces: non-finite or non-positive
  prices, negative sizes, a high below the low, or a source timestamp more than
  `EVENT_MAX_FUTURE_SECONDS` (30) ahead of the local clock. Persistent rejections usually mean the
  machine's clock is wrong.
- **The pipeline** (one per account) takes events in batches. Each batch goes to the provider's event
  stream, is merged into the latest-quote keys (kept for `QUOTE_CACHE_TTL_SECONDS`, 7 days) and is fed to
  the candle builder.
- **Candles** are built for `CANDLE_INTERVALS` (default 1m, 3m, 5m, 15m, 30m, 1h, 1d; 1s is opt-in).
  Buckets follow the exchange calendar: intraday buckets start at the session open and the daily
  bucket is the session itself. Events are bucketed by source time (receive time when there is none). A
  bucket closes when the clock passes its end plus `CANDLE_LATENESS_SECONDS` (2). A later event for a
  closed bucket is rejected, and the last closed candle is revised once with `LATE_EVENTS_IGNORED`.
- **Candle flags** record what the data cannot show: `PARTIAL_START`, `GAP_BEFORE`,
  `DISCONNECTED_DURING`, `LATE_EVENTS_IGNORED`, `VOLUME_INCOMPLETE`, `VOLUME_RESET`,
  `VOLUME_UNAVAILABLE`, `RECEIVE_TIME_BASIS` and `OUTSIDE_SESSION`. Gaps are flagged, never filled in.
- **Volume**: providers report cumulative day volume, so an intraday candle's volume is the increase
  across its bucket. When that cannot be derived reliably, the volume is `None` with
  `VOLUME_INCOMPLETE`.
- **Closed candles** go to the shared `CandleWriter`, which upserts them into PostgreSQL every
  `CANDLE_FLUSH_INTERVAL_SECONDS` (2), and to `qt:md:candles`. **Forming candles** are published to their
  `qt:candle:partial:*` key when they change, at most every `CANDLE_PARTIAL_PUBLISH_INTERVAL_SECONDS`
  (1). They are also checkpointed to PostgreSQL every `CANDLE_CHECKPOINT_INTERVAL_SECONDS` (60) and on
  shutdown, so the next run resumes them.
- **Feed health**: every `FEED_STATUS_PUBLISH_INTERVAL_SECONDS` (1), each connection's health is written
  to `qt:feed:<provider>:<account>:<shard>` (it expires if the worker stops). Every connection state
  change is published to `qt:md:feed`.

Redis trouble never stops a feed. Writes are retried briefly, then dropped and counted
(`qt_redis_errors_total`). A retried write may repeat entries, so readers tolerate duplicates: events
carry an `event_id`, and candles are keyed by series, bucket and revision.

Raw ticks are not stored in PostgreSQL. `TICK_PERSISTENCE_ENABLED` exists, but tick persistence is not
implemented in Phase 1.

## 3. Data status

Every quote and candle carries a status: `LIVE`, `DELAYED`, `STALE`, `DISCONNECTED`, `RECONNECTING`,
`SIMULATED` or `UNKNOWN`. A stored quote keeps the status it was written with. When it is read, the API
shows the worst of three things:

- the stored status;
- the current state of the account's feed (a quote is never `LIVE` after its feed has stopped);
- the quote's age (`STALE` after `DATA_STALE_AFTER_SECONDS`, 30).

An instrument that has not traded for 30 seconds therefore shows `STALE`; a quiet instrument cannot be
told apart from a feed that went silent for it.

## 4. From candle to signal

The strategy worker reads `qt:commands`, `qt:md:candles` and, for runs whose strategy asks for them, the
providers' event streams. It reads them from the tail with plain `XREAD`.

1. **Warm-up.** A run feeds its indicators the stored candles that closed up to five minutes earlier,
   then the last ten minutes of the candle stream. The strategy itself is only called with candles that
   close while it runs, so candles published while the worker was down never reach it as live data.
2. **Evaluation.** All candles closing at the same time are folded into every run before any strategy
   is called. Each plugin hook runs under a timeout, and a per-strategy circuit breaker stops calling a
   plugin that keeps failing. A strategy only sees its context (configuration, indicators, recent
   candles, instrument data) and can only *propose* signals.
3. **Risk gate.** The signal engine handles each run's batch of proposals in one transaction. The kill
   switch, the risk policy and the deployment's state are read inside that transaction, so a pause or a
   disable applies to the very next candidate. The rules:

   | Rule | Mandatory | Checks |
   | --- | --- | --- |
   | `kill_switch` | yes | the global kill switch is released |
   | `workspace_pause` | yes | the workspace is not paused |
   | `live_signals` | yes | live-data signals need `LIVE_SIGNALS_ENABLED=true` |
   | `strategy_enabled` | yes | the deployment is enabled and runnable |
   | `data_quality` | yes | feed status (STALE, RECONNECTING, DISCONNECTED and UNKNOWN block), candle flags (`DISCONNECTED_DURING` blocks by default), data age (120 s) |
   | `instrument_status` | yes | the instrument is active and not expired |
   | `eligibility` | yes | the market, segment and instrument type are allowed by the strategy and the workspace |
   | `session_status` | no | the exchange session is OPEN (by default) |
   | `frequency` | no | at most 3 BUY/SELL signals per deployment and instrument per 60 minutes (by default) |
   | `price_sanity` | no | levels on the correct side, entry within 2 % of the last price |
   | `volatility_limit` | no | source candle range ≤ 5 %, stop distance ≤ 10 % |
   | `stop_loss_required` | no | directional signals carry a stop-loss |

   Settings resolve as code default, then the global row, then the workspace's row (`qt risk`, or
   `PUT /api/v1/risk/rules/...`). Mandatory rules cannot be disabled, but their parameters can be tuned.
   The gate fails closed: a rule that raises, or stored parameters that no longer validate, BLOCK.
4. **Lifecycle.** At most one signal per deployment and instrument is open. A duplicate candidate is
   dropped before the gate; changed levels UPDATE the open signal; a new signal SUPERSEDES it (or CLOSES
   it, for an EXIT); an INVALIDATED candidate closes it. Blocked candidates are kept as `BLOCKED`
   signals with their risk decisions, for audit. Open signals EXPIRE at `valid_until`.
5. **Publishing.** Lifecycle changes go to `qt:signals` after the commit. That is best effort: the
   database is the source of truth.

No signal places an order. There is no order code in Phase 1.

## 5. To the browser

- **REST snapshots:** latest quotes with recomputed status (`GET /api/v1/quotes/latest`), candle series
  (`GET /api/v1/candles`: closed candles from PostgreSQL plus the forming one from Redis), signals,
  providers and system health.
- **WebSockets:** each API process's hub tails `qt:md:candles`, `qt:md:feed` and `qt:signals`, and
  polls the quote, forming-candle and feed keys at most `WS_MAX_UPDATES_PER_SECOND` (4) times a second.
  Each client receives only what it subscribed to. Latest values are conflated per client; events are
  queued in order. Nothing missed is replayed: after a reconnect the client resubscribes and reloads its
  REST snapshots. See [websocket-protocol.md](../websocket-protocol.md).

## Commands

The API and the CLI tell the workers about changes through `qt:commands`. The workers also re-read
the database periodically, so a lost command only delays a change.

| Command | Issued when | Handled by |
| --- | --- | --- |
| `CONNECT_ACCOUNT` | an account is enabled or receives a new token (Kite login, Groww token) | market-data worker: re-plan, reconnect that account's feed |
| `DISCONNECT_ACCOUNT` | an account is disabled or removed, logs out, or its stored credentials are changed or cleared | market-data worker: re-plan, reconnect or stop that account's feed |
| `REFRESH_SUBSCRIPTIONS` | a workspace's instruments change, a workspace is enabled or disabled, instruments are refreshed | market-data worker: re-plan; strategy worker: refresh its runs |
| `RELOAD_DEPLOYMENTS` | a strategy deployment is created, changed, enabled or disabled | strategy worker: refresh its runs |

`REFRESH_INSTRUMENTS` is defined, and the strategy worker reacts to it, but nothing issues it in
Phase 1.

## Instruments

`qt instruments refresh PROVIDER` (or `POST /api/v1/instruments/refresh`) downloads the provider's
instrument dump and applies it to the canonical instrument master, then issues
`REFRESH_SUBSCRIPTIONS`:

- Every instrument has a provider-independent key: `NSE:CASH:EQUITY:INFY`, futures
  `EXCHANGE:SEGMENT:FUTURE:UNDERLYING:YYYY-MM-DD`, options `...:OPTION:UNDERLYING:YYYY-MM-DD:STRIKE:CE|PE`.
  Providers are linked to the same instrument only when their keys match exactly; Kite's "NIFTY 50"
  index and Groww's "NIFTY" stay separate rather than being merged by guesswork.
- A provider token whose key changed (Kite reuses tokens of expired contracts) gets a new mapping
  version.
- Mappings missing from the dump are closed, but only within the exchanges and segments the dump
  covers. A dump that would close more than half of a sizeable scope is refused unless `--force` is
  given, because a truncated download is likelier than a mass delisting.
- Zerodha owns lot sizes, tick sizes and ISINs; other providers only fill them in when they are missing.

## Backtests

Backtests take no part in the live flow above. The backtest worker replays frozen candles
([ADR-016](../decisions/016-frozen-datasets-and-queued-backtests.md)); the user guide is
[backtesting.md](../backtesting.md).

```text
qt / API ── request a dataset ──> backtest_datasets (PENDING) ──┐
qt / API ── run a backtest ─────> backtest_runs (QUEUED) ───────┤ the oldest job, datasets first
                                                                 v
                                                       qt-backtest-worker
           dataset:  provider history (REST) or stored candles ─> calendar, coverage, SHA-256 ─> READY
           backtest: READY dataset ─> strategy, lifecycle, history risk rules, trade rules ─> SUCCEEDED
```

1. **Requests.** `qt datasets request` or `POST /api/v1/datasets` stores a PENDING dataset. A matching
   request that is still PENDING or BUILDING gets that dataset back instead. `qt backtests run` or
   `POST /api/v1/backtests` checks the configuration, its scope, its trade rules and the READY dataset,
   then stores a QUEUED backtest. A backtest of the same configuration, instrument, dataset and settings
   that is queued, running or succeeded is returned instead, with `created` false. Nothing is published:
   the rows are the queue.
2. **Claiming.** Each cycle, the worker first fails jobs whose claim has not been refreshed for 5
   minutes, then claims the oldest PENDING dataset, or else the oldest QUEUED backtest
   (`SELECT … FOR UPDATE SKIP LOCKED`). While a job runs, it refreshes the claim every 15 seconds. After
   a job it looks again at once; when nothing waits, it sleeps for `BACKTEST_POLL_SECONDS` (2).
3. **Building a dataset.** Provider history is downloaded with the account's access token, in date
   windows the provider accepts and within its rate limits (`providers/history.py`). Recorded and
   simulated candles are copied from the `candles` table. The candles are placed on the exchange
   calendar; coverage, gaps and doubtful candles are recorded, and a SHA-256 of the candles becomes the
   dataset's identity. The dataset ends READY, or FAILED with the reason, and never changes afterwards.
4. **Running a backtest.** The engine (`backtest/engine.py`) gives the strategy each candle after it
   closes, through the live runtime, the signal lifecycle and the history risk rules, then applies the
   trade rules. The summary, equity curve and trades are stored on the `backtest_runs` row with the
   settings and settings hash they were produced with. Replayed signals are kept with the backtest:
   they are never stored as live signals or published.
5. **Reading.** `GET /api/v1/backtests/latest` compares the settings hash of the configuration's
   succeeded backtests on the instrument with its current settings, and answers CURRENT, OUTDATED (with
   what changed) or NOT_BACKTESTED. Outdated is worked out when read, never stored. No WebSocket channel
   carries backtests: the panel re-reads every 60 seconds, and every 3 seconds while a backtest is
   queued or running.
