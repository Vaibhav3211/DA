# Registering your own strategy

Your strategies are Python classes in `backend/app/strategies/custom`. They are trusted code
([ADR-008](decisions/008-trusted-strategy-plugins.md)): the strategy worker runs them with its own
permissions, so review them like the rest of the code. They must follow the [plugin rules](#plugin-rules).
A strategy only *proposes* signals. The risk rules decide what may be presented as actionable, and nothing
places orders ([ADR-011](decisions/011-no-order-execution.md)).

There is no code editor or upload in the browser. Running code supplied that way needs an isolation the
platform does not have yet.

## Steps

Run the commands in `backend`, with its virtual environment active.

1. **Write the module**, for example `app/strategies/custom/rsi_reversion.py`. Start from the
   [template](#template).
2. **List the class** in `app/strategies/custom/__init__.py`:

   ```python
   from app.strategies.base import Strategy
   from app.strategies.custom.rsi_reversion import RsiReversion

   CUSTOM_STRATEGIES: Final[tuple[type[Strategy[Any]], ...]] = (RsiReversion,)
   ```

3. **Check it.** `qt strategies check` registers every strategy as the API and the strategy worker do,
   without touching the database. With the template listed, it prints:

   ```text
   STRATEGY               VERSION  SOURCE   SIGNALS    WARM-UP CANDLES  DATA NEEDED
   example.ema_crossover  1.1.0    example  BUY, SELL  1m: 63           prices only
   my.rsi_reversion       0.1.0    yours    BUY, EXIT  5m: 140          prices only

   Every strategy passes registration (1 of them yours, from app/strategies/custom). Restart the API and the strategy worker to load code changes; the worker then syncs the catalogue.
   ```

   Each problem is printed as an `error:` line and the command exits with status 1. A module that cannot
   be imported shows a Python traceback instead. Causes include a syntax error, a forbidden import or
   metadata that fails validation, such as an invalid `strategy_id`. Then run the plugin rules and your
   [tests](#testing):

   ```text
   pytest tests/unit/test_architecture.py tests/unit/strategies
   ```

4. **Restart the API and the strategy worker.** Each loads the strategy code when it starts. Do not
   restart them with a strategy that fails step 3:
   - the strategy worker stops at startup;
   - the API's strategy requests fail;
   - a module that cannot be imported stops the API from starting.
5. **Sync the catalogue.** The strategy worker syncs it when it starts. To sync on demand, use
   `qt strategies sync`, `POST /api/v1/strategies/sync`, or the **Sync catalogue** button on the
   Strategies page and in the strategy panel. The catalogue records the strategy, its version and its
   code fingerprint, so configurations, runs and signals can name the code they used.
6. **Open a chart.** The strategy is listed in the **Strategies** section of the strategy panel beside
   the chart, with its compatibility with that instrument. `qt strategies show my.rsi_reversion` prints
   its declarations. [Live monitoring](operations/live-monitoring.md) takes it from there: saving a
   configuration, applying it to the chart, and enabling and stopping live signals.

## Template

`app/strategies/custom/rsi_reversion.py`. It passes `qt strategies check`, ruff, strict mypy and the
plugin rules. Replace the rule with yours.

```python
"""RSI reversion: a template for your own strategy (docs/strategy-registration.md).

Replace the rule with yours. As written, on each closed 5-minute candle it proposes BUY when RSI(14)
crosses above the oversold level, with a stop-loss a set percentage below the close, and EXIT when RSI
crosses above the overbought level. It shows the plugin contract; it is not a trading idea.
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import ROUND_HALF_UP, Decimal
from typing import Final

from pydantic import Field, model_validator

from app.domain.enums import CandleInterval, InstrumentType, MarketRegion, Segment, SignalType
from app.domain.models import (
    Candle,
    IndicatorRequirement,
    SignalCandidate,
    SignalCondition,
    StrategyMetadata,
)
from app.strategies.base import Strategy, StrategyConfig, StrategyContext

INTERVAL: Final = CandleInterval.M5
PERIOD: Final = 14
WARMUP: Final = 10 * PERIOD  # Wilder's RSI needs several periods to forget its starting value
_HUNDRED: Final = Decimal(100)


class RsiReversionConfig(StrategyConfig):
    oversold: Decimal = Field(
        default=Decimal(30), gt=0, lt=100, description="BUY when RSI crosses above this level."
    )
    overbought: Decimal = Field(
        default=Decimal(70), gt=0, lt=100, description="EXIT when RSI crosses above this level."
    )
    stop_pct: Decimal = Field(
        default=Decimal("1.5"), gt=0, le=10, description="Stop-loss distance below the close, in percent."
    )
    valid_for_minutes: int = Field(
        default=60, ge=1, le=375, description="How long a signal stays valid if nothing updates it."
    )

    @model_validator(mode="after")
    def _levels_in_order(self) -> RsiReversionConfig:
        if self.oversold >= self.overbought:
            raise ValueError("oversold must be below overbought")
        return self


class RsiReversion(Strategy[RsiReversionConfig]):
    metadata = StrategyMetadata(
        strategy_id="my.rsi_reversion",
        name="RSI reversion (template)",
        description=(
            f"Template. Proposes BUY when RSI({PERIOD}) crosses above the oversold level on a closed "
            f"{INTERVAL.value} candle and EXIT when it crosses above the overbought level."
        ),
        version="0.1.0",
        author="Your name",
        markets=(MarketRegion.INDIA, MarketRegion.LAB),
        segments=(Segment.CASH,),
        instrument_types=(InstrumentType.EQUITY,),
        candle_intervals=(INTERVAL,),
        indicators=(
            IndicatorRequirement(alias="rsi", indicator="rsi", interval=INTERVAL, params={"period": PERIOD}),
        ),
        warmup_candles=WARMUP,
        signal_conditions=(
            SignalCondition(
                signal_type=SignalType.BUY,
                description=(
                    f"On a closed {INTERVAL.value} candle, RSI({PERIOD}) is above oversold after being at "
                    "or below it on the previous candle. Entry: the close. Stop-loss: stop_pct percent "
                    "below the entry, rounded to the tick size. No target."
                ),
                inputs=("rsi", "close"),
            ),
            SignalCondition(
                signal_type=SignalType.EXIT,
                description=(
                    f"On a closed {INTERVAL.value} candle, RSI({PERIOD}) is above overbought after being "
                    "at or below it on the previous candle."
                ),
                inputs=("rsi",),
            ),
        ),
        resource_profile="light",
        risk_profile="every BUY carries a stop-loss",
        can_emit_actionable=True,
    )
    config_model = RsiReversionConfig

    async def on_candle(
        self, candle: Candle, context: StrategyContext[RsiReversionConfig]
    ) -> Sequence[SignalCandidate]:
        instrument_id = candle.instrument_id
        if len(context.candles(instrument_id, INTERVAL)) < WARMUP:
            return ()  # the strategy is called while it warms up; RSI has not settled yet
        rsi = context.value(instrument_id, "rsi")
        previous = context.value(instrument_id, "rsi", lag=1)
        if rsi is None or previous is None:
            return ()
        config, close = context.config, candle.close_price
        reading = context.indicator(instrument_id, "rsi")
        readings = (reading,) if reading is not None else ()
        crossing = f"RSI({PERIOD}) went from {previous:.2f} to {rsi:.2f}"

        if previous <= config.oversold < rsi:
            instrument = context.instrument(instrument_id)
            tick = instrument.tick_size if instrument is not None else None
            stop = _to_tick(close * (1 - config.stop_pct / _HUNDRED), tick)
            if stop <= 0 or stop >= close:
                return ()  # the stop rounds onto the close: no valid level
            return (
                SignalCandidate(
                    instrument_id=instrument_id,
                    signal_type=SignalType.BUY,
                    reasons=(f"{crossing}, crossing above oversold {config.oversold}",),
                    explanation=(
                        f"RSI({PERIOD}) crossed above {config.oversold} on the {INTERVAL.value} candle that "
                        f"closed at {close} ({candle.bucket_end:%H:%M} UTC). Reference entry {close}, "
                        f"stop-loss {stop}. Template strategy; not a recommendation."
                    ),
                    entry_price=close,
                    stop_loss=stop,
                    indicator_values=readings,
                    invalidation_conditions=(
                        f"price trades below the stop-loss {stop}",
                        f"no update within {config.valid_for_minutes} minutes",
                    ),
                    valid_for_seconds=config.valid_for_minutes * 60,
                    source_event_time=candle.last_event_at,
                    source_candle_interval=candle.interval,
                    source_candle_start=candle.bucket_start,
                ),
            )
        if previous <= config.overbought < rsi:
            return (
                SignalCandidate(
                    instrument_id=instrument_id,
                    signal_type=SignalType.EXIT,
                    reasons=(f"{crossing}, crossing above overbought {config.overbought}",),
                    explanation=(
                        f"RSI({PERIOD}) crossed above {config.overbought} on the {INTERVAL.value} candle "
                        f"that closed at {close} ({candle.bucket_end:%H:%M} UTC). Template strategy; not a "
                        "recommendation."
                    ),
                    indicator_values=readings,
                    valid_for_seconds=config.valid_for_minutes * 60,
                    source_event_time=candle.last_event_at,
                    source_candle_interval=candle.interval,
                    source_candle_start=candle.bucket_start,
                ),
            )
        return ()


def _to_tick(price: Decimal, tick: Decimal | None) -> Decimal:
    """Round to the instrument's tick size, keeping only the tick's own decimal places."""
    if tick is None or tick <= 0:
        return price
    rounded = (price / tick).to_integral_value(rounding=ROUND_HALF_UP) * tick
    exponent = tick.normalize().as_tuple().exponent
    return rounded.quantize(Decimal(1).scaleb(min(exponent, 0))) if isinstance(exponent, int) else rounded
```

An EXIT closes the open signal of the same configuration and instrument. When none is open, the EXIT is
stored as a signal of its own: a strategy does not see what happened to its earlier proposals.

## Declarations

`metadata` is a `StrategyMetadata`. Registration checks every value and rejects contradictions, such as an
exchange outside the declared markets or a condition input that nothing provides.

| Field | Required | Meaning and rules |
| --- | --- | --- |
| `strategy_id` | yes | 3 to 64 characters: a lower-case letter, then lower-case letters, digits, `_`, `.` or `-`. Configurations, runs and signals refer to it, so never rename it. |
| `name`, `description` | yes | Shown in the strategy panel. |
| `version` | yes | `MAJOR.MINOR.PATCH`. Bump it for every change in behaviour ([versions](#versions-and-code-identity)). |
| `author` | yes | Free text. |
| `markets` | yes | At least one of `INDIA`, `FOREX`, `CRYPTO` and `LAB`. `LAB` is the simulator, for trying a strategy without a broker. |
| `exchanges` | no | `NSE`, `BSE` or `MCX` (market `INDIA`), or `SIM` (`LAB`). Each must belong to a declared market. Empty means any. |
| `segments` | yes | At least one of `CASH`, `FNO`, `CURRENCY`, `COMMODITY` and `INDEX`. |
| `instrument_types` | yes | At least one of `EQUITY`, `INDEX`, `FUTURE`, `OPTION` and `OTHER`. |
| `instrument_keys` | no | Restricts the strategy to these instruments. Use upper-case canonical keys, such as `NSE:CASH:EQUITY:INFY` (futures and options have more parts), that the other declarations allow. |
| `candle_intervals` | this or `event_types` | The timeframes `on_candle` runs on: `1s`, `1m`, `3m`, `5m`, `15m`, `30m`, `1h` or `1d`. The platform must build them. `CANDLE_INTERVALS` defaults to `1m` through `1d`, without `1s`. |
| `event_types` | this or `candle_intervals` | The market events `on_market_event` receives: `LTP`, `QUOTE`, `DEPTH` or `INDEX_VALUE`. |
| `indicators` | no | `IndicatorRequirement(alias, indicator, interval, params)`. The alias (a lower-case letter, then lower-case letters, digits or `_`, up to 64 characters) is the name you read the indicator by. Available indicators: `rsi`, `sma`, `ema`, `macd`, `supertrend`, `atr`, `atr_percent`, `bollinger`, `returns_stdev`, `vwap`, `volume_sma`, `relative_volume` and `opening_range`. Their parameters and outputs are in `app/strategies/indicators`. An indicator may use an interval that is not in `candle_intervals`, if the platform builds it. |
| `warmup_candles` | no | The closed candles each interval needs before the strategy's readings settle, at most 5000. The worker feeds stored candles first. `qt strategies check` shows the count per interval. |
| `required_data` | no | `VOLUME`, `OPEN_INTEREST` or `MARKET_DEPTH`. The last two need `event_types`. Volume indicators and inputs add what they need by themselves. |
| `signal_conditions` | no | One `SignalCondition(signal_type, description, inputs)` per signal type the strategy proposes. The description is 1 to 500 characters and is shown in the panel. `inputs` lists what the condition reads: indicator aliases or `alias.output`; `open`, `high`, `low`, `close` and `volume` with candle intervals; `last_price`, `bid`, `ask`, `volume`, `open_interest` and `market_depth` with event types. A strategy can only propose the types declared here. |
| `uses_partial_candles` | no | Must stay `False`: strategies see closed candles only. |
| `resource_profile` | no | `light` (the default), `medium` or `heavy`. |
| `risk_profile` | no | Free text about the strategy's risk handling. |
| `can_emit_actionable` | no | `False` (the default): every signal is informational. `True`: an allowed BUY, SELL or EXIT on real data is actionable. |
| `kind`, `is_example` | no | Leave the defaults. |

## Declaring trade rules

A backtest needs trade rules: which sides to trade, when decisions fill, where stops and targets come
from, how entries are sized and what trading costs ([backtesting](backtesting.md#step-2-set-the-trade-rules)).
A strategy may declare default rules as `trade_rules`; rules saved with a configuration take precedence.
Without either, its backtests are refused. The template proposes BUY with a stop-loss and no target, then
EXIT, so it could declare:

```python
from app.domain.enums import ExitCheck, FillTiming, OppositeSignal, SizingMethod, StopTargetSource, TradeSides
from app.domain.models.backtest import TradeRules


class RsiReversion(Strategy[RsiReversionConfig]):
    metadata = StrategyMetadata(...)  # as in the template
    config_model = RsiReversionConfig
    trade_rules = TradeRules(
        sides=TradeSides.LONG_ONLY,
        opposite_signal=OppositeSignal.CLOSE,
        fill=FillTiming.NEXT_OPEN,
        exit_check=ExitCheck.INTRABAR,
        stop_target=StopTargetSource.SIGNAL,  # the BUY's stop-loss; it proposes no target
        sizing=SizingMethod.RISK_PERCENT,
        risk_pct=Decimal("1"),
        initial_capital=Decimal("100000"),
        fee_pct_per_side=Decimal("0.03"),
        fee_per_order=Decimal("20"),
        slippage_ticks=1,
    )
```

- `TradeRules` checks its values as it is created, so a contradiction (such as `quantity` with
  `RISK_PERCENT`) fails when the module is imported. Registration rejects a `trade_rules` that is not a
  `TradeRules` or `None`.
- The rules are part of the module, so changing them changes its fingerprint: bump `version`, as for any
  change in behaviour ([versions](#versions-and-code-identity)). Backtests that used other rules become
  outdated.
- `qt backtests rules show WORKSPACE CONFIGURATION` prints the rules a configuration would use, and where
  they come from.

## Settings and their form

`config_model` is a subclass of `StrategyConfig`, a frozen Pydantic model that rejects unknown keys.
- **Defaults:** every field needs a default, and registration checks that the defaults validate, because a
  new configuration starts from them.
- **Validation:** declare constraints with `Field(default=..., ge=, gt=, le=, lt=, description=...)`. Add a
  `model_validator` for rules that span fields, as the template does.

The configuration dialog builds its form from the model's JSON schema:

| Python type | Form control |
| --- | --- |
| `bool` | checkbox |
| `int`, `float`, `Decimal` | number field, with the declared bounds |
| `str` | text field |
| `Literal[...]` or an `Enum` | drop-down list |
| `X \| None` | the control for `X`, which may be left empty (an optional `bool` becomes a drop-down list) |
| anything else (lists, mappings, nested models) | JSON text |

Each field has two labels:
- **Label:** the field's title. Pydantic derives the title from the name (`stop_pct` becomes "Stop Pct");
  set `Field(title=...)` for a better one.
- **Help text:** the `description`.

The API validates every save against the model, including rules that span fields. Each configuration
keeps an immutable snapshot of its settings; changing them means saving the configuration again.

## The context and the hooks

A strategy sees market data only through its `StrategyContext`:

| Member | Gives |
| --- | --- |
| `context.config` | The configuration's settings, an instance of your `config_model`. |
| `context.now()` | The current UTC time. Use it instead of reading the clock. |
| `context.instrument_ids` | The instruments in the configuration's scope. |
| `context.instrument(id)` | The instrument's reference data (symbol, exchange, tick size, ...), or `None`. |
| `context.value(id, name, lag=0)` | An indicator output as a `Decimal`, read by `alias` or `alias.output`. `None` while the indicator warms up or when the output is undefined. `lag=1` reads the value after the previous candle. |
| `context.indicator(id, name, lag=0)` | The full reading (`IndicatorValue`), to attach to a signal. |
| `context.indicators(id, lag=0)` | Every reading, by name. |
| `context.candles(id, interval, count=None)` | Recent closed candles, oldest first. Up to `warmup_candles` of them (at least the latest) are kept per interval in `candle_intervals`. |
| `context.log` | A structured logger. |
| `context.run_id`, `.deployment_id`, `.workspace_id` | The run, the saved configuration and its workspace. |

Override the hooks you need:

| Hook | When it runs |
| --- | --- |
| `on_candle(candle, context)` | For each newly closed candle on `candle_intervals` of an instrument in scope, after the indicators have taken it. It also runs while the strategy warms up, so check for `None`. |
| `on_market_event(event, context)` | For each market event of an instrument in scope, when `event_types` is set. |
| `initialize(context)` | Once per run, after the warm-up and before any live data. |
| `shutdown()` | Once, when the run stops. |

One instance serves one run. Its attributes are private to that run and are lost when the run restarts,
for example after an edit or a worker restart.

The runtime limits each hook:
- **Timeout:** each call gets `STRATEGY_TIMEOUT_SECONDS` (0.5 s).
- **Failures:** an exception, a timeout and a broken contract all count as failures. After
  `STRATEGY_FAILURE_THRESHOLD` (5) consecutive failures, the circuit opens. Calls then stop for
  `STRATEGY_CIRCUIT_RESET_SECONDS` (60 s), then one trial call is let through.
- **Contract:** a hook returns a sequence of at most 50 `SignalCandidate`s. Each must be of a declared
  signal type, for an instrument in scope.
- **Blocking:** a hook must not block. A hook that blocks the event loop stalls the whole strategy
  worker, and its timeout only detects it afterwards.

## Proposing signals

A hook returns `SignalCandidate`s:

| Field | Notes |
| --- | --- |
| `instrument_id` | An instrument in scope. |
| `signal_type` | `BUY`, `SELL`, `EXIT`, `HOLD`, `WATCH` or `INVALIDATED`, declared in `signal_conditions`. |
| `reasons` | At least one short statement. Shown in the signal detail. |
| `explanation` | Required text. |
| `entry_price`, `stop_loss`, `targets` | Optional reference levels. A target is a `TargetLevel(label, price)`. |
| `score`, `score_definition` | Optional. A score needs a definition. It is not a probability or a historical win rate. |
| `indicator_values` | The readings to show with the signal, from `context.indicator`. |
| `invalidation_conditions` | What would make the signal wrong. |
| `valid_for_seconds` | The signal's lifetime. Defaults to `SIGNAL_DEFAULT_VALIDITY_SECONDS` (900). |
| `source_event_time`, `source_candle_interval`, `source_candle_start` | The data it was computed from. Set them from the candle, as the template does. |

Prices and indicator values are `Decimal` ([ADR-004](decisions/004-decimal-and-utc.md)). Mixing them with
`float` raises `TypeError`, so write constants as `Decimal`.

The signal engine then applies the [risk gate and the lifecycle](architecture/data-flow.md#4-from-candle-to-signal).

**Risk rules that shape proposals** (default settings):
- **`stop_loss_required`:** BUY and SELL need a stop-loss.
- **`price_sanity`:** BUY and SELL levels must be on the correct side of the entry, and the entry within
  2 % of the last price.
- **`volatility_limit`:** the stop must be at most 10 % from the entry.
- **`frequency`:** at most 3 BUY or SELL signals per configuration and instrument per 60 minutes.

**Lifecycle:** one signal per configuration and instrument is open.
- A candidate repeating the open signal's type and levels is dropped.
- Changed levels update the open signal.
- Another type replaces it: SUPERSEDED, or CLOSED by an EXIT.
- An `INVALIDATED` candidate closes it.
- Open signals expire at the end of their validity.

**Actionable signals:** only an allowed BUY, SELL or EXIT from a strategy with `can_emit_actionable`, on
real data, is actionable. Everything else is informational, including every signal on simulated data.

## Plugin rules

`tests/unit/test_architecture.py` checks every module under `app/strategies`, including `custom`. A
strategy module may import only:
- **Standard library:** `__future__`, `abc`, `collections`, `dataclasses`, `datetime`, `decimal`, `enum`,
  `functools`, `itertools`, `math`, `operator`, `statistics`, `typing` and `uuid`.
- **Packages:** `pydantic`, `app.domain.enums`, `app.domain.models` and `app.strategies`, except
  `app.strategies.registry` and `app.strategies.runtime`.

Everything else is refused, including `numpy`, `pandas`, `requests`, `os`, `time` and `random`.

Other rules:
- The builtins `open`, `eval`, `exec`, `compile`, `__import__`, `breakpoint`, `input`, `globals` and
  `__builtins__` are refused.
- Reading the clock (`datetime.now()`, `utcnow()`, `today()`) is refused; use `context.now()`, which tests
  can fix.
- No I/O of any kind: a strategy gets no database, network, files or credentials.

## Versions and code identity

Registration fingerprints the strategy's module: a SHA-256 of its source. Only that module counts, so a
change to a helper module it imports does not change the fingerprint. Each run records the fingerprint of
the code it ran.

Bump `version` for every change in behaviour:
- **After a bump:** the next sync lists the strategy under "New versions". Its saved configurations are
  blocked with "it was saved with version A but the code has B; save it again to upgrade".
- **To upgrade a configuration:** save it again, with **Edit…** then **Save**, or with
  `qt strategies update WORKSPACE CONFIGURATION`. It moves to the code's version and keeps the settings
  that still exist; new settings take their defaults.
- **Changing the code without a bump:** `qt strategies sync` prints "warning: strategy code changed
  without a version bump", and the catalogue's entry for that version takes the new fingerprint. The
  version number then no longer identifies the code; only the runs' recorded fingerprints tell the two
  apart.

## Testing

Test the rule without the worker, as in `tests/unit/strategies/test_example_strategy.py`: give the
strategy a context over a fake market. For the template, `tests/unit/strategies/test_rsi_reversion.py`:

```python
"""The RSI reversion strategy, with a fake market in place of the strategy worker."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

import pytest
import structlog
from pydantic import ValidationError

from app.domain.enums import CandleInterval, DataStatus, SignalType
from app.domain.models import Candle, IndicatorValue, Instrument
from app.strategies.base import StrategyContext
from app.strategies.custom.rsi_reversion import WARMUP, RsiReversion, RsiReversionConfig
from app.strategies.registry import register
from tests.candle_support import INSTRUMENT, T0, bar

M5 = CandleInterval.M5


class FakeMarket:
    """RSI after the latest closed candle (lag 0) and the one before (lag 1), over ``history`` candles."""

    def __init__(self, latest: str, previous: str, history: int = WARMUP) -> None:
        self._rsi = {0: Decimal(latest), 1: Decimal(previous)}
        self._history = [bar(index, 100, interval=M5) for index in range(history)]

    @property
    def instrument_ids(self) -> frozenset[UUID]:
        return frozenset({INSTRUMENT})

    def instrument(self, instrument_id: UUID) -> Instrument | None:
        return None  # no tick size: levels are not rounded

    def indicator_values(self, instrument_id: UUID, lag: int) -> Mapping[str, IndicatorValue]:
        reading = IndicatorValue(
            name="rsi",
            indicator="rsi",
            version="1.0",
            value=self._rsi[lag],
            interval=M5,
            data_status=DataStatus.LIVE,
        )
        return {"rsi": reading}

    def candles(self, instrument_id: UUID, interval: CandleInterval) -> Sequence[Candle]:
        return self._history


def _context(market: FakeMarket, **settings: Any) -> StrategyContext[RsiReversionConfig]:
    return StrategyContext(
        config=RsiReversionConfig(**settings),
        run_id=uuid4(),
        deployment_id=uuid4(),
        workspace_id=uuid4(),
        market=market,
        clock=lambda: T0,
        log=structlog.stdlib.get_logger("test"),
    )


def test_it_passes_registration() -> None:
    assert register(RsiReversion).strategy_id == "my.rsi_reversion"


async def test_crossing_above_oversold_proposes_buy_with_a_stop_loss() -> None:
    candle = bar(WARMUP, 200, interval=M5)
    (signal,) = await RsiReversion().on_candle(candle, _context(FakeMarket("31", "29")))
    assert signal.signal_type is SignalType.BUY
    assert (signal.entry_price, signal.stop_loss) == (Decimal(200), Decimal(197))


async def test_crossing_above_overbought_proposes_exit() -> None:
    candle = bar(WARMUP, 200, interval=M5)
    (signal,) = await RsiReversion().on_candle(candle, _context(FakeMarket("71", "69")))
    assert signal.signal_type is SignalType.EXIT


async def test_nothing_without_a_crossing_or_before_the_warm_up() -> None:
    candle = bar(WARMUP, 200, interval=M5)
    assert await RsiReversion().on_candle(candle, _context(FakeMarket("35", "33"))) == ()
    assert await RsiReversion().on_candle(candle, _context(FakeMarket("31", "29", history=10))) == ()


def test_oversold_must_stay_below_overbought() -> None:
    with pytest.raises(ValidationError, match="oversold must be below overbought"):
        RsiReversionConfig(oversold=Decimal(70), overbought=Decimal(30))
```

Run it with `pytest tests/unit/strategies/test_rsi_reversion.py`.

To watch the strategy on live-shaped data without a broker, declare the `LAB` market and run it on the
simulator's `simulation-lab` workspace (see the [README](../README.md)). Signals on simulated data are
informational only.

## Removing a strategy

Remove the class from `CUSTOM_STRATEGIES`, then restart and sync:
- **The catalogue** keeps the strategy, marked unavailable, so its runs and signals stay readable.
- **Its configurations** are blocked with "strategy *id* is no longer in the code". Stop and archive them.
- **Putting it back** restores it: the next sync lists it under "Restored".

Never reuse a strategy id for a different strategy.

## Not supported yet

- Editing or uploading strategy code in the browser.
- Backtests of strategies that react to market events, or that use candles of more than one interval
  ([backtesting](backtesting.md#known-limitations)).
- Partial (still-forming) candles.
