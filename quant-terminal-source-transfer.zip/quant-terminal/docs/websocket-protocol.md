# WebSocket protocol

Live updates for the frontend: quotes, forming and closed candles, feed status, signal updates and
system health. The REST API (`/api/v1`) is always the snapshot. A WebSocket delivers only what changes
after you subscribe, and nothing missed while disconnected is replayed.

Source: `backend/app/api/ws/` (`routes.py` endpoints and limits, `protocol.py` messages and close
codes, `hub.py` fan-out and conflation). Settings named in `UPPER_CASE` are environment variables
read by `backend/app/core/config.py`.

## Endpoints

| Path | Channels | Purpose |
| --- | --- | --- |
| `/ws/v1/market` | `quotes`, `candles`, `feed` | Latest quotes, forming and closed candles, feed status |
| `/ws/v1/signals` | `signals` | Signal lifecycle updates |
| `/ws/v1/system` | `system` | System health |

The endpoints are served by the API process itself (default `ws://localhost:8000`), not through the
frontend's `/api` proxy. Use `localhost` consistently in browser-facing URLs so the session cookie is
sent to both.

## Connecting

1. **Origin.** The `Origin` header must be one of `ALLOWED_ORIGINS`. Otherwise the handshake is
   refused before it is accepted; a browser reports close code 1006 with no reason.
2. **Session.** The connection is accepted, then the `qt_session` cookie is checked (the same cookie
   as the REST API; sign in with `POST /api/v1/auth/login` first). No valid session closes with
   **4401** `unauthenticated`. If Redis cannot be reached, it closes with 1011 `unavailable`.
3. **Connection limit.** At most 10 open connections per user per API process; one more closes with
   1008 `too_many_connections`.
4. **Welcome.** The server sends a `welcome` frame:

```json
{
  "type": "welcome",
  "connection_id": "3f9c0d5be3a94f6f8f3f5b7d2a1c9e04",
  "channels": ["candles", "feed", "quotes"],
  "server_time": "2026-11-02T04:00:00.123456Z",
  "heartbeat_interval_seconds": 15.0,
  "max_updates_per_second": 4.0,
  "stale_after_seconds": 30.0,
  "max_instruments": 500,
  "reconnect": {
    "retry_close_codes": [1001, 1006, 1011, 1012, 1013],
    "final_close_codes": [1003, 1008, 4401],
    "initial_delay_seconds": 1,
    "max_delay_seconds": 30,
    "advice": "After an unexpected close, reconnect with exponential backoff and jitter, ..."
  }
}
```

The session is checked again every `WS_HEARTBEAT_INTERVAL_SECONDS` (15 s). Signing out, an expired
session or a different user on the cookie closes the connection with **4401** `session_expired`.
If Redis is briefly unavailable for that check, the connection is kept and checked next time.

## Client messages

JSON **text** frames, each an object with an `action`. Unknown fields are rejected.

| Field | Applies to | Notes |
| --- | --- | --- |
| `action` | all | `subscribe`, `unsubscribe` or `heartbeat` |
| `request_id` | all | Optional, `^[A-Za-z0-9._:-]{1,64}$`; echoed on the reply |
| `channel` | subscribe, unsubscribe | One of the endpoint's channels |
| `workspace_id` | quotes, candles, signals | Workspace slug or id (1–64 characters) |
| `instrument_ids` | quotes, candles, signals | Up to 500 instrument UUIDs |
| `provider` | quotes, candles, feed | `ZERODHA`, `GROWW` or `SIMULATOR` |
| `interval` | candles (required) | A candle interval such as `1m` (see `CANDLE_INTERVALS`) |
| `depth` | quotes | `true` to include market depth (default `false`) |

Setting an option that the channel does not take returns `option_not_allowed`.

- **quotes / candles** need a selection: a workspace (its universe, optionally narrowed to
  `instrument_ids`) or at least one instrument id (from every provider streaming it, or only
  `provider`). A selection may cover at most 1500 (provider, instrument) pairs.
- **feed** takes an optional `provider`; **signals** an optional workspace and/or instruments;
  **system** takes no options.
- Subscribing to a channel again **replaces** this connection's earlier subscription to it. Editing a
  workspace's universe does not change existing subscriptions: resubscribe.

```json
{"action": "subscribe", "channel": "quotes", "workspace_id": "india-equity", "depth": false, "request_id": "q1"}
{"action": "subscribe", "channel": "candles", "instrument_ids": ["8d0b6f0e-..."], "interval": "5m", "request_id": "c1"}
{"action": "subscribe", "channel": "feed", "provider": "ZERODHA"}
{"action": "unsubscribe", "channel": "quotes", "request_id": "q2"}
{"action": "heartbeat", "request_id": "h1"}
```

Client heartbeats are optional: the server sends its own every 15 s and does not time out quiet
clients.

## Server frames

Every frame is a JSON object with a `type`. Prices are exact decimal **strings** and times ISO 8601
UTC, exactly as in the REST API; `items` hold the same objects as the matching REST endpoint.

| `type` | Channel | Content |
| --- | --- | --- |
| `welcome` | — | See above |
| `subscribed` | any | `channel`, `request_id`, `workspace` (`{id, slug}` or null), `instrument_ids`, `provider`, `interval`, `depth` |
| `unsubscribed` | any | `channel`, `request_id` |
| `heartbeat` | — | `server_time`, `request_id` (null when sent by the server) |
| `error` | — | `code`, `message`, `details`, `request_id` |
| `quote.snapshot` | quotes | `items`, `missing` (requested instrument ids with no quote yet), `generated_at`, `request_id` |
| `quote.update` | quotes | `items`: quotes that changed |
| `candle.snapshot` | candles | `items` (forming candles), `interval`, `generated_at`, `request_id` |
| `candle.update` | candles | `items`: forming candles that changed |
| `candle.closed` | candles | `candle`: one closed candle |
| `feed.status` | feed | `streams`, `providers` (status per provider), `generated_at` |
| `feed.state_change` | feed | `provider`, `account_id`, `stream_id`, `previous_state`, `state`, `reason`, `at` |
| `signal.update` | signals | `event_type`, `at`, `signal` |
| `system.status` | system | `health`: the `GET /api/v1/system/health` report |

After a valid `subscribe`, the server sends `subscribed` and then the channel's snapshot:

- quotes: `quote.snapshot`, the same items as `GET /api/v1/quotes/latest`;
- candles: `candle.snapshot` with the forming candles (closed history comes from `GET /api/v1/candles`);
- feed: `feed.status`;
- system: `system.status`;
- signals: no snapshot. Load `GET /api/v1/signals` and apply the updates that follow the ack.

Every quote and candle carries its own `data_status` (`LIVE`, `DELAYED`, `STALE`, `DISCONNECTED`,
`RECONNECTING`, `SIMULATED` or `UNKNOWN`). Show it: a quote with no new data for
`DATA_STALE_AFTER_SECONDS` (30 s) becomes `STALE`, and simulated data is always `SIMULATED`.

## Delivery, conflation and slow clients

- **Latest values** (quotes, forming candles, feed and system status) are read at most
  `WS_MAX_UPDATES_PER_SECOND` (4) times a second and **conflated** per client. An item is queued
  only when it changed, and an update replaced before it was sent is dropped: you always get the
  newest value, not every tick. Feed status is refreshed every
  `FEED_STATUS_PUBLISH_INTERVAL_SECONDS` (1 s) and at once after a state change; system status every
  5 s.
- **Events** (`candle.closed`, `feed.state_change`, `signal.update`) and replies are queued in
  order and never conflated, up to `WS_CLIENT_QUEUE_SIZE` (500) frames.
- A forming candle is never sent after the closed candle of the same bucket.
- A client whose queue overflows, or that lets more than `WS_SLOW_CLIENT_DROP_LIMIT` (2000) updates
  be replaced before reading them, is closed with **1013** `slow_client`.

## Limits and errors

| Limit | Value | Result |
| --- | --- | --- |
| Frame type | text only | A binary frame closes with **1003** `text_frames_only` |
| Message size | 32 KiB (32,768 characters) | `error` `message_too_large` |
| Message rate | 100 messages per 10-second window | Close **1008** `rate_limited` |
| Unparseable messages | 20 per connection | The 20th closes with **1008** `too_many_invalid_messages` |
| Connections | 10 per user per API process | Close **1008** `too_many_connections` |
| Instruments | 500 ids per subscription; 1500 (provider, instrument) pairs | `error` (`invalid_message` / `selection_too_large`) |

Only messages that cannot be parsed (`invalid_message`, `message_too_large`) count towards the
invalid-message limit. A request that parses but fails gets an `error` and the connection stays open.
`request_id` is echoed whenever it could be read.

| Error code | Meaning |
| --- | --- |
| `invalid_message` | Not valid JSON, unknown action or field, or a value out of range (`details` lists the problems without echoing input) |
| `message_too_large` | Over 32 KiB |
| `channel_not_available` | The channel is not served on this endpoint |
| `option_not_allowed` | An option the channel does not take |
| `selection_required` | quotes/candles without a workspace or instruments |
| `interval_required` | candles without `interval` |
| `selection_too_large` | More than 1500 (provider, instrument) pairs |
| `unavailable` | Redis or the database failed; try again shortly |
| REST error codes | For example an unknown workspace, as in the REST API |

## Close codes and reconnecting

| Code | Reason(s) | What the client should do |
| --- | --- | --- |
| 1000 | — | Normal close |
| 1001 | `server_shutdown` | Reconnect with backoff |
| 1003 | `text_frames_only` | Fix the client; do not retry |
| 1006 | (set by the browser) | Connection lost or handshake refused. Retry with backoff, but check `ALLOWED_ORIGINS` if it never connects |
| 1008 | `too_many_connections`, `rate_limited`, `too_many_invalid_messages` | Fix the client (or close other tabs); do not retry blindly |
| 1011 | `unavailable`, `internal_error` | Reconnect with backoff |
| 1012 | (proxy or server restart) | Reconnect with backoff |
| 1013 | `slow_client` | Reconnect with backoff; read frames faster or subscribe to less |
| 4401 | `unauthenticated`, `session_expired` | Sign in again, then reconnect |

After an unexpected close, reconnect with exponential backoff and jitter (1 s doubling to 30 s),
resubscribe, and reload the REST snapshots. The frontend's client (`frontend/src/lib/ws/socket.ts`)
backs off this way and resubscribes after every reconnect, once the `welcome` frame has arrived.
