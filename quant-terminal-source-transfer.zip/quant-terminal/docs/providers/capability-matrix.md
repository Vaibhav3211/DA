# Provider capability matrix

What each provider supports, as encoded in `backend/app/providers/capabilities.py`. Zerodha and
Groww values were verified on **2026-10-30** from official documentation and official SDK source, not
from a live account. Support is never inferred from an instrument merely appearing in a provider's
symbol list.

The details, links and open questions are in [zerodha.md](zerodha.md) and [groww.md](groww.md).

| Capability | Zerodha Kite Connect | Groww Trading API | Simulator |
| --- | --- | --- | --- |
| Exchanges | NSE, BSE, MCX | NSE, BSE | SIM (synthetic only) |
| Segments | cash, F&O, currency, commodity, indices | cash, F&O, indices | cash, indices |
| Instrument types | equity, index, future, option | equity, index, future, option | equity, index |
| Streaming | yes: binary WebSocket | yes: NATS over WebSocket (from SDK source) | yes |
| Modes | LTP, QUOTE, FULL | LTP and QUOTE (price feed), FULL (+ depth feed) | LTP, QUOTE, FULL |
| Depth | 5 levels (FULL) | aggregated, variable size (FULL) | 5 levels (FULL) |
| Exchange timestamp | FULL packets only | `tsInMillis` (meaning unverified) | yes |
| Volume | cumulative day volume (QUOTE, FULL) | ignored unless `GROWW_FEED_VOLUME_IS_CUMULATIVE=true` | cumulative day volume |
| Instruments per connection | 3000 | 1000 subscriptions (FULL uses 2) | 5000 |
| Connections per account | 3 per API key | 1 (assumed) | 1 |
| REST quotes | yes | yes | no |
| REST limits | quote 1/s (≤500 instruments); LTP/OHLC ≤1000 per call; historical 3/s; other 10/s | live data 10/s and 300/min (≤50 per LTP/OHLC call); auth 5/s and 30/min; non-trading 20/s and 500/min; 150 tokens per 24 h | — |
| Historical candles | 1m to 1d; cash, F&O, currency, commodity, indices; paid plan | 1m to 1d; cash and F&O; from 2020 | none to download: backtests replay recorded simulator candles |
| Token lifetime | until about 06:00 IST the next day; no refresh token | daily (`exp` claim, else 06:00 IST) | — |
| Daily re-auth | Kite login redirect | token from Groww Cloud, API key + secret (daily approval) or TOTP | none |
| Entitlement | paid Kite Connect plan (INR 500/month per app) | active Trading API subscription (price not officially published) | none; `APP_ENV` development or replay with `SIMULATOR_ENABLED=true` |
| Data-use terms | no redistribution, public display or mock trading | none specific found: own use only | labelled `SIMULATED`; never real data |

Historical candles feed only backtest datasets. Their support is encoded in
`backend/app/providers/history.py`, not in the capabilities, and is described in
[backtesting](../backtesting.md#what-the-providers-offer).

The simulator streams only synthetic `SIM`-exchange instruments (the Simulation Lab workspace). It is
never attached to real exchange symbols and never used as a fallback for a live provider.

## How the platform uses capabilities

- **Subscription planning** (market-data worker) reads each enabled account's *effective*
  capabilities. An account whose provider does not stream is left idle (`streaming_disabled`).
  Instruments outside its exchanges, segments or modes are skipped as `unsupported`, and
  instruments the provider does not list as `not_listed`. The skips are visible on the workspace's
  universe.
- **Workspaces** refuse to add an instrument with a subscription mode the provider does not offer.
- **Streaming adapters** spread subscriptions across at most `max_connections_per_account`
  connections of `max_instruments_per_connection` slots each.
- The API serves the effective values at `GET /api/v1/providers/{provider}/capabilities`, and the
  frontend's Providers page shows them.

## Correcting a value

If a live check shows that a documented value is wrong for your account or plan, record an override
instead of editing code. Overrides live in the `provider_capabilities` table; an account-level row
beats a provider-level row, which beats the defaults.

```powershell
qt capabilities show groww
qt capabilities set groww max_connections_per_account=2 --source "live check, support ticket #123"
qt capabilities set zerodha depth_levels=5 --account "My Kite" --source "live smoke test"
qt capabilities clear groww max_connections_per_account
```

`--verified-on` defaults to today. Overrides are managed only from the CLI.
