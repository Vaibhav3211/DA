# Zerodha Kite Connect

Facts below were verified on **2026-10-30** from the official Kite Connect documentation and the
pykiteconnect 5.2.2 source (`ticker.py`). No live account was available, so live connectivity is
**unverified** until the live smoke tests pass on your machine (see
[Verifying live](#verifying-live)). The same values drive the code:
`backend/app/providers/capabilities.py` and `backend/app/providers/zerodha/constants.py`.

Official documentation:

- Kite Connect v3: <https://kite.trade/docs/connect/v3/>
- Login flow and sessions: <https://kite.trade/docs/connect/v3/user/>
- WebSocket streaming: <https://kite.trade/docs/connect/v3/websocket/>
- Market quotes and limits: <https://kite.trade/docs/connect/v3/market-quotes/>
- Exceptions: <https://kite.trade/docs/connect/v3/exceptions/>
- Developer console: <https://developers.kite.trade/>
- Terms: <https://kite.trade/terms/>

## Subscription requirements

- A Kite Connect app on the developer console. **WebSocket streaming, market depth and historical
  data need the paid Kite Connect plan (INR 500/month per app).** The free Personal plan has no
  market data, so this platform cannot stream with it.
- The redirect URL registered for the app must equal `ZERODHA_REDIRECT_URL` exactly. Use the
  frontend origin, `http://localhost:3000/api/v1/providers/zerodha/callback`, so the callback goes
  through the frontend proxy where the browser sends the session cookie.
- **Data-use terms:** Kite Connect terms prohibit redistributing, reselling or publicly displaying
  market data, and using it in virtual or mock-trading products. Use the data for the account
  holder only.

## Setting up an account

```powershell
qt accounts add zerodha "My Kite"           # stays disabled until enabled
qt accounts set-credentials "My Kite" --api-key --api-secret   # prompted without echo, stored encrypted
qt accounts enable "My Kite"                # one enabled account per provider streams
```

Credentials stored on the account take precedence. `ZERODHA_API_KEY` and `ZERODHA_API_SECRET` in
`backend/.env` are only a deployment-wide fallback. Run `qt accounts --help` for every option.

## Daily login

Kite has **no refresh token** for individual developer apps. The access token is invalidated at
**about 06:00 IST the next day**, whatever time you logged in, so log in once per trading day:

- **Web:** Providers page → **Sign in with Kite** (**Sign in again** once signed in). You are sent to
  Kite, and Kite redirects back to the Providers page.
- **CLI:** `qt zerodha login` prints the Kite login address. After logging in, the callback page
  says "Finish the login at the command line" and shows the address to paste back. You do not need to be signed in
  to the web app for this.

How it works: the login URL carries a one-time `state` (valid 10 minutes, bound to who started the
login) through Kite's `redirect_params`. Kite redirects with a `request_token`, which the backend
exchanges at `POST /session/token` with `checksum = SHA-256(api_key + request_token + api_secret)`.
The access token is encrypted with AES-GCM before it is stored. `qt zerodha logout` ends the Kite
session (`DELETE /session/token`) and deletes the token.

## Instruments

Run `qt instruments refresh zerodha` **every trading day after about 08:30 IST**. Kite reuses the
`instrument_token` values of expired derivatives for new contracts, so a stale instrument master can
map ticks to the wrong instrument. There is no scheduler yet; see the
[runbook](../operations/live-feed-runbook.md).

Instrument dump exchanges are mapped as: NSE and BSE (cash), NFO and BFO (F&O), CDS and BCD
(currency), MCX and NCO (commodity), and `INDICES` rows (indices). Indices are not tradable and
stream no volume or depth.

## Streaming

- Endpoint `wss://ws.kite.trade` (`ZERODHA_WS_URL`), binary packets. The platform has its own
  client and parser, built from pykiteconnect's `ticker.py`; the SDK is not a runtime dependency.
- Modes: `ltp`, `quote` and `full`, mapped to LTP, QUOTE and FULL. FULL adds 5-level depth, last
  trade time and the exchange timestamp. Only FULL packets carry an exchange timestamp; other modes
  use the receive time and their candles are flagged `RECEIVE_TIME_BASIS`.
- Prices arrive as integers: paise (2 decimals), except currency (CDS 7 decimals, BCD 4) and NSE
  commodity (NCO 4). They become exact decimals; floats are never used.
- Volume is cumulative for the day (QUOTE and FULL).
- Limits: **3000 instruments per connection** and **3 connections per API key**.

## REST API used

| Call | Use | Documented limit |
| --- | --- | --- |
| `POST /session/token`, `DELETE /session/token` | Login and logout | 10 requests/s |
| `GET /user/profile` | Token check | 10 requests/s |
| `GET /instruments` | Instrument master (`--account` picks whose API key downloads it) | 10 requests/s |
| `GET /quote/ltp` | Live smoke tests only: REST last prices checked against tick sizes and the stream | ≤1000 instruments per call |
| `GET /instruments/historical/{token}/{interval}` | Backtest datasets only: historical candles, with open interest for futures and options ([backtesting](../backtesting.md)) | 3 requests/s |

The client also implements `/quote` (1 request/s, ≤500 instruments) and `/quote/ohlc`, but the
platform does not call them.

Historical candles feed only [backtest datasets](../backtesting.md#step-1-get-candles): live charts and
signals are always built from the live stream. They need the paid Kite Connect plan and the account's
current access token. A download is split into requests of at most 30 days (1 minute), 90 days (3 and
5 minutes), 180 days (15 and 30 minutes), 365 days (1 hour) or 1800 days (1 day), below the ranges
Kite accepts, and sent one after another. The ranges are in `backend/app/providers/history.py`.

## Verifying live

These need a real account and could not be confirmed from documentation alone:

- WebSocket streaming and depth on the account's actual Kite Connect plan.
- The exact daily token invalidation time (documented as about 06:00 IST).
- Price scaling, timestamp time zone, depth ordering, and staying connected on heartbeats outside
  market hours.
- Historical candles: the per-interval ranges Kite accepts and the response format. The download is
  tested only against fixtures, not a live account.

Run the read-only live smoke tests from `backend` after logging in and refreshing instruments:

```powershell
$env:RUN_LIVE_SMOKE = "1"; pytest -m live tests/live
```

`backend/tests/live/test_live_smoke.py` documents the optional variables. If a verified value
differs, record it with `qt capabilities set zerodha ...`; the
[capability matrix](capability-matrix.md) explains overrides.
