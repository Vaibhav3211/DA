# Backtesting

A backtest replays one saved strategy configuration over frozen historical candles of one instrument at
one interval. It reports the trades the configuration's signals would have made under trade rules you set
beforehand. It places no orders, calls no provider while it runs, and is not a forecast: its results
describe what happened on those candles, nothing more.

This guide covers getting candles, setting trade rules, running a backtest, how the replay works and how
to read the results. The design is in
[ADR-016](decisions/016-frozen-datasets-and-queued-backtests.md), and the requirements are EXT-3 and
EXT-4 of the [specification extension](specification-extension.md).

- [Before you start](#before-you-start)
- [Step 1: get candles](#step-1-get-candles)
- [Step 2: set the trade rules](#step-2-set-the-trade-rules)
- [Step 3: run the backtest](#step-3-run-the-backtest)
- [How the replay works](#how-the-replay-works)
- [Reading the results](#reading-the-results)
- [Outdated results and run history](#outdated-results-and-run-history)
- [Backtest trades on the chart](#backtest-trades-on-the-chart)
- [Limits and settings](#limits-and-settings)
- [Command and API reference](#command-and-api-reference)
- [Known limitations](#known-limitations)

## Before you start

A backtest needs four things.

1. **The backtest worker.** `qt-backtest-worker` builds requested datasets and runs queued backtests, one
   job at a time. `scripts\start-dev.ps1` opens it in its own window, and Docker Compose runs it as the
   `backtest-worker` service. Run exactly one. Without it, requests are accepted but wait, and the panel
   and `qt` warn: "The backtest worker is not running, so queued jobs wait; start qt-backtest-worker".
2. **A saved configuration** that can be replayed
   ([saving a configuration](operations/live-monitoring.md#saving-a-configuration)):
   - its strategy and indicators use closed candles of one interval only;
   - it reacts to no market events (ticks or depth) and needs no data that only events carry;
   - it is eligible for the instrument's market, exchange, segment and type;
   - the instrument is in its scope (for a whole-workspace scope, in the workspace).
3. **Trade rules**, declared by the strategy or saved with the configuration
   ([step 2](#step-2-set-the-trade-rules)).
4. **A READY dataset** of the instrument at the strategy's interval ([step 1](#step-1-get-candles)).

Live signals need not be on. Backtests and live monitoring are separate actions, and neither starts the
other.

## Step 1: get candles

A dataset freezes one instrument's candles at one interval over a range of exchange-local dates, from one
source. The backtest worker builds it once. A READY dataset never changes: its content hash identifies its
candles, and every backtest records the hash of the dataset it replayed.

### Sources

| Source | `--source` | Candles | Needs |
| --- | --- | --- | --- |
| Provider history | `provider-history` (the default) | Downloaded from the Zerodha or Groww historical-candle API, only when you ask | An enabled account of the provider with a current access token, on a plan that includes the API (for Zerodha, the paid Kite Connect plan) |
| Recorded | `recorded` | The closed candles this platform built from the Zerodha or Groww live feed | Closed candles recorded in the range |
| Simulated | `simulated` | The closed candles built from the development simulator (`--provider simulator`) | Simulator candles in the range. Everything built on them is labelled **SIMULATED**: they are not market prices. |

Missing candles are never filled in, interpolated, or taken from another provider or source.

Provider history downloads with the provider's enabled account (a provider has at most one), unless
`--account` names another of its accounts. Recorded and simulated candles use no account.

### What the providers offer

| | Zerodha Kite Connect | Groww Trading API |
| --- | --- | --- |
| Call | `GET /instruments/historical/{token}/{interval}` | `GET /historical/candles` |
| Intervals | 1m, 3m, 5m, 15m, 30m, 1h, 1d | 1m, 3m, 5m, 15m, 30m, 1h, 1d |
| Dates per request | 1m: 30; 3m and 5m: 90; 15m and 30m: 180; 1h: 365; 1d: 1800 | 1m, 3m and 5m: 30; 15m and 30m: 90; 1h and 1d: 180 |
| Instruments | cash, F&O, currency, commodity, indices | cash and F&O only (no indices) |
| Request rate | 3 per second | 20 per second and 500 per minute (Groww's non-trading limits) |
| Notes | Needs the paid Kite Connect plan. Open interest is downloaded for futures and options. | Groww documents candles from 2020 onwards. |

Zerodha's dates per request are kept below Kite's published limits. A longer range is split into several
requests, sent one after another, and the dataset records how many were made. Timestamps are candle
starts. Both downloads follow the providers' documentation and have not yet run against a real account
(see [known limitations](#known-limitations)).

### Requesting candles

In the chart's Strategy panel, a configuration's **Run backtest…** → **Get candles…** opens a form listing
each source (it opens by itself when no dataset is ready): available ones, unavailable ones with the
reason ("Unavailable: …"), the request size ("Downloaded in requests of up to N days each") and what has
been recorded. Choose the source and the dates, then **Request candles**. Provider history names the
account it downloads with.

From the command line:

```powershell
qt datasets sources NSE:CASH:EQUITY:INFY     # what each source can supply, and what was recorded
qt datasets request NSE:CASH:EQUITY:INFY --provider zerodha --interval 5m --from 2025-01-01 --to 2025-06-30
qt datasets request NSE:CASH:EQUITY:INFY --provider groww --source recorded --interval 1m --from 2026-01-05 --to 2026-01-09
qt datasets show DATASET_ID                  # status, candles, coverage and gaps
qt datasets list --instrument NSE:CASH:EQUITY:INFY --status ready
```

A request only queues the dataset:

| Status | Meaning |
| --- | --- |
| `PENDING` | Waiting for the backtest worker. |
| `BUILDING` | The worker is downloading or collecting the candles. |
| `READY` | Stored with its coverage and content hash. It never changes. |
| `FAILED` | It could not be built, and says why. Request it again once the cause is fixed. |

Asking again for the same instrument, provider, source, interval, dates and account while it is PENDING
or BUILDING returns that request. Once it is READY, the same request makes a new dataset (for example,
after more days were recorded), and the old one stays. Each request is audited
(`backtest_dataset.request`).

These requests are refused at once, with the reason:

- the first date is after the last, or the last is after today on the exchange;
- more than 7,305 dates (20 years);
- more candles than `BACKTEST_MAX_CANDLES` would fit in the range (estimated from the calendar);
- the provider has no mapping for the instrument (refresh its instrument master), or its API does not
  offer the instrument's segment or the interval;
- recorded or simulated candles that do not exist in the range (the message lists what was recorded);
- `--account` with a source other than provider history, or a source that does not match the provider.

### Coverage: how complete the candles are

The worker places every candle on the exchange calendar and measures the dataset against it. **Check the
coverage before trusting a result**: a backtest replays only the candles that exist.

| Field | Meaning |
| --- | --- |
| Expected | Candles the calendar expects on the session days of the range. |
| Present, missing | How many of those the dataset has, and lacks. |
| Coverage | present ÷ expected × 100, rounded down; none when nothing is expected. |
| Gaps | Runs of consecutive missing candles, with their start, end and size. The first 50 are listed; all are counted. |
| Anchor | Intraday only: `SESSION` or `CLOCK`, the grid the candles start on. Both are tried and the one that more candles fit is kept; on a tie, the live candles' `CANDLE_ANCHOR`. A note says when the dataset's grid differs from the live candles'. |
| Assumed days | Session days past the published calendar. Their regular hours are assumed, so a holiday the calendar does not list shows as missing candles. |
| Unknown days | Days without a calendar (MCX, for example). Their candles are kept unchecked and flagged `OUTSIDE_SESSION`, and nothing counts as missing on them. |
| Left out | Candles not on an expected slot, by reason (`CLOSED_DAY`, `OUTSIDE_HOURS`, `OFF_GRID`, `OUTSIDE_DATES`), with up to 10 examples. They are not replayed. |
| Duplicates | Candles received more than once; one is kept. |
| Inconsistent | Candles whose high and low do not contain their open and close. They are kept and flagged. |
| Without volume | Candles with no volume. A strategy that needs volume cannot replay a dataset in which no candle has it. |
| Incomplete | Recorded or simulated candles built from partial data: started late (`PARTIAL_START`), after a gap (`GAP_BEFORE`) or across a disconnection (`DISCONNECTED_DURING`). |
| Requests | Provider requests made. |

Daily candles belong to their exchange-local date. Prices are kept to 8 decimal places.

## Step 2: set the trade rules

Signals are not trades. Before anything can be measured, trade rules must say which sides to trade, when
decisions fill, where stops and targets come from, how entries are sized and what trading costs. Every
rule is required unless marked optional, and nothing is assumed: without rules, a backtest is refused with
"no trade rules are set: set them for this configuration, or declare trade_rules in the strategy".

The rules come from one of two places, and the results say which (`CONFIGURATION` or `STRATEGY`):

1. **The configuration's own rules**, saved with it. They take precedence.
2. **The strategy's declared rules**, its `trade_rules`
   ([declaring trade rules](strategy-registration.md#declaring-trade-rules)), when the configuration has
   none.

| Rule | Values | Meaning |
| --- | --- | --- |
| `sides` | `LONG_ONLY`, `SHORT_ONLY`, `BOTH` | Which positions may be opened. |
| `opposite_signal` | `REVERSE`, `CLOSE` | What a BUY against a short, or a SELL against a long, does: close the position and open the other side when `sides` allows it (`REVERSE`), or only close it (`CLOSE`). |
| `fill` | `NEXT_OPEN`, `SAME_CLOSE` | When a decision taken at a candle's close fills: at the next candle's open, or at that close (optimistic). |
| `exit_check` | `INTRABAR`, `CLOSE` | Whether the stop-loss and target are checked against each candle's high and low, or only its close. |
| `stop_target` | `SIGNAL`, `PERCENT`, `NONE` | Where the stop-loss and target come from: the entry signal, percentages of the entry fill, or nowhere. |
| `stop_pct` | above 0 and below 100 (optional) | `PERCENT` only: the stop-loss distance from the entry fill, in %. |
| `target_pct` | above 0, up to 1000 (optional) | `PERCENT` only: the target distance from the entry fill, in %. |
| `max_holding_candles` | 1 to 100,000 (optional) | Close a position after this many candles. |
| `sizing` | `FIXED_QUANTITY`, `FIXED_AMOUNT`, `RISK_PERCENT` | How many units an entry takes, rounded down to the lot. |
| `quantity` | 1 or more | `FIXED_QUANTITY` only: units per entry. |
| `amount` | above 0 | `FIXED_AMOUNT` only: value per entry. |
| `risk_pct` | above 0, up to 100 | `RISK_PERCENT` only: the share of the realised equity lost at the stop-loss, in %. |
| `initial_capital` | above 0 | Equity at the start. |
| `fee_pct_per_side` | 0 to 10 | Fee on each fill's value, in %. |
| `fee_per_order` | 0 or more | Fixed fee on each fill (entry and exit). |
| `slippage_ticks` | 0 to 1000 | Whole ticks each fill moves against the trade. |

The rules must also agree with each other:

- `PERCENT` needs `stop_pct`, `target_pct` or both, and those two apply only to `PERCENT`;
- `quantity`, `amount` and `risk_pct` each go with their own sizing method only;
- `RISK_PERCENT` needs a stop-loss: `SIGNAL`, or `PERCENT` with `stop_pct`.

**In the panel**, **Trade rules…** (in a configuration's backtest summary, or in the **Run backtest…**
dialog) shows the rules in use and where they come from. **Save rules** saves them with the
configuration; **Remove its own rules** returns to the strategy's.

**From the command line:**

```powershell
qt backtests rules show india-equity "rsi all"
qt backtests rules set india-equity "rsi all" --replace `
  --rule sides=both --rule opposite_signal=reverse --rule fill=next-open --rule exit_check=intrabar `
  --rule stop_target=signal --rule sizing=fixed-quantity --rule quantity=10 --rule initial_capital=100000 `
  --rule fee_pct_per_side=0.03 --rule fee_per_order=20 --rule slippage_ticks=1
qt backtests rules set india-equity "rsi all" --rule quantity=20                 # change one rule
qt backtests rules set india-equity "rsi all" --rule max_holding_candles=null    # remove an optional rule
qt backtests rules clear india-equity "rsi all"                                  # use the strategy's rules
```

`set` starts from the rules in use, so one `--rule` changes one rule. `--replace` starts from none, so
every required rule must be given. Values may be written in lower case with hyphens (`fill=next-open`,
`sizing=risk-percent`). A configuration is named by its label or id, as in `qt strategies`.

Changing the rules makes the configuration's earlier backtests outdated. They are kept
([outdated results](#outdated-results-and-run-history)).

## Step 3: run the backtest

**In the panel:**

1. Open the instrument's chart. In the Strategy panel, each saved configuration has a **Backtest**
   summary, which shows **Not backtested** until a backtest succeeds.
2. **Run backtest…** opens a dialog with the configuration, the instrument, the interval it replays, its
   trade rules and its latest result. It lists the instrument's READY datasets at that interval (source,
   dates, candles, coverage and content hash), datasets still being built, and failed requests. A
   simulated dataset carries a notice, and one with missing candles a warning.
3. Choose a dataset, or use **Get candles…** first, then **Run backtest**. The button stays disabled while
   the backtest cannot run, and the dialog says why.
4. The dialog follows the run, which happens on the backtest worker, not in the browser. When it has
   finished, **View results**.

**From the command line:**

```powershell
qt backtests run india-equity "rsi all" --instrument NSE:CASH:EQUITY:INFY --dataset DATASET_ID
qt backtests latest india-equity "rsi all" --instrument NSE:CASH:EQUITY:INFY
qt backtests show BACKTEST_ID
```

A backtest is `QUEUED`, then `RUNNING`, then `SUCCEEDED` or `FAILED`. Asking again for the same
configuration, instrument, dataset and settings while that backtest waits, runs or has succeeded returns
it instead of running it twice ("This exact backtest … already succeeded, so it was not run again"). A
failed backtest can be queued again. Each queued backtest is audited (`backtest.queue`).

### Why a backtest is refused

These refusals come when you queue, before anything runs:

| Message (abridged) | What to do |
| --- | --- |
| "… is not in its instrument scope; choose one of its instruments or change its scope" | Backtest an instrument in its scope, or edit the scope. |
| "its scope is the whole workspace, and … is not in workspace …" | Add the instrument to the workspace, or choose another. |
| "no trade rules are set: …" | [Set the trade rules](#step-2-set-the-trade-rules). |
| "the saved trade rules no longer validate (…)" | Set them again, or clear them. |
| "… uses 5m candles, and the dataset has 1m candles" | Request candles at the strategy's interval. |
| "… uses 1m, 5m candles; a backtest replays the candles of one interval" | Not supported. |
| "… reacts to market events (…), which candles cannot replay" | Not supported. |
| "slippage is set in ticks, and … has no tick size" | Set `slippage_ticks=0`, or refresh the instrument master. |
| "risk rules that apply to history have invalid parameters (…)" | Fix them with `qt risk set` or `qt risk reset`. |
| "it was saved with version A but the code has B; save it again to upgrade" | Save the configuration again ([versions](strategy-registration.md#versions-and-code-identity)). |
| "it is archived" | Save a new configuration. |
| "… needs volume, and none of the dataset's candles has it" | Use a source with volume. |

The strategy's eligibility rules (market, exchange, segment, instrument type) apply as well.

### What the worker checks before replaying

The worker checks a queued backtest again before replaying it. The backtest fails, with a reason ending
"queue it again", when:

- the dataset is no longer READY with the same content hash and interval;
- the strategy's version or code changed after it was queued ("the strategy's code changed after it was
  queued");
- the configuration's settings no longer give the same settings hash;
- the stored candles no longer hash to the dataset's content hash ("request the dataset again").

A result therefore always belongs to the exact code, settings and candles it records.

The worker takes one job at a time, oldest first, building datasets before running backtests. It
refreshes a running job every 15 seconds. Each time it looks for work, it first fails any job that has
shown no progress for 5 minutes (its worker stopped or lost the database); a backtest then says "The
backtest worker stopped while running it; queue it again". Stopping the worker (Ctrl+C) abandons its
current job, which is failed in this way once a worker runs again.

## How the replay works

The replay mirrors live signals as far as candles allow.

1. **Warm-up.** The first candles feed the strategy's indicators until they are warm (the strategy's
   warm-up, and each indicator's). The strategy is first called after them, and only the rest are
   evaluated. A dataset that is too short fails with "needs N … candles to warm up before it is first
   called, and the dataset has M".
2. **Decisions at closes.** Each candle reaches the strategy after it has closed, in order, with the
   indicators up to that candle. The strategy never sees a later price, so there is no look-ahead. Its
   proposals go through the live signal lifecycle (new, update, duplicate, invalidation, expiry).
3. **Risk rules.** Each proposal goes through the rules that make sense for history, with the workspace's
   current settings, at the candle's close: `session_status`, `frequency`, `price_sanity`,
   `volatility_limit` and `stop_loss_required`. Rules about the live system (the kill switch, the
   workspace pause, `LIVE_SIGNALS_ENABLED`, the configuration's state, feed quality and instrument
   status) do not apply to history; eligibility is checked once beforehand. Blocked signals never trade,
   and they are counted per rule.
4. **Signals to trades.** Allowed BUY, SELL and EXIT signals act on the position:
   - BUY opens a long and SELL a short, when `sides` allows it; otherwise the entry is skipped, with the
     reason;
   - a signal on the side of the open position is ignored;
   - an opposite BUY or SELL closes the position (`OPPOSITE_SIGNAL`) and, with `REVERSE`, opens the other
     side when `sides` allows it;
   - EXIT closes the position (`EXIT_SIGNAL`), or cancels an entry that has not filled yet.
5. **Fills.** `NEXT_OPEN` fills a decision at the next candle's open, the first price after it.
   `SAME_CLOSE` fills it at the close it was taken at, a price known only once the candle had closed, so
   its results are optimistic and say so. Each fill moves `slippage_ticks` ticks against the trade and
   pays `fee_pct_per_side` % of its value plus `fee_per_order`, rounded to two decimal places.
6. **Stops and targets.**
   - `SIGNAL` uses the entry signal's stop-loss and first target, and follows the updates the strategy
     makes to that signal. `PERCENT` measures them from the entry fill. `NONE` has neither.
   - `INTRABAR` exits when a candle's low or high reaches a level, at the level. When a candle opens
     beyond a level (a gap), the exit fills at the open, which is worse than the level.
   - **When one candle reaches both the stop-loss and the target**, the order of prices inside it is
     unknown, so the stop-loss is assumed. The trade is marked "both touched", and the notes count such
     trades.
   - `CLOSE` checks the levels against closes only. A close beyond a level decides an exit, which fills
     like any decision (at the next open, or at that close).
   - `max_holding_candles` decides an exit (`MAX_HOLDING`) at the close of the candle that reaches it.
   - A position is checked from the candle it entered in when it filled at an open, and from the next
     candle when it filled at a close.
7. **Sizing.** `FIXED_QUANTITY` takes `quantity` units. `FIXED_AMOUNT` takes `amount` ÷ the fill price.
   `RISK_PERCENT` takes the realised equity (the initial capital plus the closed trades' net results) ×
   `risk_pct` ÷ 100 ÷ the distance from the fill to the stop-loss. Each is rounded down to the lot. There
   is no margin model: an entry worth more than the equity is taken in full and counted in the notes.
8. **Entries not taken.** An entry is skipped, with its reason, when its fill price is already at or
   beyond the signal's stop-loss or target, when equity is not positive, when sizing gives less than one
   lot, when `RISK_PERCENT` has no stop-loss or no distance to it, or when an EXIT cancels it first. The
   first 50 are listed; all are counted.
9. **The end of the data.** A position still open after the last candle is not a closed trade. It is
   reported separately, marked at the last close. Decisions taken at the last close have no candle left
   to fill on, and are listed as decided but not filled.

### Signals at the close and `session_status`

By default `session_status` allows signals only while the session is `OPEN`. A signal is decided at its
candle's close, so signals on **the last candle of each session** and on **every daily candle** are
decided when the session is `POST_CLOSE`, and are blocked, in backtests and live alike. The results' notes
say so, with the count per state.

To let them through, add `POST_CLOSE` to the rule's `allowed_states`. On the workspace's **Risk** tab (or
the System page, for every workspace), choose **Tune** on Session status, set the parameters to
`{"allowed_states": ["OPEN", "POST_CLOSE"]}` and **Save**. From the command line:

```powershell
# PowerShell 7
qt risk set session_status --workspace india-equity --param 'allowed_states=["OPEN","POST_CLOSE"]'
# Windows PowerShell 5.1 needs the inner quotes escaped
qt risk set session_status --workspace india-equity --param 'allowed_states=[\"OPEN\",\"POST_CLOSE\"]'
```

This lets live signals through after the close as well. The history risk settings are part of every
backtest's settings, so the workspace's earlier backtests become outdated.

## Reading the results

**Results…** in the backtest summary, or `qt backtests show BACKTEST_ID`, shows a backtest. Its results
replay the past on the dataset's candles: they are not a forecast.

### The summary

| Metric | Definition |
| --- | --- |
| Testing period | The dataset's dates, then the evaluated period: its first and last candle and how many candles were evaluated after the warm-up candles, which only fed the indicators. |
| Data source | The dataset's provider and source, its coverage and its content hash. |
| Closed trades | Trades opened and closed in the evaluated period. The position open at the end is not one. |
| Wins · losses · breakeven | By each closed trade's net result: above zero is a win, below zero a loss, exactly zero breakeven. |
| Win rate | wins ÷ closed trades × 100. Breakeven trades count in the total. Signals, the open position and strategy scores never count. |
| Average win, average loss | The mean net result of the winning trades, and of the losing trades (negative). |
| Gross result | The closed trades' results at their reference prices (the open, close or level each fill was based on, before slippage and fees), with the gross return: that amount over the initial capital, in %. |
| Net result | The closed trades' net results, after slippage and fees, with the net return over the initial capital, in %. |
| Profit factor | The winning trades' net results added up, ÷ the losing trades' net results added up (as a positive amount). |
| Maximum drawdown | The largest fall of equity from an earlier peak, with equity marked at every candle close (the open position included), in money and as a % of the peak. Falls inside a candle are not seen. |
| Fees · slippage | What the closed trades paid in fees, and lost to slippage. |
| Final equity | The equity at the last close: the initial capital plus the closed trades' net results, plus the open position at its mark. |

Hovering over a metric in the results shows its definition.

**Undefined is not zero.** A metric that cannot be calculated shows why, instead of a number:

| Reason | Metrics |
| --- | --- |
| "No closed trades" | Win rate and profit factor |
| "No winning trades" | Average win |
| "No losing trades" | Average loss |
| "No losing trades, so there is no loss to divide by" | Profit factor, when trades closed but none lost |
| "No equity points" | Maximum drawdown |
| "The equity peak before the fall was not positive" | Maximum drawdown in % |

With no closed trades, the panel says: "No closed trades, so its win rate and other trade metrics are
undefined (not zero)."

### The other sections

| Section | What it holds |
| --- | --- |
| Equity curve | Equity at candle closes, sampled to at most 2,000 points for display. The drawdown uses every close. |
| Open at the end: not a closed trade | The open position, marked at the last close, with its unrealised result after the entry fee. |
| Decided but not filled | Decisions taken at the last close, with no candle left to fill on. |
| Signals: not trades | What the strategy proposed: proposed, allowed (and how many of them were updates), blocked by risk rules (in total and per rule), duplicates, invalidations and expired. These count signals; they are never a win rate. |
| Notes | What to keep in mind: simulated data, optimistic `SAME_CLOSE` fills, close-only exit checks, both-touched trades, oversized entries, candles without the volume the strategy needs, signals blocked by `session_status`, a strategy that does not emit actionable signals live, and "No trade closed in the evaluated period." |
| Trades | Every closed trade, in order, and the entries not taken, with their reasons. Selecting a trade shows its outcome and exit reason (`STOP_LOSS`, `TARGET`, `EXIT_SIGNAL`, `OPPOSITE_SIGNAL` or `MAX_HOLDING`); its net result, return, gross result, fees and slippage; its fills (side, quantity, candle, reference and fill price); the stop-loss and target in force when it closed, and the candles held; whether it was a gap exit or touched both levels; the entry and exit signals behind it, with their levels, reasons and indicator values; and what it was recorded with. |
| Data | The dataset: source, interval, dates and candles, the first and last candle, the content hash and the coverage, gaps included. |
| Strategy and settings | The configuration, the strategy's id, version and code fingerprint, the settings hash and the instrument; the parameters, lot and tick size, signal validity and engine version; where the trade rules came from; each history risk rule's settings, and the live-only rules not applied. |
| Trade rules | The rules used. |
| Run | When it was requested and by whom, when it started and finished, the worker, the engine version and the backtest's id. |

From the command line:

```powershell
qt backtests show BACKTEST_ID --curve    # with the equity curve's points
qt backtests trades BACKTEST_ID          # closed trades, 100 at a time (--limit, --offset)
qt backtests trade BACKTEST_ID 7         # one trade, with the signals behind its fills
```

## Outdated results and run history

Each backtest records the settings it ran with, and their hash:

- the engine version;
- the strategy's id, version and code fingerprint;
- the configuration's parameters and their hash;
- the instrument, the interval, the lot size and the tick size;
- the trade rules;
- the signal validity;
- the history risk rules' settings.

Its data is identified separately, by the dataset's content hash. Its source, provider, dates and
coverage are shown with it.

When a configuration is selected, the panel shows its latest backtest on the chart's instrument:

| State | Meaning |
| --- | --- |
| **Current** | The latest succeeded backtest with the configuration's current settings. |
| **Outdated** | The latest succeeded backtest ran with other settings. The panel lists what changed: "Changed since that backtest: … Its results are kept for comparison; run a new backtest for the current settings." |
| **Not backtested** | No backtest of the configuration on the instrument has succeeded. Nothing runs until you run one. |

Nothing reruns a backtest by itself: not price updates, not opening the chart, not changing settings. The
panel re-reads the stored result every 60 seconds, and every 3 seconds while a backtest is queued or
running.

Earlier runs are kept for comparison. **All runs…** lists them, newest first, each marked current or
outdated; so does `qt backtests list --workspace india-equity --config "rsi all"`. A backtest on another
dataset with the same settings is not outdated: it is another run, listed alongside.

## Backtest trades on the chart

When a configuration is applied to the chart (**Apply to chart**), the trades of its current backtest are
drawn as muted circles, unlike the arrows and squares of live signals. Each sits on the bar that contains
its fill:

| Marker | Meaning |
| --- | --- |
| Circle below the bar, labelled `N·BT7` | Backtest long entry of trade 7, for the configuration numbered N |
| Circle above the bar | Backtest short entry |
| Circle on the other side of the bar | Backtest exit |

- Only the current backtest is drawn, never an outdated one, and only when it replayed the chart's
  interval and provider, so that its trades line up with the bars. The newest 200 closed trades are drawn.
- Otherwise the chart says "Backtest trades not drawn: …" with the reason, for example "switch the chart
  to 5m to draw its trades".
- **Backtest trades** above the chart hides or shows them (shown by default).
- Clicking a backtest marker opens its trade. When several share a bar, pick one. The open position at
  the end appears only in the results.

## Limits and settings

| Setting | Default | Effect |
| --- | --- | --- |
| `BACKTEST_MAX_CANDLES` | 250000 | The most candles a dataset may hold (1 to 5,000,000). Checked when requesting (estimated from the calendar) and again when building. |
| `BACKTEST_MAX_SECONDS` | 600 | The longest a replay may run. It stops with "stopped after … at candle i of n; use a shorter dataset or raise BACKTEST_MAX_SECONDS". |
| `BACKTEST_POLL_SECONDS` | 2 | How often an idle backtest worker looks for jobs. |
| `BACKTEST_WORKER_METRICS_PORT` | 0 | The worker's Prometheus metrics on `127.0.0.1:<port>/metrics`; 0 disables them. |
| `STRATEGY_TIMEOUT_SECONDS` | as live | Also limits each strategy call during a replay. |

Fixed limits: a dataset covers at most 7,305 dates; a backtest stores at most 20,000 closed trades (more
fails, suggesting "use fewer dates, a longer interval or stricter rules"); lists return at most 500 items
per page.

## Command and API reference

```powershell
qt datasets sources INSTRUMENT
qt datasets request INSTRUMENT --provider PROVIDER [--source SOURCE] --interval INTERVAL --from YYYY-MM-DD --to YYYY-MM-DD [--account ACCOUNT]
qt datasets list [--instrument KEY] [--interval INTERVAL] [--status STATUS] [--limit N] [--offset N]
qt datasets show DATASET_ID

qt backtests rules show WORKSPACE CONFIGURATION
qt backtests rules set WORKSPACE CONFIGURATION --rule KEY=VALUE [--rule KEY=VALUE ...] [--replace]
qt backtests rules clear WORKSPACE CONFIGURATION
qt backtests run WORKSPACE CONFIGURATION --instrument KEY --dataset DATASET_ID
qt backtests latest WORKSPACE CONFIGURATION --instrument KEY
qt backtests list [--workspace WORKSPACE --config CONFIGURATION] [--instrument KEY] [--status STATUS] [--limit N] [--offset N]
qt backtests show BACKTEST_ID [--curve]
qt backtests trades BACKTEST_ID [--limit N] [--offset N]
qt backtests trade BACKTEST_ID NUMBER
```

`PROVIDER` is `zerodha`, `groww` or `simulator`; `SOURCE` is `provider-history` (the default),
`recorded` or `simulated`.

The REST API, under `/api/v1`, needs a signed-in session like the rest of the app
([terminal sign-in](security/secrets-and-auth.md#terminal-sign-in)):

| Call | Purpose |
| --- | --- |
| `GET /datasets/sources?instrument=KEY` | What each source can supply for the instrument |
| `POST /datasets` | Request a dataset (202) |
| `GET /datasets`, `GET /datasets/{id}` | List and read datasets |
| `GET`, `PUT`, `DELETE /deployments/{id}/backtest-rules` | Read, save or remove a configuration's own trade rules |
| `POST /backtests` | Queue a backtest (202); `created` is false when an identical one is returned |
| `GET /backtests` | Backtests, newest first, each marked outdated or not |
| `GET /backtests/latest?deployment_id=ID&instrument=KEY` | The panel's summary: `CURRENT`, `OUTDATED` or `NOT_BACKTESTED`, and why it cannot run now |
| `GET /backtests/{id}` | A backtest with its summary, dataset, equity curve and the settings changed since |
| `GET /backtests/{id}/trades` | A page of its closed trades (at most 500) |

## Known limitations

- One instrument and one interval per backtest: no portfolio, multi-instrument or multi-timeframe
  backtests.
- Strategies that react to market events (ticks or depth) cannot be replayed.
- No margin, leverage or contract-expiry model. An entry is valued at its full price, oversized entries
  are taken in full, and a futures or options dataset covers one contract, not a rolled series.
- Fees are a percentage plus a fixed amount per fill; taxes and exchange charges are not itemised.
- The order of prices inside a candle is unknown: a candle that reaches both levels assumes the
  stop-loss, and drawdown is measured at closes.
- Live-only risk rules (kill switch, pause, `LIVE_SIGNALS_ENABLED`, feed quality, instrument status) are
  not applied.
- MCX has no exchange calendar here, so the coverage of commodity datasets cannot be measured.
- Datasets and backtests cannot be deleted from `qt` or the API, so they accumulate in the database.
- The Zerodha and Groww downloads were built from their documentation and tested against fixtures only,
  not a real account. Check the coverage of the first real dataset, and compare a few of its candles with
  the provider's own chart.
