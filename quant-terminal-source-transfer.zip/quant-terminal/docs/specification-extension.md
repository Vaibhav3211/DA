# Specification extension: strategy workflow, backtests and markets

Status: accepted on 2026-11-02. This document extends the Phase 1 build specification, which is kept
outside the repository and is not changed. For the features below, this document takes precedence.

The extension builds on what already exists. It reuses the strategy plugin contract, the registry and
catalogue sync, deployments, the strategy worker, the risk gate, the signal lifecycle, the REST and
WebSocket APIs, the generated settings forms and the chart. It does not restart the project or add a
second copy of any of these systems.

| Milestone | Scope | Where it is verified |
|---|---|---|
| M8 | Strategy panel beside the chart, strategy declarations and registration, saved configurations with explicit scope, live monitoring controls and states, chart signal markers, unavailable markets | Backend here; frontend on the development machine |
| M9 | Historical data with coverage, the backtest engine, results, outdated detection, run history | Fixtures here; real data on the development machine |
| M10 | The whole journey on one Indian instrument with real data | Development machine |
| M11 | Crypto provider | To be planned |
| M12 | Forex provider | To be planned |
| M13 | Metals provider (spot XAUUSD/XAGUSD; MCX contracts already come through Zerodha) | To be planned |

Status on 2026-11-02: M8 and M9 are implemented. Their backends pass their automated tests, and M9's
provider downloads are tested against fixtures only. Their frontends have been type-checked with
stand-in packages, but not compiled or run. The completion report lists what is verified, what is not,
and the remaining work for
[M8](completion-report.md#m8-strategy-panel-saved-configurations-and-live-monitoring) and
[M9](completion-report.md#m9-historical-data-and-backtests). M10 to M13 have not started.

## Requirements

Each requirement has an ID so tests, documents and the completion report can refer to it.

### EXT-1 Strategy panel beside each chart

- **EXT-1.1** Selecting an instrument shows a Strategy panel beside its chart.
- **EXT-1.2** The panel lists the registered strategies with their descriptions and versions.
- **EXT-1.3** Each strategy clearly shows whether it suits the instrument: market, instrument, required
  data and timeframe.
- **EXT-1.4** The scope of a new configuration defaults to the selected instrument.
- **EXT-1.5** Applying a strategy to the whole workspace needs an explicit choice.
- **EXT-1.6** Several strategies, and several configurations of one strategy, can be used at once. Each
  configuration is clearly identified.
- **EXT-1.7** Opening a chart or selecting a strategy never starts background monitoring.
- **EXT-1.8** Four separate actions: Apply to chart, Run backtest, Enable live signals and Stop live
  signals.

### EXT-2 Your own strategies

- **EXT-2.1** You supply the trading logic as Python strategies that use the existing plugin contract,
  registered through an explicit, documented workflow.
- **EXT-2.2** Each strategy declares:
  - its name, description, ID and version;
  - the instruments and markets it supports;
  - the timeframes, indicators and warm-up data it needs;
  - its parameters, with defaults and validation;
  - its signal conditions and the inputs each one uses.
- **EXT-2.3** After registration and a catalogue sync, the strategy appears in the panel.
- **EXT-2.4** Settings forms are generated from the strategy's schema.
- **EXT-2.5** A code editor in the browser, or uploading code, is a later feature. It needs proper
  isolation first.

### EXT-3 Saved configurations and reproducible results

- **EXT-3.1** One saved configuration is used by the chart, backtests and live signals.
- **EXT-3.2** A configuration and its results record:
  - the strategy ID, version and code identity;
  - the parameters and the instrument scope;
  - the provider or data source and the timeframe;
  - the historical date range and the dataset identity;
  - position sizing, fees, slippage and fill assumptions.
- **EXT-3.3** Changing a setting that affects results marks older backtests as outdated. Earlier runs
  are kept for comparison.
- **EXT-3.4** Selecting a configuration shows its latest matching backtest, if there is one. Backtests
  are never re-run on price updates. Without a matching result the panel shows "Not backtested".

### EXT-4 Backtest engine and results

- **EXT-4.1** A bounded first version: one Indian instrument, one timeframe and one of your strategies
  per run.
- **EXT-4.2** Backtests use real historical data and show its coverage and any missing data. Fixtures
  are only for automated tests and are never shown as results.
- **EXT-4.3** Entry, exit, stop and target, and sizing rules must be defined, by the strategy or by the
  configuration, before performance can be calculated.
- **EXT-4.4** The engine must:
  - prevent look-ahead bias;
  - say explicitly whether exits are checked at the candle close or within the candle;
  - document what happens when one candle touches both the stop and the target;
  - apply fees, slippage and fill assumptions;
  - report open and closed trades separately.
- **EXT-4.5** Results show:
  - the testing period and data source;
  - the number of closed trades;
  - wins, losses and breakeven trades;
  - the win rate, with its definition;
  - the average win and average loss;
  - gross and net return;
  - profit factor and maximum drawdown;
  - an equity curve and a trade list you can inspect.
- **EXT-4.6** Zero trades and undefined metrics are shown as such. A win rate is never derived from
  signal counts, and a strategy's confidence score is never labelled as a historical win rate.

### EXT-5 Live signals and explanations

- **EXT-5.1** Enabling live signals explicitly starts monitoring the selected saved configuration and
  its instrument scope.
- **EXT-5.2** Monitoring states shown: running, stopped, warming up, blocked and failed.
- **EXT-5.3** Pressing Enable again never creates a duplicate deployment.
- **EXT-5.4** The panel explains whether monitoring continues after the chart is closed.
- **EXT-5.5** A clear Stop control.
- **EXT-5.6** The existing freshness checks, risk rules and `LIVE_SIGNALS_ENABLED` still apply.
- **EXT-5.7** Blocked reasons are shown; nothing is silently discarded.
- **EXT-5.8** BUY, SELL and EXIT signals appear on the chart and in the signal history.
- **EXT-5.9** Clicking a marker shows:
  - the strategy version and configuration;
  - the conditions and indicator values;
  - the instrument, provider and timestamps;
  - the entry, stop and target, where supplied;
  - the risk decision, and any blocking or invalidation reasons.
- **EXT-5.10** Backtest markers and live signals look clearly different.

### EXT-6 Markets and delivery order

- **EXT-6.1** The same workflow is used in every supported market, and the panel shows what each
  provider actually supports.
- **EXT-6.2** Delivery order:
  1. finish the M6/M7 work, including the chart strategy selector and explicit instrument scope (M8);
  2. the backtest engine and results, as a separate milestone (M9);
  3. prove the whole journey with one Indian instrument before expanding (M10);
  4. crypto, Forex and metals, each through its own provider milestone (M11 to M13).
- **EXT-6.3** For metals, exchange-traded commodity contracts are kept distinct from spot instruments
  such as XAUUSD and XAGUSD.
- **EXT-6.4** Unsupported markets are shown as unavailable, with a reason. Feeds are never made up and
  another provider is never silently substituted.

### EXT-7 Validation and completion

- **EXT-7.1** The whole journey is tested: open a chart, select and configure a strategy, run a
  backtest, inspect the results, enable signals, inspect a signal and stop monitoring.
- **EXT-7.2** Checks cover:
  - a wrong instrument scope;
  - outdated results;
  - missing history;
  - zero trades;
  - pressing Enable twice;
  - blocked live signals.
- **EXT-7.3** Documentation explains how to register a strategy, interpret results and operate live
  monitoring.
- **EXT-7.4** The completion report lists separately what is implemented and verified, what is
  implemented but unverified, and the remaining work.

## Design

### Saved configurations are deployments (EXT-1.6, EXT-3.1, EXT-5.3)

A deployment row already stores a strategy, its version, an immutable configuration snapshot, a scope
and an enabled flag. New deployments already start disabled. M8 turns it into the saved configuration
instead of adding a parallel table:

- One strategy can have several configurations in a workspace. The old one-per-strategy rule goes.
- Each configuration has a label, unique among the workspace's active configurations, so it is clearly
  identified.
- "Enable live signals" turns on the configuration's own deployment. Pressing it again changes nothing.
- Enabling is refused while another enabled configuration in the workspace runs the same strategy
  version, with the same parameters, on an overlapping instrument. The error names that configuration.
- A configuration is archived rather than deleted, so its signal history stays. Only a stopped
  configuration can be archived.
- Signals already record their deployment and run; the run records the configuration snapshot, its hash
  and the code fingerprint. M9 backtests record the same, plus their own settings.

### Explicit scope (EXT-1.4, EXT-1.5)

- A scope is either "these instruments" or "the whole workspace". The API has no default: a request
  must name one.
- The panel offers "This instrument" by default. The whole workspace is a separate option that must be
  selected and confirmed.
- Today an empty scope silently means the whole workspace. The migration rewrites existing empty scopes
  as an explicit whole-workspace scope, so their behaviour does not change.
- The CLI requires `--instrument` (repeatable) or `--whole-workspace`.

### Strategy declarations and registration (EXT-2)

- Existing metadata already declares name, description, ID, version, markets, segments, instrument
  types, candle intervals (the timeframes), indicators with their intervals, and warm-up candles. The
  settings model declares the parameters, their defaults and their validation.
- M8 adds:
  - optional exchanges and instrument keys, to restrict a strategy further;
  - signal conditions: for each signal type, a description and the inputs it uses (indicator aliases or
    candle fields);
  - required data, such as traded volume.
- Registration validates every declaration and refuses to start when one is missing or inconsistent.
- Your strategies live in `backend/app/strategies/custom/` and are listed explicitly in that package.
  The same import allow-list test covers them. `qt strategies check` validates them without starting
  anything; a restart and a catalogue sync make them appear in the panel.
- A strategy's timeframes are fixed by its declaration. Choosing a timeframe per configuration is later
  work.

### Compatibility (EXT-1.3, EXT-6.1)

For each strategy and the selected instrument, the panel shows a list of checks, each passed, warning
or failed:

- **Market:** the instrument's market is one the strategy supports.
- **Instrument:** exchange, segment, instrument type and any instrument keys.
- **Timeframe:** every interval the strategy needs is built by the platform (`CANDLE_INTERVALS`). The
  chart's interval is shown for comparison.
- **Data:** event types and required data are supported by the instrument's bound provider. The panel
  also shows whether enough candles are stored to finish warming up now, or whether the strategy will
  warm up from live data.

A strategy with a failed check cannot be applied to that instrument.

### Monitoring states (EXT-5.2, EXT-5.4, EXT-5.6, EXT-5.7)

One state per configuration, with reasons:

| State | When |
|---|---|
| Stopped | Live signals are off. |
| Starting | Enabled; the worker has not started a run yet. |
| Warming up | The run is waiting for enough closed candles; progress is shown. |
| Running | The run is evaluating every closed candle. |
| Blocked | Enabled, but every signal would be blocked or the run cannot start. Reasons include the kill switch, a paused workspace, `LIVE_SIGNALS_ENABLED=false` for live data, an unrunnable deployment, and no instruments in scope. |
| Failed | The run failed, its circuit is open, or the strategy worker's heartbeat is missing. |

- Monitoring runs in the strategy worker on the server. It continues after the chart or the browser is
  closed, until you stop it. The panel says so next to the Enable button.
- Blocked candidates are still stored as BLOCKED signals with their reasons, as today.

### Chart markers (EXT-5.8 to EXT-5.10)

- Apply to chart shows a configuration's stored results on the chart; it computes nothing and starts
  nothing.
  - **M8:** live signal markers.
  - **M9:** the trades of its latest matching backtest.
- Live signals are solid arrows, numbered after the configuration (BUY below the candle, SELL above it,
  EXIT as a square). Blocked signals are grey.
- Backtest trades (M9) are circles marked "BT", in muted colours.
- Clicking a marker opens the existing signal detail, extended with the configuration label, its
  settings snapshot, the hash and the code fingerprint.

### Historical data (M9; EXT-4.2)

- Data comes from two sources:
  - the Zerodha and Groww historical-candle APIs, downloaded only when you ask;
  - the candles the platform recorded from its own feed.
- Each download or snapshot becomes an immutable dataset. A dataset records the instrument, interval,
  provider, source, range, candle count, a SHA-256 of its candles (its identity), and its coverage
  against the exchange calendar, with the gaps listed.
- MCX has no calendar yet, so MCX coverage is shown as unverified.
- Candles recorded from the simulator form SIMULATED datasets. They exercise the workflow but are always
  labelled as simulated, never as historical results.

### Backtest semantics (M9; EXT-4.3 to EXT-4.6)

- **Order of events:**
  - The strategy runs on each closed candle in turn, through the same contract, indicators and context
    as live, with a simulated clock.
  - Decisions are taken at a candle's close. By default orders fill at the next candle's open.
  - Filling at the same candle's close is an explicit option, labelled optimistic.
- **Exits:**
  - Stops and targets are checked either within the candle, using its high and low, or only at its
    close. The configuration says which.
  - When one candle touches both, the stop is always assumed to have come first. This is conservative,
    and there is no option to change it. Such trades are flagged and counted.
  - A gap through a level fills at the open.
- **Trade rules:** these come from the strategy's declared defaults or from the configuration:
  - which sides may be traded;
  - what an opposite signal does: reverse the position or only close it;
  - where the stop and target come from: the signal's levels, fixed percentages, or none;
  - an optional maximum holding period;
  - sizing: fixed quantity, fixed amount, or a percentage of equity at risk, rounded down to the lot
    size;
  - fees: a percentage per side plus a fixed amount per order;
  - slippage, in ticks per fill.
  - Without complete rules, no performance is calculated.
- **Risk rules:** the rules that make sense for history (signal frequency, price sanity, volatility
  limit, stop-loss required, session) are applied to replayed signals. Rules about the present moment
  (kill switch, pause, live signals, freshness) are listed as not applicable.
- **Metrics:**
  - **Win rate** is winning closed trades divided by all closed trades. A trade is a win when its net
    result, after fees and slippage, is above zero. A trade whose net result rounds to 0.00 is
    breakeven; it is not a win but counts in the denominator.
  - **Gross** results are before fees and slippage; **net** results are after both.
  - **Profit factor** is net profit from wins divided by net loss from losses.
  - **Maximum drawdown** is the largest fall from a peak on the equity curve, which is marked at every
    candle close.
  - Open positions at the end are reported separately, valued at the last close, and left out of the
    closed-trade statistics.
  - Undefined values are shown with their reason, for example "no closed trades" or "no losing trades".
- **Outdated results:**
  - Each run stores a settings hash over everything in EXT-3.2 except the dataset, plus the dataset
    identity.
  - The panel shows the latest run that matches the configuration's current settings. Older runs are
    marked outdated, with what changed, and are kept for comparison.
- **Running a backtest:** a backtest runs as a queued job outside the web request, with limits on
  candles and duration.

### Markets (EXT-6)

Market availability is derived from provider capabilities and shown with reasons:

- **Available through Zerodha and Groww:** NSE and BSE cash, F&O and indices.
- **Zerodha only:** MCX commodity contracts, including exchange-traded gold and silver, and NSE currency
  derivatives. MCX sessions show as UNKNOWN until an MCX calendar exists.
- **Unavailable:**
  - crypto, with no provider adapter (M11);
  - spot Forex, with no provider adapter (M12);
  - spot metals such as XAUUSD and XAGUSD, with no provider adapter; these are not MCX contracts (M13).

## Milestones in detail

### M8: strategy panel, saved configurations and live monitoring

Done when:

- the panel, declarations, saved configurations, explicit scope, monitoring states, markers and market
  availability above are built;
- Run backtest shows "Not backtested";
- backend tests cover declarations, scope, duplicate enables, monitoring states, compatibility and the
  migration;
- frontend helpers have unit tests;
- the registration and live-monitoring guides are written.

Status: implemented; see the
[completion report](completion-report.md#m8-strategy-panel-saved-configurations-and-live-monitoring).

### M9: historical data and backtests

Done when:

- datasets download from both providers; the parsers are tested against fixtures;
- recorded-candle snapshots work;
- the engine, metrics, results view, outdated detection and run history work;
- tests cover look-ahead, both-touch candles, zero trades, missing history and outdated results.

Status: implemented; see the [backtesting guide](backtesting.md),
[ADR-016](decisions/016-frozen-datasets-and-queued-backtests.md) and the
[completion report](completion-report.md#m9-historical-data-and-backtests). Downloading real history is
first tried in M10.

### M10: the whole journey on one Indian instrument

Done when you complete EXT-7.1 on the development machine with real data and one of your strategies,
and the completion report records the outcome. An integration test already runs the journey over the
API with fixture candles and a fixture strategy; M10 repeats it in the browser with real data.

### M11 to M13: new markets

Each milestone starts by choosing a provider and checking its terms, data rights and capabilities. Until
then, those markets show as unavailable.

## Out of scope for now

- Placing orders (ADR-011).
- A code editor in the browser, or uploading strategy code (EXT-2.5).
- Previewing signals on the chart for configurations that were never backtested or live.
- Choosing a timeframe per configuration.
- Portfolio-level, multi-instrument or multi-timeframe backtests.
